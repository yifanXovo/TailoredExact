* Signature: 0x297e46184c726c5b
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 E  onehot_31_26
 E  normalized_mass_31_27
 E  normalized_ratio_31_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 E  onehot_25_61
 E  normalized_mass_25_62
 E  normalized_ratio_25_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 E  onehot_32_90
 E  normalized_mass_32_91
 E  normalized_ratio_32_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 E  onehot_29_125
 E  normalized_mass_29_126
 E  normalized_ratio_29_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 E  onehot_2_160
 E  normalized_mass_2_161
 E  normalized_ratio_2_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 E  onehot_24_195
 E  normalized_mass_24_196
 E  normalized_ratio_24_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 G  product_lb_216
 L  product_ub_217
 G  product_lb_218
 L  product_ub_219
 G  product_lb_220
 L  product_ub_221
 G  product_lb_222
 L  product_ub_223
 G  product_lb_224
 L  product_ub_225
 G  product_lb_226
 L  product_ub_227
 G  product_lb_228
 L  product_ub_229
 E  onehot_12_230
 E  normalized_mass_12_231
 E  normalized_ratio_12_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 G  product_lb_255
 L  product_ub_256
 G  product_lb_257
 L  product_ub_258
 G  product_lb_259
 L  product_ub_260
 G  product_lb_261
 L  product_ub_262
 G  product_lb_263
 L  product_ub_264
 E  onehot_27_265
 E  normalized_mass_27_266
 E  normalized_ratio_27_267
 G  stock_lb_268
 L  stock_ub_269
 L  parent_nonstrict_scope_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 G  block_pair_pos_317
 G  block_pair_neg_318
 G  block_pair_pos_319
 G  block_pair_neg_320
 G  block_pair_pos_321
 G  block_pair_neg_322
 G  block_pair_pos_323
 G  block_pair_neg_324
 G  block_pair_pos_325
 G  block_pair_neg_326
 E  normalization_327
 G  full_original_Gini_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 E  unique_nonzero_owner_428
 E  unique_nonzero_owner_429
 E  unique_nonzero_owner_430
 E  unique_nonzero_owner_431
 E  unique_nonzero_owner_432
 E  unique_nonzero_owner_433
 E  unique_nonzero_owner_434
 E  unique_nonzero_owner_435
 E  unique_nonzero_owner_436
 E  unique_nonzero_owner_437
 E  unique_nonzero_owner_438
 E  unique_nonzero_owner_439
 E  unique_nonzero_owner_440
 E  unique_nonzero_owner_441
 E  unique_nonzero_owner_442
 L  arc_capacity_443
 L  arc_capacity_444
 L  arc_capacity_445
 L  arc_capacity_446
 L  arc_capacity_447
 L  arc_capacity_448
 L  arc_capacity_449
 L  arc_capacity_450
 L  arc_capacity_451
 L  arc_capacity_452
 L  arc_capacity_453
 L  arc_capacity_454
 L  arc_capacity_455
 L  arc_capacity_456
 L  arc_capacity_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 G  connected_order_arc_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 L  arc_capacity_733
 G  connected_order_arc_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 G  connected_order_arc_748
 L  arc_capacity_749
 G  connected_order_arc_750
 L  arc_capacity_751
 G  connected_order_arc_752
 L  arc_capacity_753
 G  connected_order_arc_754
 L  arc_capacity_755
 G  connected_order_arc_756
 L  arc_capacity_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 L  arc_capacity_768
 G  connected_order_arc_769
 L  arc_capacity_770
 G  connected_order_arc_771
 L  arc_capacity_772
 G  connected_order_arc_773
 L  arc_capacity_774
 G  connected_order_arc_775
 L  arc_capacity_776
 G  connected_order_arc_777
 L  arc_capacity_778
 G  connected_order_arc_779
 L  arc_capacity_780
 G  connected_order_arc_781
 E  depot_departure_or_bypass_782
 E  depot_return_or_bypass_783
 E  out_degree_784
 E  in_degree_785
 G  order_active_lb_786
 L  order_active_ub_787
 E  segment_load_conservation_788
 G  segment_prefix_lb_789
 L  segment_prefix_ub_790
 E  out_degree_791
 E  in_degree_792
 G  order_active_lb_793
 L  order_active_ub_794
 E  segment_load_conservation_795
 G  segment_prefix_lb_796
 L  segment_prefix_ub_797
 E  out_degree_798
 E  in_degree_799
 G  order_active_lb_800
 L  order_active_ub_801
 E  segment_load_conservation_802
 G  segment_prefix_lb_803
 L  segment_prefix_ub_804
 E  out_degree_805
 E  in_degree_806
 G  order_active_lb_807
 L  order_active_ub_808
 E  segment_load_conservation_809
 G  segment_prefix_lb_810
 L  segment_prefix_ub_811
 E  out_degree_812
 E  in_degree_813
 G  order_active_lb_814
 L  order_active_ub_815
 E  segment_load_conservation_816
 G  segment_prefix_lb_817
 L  segment_prefix_ub_818
 E  out_degree_819
 E  in_degree_820
 G  order_active_lb_821
 L  order_active_ub_822
 E  service_visit_def_823
 E  free_load_conservation_824
 E  out_degree_825
 E  in_degree_826
 G  order_active_lb_827
 L  order_active_ub_828
 E  service_visit_def_829
 E  free_load_conservation_830
 E  out_degree_831
 E  in_degree_832
 G  order_active_lb_833
 L  order_active_ub_834
 E  service_visit_def_835
 E  free_load_conservation_836
 E  out_degree_837
 E  in_degree_838
 G  order_active_lb_839
 L  order_active_ub_840
 E  service_visit_def_841
 E  free_load_conservation_842
 E  out_degree_843
 E  in_degree_844
 G  order_active_lb_845
 L  order_active_ub_846
 E  service_visit_def_847
 E  free_load_conservation_848
 E  out_degree_849
 E  in_degree_850
 G  order_active_lb_851
 L  order_active_ub_852
 E  service_visit_def_853
 E  free_load_conservation_854
 E  out_degree_855
 E  in_degree_856
 G  order_active_lb_857
 L  order_active_ub_858
 E  service_visit_def_859
 E  free_load_conservation_860
 E  out_degree_861
 E  in_degree_862
 G  order_active_lb_863
 L  order_active_ub_864
 E  service_visit_def_865
 E  free_load_conservation_866
 G  fixed_segment_relative_order_867
 G  fixed_segment_relative_order_868
 G  fixed_segment_relative_order_869
 G  fixed_segment_relative_order_870
 L  original_T_including_depot_unload_871
 L  arc_capacity_872
 L  arc_capacity_873
 L  arc_capacity_874
 L  arc_capacity_875
 L  arc_capacity_876
 L  arc_capacity_877
 L  arc_capacity_878
 L  arc_capacity_879
 L  arc_capacity_880
 L  arc_capacity_881
 L  arc_capacity_882
 L  arc_capacity_883
 L  arc_capacity_884
 L  arc_capacity_885
 L  arc_capacity_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 G  connected_order_arc_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 G  connected_order_arc_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 L  arc_capacity_1128
 G  connected_order_arc_1129
 L  arc_capacity_1130
 G  connected_order_arc_1131
 L  arc_capacity_1132
 G  connected_order_arc_1133
 L  arc_capacity_1134
 G  connected_order_arc_1135
 L  arc_capacity_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 L  arc_capacity_1139
 G  connected_order_arc_1140
 L  arc_capacity_1141
 G  connected_order_arc_1142
 L  arc_capacity_1143
 G  connected_order_arc_1144
 L  arc_capacity_1145
 G  connected_order_arc_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 L  arc_capacity_1149
 G  connected_order_arc_1150
 L  arc_capacity_1151
 G  connected_order_arc_1152
 L  arc_capacity_1153
 G  connected_order_arc_1154
 L  arc_capacity_1155
 G  connected_order_arc_1156
 L  arc_capacity_1157
 G  connected_order_arc_1158
 L  arc_capacity_1159
 G  connected_order_arc_1160
 L  arc_capacity_1161
 L  arc_capacity_1162
 G  connected_order_arc_1163
 L  arc_capacity_1164
 G  connected_order_arc_1165
 L  arc_capacity_1166
 G  connected_order_arc_1167
 L  arc_capacity_1168
 G  connected_order_arc_1169
 L  arc_capacity_1170
 G  connected_order_arc_1171
 L  arc_capacity_1172
 G  connected_order_arc_1173
 L  arc_capacity_1174
 G  connected_order_arc_1175
 L  arc_capacity_1176
 G  connected_order_arc_1177
 L  arc_capacity_1178
 G  connected_order_arc_1179
 L  arc_capacity_1180
 G  connected_order_arc_1181
 L  arc_capacity_1182
 G  connected_order_arc_1183
 L  arc_capacity_1184
 G  connected_order_arc_1185
 L  arc_capacity_1186
 L  arc_capacity_1187
 G  connected_order_arc_1188
 L  arc_capacity_1189
 G  connected_order_arc_1190
 L  arc_capacity_1191
 G  connected_order_arc_1192
 L  arc_capacity_1193
 G  connected_order_arc_1194
 L  arc_capacity_1195
 G  connected_order_arc_1196
 L  arc_capacity_1197
 G  connected_order_arc_1198
 L  arc_capacity_1199
 G  connected_order_arc_1200
 L  arc_capacity_1201
 G  connected_order_arc_1202
 L  arc_capacity_1203
 G  connected_order_arc_1204
 L  arc_capacity_1205
 G  connected_order_arc_1206
 L  arc_capacity_1207
 G  connected_order_arc_1208
 L  arc_capacity_1209
 G  connected_order_arc_1210
 E  depot_departure_or_bypass_1211
 E  depot_return_or_bypass_1212
 E  out_degree_1213
 E  in_degree_1214
 G  order_active_lb_1215
 L  order_active_ub_1216
 E  segment_load_conservation_1217
 G  segment_prefix_lb_1218
 L  segment_prefix_ub_1219
 E  out_degree_1220
 E  in_degree_1221
 G  order_active_lb_1222
 L  order_active_ub_1223
 E  segment_load_conservation_1224
 G  segment_prefix_lb_1225
 L  segment_prefix_ub_1226
 E  out_degree_1227
 E  in_degree_1228
 G  order_active_lb_1229
 L  order_active_ub_1230
 E  segment_load_conservation_1231
 G  segment_prefix_lb_1232
 L  segment_prefix_ub_1233
 E  out_degree_1234
 E  in_degree_1235
 G  order_active_lb_1236
 L  order_active_ub_1237
 E  segment_load_conservation_1238
 G  segment_prefix_lb_1239
 L  segment_prefix_ub_1240
 E  out_degree_1241
 E  in_degree_1242
 G  order_active_lb_1243
 L  order_active_ub_1244
 E  segment_load_conservation_1245
 G  segment_prefix_lb_1246
 L  segment_prefix_ub_1247
 E  out_degree_1248
 E  in_degree_1249
 G  order_active_lb_1250
 L  order_active_ub_1251
 E  service_visit_def_1252
 E  free_load_conservation_1253
 E  out_degree_1254
 E  in_degree_1255
 G  order_active_lb_1256
 L  order_active_ub_1257
 E  service_visit_def_1258
 E  free_load_conservation_1259
 E  out_degree_1260
 E  in_degree_1261
 G  order_active_lb_1262
 L  order_active_ub_1263
 E  service_visit_def_1264
 E  free_load_conservation_1265
 E  out_degree_1266
 E  in_degree_1267
 G  order_active_lb_1268
 L  order_active_ub_1269
 E  service_visit_def_1270
 E  free_load_conservation_1271
 E  out_degree_1272
 E  in_degree_1273
 G  order_active_lb_1274
 L  order_active_ub_1275
 E  service_visit_def_1276
 E  free_load_conservation_1277
 E  out_degree_1278
 E  in_degree_1279
 G  order_active_lb_1280
 L  order_active_ub_1281
 E  service_visit_def_1282
 E  free_load_conservation_1283
 E  out_degree_1284
 E  in_degree_1285
 G  order_active_lb_1286
 L  order_active_ub_1287
 E  service_visit_def_1288
 E  free_load_conservation_1289
 E  out_degree_1290
 E  in_degree_1291
 G  order_active_lb_1292
 L  order_active_ub_1293
 E  service_visit_def_1294
 E  free_load_conservation_1295
 G  fixed_segment_relative_order_1296
 G  fixed_segment_relative_order_1297
 G  fixed_segment_relative_order_1298
 G  fixed_segment_relative_order_1299
 L  original_T_including_depot_unload_1300
 L  arc_capacity_1301
 L  arc_capacity_1302
 L  arc_capacity_1303
 L  arc_capacity_1304
 L  arc_capacity_1305
 L  arc_capacity_1306
 L  arc_capacity_1307
 L  arc_capacity_1308
 L  arc_capacity_1309
 L  arc_capacity_1310
 L  arc_capacity_1311
 L  arc_capacity_1312
 L  arc_capacity_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 L  arc_capacity_1395
 G  connected_order_arc_1396
 L  arc_capacity_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 G  connected_order_arc_1415
 L  arc_capacity_1416
 G  connected_order_arc_1417
 L  arc_capacity_1418
 L  arc_capacity_1419
 G  connected_order_arc_1420
 L  arc_capacity_1421
 G  connected_order_arc_1422
 L  arc_capacity_1423
 G  connected_order_arc_1424
 L  arc_capacity_1425
 G  connected_order_arc_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 G  connected_order_arc_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 G  connected_order_arc_1436
 L  arc_capacity_1437
 G  connected_order_arc_1438
 L  arc_capacity_1439
 L  arc_capacity_1440
 G  connected_order_arc_1441
 L  arc_capacity_1442
 G  connected_order_arc_1443
 L  arc_capacity_1444
 G  connected_order_arc_1445
 L  arc_capacity_1446
 G  connected_order_arc_1447
 L  arc_capacity_1448
 G  connected_order_arc_1449
 L  arc_capacity_1450
 G  connected_order_arc_1451
 L  arc_capacity_1452
 G  connected_order_arc_1453
 L  arc_capacity_1454
 G  connected_order_arc_1455
 L  arc_capacity_1456
 G  connected_order_arc_1457
 L  arc_capacity_1458
 G  connected_order_arc_1459
 L  arc_capacity_1460
 L  arc_capacity_1461
 G  connected_order_arc_1462
 L  arc_capacity_1463
 G  connected_order_arc_1464
 L  arc_capacity_1465
 G  connected_order_arc_1466
 L  arc_capacity_1467
 G  connected_order_arc_1468
 L  arc_capacity_1469
 G  connected_order_arc_1470
 L  arc_capacity_1471
 G  connected_order_arc_1472
 L  arc_capacity_1473
 G  connected_order_arc_1474
 L  arc_capacity_1475
 G  connected_order_arc_1476
 L  arc_capacity_1477
 G  connected_order_arc_1478
 L  arc_capacity_1479
 G  connected_order_arc_1480
 L  arc_capacity_1481
 L  arc_capacity_1482
 G  connected_order_arc_1483
 L  arc_capacity_1484
 G  connected_order_arc_1485
 L  arc_capacity_1486
 G  connected_order_arc_1487
 L  arc_capacity_1488
 G  connected_order_arc_1489
 L  arc_capacity_1490
 G  connected_order_arc_1491
 L  arc_capacity_1492
 G  connected_order_arc_1493
 L  arc_capacity_1494
 G  connected_order_arc_1495
 L  arc_capacity_1496
 G  connected_order_arc_1497
 L  arc_capacity_1498
 G  connected_order_arc_1499
 L  arc_capacity_1500
 G  connected_order_arc_1501
 L  arc_capacity_1502
 L  arc_capacity_1503
 G  connected_order_arc_1504
 L  arc_capacity_1505
 G  connected_order_arc_1506
 L  arc_capacity_1507
 G  connected_order_arc_1508
 L  arc_capacity_1509
 G  connected_order_arc_1510
 L  arc_capacity_1511
 G  connected_order_arc_1512
 L  arc_capacity_1513
 G  connected_order_arc_1514
 L  arc_capacity_1515
 G  connected_order_arc_1516
 L  arc_capacity_1517
 G  connected_order_arc_1518
 L  arc_capacity_1519
 G  connected_order_arc_1520
 L  arc_capacity_1521
 G  connected_order_arc_1522
 L  arc_capacity_1523
 L  arc_capacity_1524
 G  connected_order_arc_1525
 L  arc_capacity_1526
 G  connected_order_arc_1527
 L  arc_capacity_1528
 G  connected_order_arc_1529
 L  arc_capacity_1530
 G  connected_order_arc_1531
 L  arc_capacity_1532
 G  connected_order_arc_1533
 L  arc_capacity_1534
 G  connected_order_arc_1535
 L  arc_capacity_1536
 G  connected_order_arc_1537
 L  arc_capacity_1538
 G  connected_order_arc_1539
 L  arc_capacity_1540
 G  connected_order_arc_1541
 L  arc_capacity_1542
 G  connected_order_arc_1543
 E  depot_departure_or_bypass_1544
 E  depot_return_or_bypass_1545
 E  out_degree_1546
 E  in_degree_1547
 G  order_active_lb_1548
 L  order_active_ub_1549
 E  segment_load_conservation_1550
 G  segment_prefix_lb_1551
 L  segment_prefix_ub_1552
 E  out_degree_1553
 E  in_degree_1554
 G  order_active_lb_1555
 L  order_active_ub_1556
 E  segment_load_conservation_1557
 G  segment_prefix_lb_1558
 L  segment_prefix_ub_1559
 E  out_degree_1560
 E  in_degree_1561
 G  order_active_lb_1562
 L  order_active_ub_1563
 E  segment_load_conservation_1564
 G  segment_prefix_lb_1565
 L  segment_prefix_ub_1566
 E  out_degree_1567
 E  in_degree_1568
 G  order_active_lb_1569
 L  order_active_ub_1570
 E  service_visit_def_1571
 E  free_load_conservation_1572
 E  out_degree_1573
 E  in_degree_1574
 G  order_active_lb_1575
 L  order_active_ub_1576
 E  service_visit_def_1577
 E  free_load_conservation_1578
 E  out_degree_1579
 E  in_degree_1580
 G  order_active_lb_1581
 L  order_active_ub_1582
 E  service_visit_def_1583
 E  free_load_conservation_1584
 E  out_degree_1585
 E  in_degree_1586
 G  order_active_lb_1587
 L  order_active_ub_1588
 E  service_visit_def_1589
 E  free_load_conservation_1590
 E  out_degree_1591
 E  in_degree_1592
 G  order_active_lb_1593
 L  order_active_ub_1594
 E  service_visit_def_1595
 E  free_load_conservation_1596
 E  out_degree_1597
 E  in_degree_1598
 G  order_active_lb_1599
 L  order_active_ub_1600
 E  service_visit_def_1601
 E  free_load_conservation_1602
 E  out_degree_1603
 E  in_degree_1604
 G  order_active_lb_1605
 L  order_active_ub_1606
 E  service_visit_def_1607
 E  free_load_conservation_1608
 E  out_degree_1609
 E  in_degree_1610
 G  order_active_lb_1611
 L  order_active_ub_1612
 E  service_visit_def_1613
 E  free_load_conservation_1614
 G  fixed_segment_relative_order_1615
 G  fixed_segment_relative_order_1616
 L  original_T_including_depot_unload_1617
COLUMNS
    t         normalized_mass_31_27  -1
    t         normalized_mass_25_62  -1
    t         normalized_mass_32_91  -1
    t         normalized_mass_29_126  -1
    t         normalized_mass_2_161  -1
    t         normalized_mass_24_196  -1
    t         normalized_mass_12_231  -1
    t         normalized_mass_27_266  -1
    t         normalization_327  2.4007142857142856e+01
    t         full_original_Gini_328  -1.0343571428571437e+02
    q         OBJ       1
    q         parent_nonstrict_scope_270  1
    q         full_original_Gini_328  35
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_0  -2.4726245143034259e-02
    x_31_0    product_ub_1  -4.1654269562671840e-02
    x_31_0    onehot_31_26  1
    x_31_0    parent_nonstrict_scope_270  0.0735
    x_31_0    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_0  1
    w_31_0    product_ub_1  1
    w_31_0    normalized_mass_31_27  1
    w_31_0    full_original_Gini_328  -2.4007142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_2  -2.4726245143034259e-02
    x_31_1    product_ub_3  -4.1654269562671840e-02
    x_31_1    onehot_31_26  1
    x_31_1    stock_lb_268  1
    x_31_1    stock_ub_269  1
    x_31_1    parent_nonstrict_scope_270  0.063
    x_31_1    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_2  1
    w_31_1    product_ub_3  1
    w_31_1    normalized_mass_31_27  1
    w_31_1    normalized_ratio_31_28  -1.4285714285714285e-01
    w_31_1    full_original_Gini_328  -2.0435714285714294e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_4  -2.4726245143034259e-02
    x_31_2    product_ub_5  -4.1654269562671840e-02
    x_31_2    onehot_31_26  1
    x_31_2    stock_lb_268  2
    x_31_2    stock_ub_269  2
    x_31_2    parent_nonstrict_scope_270  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_4  1
    w_31_2    product_ub_5  1
    w_31_2    normalized_mass_31_27  1
    w_31_2    normalized_ratio_31_28  -2.8571428571428570e-01
    w_31_2    full_original_Gini_328  -1.6935714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_6  -2.4726245143034259e-02
    x_31_3    product_ub_7  -4.1654269562671840e-02
    x_31_3    onehot_31_26  1
    x_31_3    stock_lb_268  3
    x_31_3    stock_ub_269  3
    x_31_3    parent_nonstrict_scope_270  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_6  1
    w_31_3    product_ub_7  1
    w_31_3    normalized_mass_31_27  1
    w_31_3    normalized_ratio_31_28  -4.2857142857142855e-01
    w_31_3    full_original_Gini_328  -1.3764285714285712e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_8  -2.4726245143034259e-02
    x_31_4    product_ub_9  -4.1654269562671840e-02
    x_31_4    onehot_31_26  1
    x_31_4    stock_lb_268  4
    x_31_4    stock_ub_269  4
    x_31_4    parent_nonstrict_scope_270  0.0315
    x_31_4    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_8  1
    w_31_4    product_ub_9  1
    w_31_4    normalized_mass_31_27  1
    w_31_4    normalized_ratio_31_28  -5.7142857142857140e-01
    w_31_4    full_original_Gini_328  -1.1192857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_10  -2.4726245143034259e-02
    x_31_5    product_ub_11  -4.1654269562671840e-02
    x_31_5    onehot_31_26  1
    x_31_5    stock_lb_268  5
    x_31_5    stock_ub_269  5
    x_31_5    parent_nonstrict_scope_270  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_10  1
    w_31_5    product_ub_11  1
    w_31_5    normalized_mass_31_27  1
    w_31_5    normalized_ratio_31_28  -7.1428571428571419e-01
    w_31_5    full_original_Gini_328  -8.7642857142857160e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_12  -2.4726245143034259e-02
    x_31_6    product_ub_13  -4.1654269562671840e-02
    x_31_6    onehot_31_26  1
    x_31_6    stock_lb_268  6
    x_31_6    stock_ub_269  6
    x_31_6    parent_nonstrict_scope_270  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_12  1
    w_31_6    product_ub_13  1
    w_31_6    normalized_mass_31_27  1
    w_31_6    normalized_ratio_31_28  -8.5714285714285710e-01
    w_31_6    full_original_Gini_328  -6.3357142857142872e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_14  -2.4726245143034259e-02
    x_31_7    product_ub_15  -4.1654269562671840e-02
    x_31_7    onehot_31_26  1
    x_31_7    stock_lb_268  7
    x_31_7    stock_ub_269  7
    x_31_7    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_14  1
    w_31_7    product_ub_15  1
    w_31_7    normalized_mass_31_27  1
    w_31_7    normalized_ratio_31_28  -1
    w_31_7    full_original_Gini_328  -4.6928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_16  -2.4726245143034259e-02
    x_31_8    product_ub_17  -4.1654269562671840e-02
    x_31_8    onehot_31_26  1
    x_31_8    stock_lb_268  8
    x_31_8    stock_ub_269  8
    x_31_8    parent_nonstrict_scope_270  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_16  1
    w_31_8    product_ub_17  1
    w_31_8    normalized_mass_31_27  1
    w_31_8    normalized_ratio_31_28  -1.1428571428571428e+00
    w_31_8    full_original_Gini_328  -7.4071428571428548e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_18  -2.4726245143034259e-02
    x_31_9    product_ub_19  -4.1654269562671840e-02
    x_31_9    onehot_31_26  1
    x_31_9    stock_lb_268  9
    x_31_9    stock_ub_269  9
    x_31_9    parent_nonstrict_scope_270  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_18  1
    w_31_9    product_ub_19  1
    w_31_9    normalized_mass_31_27  1
    w_31_9    normalized_ratio_31_28  -1.2857142857142856e+00
    w_31_9    full_original_Gini_328  -1.0707142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_20  -2.4726245143034259e-02
    x_31_10   product_ub_21  -4.1654269562671840e-02
    x_31_10   onehot_31_26  1
    x_31_10   stock_lb_268  10
    x_31_10   stock_ub_269  10
    x_31_10   parent_nonstrict_scope_270  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_20  1
    w_31_10   product_ub_21  1
    w_31_10   normalized_mass_31_27  1
    w_31_10   normalized_ratio_31_28  -1.4285714285714284e+00
    w_31_10   full_original_Gini_328  -1.4564285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_22  -2.4726245143034259e-02
    x_31_11   product_ub_23  -4.1654269562671840e-02
    x_31_11   onehot_31_26  1
    x_31_11   stock_lb_268  11
    x_31_11   stock_ub_269  11
    x_31_11   parent_nonstrict_scope_270  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_22  1
    w_31_11   product_ub_23  1
    w_31_11   normalized_mass_31_27  1
    w_31_11   normalized_ratio_31_28  -1.5714285714285714e+00
    w_31_11   full_original_Gini_328  -1.8421428571428567e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_24  -2.4726245143034259e-02
    x_31_12   product_ub_25  -4.1654269562671840e-02
    x_31_12   onehot_31_26  1
    x_31_12   stock_lb_268  12
    x_31_12   stock_ub_269  12
    x_31_12   parent_nonstrict_scope_270  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_24  1
    w_31_12   product_ub_25  1
    w_31_12   normalized_mass_31_27  1
    w_31_12   normalized_ratio_31_28  -1.7142857142857142e+00
    w_31_12   full_original_Gini_328  -2.2278571428571425e+01
    rho_31    normalized_ratio_31_28  1
    rho_31    block_pair_pos_303  -1
    rho_31    block_pair_neg_304  1
    rho_31    block_pair_pos_305  -1
    rho_31    block_pair_neg_306  1
    rho_31    block_pair_pos_307  -1
    rho_31    block_pair_neg_308  1
    rho_31    block_pair_pos_309  -1
    rho_31    block_pair_neg_310  1
    rho_31    block_pair_pos_311  -1
    rho_31    block_pair_neg_312  1
    rho_31    block_pair_pos_313  -1
    rho_31    block_pair_neg_314  1
    rho_31    block_pair_pos_315  -1
    rho_31    block_pair_neg_316  1
    rho_31    normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_25_0    OBJ       0.0315
    x_25_0    product_lb_29  -2.4726245143034259e-02
    x_25_0    product_ub_30  -4.1654269562671840e-02
    x_25_0    onehot_25_61  1
    x_25_0    parent_nonstrict_scope_270  0.0735
    x_25_0    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_0    product_lb_29  1
    w_25_0    product_ub_30  1
    w_25_0    normalized_mass_25_62  1
    w_25_0    full_original_Gini_328  -2.4007142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_1    OBJ       2.1000000000000005e-02
    x_25_1    product_lb_31  -2.4726245143034259e-02
    x_25_1    product_ub_32  -4.1654269562671840e-02
    x_25_1    onehot_25_61  1
    x_25_1    stock_lb_268  1
    x_25_1    stock_ub_269  1
    x_25_1    parent_nonstrict_scope_270  0.063
    MARKER    'MARKER'                 'INTEND'
    w_25_1    product_lb_31  1
    w_25_1    product_ub_32  1
    w_25_1    normalized_mass_25_62  1
    w_25_1    normalized_ratio_25_63  -1.4285714285714285e-01
    w_25_1    full_original_Gini_328  -2.0435714285714294e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_2    OBJ       1.0500000000000002e-02
    x_25_2    product_lb_33  -2.4726245143034259e-02
    x_25_2    product_ub_34  -4.1654269562671840e-02
    x_25_2    onehot_25_61  1
    x_25_2    stock_lb_268  2
    x_25_2    stock_ub_269  2
    x_25_2    parent_nonstrict_scope_270  0.0525
    x_25_2    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_2    product_lb_33  1
    w_25_2    product_ub_34  1
    w_25_2    normalized_mass_25_62  1
    w_25_2    normalized_ratio_25_63  -2.8571428571428570e-01
    w_25_2    full_original_Gini_328  -1.6935714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_3    product_lb_35  -2.4726245143034259e-02
    x_25_3    product_ub_36  -4.1654269562671840e-02
    x_25_3    onehot_25_61  1
    x_25_3    stock_lb_268  3
    x_25_3    stock_ub_269  3
    x_25_3    parent_nonstrict_scope_270  4.1999999999999996e-02
    x_25_3    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_3    product_lb_35  1
    w_25_3    product_ub_36  1
    w_25_3    normalized_mass_25_62  1
    w_25_3    normalized_ratio_25_63  -4.2857142857142855e-01
    w_25_3    full_original_Gini_328  -1.3764285714285712e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_4    OBJ       -1.0499999999999995e-02
    x_25_4    product_lb_37  -2.4726245143034259e-02
    x_25_4    product_ub_38  -4.1654269562671840e-02
    x_25_4    onehot_25_61  1
    x_25_4    stock_lb_268  4
    x_25_4    stock_ub_269  4
    x_25_4    parent_nonstrict_scope_270  0.0315
    x_25_4    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_4    product_lb_37  1
    w_25_4    product_ub_38  1
    w_25_4    normalized_mass_25_62  1
    w_25_4    normalized_ratio_25_63  -5.7142857142857140e-01
    w_25_4    full_original_Gini_328  -1.1192857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_5    OBJ       -2.0999999999999991e-02
    x_25_5    product_lb_39  -2.4726245143034259e-02
    x_25_5    product_ub_40  -4.1654269562671840e-02
    x_25_5    onehot_25_61  1
    x_25_5    stock_lb_268  5
    x_25_5    stock_ub_269  5
    x_25_5    parent_nonstrict_scope_270  2.1000000000000005e-02
    x_25_5    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_5    product_lb_39  1
    w_25_5    product_ub_40  1
    w_25_5    normalized_mass_25_62  1
    w_25_5    normalized_ratio_25_63  -7.1428571428571419e-01
    w_25_5    full_original_Gini_328  -8.7642857142857160e+00
    MARKER    'MARKER'                 'INTORG'
    x_25_6    OBJ       -3.1499999999999993e-02
    x_25_6    product_lb_41  -2.4726245143034259e-02
    x_25_6    product_ub_42  -4.1654269562671840e-02
    x_25_6    onehot_25_61  1
    x_25_6    stock_lb_268  6
    x_25_6    stock_ub_269  6
    x_25_6    parent_nonstrict_scope_270  1.0500000000000002e-02
    x_25_6    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_6    product_lb_41  1
    w_25_6    product_ub_42  1
    w_25_6    normalized_mass_25_62  1
    w_25_6    normalized_ratio_25_63  -8.5714285714285710e-01
    w_25_6    full_original_Gini_328  -6.3357142857142872e+00
    MARKER    'MARKER'                 'INTORG'
    x_25_7    OBJ       -4.1999999999999996e-02
    x_25_7    product_lb_43  -2.4726245143034259e-02
    x_25_7    product_ub_44  -4.1654269562671840e-02
    x_25_7    onehot_25_61  1
    x_25_7    stock_lb_268  7
    x_25_7    stock_ub_269  7
    x_25_7    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_7    product_lb_43  1
    w_25_7    product_ub_44  1
    w_25_7    normalized_mass_25_62  1
    w_25_7    normalized_ratio_25_63  -1
    w_25_7    full_original_Gini_328  -4.6928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_25_8    OBJ       -0.0315
    x_25_8    product_lb_45  -2.4726245143034259e-02
    x_25_8    product_ub_46  -4.1654269562671840e-02
    x_25_8    onehot_25_61  1
    x_25_8    stock_lb_268  8
    x_25_8    stock_ub_269  8
    x_25_8    parent_nonstrict_scope_270  1.0499999999999995e-02
    x_25_8    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_8    product_lb_45  1
    w_25_8    product_ub_46  1
    w_25_8    normalized_mass_25_62  1
    w_25_8    normalized_ratio_25_63  -1.1428571428571428e+00
    w_25_8    full_original_Gini_328  -7.4071428571428548e+00
    MARKER    'MARKER'                 'INTORG'
    x_25_9    OBJ       -2.1000000000000005e-02
    x_25_9    product_lb_47  -2.4726245143034259e-02
    x_25_9    product_ub_48  -4.1654269562671840e-02
    x_25_9    onehot_25_61  1
    x_25_9    stock_lb_268  9
    x_25_9    stock_ub_269  9
    x_25_9    parent_nonstrict_scope_270  2.0999999999999991e-02
    x_25_9    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_9    product_lb_47  1
    w_25_9    product_ub_48  1
    w_25_9    normalized_mass_25_62  1
    w_25_9    normalized_ratio_25_63  -1.2857142857142856e+00
    w_25_9    full_original_Gini_328  -1.0707142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_10   OBJ       -1.0500000000000009e-02
    x_25_10   product_lb_49  -2.4726245143034259e-02
    x_25_10   product_ub_50  -4.1654269562671840e-02
    x_25_10   onehot_25_61  1
    x_25_10   stock_lb_268  10
    x_25_10   stock_ub_269  10
    x_25_10   parent_nonstrict_scope_270  3.1499999999999986e-02
    x_25_10   unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_10   product_lb_49  1
    w_25_10   product_ub_50  1
    w_25_10   normalized_mass_25_62  1
    w_25_10   normalized_ratio_25_63  -1.4285714285714284e+00
    w_25_10   full_original_Gini_328  -1.4564285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_11   product_lb_51  -2.4726245143034259e-02
    x_25_11   product_ub_52  -4.1654269562671840e-02
    x_25_11   onehot_25_61  1
    x_25_11   stock_lb_268  11
    x_25_11   stock_ub_269  11
    x_25_11   parent_nonstrict_scope_270  4.1999999999999996e-02
    x_25_11   unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_11   product_lb_51  1
    w_25_11   product_ub_52  1
    w_25_11   normalized_mass_25_62  1
    w_25_11   normalized_ratio_25_63  -1.5714285714285714e+00
    w_25_11   full_original_Gini_328  -1.8421428571428567e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_12   OBJ       1.0499999999999995e-02
    x_25_12   product_lb_53  -2.4726245143034259e-02
    x_25_12   product_ub_54  -4.1654269562671840e-02
    x_25_12   onehot_25_61  1
    x_25_12   stock_lb_268  12
    x_25_12   stock_ub_269  12
    x_25_12   parent_nonstrict_scope_270  5.2499999999999991e-02
    x_25_12   unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_12   product_lb_53  1
    w_25_12   product_ub_54  1
    w_25_12   normalized_mass_25_62  1
    w_25_12   normalized_ratio_25_63  -1.7142857142857142e+00
    w_25_12   full_original_Gini_328  -2.2278571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_13   OBJ       2.0999999999999991e-02
    x_25_13   product_lb_55  -2.4726245143034259e-02
    x_25_13   product_ub_56  -4.1654269562671840e-02
    x_25_13   onehot_25_61  1
    x_25_13   stock_lb_268  13
    x_25_13   stock_ub_269  13
    x_25_13   parent_nonstrict_scope_270  6.2999999999999987e-02
    x_25_13   unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_13   product_lb_55  1
    w_25_13   product_ub_56  1
    w_25_13   normalized_mass_25_62  1
    w_25_13   normalized_ratio_25_63  -1.8571428571428570e+00
    w_25_13   full_original_Gini_328  -2.6135714285714290e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_14   OBJ       0.0315
    x_25_14   product_lb_57  -2.4726245143034259e-02
    x_25_14   product_ub_58  -4.1654269562671840e-02
    x_25_14   onehot_25_61  1
    x_25_14   stock_lb_268  14
    x_25_14   stock_ub_269  14
    x_25_14   parent_nonstrict_scope_270  0.0735
    x_25_14   unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_14   product_lb_57  1
    w_25_14   product_ub_58  1
    w_25_14   normalized_mass_25_62  1
    w_25_14   normalized_ratio_25_63  -2
    w_25_14   full_original_Gini_328  -2.9992857142857144e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_15   OBJ       4.1999999999999996e-02
    x_25_15   product_lb_59  -2.4726245143034259e-02
    x_25_15   product_ub_60  -4.1654269562671840e-02
    x_25_15   onehot_25_61  1
    x_25_15   stock_lb_268  15
    x_25_15   stock_ub_269  15
    x_25_15   parent_nonstrict_scope_270  8.3999999999999991e-02
    x_25_15   unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_15   product_lb_59  1
    w_25_15   product_ub_60  1
    w_25_15   normalized_mass_25_62  1
    w_25_15   normalized_ratio_25_63  -2.1428571428571428e+00
    w_25_15   full_original_Gini_328  -3.3849999999999994e+01
    rho_25    normalized_ratio_25_63  1
    rho_25    block_pair_pos_283  -1
    rho_25    block_pair_neg_284  1
    rho_25    block_pair_pos_285  -1
    rho_25    block_pair_neg_286  1
    rho_25    block_pair_pos_287  -1
    rho_25    block_pair_neg_288  1
    rho_25    block_pair_pos_289  -1
    rho_25    block_pair_neg_290  1
    rho_25    block_pair_pos_291  -1
    rho_25    block_pair_neg_292  1
    rho_25    block_pair_pos_293  -1
    rho_25    block_pair_neg_294  1
    rho_25    block_pair_pos_309  1
    rho_25    block_pair_neg_310  -1
    rho_25    normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_64  -2.4726245143034259e-02
    x_32_0    product_ub_65  -4.1654269562671840e-02
    x_32_0    onehot_32_90  1
    x_32_0    parent_nonstrict_scope_270  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_64  1
    w_32_0    product_ub_65  1
    w_32_0    normalized_mass_32_91  1
    w_32_0    full_original_Gini_328  -2.4007142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_66  -2.4726245143034259e-02
    x_32_1    product_ub_67  -4.1654269562671840e-02
    x_32_1    onehot_32_90  1
    x_32_1    stock_lb_268  1
    x_32_1    stock_ub_269  1
    x_32_1    parent_nonstrict_scope_270  0.03
    x_32_1    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_66  1
    w_32_1    product_ub_67  1
    w_32_1    normalized_mass_32_91  1
    w_32_1    normalized_ratio_32_92  -0.2
    w_32_1    full_original_Gini_328  -1.9007142857142863e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_68  -2.4726245143034259e-02
    x_32_2    product_ub_69  -4.1654269562671840e-02
    x_32_2    onehot_32_90  1
    x_32_2    stock_lb_268  2
    x_32_2    stock_ub_269  2
    x_32_2    parent_nonstrict_scope_270  0.0225
    x_32_2    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_68  1
    w_32_2    product_ub_69  1
    w_32_2    normalized_mass_32_91  1
    w_32_2    normalized_ratio_32_92  -0.4
    w_32_2    full_original_Gini_328  -1.4307142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_70  -2.4726245143034259e-02
    x_32_3    product_ub_71  -4.1654269562671840e-02
    x_32_3    onehot_32_90  1
    x_32_3    stock_lb_268  3
    x_32_3    stock_ub_269  3
    x_32_3    parent_nonstrict_scope_270  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_70  1
    w_32_3    product_ub_71  1
    w_32_3    normalized_mass_32_91  1
    w_32_3    normalized_ratio_32_92  -6.0000000000000009e-01
    w_32_3    full_original_Gini_328  -1.0707142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_72  -2.4726245143034259e-02
    x_32_4    product_ub_73  -4.1654269562671840e-02
    x_32_4    onehot_32_90  1
    x_32_4    stock_lb_268  4
    x_32_4    stock_ub_269  4
    x_32_4    parent_nonstrict_scope_270  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_72  1
    w_32_4    product_ub_73  1
    w_32_4    normalized_mass_32_91  1
    w_32_4    normalized_ratio_32_92  -0.8
    w_32_4    full_original_Gini_328  -7.3071428571428587e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_74  -2.4726245143034259e-02
    x_32_5    product_ub_75  -4.1654269562671840e-02
    x_32_5    onehot_32_90  1
    x_32_5    stock_lb_268  5
    x_32_5    stock_ub_269  5
    x_32_5    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_74  1
    w_32_5    product_ub_75  1
    w_32_5    normalized_mass_32_91  1
    w_32_5    normalized_ratio_32_92  -1
    w_32_5    full_original_Gini_328  -4.6928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_76  -2.4726245143034259e-02
    x_32_6    product_ub_77  -4.1654269562671840e-02
    x_32_6    onehot_32_90  1
    x_32_6    stock_lb_268  6
    x_32_6    stock_ub_269  6
    x_32_6    parent_nonstrict_scope_270  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_76  1
    w_32_6    product_ub_77  1
    w_32_6    normalized_mass_32_91  1
    w_32_6    normalized_ratio_32_92  -1.2000000000000002e+00
    w_32_6    full_original_Gini_328  -8.4928571428571473e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_78  -2.4726245143034259e-02
    x_32_7    product_ub_79  -4.1654269562671840e-02
    x_32_7    onehot_32_90  1
    x_32_7    stock_lb_268  7
    x_32_7    stock_ub_269  7
    x_32_7    parent_nonstrict_scope_270  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_78  1
    w_32_7    product_ub_79  1
    w_32_7    normalized_mass_32_91  1
    w_32_7    normalized_ratio_32_92  -1.4000000000000001e+00
    w_32_7    full_original_Gini_328  -1.3792857142857148e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_80  -2.4726245143034259e-02
    x_32_8    product_ub_81  -4.1654269562671840e-02
    x_32_8    onehot_32_90  1
    x_32_8    stock_lb_268  8
    x_32_8    stock_ub_269  8
    x_32_8    parent_nonstrict_scope_270  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_80  1
    w_32_8    product_ub_81  1
    w_32_8    normalized_mass_32_91  1
    w_32_8    normalized_ratio_32_92  -1.6
    w_32_8    full_original_Gini_328  -1.9192857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_82  -2.4726245143034259e-02
    x_32_9    product_ub_83  -4.1654269562671840e-02
    x_32_9    onehot_32_90  1
    x_32_9    stock_lb_268  9
    x_32_9    stock_ub_269  9
    x_32_9    parent_nonstrict_scope_270  0.03
    x_32_9    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_82  1
    w_32_9    product_ub_83  1
    w_32_9    normalized_mass_32_91  1
    w_32_9    normalized_ratio_32_92  -1.8
    w_32_9    full_original_Gini_328  -2.4592857142857152e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_84  -2.4726245143034259e-02
    x_32_10   product_ub_85  -4.1654269562671840e-02
    x_32_10   onehot_32_90  1
    x_32_10   stock_lb_268  10
    x_32_10   stock_ub_269  10
    x_32_10   parent_nonstrict_scope_270  0.0375
    x_32_10   unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_84  1
    w_32_10   product_ub_85  1
    w_32_10   normalized_mass_32_91  1
    w_32_10   normalized_ratio_32_92  -2
    w_32_10   full_original_Gini_328  -2.9992857142857144e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_86  -2.4726245143034259e-02
    x_32_11   product_ub_87  -4.1654269562671840e-02
    x_32_11   onehot_32_90  1
    x_32_11   stock_lb_268  11
    x_32_11   stock_ub_269  11
    x_32_11   parent_nonstrict_scope_270  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_86  1
    w_32_11   product_ub_87  1
    w_32_11   normalized_mass_32_91  1
    w_32_11   normalized_ratio_32_92  -2.2
    w_32_11   full_original_Gini_328  -3.5392857142857139e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_88  -2.4726245143034259e-02
    x_32_12   product_ub_89  -4.1654269562671840e-02
    x_32_12   onehot_32_90  1
    x_32_12   stock_lb_268  12
    x_32_12   stock_ub_269  12
    x_32_12   parent_nonstrict_scope_270  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_88  1
    w_32_12   product_ub_89  1
    w_32_12   normalized_mass_32_91  1
    w_32_12   normalized_ratio_32_92  -2.4000000000000004e+00
    w_32_12   full_original_Gini_328  -4.0792857142857137e+01
    rho_32    normalized_ratio_32_92  1
    rho_32    block_pair_pos_293  1
    rho_32    block_pair_neg_294  -1
    rho_32    block_pair_pos_315  1
    rho_32    block_pair_neg_316  -1
    rho_32    block_pair_pos_317  -1
    rho_32    block_pair_neg_318  1
    rho_32    block_pair_pos_319  -1
    rho_32    block_pair_neg_320  1
    rho_32    block_pair_pos_321  -1
    rho_32    block_pair_neg_322  1
    rho_32    block_pair_pos_323  -1
    rho_32    block_pair_neg_324  1
    rho_32    block_pair_pos_325  -1
    rho_32    block_pair_neg_326  1
    rho_32    normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_29_0    OBJ       0.048
    x_29_0    product_lb_93  -2.4726245143034259e-02
    x_29_0    product_ub_94  -4.1654269562671840e-02
    x_29_0    onehot_29_125  1
    x_29_0    parent_nonstrict_scope_270  0.096
    x_29_0    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_0    product_lb_93  1
    w_29_0    product_ub_94  1
    w_29_0    normalized_mass_29_126  1
    w_29_0    full_original_Gini_328  -2.4007142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_1    OBJ       3.6000000000000004e-02
    x_29_1    product_lb_95  -2.4726245143034259e-02
    x_29_1    product_ub_96  -4.1654269562671840e-02
    x_29_1    onehot_29_125  1
    x_29_1    stock_lb_268  1
    x_29_1    stock_ub_269  1
    x_29_1    parent_nonstrict_scope_270  0.084
    x_29_1    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_1    product_lb_95  1
    w_29_1    product_ub_96  1
    w_29_1    normalized_mass_29_126  1
    w_29_1    normalized_ratio_29_127  -0.125
    w_29_1    full_original_Gini_328  -2.0882142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_2    OBJ       2.4000000000000007e-02
    x_29_2    product_lb_97  -2.4726245143034259e-02
    x_29_2    product_ub_98  -4.1654269562671840e-02
    x_29_2    onehot_29_125  1
    x_29_2    stock_lb_268  2
    x_29_2    stock_ub_269  2
    x_29_2    parent_nonstrict_scope_270  7.2000000000000008e-02
    x_29_2    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_2    product_lb_97  1
    w_29_2    product_ub_98  1
    w_29_2    normalized_mass_29_126  1
    w_29_2    normalized_ratio_29_127  -0.25
    w_29_2    full_original_Gini_328  -1.7757142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_3    OBJ       1.1999999999999997e-02
    x_29_3    product_lb_99  -2.4726245143034259e-02
    x_29_3    product_ub_100  -4.1654269562671840e-02
    x_29_3    onehot_29_125  1
    x_29_3    stock_lb_268  3
    x_29_3    stock_ub_269  3
    x_29_3    parent_nonstrict_scope_270  0.06
    x_29_3    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_3    product_lb_99  1
    w_29_3    product_ub_100  1
    w_29_3    normalized_mass_29_126  1
    w_29_3    normalized_ratio_29_127  -0.375
    w_29_3    full_original_Gini_328  -1.4882142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_4    product_lb_101  -2.4726245143034259e-02
    x_29_4    product_ub_102  -4.1654269562671840e-02
    x_29_4    onehot_29_125  1
    x_29_4    stock_lb_268  4
    x_29_4    stock_ub_269  4
    x_29_4    parent_nonstrict_scope_270  0.048
    x_29_4    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_4    product_lb_101  1
    w_29_4    product_ub_102  1
    w_29_4    normalized_mass_29_126  1
    w_29_4    normalized_ratio_29_127  -0.5
    w_29_4    full_original_Gini_328  -1.2407142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_5    OBJ       -1.1999999999999997e-02
    x_29_5    product_lb_103  -2.4726245143034259e-02
    x_29_5    product_ub_104  -4.1654269562671840e-02
    x_29_5    onehot_29_125  1
    x_29_5    stock_lb_268  5
    x_29_5    stock_ub_269  5
    x_29_5    parent_nonstrict_scope_270  3.6000000000000004e-02
    x_29_5    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_5    product_lb_103  1
    w_29_5    product_ub_104  1
    w_29_5    normalized_mass_29_126  1
    w_29_5    normalized_ratio_29_127  -0.625
    w_29_5    full_original_Gini_328  -1.0282142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_6    OBJ       -0.024
    x_29_6    product_lb_105  -2.4726245143034259e-02
    x_29_6    product_ub_106  -4.1654269562671840e-02
    x_29_6    onehot_29_125  1
    x_29_6    stock_lb_268  6
    x_29_6    stock_ub_269  6
    x_29_6    parent_nonstrict_scope_270  0.024
    x_29_6    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_6    product_lb_105  1
    w_29_6    product_ub_106  1
    w_29_6    normalized_mass_29_126  1
    w_29_6    normalized_ratio_29_127  -0.75
    w_29_6    full_original_Gini_328  -8.1571428571428566e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_7    OBJ       -3.6000000000000004e-02
    x_29_7    product_lb_107  -2.4726245143034259e-02
    x_29_7    product_ub_108  -4.1654269562671840e-02
    x_29_7    onehot_29_125  1
    x_29_7    stock_lb_268  7
    x_29_7    stock_ub_269  7
    x_29_7    parent_nonstrict_scope_270  0.012
    x_29_7    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_7    product_lb_107  1
    w_29_7    product_ub_108  1
    w_29_7    normalized_mass_29_126  1
    w_29_7    normalized_ratio_29_127  -0.875
    w_29_7    full_original_Gini_328  -6.0678571428571439e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_8    OBJ       -0.048
    x_29_8    product_lb_109  -2.4726245143034259e-02
    x_29_8    product_ub_110  -4.1654269562671840e-02
    x_29_8    onehot_29_125  1
    x_29_8    stock_lb_268  8
    x_29_8    stock_ub_269  8
    x_29_8    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_8    product_lb_109  1
    w_29_8    product_ub_110  1
    w_29_8    normalized_mass_29_126  1
    w_29_8    normalized_ratio_29_127  -1
    w_29_8    full_original_Gini_328  -4.6928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_9    OBJ       -3.6000000000000004e-02
    x_29_9    product_lb_111  -2.4726245143034259e-02
    x_29_9    product_ub_112  -4.1654269562671840e-02
    x_29_9    onehot_29_125  1
    x_29_9    stock_lb_268  9
    x_29_9    stock_ub_269  9
    x_29_9    parent_nonstrict_scope_270  0.012
    x_29_9    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_9    product_lb_111  1
    w_29_9    product_ub_112  1
    w_29_9    normalized_mass_29_126  1
    w_29_9    normalized_ratio_29_127  -1.125
    w_29_9    full_original_Gini_328  -7.0678571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_10   OBJ       -0.024
    x_29_10   product_lb_113  -2.4726245143034259e-02
    x_29_10   product_ub_114  -4.1654269562671840e-02
    x_29_10   onehot_29_125  1
    x_29_10   stock_lb_268  10
    x_29_10   stock_ub_269  10
    x_29_10   parent_nonstrict_scope_270  0.024
    x_29_10   unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_10   product_lb_113  1
    w_29_10   product_ub_114  1
    w_29_10   normalized_mass_29_126  1
    w_29_10   normalized_ratio_29_127  -1.25
    w_29_10   full_original_Gini_328  -9.7428571428571420e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_11   OBJ       -1.1999999999999997e-02
    x_29_11   product_lb_115  -2.4726245143034259e-02
    x_29_11   product_ub_116  -4.1654269562671840e-02
    x_29_11   onehot_29_125  1
    x_29_11   stock_lb_268  11
    x_29_11   stock_ub_269  11
    x_29_11   parent_nonstrict_scope_270  3.6000000000000004e-02
    MARKER    'MARKER'                 'INTEND'
    w_29_11   product_lb_115  1
    w_29_11   product_ub_116  1
    w_29_11   normalized_mass_29_126  1
    w_29_11   normalized_ratio_29_127  -1.375
    w_29_11   full_original_Gini_328  -1.3117857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_12   product_lb_117  -2.4726245143034259e-02
    x_29_12   product_ub_118  -4.1654269562671840e-02
    x_29_12   onehot_29_125  1
    x_29_12   stock_lb_268  12
    x_29_12   stock_ub_269  12
    x_29_12   parent_nonstrict_scope_270  0.048
    x_29_12   unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_12   product_lb_117  1
    w_29_12   product_ub_118  1
    w_29_12   normalized_mass_29_126  1
    w_29_12   normalized_ratio_29_127  -1.5
    w_29_12   full_original_Gini_328  -1.6492857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_13   OBJ       1.1999999999999997e-02
    x_29_13   product_lb_119  -2.4726245143034259e-02
    x_29_13   product_ub_120  -4.1654269562671840e-02
    x_29_13   onehot_29_125  1
    x_29_13   stock_lb_268  13
    x_29_13   stock_ub_269  13
    x_29_13   parent_nonstrict_scope_270  0.06
    x_29_13   unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_13   product_lb_119  1
    w_29_13   product_ub_120  1
    w_29_13   normalized_mass_29_126  1
    w_29_13   normalized_ratio_29_127  -1.625
    w_29_13   full_original_Gini_328  -1.9867857142857144e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_14   OBJ       2.4000000000000007e-02
    x_29_14   product_lb_121  -2.4726245143034259e-02
    x_29_14   product_ub_122  -4.1654269562671840e-02
    x_29_14   onehot_29_125  1
    x_29_14   stock_lb_268  14
    x_29_14   stock_ub_269  14
    x_29_14   parent_nonstrict_scope_270  7.2000000000000008e-02
    x_29_14   unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_14   product_lb_121  1
    w_29_14   product_ub_122  1
    w_29_14   normalized_mass_29_126  1
    w_29_14   normalized_ratio_29_127  -1.75
    w_29_14   full_original_Gini_328  -2.3242857142857144e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_15   OBJ       3.6000000000000004e-02
    x_29_15   product_lb_123  -2.4726245143034259e-02
    x_29_15   product_ub_124  -4.1654269562671840e-02
    x_29_15   onehot_29_125  1
    x_29_15   stock_lb_268  15
    x_29_15   stock_ub_269  15
    x_29_15   parent_nonstrict_scope_270  0.084
    x_29_15   unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_15   product_lb_123  1
    w_29_15   product_ub_124  1
    w_29_15   normalized_mass_29_126  1
    w_29_15   normalized_ratio_29_127  -1.875
    w_29_15   full_original_Gini_328  -2.6617857142857144e+01
    rho_29    normalized_ratio_29_127  1
    rho_29    block_pair_pos_291  1
    rho_29    block_pair_neg_292  -1
    rho_29    block_pair_pos_295  -1
    rho_29    block_pair_neg_296  1
    rho_29    block_pair_pos_297  -1
    rho_29    block_pair_neg_298  1
    rho_29    block_pair_pos_299  -1
    rho_29    block_pair_neg_300  1
    rho_29    block_pair_pos_301  -1
    rho_29    block_pair_neg_302  1
    rho_29    block_pair_pos_313  1
    rho_29    block_pair_neg_314  -1
    rho_29    block_pair_pos_325  1
    rho_29    block_pair_neg_326  -1
    rho_29    normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_128  -2.4726245143034259e-02
    x_2_0     product_ub_129  -4.1654269562671840e-02
    x_2_0     onehot_2_160  1
    x_2_0     parent_nonstrict_scope_270  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_128  1
    w_2_0     product_ub_129  1
    w_2_0     normalized_mass_2_161  1
    w_2_0     full_original_Gini_328  -2.4007142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_130  -2.4726245143034259e-02
    x_2_1     product_ub_131  -4.1654269562671840e-02
    x_2_1     onehot_2_160  1
    x_2_1     stock_lb_268  1
    x_2_1     stock_ub_269  1
    x_2_1     parent_nonstrict_scope_270  0.063
    x_2_1     unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_130  1
    w_2_1     product_ub_131  1
    w_2_1     normalized_mass_2_161  1
    w_2_1     normalized_ratio_2_162  -1.4285714285714285e-01
    w_2_1     full_original_Gini_328  -2.0435714285714294e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_132  -2.4726245143034259e-02
    x_2_2     product_ub_133  -4.1654269562671840e-02
    x_2_2     onehot_2_160  1
    x_2_2     stock_lb_268  2
    x_2_2     stock_ub_269  2
    x_2_2     parent_nonstrict_scope_270  0.0525
    x_2_2     unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_132  1
    w_2_2     product_ub_133  1
    w_2_2     normalized_mass_2_161  1
    w_2_2     normalized_ratio_2_162  -2.8571428571428570e-01
    w_2_2     full_original_Gini_328  -1.6935714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_134  -2.4726245143034259e-02
    x_2_3     product_ub_135  -4.1654269562671840e-02
    x_2_3     onehot_2_160  1
    x_2_3     stock_lb_268  3
    x_2_3     stock_ub_269  3
    x_2_3     parent_nonstrict_scope_270  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_134  1
    w_2_3     product_ub_135  1
    w_2_3     normalized_mass_2_161  1
    w_2_3     normalized_ratio_2_162  -4.2857142857142855e-01
    w_2_3     full_original_Gini_328  -1.3764285714285712e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_136  -2.4726245143034259e-02
    x_2_4     product_ub_137  -4.1654269562671840e-02
    x_2_4     onehot_2_160  1
    x_2_4     stock_lb_268  4
    x_2_4     stock_ub_269  4
    x_2_4     parent_nonstrict_scope_270  0.0315
    x_2_4     unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_136  1
    w_2_4     product_ub_137  1
    w_2_4     normalized_mass_2_161  1
    w_2_4     normalized_ratio_2_162  -5.7142857142857140e-01
    w_2_4     full_original_Gini_328  -1.1192857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_138  -2.4726245143034259e-02
    x_2_5     product_ub_139  -4.1654269562671840e-02
    x_2_5     onehot_2_160  1
    x_2_5     stock_lb_268  5
    x_2_5     stock_ub_269  5
    x_2_5     parent_nonstrict_scope_270  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_138  1
    w_2_5     product_ub_139  1
    w_2_5     normalized_mass_2_161  1
    w_2_5     normalized_ratio_2_162  -7.1428571428571419e-01
    w_2_5     full_original_Gini_328  -8.7642857142857160e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_140  -2.4726245143034259e-02
    x_2_6     product_ub_141  -4.1654269562671840e-02
    x_2_6     onehot_2_160  1
    x_2_6     stock_lb_268  6
    x_2_6     stock_ub_269  6
    x_2_6     parent_nonstrict_scope_270  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_140  1
    w_2_6     product_ub_141  1
    w_2_6     normalized_mass_2_161  1
    w_2_6     normalized_ratio_2_162  -8.5714285714285710e-01
    w_2_6     full_original_Gini_328  -6.3357142857142872e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_142  -2.4726245143034259e-02
    x_2_7     product_ub_143  -4.1654269562671840e-02
    x_2_7     onehot_2_160  1
    x_2_7     stock_lb_268  7
    x_2_7     stock_ub_269  7
    x_2_7     unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_142  1
    w_2_7     product_ub_143  1
    w_2_7     normalized_mass_2_161  1
    w_2_7     normalized_ratio_2_162  -1
    w_2_7     full_original_Gini_328  -4.6928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_144  -2.4726245143034259e-02
    x_2_8     product_ub_145  -4.1654269562671840e-02
    x_2_8     onehot_2_160  1
    x_2_8     stock_lb_268  8
    x_2_8     stock_ub_269  8
    x_2_8     parent_nonstrict_scope_270  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_144  1
    w_2_8     product_ub_145  1
    w_2_8     normalized_mass_2_161  1
    w_2_8     normalized_ratio_2_162  -1.1428571428571428e+00
    w_2_8     full_original_Gini_328  -7.4071428571428548e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_146  -2.4726245143034259e-02
    x_2_9     product_ub_147  -4.1654269562671840e-02
    x_2_9     onehot_2_160  1
    x_2_9     stock_lb_268  9
    x_2_9     stock_ub_269  9
    x_2_9     parent_nonstrict_scope_270  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_146  1
    w_2_9     product_ub_147  1
    w_2_9     normalized_mass_2_161  1
    w_2_9     normalized_ratio_2_162  -1.2857142857142856e+00
    w_2_9     full_original_Gini_328  -1.0707142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_148  -2.4726245143034259e-02
    x_2_10    product_ub_149  -4.1654269562671840e-02
    x_2_10    onehot_2_160  1
    x_2_10    stock_lb_268  10
    x_2_10    stock_ub_269  10
    x_2_10    parent_nonstrict_scope_270  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_148  1
    w_2_10    product_ub_149  1
    w_2_10    normalized_mass_2_161  1
    w_2_10    normalized_ratio_2_162  -1.4285714285714284e+00
    w_2_10    full_original_Gini_328  -1.4564285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_150  -2.4726245143034259e-02
    x_2_11    product_ub_151  -4.1654269562671840e-02
    x_2_11    onehot_2_160  1
    x_2_11    stock_lb_268  11
    x_2_11    stock_ub_269  11
    x_2_11    parent_nonstrict_scope_270  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_150  1
    w_2_11    product_ub_151  1
    w_2_11    normalized_mass_2_161  1
    w_2_11    normalized_ratio_2_162  -1.5714285714285714e+00
    w_2_11    full_original_Gini_328  -1.8421428571428567e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_152  -2.4726245143034259e-02
    x_2_12    product_ub_153  -4.1654269562671840e-02
    x_2_12    onehot_2_160  1
    x_2_12    stock_lb_268  12
    x_2_12    stock_ub_269  12
    x_2_12    parent_nonstrict_scope_270  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_152  1
    w_2_12    product_ub_153  1
    w_2_12    normalized_mass_2_161  1
    w_2_12    normalized_ratio_2_162  -1.7142857142857142e+00
    w_2_12    full_original_Gini_328  -2.2278571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_154  -2.4726245143034259e-02
    x_2_13    product_ub_155  -4.1654269562671840e-02
    x_2_13    onehot_2_160  1
    x_2_13    stock_lb_268  13
    x_2_13    stock_ub_269  13
    x_2_13    parent_nonstrict_scope_270  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_154  1
    w_2_13    product_ub_155  1
    w_2_13    normalized_mass_2_161  1
    w_2_13    normalized_ratio_2_162  -1.8571428571428570e+00
    w_2_13    full_original_Gini_328  -2.6135714285714290e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_156  -2.4726245143034259e-02
    x_2_14    product_ub_157  -4.1654269562671840e-02
    x_2_14    onehot_2_160  1
    x_2_14    stock_lb_268  14
    x_2_14    stock_ub_269  14
    x_2_14    parent_nonstrict_scope_270  0.0735
    x_2_14    unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_156  1
    w_2_14    product_ub_157  1
    w_2_14    normalized_mass_2_161  1
    w_2_14    normalized_ratio_2_162  -2
    w_2_14    full_original_Gini_328  -2.9992857142857144e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_158  -2.4726245143034259e-02
    x_2_15    product_ub_159  -4.1654269562671840e-02
    x_2_15    onehot_2_160  1
    x_2_15    stock_lb_268  15
    x_2_15    stock_ub_269  15
    x_2_15    parent_nonstrict_scope_270  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_158  1
    w_2_15    product_ub_159  1
    w_2_15    normalized_mass_2_161  1
    w_2_15    normalized_ratio_2_162  -2.1428571428571428e+00
    w_2_15    full_original_Gini_328  -3.3849999999999994e+01
    rho_2     normalized_ratio_2_162  1
    rho_2     block_pair_pos_271  -1
    rho_2     block_pair_neg_272  1
    rho_2     block_pair_pos_273  -1
    rho_2     block_pair_neg_274  1
    rho_2     block_pair_pos_275  -1
    rho_2     block_pair_neg_276  1
    rho_2     block_pair_pos_283  1
    rho_2     block_pair_neg_284  -1
    rho_2     block_pair_pos_295  1
    rho_2     block_pair_neg_296  -1
    rho_2     block_pair_pos_303  1
    rho_2     block_pair_neg_304  -1
    rho_2     block_pair_pos_317  1
    rho_2     block_pair_neg_318  -1
    rho_2     normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_24_0    OBJ       0.048
    x_24_0    product_lb_163  -2.4726245143034259e-02
    x_24_0    product_ub_164  -4.1654269562671840e-02
    x_24_0    onehot_24_195  1
    x_24_0    parent_nonstrict_scope_270  0.096
    x_24_0    unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_0    product_lb_163  1
    w_24_0    product_ub_164  1
    w_24_0    normalized_mass_24_196  1
    w_24_0    full_original_Gini_328  -2.4007142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_1    OBJ       3.6000000000000004e-02
    x_24_1    product_lb_165  -2.4726245143034259e-02
    x_24_1    product_ub_166  -4.1654269562671840e-02
    x_24_1    onehot_24_195  1
    x_24_1    stock_lb_268  1
    x_24_1    stock_ub_269  1
    x_24_1    parent_nonstrict_scope_270  0.084
    x_24_1    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_1    product_lb_165  1
    w_24_1    product_ub_166  1
    w_24_1    normalized_mass_24_196  1
    w_24_1    normalized_ratio_24_197  -0.125
    w_24_1    full_original_Gini_328  -2.0882142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_2    OBJ       2.4000000000000007e-02
    x_24_2    product_lb_167  -2.4726245143034259e-02
    x_24_2    product_ub_168  -4.1654269562671840e-02
    x_24_2    onehot_24_195  1
    x_24_2    stock_lb_268  2
    x_24_2    stock_ub_269  2
    x_24_2    parent_nonstrict_scope_270  7.2000000000000008e-02
    x_24_2    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_2    product_lb_167  1
    w_24_2    product_ub_168  1
    w_24_2    normalized_mass_24_196  1
    w_24_2    normalized_ratio_24_197  -0.25
    w_24_2    full_original_Gini_328  -1.7757142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_3    OBJ       1.1999999999999997e-02
    x_24_3    product_lb_169  -2.4726245143034259e-02
    x_24_3    product_ub_170  -4.1654269562671840e-02
    x_24_3    onehot_24_195  1
    x_24_3    stock_lb_268  3
    x_24_3    stock_ub_269  3
    x_24_3    parent_nonstrict_scope_270  0.06
    x_24_3    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_3    product_lb_169  1
    w_24_3    product_ub_170  1
    w_24_3    normalized_mass_24_196  1
    w_24_3    normalized_ratio_24_197  -0.375
    w_24_3    full_original_Gini_328  -1.4882142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_4    product_lb_171  -2.4726245143034259e-02
    x_24_4    product_ub_172  -4.1654269562671840e-02
    x_24_4    onehot_24_195  1
    x_24_4    stock_lb_268  4
    x_24_4    stock_ub_269  4
    x_24_4    parent_nonstrict_scope_270  0.048
    x_24_4    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_4    product_lb_171  1
    w_24_4    product_ub_172  1
    w_24_4    normalized_mass_24_196  1
    w_24_4    normalized_ratio_24_197  -0.5
    w_24_4    full_original_Gini_328  -1.2407142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_5    OBJ       -1.1999999999999997e-02
    x_24_5    product_lb_173  -2.4726245143034259e-02
    x_24_5    product_ub_174  -4.1654269562671840e-02
    x_24_5    onehot_24_195  1
    x_24_5    stock_lb_268  5
    x_24_5    stock_ub_269  5
    x_24_5    parent_nonstrict_scope_270  3.6000000000000004e-02
    x_24_5    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_5    product_lb_173  1
    w_24_5    product_ub_174  1
    w_24_5    normalized_mass_24_196  1
    w_24_5    normalized_ratio_24_197  -0.625
    w_24_5    full_original_Gini_328  -1.0282142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_6    OBJ       -0.024
    x_24_6    product_lb_175  -2.4726245143034259e-02
    x_24_6    product_ub_176  -4.1654269562671840e-02
    x_24_6    onehot_24_195  1
    x_24_6    stock_lb_268  6
    x_24_6    stock_ub_269  6
    x_24_6    parent_nonstrict_scope_270  0.024
    x_24_6    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_6    product_lb_175  1
    w_24_6    product_ub_176  1
    w_24_6    normalized_mass_24_196  1
    w_24_6    normalized_ratio_24_197  -0.75
    w_24_6    full_original_Gini_328  -8.1571428571428566e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_7    OBJ       -3.6000000000000004e-02
    x_24_7    product_lb_177  -2.4726245143034259e-02
    x_24_7    product_ub_178  -4.1654269562671840e-02
    x_24_7    onehot_24_195  1
    x_24_7    stock_lb_268  7
    x_24_7    stock_ub_269  7
    x_24_7    parent_nonstrict_scope_270  0.012
    x_24_7    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_7    product_lb_177  1
    w_24_7    product_ub_178  1
    w_24_7    normalized_mass_24_196  1
    w_24_7    normalized_ratio_24_197  -0.875
    w_24_7    full_original_Gini_328  -6.0678571428571439e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_8    OBJ       -0.048
    x_24_8    product_lb_179  -2.4726245143034259e-02
    x_24_8    product_ub_180  -4.1654269562671840e-02
    x_24_8    onehot_24_195  1
    x_24_8    stock_lb_268  8
    x_24_8    stock_ub_269  8
    x_24_8    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_8    product_lb_179  1
    w_24_8    product_ub_180  1
    w_24_8    normalized_mass_24_196  1
    w_24_8    normalized_ratio_24_197  -1
    w_24_8    full_original_Gini_328  -4.6928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_9    OBJ       -3.6000000000000004e-02
    x_24_9    product_lb_181  -2.4726245143034259e-02
    x_24_9    product_ub_182  -4.1654269562671840e-02
    x_24_9    onehot_24_195  1
    x_24_9    stock_lb_268  9
    x_24_9    stock_ub_269  9
    x_24_9    parent_nonstrict_scope_270  0.012
    x_24_9    unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_9    product_lb_181  1
    w_24_9    product_ub_182  1
    w_24_9    normalized_mass_24_196  1
    w_24_9    normalized_ratio_24_197  -1.125
    w_24_9    full_original_Gini_328  -7.0678571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_10   OBJ       -0.024
    x_24_10   product_lb_183  -2.4726245143034259e-02
    x_24_10   product_ub_184  -4.1654269562671840e-02
    x_24_10   onehot_24_195  1
    x_24_10   stock_lb_268  10
    x_24_10   stock_ub_269  10
    x_24_10   parent_nonstrict_scope_270  0.024
    x_24_10   unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_10   product_lb_183  1
    w_24_10   product_ub_184  1
    w_24_10   normalized_mass_24_196  1
    w_24_10   normalized_ratio_24_197  -1.25
    w_24_10   full_original_Gini_328  -9.7428571428571420e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_11   OBJ       -1.1999999999999997e-02
    x_24_11   product_lb_185  -2.4726245143034259e-02
    x_24_11   product_ub_186  -4.1654269562671840e-02
    x_24_11   onehot_24_195  1
    x_24_11   stock_lb_268  11
    x_24_11   stock_ub_269  11
    x_24_11   parent_nonstrict_scope_270  3.6000000000000004e-02
    MARKER    'MARKER'                 'INTEND'
    w_24_11   product_lb_185  1
    w_24_11   product_ub_186  1
    w_24_11   normalized_mass_24_196  1
    w_24_11   normalized_ratio_24_197  -1.375
    w_24_11   full_original_Gini_328  -1.3117857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_12   product_lb_187  -2.4726245143034259e-02
    x_24_12   product_ub_188  -4.1654269562671840e-02
    x_24_12   onehot_24_195  1
    x_24_12   stock_lb_268  12
    x_24_12   stock_ub_269  12
    x_24_12   parent_nonstrict_scope_270  0.048
    x_24_12   unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_12   product_lb_187  1
    w_24_12   product_ub_188  1
    w_24_12   normalized_mass_24_196  1
    w_24_12   normalized_ratio_24_197  -1.5
    w_24_12   full_original_Gini_328  -1.6492857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_13   OBJ       1.1999999999999997e-02
    x_24_13   product_lb_189  -2.4726245143034259e-02
    x_24_13   product_ub_190  -4.1654269562671840e-02
    x_24_13   onehot_24_195  1
    x_24_13   stock_lb_268  13
    x_24_13   stock_ub_269  13
    x_24_13   parent_nonstrict_scope_270  0.06
    x_24_13   unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_13   product_lb_189  1
    w_24_13   product_ub_190  1
    w_24_13   normalized_mass_24_196  1
    w_24_13   normalized_ratio_24_197  -1.625
    w_24_13   full_original_Gini_328  -1.9867857142857144e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_14   OBJ       2.4000000000000007e-02
    x_24_14   product_lb_191  -2.4726245143034259e-02
    x_24_14   product_ub_192  -4.1654269562671840e-02
    x_24_14   onehot_24_195  1
    x_24_14   stock_lb_268  14
    x_24_14   stock_ub_269  14
    x_24_14   parent_nonstrict_scope_270  7.2000000000000008e-02
    x_24_14   unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_14   product_lb_191  1
    w_24_14   product_ub_192  1
    w_24_14   normalized_mass_24_196  1
    w_24_14   normalized_ratio_24_197  -1.75
    w_24_14   full_original_Gini_328  -2.3242857142857144e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_15   OBJ       3.6000000000000004e-02
    x_24_15   product_lb_193  -2.4726245143034259e-02
    x_24_15   product_ub_194  -4.1654269562671840e-02
    x_24_15   onehot_24_195  1
    x_24_15   stock_lb_268  15
    x_24_15   stock_ub_269  15
    x_24_15   parent_nonstrict_scope_270  0.084
    x_24_15   unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_15   product_lb_193  1
    w_24_15   product_ub_194  1
    w_24_15   normalized_mass_24_196  1
    w_24_15   normalized_ratio_24_197  -1.875
    w_24_15   full_original_Gini_328  -2.6617857142857144e+01
    rho_24    normalized_ratio_24_197  1
    rho_24    block_pair_pos_273  1
    rho_24    block_pair_neg_274  -1
    rho_24    block_pair_pos_279  -1
    rho_24    block_pair_neg_280  1
    rho_24    block_pair_pos_281  -1
    rho_24    block_pair_neg_282  1
    rho_24    block_pair_pos_287  1
    rho_24    block_pair_neg_288  -1
    rho_24    block_pair_pos_299  1
    rho_24    block_pair_neg_300  -1
    rho_24    block_pair_pos_307  1
    rho_24    block_pair_neg_308  -1
    rho_24    block_pair_pos_321  1
    rho_24    block_pair_neg_322  -1
    rho_24    normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_12_0    OBJ       0.0315
    x_12_0    product_lb_198  -2.4726245143034259e-02
    x_12_0    product_ub_199  -4.1654269562671840e-02
    x_12_0    onehot_12_230  1
    x_12_0    parent_nonstrict_scope_270  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_12_0    product_lb_198  1
    w_12_0    product_ub_199  1
    w_12_0    normalized_mass_12_231  1
    w_12_0    full_original_Gini_328  -2.4007142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_1    OBJ       2.1000000000000005e-02
    x_12_1    product_lb_200  -2.4726245143034259e-02
    x_12_1    product_ub_201  -4.1654269562671840e-02
    x_12_1    onehot_12_230  1
    x_12_1    stock_lb_268  1
    x_12_1    stock_ub_269  1
    x_12_1    parent_nonstrict_scope_270  0.063
    x_12_1    unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_1    product_lb_200  1
    w_12_1    product_ub_201  1
    w_12_1    normalized_mass_12_231  1
    w_12_1    normalized_ratio_12_232  -1.4285714285714285e-01
    w_12_1    full_original_Gini_328  -2.0435714285714294e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_2    OBJ       1.0500000000000002e-02
    x_12_2    product_lb_202  -2.4726245143034259e-02
    x_12_2    product_ub_203  -4.1654269562671840e-02
    x_12_2    onehot_12_230  1
    x_12_2    stock_lb_268  2
    x_12_2    stock_ub_269  2
    x_12_2    parent_nonstrict_scope_270  0.0525
    x_12_2    unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_2    product_lb_202  1
    w_12_2    product_ub_203  1
    w_12_2    normalized_mass_12_231  1
    w_12_2    normalized_ratio_12_232  -2.8571428571428570e-01
    w_12_2    full_original_Gini_328  -1.6935714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_3    product_lb_204  -2.4726245143034259e-02
    x_12_3    product_ub_205  -4.1654269562671840e-02
    x_12_3    onehot_12_230  1
    x_12_3    stock_lb_268  3
    x_12_3    stock_ub_269  3
    x_12_3    parent_nonstrict_scope_270  4.1999999999999996e-02
    x_12_3    unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_3    product_lb_204  1
    w_12_3    product_ub_205  1
    w_12_3    normalized_mass_12_231  1
    w_12_3    normalized_ratio_12_232  -4.2857142857142855e-01
    w_12_3    full_original_Gini_328  -1.3764285714285712e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_4    OBJ       -1.0499999999999995e-02
    x_12_4    product_lb_206  -2.4726245143034259e-02
    x_12_4    product_ub_207  -4.1654269562671840e-02
    x_12_4    onehot_12_230  1
    x_12_4    stock_lb_268  4
    x_12_4    stock_ub_269  4
    x_12_4    parent_nonstrict_scope_270  0.0315
    x_12_4    unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_4    product_lb_206  1
    w_12_4    product_ub_207  1
    w_12_4    normalized_mass_12_231  1
    w_12_4    normalized_ratio_12_232  -5.7142857142857140e-01
    w_12_4    full_original_Gini_328  -1.1192857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_5    OBJ       -2.0999999999999991e-02
    x_12_5    product_lb_208  -2.4726245143034259e-02
    x_12_5    product_ub_209  -4.1654269562671840e-02
    x_12_5    onehot_12_230  1
    x_12_5    stock_lb_268  5
    x_12_5    stock_ub_269  5
    x_12_5    parent_nonstrict_scope_270  2.1000000000000005e-02
    x_12_5    unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_5    product_lb_208  1
    w_12_5    product_ub_209  1
    w_12_5    normalized_mass_12_231  1
    w_12_5    normalized_ratio_12_232  -7.1428571428571419e-01
    w_12_5    full_original_Gini_328  -8.7642857142857160e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_6    OBJ       -3.1499999999999993e-02
    x_12_6    product_lb_210  -2.4726245143034259e-02
    x_12_6    product_ub_211  -4.1654269562671840e-02
    x_12_6    onehot_12_230  1
    x_12_6    stock_lb_268  6
    x_12_6    stock_ub_269  6
    x_12_6    parent_nonstrict_scope_270  1.0500000000000002e-02
    x_12_6    unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_6    product_lb_210  1
    w_12_6    product_ub_211  1
    w_12_6    normalized_mass_12_231  1
    w_12_6    normalized_ratio_12_232  -8.5714285714285710e-01
    w_12_6    full_original_Gini_328  -6.3357142857142872e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_7    OBJ       -4.1999999999999996e-02
    x_12_7    product_lb_212  -2.4726245143034259e-02
    x_12_7    product_ub_213  -4.1654269562671840e-02
    x_12_7    onehot_12_230  1
    x_12_7    stock_lb_268  7
    x_12_7    stock_ub_269  7
    x_12_7    unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_7    product_lb_212  1
    w_12_7    product_ub_213  1
    w_12_7    normalized_mass_12_231  1
    w_12_7    normalized_ratio_12_232  -1
    w_12_7    full_original_Gini_328  -4.6928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_8    OBJ       -0.0315
    x_12_8    product_lb_214  -2.4726245143034259e-02
    x_12_8    product_ub_215  -4.1654269562671840e-02
    x_12_8    onehot_12_230  1
    x_12_8    stock_lb_268  8
    x_12_8    stock_ub_269  8
    x_12_8    parent_nonstrict_scope_270  1.0499999999999995e-02
    x_12_8    unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_8    product_lb_214  1
    w_12_8    product_ub_215  1
    w_12_8    normalized_mass_12_231  1
    w_12_8    normalized_ratio_12_232  -1.1428571428571428e+00
    w_12_8    full_original_Gini_328  -7.4071428571428548e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_9    OBJ       -2.1000000000000005e-02
    x_12_9    product_lb_216  -2.4726245143034259e-02
    x_12_9    product_ub_217  -4.1654269562671840e-02
    x_12_9    onehot_12_230  1
    x_12_9    stock_lb_268  9
    x_12_9    stock_ub_269  9
    x_12_9    parent_nonstrict_scope_270  2.0999999999999991e-02
    x_12_9    unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_9    product_lb_216  1
    w_12_9    product_ub_217  1
    w_12_9    normalized_mass_12_231  1
    w_12_9    normalized_ratio_12_232  -1.2857142857142856e+00
    w_12_9    full_original_Gini_328  -1.0707142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_10   OBJ       -1.0500000000000009e-02
    x_12_10   product_lb_218  -2.4726245143034259e-02
    x_12_10   product_ub_219  -4.1654269562671840e-02
    x_12_10   onehot_12_230  1
    x_12_10   stock_lb_268  10
    x_12_10   stock_ub_269  10
    x_12_10   parent_nonstrict_scope_270  3.1499999999999986e-02
    x_12_10   unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_10   product_lb_218  1
    w_12_10   product_ub_219  1
    w_12_10   normalized_mass_12_231  1
    w_12_10   normalized_ratio_12_232  -1.4285714285714284e+00
    w_12_10   full_original_Gini_328  -1.4564285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_11   product_lb_220  -2.4726245143034259e-02
    x_12_11   product_ub_221  -4.1654269562671840e-02
    x_12_11   onehot_12_230  1
    x_12_11   stock_lb_268  11
    x_12_11   stock_ub_269  11
    x_12_11   parent_nonstrict_scope_270  4.1999999999999996e-02
    x_12_11   unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_11   product_lb_220  1
    w_12_11   product_ub_221  1
    w_12_11   normalized_mass_12_231  1
    w_12_11   normalized_ratio_12_232  -1.5714285714285714e+00
    w_12_11   full_original_Gini_328  -1.8421428571428567e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_12   OBJ       1.0499999999999995e-02
    x_12_12   product_lb_222  -2.4726245143034259e-02
    x_12_12   product_ub_223  -4.1654269562671840e-02
    x_12_12   onehot_12_230  1
    x_12_12   stock_lb_268  12
    x_12_12   stock_ub_269  12
    x_12_12   parent_nonstrict_scope_270  5.2499999999999991e-02
    x_12_12   unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_12   product_lb_222  1
    w_12_12   product_ub_223  1
    w_12_12   normalized_mass_12_231  1
    w_12_12   normalized_ratio_12_232  -1.7142857142857142e+00
    w_12_12   full_original_Gini_328  -2.2278571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_13   OBJ       2.0999999999999991e-02
    x_12_13   product_lb_224  -2.4726245143034259e-02
    x_12_13   product_ub_225  -4.1654269562671840e-02
    x_12_13   onehot_12_230  1
    x_12_13   stock_lb_268  13
    x_12_13   stock_ub_269  13
    x_12_13   parent_nonstrict_scope_270  6.2999999999999987e-02
    x_12_13   unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_13   product_lb_224  1
    w_12_13   product_ub_225  1
    w_12_13   normalized_mass_12_231  1
    w_12_13   normalized_ratio_12_232  -1.8571428571428570e+00
    w_12_13   full_original_Gini_328  -2.6135714285714290e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_14   OBJ       0.0315
    x_12_14   product_lb_226  -2.4726245143034259e-02
    x_12_14   product_ub_227  -4.1654269562671840e-02
    x_12_14   onehot_12_230  1
    x_12_14   stock_lb_268  14
    x_12_14   stock_ub_269  14
    x_12_14   parent_nonstrict_scope_270  0.0735
    x_12_14   unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_14   product_lb_226  1
    w_12_14   product_ub_227  1
    w_12_14   normalized_mass_12_231  1
    w_12_14   normalized_ratio_12_232  -2
    w_12_14   full_original_Gini_328  -2.9992857142857144e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_15   OBJ       4.1999999999999996e-02
    x_12_15   product_lb_228  -2.4726245143034259e-02
    x_12_15   product_ub_229  -4.1654269562671840e-02
    x_12_15   onehot_12_230  1
    x_12_15   stock_lb_268  15
    x_12_15   stock_ub_269  15
    x_12_15   parent_nonstrict_scope_270  8.3999999999999991e-02
    x_12_15   unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_15   product_lb_228  1
    w_12_15   product_ub_229  1
    w_12_15   normalized_mass_12_231  1
    w_12_15   normalized_ratio_12_232  -2.1428571428571428e+00
    w_12_15   full_original_Gini_328  -3.3849999999999994e+01
    rho_12    normalized_ratio_12_232  1
    rho_12    block_pair_pos_271  1
    rho_12    block_pair_neg_272  -1
    rho_12    block_pair_pos_277  -1
    rho_12    block_pair_neg_278  1
    rho_12    block_pair_pos_279  1
    rho_12    block_pair_neg_280  -1
    rho_12    block_pair_pos_285  1
    rho_12    block_pair_neg_286  -1
    rho_12    block_pair_pos_297  1
    rho_12    block_pair_neg_298  -1
    rho_12    block_pair_pos_305  1
    rho_12    block_pair_neg_306  -1
    rho_12    block_pair_pos_319  1
    rho_12    block_pair_neg_320  -1
    rho_12    normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       0.0315
    x_27_0    product_lb_233  -2.4726245143034259e-02
    x_27_0    product_ub_234  -4.1654269562671840e-02
    x_27_0    onehot_27_265  1
    x_27_0    parent_nonstrict_scope_270  0.0735
    x_27_0    unique_nonzero_owner_428  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_233  1
    w_27_0    product_ub_234  1
    w_27_0    normalized_mass_27_266  1
    w_27_0    full_original_Gini_328  -2.4007142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       2.1000000000000005e-02
    x_27_1    product_lb_235  -2.4726245143034259e-02
    x_27_1    product_ub_236  -4.1654269562671840e-02
    x_27_1    onehot_27_265  1
    x_27_1    stock_lb_268  1
    x_27_1    stock_ub_269  1
    x_27_1    parent_nonstrict_scope_270  0.063
    x_27_1    unique_nonzero_owner_429  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_235  1
    w_27_1    product_ub_236  1
    w_27_1    normalized_mass_27_266  1
    w_27_1    normalized_ratio_27_267  -1.4285714285714285e-01
    w_27_1    full_original_Gini_328  -2.0435714285714294e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       1.0500000000000002e-02
    x_27_2    product_lb_237  -2.4726245143034259e-02
    x_27_2    product_ub_238  -4.1654269562671840e-02
    x_27_2    onehot_27_265  1
    x_27_2    stock_lb_268  2
    x_27_2    stock_ub_269  2
    x_27_2    parent_nonstrict_scope_270  0.0525
    x_27_2    unique_nonzero_owner_430  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_237  1
    w_27_2    product_ub_238  1
    w_27_2    normalized_mass_27_266  1
    w_27_2    normalized_ratio_27_267  -2.8571428571428570e-01
    w_27_2    full_original_Gini_328  -1.6935714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_3    product_lb_239  -2.4726245143034259e-02
    x_27_3    product_ub_240  -4.1654269562671840e-02
    x_27_3    onehot_27_265  1
    x_27_3    stock_lb_268  3
    x_27_3    stock_ub_269  3
    x_27_3    parent_nonstrict_scope_270  4.1999999999999996e-02
    x_27_3    unique_nonzero_owner_431  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_239  1
    w_27_3    product_ub_240  1
    w_27_3    normalized_mass_27_266  1
    w_27_3    normalized_ratio_27_267  -4.2857142857142855e-01
    w_27_3    full_original_Gini_328  -1.3764285714285712e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.0499999999999995e-02
    x_27_4    product_lb_241  -2.4726245143034259e-02
    x_27_4    product_ub_242  -4.1654269562671840e-02
    x_27_4    onehot_27_265  1
    x_27_4    stock_lb_268  4
    x_27_4    stock_ub_269  4
    x_27_4    parent_nonstrict_scope_270  0.0315
    x_27_4    unique_nonzero_owner_432  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_241  1
    w_27_4    product_ub_242  1
    w_27_4    normalized_mass_27_266  1
    w_27_4    normalized_ratio_27_267  -5.7142857142857140e-01
    w_27_4    full_original_Gini_328  -1.1192857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       -2.0999999999999991e-02
    x_27_5    product_lb_243  -2.4726245143034259e-02
    x_27_5    product_ub_244  -4.1654269562671840e-02
    x_27_5    onehot_27_265  1
    x_27_5    stock_lb_268  5
    x_27_5    stock_ub_269  5
    x_27_5    parent_nonstrict_scope_270  2.1000000000000005e-02
    x_27_5    unique_nonzero_owner_433  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_243  1
    w_27_5    product_ub_244  1
    w_27_5    normalized_mass_27_266  1
    w_27_5    normalized_ratio_27_267  -7.1428571428571419e-01
    w_27_5    full_original_Gini_328  -8.7642857142857160e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       -3.1499999999999993e-02
    x_27_6    product_lb_245  -2.4726245143034259e-02
    x_27_6    product_ub_246  -4.1654269562671840e-02
    x_27_6    onehot_27_265  1
    x_27_6    stock_lb_268  6
    x_27_6    stock_ub_269  6
    x_27_6    parent_nonstrict_scope_270  1.0500000000000002e-02
    x_27_6    unique_nonzero_owner_434  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_245  1
    w_27_6    product_ub_246  1
    w_27_6    normalized_mass_27_266  1
    w_27_6    normalized_ratio_27_267  -8.5714285714285710e-01
    w_27_6    full_original_Gini_328  -6.3357142857142872e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_7    OBJ       -4.1999999999999996e-02
    x_27_7    product_lb_247  -2.4726245143034259e-02
    x_27_7    product_ub_248  -4.1654269562671840e-02
    x_27_7    onehot_27_265  1
    x_27_7    stock_lb_268  7
    x_27_7    stock_ub_269  7
    x_27_7    unique_nonzero_owner_435  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_7    product_lb_247  1
    w_27_7    product_ub_248  1
    w_27_7    normalized_mass_27_266  1
    w_27_7    normalized_ratio_27_267  -1
    w_27_7    full_original_Gini_328  -4.6928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_8    OBJ       -0.0315
    x_27_8    product_lb_249  -2.4726245143034259e-02
    x_27_8    product_ub_250  -4.1654269562671840e-02
    x_27_8    onehot_27_265  1
    x_27_8    stock_lb_268  8
    x_27_8    stock_ub_269  8
    x_27_8    parent_nonstrict_scope_270  1.0499999999999995e-02
    x_27_8    unique_nonzero_owner_436  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_8    product_lb_249  1
    w_27_8    product_ub_250  1
    w_27_8    normalized_mass_27_266  1
    w_27_8    normalized_ratio_27_267  -1.1428571428571428e+00
    w_27_8    full_original_Gini_328  -7.4071428571428548e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_9    OBJ       -2.1000000000000005e-02
    x_27_9    product_lb_251  -2.4726245143034259e-02
    x_27_9    product_ub_252  -4.1654269562671840e-02
    x_27_9    onehot_27_265  1
    x_27_9    stock_lb_268  9
    x_27_9    stock_ub_269  9
    x_27_9    parent_nonstrict_scope_270  2.0999999999999991e-02
    x_27_9    unique_nonzero_owner_437  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_9    product_lb_251  1
    w_27_9    product_ub_252  1
    w_27_9    normalized_mass_27_266  1
    w_27_9    normalized_ratio_27_267  -1.2857142857142856e+00
    w_27_9    full_original_Gini_328  -1.0707142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_10   OBJ       -1.0500000000000009e-02
    x_27_10   product_lb_253  -2.4726245143034259e-02
    x_27_10   product_ub_254  -4.1654269562671840e-02
    x_27_10   onehot_27_265  1
    x_27_10   stock_lb_268  10
    x_27_10   stock_ub_269  10
    x_27_10   parent_nonstrict_scope_270  3.1499999999999986e-02
    x_27_10   unique_nonzero_owner_438  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_10   product_lb_253  1
    w_27_10   product_ub_254  1
    w_27_10   normalized_mass_27_266  1
    w_27_10   normalized_ratio_27_267  -1.4285714285714284e+00
    w_27_10   full_original_Gini_328  -1.4564285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_11   product_lb_255  -2.4726245143034259e-02
    x_27_11   product_ub_256  -4.1654269562671840e-02
    x_27_11   onehot_27_265  1
    x_27_11   stock_lb_268  11
    x_27_11   stock_ub_269  11
    x_27_11   parent_nonstrict_scope_270  4.1999999999999996e-02
    MARKER    'MARKER'                 'INTEND'
    w_27_11   product_lb_255  1
    w_27_11   product_ub_256  1
    w_27_11   normalized_mass_27_266  1
    w_27_11   normalized_ratio_27_267  -1.5714285714285714e+00
    w_27_11   full_original_Gini_328  -1.8421428571428567e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_12   OBJ       1.0499999999999995e-02
    x_27_12   product_lb_257  -2.4726245143034259e-02
    x_27_12   product_ub_258  -4.1654269562671840e-02
    x_27_12   onehot_27_265  1
    x_27_12   stock_lb_268  12
    x_27_12   stock_ub_269  12
    x_27_12   parent_nonstrict_scope_270  5.2499999999999991e-02
    x_27_12   unique_nonzero_owner_439  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_12   product_lb_257  1
    w_27_12   product_ub_258  1
    w_27_12   normalized_mass_27_266  1
    w_27_12   normalized_ratio_27_267  -1.7142857142857142e+00
    w_27_12   full_original_Gini_328  -2.2278571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_13   OBJ       2.0999999999999991e-02
    x_27_13   product_lb_259  -2.4726245143034259e-02
    x_27_13   product_ub_260  -4.1654269562671840e-02
    x_27_13   onehot_27_265  1
    x_27_13   stock_lb_268  13
    x_27_13   stock_ub_269  13
    x_27_13   parent_nonstrict_scope_270  6.2999999999999987e-02
    x_27_13   unique_nonzero_owner_440  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_13   product_lb_259  1
    w_27_13   product_ub_260  1
    w_27_13   normalized_mass_27_266  1
    w_27_13   normalized_ratio_27_267  -1.8571428571428570e+00
    w_27_13   full_original_Gini_328  -2.6135714285714290e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_14   OBJ       0.0315
    x_27_14   product_lb_261  -2.4726245143034259e-02
    x_27_14   product_ub_262  -4.1654269562671840e-02
    x_27_14   onehot_27_265  1
    x_27_14   stock_lb_268  14
    x_27_14   stock_ub_269  14
    x_27_14   parent_nonstrict_scope_270  0.0735
    x_27_14   unique_nonzero_owner_441  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_14   product_lb_261  1
    w_27_14   product_ub_262  1
    w_27_14   normalized_mass_27_266  1
    w_27_14   normalized_ratio_27_267  -2
    w_27_14   full_original_Gini_328  -2.9992857142857144e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_15   OBJ       4.1999999999999996e-02
    x_27_15   product_lb_263  -2.4726245143034259e-02
    x_27_15   product_ub_264  -4.1654269562671840e-02
    x_27_15   onehot_27_265  1
    x_27_15   stock_lb_268  15
    x_27_15   stock_ub_269  15
    x_27_15   parent_nonstrict_scope_270  8.3999999999999991e-02
    x_27_15   unique_nonzero_owner_442  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_15   product_lb_263  1
    w_27_15   product_ub_264  1
    w_27_15   normalized_mass_27_266  1
    w_27_15   normalized_ratio_27_267  -2.1428571428571428e+00
    w_27_15   full_original_Gini_328  -3.3849999999999994e+01
    rho_27    normalized_ratio_27_267  1
    rho_27    block_pair_pos_275  1
    rho_27    block_pair_neg_276  -1
    rho_27    block_pair_pos_277  1
    rho_27    block_pair_neg_278  -1
    rho_27    block_pair_pos_281  1
    rho_27    block_pair_neg_282  -1
    rho_27    block_pair_pos_289  1
    rho_27    block_pair_neg_290  -1
    rho_27    block_pair_pos_301  1
    rho_27    block_pair_neg_302  -1
    rho_27    block_pair_pos_311  1
    rho_27    block_pair_neg_312  -1
    rho_27    block_pair_pos_323  1
    rho_27    block_pair_neg_324  -1
    rho_27    normalization_327  1
    a_31_25   block_pair_pos_309  1
    a_31_25   block_pair_neg_310  1
    a_31_25   full_original_Gini_328  -1
    a_31_32   block_pair_pos_315  1
    a_31_32   block_pair_neg_316  1
    a_31_32   full_original_Gini_328  -1
    a_31_29   block_pair_pos_313  1
    a_31_29   block_pair_neg_314  1
    a_31_29   full_original_Gini_328  -1
    a_31_2    block_pair_pos_303  1
    a_31_2    block_pair_neg_304  1
    a_31_2    full_original_Gini_328  -1
    a_31_24   block_pair_pos_307  1
    a_31_24   block_pair_neg_308  1
    a_31_24   full_original_Gini_328  -1
    a_31_12   block_pair_pos_305  1
    a_31_12   block_pair_neg_306  1
    a_31_12   full_original_Gini_328  -1
    a_31_27   block_pair_pos_311  1
    a_31_27   block_pair_neg_312  1
    a_31_27   full_original_Gini_328  -1
    a_25_32   block_pair_pos_293  1
    a_25_32   block_pair_neg_294  1
    a_25_32   full_original_Gini_328  -1
    a_25_29   block_pair_pos_291  1
    a_25_29   block_pair_neg_292  1
    a_25_29   full_original_Gini_328  -1
    a_25_2    block_pair_pos_283  1
    a_25_2    block_pair_neg_284  1
    a_25_2    full_original_Gini_328  -1
    a_25_24   block_pair_pos_287  1
    a_25_24   block_pair_neg_288  1
    a_25_24   full_original_Gini_328  -1
    a_25_12   block_pair_pos_285  1
    a_25_12   block_pair_neg_286  1
    a_25_12   full_original_Gini_328  -1
    a_25_27   block_pair_pos_289  1
    a_25_27   block_pair_neg_290  1
    a_25_27   full_original_Gini_328  -1
    a_32_29   block_pair_pos_325  1
    a_32_29   block_pair_neg_326  1
    a_32_29   full_original_Gini_328  -1
    a_32_2    block_pair_pos_317  1
    a_32_2    block_pair_neg_318  1
    a_32_2    full_original_Gini_328  -1
    a_32_24   block_pair_pos_321  1
    a_32_24   block_pair_neg_322  1
    a_32_24   full_original_Gini_328  -1
    a_32_12   block_pair_pos_319  1
    a_32_12   block_pair_neg_320  1
    a_32_12   full_original_Gini_328  -1
    a_32_27   block_pair_pos_323  1
    a_32_27   block_pair_neg_324  1
    a_32_27   full_original_Gini_328  -1
    a_29_2    block_pair_pos_295  1
    a_29_2    block_pair_neg_296  1
    a_29_2    full_original_Gini_328  -1
    a_29_24   block_pair_pos_299  1
    a_29_24   block_pair_neg_300  1
    a_29_24   full_original_Gini_328  -1
    a_29_12   block_pair_pos_297  1
    a_29_12   block_pair_neg_298  1
    a_29_12   full_original_Gini_328  -1
    a_29_27   block_pair_pos_301  1
    a_29_27   block_pair_neg_302  1
    a_29_27   full_original_Gini_328  -1
    a_2_24    block_pair_pos_273  1
    a_2_24    block_pair_neg_274  1
    a_2_24    full_original_Gini_328  -1
    a_2_12    block_pair_pos_271  1
    a_2_12    block_pair_neg_272  1
    a_2_12    full_original_Gini_328  -1
    a_2_27    block_pair_pos_275  1
    a_2_27    block_pair_neg_276  1
    a_2_27    full_original_Gini_328  -1
    a_24_12   block_pair_pos_279  1
    a_24_12   block_pair_neg_280  1
    a_24_12   full_original_Gini_328  -1
    a_24_27   block_pair_pos_281  1
    a_24_27   block_pair_neg_282  1
    a_24_27   full_original_Gini_328  -1
    a_12_27   block_pair_pos_277  1
    a_12_27   block_pair_neg_278  1
    a_12_27   full_original_Gini_328  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_31_0  unique_nonzero_owner_329  1
    service_0_31_0  service_visit_def_823  1
    service_0_31_0  free_load_conservation_824  -2
    service_0_31_0  original_T_including_depot_unload_871  240
    service_0_31_1  unique_nonzero_owner_330  1
    service_0_31_1  service_visit_def_823  1
    service_0_31_1  free_load_conservation_824  -1
    service_0_31_1  original_T_including_depot_unload_871  120
    service_0_31_3  unique_nonzero_owner_331  1
    service_0_31_3  service_visit_def_823  1
    service_0_31_3  free_load_conservation_824  1
    service_0_31_4  unique_nonzero_owner_332  1
    service_0_31_4  service_visit_def_823  1
    service_0_31_4  free_load_conservation_824  2
    service_0_31_5  unique_nonzero_owner_333  1
    service_0_31_5  service_visit_def_823  1
    service_0_31_5  free_load_conservation_824  3
    service_0_31_6  unique_nonzero_owner_334  1
    service_0_31_6  service_visit_def_823  1
    service_0_31_6  free_load_conservation_824  4
    service_0_31_7  unique_nonzero_owner_335  1
    service_0_31_7  service_visit_def_823  1
    service_0_31_7  free_load_conservation_824  5
    service_0_31_8  unique_nonzero_owner_336  1
    service_0_31_8  service_visit_def_823  1
    service_0_31_8  free_load_conservation_824  6
    service_0_31_9  unique_nonzero_owner_337  1
    service_0_31_9  service_visit_def_823  1
    service_0_31_9  free_load_conservation_824  7
    service_0_31_10  unique_nonzero_owner_338  1
    service_0_31_10  service_visit_def_823  1
    service_0_31_10  free_load_conservation_824  8
    service_0_31_11  unique_nonzero_owner_339  1
    service_0_31_11  service_visit_def_823  1
    service_0_31_11  free_load_conservation_824  9
    service_0_31_12  unique_nonzero_owner_340  1
    service_0_31_12  service_visit_def_823  1
    service_0_31_12  free_load_conservation_824  10
    service_1_31_0  unique_nonzero_owner_329  1
    service_1_31_0  service_visit_def_1252  1
    service_1_31_0  free_load_conservation_1253  -2
    service_1_31_0  original_T_including_depot_unload_1300  240
    service_1_31_1  unique_nonzero_owner_330  1
    service_1_31_1  service_visit_def_1252  1
    service_1_31_1  free_load_conservation_1253  -1
    service_1_31_1  original_T_including_depot_unload_1300  120
    service_1_31_3  unique_nonzero_owner_331  1
    service_1_31_3  service_visit_def_1252  1
    service_1_31_3  free_load_conservation_1253  1
    service_1_31_4  unique_nonzero_owner_332  1
    service_1_31_4  service_visit_def_1252  1
    service_1_31_4  free_load_conservation_1253  2
    service_1_31_5  unique_nonzero_owner_333  1
    service_1_31_5  service_visit_def_1252  1
    service_1_31_5  free_load_conservation_1253  3
    service_1_31_6  unique_nonzero_owner_334  1
    service_1_31_6  service_visit_def_1252  1
    service_1_31_6  free_load_conservation_1253  4
    service_1_31_7  unique_nonzero_owner_335  1
    service_1_31_7  service_visit_def_1252  1
    service_1_31_7  free_load_conservation_1253  5
    service_1_31_8  unique_nonzero_owner_336  1
    service_1_31_8  service_visit_def_1252  1
    service_1_31_8  free_load_conservation_1253  6
    service_1_31_9  unique_nonzero_owner_337  1
    service_1_31_9  service_visit_def_1252  1
    service_1_31_9  free_load_conservation_1253  7
    service_1_31_10  unique_nonzero_owner_338  1
    service_1_31_10  service_visit_def_1252  1
    service_1_31_10  free_load_conservation_1253  8
    service_1_31_11  unique_nonzero_owner_339  1
    service_1_31_11  service_visit_def_1252  1
    service_1_31_11  free_load_conservation_1253  9
    service_1_31_12  unique_nonzero_owner_340  1
    service_1_31_12  service_visit_def_1252  1
    service_1_31_12  free_load_conservation_1253  10
    service_2_31_0  unique_nonzero_owner_329  1
    service_2_31_0  service_visit_def_1571  1
    service_2_31_0  free_load_conservation_1572  -2
    service_2_31_0  original_T_including_depot_unload_1617  240
    service_2_31_1  unique_nonzero_owner_330  1
    service_2_31_1  service_visit_def_1571  1
    service_2_31_1  free_load_conservation_1572  -1
    service_2_31_1  original_T_including_depot_unload_1617  120
    service_2_31_3  unique_nonzero_owner_331  1
    service_2_31_3  service_visit_def_1571  1
    service_2_31_3  free_load_conservation_1572  1
    service_2_31_4  unique_nonzero_owner_332  1
    service_2_31_4  service_visit_def_1571  1
    service_2_31_4  free_load_conservation_1572  2
    service_2_31_5  unique_nonzero_owner_333  1
    service_2_31_5  service_visit_def_1571  1
    service_2_31_5  free_load_conservation_1572  3
    service_2_31_6  unique_nonzero_owner_334  1
    service_2_31_6  service_visit_def_1571  1
    service_2_31_6  free_load_conservation_1572  4
    service_2_31_7  unique_nonzero_owner_335  1
    service_2_31_7  service_visit_def_1571  1
    service_2_31_7  free_load_conservation_1572  5
    service_2_31_8  unique_nonzero_owner_336  1
    service_2_31_8  service_visit_def_1571  1
    service_2_31_8  free_load_conservation_1572  6
    service_2_31_9  unique_nonzero_owner_337  1
    service_2_31_9  service_visit_def_1571  1
    service_2_31_9  free_load_conservation_1572  7
    service_2_31_10  unique_nonzero_owner_338  1
    service_2_31_10  service_visit_def_1571  1
    service_2_31_10  free_load_conservation_1572  8
    service_2_31_11  unique_nonzero_owner_339  1
    service_2_31_11  service_visit_def_1571  1
    service_2_31_11  free_load_conservation_1572  9
    service_2_31_12  unique_nonzero_owner_340  1
    service_2_31_12  service_visit_def_1571  1
    service_2_31_12  free_load_conservation_1572  10
    service_0_25_0  unique_nonzero_owner_341  1
    service_0_25_0  service_visit_def_829  1
    service_0_25_0  free_load_conservation_830  -1
    service_0_25_0  original_T_including_depot_unload_871  120
    service_0_25_2  unique_nonzero_owner_342  1
    service_0_25_2  service_visit_def_829  1
    service_0_25_2  free_load_conservation_830  1
    service_0_25_3  unique_nonzero_owner_343  1
    service_0_25_3  service_visit_def_829  1
    service_0_25_3  free_load_conservation_830  2
    service_0_25_4  unique_nonzero_owner_344  1
    service_0_25_4  service_visit_def_829  1
    service_0_25_4  free_load_conservation_830  3
    service_0_25_5  unique_nonzero_owner_345  1
    service_0_25_5  service_visit_def_829  1
    service_0_25_5  free_load_conservation_830  4
    service_0_25_6  unique_nonzero_owner_346  1
    service_0_25_6  service_visit_def_829  1
    service_0_25_6  free_load_conservation_830  5
    service_0_25_7  unique_nonzero_owner_347  1
    service_0_25_7  service_visit_def_829  1
    service_0_25_7  free_load_conservation_830  6
    service_0_25_8  unique_nonzero_owner_348  1
    service_0_25_8  service_visit_def_829  1
    service_0_25_8  free_load_conservation_830  7
    service_0_25_9  unique_nonzero_owner_349  1
    service_0_25_9  service_visit_def_829  1
    service_0_25_9  free_load_conservation_830  8
    service_0_25_10  unique_nonzero_owner_350  1
    service_0_25_10  service_visit_def_829  1
    service_0_25_10  free_load_conservation_830  9
    service_0_25_11  unique_nonzero_owner_351  1
    service_0_25_11  service_visit_def_829  1
    service_0_25_11  free_load_conservation_830  10
    service_0_25_12  unique_nonzero_owner_352  1
    service_0_25_12  service_visit_def_829  1
    service_0_25_12  free_load_conservation_830  11
    service_0_25_13  unique_nonzero_owner_353  1
    service_0_25_13  service_visit_def_829  1
    service_0_25_13  free_load_conservation_830  12
    service_0_25_14  unique_nonzero_owner_354  1
    service_0_25_14  service_visit_def_829  1
    service_0_25_14  free_load_conservation_830  13
    service_0_25_15  unique_nonzero_owner_355  1
    service_0_25_15  service_visit_def_829  1
    service_0_25_15  free_load_conservation_830  14
    service_1_25_0  unique_nonzero_owner_341  1
    service_1_25_0  service_visit_def_1258  1
    service_1_25_0  free_load_conservation_1259  -1
    service_1_25_0  original_T_including_depot_unload_1300  120
    service_1_25_2  unique_nonzero_owner_342  1
    service_1_25_2  service_visit_def_1258  1
    service_1_25_2  free_load_conservation_1259  1
    service_1_25_3  unique_nonzero_owner_343  1
    service_1_25_3  service_visit_def_1258  1
    service_1_25_3  free_load_conservation_1259  2
    service_1_25_4  unique_nonzero_owner_344  1
    service_1_25_4  service_visit_def_1258  1
    service_1_25_4  free_load_conservation_1259  3
    service_1_25_5  unique_nonzero_owner_345  1
    service_1_25_5  service_visit_def_1258  1
    service_1_25_5  free_load_conservation_1259  4
    service_1_25_6  unique_nonzero_owner_346  1
    service_1_25_6  service_visit_def_1258  1
    service_1_25_6  free_load_conservation_1259  5
    service_1_25_7  unique_nonzero_owner_347  1
    service_1_25_7  service_visit_def_1258  1
    service_1_25_7  free_load_conservation_1259  6
    service_1_25_8  unique_nonzero_owner_348  1
    service_1_25_8  service_visit_def_1258  1
    service_1_25_8  free_load_conservation_1259  7
    service_1_25_9  unique_nonzero_owner_349  1
    service_1_25_9  service_visit_def_1258  1
    service_1_25_9  free_load_conservation_1259  8
    service_1_25_10  unique_nonzero_owner_350  1
    service_1_25_10  service_visit_def_1258  1
    service_1_25_10  free_load_conservation_1259  9
    service_1_25_11  unique_nonzero_owner_351  1
    service_1_25_11  service_visit_def_1258  1
    service_1_25_11  free_load_conservation_1259  10
    service_1_25_12  unique_nonzero_owner_352  1
    service_1_25_12  service_visit_def_1258  1
    service_1_25_12  free_load_conservation_1259  11
    service_1_25_13  unique_nonzero_owner_353  1
    service_1_25_13  service_visit_def_1258  1
    service_1_25_13  free_load_conservation_1259  12
    service_1_25_14  unique_nonzero_owner_354  1
    service_1_25_14  service_visit_def_1258  1
    service_1_25_14  free_load_conservation_1259  13
    service_1_25_15  unique_nonzero_owner_355  1
    service_1_25_15  service_visit_def_1258  1
    service_1_25_15  free_load_conservation_1259  14
    service_2_25_0  unique_nonzero_owner_341  1
    service_2_25_0  service_visit_def_1577  1
    service_2_25_0  free_load_conservation_1578  -1
    service_2_25_0  original_T_including_depot_unload_1617  120
    service_2_25_2  unique_nonzero_owner_342  1
    service_2_25_2  service_visit_def_1577  1
    service_2_25_2  free_load_conservation_1578  1
    service_2_25_3  unique_nonzero_owner_343  1
    service_2_25_3  service_visit_def_1577  1
    service_2_25_3  free_load_conservation_1578  2
    service_2_25_4  unique_nonzero_owner_344  1
    service_2_25_4  service_visit_def_1577  1
    service_2_25_4  free_load_conservation_1578  3
    service_2_25_5  unique_nonzero_owner_345  1
    service_2_25_5  service_visit_def_1577  1
    service_2_25_5  free_load_conservation_1578  4
    service_2_25_6  unique_nonzero_owner_346  1
    service_2_25_6  service_visit_def_1577  1
    service_2_25_6  free_load_conservation_1578  5
    service_2_25_7  unique_nonzero_owner_347  1
    service_2_25_7  service_visit_def_1577  1
    service_2_25_7  free_load_conservation_1578  6
    service_2_25_8  unique_nonzero_owner_348  1
    service_2_25_8  service_visit_def_1577  1
    service_2_25_8  free_load_conservation_1578  7
    service_2_25_9  unique_nonzero_owner_349  1
    service_2_25_9  service_visit_def_1577  1
    service_2_25_9  free_load_conservation_1578  8
    service_2_25_10  unique_nonzero_owner_350  1
    service_2_25_10  service_visit_def_1577  1
    service_2_25_10  free_load_conservation_1578  9
    service_2_25_11  unique_nonzero_owner_351  1
    service_2_25_11  service_visit_def_1577  1
    service_2_25_11  free_load_conservation_1578  10
    service_2_25_12  unique_nonzero_owner_352  1
    service_2_25_12  service_visit_def_1577  1
    service_2_25_12  free_load_conservation_1578  11
    service_2_25_13  unique_nonzero_owner_353  1
    service_2_25_13  service_visit_def_1577  1
    service_2_25_13  free_load_conservation_1578  12
    service_2_25_14  unique_nonzero_owner_354  1
    service_2_25_14  service_visit_def_1577  1
    service_2_25_14  free_load_conservation_1578  13
    service_2_25_15  unique_nonzero_owner_355  1
    service_2_25_15  service_visit_def_1577  1
    service_2_25_15  free_load_conservation_1578  14
    service_0_32_1  unique_nonzero_owner_356  1
    service_0_32_1  service_visit_def_835  1
    service_0_32_1  free_load_conservation_836  1
    service_0_32_2  unique_nonzero_owner_357  1
    service_0_32_2  service_visit_def_835  1
    service_0_32_2  free_load_conservation_836  2
    service_0_32_3  unique_nonzero_owner_358  1
    service_0_32_3  service_visit_def_835  1
    service_0_32_3  free_load_conservation_836  3
    service_0_32_4  unique_nonzero_owner_359  1
    service_0_32_4  service_visit_def_835  1
    service_0_32_4  free_load_conservation_836  4
    service_0_32_5  unique_nonzero_owner_360  1
    service_0_32_5  service_visit_def_835  1
    service_0_32_5  free_load_conservation_836  5
    service_0_32_6  unique_nonzero_owner_361  1
    service_0_32_6  service_visit_def_835  1
    service_0_32_6  free_load_conservation_836  6
    service_0_32_7  unique_nonzero_owner_362  1
    service_0_32_7  service_visit_def_835  1
    service_0_32_7  free_load_conservation_836  7
    service_0_32_8  unique_nonzero_owner_363  1
    service_0_32_8  service_visit_def_835  1
    service_0_32_8  free_load_conservation_836  8
    service_0_32_9  unique_nonzero_owner_364  1
    service_0_32_9  service_visit_def_835  1
    service_0_32_9  free_load_conservation_836  9
    service_0_32_10  unique_nonzero_owner_365  1
    service_0_32_10  service_visit_def_835  1
    service_0_32_10  free_load_conservation_836  10
    service_0_32_11  unique_nonzero_owner_366  1
    service_0_32_11  service_visit_def_835  1
    service_0_32_11  free_load_conservation_836  11
    service_0_32_12  unique_nonzero_owner_367  1
    service_0_32_12  service_visit_def_835  1
    service_0_32_12  free_load_conservation_836  12
    service_1_32_1  unique_nonzero_owner_356  1
    service_1_32_1  service_visit_def_1264  1
    service_1_32_1  free_load_conservation_1265  1
    service_1_32_2  unique_nonzero_owner_357  1
    service_1_32_2  service_visit_def_1264  1
    service_1_32_2  free_load_conservation_1265  2
    service_1_32_3  unique_nonzero_owner_358  1
    service_1_32_3  service_visit_def_1264  1
    service_1_32_3  free_load_conservation_1265  3
    service_1_32_4  unique_nonzero_owner_359  1
    service_1_32_4  service_visit_def_1264  1
    service_1_32_4  free_load_conservation_1265  4
    service_1_32_5  unique_nonzero_owner_360  1
    service_1_32_5  service_visit_def_1264  1
    service_1_32_5  free_load_conservation_1265  5
    service_1_32_6  unique_nonzero_owner_361  1
    service_1_32_6  service_visit_def_1264  1
    service_1_32_6  free_load_conservation_1265  6
    service_1_32_7  unique_nonzero_owner_362  1
    service_1_32_7  service_visit_def_1264  1
    service_1_32_7  free_load_conservation_1265  7
    service_1_32_8  unique_nonzero_owner_363  1
    service_1_32_8  service_visit_def_1264  1
    service_1_32_8  free_load_conservation_1265  8
    service_1_32_9  unique_nonzero_owner_364  1
    service_1_32_9  service_visit_def_1264  1
    service_1_32_9  free_load_conservation_1265  9
    service_1_32_10  unique_nonzero_owner_365  1
    service_1_32_10  service_visit_def_1264  1
    service_1_32_10  free_load_conservation_1265  10
    service_1_32_11  unique_nonzero_owner_366  1
    service_1_32_11  service_visit_def_1264  1
    service_1_32_11  free_load_conservation_1265  11
    service_1_32_12  unique_nonzero_owner_367  1
    service_1_32_12  service_visit_def_1264  1
    service_1_32_12  free_load_conservation_1265  12
    service_2_32_1  unique_nonzero_owner_356  1
    service_2_32_1  service_visit_def_1583  1
    service_2_32_1  free_load_conservation_1584  1
    service_2_32_2  unique_nonzero_owner_357  1
    service_2_32_2  service_visit_def_1583  1
    service_2_32_2  free_load_conservation_1584  2
    service_2_32_3  unique_nonzero_owner_358  1
    service_2_32_3  service_visit_def_1583  1
    service_2_32_3  free_load_conservation_1584  3
    service_2_32_4  unique_nonzero_owner_359  1
    service_2_32_4  service_visit_def_1583  1
    service_2_32_4  free_load_conservation_1584  4
    service_2_32_5  unique_nonzero_owner_360  1
    service_2_32_5  service_visit_def_1583  1
    service_2_32_5  free_load_conservation_1584  5
    service_2_32_6  unique_nonzero_owner_361  1
    service_2_32_6  service_visit_def_1583  1
    service_2_32_6  free_load_conservation_1584  6
    service_2_32_7  unique_nonzero_owner_362  1
    service_2_32_7  service_visit_def_1583  1
    service_2_32_7  free_load_conservation_1584  7
    service_2_32_8  unique_nonzero_owner_363  1
    service_2_32_8  service_visit_def_1583  1
    service_2_32_8  free_load_conservation_1584  8
    service_2_32_9  unique_nonzero_owner_364  1
    service_2_32_9  service_visit_def_1583  1
    service_2_32_9  free_load_conservation_1584  9
    service_2_32_10  unique_nonzero_owner_365  1
    service_2_32_10  service_visit_def_1583  1
    service_2_32_10  free_load_conservation_1584  10
    service_2_32_11  unique_nonzero_owner_366  1
    service_2_32_11  service_visit_def_1583  1
    service_2_32_11  free_load_conservation_1584  11
    service_2_32_12  unique_nonzero_owner_367  1
    service_2_32_12  service_visit_def_1583  1
    service_2_32_12  free_load_conservation_1584  12
    service_0_29_0  unique_nonzero_owner_368  1
    service_0_29_0  service_visit_def_841  1
    service_0_29_0  free_load_conservation_842  -11
    service_0_29_0  original_T_including_depot_unload_871  1320
    service_0_29_1  unique_nonzero_owner_369  1
    service_0_29_1  service_visit_def_841  1
    service_0_29_1  free_load_conservation_842  -10
    service_0_29_1  original_T_including_depot_unload_871  1200
    service_0_29_2  unique_nonzero_owner_370  1
    service_0_29_2  service_visit_def_841  1
    service_0_29_2  free_load_conservation_842  -9
    service_0_29_2  original_T_including_depot_unload_871  1080
    service_0_29_3  unique_nonzero_owner_371  1
    service_0_29_3  service_visit_def_841  1
    service_0_29_3  free_load_conservation_842  -8
    service_0_29_3  original_T_including_depot_unload_871  960
    service_0_29_4  unique_nonzero_owner_372  1
    service_0_29_4  service_visit_def_841  1
    service_0_29_4  free_load_conservation_842  -7
    service_0_29_4  original_T_including_depot_unload_871  840
    service_0_29_5  unique_nonzero_owner_373  1
    service_0_29_5  service_visit_def_841  1
    service_0_29_5  free_load_conservation_842  -6
    service_0_29_5  original_T_including_depot_unload_871  720
    service_0_29_6  unique_nonzero_owner_374  1
    service_0_29_6  service_visit_def_841  1
    service_0_29_6  free_load_conservation_842  -5
    service_0_29_6  original_T_including_depot_unload_871  600
    service_0_29_7  unique_nonzero_owner_375  1
    service_0_29_7  service_visit_def_841  1
    service_0_29_7  free_load_conservation_842  -4
    service_0_29_7  original_T_including_depot_unload_871  480
    service_0_29_8  unique_nonzero_owner_376  1
    service_0_29_8  service_visit_def_841  1
    service_0_29_8  free_load_conservation_842  -3
    service_0_29_8  original_T_including_depot_unload_871  360
    service_0_29_9  unique_nonzero_owner_377  1
    service_0_29_9  service_visit_def_841  1
    service_0_29_9  free_load_conservation_842  -2
    service_0_29_9  original_T_including_depot_unload_871  240
    service_0_29_10  unique_nonzero_owner_378  1
    service_0_29_10  service_visit_def_841  1
    service_0_29_10  free_load_conservation_842  -1
    service_0_29_10  original_T_including_depot_unload_871  120
    service_0_29_12  unique_nonzero_owner_379  1
    service_0_29_12  service_visit_def_841  1
    service_0_29_12  free_load_conservation_842  1
    service_0_29_13  unique_nonzero_owner_380  1
    service_0_29_13  service_visit_def_841  1
    service_0_29_13  free_load_conservation_842  2
    service_0_29_14  unique_nonzero_owner_381  1
    service_0_29_14  service_visit_def_841  1
    service_0_29_14  free_load_conservation_842  3
    service_0_29_15  unique_nonzero_owner_382  1
    service_0_29_15  service_visit_def_841  1
    service_0_29_15  free_load_conservation_842  4
    service_1_29_0  unique_nonzero_owner_368  1
    service_1_29_0  service_visit_def_1270  1
    service_1_29_0  free_load_conservation_1271  -11
    service_1_29_0  original_T_including_depot_unload_1300  1320
    service_1_29_1  unique_nonzero_owner_369  1
    service_1_29_1  service_visit_def_1270  1
    service_1_29_1  free_load_conservation_1271  -10
    service_1_29_1  original_T_including_depot_unload_1300  1200
    service_1_29_2  unique_nonzero_owner_370  1
    service_1_29_2  service_visit_def_1270  1
    service_1_29_2  free_load_conservation_1271  -9
    service_1_29_2  original_T_including_depot_unload_1300  1080
    service_1_29_3  unique_nonzero_owner_371  1
    service_1_29_3  service_visit_def_1270  1
    service_1_29_3  free_load_conservation_1271  -8
    service_1_29_3  original_T_including_depot_unload_1300  960
    service_1_29_4  unique_nonzero_owner_372  1
    service_1_29_4  service_visit_def_1270  1
    service_1_29_4  free_load_conservation_1271  -7
    service_1_29_4  original_T_including_depot_unload_1300  840
    service_1_29_5  unique_nonzero_owner_373  1
    service_1_29_5  service_visit_def_1270  1
    service_1_29_5  free_load_conservation_1271  -6
    service_1_29_5  original_T_including_depot_unload_1300  720
    service_1_29_6  unique_nonzero_owner_374  1
    service_1_29_6  service_visit_def_1270  1
    service_1_29_6  free_load_conservation_1271  -5
    service_1_29_6  original_T_including_depot_unload_1300  600
    service_1_29_7  unique_nonzero_owner_375  1
    service_1_29_7  service_visit_def_1270  1
    service_1_29_7  free_load_conservation_1271  -4
    service_1_29_7  original_T_including_depot_unload_1300  480
    service_1_29_8  unique_nonzero_owner_376  1
    service_1_29_8  service_visit_def_1270  1
    service_1_29_8  free_load_conservation_1271  -3
    service_1_29_8  original_T_including_depot_unload_1300  360
    service_1_29_9  unique_nonzero_owner_377  1
    service_1_29_9  service_visit_def_1270  1
    service_1_29_9  free_load_conservation_1271  -2
    service_1_29_9  original_T_including_depot_unload_1300  240
    service_1_29_10  unique_nonzero_owner_378  1
    service_1_29_10  service_visit_def_1270  1
    service_1_29_10  free_load_conservation_1271  -1
    service_1_29_10  original_T_including_depot_unload_1300  120
    service_1_29_12  unique_nonzero_owner_379  1
    service_1_29_12  service_visit_def_1270  1
    service_1_29_12  free_load_conservation_1271  1
    service_1_29_13  unique_nonzero_owner_380  1
    service_1_29_13  service_visit_def_1270  1
    service_1_29_13  free_load_conservation_1271  2
    service_1_29_14  unique_nonzero_owner_381  1
    service_1_29_14  service_visit_def_1270  1
    service_1_29_14  free_load_conservation_1271  3
    service_1_29_15  unique_nonzero_owner_382  1
    service_1_29_15  service_visit_def_1270  1
    service_1_29_15  free_load_conservation_1271  4
    service_2_29_0  unique_nonzero_owner_368  1
    service_2_29_0  service_visit_def_1589  1
    service_2_29_0  free_load_conservation_1590  -11
    service_2_29_0  original_T_including_depot_unload_1617  1320
    service_2_29_1  unique_nonzero_owner_369  1
    service_2_29_1  service_visit_def_1589  1
    service_2_29_1  free_load_conservation_1590  -10
    service_2_29_1  original_T_including_depot_unload_1617  1200
    service_2_29_2  unique_nonzero_owner_370  1
    service_2_29_2  service_visit_def_1589  1
    service_2_29_2  free_load_conservation_1590  -9
    service_2_29_2  original_T_including_depot_unload_1617  1080
    service_2_29_3  unique_nonzero_owner_371  1
    service_2_29_3  service_visit_def_1589  1
    service_2_29_3  free_load_conservation_1590  -8
    service_2_29_3  original_T_including_depot_unload_1617  960
    service_2_29_4  unique_nonzero_owner_372  1
    service_2_29_4  service_visit_def_1589  1
    service_2_29_4  free_load_conservation_1590  -7
    service_2_29_4  original_T_including_depot_unload_1617  840
    service_2_29_5  unique_nonzero_owner_373  1
    service_2_29_5  service_visit_def_1589  1
    service_2_29_5  free_load_conservation_1590  -6
    service_2_29_5  original_T_including_depot_unload_1617  720
    service_2_29_6  unique_nonzero_owner_374  1
    service_2_29_6  service_visit_def_1589  1
    service_2_29_6  free_load_conservation_1590  -5
    service_2_29_6  original_T_including_depot_unload_1617  600
    service_2_29_7  unique_nonzero_owner_375  1
    service_2_29_7  service_visit_def_1589  1
    service_2_29_7  free_load_conservation_1590  -4
    service_2_29_7  original_T_including_depot_unload_1617  480
    service_2_29_8  unique_nonzero_owner_376  1
    service_2_29_8  service_visit_def_1589  1
    service_2_29_8  free_load_conservation_1590  -3
    service_2_29_8  original_T_including_depot_unload_1617  360
    service_2_29_9  unique_nonzero_owner_377  1
    service_2_29_9  service_visit_def_1589  1
    service_2_29_9  free_load_conservation_1590  -2
    service_2_29_9  original_T_including_depot_unload_1617  240
    service_2_29_10  unique_nonzero_owner_378  1
    service_2_29_10  service_visit_def_1589  1
    service_2_29_10  free_load_conservation_1590  -1
    service_2_29_10  original_T_including_depot_unload_1617  120
    service_2_29_12  unique_nonzero_owner_379  1
    service_2_29_12  service_visit_def_1589  1
    service_2_29_12  free_load_conservation_1590  1
    service_2_29_13  unique_nonzero_owner_380  1
    service_2_29_13  service_visit_def_1589  1
    service_2_29_13  free_load_conservation_1590  2
    service_2_29_14  unique_nonzero_owner_381  1
    service_2_29_14  service_visit_def_1589  1
    service_2_29_14  free_load_conservation_1590  3
    service_2_29_15  unique_nonzero_owner_382  1
    service_2_29_15  service_visit_def_1589  1
    service_2_29_15  free_load_conservation_1590  4
    service_0_2_1  unique_nonzero_owner_383  1
    service_0_2_1  service_visit_def_847  1
    service_0_2_1  free_load_conservation_848  1
    service_0_2_2  unique_nonzero_owner_384  1
    service_0_2_2  service_visit_def_847  1
    service_0_2_2  free_load_conservation_848  2
    service_0_2_3  unique_nonzero_owner_385  1
    service_0_2_3  service_visit_def_847  1
    service_0_2_3  free_load_conservation_848  3
    service_0_2_4  unique_nonzero_owner_386  1
    service_0_2_4  service_visit_def_847  1
    service_0_2_4  free_load_conservation_848  4
    service_0_2_5  unique_nonzero_owner_387  1
    service_0_2_5  service_visit_def_847  1
    service_0_2_5  free_load_conservation_848  5
    service_0_2_6  unique_nonzero_owner_388  1
    service_0_2_6  service_visit_def_847  1
    service_0_2_6  free_load_conservation_848  6
    service_0_2_7  unique_nonzero_owner_389  1
    service_0_2_7  service_visit_def_847  1
    service_0_2_7  free_load_conservation_848  7
    service_0_2_8  unique_nonzero_owner_390  1
    service_0_2_8  service_visit_def_847  1
    service_0_2_8  free_load_conservation_848  8
    service_0_2_9  unique_nonzero_owner_391  1
    service_0_2_9  service_visit_def_847  1
    service_0_2_9  free_load_conservation_848  9
    service_0_2_10  unique_nonzero_owner_392  1
    service_0_2_10  service_visit_def_847  1
    service_0_2_10  free_load_conservation_848  10
    service_0_2_11  unique_nonzero_owner_393  1
    service_0_2_11  service_visit_def_847  1
    service_0_2_11  free_load_conservation_848  11
    service_0_2_12  unique_nonzero_owner_394  1
    service_0_2_12  service_visit_def_847  1
    service_0_2_12  free_load_conservation_848  12
    service_0_2_13  unique_nonzero_owner_395  1
    service_0_2_13  service_visit_def_847  1
    service_0_2_13  free_load_conservation_848  13
    service_0_2_14  unique_nonzero_owner_396  1
    service_0_2_14  service_visit_def_847  1
    service_0_2_14  free_load_conservation_848  14
    service_0_2_15  unique_nonzero_owner_397  1
    service_0_2_15  service_visit_def_847  1
    service_0_2_15  free_load_conservation_848  15
    service_1_2_1  unique_nonzero_owner_383  1
    service_1_2_1  service_visit_def_1276  1
    service_1_2_1  free_load_conservation_1277  1
    service_1_2_2  unique_nonzero_owner_384  1
    service_1_2_2  service_visit_def_1276  1
    service_1_2_2  free_load_conservation_1277  2
    service_1_2_3  unique_nonzero_owner_385  1
    service_1_2_3  service_visit_def_1276  1
    service_1_2_3  free_load_conservation_1277  3
    service_1_2_4  unique_nonzero_owner_386  1
    service_1_2_4  service_visit_def_1276  1
    service_1_2_4  free_load_conservation_1277  4
    service_1_2_5  unique_nonzero_owner_387  1
    service_1_2_5  service_visit_def_1276  1
    service_1_2_5  free_load_conservation_1277  5
    service_1_2_6  unique_nonzero_owner_388  1
    service_1_2_6  service_visit_def_1276  1
    service_1_2_6  free_load_conservation_1277  6
    service_1_2_7  unique_nonzero_owner_389  1
    service_1_2_7  service_visit_def_1276  1
    service_1_2_7  free_load_conservation_1277  7
    service_1_2_8  unique_nonzero_owner_390  1
    service_1_2_8  service_visit_def_1276  1
    service_1_2_8  free_load_conservation_1277  8
    service_1_2_9  unique_nonzero_owner_391  1
    service_1_2_9  service_visit_def_1276  1
    service_1_2_9  free_load_conservation_1277  9
    service_1_2_10  unique_nonzero_owner_392  1
    service_1_2_10  service_visit_def_1276  1
    service_1_2_10  free_load_conservation_1277  10
    service_1_2_11  unique_nonzero_owner_393  1
    service_1_2_11  service_visit_def_1276  1
    service_1_2_11  free_load_conservation_1277  11
    service_1_2_12  unique_nonzero_owner_394  1
    service_1_2_12  service_visit_def_1276  1
    service_1_2_12  free_load_conservation_1277  12
    service_1_2_13  unique_nonzero_owner_395  1
    service_1_2_13  service_visit_def_1276  1
    service_1_2_13  free_load_conservation_1277  13
    service_1_2_14  unique_nonzero_owner_396  1
    service_1_2_14  service_visit_def_1276  1
    service_1_2_14  free_load_conservation_1277  14
    service_1_2_15  unique_nonzero_owner_397  1
    service_1_2_15  service_visit_def_1276  1
    service_1_2_15  free_load_conservation_1277  15
    service_2_2_1  unique_nonzero_owner_383  1
    service_2_2_1  service_visit_def_1595  1
    service_2_2_1  free_load_conservation_1596  1
    service_2_2_2  unique_nonzero_owner_384  1
    service_2_2_2  service_visit_def_1595  1
    service_2_2_2  free_load_conservation_1596  2
    service_2_2_3  unique_nonzero_owner_385  1
    service_2_2_3  service_visit_def_1595  1
    service_2_2_3  free_load_conservation_1596  3
    service_2_2_4  unique_nonzero_owner_386  1
    service_2_2_4  service_visit_def_1595  1
    service_2_2_4  free_load_conservation_1596  4
    service_2_2_5  unique_nonzero_owner_387  1
    service_2_2_5  service_visit_def_1595  1
    service_2_2_5  free_load_conservation_1596  5
    service_2_2_6  unique_nonzero_owner_388  1
    service_2_2_6  service_visit_def_1595  1
    service_2_2_6  free_load_conservation_1596  6
    service_2_2_7  unique_nonzero_owner_389  1
    service_2_2_7  service_visit_def_1595  1
    service_2_2_7  free_load_conservation_1596  7
    service_2_2_8  unique_nonzero_owner_390  1
    service_2_2_8  service_visit_def_1595  1
    service_2_2_8  free_load_conservation_1596  8
    service_2_2_9  unique_nonzero_owner_391  1
    service_2_2_9  service_visit_def_1595  1
    service_2_2_9  free_load_conservation_1596  9
    service_2_2_10  unique_nonzero_owner_392  1
    service_2_2_10  service_visit_def_1595  1
    service_2_2_10  free_load_conservation_1596  10
    service_2_2_11  unique_nonzero_owner_393  1
    service_2_2_11  service_visit_def_1595  1
    service_2_2_11  free_load_conservation_1596  11
    service_2_2_12  unique_nonzero_owner_394  1
    service_2_2_12  service_visit_def_1595  1
    service_2_2_12  free_load_conservation_1596  12
    service_2_2_13  unique_nonzero_owner_395  1
    service_2_2_13  service_visit_def_1595  1
    service_2_2_13  free_load_conservation_1596  13
    service_2_2_14  unique_nonzero_owner_396  1
    service_2_2_14  service_visit_def_1595  1
    service_2_2_14  free_load_conservation_1596  14
    service_2_2_15  unique_nonzero_owner_397  1
    service_2_2_15  service_visit_def_1595  1
    service_2_2_15  free_load_conservation_1596  15
    service_0_24_0  unique_nonzero_owner_398  1
    service_0_24_0  service_visit_def_853  1
    service_0_24_0  free_load_conservation_854  -11
    service_0_24_0  original_T_including_depot_unload_871  1320
    service_0_24_1  unique_nonzero_owner_399  1
    service_0_24_1  service_visit_def_853  1
    service_0_24_1  free_load_conservation_854  -10
    service_0_24_1  original_T_including_depot_unload_871  1200
    service_0_24_2  unique_nonzero_owner_400  1
    service_0_24_2  service_visit_def_853  1
    service_0_24_2  free_load_conservation_854  -9
    service_0_24_2  original_T_including_depot_unload_871  1080
    service_0_24_3  unique_nonzero_owner_401  1
    service_0_24_3  service_visit_def_853  1
    service_0_24_3  free_load_conservation_854  -8
    service_0_24_3  original_T_including_depot_unload_871  960
    service_0_24_4  unique_nonzero_owner_402  1
    service_0_24_4  service_visit_def_853  1
    service_0_24_4  free_load_conservation_854  -7
    service_0_24_4  original_T_including_depot_unload_871  840
    service_0_24_5  unique_nonzero_owner_403  1
    service_0_24_5  service_visit_def_853  1
    service_0_24_5  free_load_conservation_854  -6
    service_0_24_5  original_T_including_depot_unload_871  720
    service_0_24_6  unique_nonzero_owner_404  1
    service_0_24_6  service_visit_def_853  1
    service_0_24_6  free_load_conservation_854  -5
    service_0_24_6  original_T_including_depot_unload_871  600
    service_0_24_7  unique_nonzero_owner_405  1
    service_0_24_7  service_visit_def_853  1
    service_0_24_7  free_load_conservation_854  -4
    service_0_24_7  original_T_including_depot_unload_871  480
    service_0_24_8  unique_nonzero_owner_406  1
    service_0_24_8  service_visit_def_853  1
    service_0_24_8  free_load_conservation_854  -3
    service_0_24_8  original_T_including_depot_unload_871  360
    service_0_24_9  unique_nonzero_owner_407  1
    service_0_24_9  service_visit_def_853  1
    service_0_24_9  free_load_conservation_854  -2
    service_0_24_9  original_T_including_depot_unload_871  240
    service_0_24_10  unique_nonzero_owner_408  1
    service_0_24_10  service_visit_def_853  1
    service_0_24_10  free_load_conservation_854  -1
    service_0_24_10  original_T_including_depot_unload_871  120
    service_0_24_12  unique_nonzero_owner_409  1
    service_0_24_12  service_visit_def_853  1
    service_0_24_12  free_load_conservation_854  1
    service_0_24_13  unique_nonzero_owner_410  1
    service_0_24_13  service_visit_def_853  1
    service_0_24_13  free_load_conservation_854  2
    service_0_24_14  unique_nonzero_owner_411  1
    service_0_24_14  service_visit_def_853  1
    service_0_24_14  free_load_conservation_854  3
    service_0_24_15  unique_nonzero_owner_412  1
    service_0_24_15  service_visit_def_853  1
    service_0_24_15  free_load_conservation_854  4
    service_1_24_0  unique_nonzero_owner_398  1
    service_1_24_0  service_visit_def_1282  1
    service_1_24_0  free_load_conservation_1283  -11
    service_1_24_0  original_T_including_depot_unload_1300  1320
    service_1_24_1  unique_nonzero_owner_399  1
    service_1_24_1  service_visit_def_1282  1
    service_1_24_1  free_load_conservation_1283  -10
    service_1_24_1  original_T_including_depot_unload_1300  1200
    service_1_24_2  unique_nonzero_owner_400  1
    service_1_24_2  service_visit_def_1282  1
    service_1_24_2  free_load_conservation_1283  -9
    service_1_24_2  original_T_including_depot_unload_1300  1080
    service_1_24_3  unique_nonzero_owner_401  1
    service_1_24_3  service_visit_def_1282  1
    service_1_24_3  free_load_conservation_1283  -8
    service_1_24_3  original_T_including_depot_unload_1300  960
    service_1_24_4  unique_nonzero_owner_402  1
    service_1_24_4  service_visit_def_1282  1
    service_1_24_4  free_load_conservation_1283  -7
    service_1_24_4  original_T_including_depot_unload_1300  840
    service_1_24_5  unique_nonzero_owner_403  1
    service_1_24_5  service_visit_def_1282  1
    service_1_24_5  free_load_conservation_1283  -6
    service_1_24_5  original_T_including_depot_unload_1300  720
    service_1_24_6  unique_nonzero_owner_404  1
    service_1_24_6  service_visit_def_1282  1
    service_1_24_6  free_load_conservation_1283  -5
    service_1_24_6  original_T_including_depot_unload_1300  600
    service_1_24_7  unique_nonzero_owner_405  1
    service_1_24_7  service_visit_def_1282  1
    service_1_24_7  free_load_conservation_1283  -4
    service_1_24_7  original_T_including_depot_unload_1300  480
    service_1_24_8  unique_nonzero_owner_406  1
    service_1_24_8  service_visit_def_1282  1
    service_1_24_8  free_load_conservation_1283  -3
    service_1_24_8  original_T_including_depot_unload_1300  360
    service_1_24_9  unique_nonzero_owner_407  1
    service_1_24_9  service_visit_def_1282  1
    service_1_24_9  free_load_conservation_1283  -2
    service_1_24_9  original_T_including_depot_unload_1300  240
    service_1_24_10  unique_nonzero_owner_408  1
    service_1_24_10  service_visit_def_1282  1
    service_1_24_10  free_load_conservation_1283  -1
    service_1_24_10  original_T_including_depot_unload_1300  120
    service_1_24_12  unique_nonzero_owner_409  1
    service_1_24_12  service_visit_def_1282  1
    service_1_24_12  free_load_conservation_1283  1
    service_1_24_13  unique_nonzero_owner_410  1
    service_1_24_13  service_visit_def_1282  1
    service_1_24_13  free_load_conservation_1283  2
    service_1_24_14  unique_nonzero_owner_411  1
    service_1_24_14  service_visit_def_1282  1
    service_1_24_14  free_load_conservation_1283  3
    service_1_24_15  unique_nonzero_owner_412  1
    service_1_24_15  service_visit_def_1282  1
    service_1_24_15  free_load_conservation_1283  4
    service_2_24_0  unique_nonzero_owner_398  1
    service_2_24_0  service_visit_def_1601  1
    service_2_24_0  free_load_conservation_1602  -11
    service_2_24_0  original_T_including_depot_unload_1617  1320
    service_2_24_1  unique_nonzero_owner_399  1
    service_2_24_1  service_visit_def_1601  1
    service_2_24_1  free_load_conservation_1602  -10
    service_2_24_1  original_T_including_depot_unload_1617  1200
    service_2_24_2  unique_nonzero_owner_400  1
    service_2_24_2  service_visit_def_1601  1
    service_2_24_2  free_load_conservation_1602  -9
    service_2_24_2  original_T_including_depot_unload_1617  1080
    service_2_24_3  unique_nonzero_owner_401  1
    service_2_24_3  service_visit_def_1601  1
    service_2_24_3  free_load_conservation_1602  -8
    service_2_24_3  original_T_including_depot_unload_1617  960
    service_2_24_4  unique_nonzero_owner_402  1
    service_2_24_4  service_visit_def_1601  1
    service_2_24_4  free_load_conservation_1602  -7
    service_2_24_4  original_T_including_depot_unload_1617  840
    service_2_24_5  unique_nonzero_owner_403  1
    service_2_24_5  service_visit_def_1601  1
    service_2_24_5  free_load_conservation_1602  -6
    service_2_24_5  original_T_including_depot_unload_1617  720
    service_2_24_6  unique_nonzero_owner_404  1
    service_2_24_6  service_visit_def_1601  1
    service_2_24_6  free_load_conservation_1602  -5
    service_2_24_6  original_T_including_depot_unload_1617  600
    service_2_24_7  unique_nonzero_owner_405  1
    service_2_24_7  service_visit_def_1601  1
    service_2_24_7  free_load_conservation_1602  -4
    service_2_24_7  original_T_including_depot_unload_1617  480
    service_2_24_8  unique_nonzero_owner_406  1
    service_2_24_8  service_visit_def_1601  1
    service_2_24_8  free_load_conservation_1602  -3
    service_2_24_8  original_T_including_depot_unload_1617  360
    service_2_24_9  unique_nonzero_owner_407  1
    service_2_24_9  service_visit_def_1601  1
    service_2_24_9  free_load_conservation_1602  -2
    service_2_24_9  original_T_including_depot_unload_1617  240
    service_2_24_10  unique_nonzero_owner_408  1
    service_2_24_10  service_visit_def_1601  1
    service_2_24_10  free_load_conservation_1602  -1
    service_2_24_10  original_T_including_depot_unload_1617  120
    service_2_24_12  unique_nonzero_owner_409  1
    service_2_24_12  service_visit_def_1601  1
    service_2_24_12  free_load_conservation_1602  1
    service_2_24_13  unique_nonzero_owner_410  1
    service_2_24_13  service_visit_def_1601  1
    service_2_24_13  free_load_conservation_1602  2
    service_2_24_14  unique_nonzero_owner_411  1
    service_2_24_14  service_visit_def_1601  1
    service_2_24_14  free_load_conservation_1602  3
    service_2_24_15  unique_nonzero_owner_412  1
    service_2_24_15  service_visit_def_1601  1
    service_2_24_15  free_load_conservation_1602  4
    service_0_12_1  unique_nonzero_owner_413  1
    service_0_12_1  service_visit_def_859  1
    service_0_12_1  free_load_conservation_860  1
    service_0_12_2  unique_nonzero_owner_414  1
    service_0_12_2  service_visit_def_859  1
    service_0_12_2  free_load_conservation_860  2
    service_0_12_3  unique_nonzero_owner_415  1
    service_0_12_3  service_visit_def_859  1
    service_0_12_3  free_load_conservation_860  3
    service_0_12_4  unique_nonzero_owner_416  1
    service_0_12_4  service_visit_def_859  1
    service_0_12_4  free_load_conservation_860  4
    service_0_12_5  unique_nonzero_owner_417  1
    service_0_12_5  service_visit_def_859  1
    service_0_12_5  free_load_conservation_860  5
    service_0_12_6  unique_nonzero_owner_418  1
    service_0_12_6  service_visit_def_859  1
    service_0_12_6  free_load_conservation_860  6
    service_0_12_7  unique_nonzero_owner_419  1
    service_0_12_7  service_visit_def_859  1
    service_0_12_7  free_load_conservation_860  7
    service_0_12_8  unique_nonzero_owner_420  1
    service_0_12_8  service_visit_def_859  1
    service_0_12_8  free_load_conservation_860  8
    service_0_12_9  unique_nonzero_owner_421  1
    service_0_12_9  service_visit_def_859  1
    service_0_12_9  free_load_conservation_860  9
    service_0_12_10  unique_nonzero_owner_422  1
    service_0_12_10  service_visit_def_859  1
    service_0_12_10  free_load_conservation_860  10
    service_0_12_11  unique_nonzero_owner_423  1
    service_0_12_11  service_visit_def_859  1
    service_0_12_11  free_load_conservation_860  11
    service_0_12_12  unique_nonzero_owner_424  1
    service_0_12_12  service_visit_def_859  1
    service_0_12_12  free_load_conservation_860  12
    service_0_12_13  unique_nonzero_owner_425  1
    service_0_12_13  service_visit_def_859  1
    service_0_12_13  free_load_conservation_860  13
    service_0_12_14  unique_nonzero_owner_426  1
    service_0_12_14  service_visit_def_859  1
    service_0_12_14  free_load_conservation_860  14
    service_0_12_15  unique_nonzero_owner_427  1
    service_0_12_15  service_visit_def_859  1
    service_0_12_15  free_load_conservation_860  15
    service_1_12_1  unique_nonzero_owner_413  1
    service_1_12_1  service_visit_def_1288  1
    service_1_12_1  free_load_conservation_1289  1
    service_1_12_2  unique_nonzero_owner_414  1
    service_1_12_2  service_visit_def_1288  1
    service_1_12_2  free_load_conservation_1289  2
    service_1_12_3  unique_nonzero_owner_415  1
    service_1_12_3  service_visit_def_1288  1
    service_1_12_3  free_load_conservation_1289  3
    service_1_12_4  unique_nonzero_owner_416  1
    service_1_12_4  service_visit_def_1288  1
    service_1_12_4  free_load_conservation_1289  4
    service_1_12_5  unique_nonzero_owner_417  1
    service_1_12_5  service_visit_def_1288  1
    service_1_12_5  free_load_conservation_1289  5
    service_1_12_6  unique_nonzero_owner_418  1
    service_1_12_6  service_visit_def_1288  1
    service_1_12_6  free_load_conservation_1289  6
    service_1_12_7  unique_nonzero_owner_419  1
    service_1_12_7  service_visit_def_1288  1
    service_1_12_7  free_load_conservation_1289  7
    service_1_12_8  unique_nonzero_owner_420  1
    service_1_12_8  service_visit_def_1288  1
    service_1_12_8  free_load_conservation_1289  8
    service_1_12_9  unique_nonzero_owner_421  1
    service_1_12_9  service_visit_def_1288  1
    service_1_12_9  free_load_conservation_1289  9
    service_1_12_10  unique_nonzero_owner_422  1
    service_1_12_10  service_visit_def_1288  1
    service_1_12_10  free_load_conservation_1289  10
    service_1_12_11  unique_nonzero_owner_423  1
    service_1_12_11  service_visit_def_1288  1
    service_1_12_11  free_load_conservation_1289  11
    service_1_12_12  unique_nonzero_owner_424  1
    service_1_12_12  service_visit_def_1288  1
    service_1_12_12  free_load_conservation_1289  12
    service_1_12_13  unique_nonzero_owner_425  1
    service_1_12_13  service_visit_def_1288  1
    service_1_12_13  free_load_conservation_1289  13
    service_1_12_14  unique_nonzero_owner_426  1
    service_1_12_14  service_visit_def_1288  1
    service_1_12_14  free_load_conservation_1289  14
    service_1_12_15  unique_nonzero_owner_427  1
    service_1_12_15  service_visit_def_1288  1
    service_1_12_15  free_load_conservation_1289  15
    service_2_12_1  unique_nonzero_owner_413  1
    service_2_12_1  service_visit_def_1607  1
    service_2_12_1  free_load_conservation_1608  1
    service_2_12_2  unique_nonzero_owner_414  1
    service_2_12_2  service_visit_def_1607  1
    service_2_12_2  free_load_conservation_1608  2
    service_2_12_3  unique_nonzero_owner_415  1
    service_2_12_3  service_visit_def_1607  1
    service_2_12_3  free_load_conservation_1608  3
    service_2_12_4  unique_nonzero_owner_416  1
    service_2_12_4  service_visit_def_1607  1
    service_2_12_4  free_load_conservation_1608  4
    service_2_12_5  unique_nonzero_owner_417  1
    service_2_12_5  service_visit_def_1607  1
    service_2_12_5  free_load_conservation_1608  5
    service_2_12_6  unique_nonzero_owner_418  1
    service_2_12_6  service_visit_def_1607  1
    service_2_12_6  free_load_conservation_1608  6
    service_2_12_7  unique_nonzero_owner_419  1
    service_2_12_7  service_visit_def_1607  1
    service_2_12_7  free_load_conservation_1608  7
    service_2_12_8  unique_nonzero_owner_420  1
    service_2_12_8  service_visit_def_1607  1
    service_2_12_8  free_load_conservation_1608  8
    service_2_12_9  unique_nonzero_owner_421  1
    service_2_12_9  service_visit_def_1607  1
    service_2_12_9  free_load_conservation_1608  9
    service_2_12_10  unique_nonzero_owner_422  1
    service_2_12_10  service_visit_def_1607  1
    service_2_12_10  free_load_conservation_1608  10
    service_2_12_11  unique_nonzero_owner_423  1
    service_2_12_11  service_visit_def_1607  1
    service_2_12_11  free_load_conservation_1608  11
    service_2_12_12  unique_nonzero_owner_424  1
    service_2_12_12  service_visit_def_1607  1
    service_2_12_12  free_load_conservation_1608  12
    service_2_12_13  unique_nonzero_owner_425  1
    service_2_12_13  service_visit_def_1607  1
    service_2_12_13  free_load_conservation_1608  13
    service_2_12_14  unique_nonzero_owner_426  1
    service_2_12_14  service_visit_def_1607  1
    service_2_12_14  free_load_conservation_1608  14
    service_2_12_15  unique_nonzero_owner_427  1
    service_2_12_15  service_visit_def_1607  1
    service_2_12_15  free_load_conservation_1608  15
    service_0_27_0  unique_nonzero_owner_428  1
    service_0_27_0  service_visit_def_865  1
    service_0_27_0  free_load_conservation_866  -11
    service_0_27_0  original_T_including_depot_unload_871  1320
    service_0_27_1  unique_nonzero_owner_429  1
    service_0_27_1  service_visit_def_865  1
    service_0_27_1  free_load_conservation_866  -10
    service_0_27_1  original_T_including_depot_unload_871  1200
    service_0_27_2  unique_nonzero_owner_430  1
    service_0_27_2  service_visit_def_865  1
    service_0_27_2  free_load_conservation_866  -9
    service_0_27_2  original_T_including_depot_unload_871  1080
    service_0_27_3  unique_nonzero_owner_431  1
    service_0_27_3  service_visit_def_865  1
    service_0_27_3  free_load_conservation_866  -8
    service_0_27_3  original_T_including_depot_unload_871  960
    service_0_27_4  unique_nonzero_owner_432  1
    service_0_27_4  service_visit_def_865  1
    service_0_27_4  free_load_conservation_866  -7
    service_0_27_4  original_T_including_depot_unload_871  840
    service_0_27_5  unique_nonzero_owner_433  1
    service_0_27_5  service_visit_def_865  1
    service_0_27_5  free_load_conservation_866  -6
    service_0_27_5  original_T_including_depot_unload_871  720
    service_0_27_6  unique_nonzero_owner_434  1
    service_0_27_6  service_visit_def_865  1
    service_0_27_6  free_load_conservation_866  -5
    service_0_27_6  original_T_including_depot_unload_871  600
    service_0_27_7  unique_nonzero_owner_435  1
    service_0_27_7  service_visit_def_865  1
    service_0_27_7  free_load_conservation_866  -4
    service_0_27_7  original_T_including_depot_unload_871  480
    service_0_27_8  unique_nonzero_owner_436  1
    service_0_27_8  service_visit_def_865  1
    service_0_27_8  free_load_conservation_866  -3
    service_0_27_8  original_T_including_depot_unload_871  360
    service_0_27_9  unique_nonzero_owner_437  1
    service_0_27_9  service_visit_def_865  1
    service_0_27_9  free_load_conservation_866  -2
    service_0_27_9  original_T_including_depot_unload_871  240
    service_0_27_10  unique_nonzero_owner_438  1
    service_0_27_10  service_visit_def_865  1
    service_0_27_10  free_load_conservation_866  -1
    service_0_27_10  original_T_including_depot_unload_871  120
    service_0_27_12  unique_nonzero_owner_439  1
    service_0_27_12  service_visit_def_865  1
    service_0_27_12  free_load_conservation_866  1
    service_0_27_13  unique_nonzero_owner_440  1
    service_0_27_13  service_visit_def_865  1
    service_0_27_13  free_load_conservation_866  2
    service_0_27_14  unique_nonzero_owner_441  1
    service_0_27_14  service_visit_def_865  1
    service_0_27_14  free_load_conservation_866  3
    service_0_27_15  unique_nonzero_owner_442  1
    service_0_27_15  service_visit_def_865  1
    service_0_27_15  free_load_conservation_866  4
    service_1_27_0  unique_nonzero_owner_428  1
    service_1_27_0  service_visit_def_1294  1
    service_1_27_0  free_load_conservation_1295  -11
    service_1_27_0  original_T_including_depot_unload_1300  1320
    service_1_27_1  unique_nonzero_owner_429  1
    service_1_27_1  service_visit_def_1294  1
    service_1_27_1  free_load_conservation_1295  -10
    service_1_27_1  original_T_including_depot_unload_1300  1200
    service_1_27_2  unique_nonzero_owner_430  1
    service_1_27_2  service_visit_def_1294  1
    service_1_27_2  free_load_conservation_1295  -9
    service_1_27_2  original_T_including_depot_unload_1300  1080
    service_1_27_3  unique_nonzero_owner_431  1
    service_1_27_3  service_visit_def_1294  1
    service_1_27_3  free_load_conservation_1295  -8
    service_1_27_3  original_T_including_depot_unload_1300  960
    service_1_27_4  unique_nonzero_owner_432  1
    service_1_27_4  service_visit_def_1294  1
    service_1_27_4  free_load_conservation_1295  -7
    service_1_27_4  original_T_including_depot_unload_1300  840
    service_1_27_5  unique_nonzero_owner_433  1
    service_1_27_5  service_visit_def_1294  1
    service_1_27_5  free_load_conservation_1295  -6
    service_1_27_5  original_T_including_depot_unload_1300  720
    service_1_27_6  unique_nonzero_owner_434  1
    service_1_27_6  service_visit_def_1294  1
    service_1_27_6  free_load_conservation_1295  -5
    service_1_27_6  original_T_including_depot_unload_1300  600
    service_1_27_7  unique_nonzero_owner_435  1
    service_1_27_7  service_visit_def_1294  1
    service_1_27_7  free_load_conservation_1295  -4
    service_1_27_7  original_T_including_depot_unload_1300  480
    service_1_27_8  unique_nonzero_owner_436  1
    service_1_27_8  service_visit_def_1294  1
    service_1_27_8  free_load_conservation_1295  -3
    service_1_27_8  original_T_including_depot_unload_1300  360
    service_1_27_9  unique_nonzero_owner_437  1
    service_1_27_9  service_visit_def_1294  1
    service_1_27_9  free_load_conservation_1295  -2
    service_1_27_9  original_T_including_depot_unload_1300  240
    service_1_27_10  unique_nonzero_owner_438  1
    service_1_27_10  service_visit_def_1294  1
    service_1_27_10  free_load_conservation_1295  -1
    service_1_27_10  original_T_including_depot_unload_1300  120
    service_1_27_12  unique_nonzero_owner_439  1
    service_1_27_12  service_visit_def_1294  1
    service_1_27_12  free_load_conservation_1295  1
    service_1_27_13  unique_nonzero_owner_440  1
    service_1_27_13  service_visit_def_1294  1
    service_1_27_13  free_load_conservation_1295  2
    service_1_27_14  unique_nonzero_owner_441  1
    service_1_27_14  service_visit_def_1294  1
    service_1_27_14  free_load_conservation_1295  3
    service_1_27_15  unique_nonzero_owner_442  1
    service_1_27_15  service_visit_def_1294  1
    service_1_27_15  free_load_conservation_1295  4
    service_2_27_0  unique_nonzero_owner_428  1
    service_2_27_0  service_visit_def_1613  1
    service_2_27_0  free_load_conservation_1614  -11
    service_2_27_0  original_T_including_depot_unload_1617  1320
    service_2_27_1  unique_nonzero_owner_429  1
    service_2_27_1  service_visit_def_1613  1
    service_2_27_1  free_load_conservation_1614  -10
    service_2_27_1  original_T_including_depot_unload_1617  1200
    service_2_27_2  unique_nonzero_owner_430  1
    service_2_27_2  service_visit_def_1613  1
    service_2_27_2  free_load_conservation_1614  -9
    service_2_27_2  original_T_including_depot_unload_1617  1080
    service_2_27_3  unique_nonzero_owner_431  1
    service_2_27_3  service_visit_def_1613  1
    service_2_27_3  free_load_conservation_1614  -8
    service_2_27_3  original_T_including_depot_unload_1617  960
    service_2_27_4  unique_nonzero_owner_432  1
    service_2_27_4  service_visit_def_1613  1
    service_2_27_4  free_load_conservation_1614  -7
    service_2_27_4  original_T_including_depot_unload_1617  840
    service_2_27_5  unique_nonzero_owner_433  1
    service_2_27_5  service_visit_def_1613  1
    service_2_27_5  free_load_conservation_1614  -6
    service_2_27_5  original_T_including_depot_unload_1617  720
    service_2_27_6  unique_nonzero_owner_434  1
    service_2_27_6  service_visit_def_1613  1
    service_2_27_6  free_load_conservation_1614  -5
    service_2_27_6  original_T_including_depot_unload_1617  600
    service_2_27_7  unique_nonzero_owner_435  1
    service_2_27_7  service_visit_def_1613  1
    service_2_27_7  free_load_conservation_1614  -4
    service_2_27_7  original_T_including_depot_unload_1617  480
    service_2_27_8  unique_nonzero_owner_436  1
    service_2_27_8  service_visit_def_1613  1
    service_2_27_8  free_load_conservation_1614  -3
    service_2_27_8  original_T_including_depot_unload_1617  360
    service_2_27_9  unique_nonzero_owner_437  1
    service_2_27_9  service_visit_def_1613  1
    service_2_27_9  free_load_conservation_1614  -2
    service_2_27_9  original_T_including_depot_unload_1617  240
    service_2_27_10  unique_nonzero_owner_438  1
    service_2_27_10  service_visit_def_1613  1
    service_2_27_10  free_load_conservation_1614  -1
    service_2_27_10  original_T_including_depot_unload_1617  120
    service_2_27_12  unique_nonzero_owner_439  1
    service_2_27_12  service_visit_def_1613  1
    service_2_27_12  free_load_conservation_1614  1
    service_2_27_13  unique_nonzero_owner_440  1
    service_2_27_13  service_visit_def_1613  1
    service_2_27_13  free_load_conservation_1614  2
    service_2_27_14  unique_nonzero_owner_441  1
    service_2_27_14  service_visit_def_1613  1
    service_2_27_14  free_load_conservation_1614  3
    service_2_27_15  unique_nonzero_owner_442  1
    service_2_27_15  service_visit_def_1613  1
    service_2_27_15  free_load_conservation_1614  4
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_784  -1
    visit_0_1  in_degree_785  -1
    visit_0_1  order_active_lb_786  -1
    visit_0_1  order_active_ub_787  -13
    order_0_1  connected_order_arc_459  -1
    order_0_1  connected_order_arc_461  -1
    order_0_1  connected_order_arc_463  -1
    order_0_1  connected_order_arc_465  -1
    order_0_1  connected_order_arc_467  -1
    order_0_1  connected_order_arc_469  -1
    order_0_1  connected_order_arc_471  -1
    order_0_1  connected_order_arc_473  -1
    order_0_1  connected_order_arc_475  -1
    order_0_1  connected_order_arc_477  -1
    order_0_1  connected_order_arc_479  -1
    order_0_1  connected_order_arc_481  -1
    order_0_1  connected_order_arc_484  1
    order_0_1  connected_order_arc_509  1
    order_0_1  connected_order_arc_534  1
    order_0_1  connected_order_arc_559  1
    order_0_1  connected_order_arc_584  1
    order_0_1  connected_order_arc_609  1
    order_0_1  connected_order_arc_634  1
    order_0_1  connected_order_arc_659  1
    order_0_1  connected_order_arc_684  1
    order_0_1  connected_order_arc_709  1
    order_0_1  connected_order_arc_734  1
    order_0_1  connected_order_arc_759  1
    order_0_1  order_active_lb_786  1
    order_0_1  order_active_ub_787  1
    order_0_1  fixed_segment_relative_order_867  -1
    visit_0_2  out_degree_791  -1
    visit_0_2  in_degree_792  -1
    visit_0_2  order_active_lb_793  -1
    visit_0_2  order_active_ub_794  -13
    order_0_2  connected_order_arc_459  1
    order_0_2  connected_order_arc_484  -1
    order_0_2  connected_order_arc_486  -1
    order_0_2  connected_order_arc_488  -1
    order_0_2  connected_order_arc_490  -1
    order_0_2  connected_order_arc_492  -1
    order_0_2  connected_order_arc_494  -1
    order_0_2  connected_order_arc_496  -1
    order_0_2  connected_order_arc_498  -1
    order_0_2  connected_order_arc_500  -1
    order_0_2  connected_order_arc_502  -1
    order_0_2  connected_order_arc_504  -1
    order_0_2  connected_order_arc_506  -1
    order_0_2  connected_order_arc_511  1
    order_0_2  connected_order_arc_536  1
    order_0_2  connected_order_arc_561  1
    order_0_2  connected_order_arc_586  1
    order_0_2  connected_order_arc_611  1
    order_0_2  connected_order_arc_636  1
    order_0_2  connected_order_arc_661  1
    order_0_2  connected_order_arc_686  1
    order_0_2  connected_order_arc_711  1
    order_0_2  connected_order_arc_736  1
    order_0_2  connected_order_arc_761  1
    order_0_2  order_active_lb_793  1
    order_0_2  order_active_ub_794  1
    order_0_2  fixed_segment_relative_order_867  1
    order_0_2  fixed_segment_relative_order_868  -1
    visit_0_3  out_degree_798  -1
    visit_0_3  in_degree_799  -1
    visit_0_3  order_active_lb_800  -1
    visit_0_3  order_active_ub_801  -13
    order_0_3  connected_order_arc_461  1
    order_0_3  connected_order_arc_486  1
    order_0_3  connected_order_arc_509  -1
    order_0_3  connected_order_arc_511  -1
    order_0_3  connected_order_arc_513  -1
    order_0_3  connected_order_arc_515  -1
    order_0_3  connected_order_arc_517  -1
    order_0_3  connected_order_arc_519  -1
    order_0_3  connected_order_arc_521  -1
    order_0_3  connected_order_arc_523  -1
    order_0_3  connected_order_arc_525  -1
    order_0_3  connected_order_arc_527  -1
    order_0_3  connected_order_arc_529  -1
    order_0_3  connected_order_arc_531  -1
    order_0_3  connected_order_arc_538  1
    order_0_3  connected_order_arc_563  1
    order_0_3  connected_order_arc_588  1
    order_0_3  connected_order_arc_613  1
    order_0_3  connected_order_arc_638  1
    order_0_3  connected_order_arc_663  1
    order_0_3  connected_order_arc_688  1
    order_0_3  connected_order_arc_713  1
    order_0_3  connected_order_arc_738  1
    order_0_3  connected_order_arc_763  1
    order_0_3  order_active_lb_800  1
    order_0_3  order_active_ub_801  1
    order_0_3  fixed_segment_relative_order_868  1
    order_0_3  fixed_segment_relative_order_869  -1
    visit_0_4  out_degree_805  -1
    visit_0_4  in_degree_806  -1
    visit_0_4  order_active_lb_807  -1
    visit_0_4  order_active_ub_808  -13
    order_0_4  connected_order_arc_463  1
    order_0_4  connected_order_arc_488  1
    order_0_4  connected_order_arc_513  1
    order_0_4  connected_order_arc_534  -1
    order_0_4  connected_order_arc_536  -1
    order_0_4  connected_order_arc_538  -1
    order_0_4  connected_order_arc_540  -1
    order_0_4  connected_order_arc_542  -1
    order_0_4  connected_order_arc_544  -1
    order_0_4  connected_order_arc_546  -1
    order_0_4  connected_order_arc_548  -1
    order_0_4  connected_order_arc_550  -1
    order_0_4  connected_order_arc_552  -1
    order_0_4  connected_order_arc_554  -1
    order_0_4  connected_order_arc_556  -1
    order_0_4  connected_order_arc_565  1
    order_0_4  connected_order_arc_590  1
    order_0_4  connected_order_arc_615  1
    order_0_4  connected_order_arc_640  1
    order_0_4  connected_order_arc_665  1
    order_0_4  connected_order_arc_690  1
    order_0_4  connected_order_arc_715  1
    order_0_4  connected_order_arc_740  1
    order_0_4  connected_order_arc_765  1
    order_0_4  order_active_lb_807  1
    order_0_4  order_active_ub_808  1
    order_0_4  fixed_segment_relative_order_869  1
    order_0_4  fixed_segment_relative_order_870  -1
    visit_0_5  out_degree_812  -1
    visit_0_5  in_degree_813  -1
    visit_0_5  order_active_lb_814  -1
    visit_0_5  order_active_ub_815  -13
    order_0_5  connected_order_arc_465  1
    order_0_5  connected_order_arc_490  1
    order_0_5  connected_order_arc_515  1
    order_0_5  connected_order_arc_540  1
    order_0_5  connected_order_arc_559  -1
    order_0_5  connected_order_arc_561  -1
    order_0_5  connected_order_arc_563  -1
    order_0_5  connected_order_arc_565  -1
    order_0_5  connected_order_arc_567  -1
    order_0_5  connected_order_arc_569  -1
    order_0_5  connected_order_arc_571  -1
    order_0_5  connected_order_arc_573  -1
    order_0_5  connected_order_arc_575  -1
    order_0_5  connected_order_arc_577  -1
    order_0_5  connected_order_arc_579  -1
    order_0_5  connected_order_arc_581  -1
    order_0_5  connected_order_arc_592  1
    order_0_5  connected_order_arc_617  1
    order_0_5  connected_order_arc_642  1
    order_0_5  connected_order_arc_667  1
    order_0_5  connected_order_arc_692  1
    order_0_5  connected_order_arc_717  1
    order_0_5  connected_order_arc_742  1
    order_0_5  connected_order_arc_767  1
    order_0_5  order_active_lb_814  1
    order_0_5  order_active_ub_815  1
    order_0_5  fixed_segment_relative_order_870  1
    visit_0_14  out_degree_819  -1
    visit_0_14  in_degree_820  -1
    visit_0_14  order_active_lb_821  -1
    visit_0_14  order_active_ub_822  -13
    visit_0_14  service_visit_def_823  -1
    order_0_14  connected_order_arc_467  1
    order_0_14  connected_order_arc_492  1
    order_0_14  connected_order_arc_517  1
    order_0_14  connected_order_arc_542  1
    order_0_14  connected_order_arc_567  1
    order_0_14  connected_order_arc_584  -1
    order_0_14  connected_order_arc_586  -1
    order_0_14  connected_order_arc_588  -1
    order_0_14  connected_order_arc_590  -1
    order_0_14  connected_order_arc_592  -1
    order_0_14  connected_order_arc_594  -1
    order_0_14  connected_order_arc_596  -1
    order_0_14  connected_order_arc_598  -1
    order_0_14  connected_order_arc_600  -1
    order_0_14  connected_order_arc_602  -1
    order_0_14  connected_order_arc_604  -1
    order_0_14  connected_order_arc_606  -1
    order_0_14  connected_order_arc_619  1
    order_0_14  connected_order_arc_644  1
    order_0_14  connected_order_arc_669  1
    order_0_14  connected_order_arc_694  1
    order_0_14  connected_order_arc_719  1
    order_0_14  connected_order_arc_744  1
    order_0_14  connected_order_arc_769  1
    order_0_14  order_active_lb_821  1
    order_0_14  order_active_ub_822  1
    visit_0_15  out_degree_825  -1
    visit_0_15  in_degree_826  -1
    visit_0_15  order_active_lb_827  -1
    visit_0_15  order_active_ub_828  -13
    visit_0_15  service_visit_def_829  -1
    order_0_15  connected_order_arc_469  1
    order_0_15  connected_order_arc_494  1
    order_0_15  connected_order_arc_519  1
    order_0_15  connected_order_arc_544  1
    order_0_15  connected_order_arc_569  1
    order_0_15  connected_order_arc_594  1
    order_0_15  connected_order_arc_609  -1
    order_0_15  connected_order_arc_611  -1
    order_0_15  connected_order_arc_613  -1
    order_0_15  connected_order_arc_615  -1
    order_0_15  connected_order_arc_617  -1
    order_0_15  connected_order_arc_619  -1
    order_0_15  connected_order_arc_621  -1
    order_0_15  connected_order_arc_623  -1
    order_0_15  connected_order_arc_625  -1
    order_0_15  connected_order_arc_627  -1
    order_0_15  connected_order_arc_629  -1
    order_0_15  connected_order_arc_631  -1
    order_0_15  connected_order_arc_646  1
    order_0_15  connected_order_arc_671  1
    order_0_15  connected_order_arc_696  1
    order_0_15  connected_order_arc_721  1
    order_0_15  connected_order_arc_746  1
    order_0_15  connected_order_arc_771  1
    order_0_15  order_active_lb_827  1
    order_0_15  order_active_ub_828  1
    visit_0_16  out_degree_831  -1
    visit_0_16  in_degree_832  -1
    visit_0_16  order_active_lb_833  -1
    visit_0_16  order_active_ub_834  -13
    visit_0_16  service_visit_def_835  -1
    order_0_16  connected_order_arc_471  1
    order_0_16  connected_order_arc_496  1
    order_0_16  connected_order_arc_521  1
    order_0_16  connected_order_arc_546  1
    order_0_16  connected_order_arc_571  1
    order_0_16  connected_order_arc_596  1
    order_0_16  connected_order_arc_621  1
    order_0_16  connected_order_arc_634  -1
    order_0_16  connected_order_arc_636  -1
    order_0_16  connected_order_arc_638  -1
    order_0_16  connected_order_arc_640  -1
    order_0_16  connected_order_arc_642  -1
    order_0_16  connected_order_arc_644  -1
    order_0_16  connected_order_arc_646  -1
    order_0_16  connected_order_arc_648  -1
    order_0_16  connected_order_arc_650  -1
    order_0_16  connected_order_arc_652  -1
    order_0_16  connected_order_arc_654  -1
    order_0_16  connected_order_arc_656  -1
    order_0_16  connected_order_arc_673  1
    order_0_16  connected_order_arc_698  1
    order_0_16  connected_order_arc_723  1
    order_0_16  connected_order_arc_748  1
    order_0_16  connected_order_arc_773  1
    order_0_16  order_active_lb_833  1
    order_0_16  order_active_ub_834  1
    visit_0_17  out_degree_837  -1
    visit_0_17  in_degree_838  -1
    visit_0_17  order_active_lb_839  -1
    visit_0_17  order_active_ub_840  -13
    visit_0_17  service_visit_def_841  -1
    order_0_17  connected_order_arc_473  1
    order_0_17  connected_order_arc_498  1
    order_0_17  connected_order_arc_523  1
    order_0_17  connected_order_arc_548  1
    order_0_17  connected_order_arc_573  1
    order_0_17  connected_order_arc_598  1
    order_0_17  connected_order_arc_623  1
    order_0_17  connected_order_arc_648  1
    order_0_17  connected_order_arc_659  -1
    order_0_17  connected_order_arc_661  -1
    order_0_17  connected_order_arc_663  -1
    order_0_17  connected_order_arc_665  -1
    order_0_17  connected_order_arc_667  -1
    order_0_17  connected_order_arc_669  -1
    order_0_17  connected_order_arc_671  -1
    order_0_17  connected_order_arc_673  -1
    order_0_17  connected_order_arc_675  -1
    order_0_17  connected_order_arc_677  -1
    order_0_17  connected_order_arc_679  -1
    order_0_17  connected_order_arc_681  -1
    order_0_17  connected_order_arc_700  1
    order_0_17  connected_order_arc_725  1
    order_0_17  connected_order_arc_750  1
    order_0_17  connected_order_arc_775  1
    order_0_17  order_active_lb_839  1
    order_0_17  order_active_ub_840  1
    visit_0_18  out_degree_843  -1
    visit_0_18  in_degree_844  -1
    visit_0_18  order_active_lb_845  -1
    visit_0_18  order_active_ub_846  -13
    visit_0_18  service_visit_def_847  -1
    order_0_18  connected_order_arc_475  1
    order_0_18  connected_order_arc_500  1
    order_0_18  connected_order_arc_525  1
    order_0_18  connected_order_arc_550  1
    order_0_18  connected_order_arc_575  1
    order_0_18  connected_order_arc_600  1
    order_0_18  connected_order_arc_625  1
    order_0_18  connected_order_arc_650  1
    order_0_18  connected_order_arc_675  1
    order_0_18  connected_order_arc_684  -1
    order_0_18  connected_order_arc_686  -1
    order_0_18  connected_order_arc_688  -1
    order_0_18  connected_order_arc_690  -1
    order_0_18  connected_order_arc_692  -1
    order_0_18  connected_order_arc_694  -1
    order_0_18  connected_order_arc_696  -1
    order_0_18  connected_order_arc_698  -1
    order_0_18  connected_order_arc_700  -1
    order_0_18  connected_order_arc_702  -1
    order_0_18  connected_order_arc_704  -1
    order_0_18  connected_order_arc_706  -1
    order_0_18  connected_order_arc_727  1
    order_0_18  connected_order_arc_752  1
    order_0_18  connected_order_arc_777  1
    order_0_18  order_active_lb_845  1
    order_0_18  order_active_ub_846  1
    visit_0_19  out_degree_849  -1
    visit_0_19  in_degree_850  -1
    visit_0_19  order_active_lb_851  -1
    visit_0_19  order_active_ub_852  -13
    visit_0_19  service_visit_def_853  -1
    order_0_19  connected_order_arc_477  1
    order_0_19  connected_order_arc_502  1
    order_0_19  connected_order_arc_527  1
    order_0_19  connected_order_arc_552  1
    order_0_19  connected_order_arc_577  1
    order_0_19  connected_order_arc_602  1
    order_0_19  connected_order_arc_627  1
    order_0_19  connected_order_arc_652  1
    order_0_19  connected_order_arc_677  1
    order_0_19  connected_order_arc_702  1
    order_0_19  connected_order_arc_709  -1
    order_0_19  connected_order_arc_711  -1
    order_0_19  connected_order_arc_713  -1
    order_0_19  connected_order_arc_715  -1
    order_0_19  connected_order_arc_717  -1
    order_0_19  connected_order_arc_719  -1
    order_0_19  connected_order_arc_721  -1
    order_0_19  connected_order_arc_723  -1
    order_0_19  connected_order_arc_725  -1
    order_0_19  connected_order_arc_727  -1
    order_0_19  connected_order_arc_729  -1
    order_0_19  connected_order_arc_731  -1
    order_0_19  connected_order_arc_754  1
    order_0_19  connected_order_arc_779  1
    order_0_19  order_active_lb_851  1
    order_0_19  order_active_ub_852  1
    visit_0_20  out_degree_855  -1
    visit_0_20  in_degree_856  -1
    visit_0_20  order_active_lb_857  -1
    visit_0_20  order_active_ub_858  -13
    visit_0_20  service_visit_def_859  -1
    order_0_20  connected_order_arc_479  1
    order_0_20  connected_order_arc_504  1
    order_0_20  connected_order_arc_529  1
    order_0_20  connected_order_arc_554  1
    order_0_20  connected_order_arc_579  1
    order_0_20  connected_order_arc_604  1
    order_0_20  connected_order_arc_629  1
    order_0_20  connected_order_arc_654  1
    order_0_20  connected_order_arc_679  1
    order_0_20  connected_order_arc_704  1
    order_0_20  connected_order_arc_729  1
    order_0_20  connected_order_arc_734  -1
    order_0_20  connected_order_arc_736  -1
    order_0_20  connected_order_arc_738  -1
    order_0_20  connected_order_arc_740  -1
    order_0_20  connected_order_arc_742  -1
    order_0_20  connected_order_arc_744  -1
    order_0_20  connected_order_arc_746  -1
    order_0_20  connected_order_arc_748  -1
    order_0_20  connected_order_arc_750  -1
    order_0_20  connected_order_arc_752  -1
    order_0_20  connected_order_arc_754  -1
    order_0_20  connected_order_arc_756  -1
    order_0_20  connected_order_arc_781  1
    order_0_20  order_active_lb_857  1
    order_0_20  order_active_ub_858  1
    visit_0_21  out_degree_861  -1
    visit_0_21  in_degree_862  -1
    visit_0_21  order_active_lb_863  -1
    visit_0_21  order_active_ub_864  -13
    visit_0_21  service_visit_def_865  -1
    order_0_21  connected_order_arc_481  1
    order_0_21  connected_order_arc_506  1
    order_0_21  connected_order_arc_531  1
    order_0_21  connected_order_arc_556  1
    order_0_21  connected_order_arc_581  1
    order_0_21  connected_order_arc_606  1
    order_0_21  connected_order_arc_631  1
    order_0_21  connected_order_arc_656  1
    order_0_21  connected_order_arc_681  1
    order_0_21  connected_order_arc_706  1
    order_0_21  connected_order_arc_731  1
    order_0_21  connected_order_arc_756  1
    order_0_21  connected_order_arc_759  -1
    order_0_21  connected_order_arc_761  -1
    order_0_21  connected_order_arc_763  -1
    order_0_21  connected_order_arc_765  -1
    order_0_21  connected_order_arc_767  -1
    order_0_21  connected_order_arc_769  -1
    order_0_21  connected_order_arc_771  -1
    order_0_21  connected_order_arc_773  -1
    order_0_21  connected_order_arc_775  -1
    order_0_21  connected_order_arc_777  -1
    order_0_21  connected_order_arc_779  -1
    order_0_21  connected_order_arc_781  -1
    order_0_21  order_active_lb_863  1
    order_0_21  order_active_ub_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_443  -20
    arc_0_0_0  depot_departure_or_bypass_782  1
    arc_0_0_0  depot_return_or_bypass_783  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_443  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_444  -20
    arc_0_0_1  depot_departure_or_bypass_782  1
    arc_0_0_1  in_degree_785  1
    arc_0_0_1  original_T_including_depot_unload_871  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_444  1
    load_0_0_1  segment_load_conservation_788  -1
    load_0_0_1  segment_prefix_lb_789  1
    load_0_0_1  segment_prefix_ub_790  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_445  -20
    arc_0_0_2  depot_departure_or_bypass_782  1
    arc_0_0_2  in_degree_792  1
    arc_0_0_2  original_T_including_depot_unload_871  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_445  1
    load_0_0_2  segment_load_conservation_795  -1
    load_0_0_2  segment_prefix_lb_796  1
    load_0_0_2  segment_prefix_ub_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_446  -20
    arc_0_0_3  depot_departure_or_bypass_782  1
    arc_0_0_3  in_degree_799  1
    arc_0_0_3  original_T_including_depot_unload_871  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_446  1
    load_0_0_3  segment_load_conservation_802  -1
    load_0_0_3  segment_prefix_lb_803  1
    load_0_0_3  segment_prefix_ub_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_447  -20
    arc_0_0_4  depot_departure_or_bypass_782  1
    arc_0_0_4  in_degree_806  1
    arc_0_0_4  original_T_including_depot_unload_871  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_447  1
    load_0_0_4  segment_load_conservation_809  -1
    load_0_0_4  segment_prefix_lb_810  1
    load_0_0_4  segment_prefix_ub_811  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_448  -20
    arc_0_0_5  depot_departure_or_bypass_782  1
    arc_0_0_5  in_degree_813  1
    arc_0_0_5  original_T_including_depot_unload_871  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_448  1
    load_0_0_5  segment_load_conservation_816  -1
    load_0_0_5  segment_prefix_lb_817  1
    load_0_0_5  segment_prefix_ub_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_449  -20
    arc_0_0_14  depot_departure_or_bypass_782  1
    arc_0_0_14  in_degree_820  1
    arc_0_0_14  original_T_including_depot_unload_871  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_449  1
    load_0_0_14  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_450  -20
    arc_0_0_15  depot_departure_or_bypass_782  1
    arc_0_0_15  in_degree_826  1
    arc_0_0_15  original_T_including_depot_unload_871  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_450  1
    load_0_0_15  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_451  -20
    arc_0_0_16  depot_departure_or_bypass_782  1
    arc_0_0_16  in_degree_832  1
    arc_0_0_16  original_T_including_depot_unload_871  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_451  1
    load_0_0_16  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_452  -20
    arc_0_0_17  depot_departure_or_bypass_782  1
    arc_0_0_17  in_degree_838  1
    arc_0_0_17  original_T_including_depot_unload_871  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_452  1
    load_0_0_17  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_453  -20
    arc_0_0_18  depot_departure_or_bypass_782  1
    arc_0_0_18  in_degree_844  1
    arc_0_0_18  original_T_including_depot_unload_871  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_453  1
    load_0_0_18  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_454  -20
    arc_0_0_19  depot_departure_or_bypass_782  1
    arc_0_0_19  in_degree_850  1
    arc_0_0_19  original_T_including_depot_unload_871  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_454  1
    load_0_0_19  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_455  -20
    arc_0_0_20  depot_departure_or_bypass_782  1
    arc_0_0_20  in_degree_856  1
    arc_0_0_20  original_T_including_depot_unload_871  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_455  1
    load_0_0_20  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_456  -20
    arc_0_0_21  depot_departure_or_bypass_782  1
    arc_0_0_21  in_degree_862  1
    arc_0_0_21  original_T_including_depot_unload_871  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_456  1
    load_0_0_21  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_457  -20
    arc_0_1_0  depot_return_or_bypass_783  1
    arc_0_1_0  out_degree_784  1
    arc_0_1_0  original_T_including_depot_unload_871  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_457  1
    load_0_1_0  segment_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_458  -20
    arc_0_1_2  connected_order_arc_459  -14
    arc_0_1_2  out_degree_784  1
    arc_0_1_2  in_degree_792  1
    arc_0_1_2  original_T_including_depot_unload_871  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_458  1
    load_0_1_2  segment_load_conservation_788  1
    load_0_1_2  segment_load_conservation_795  -1
    load_0_1_2  segment_prefix_lb_796  1
    load_0_1_2  segment_prefix_ub_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_460  -20
    arc_0_1_3  connected_order_arc_461  -14
    arc_0_1_3  out_degree_784  1
    arc_0_1_3  in_degree_799  1
    arc_0_1_3  original_T_including_depot_unload_871  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_460  1
    load_0_1_3  segment_load_conservation_788  1
    load_0_1_3  segment_load_conservation_802  -1
    load_0_1_3  segment_prefix_lb_803  1
    load_0_1_3  segment_prefix_ub_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_462  -20
    arc_0_1_4  connected_order_arc_463  -14
    arc_0_1_4  out_degree_784  1
    arc_0_1_4  in_degree_806  1
    arc_0_1_4  original_T_including_depot_unload_871  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_462  1
    load_0_1_4  segment_load_conservation_788  1
    load_0_1_4  segment_load_conservation_809  -1
    load_0_1_4  segment_prefix_lb_810  1
    load_0_1_4  segment_prefix_ub_811  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_464  -20
    arc_0_1_5  connected_order_arc_465  -14
    arc_0_1_5  out_degree_784  1
    arc_0_1_5  in_degree_813  1
    arc_0_1_5  original_T_including_depot_unload_871  7.5688558078083690e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_464  1
    load_0_1_5  segment_load_conservation_788  1
    load_0_1_5  segment_load_conservation_816  -1
    load_0_1_5  segment_prefix_lb_817  1
    load_0_1_5  segment_prefix_ub_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_466  -20
    arc_0_1_14  connected_order_arc_467  -14
    arc_0_1_14  out_degree_784  1
    arc_0_1_14  in_degree_820  1
    arc_0_1_14  original_T_including_depot_unload_871  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_466  1
    load_0_1_14  segment_load_conservation_788  1
    load_0_1_14  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_468  -20
    arc_0_1_15  connected_order_arc_469  -14
    arc_0_1_15  out_degree_784  1
    arc_0_1_15  in_degree_826  1
    arc_0_1_15  original_T_including_depot_unload_871  1.3840439316159188e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_468  1
    load_0_1_15  segment_load_conservation_788  1
    load_0_1_15  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_470  -20
    arc_0_1_16  connected_order_arc_471  -14
    arc_0_1_16  out_degree_784  1
    arc_0_1_16  in_degree_832  1
    arc_0_1_16  original_T_including_depot_unload_871  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_470  1
    load_0_1_16  segment_load_conservation_788  1
    load_0_1_16  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_472  -20
    arc_0_1_17  connected_order_arc_473  -14
    arc_0_1_17  out_degree_784  1
    arc_0_1_17  in_degree_838  1
    arc_0_1_17  original_T_including_depot_unload_871  1.5145600125783847e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_472  1
    load_0_1_17  segment_load_conservation_788  1
    load_0_1_17  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_474  -20
    arc_0_1_18  connected_order_arc_475  -14
    arc_0_1_18  out_degree_784  1
    arc_0_1_18  in_degree_844  1
    arc_0_1_18  original_T_including_depot_unload_871  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_474  1
    load_0_1_18  segment_load_conservation_788  1
    load_0_1_18  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_476  -20
    arc_0_1_19  connected_order_arc_477  -14
    arc_0_1_19  out_degree_784  1
    arc_0_1_19  in_degree_850  1
    arc_0_1_19  original_T_including_depot_unload_871  1.2876689365561549e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_476  1
    load_0_1_19  segment_load_conservation_788  1
    load_0_1_19  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_478  -20
    arc_0_1_20  connected_order_arc_479  -14
    arc_0_1_20  out_degree_784  1
    arc_0_1_20  in_degree_856  1
    arc_0_1_20  original_T_including_depot_unload_871  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_478  1
    load_0_1_20  segment_load_conservation_788  1
    load_0_1_20  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_480  -20
    arc_0_1_21  connected_order_arc_481  -14
    arc_0_1_21  out_degree_784  1
    arc_0_1_21  in_degree_862  1
    arc_0_1_21  original_T_including_depot_unload_871  1.3776676659817167e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_480  1
    load_0_1_21  segment_load_conservation_788  1
    load_0_1_21  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_482  -20
    arc_0_2_0  depot_return_or_bypass_783  1
    arc_0_2_0  out_degree_791  1
    arc_0_2_0  original_T_including_depot_unload_871  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_482  1
    load_0_2_0  segment_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_483  -20
    arc_0_2_1  connected_order_arc_484  -14
    arc_0_2_1  in_degree_785  1
    arc_0_2_1  out_degree_791  1
    arc_0_2_1  original_T_including_depot_unload_871  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_483  1
    load_0_2_1  segment_load_conservation_788  -1
    load_0_2_1  segment_prefix_lb_789  1
    load_0_2_1  segment_prefix_ub_790  1
    load_0_2_1  segment_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_485  -20
    arc_0_2_3  connected_order_arc_486  -14
    arc_0_2_3  out_degree_791  1
    arc_0_2_3  in_degree_799  1
    arc_0_2_3  original_T_including_depot_unload_871  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_485  1
    load_0_2_3  segment_load_conservation_795  1
    load_0_2_3  segment_load_conservation_802  -1
    load_0_2_3  segment_prefix_lb_803  1
    load_0_2_3  segment_prefix_ub_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_487  -20
    arc_0_2_4  connected_order_arc_488  -14
    arc_0_2_4  out_degree_791  1
    arc_0_2_4  in_degree_806  1
    arc_0_2_4  original_T_including_depot_unload_871  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_487  1
    load_0_2_4  segment_load_conservation_795  1
    load_0_2_4  segment_load_conservation_809  -1
    load_0_2_4  segment_prefix_lb_810  1
    load_0_2_4  segment_prefix_ub_811  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_489  -20
    arc_0_2_5  connected_order_arc_490  -14
    arc_0_2_5  out_degree_791  1
    arc_0_2_5  in_degree_813  1
    arc_0_2_5  original_T_including_depot_unload_871  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_489  1
    load_0_2_5  segment_load_conservation_795  1
    load_0_2_5  segment_load_conservation_816  -1
    load_0_2_5  segment_prefix_lb_817  1
    load_0_2_5  segment_prefix_ub_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_491  -20
    arc_0_2_14  connected_order_arc_492  -14
    arc_0_2_14  out_degree_791  1
    arc_0_2_14  in_degree_820  1
    arc_0_2_14  original_T_including_depot_unload_871  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_491  1
    load_0_2_14  segment_load_conservation_795  1
    load_0_2_14  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_493  -20
    arc_0_2_15  connected_order_arc_494  -14
    arc_0_2_15  out_degree_791  1
    arc_0_2_15  in_degree_826  1
    arc_0_2_15  original_T_including_depot_unload_871  1.3293032990949939e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_493  1
    load_0_2_15  segment_load_conservation_795  1
    load_0_2_15  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_495  -20
    arc_0_2_16  connected_order_arc_496  -14
    arc_0_2_16  out_degree_791  1
    arc_0_2_16  in_degree_832  1
    arc_0_2_16  original_T_including_depot_unload_871  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_495  1
    load_0_2_16  segment_load_conservation_795  1
    load_0_2_16  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_497  -20
    arc_0_2_17  connected_order_arc_498  -14
    arc_0_2_17  out_degree_791  1
    arc_0_2_17  in_degree_838  1
    arc_0_2_17  original_T_including_depot_unload_871  1.4829753176244692e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_497  1
    load_0_2_17  segment_load_conservation_795  1
    load_0_2_17  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_499  -20
    arc_0_2_18  connected_order_arc_500  -14
    arc_0_2_18  out_degree_791  1
    arc_0_2_18  in_degree_844  1
    arc_0_2_18  original_T_including_depot_unload_871  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_499  1
    load_0_2_18  segment_load_conservation_795  1
    load_0_2_18  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_501  -20
    arc_0_2_19  connected_order_arc_502  -14
    arc_0_2_19  out_degree_791  1
    arc_0_2_19  in_degree_850  1
    arc_0_2_19  original_T_including_depot_unload_871  1.2798962893775918e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_501  1
    load_0_2_19  segment_load_conservation_795  1
    load_0_2_19  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_503  -20
    arc_0_2_20  connected_order_arc_504  -14
    arc_0_2_20  out_degree_791  1
    arc_0_2_20  in_degree_856  1
    arc_0_2_20  original_T_including_depot_unload_871  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_503  1
    load_0_2_20  segment_load_conservation_795  1
    load_0_2_20  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_505  -20
    arc_0_2_21  connected_order_arc_506  -14
    arc_0_2_21  out_degree_791  1
    arc_0_2_21  in_degree_862  1
    arc_0_2_21  original_T_including_depot_unload_871  1.3874440214926751e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_505  1
    load_0_2_21  segment_load_conservation_795  1
    load_0_2_21  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_507  -20
    arc_0_3_0  depot_return_or_bypass_783  1
    arc_0_3_0  out_degree_798  1
    arc_0_3_0  original_T_including_depot_unload_871  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_507  1
    load_0_3_0  segment_load_conservation_802  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_508  -20
    arc_0_3_1  connected_order_arc_509  -14
    arc_0_3_1  in_degree_785  1
    arc_0_3_1  out_degree_798  1
    arc_0_3_1  original_T_including_depot_unload_871  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_508  1
    load_0_3_1  segment_load_conservation_788  -1
    load_0_3_1  segment_prefix_lb_789  1
    load_0_3_1  segment_prefix_ub_790  1
    load_0_3_1  segment_load_conservation_802  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_510  -20
    arc_0_3_2  connected_order_arc_511  -14
    arc_0_3_2  in_degree_792  1
    arc_0_3_2  out_degree_798  1
    arc_0_3_2  original_T_including_depot_unload_871  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_510  1
    load_0_3_2  segment_load_conservation_795  -1
    load_0_3_2  segment_prefix_lb_796  1
    load_0_3_2  segment_prefix_ub_797  1
    load_0_3_2  segment_load_conservation_802  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_512  -20
    arc_0_3_4  connected_order_arc_513  -14
    arc_0_3_4  out_degree_798  1
    arc_0_3_4  in_degree_806  1
    arc_0_3_4  original_T_including_depot_unload_871  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_512  1
    load_0_3_4  segment_load_conservation_802  1
    load_0_3_4  segment_load_conservation_809  -1
    load_0_3_4  segment_prefix_lb_810  1
    load_0_3_4  segment_prefix_ub_811  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_514  -20
    arc_0_3_5  connected_order_arc_515  -14
    arc_0_3_5  out_degree_798  1
    arc_0_3_5  in_degree_813  1
    arc_0_3_5  original_T_including_depot_unload_871  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_514  1
    load_0_3_5  segment_load_conservation_802  1
    load_0_3_5  segment_load_conservation_816  -1
    load_0_3_5  segment_prefix_lb_817  1
    load_0_3_5  segment_prefix_ub_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_516  -20
    arc_0_3_14  connected_order_arc_517  -14
    arc_0_3_14  out_degree_798  1
    arc_0_3_14  in_degree_820  1
    arc_0_3_14  original_T_including_depot_unload_871  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_516  1
    load_0_3_14  segment_load_conservation_802  1
    load_0_3_14  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_518  -20
    arc_0_3_15  connected_order_arc_519  -14
    arc_0_3_15  out_degree_798  1
    arc_0_3_15  in_degree_826  1
    arc_0_3_15  original_T_including_depot_unload_871  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_518  1
    load_0_3_15  segment_load_conservation_802  1
    load_0_3_15  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_520  -20
    arc_0_3_16  connected_order_arc_521  -14
    arc_0_3_16  out_degree_798  1
    arc_0_3_16  in_degree_832  1
    arc_0_3_16  original_T_including_depot_unload_871  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_520  1
    load_0_3_16  segment_load_conservation_802  1
    load_0_3_16  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_522  -20
    arc_0_3_17  connected_order_arc_523  -14
    arc_0_3_17  out_degree_798  1
    arc_0_3_17  in_degree_838  1
    arc_0_3_17  original_T_including_depot_unload_871  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_522  1
    load_0_3_17  segment_load_conservation_802  1
    load_0_3_17  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_524  -20
    arc_0_3_18  connected_order_arc_525  -14
    arc_0_3_18  out_degree_798  1
    arc_0_3_18  in_degree_844  1
    arc_0_3_18  original_T_including_depot_unload_871  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_524  1
    load_0_3_18  segment_load_conservation_802  1
    load_0_3_18  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_526  -20
    arc_0_3_19  connected_order_arc_527  -14
    arc_0_3_19  out_degree_798  1
    arc_0_3_19  in_degree_850  1
    arc_0_3_19  original_T_including_depot_unload_871  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_526  1
    load_0_3_19  segment_load_conservation_802  1
    load_0_3_19  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_528  -20
    arc_0_3_20  connected_order_arc_529  -14
    arc_0_3_20  out_degree_798  1
    arc_0_3_20  in_degree_856  1
    arc_0_3_20  original_T_including_depot_unload_871  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_528  1
    load_0_3_20  segment_load_conservation_802  1
    load_0_3_20  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_530  -20
    arc_0_3_21  connected_order_arc_531  -14
    arc_0_3_21  out_degree_798  1
    arc_0_3_21  in_degree_862  1
    arc_0_3_21  original_T_including_depot_unload_871  1.4252778892498145e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_530  1
    load_0_3_21  segment_load_conservation_802  1
    load_0_3_21  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_532  -20
    arc_0_4_0  depot_return_or_bypass_783  1
    arc_0_4_0  out_degree_805  1
    arc_0_4_0  original_T_including_depot_unload_871  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_532  1
    load_0_4_0  segment_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_533  -20
    arc_0_4_1  connected_order_arc_534  -14
    arc_0_4_1  in_degree_785  1
    arc_0_4_1  out_degree_805  1
    arc_0_4_1  original_T_including_depot_unload_871  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_533  1
    load_0_4_1  segment_load_conservation_788  -1
    load_0_4_1  segment_prefix_lb_789  1
    load_0_4_1  segment_prefix_ub_790  1
    load_0_4_1  segment_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_535  -20
    arc_0_4_2  connected_order_arc_536  -14
    arc_0_4_2  in_degree_792  1
    arc_0_4_2  out_degree_805  1
    arc_0_4_2  original_T_including_depot_unload_871  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_535  1
    load_0_4_2  segment_load_conservation_795  -1
    load_0_4_2  segment_prefix_lb_796  1
    load_0_4_2  segment_prefix_ub_797  1
    load_0_4_2  segment_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_537  -20
    arc_0_4_3  connected_order_arc_538  -14
    arc_0_4_3  in_degree_799  1
    arc_0_4_3  out_degree_805  1
    arc_0_4_3  original_T_including_depot_unload_871  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_537  1
    load_0_4_3  segment_load_conservation_802  -1
    load_0_4_3  segment_prefix_lb_803  1
    load_0_4_3  segment_prefix_ub_804  1
    load_0_4_3  segment_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_539  -20
    arc_0_4_5  connected_order_arc_540  -14
    arc_0_4_5  out_degree_805  1
    arc_0_4_5  in_degree_813  1
    arc_0_4_5  original_T_including_depot_unload_871  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_539  1
    load_0_4_5  segment_load_conservation_809  1
    load_0_4_5  segment_load_conservation_816  -1
    load_0_4_5  segment_prefix_lb_817  1
    load_0_4_5  segment_prefix_ub_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_541  -20
    arc_0_4_14  connected_order_arc_542  -14
    arc_0_4_14  out_degree_805  1
    arc_0_4_14  in_degree_820  1
    arc_0_4_14  original_T_including_depot_unload_871  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_541  1
    load_0_4_14  segment_load_conservation_809  1
    load_0_4_14  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_543  -20
    arc_0_4_15  connected_order_arc_544  -14
    arc_0_4_15  out_degree_805  1
    arc_0_4_15  in_degree_826  1
    arc_0_4_15  original_T_including_depot_unload_871  1.5053327747786273e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_543  1
    load_0_4_15  segment_load_conservation_809  1
    load_0_4_15  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_545  -20
    arc_0_4_16  connected_order_arc_546  -14
    arc_0_4_16  out_degree_805  1
    arc_0_4_16  in_degree_832  1
    arc_0_4_16  original_T_including_depot_unload_871  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_545  1
    load_0_4_16  segment_load_conservation_809  1
    load_0_4_16  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_547  -20
    arc_0_4_17  connected_order_arc_548  -14
    arc_0_4_17  out_degree_805  1
    arc_0_4_17  in_degree_838  1
    arc_0_4_17  original_T_including_depot_unload_871  1.6982456083268751e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_547  1
    load_0_4_17  segment_load_conservation_809  1
    load_0_4_17  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_549  -20
    arc_0_4_18  connected_order_arc_550  -14
    arc_0_4_18  out_degree_805  1
    arc_0_4_18  in_degree_844  1
    arc_0_4_18  original_T_including_depot_unload_871  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_549  1
    load_0_4_18  segment_load_conservation_809  1
    load_0_4_18  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_551  -20
    arc_0_4_19  connected_order_arc_552  -14
    arc_0_4_19  out_degree_805  1
    arc_0_4_19  in_degree_850  1
    arc_0_4_19  original_T_including_depot_unload_871  1.5437191441012344e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_551  1
    load_0_4_19  segment_load_conservation_809  1
    load_0_4_19  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_553  -20
    arc_0_4_20  connected_order_arc_554  -14
    arc_0_4_20  out_degree_805  1
    arc_0_4_20  in_degree_856  1
    arc_0_4_20  original_T_including_depot_unload_871  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_553  1
    load_0_4_20  segment_load_conservation_809  1
    load_0_4_20  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_555  -20
    arc_0_4_21  connected_order_arc_556  -14
    arc_0_4_21  out_degree_805  1
    arc_0_4_21  in_degree_862  1
    arc_0_4_21  original_T_including_depot_unload_871  1.6744862285014353e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_555  1
    load_0_4_21  segment_load_conservation_809  1
    load_0_4_21  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_557  -20
    arc_0_5_0  depot_return_or_bypass_783  1
    arc_0_5_0  out_degree_812  1
    arc_0_5_0  original_T_including_depot_unload_871  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_557  1
    load_0_5_0  segment_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_558  -20
    arc_0_5_1  connected_order_arc_559  -14
    arc_0_5_1  in_degree_785  1
    arc_0_5_1  out_degree_812  1
    arc_0_5_1  original_T_including_depot_unload_871  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_558  1
    load_0_5_1  segment_load_conservation_788  -1
    load_0_5_1  segment_prefix_lb_789  1
    load_0_5_1  segment_prefix_ub_790  1
    load_0_5_1  segment_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_560  -20
    arc_0_5_2  connected_order_arc_561  -14
    arc_0_5_2  in_degree_792  1
    arc_0_5_2  out_degree_812  1
    arc_0_5_2  original_T_including_depot_unload_871  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_560  1
    load_0_5_2  segment_load_conservation_795  -1
    load_0_5_2  segment_prefix_lb_796  1
    load_0_5_2  segment_prefix_ub_797  1
    load_0_5_2  segment_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_562  -20
    arc_0_5_3  connected_order_arc_563  -14
    arc_0_5_3  in_degree_799  1
    arc_0_5_3  out_degree_812  1
    arc_0_5_3  original_T_including_depot_unload_871  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_562  1
    load_0_5_3  segment_load_conservation_802  -1
    load_0_5_3  segment_prefix_lb_803  1
    load_0_5_3  segment_prefix_ub_804  1
    load_0_5_3  segment_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_564  -20
    arc_0_5_4  connected_order_arc_565  -14
    arc_0_5_4  in_degree_806  1
    arc_0_5_4  out_degree_812  1
    arc_0_5_4  original_T_including_depot_unload_871  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_564  1
    load_0_5_4  segment_load_conservation_809  -1
    load_0_5_4  segment_prefix_lb_810  1
    load_0_5_4  segment_prefix_ub_811  1
    load_0_5_4  segment_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_566  -20
    arc_0_5_14  connected_order_arc_567  -14
    arc_0_5_14  out_degree_812  1
    arc_0_5_14  in_degree_820  1
    arc_0_5_14  original_T_including_depot_unload_871  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_566  1
    load_0_5_14  segment_load_conservation_816  1
    load_0_5_14  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_568  -20
    arc_0_5_15  connected_order_arc_569  -14
    arc_0_5_15  out_degree_812  1
    arc_0_5_15  in_degree_826  1
    arc_0_5_15  original_T_including_depot_unload_871  1.0250717569202773e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_568  1
    load_0_5_15  segment_load_conservation_816  1
    load_0_5_15  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_570  -20
    arc_0_5_16  connected_order_arc_571  -14
    arc_0_5_16  out_degree_812  1
    arc_0_5_16  in_degree_832  1
    arc_0_5_16  original_T_including_depot_unload_871  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_570  1
    load_0_5_16  segment_load_conservation_816  1
    load_0_5_16  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_572  -20
    arc_0_5_17  connected_order_arc_573  -14
    arc_0_5_17  out_degree_812  1
    arc_0_5_17  in_degree_838  1
    arc_0_5_17  original_T_including_depot_unload_871  1.2492199513695298e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_572  1
    load_0_5_17  segment_load_conservation_816  1
    load_0_5_17  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_574  -20
    arc_0_5_18  connected_order_arc_575  -14
    arc_0_5_18  out_degree_812  1
    arc_0_5_18  in_degree_844  1
    arc_0_5_18  original_T_including_depot_unload_871  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_574  1
    load_0_5_18  segment_load_conservation_816  1
    load_0_5_18  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_576  -20
    arc_0_5_19  connected_order_arc_577  -14
    arc_0_5_19  out_degree_812  1
    arc_0_5_19  in_degree_850  1
    arc_0_5_19  original_T_including_depot_unload_871  1.1724800521319269e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_576  1
    load_0_5_19  segment_load_conservation_816  1
    load_0_5_19  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_578  -20
    arc_0_5_20  connected_order_arc_579  -14
    arc_0_5_20  out_degree_812  1
    arc_0_5_20  in_degree_856  1
    arc_0_5_20  original_T_including_depot_unload_871  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_578  1
    load_0_5_20  segment_load_conservation_816  1
    load_0_5_20  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_580  -20
    arc_0_5_21  connected_order_arc_581  -14
    arc_0_5_21  out_degree_812  1
    arc_0_5_21  in_degree_862  1
    arc_0_5_21  original_T_including_depot_unload_871  1.3294477435531232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_580  1
    load_0_5_21  segment_load_conservation_816  1
    load_0_5_21  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_582  -20
    arc_0_14_0  depot_return_or_bypass_783  1
    arc_0_14_0  out_degree_819  1
    arc_0_14_0  original_T_including_depot_unload_871  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_582  1
    load_0_14_0  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_583  -20
    arc_0_14_1  connected_order_arc_584  -14
    arc_0_14_1  in_degree_785  1
    arc_0_14_1  out_degree_819  1
    arc_0_14_1  original_T_including_depot_unload_871  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_583  1
    load_0_14_1  segment_load_conservation_788  -1
    load_0_14_1  segment_prefix_lb_789  1
    load_0_14_1  segment_prefix_ub_790  1
    load_0_14_1  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_585  -20
    arc_0_14_2  connected_order_arc_586  -14
    arc_0_14_2  in_degree_792  1
    arc_0_14_2  out_degree_819  1
    arc_0_14_2  original_T_including_depot_unload_871  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_585  1
    load_0_14_2  segment_load_conservation_795  -1
    load_0_14_2  segment_prefix_lb_796  1
    load_0_14_2  segment_prefix_ub_797  1
    load_0_14_2  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_587  -20
    arc_0_14_3  connected_order_arc_588  -14
    arc_0_14_3  in_degree_799  1
    arc_0_14_3  out_degree_819  1
    arc_0_14_3  original_T_including_depot_unload_871  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_587  1
    load_0_14_3  segment_load_conservation_802  -1
    load_0_14_3  segment_prefix_lb_803  1
    load_0_14_3  segment_prefix_ub_804  1
    load_0_14_3  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_589  -20
    arc_0_14_4  connected_order_arc_590  -14
    arc_0_14_4  in_degree_806  1
    arc_0_14_4  out_degree_819  1
    arc_0_14_4  original_T_including_depot_unload_871  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_589  1
    load_0_14_4  segment_load_conservation_809  -1
    load_0_14_4  segment_prefix_lb_810  1
    load_0_14_4  segment_prefix_ub_811  1
    load_0_14_4  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_591  -20
    arc_0_14_5  connected_order_arc_592  -14
    arc_0_14_5  in_degree_813  1
    arc_0_14_5  out_degree_819  1
    arc_0_14_5  original_T_including_depot_unload_871  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_591  1
    load_0_14_5  segment_load_conservation_816  -1
    load_0_14_5  segment_prefix_lb_817  1
    load_0_14_5  segment_prefix_ub_818  1
    load_0_14_5  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_593  -20
    arc_0_14_15  connected_order_arc_594  -14
    arc_0_14_15  out_degree_819  1
    arc_0_14_15  in_degree_826  1
    arc_0_14_15  original_T_including_depot_unload_871  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_593  1
    load_0_14_15  free_load_conservation_824  1
    load_0_14_15  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_595  -20
    arc_0_14_16  connected_order_arc_596  -14
    arc_0_14_16  out_degree_819  1
    arc_0_14_16  in_degree_832  1
    arc_0_14_16  original_T_including_depot_unload_871  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_595  1
    load_0_14_16  free_load_conservation_824  1
    load_0_14_16  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_597  -20
    arc_0_14_17  connected_order_arc_598  -14
    arc_0_14_17  out_degree_819  1
    arc_0_14_17  in_degree_838  1
    arc_0_14_17  original_T_including_depot_unload_871  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_597  1
    load_0_14_17  free_load_conservation_824  1
    load_0_14_17  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_599  -20
    arc_0_14_18  connected_order_arc_600  -14
    arc_0_14_18  out_degree_819  1
    arc_0_14_18  in_degree_844  1
    arc_0_14_18  original_T_including_depot_unload_871  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_599  1
    load_0_14_18  free_load_conservation_824  1
    load_0_14_18  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_601  -20
    arc_0_14_19  connected_order_arc_602  -14
    arc_0_14_19  out_degree_819  1
    arc_0_14_19  in_degree_850  1
    arc_0_14_19  original_T_including_depot_unload_871  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_601  1
    load_0_14_19  free_load_conservation_824  1
    load_0_14_19  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_603  -20
    arc_0_14_20  connected_order_arc_604  -14
    arc_0_14_20  out_degree_819  1
    arc_0_14_20  in_degree_856  1
    arc_0_14_20  original_T_including_depot_unload_871  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_603  1
    load_0_14_20  free_load_conservation_824  1
    load_0_14_20  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_21  arc_capacity_605  -20
    arc_0_14_21  connected_order_arc_606  -14
    arc_0_14_21  out_degree_819  1
    arc_0_14_21  in_degree_862  1
    arc_0_14_21  original_T_including_depot_unload_871  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_0_14_21  arc_capacity_605  1
    load_0_14_21  free_load_conservation_824  1
    load_0_14_21  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_607  -20
    arc_0_15_0  depot_return_or_bypass_783  1
    arc_0_15_0  out_degree_825  1
    arc_0_15_0  original_T_including_depot_unload_871  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_607  1
    load_0_15_0  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_608  -20
    arc_0_15_1  connected_order_arc_609  -14
    arc_0_15_1  in_degree_785  1
    arc_0_15_1  out_degree_825  1
    arc_0_15_1  original_T_including_depot_unload_871  1.0988088346747072e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_608  1
    load_0_15_1  segment_load_conservation_788  -1
    load_0_15_1  segment_prefix_lb_789  1
    load_0_15_1  segment_prefix_ub_790  1
    load_0_15_1  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_610  -20
    arc_0_15_2  connected_order_arc_611  -14
    arc_0_15_2  in_degree_792  1
    arc_0_15_2  out_degree_825  1
    arc_0_15_2  original_T_including_depot_unload_871  1.3293032990949939e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_610  1
    load_0_15_2  segment_load_conservation_795  -1
    load_0_15_2  segment_prefix_lb_796  1
    load_0_15_2  segment_prefix_ub_797  1
    load_0_15_2  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_612  -20
    arc_0_15_3  connected_order_arc_613  -14
    arc_0_15_3  in_degree_799  1
    arc_0_15_3  out_degree_825  1
    arc_0_15_3  original_T_including_depot_unload_871  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_612  1
    load_0_15_3  segment_load_conservation_802  -1
    load_0_15_3  segment_prefix_lb_803  1
    load_0_15_3  segment_prefix_ub_804  1
    load_0_15_3  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_614  -20
    arc_0_15_4  connected_order_arc_615  -14
    arc_0_15_4  in_degree_806  1
    arc_0_15_4  out_degree_825  1
    arc_0_15_4  original_T_including_depot_unload_871  1.5053327747786273e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_614  1
    load_0_15_4  segment_load_conservation_809  -1
    load_0_15_4  segment_prefix_lb_810  1
    load_0_15_4  segment_prefix_ub_811  1
    load_0_15_4  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_616  -20
    arc_0_15_5  connected_order_arc_617  -14
    arc_0_15_5  in_degree_813  1
    arc_0_15_5  out_degree_825  1
    arc_0_15_5  original_T_including_depot_unload_871  1.3070841601346692e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_616  1
    load_0_15_5  segment_load_conservation_816  -1
    load_0_15_5  segment_prefix_lb_817  1
    load_0_15_5  segment_prefix_ub_818  1
    load_0_15_5  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_618  -20
    arc_0_15_14  connected_order_arc_619  -14
    arc_0_15_14  in_degree_820  1
    arc_0_15_14  out_degree_825  1
    arc_0_15_14  original_T_including_depot_unload_871  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_618  1
    load_0_15_14  free_load_conservation_824  -1
    load_0_15_14  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_620  -20
    arc_0_15_16  connected_order_arc_621  -14
    arc_0_15_16  out_degree_825  1
    arc_0_15_16  in_degree_832  1
    arc_0_15_16  original_T_including_depot_unload_871  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_620  1
    load_0_15_16  free_load_conservation_830  1
    load_0_15_16  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_622  -20
    arc_0_15_17  connected_order_arc_623  -14
    arc_0_15_17  out_degree_825  1
    arc_0_15_17  in_degree_838  1
    arc_0_15_17  original_T_including_depot_unload_871  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_622  1
    load_0_15_17  free_load_conservation_830  1
    load_0_15_17  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_624  -20
    arc_0_15_18  connected_order_arc_625  -14
    arc_0_15_18  out_degree_825  1
    arc_0_15_18  in_degree_844  1
    arc_0_15_18  original_T_including_depot_unload_871  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_624  1
    load_0_15_18  free_load_conservation_830  1
    load_0_15_18  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_626  -20
    arc_0_15_19  connected_order_arc_627  -14
    arc_0_15_19  out_degree_825  1
    arc_0_15_19  in_degree_850  1
    arc_0_15_19  original_T_including_depot_unload_871  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_626  1
    load_0_15_19  free_load_conservation_830  1
    load_0_15_19  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_628  -20
    arc_0_15_20  connected_order_arc_629  -14
    arc_0_15_20  out_degree_825  1
    arc_0_15_20  in_degree_856  1
    arc_0_15_20  original_T_including_depot_unload_871  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_628  1
    load_0_15_20  free_load_conservation_830  1
    load_0_15_20  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_630  -20
    arc_0_15_21  connected_order_arc_631  -14
    arc_0_15_21  out_degree_825  1
    arc_0_15_21  in_degree_862  1
    arc_0_15_21  original_T_including_depot_unload_871  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_630  1
    load_0_15_21  free_load_conservation_830  1
    load_0_15_21  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_632  -20
    arc_0_16_0  depot_return_or_bypass_783  1
    arc_0_16_0  out_degree_831  1
    arc_0_16_0  original_T_including_depot_unload_871  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_632  1
    load_0_16_0  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_633  -20
    arc_0_16_1  connected_order_arc_634  -14
    arc_0_16_1  in_degree_785  1
    arc_0_16_1  out_degree_831  1
    arc_0_16_1  original_T_including_depot_unload_871  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_633  1
    load_0_16_1  segment_load_conservation_788  -1
    load_0_16_1  segment_prefix_lb_789  1
    load_0_16_1  segment_prefix_ub_790  1
    load_0_16_1  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_635  -20
    arc_0_16_2  connected_order_arc_636  -14
    arc_0_16_2  in_degree_792  1
    arc_0_16_2  out_degree_831  1
    arc_0_16_2  original_T_including_depot_unload_871  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_635  1
    load_0_16_2  segment_load_conservation_795  -1
    load_0_16_2  segment_prefix_lb_796  1
    load_0_16_2  segment_prefix_ub_797  1
    load_0_16_2  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_637  -20
    arc_0_16_3  connected_order_arc_638  -14
    arc_0_16_3  in_degree_799  1
    arc_0_16_3  out_degree_831  1
    arc_0_16_3  original_T_including_depot_unload_871  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_637  1
    load_0_16_3  segment_load_conservation_802  -1
    load_0_16_3  segment_prefix_lb_803  1
    load_0_16_3  segment_prefix_ub_804  1
    load_0_16_3  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_639  -20
    arc_0_16_4  connected_order_arc_640  -14
    arc_0_16_4  in_degree_806  1
    arc_0_16_4  out_degree_831  1
    arc_0_16_4  original_T_including_depot_unload_871  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_639  1
    load_0_16_4  segment_load_conservation_809  -1
    load_0_16_4  segment_prefix_lb_810  1
    load_0_16_4  segment_prefix_ub_811  1
    load_0_16_4  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_641  -20
    arc_0_16_5  connected_order_arc_642  -14
    arc_0_16_5  in_degree_813  1
    arc_0_16_5  out_degree_831  1
    arc_0_16_5  original_T_including_depot_unload_871  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_641  1
    load_0_16_5  segment_load_conservation_816  -1
    load_0_16_5  segment_prefix_lb_817  1
    load_0_16_5  segment_prefix_ub_818  1
    load_0_16_5  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_643  -20
    arc_0_16_14  connected_order_arc_644  -14
    arc_0_16_14  in_degree_820  1
    arc_0_16_14  out_degree_831  1
    arc_0_16_14  original_T_including_depot_unload_871  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_643  1
    load_0_16_14  free_load_conservation_824  -1
    load_0_16_14  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_645  -20
    arc_0_16_15  connected_order_arc_646  -14
    arc_0_16_15  in_degree_826  1
    arc_0_16_15  out_degree_831  1
    arc_0_16_15  original_T_including_depot_unload_871  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_645  1
    load_0_16_15  free_load_conservation_830  -1
    load_0_16_15  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_647  -20
    arc_0_16_17  connected_order_arc_648  -14
    arc_0_16_17  out_degree_831  1
    arc_0_16_17  in_degree_838  1
    arc_0_16_17  original_T_including_depot_unload_871  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_647  1
    load_0_16_17  free_load_conservation_836  1
    load_0_16_17  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_649  -20
    arc_0_16_18  connected_order_arc_650  -14
    arc_0_16_18  out_degree_831  1
    arc_0_16_18  in_degree_844  1
    arc_0_16_18  original_T_including_depot_unload_871  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_649  1
    load_0_16_18  free_load_conservation_836  1
    load_0_16_18  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_651  -20
    arc_0_16_19  connected_order_arc_652  -14
    arc_0_16_19  out_degree_831  1
    arc_0_16_19  in_degree_850  1
    arc_0_16_19  original_T_including_depot_unload_871  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_651  1
    load_0_16_19  free_load_conservation_836  1
    load_0_16_19  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_653  -20
    arc_0_16_20  connected_order_arc_654  -14
    arc_0_16_20  out_degree_831  1
    arc_0_16_20  in_degree_856  1
    arc_0_16_20  original_T_including_depot_unload_871  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_653  1
    load_0_16_20  free_load_conservation_836  1
    load_0_16_20  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_655  -20
    arc_0_16_21  connected_order_arc_656  -14
    arc_0_16_21  out_degree_831  1
    arc_0_16_21  in_degree_862  1
    arc_0_16_21  original_T_including_depot_unload_871  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_655  1
    load_0_16_21  free_load_conservation_836  1
    load_0_16_21  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_657  -20
    arc_0_17_0  depot_return_or_bypass_783  1
    arc_0_17_0  out_degree_837  1
    arc_0_17_0  original_T_including_depot_unload_871  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_657  1
    load_0_17_0  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_658  -20
    arc_0_17_1  connected_order_arc_659  -14
    arc_0_17_1  in_degree_785  1
    arc_0_17_1  out_degree_837  1
    arc_0_17_1  original_T_including_depot_unload_871  1.2336637947519732e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_658  1
    load_0_17_1  segment_load_conservation_788  -1
    load_0_17_1  segment_prefix_lb_789  1
    load_0_17_1  segment_prefix_ub_790  1
    load_0_17_1  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_660  -20
    arc_0_17_2  connected_order_arc_661  -14
    arc_0_17_2  in_degree_792  1
    arc_0_17_2  out_degree_837  1
    arc_0_17_2  original_T_including_depot_unload_871  1.4829753176244692e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_660  1
    load_0_17_2  segment_load_conservation_795  -1
    load_0_17_2  segment_prefix_lb_796  1
    load_0_17_2  segment_prefix_ub_797  1
    load_0_17_2  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_662  -20
    arc_0_17_3  connected_order_arc_663  -14
    arc_0_17_3  in_degree_799  1
    arc_0_17_3  out_degree_837  1
    arc_0_17_3  original_T_including_depot_unload_871  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_662  1
    load_0_17_3  segment_load_conservation_802  -1
    load_0_17_3  segment_prefix_lb_803  1
    load_0_17_3  segment_prefix_ub_804  1
    load_0_17_3  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_664  -20
    arc_0_17_4  connected_order_arc_665  -14
    arc_0_17_4  in_degree_806  1
    arc_0_17_4  out_degree_837  1
    arc_0_17_4  original_T_including_depot_unload_871  1.6982456083268751e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_664  1
    load_0_17_4  segment_load_conservation_809  -1
    load_0_17_4  segment_prefix_lb_810  1
    load_0_17_4  segment_prefix_ub_811  1
    load_0_17_4  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_666  -20
    arc_0_17_5  connected_order_arc_667  -14
    arc_0_17_5  in_degree_813  1
    arc_0_17_5  out_degree_837  1
    arc_0_17_5  original_T_including_depot_unload_871  1.5230377993795889e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_666  1
    load_0_17_5  segment_load_conservation_816  -1
    load_0_17_5  segment_prefix_lb_817  1
    load_0_17_5  segment_prefix_ub_818  1
    load_0_17_5  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_668  -20
    arc_0_17_14  connected_order_arc_669  -14
    arc_0_17_14  in_degree_820  1
    arc_0_17_14  out_degree_837  1
    arc_0_17_14  original_T_including_depot_unload_871  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_668  1
    load_0_17_14  free_load_conservation_824  -1
    load_0_17_14  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_670  -20
    arc_0_17_15  connected_order_arc_671  -14
    arc_0_17_15  in_degree_826  1
    arc_0_17_15  out_degree_837  1
    arc_0_17_15  original_T_including_depot_unload_871  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_670  1
    load_0_17_15  free_load_conservation_830  -1
    load_0_17_15  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_672  -20
    arc_0_17_16  connected_order_arc_673  -14
    arc_0_17_16  in_degree_832  1
    arc_0_17_16  out_degree_837  1
    arc_0_17_16  original_T_including_depot_unload_871  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_672  1
    load_0_17_16  free_load_conservation_836  -1
    load_0_17_16  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_674  -20
    arc_0_17_18  connected_order_arc_675  -14
    arc_0_17_18  out_degree_837  1
    arc_0_17_18  in_degree_844  1
    arc_0_17_18  original_T_including_depot_unload_871  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_674  1
    load_0_17_18  free_load_conservation_842  1
    load_0_17_18  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_676  -20
    arc_0_17_19  connected_order_arc_677  -14
    arc_0_17_19  out_degree_837  1
    arc_0_17_19  in_degree_850  1
    arc_0_17_19  original_T_including_depot_unload_871  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_676  1
    load_0_17_19  free_load_conservation_842  1
    load_0_17_19  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_678  -20
    arc_0_17_20  connected_order_arc_679  -14
    arc_0_17_20  out_degree_837  1
    arc_0_17_20  in_degree_856  1
    arc_0_17_20  original_T_including_depot_unload_871  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_678  1
    load_0_17_20  free_load_conservation_842  1
    load_0_17_20  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_680  -20
    arc_0_17_21  connected_order_arc_681  -14
    arc_0_17_21  out_degree_837  1
    arc_0_17_21  in_degree_862  1
    arc_0_17_21  original_T_including_depot_unload_871  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_680  1
    load_0_17_21  free_load_conservation_842  1
    load_0_17_21  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_682  -20
    arc_0_18_0  depot_return_or_bypass_783  1
    arc_0_18_0  out_degree_843  1
    arc_0_18_0  original_T_including_depot_unload_871  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_682  1
    load_0_18_0  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_683  -20
    arc_0_18_1  connected_order_arc_684  -14
    arc_0_18_1  in_degree_785  1
    arc_0_18_1  out_degree_843  1
    arc_0_18_1  original_T_including_depot_unload_871  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_683  1
    load_0_18_1  segment_load_conservation_788  -1
    load_0_18_1  segment_prefix_lb_789  1
    load_0_18_1  segment_prefix_ub_790  1
    load_0_18_1  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_685  -20
    arc_0_18_2  connected_order_arc_686  -14
    arc_0_18_2  in_degree_792  1
    arc_0_18_2  out_degree_843  1
    arc_0_18_2  original_T_including_depot_unload_871  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_685  1
    load_0_18_2  segment_load_conservation_795  -1
    load_0_18_2  segment_prefix_lb_796  1
    load_0_18_2  segment_prefix_ub_797  1
    load_0_18_2  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_687  -20
    arc_0_18_3  connected_order_arc_688  -14
    arc_0_18_3  in_degree_799  1
    arc_0_18_3  out_degree_843  1
    arc_0_18_3  original_T_including_depot_unload_871  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_687  1
    load_0_18_3  segment_load_conservation_802  -1
    load_0_18_3  segment_prefix_lb_803  1
    load_0_18_3  segment_prefix_ub_804  1
    load_0_18_3  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_689  -20
    arc_0_18_4  connected_order_arc_690  -14
    arc_0_18_4  in_degree_806  1
    arc_0_18_4  out_degree_843  1
    arc_0_18_4  original_T_including_depot_unload_871  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_689  1
    load_0_18_4  segment_load_conservation_809  -1
    load_0_18_4  segment_prefix_lb_810  1
    load_0_18_4  segment_prefix_ub_811  1
    load_0_18_4  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_691  -20
    arc_0_18_5  connected_order_arc_692  -14
    arc_0_18_5  in_degree_813  1
    arc_0_18_5  out_degree_843  1
    arc_0_18_5  original_T_including_depot_unload_871  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_691  1
    load_0_18_5  segment_load_conservation_816  -1
    load_0_18_5  segment_prefix_lb_817  1
    load_0_18_5  segment_prefix_ub_818  1
    load_0_18_5  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_693  -20
    arc_0_18_14  connected_order_arc_694  -14
    arc_0_18_14  in_degree_820  1
    arc_0_18_14  out_degree_843  1
    arc_0_18_14  original_T_including_depot_unload_871  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_693  1
    load_0_18_14  free_load_conservation_824  -1
    load_0_18_14  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_695  -20
    arc_0_18_15  connected_order_arc_696  -14
    arc_0_18_15  in_degree_826  1
    arc_0_18_15  out_degree_843  1
    arc_0_18_15  original_T_including_depot_unload_871  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_695  1
    load_0_18_15  free_load_conservation_830  -1
    load_0_18_15  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_697  -20
    arc_0_18_16  connected_order_arc_698  -14
    arc_0_18_16  in_degree_832  1
    arc_0_18_16  out_degree_843  1
    arc_0_18_16  original_T_including_depot_unload_871  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_697  1
    load_0_18_16  free_load_conservation_836  -1
    load_0_18_16  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_699  -20
    arc_0_18_17  connected_order_arc_700  -14
    arc_0_18_17  in_degree_838  1
    arc_0_18_17  out_degree_843  1
    arc_0_18_17  original_T_including_depot_unload_871  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_699  1
    load_0_18_17  free_load_conservation_842  -1
    load_0_18_17  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_701  -20
    arc_0_18_19  connected_order_arc_702  -14
    arc_0_18_19  out_degree_843  1
    arc_0_18_19  in_degree_850  1
    arc_0_18_19  original_T_including_depot_unload_871  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_701  1
    load_0_18_19  free_load_conservation_848  1
    load_0_18_19  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_703  -20
    arc_0_18_20  connected_order_arc_704  -14
    arc_0_18_20  out_degree_843  1
    arc_0_18_20  in_degree_856  1
    arc_0_18_20  original_T_including_depot_unload_871  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_703  1
    load_0_18_20  free_load_conservation_848  1
    load_0_18_20  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_705  -20
    arc_0_18_21  connected_order_arc_706  -14
    arc_0_18_21  out_degree_843  1
    arc_0_18_21  in_degree_862  1
    arc_0_18_21  original_T_including_depot_unload_871  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_705  1
    load_0_18_21  free_load_conservation_848  1
    load_0_18_21  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_707  -20
    arc_0_19_0  depot_return_or_bypass_783  1
    arc_0_19_0  out_degree_849  1
    arc_0_19_0  original_T_including_depot_unload_871  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_707  1
    load_0_19_0  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_708  -20
    arc_0_19_1  connected_order_arc_709  -14
    arc_0_19_1  in_degree_785  1
    arc_0_19_1  out_degree_849  1
    arc_0_19_1  original_T_including_depot_unload_871  1.0170488276971105e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_708  1
    load_0_19_1  segment_load_conservation_788  -1
    load_0_19_1  segment_prefix_lb_789  1
    load_0_19_1  segment_prefix_ub_790  1
    load_0_19_1  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_710  -20
    arc_0_19_2  connected_order_arc_711  -14
    arc_0_19_2  in_degree_792  1
    arc_0_19_2  out_degree_849  1
    arc_0_19_2  original_T_including_depot_unload_871  1.2798962893775918e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_710  1
    load_0_19_2  segment_load_conservation_795  -1
    load_0_19_2  segment_prefix_lb_796  1
    load_0_19_2  segment_prefix_ub_797  1
    load_0_19_2  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_712  -20
    arc_0_19_3  connected_order_arc_713  -14
    arc_0_19_3  in_degree_799  1
    arc_0_19_3  out_degree_849  1
    arc_0_19_3  original_T_including_depot_unload_871  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_712  1
    load_0_19_3  segment_load_conservation_802  -1
    load_0_19_3  segment_prefix_lb_803  1
    load_0_19_3  segment_prefix_ub_804  1
    load_0_19_3  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_714  -20
    arc_0_19_4  connected_order_arc_715  -14
    arc_0_19_4  in_degree_806  1
    arc_0_19_4  out_degree_849  1
    arc_0_19_4  original_T_including_depot_unload_871  1.5437191441012344e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_714  1
    load_0_19_4  segment_load_conservation_809  -1
    load_0_19_4  segment_prefix_lb_810  1
    load_0_19_4  segment_prefix_ub_811  1
    load_0_19_4  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_716  -20
    arc_0_19_5  connected_order_arc_717  -14
    arc_0_19_5  in_degree_813  1
    arc_0_19_5  out_degree_849  1
    arc_0_19_5  original_T_including_depot_unload_871  1.4171530684324468e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_716  1
    load_0_19_5  segment_load_conservation_816  -1
    load_0_19_5  segment_prefix_lb_817  1
    load_0_19_5  segment_prefix_ub_818  1
    load_0_19_5  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_718  -20
    arc_0_19_14  connected_order_arc_719  -14
    arc_0_19_14  in_degree_820  1
    arc_0_19_14  out_degree_849  1
    arc_0_19_14  original_T_including_depot_unload_871  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_718  1
    load_0_19_14  free_load_conservation_824  -1
    load_0_19_14  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_720  -20
    arc_0_19_15  connected_order_arc_721  -14
    arc_0_19_15  in_degree_826  1
    arc_0_19_15  out_degree_849  1
    arc_0_19_15  original_T_including_depot_unload_871  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_720  1
    load_0_19_15  free_load_conservation_830  -1
    load_0_19_15  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_722  -20
    arc_0_19_16  connected_order_arc_723  -14
    arc_0_19_16  in_degree_832  1
    arc_0_19_16  out_degree_849  1
    arc_0_19_16  original_T_including_depot_unload_871  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_722  1
    load_0_19_16  free_load_conservation_836  -1
    load_0_19_16  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_724  -20
    arc_0_19_17  connected_order_arc_725  -14
    arc_0_19_17  in_degree_838  1
    arc_0_19_17  out_degree_849  1
    arc_0_19_17  original_T_including_depot_unload_871  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_724  1
    load_0_19_17  free_load_conservation_842  -1
    load_0_19_17  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_726  -20
    arc_0_19_18  connected_order_arc_727  -14
    arc_0_19_18  in_degree_844  1
    arc_0_19_18  out_degree_849  1
    arc_0_19_18  original_T_including_depot_unload_871  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_726  1
    load_0_19_18  free_load_conservation_848  -1
    load_0_19_18  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_728  -20
    arc_0_19_20  connected_order_arc_729  -14
    arc_0_19_20  out_degree_849  1
    arc_0_19_20  in_degree_856  1
    arc_0_19_20  original_T_including_depot_unload_871  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_728  1
    load_0_19_20  free_load_conservation_854  1
    load_0_19_20  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_730  -20
    arc_0_19_21  connected_order_arc_731  -14
    arc_0_19_21  out_degree_849  1
    arc_0_19_21  in_degree_862  1
    arc_0_19_21  original_T_including_depot_unload_871  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_730  1
    load_0_19_21  free_load_conservation_854  1
    load_0_19_21  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_732  -20
    arc_0_20_0  depot_return_or_bypass_783  1
    arc_0_20_0  out_degree_855  1
    arc_0_20_0  original_T_including_depot_unload_871  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_732  1
    load_0_20_0  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_733  -20
    arc_0_20_1  connected_order_arc_734  -14
    arc_0_20_1  in_degree_785  1
    arc_0_20_1  out_degree_855  1
    arc_0_20_1  original_T_including_depot_unload_871  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_733  1
    load_0_20_1  segment_load_conservation_788  -1
    load_0_20_1  segment_prefix_lb_789  1
    load_0_20_1  segment_prefix_ub_790  1
    load_0_20_1  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_735  -20
    arc_0_20_2  connected_order_arc_736  -14
    arc_0_20_2  in_degree_792  1
    arc_0_20_2  out_degree_855  1
    arc_0_20_2  original_T_including_depot_unload_871  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_735  1
    load_0_20_2  segment_load_conservation_795  -1
    load_0_20_2  segment_prefix_lb_796  1
    load_0_20_2  segment_prefix_ub_797  1
    load_0_20_2  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_737  -20
    arc_0_20_3  connected_order_arc_738  -14
    arc_0_20_3  in_degree_799  1
    arc_0_20_3  out_degree_855  1
    arc_0_20_3  original_T_including_depot_unload_871  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_737  1
    load_0_20_3  segment_load_conservation_802  -1
    load_0_20_3  segment_prefix_lb_803  1
    load_0_20_3  segment_prefix_ub_804  1
    load_0_20_3  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_739  -20
    arc_0_20_4  connected_order_arc_740  -14
    arc_0_20_4  in_degree_806  1
    arc_0_20_4  out_degree_855  1
    arc_0_20_4  original_T_including_depot_unload_871  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_739  1
    load_0_20_4  segment_load_conservation_809  -1
    load_0_20_4  segment_prefix_lb_810  1
    load_0_20_4  segment_prefix_ub_811  1
    load_0_20_4  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_741  -20
    arc_0_20_5  connected_order_arc_742  -14
    arc_0_20_5  in_degree_813  1
    arc_0_20_5  out_degree_855  1
    arc_0_20_5  original_T_including_depot_unload_871  6.8881953094806647e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_741  1
    load_0_20_5  segment_load_conservation_816  -1
    load_0_20_5  segment_prefix_lb_817  1
    load_0_20_5  segment_prefix_ub_818  1
    load_0_20_5  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_743  -20
    arc_0_20_14  connected_order_arc_744  -14
    arc_0_20_14  in_degree_820  1
    arc_0_20_14  out_degree_855  1
    arc_0_20_14  original_T_including_depot_unload_871  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_743  1
    load_0_20_14  free_load_conservation_824  -1
    load_0_20_14  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_745  -20
    arc_0_20_15  connected_order_arc_746  -14
    arc_0_20_15  in_degree_826  1
    arc_0_20_15  out_degree_855  1
    arc_0_20_15  original_T_including_depot_unload_871  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_745  1
    load_0_20_15  free_load_conservation_830  -1
    load_0_20_15  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_747  -20
    arc_0_20_16  connected_order_arc_748  -14
    arc_0_20_16  in_degree_832  1
    arc_0_20_16  out_degree_855  1
    arc_0_20_16  original_T_including_depot_unload_871  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_747  1
    load_0_20_16  free_load_conservation_836  -1
    load_0_20_16  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_749  -20
    arc_0_20_17  connected_order_arc_750  -14
    arc_0_20_17  in_degree_838  1
    arc_0_20_17  out_degree_855  1
    arc_0_20_17  original_T_including_depot_unload_871  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_749  1
    load_0_20_17  free_load_conservation_842  -1
    load_0_20_17  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_751  -20
    arc_0_20_18  connected_order_arc_752  -14
    arc_0_20_18  in_degree_844  1
    arc_0_20_18  out_degree_855  1
    arc_0_20_18  original_T_including_depot_unload_871  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_751  1
    load_0_20_18  free_load_conservation_848  -1
    load_0_20_18  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_753  -20
    arc_0_20_19  connected_order_arc_754  -14
    arc_0_20_19  in_degree_850  1
    arc_0_20_19  out_degree_855  1
    arc_0_20_19  original_T_including_depot_unload_871  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_753  1
    load_0_20_19  free_load_conservation_854  -1
    load_0_20_19  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_755  -20
    arc_0_20_21  connected_order_arc_756  -14
    arc_0_20_21  out_degree_855  1
    arc_0_20_21  in_degree_862  1
    arc_0_20_21  original_T_including_depot_unload_871  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_755  1
    load_0_20_21  free_load_conservation_860  1
    load_0_20_21  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_757  -20
    arc_0_21_0  depot_return_or_bypass_783  1
    arc_0_21_0  out_degree_861  1
    arc_0_21_0  original_T_including_depot_unload_871  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_757  1
    load_0_21_0  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_758  -20
    arc_0_21_1  connected_order_arc_759  -14
    arc_0_21_1  in_degree_785  1
    arc_0_21_1  out_degree_861  1
    arc_0_21_1  original_T_including_depot_unload_871  1.1190931627527086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_758  1
    load_0_21_1  segment_load_conservation_788  -1
    load_0_21_1  segment_prefix_lb_789  1
    load_0_21_1  segment_prefix_ub_790  1
    load_0_21_1  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_760  -20
    arc_0_21_2  connected_order_arc_761  -14
    arc_0_21_2  in_degree_792  1
    arc_0_21_2  out_degree_861  1
    arc_0_21_2  original_T_including_depot_unload_871  1.3874440214926751e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_760  1
    load_0_21_2  segment_load_conservation_795  -1
    load_0_21_2  segment_prefix_lb_796  1
    load_0_21_2  segment_prefix_ub_797  1
    load_0_21_2  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_762  -20
    arc_0_21_3  connected_order_arc_763  -14
    arc_0_21_3  in_degree_799  1
    arc_0_21_3  out_degree_861  1
    arc_0_21_3  original_T_including_depot_unload_871  1.4252778892498145e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_762  1
    load_0_21_3  segment_load_conservation_802  -1
    load_0_21_3  segment_prefix_lb_803  1
    load_0_21_3  segment_prefix_ub_804  1
    load_0_21_3  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_764  -20
    arc_0_21_4  connected_order_arc_765  -14
    arc_0_21_4  in_degree_806  1
    arc_0_21_4  out_degree_861  1
    arc_0_21_4  original_T_including_depot_unload_871  1.6744862285014353e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_764  1
    load_0_21_4  segment_load_conservation_809  -1
    load_0_21_4  segment_prefix_lb_810  1
    load_0_21_4  segment_prefix_ub_811  1
    load_0_21_4  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_766  -20
    arc_0_21_5  connected_order_arc_767  -14
    arc_0_21_5  in_degree_813  1
    arc_0_21_5  out_degree_861  1
    arc_0_21_5  original_T_including_depot_unload_871  1.5657515083159024e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_766  1
    load_0_21_5  segment_load_conservation_816  -1
    load_0_21_5  segment_prefix_lb_817  1
    load_0_21_5  segment_prefix_ub_818  1
    load_0_21_5  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_14  arc_capacity_768  -20
    arc_0_21_14  connected_order_arc_769  -14
    arc_0_21_14  in_degree_820  1
    arc_0_21_14  out_degree_861  1
    arc_0_21_14  original_T_including_depot_unload_871  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_0_21_14  arc_capacity_768  1
    load_0_21_14  free_load_conservation_824  -1
    load_0_21_14  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_770  -20
    arc_0_21_15  connected_order_arc_771  -14
    arc_0_21_15  in_degree_826  1
    arc_0_21_15  out_degree_861  1
    arc_0_21_15  original_T_including_depot_unload_871  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_770  1
    load_0_21_15  free_load_conservation_830  -1
    load_0_21_15  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_772  -20
    arc_0_21_16  connected_order_arc_773  -14
    arc_0_21_16  in_degree_832  1
    arc_0_21_16  out_degree_861  1
    arc_0_21_16  original_T_including_depot_unload_871  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_772  1
    load_0_21_16  free_load_conservation_836  -1
    load_0_21_16  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_774  -20
    arc_0_21_17  connected_order_arc_775  -14
    arc_0_21_17  in_degree_838  1
    arc_0_21_17  out_degree_861  1
    arc_0_21_17  original_T_including_depot_unload_871  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_774  1
    load_0_21_17  free_load_conservation_842  -1
    load_0_21_17  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_776  -20
    arc_0_21_18  connected_order_arc_777  -14
    arc_0_21_18  in_degree_844  1
    arc_0_21_18  out_degree_861  1
    arc_0_21_18  original_T_including_depot_unload_871  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_776  1
    load_0_21_18  free_load_conservation_848  -1
    load_0_21_18  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_778  -20
    arc_0_21_19  connected_order_arc_779  -14
    arc_0_21_19  in_degree_850  1
    arc_0_21_19  out_degree_861  1
    arc_0_21_19  original_T_including_depot_unload_871  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_778  1
    load_0_21_19  free_load_conservation_854  -1
    load_0_21_19  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_780  -20
    arc_0_21_20  connected_order_arc_781  -14
    arc_0_21_20  in_degree_856  1
    arc_0_21_20  out_degree_861  1
    arc_0_21_20  original_T_including_depot_unload_871  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_780  1
    load_0_21_20  free_load_conservation_860  -1
    load_0_21_20  free_load_conservation_866  1
    visit_1_6  out_degree_1213  -1
    visit_1_6  in_degree_1214  -1
    visit_1_6  order_active_lb_1215  -1
    visit_1_6  order_active_ub_1216  -13
    order_1_6  connected_order_arc_888  -1
    order_1_6  connected_order_arc_890  -1
    order_1_6  connected_order_arc_892  -1
    order_1_6  connected_order_arc_894  -1
    order_1_6  connected_order_arc_896  -1
    order_1_6  connected_order_arc_898  -1
    order_1_6  connected_order_arc_900  -1
    order_1_6  connected_order_arc_902  -1
    order_1_6  connected_order_arc_904  -1
    order_1_6  connected_order_arc_906  -1
    order_1_6  connected_order_arc_908  -1
    order_1_6  connected_order_arc_910  -1
    order_1_6  connected_order_arc_913  1
    order_1_6  connected_order_arc_938  1
    order_1_6  connected_order_arc_963  1
    order_1_6  connected_order_arc_988  1
    order_1_6  connected_order_arc_1013  1
    order_1_6  connected_order_arc_1038  1
    order_1_6  connected_order_arc_1063  1
    order_1_6  connected_order_arc_1088  1
    order_1_6  connected_order_arc_1113  1
    order_1_6  connected_order_arc_1138  1
    order_1_6  connected_order_arc_1163  1
    order_1_6  connected_order_arc_1188  1
    order_1_6  order_active_lb_1215  1
    order_1_6  order_active_ub_1216  1
    order_1_6  fixed_segment_relative_order_1296  -1
    visit_1_7  out_degree_1220  -1
    visit_1_7  in_degree_1221  -1
    visit_1_7  order_active_lb_1222  -1
    visit_1_7  order_active_ub_1223  -13
    order_1_7  connected_order_arc_888  1
    order_1_7  connected_order_arc_913  -1
    order_1_7  connected_order_arc_915  -1
    order_1_7  connected_order_arc_917  -1
    order_1_7  connected_order_arc_919  -1
    order_1_7  connected_order_arc_921  -1
    order_1_7  connected_order_arc_923  -1
    order_1_7  connected_order_arc_925  -1
    order_1_7  connected_order_arc_927  -1
    order_1_7  connected_order_arc_929  -1
    order_1_7  connected_order_arc_931  -1
    order_1_7  connected_order_arc_933  -1
    order_1_7  connected_order_arc_935  -1
    order_1_7  connected_order_arc_940  1
    order_1_7  connected_order_arc_965  1
    order_1_7  connected_order_arc_990  1
    order_1_7  connected_order_arc_1015  1
    order_1_7  connected_order_arc_1040  1
    order_1_7  connected_order_arc_1065  1
    order_1_7  connected_order_arc_1090  1
    order_1_7  connected_order_arc_1115  1
    order_1_7  connected_order_arc_1140  1
    order_1_7  connected_order_arc_1165  1
    order_1_7  connected_order_arc_1190  1
    order_1_7  order_active_lb_1222  1
    order_1_7  order_active_ub_1223  1
    order_1_7  fixed_segment_relative_order_1296  1
    order_1_7  fixed_segment_relative_order_1297  -1
    visit_1_8  out_degree_1227  -1
    visit_1_8  in_degree_1228  -1
    visit_1_8  order_active_lb_1229  -1
    visit_1_8  order_active_ub_1230  -13
    order_1_8  connected_order_arc_890  1
    order_1_8  connected_order_arc_915  1
    order_1_8  connected_order_arc_938  -1
    order_1_8  connected_order_arc_940  -1
    order_1_8  connected_order_arc_942  -1
    order_1_8  connected_order_arc_944  -1
    order_1_8  connected_order_arc_946  -1
    order_1_8  connected_order_arc_948  -1
    order_1_8  connected_order_arc_950  -1
    order_1_8  connected_order_arc_952  -1
    order_1_8  connected_order_arc_954  -1
    order_1_8  connected_order_arc_956  -1
    order_1_8  connected_order_arc_958  -1
    order_1_8  connected_order_arc_960  -1
    order_1_8  connected_order_arc_967  1
    order_1_8  connected_order_arc_992  1
    order_1_8  connected_order_arc_1017  1
    order_1_8  connected_order_arc_1042  1
    order_1_8  connected_order_arc_1067  1
    order_1_8  connected_order_arc_1092  1
    order_1_8  connected_order_arc_1117  1
    order_1_8  connected_order_arc_1142  1
    order_1_8  connected_order_arc_1167  1
    order_1_8  connected_order_arc_1192  1
    order_1_8  order_active_lb_1229  1
    order_1_8  order_active_ub_1230  1
    order_1_8  fixed_segment_relative_order_1297  1
    order_1_8  fixed_segment_relative_order_1298  -1
    visit_1_9  out_degree_1234  -1
    visit_1_9  in_degree_1235  -1
    visit_1_9  order_active_lb_1236  -1
    visit_1_9  order_active_ub_1237  -13
    order_1_9  connected_order_arc_892  1
    order_1_9  connected_order_arc_917  1
    order_1_9  connected_order_arc_942  1
    order_1_9  connected_order_arc_963  -1
    order_1_9  connected_order_arc_965  -1
    order_1_9  connected_order_arc_967  -1
    order_1_9  connected_order_arc_969  -1
    order_1_9  connected_order_arc_971  -1
    order_1_9  connected_order_arc_973  -1
    order_1_9  connected_order_arc_975  -1
    order_1_9  connected_order_arc_977  -1
    order_1_9  connected_order_arc_979  -1
    order_1_9  connected_order_arc_981  -1
    order_1_9  connected_order_arc_983  -1
    order_1_9  connected_order_arc_985  -1
    order_1_9  connected_order_arc_994  1
    order_1_9  connected_order_arc_1019  1
    order_1_9  connected_order_arc_1044  1
    order_1_9  connected_order_arc_1069  1
    order_1_9  connected_order_arc_1094  1
    order_1_9  connected_order_arc_1119  1
    order_1_9  connected_order_arc_1144  1
    order_1_9  connected_order_arc_1169  1
    order_1_9  connected_order_arc_1194  1
    order_1_9  order_active_lb_1236  1
    order_1_9  order_active_ub_1237  1
    order_1_9  fixed_segment_relative_order_1298  1
    order_1_9  fixed_segment_relative_order_1299  -1
    visit_1_10  out_degree_1241  -1
    visit_1_10  in_degree_1242  -1
    visit_1_10  order_active_lb_1243  -1
    visit_1_10  order_active_ub_1244  -13
    order_1_10  connected_order_arc_894  1
    order_1_10  connected_order_arc_919  1
    order_1_10  connected_order_arc_944  1
    order_1_10  connected_order_arc_969  1
    order_1_10  connected_order_arc_988  -1
    order_1_10  connected_order_arc_990  -1
    order_1_10  connected_order_arc_992  -1
    order_1_10  connected_order_arc_994  -1
    order_1_10  connected_order_arc_996  -1
    order_1_10  connected_order_arc_998  -1
    order_1_10  connected_order_arc_1000  -1
    order_1_10  connected_order_arc_1002  -1
    order_1_10  connected_order_arc_1004  -1
    order_1_10  connected_order_arc_1006  -1
    order_1_10  connected_order_arc_1008  -1
    order_1_10  connected_order_arc_1010  -1
    order_1_10  connected_order_arc_1021  1
    order_1_10  connected_order_arc_1046  1
    order_1_10  connected_order_arc_1071  1
    order_1_10  connected_order_arc_1096  1
    order_1_10  connected_order_arc_1121  1
    order_1_10  connected_order_arc_1146  1
    order_1_10  connected_order_arc_1171  1
    order_1_10  connected_order_arc_1196  1
    order_1_10  order_active_lb_1243  1
    order_1_10  order_active_ub_1244  1
    order_1_10  fixed_segment_relative_order_1299  1
    visit_1_14  out_degree_1248  -1
    visit_1_14  in_degree_1249  -1
    visit_1_14  order_active_lb_1250  -1
    visit_1_14  order_active_ub_1251  -13
    visit_1_14  service_visit_def_1252  -1
    order_1_14  connected_order_arc_896  1
    order_1_14  connected_order_arc_921  1
    order_1_14  connected_order_arc_946  1
    order_1_14  connected_order_arc_971  1
    order_1_14  connected_order_arc_996  1
    order_1_14  connected_order_arc_1013  -1
    order_1_14  connected_order_arc_1015  -1
    order_1_14  connected_order_arc_1017  -1
    order_1_14  connected_order_arc_1019  -1
    order_1_14  connected_order_arc_1021  -1
    order_1_14  connected_order_arc_1023  -1
    order_1_14  connected_order_arc_1025  -1
    order_1_14  connected_order_arc_1027  -1
    order_1_14  connected_order_arc_1029  -1
    order_1_14  connected_order_arc_1031  -1
    order_1_14  connected_order_arc_1033  -1
    order_1_14  connected_order_arc_1035  -1
    order_1_14  connected_order_arc_1048  1
    order_1_14  connected_order_arc_1073  1
    order_1_14  connected_order_arc_1098  1
    order_1_14  connected_order_arc_1123  1
    order_1_14  connected_order_arc_1148  1
    order_1_14  connected_order_arc_1173  1
    order_1_14  connected_order_arc_1198  1
    order_1_14  order_active_lb_1250  1
    order_1_14  order_active_ub_1251  1
    visit_1_15  out_degree_1254  -1
    visit_1_15  in_degree_1255  -1
    visit_1_15  order_active_lb_1256  -1
    visit_1_15  order_active_ub_1257  -13
    visit_1_15  service_visit_def_1258  -1
    order_1_15  connected_order_arc_898  1
    order_1_15  connected_order_arc_923  1
    order_1_15  connected_order_arc_948  1
    order_1_15  connected_order_arc_973  1
    order_1_15  connected_order_arc_998  1
    order_1_15  connected_order_arc_1023  1
    order_1_15  connected_order_arc_1038  -1
    order_1_15  connected_order_arc_1040  -1
    order_1_15  connected_order_arc_1042  -1
    order_1_15  connected_order_arc_1044  -1
    order_1_15  connected_order_arc_1046  -1
    order_1_15  connected_order_arc_1048  -1
    order_1_15  connected_order_arc_1050  -1
    order_1_15  connected_order_arc_1052  -1
    order_1_15  connected_order_arc_1054  -1
    order_1_15  connected_order_arc_1056  -1
    order_1_15  connected_order_arc_1058  -1
    order_1_15  connected_order_arc_1060  -1
    order_1_15  connected_order_arc_1075  1
    order_1_15  connected_order_arc_1100  1
    order_1_15  connected_order_arc_1125  1
    order_1_15  connected_order_arc_1150  1
    order_1_15  connected_order_arc_1175  1
    order_1_15  connected_order_arc_1200  1
    order_1_15  order_active_lb_1256  1
    order_1_15  order_active_ub_1257  1
    visit_1_16  out_degree_1260  -1
    visit_1_16  in_degree_1261  -1
    visit_1_16  order_active_lb_1262  -1
    visit_1_16  order_active_ub_1263  -13
    visit_1_16  service_visit_def_1264  -1
    order_1_16  connected_order_arc_900  1
    order_1_16  connected_order_arc_925  1
    order_1_16  connected_order_arc_950  1
    order_1_16  connected_order_arc_975  1
    order_1_16  connected_order_arc_1000  1
    order_1_16  connected_order_arc_1025  1
    order_1_16  connected_order_arc_1050  1
    order_1_16  connected_order_arc_1063  -1
    order_1_16  connected_order_arc_1065  -1
    order_1_16  connected_order_arc_1067  -1
    order_1_16  connected_order_arc_1069  -1
    order_1_16  connected_order_arc_1071  -1
    order_1_16  connected_order_arc_1073  -1
    order_1_16  connected_order_arc_1075  -1
    order_1_16  connected_order_arc_1077  -1
    order_1_16  connected_order_arc_1079  -1
    order_1_16  connected_order_arc_1081  -1
    order_1_16  connected_order_arc_1083  -1
    order_1_16  connected_order_arc_1085  -1
    order_1_16  connected_order_arc_1102  1
    order_1_16  connected_order_arc_1127  1
    order_1_16  connected_order_arc_1152  1
    order_1_16  connected_order_arc_1177  1
    order_1_16  connected_order_arc_1202  1
    order_1_16  order_active_lb_1262  1
    order_1_16  order_active_ub_1263  1
    visit_1_17  out_degree_1266  -1
    visit_1_17  in_degree_1267  -1
    visit_1_17  order_active_lb_1268  -1
    visit_1_17  order_active_ub_1269  -13
    visit_1_17  service_visit_def_1270  -1
    order_1_17  connected_order_arc_902  1
    order_1_17  connected_order_arc_927  1
    order_1_17  connected_order_arc_952  1
    order_1_17  connected_order_arc_977  1
    order_1_17  connected_order_arc_1002  1
    order_1_17  connected_order_arc_1027  1
    order_1_17  connected_order_arc_1052  1
    order_1_17  connected_order_arc_1077  1
    order_1_17  connected_order_arc_1088  -1
    order_1_17  connected_order_arc_1090  -1
    order_1_17  connected_order_arc_1092  -1
    order_1_17  connected_order_arc_1094  -1
    order_1_17  connected_order_arc_1096  -1
    order_1_17  connected_order_arc_1098  -1
    order_1_17  connected_order_arc_1100  -1
    order_1_17  connected_order_arc_1102  -1
    order_1_17  connected_order_arc_1104  -1
    order_1_17  connected_order_arc_1106  -1
    order_1_17  connected_order_arc_1108  -1
    order_1_17  connected_order_arc_1110  -1
    order_1_17  connected_order_arc_1129  1
    order_1_17  connected_order_arc_1154  1
    order_1_17  connected_order_arc_1179  1
    order_1_17  connected_order_arc_1204  1
    order_1_17  order_active_lb_1268  1
    order_1_17  order_active_ub_1269  1
    visit_1_18  out_degree_1272  -1
    visit_1_18  in_degree_1273  -1
    visit_1_18  order_active_lb_1274  -1
    visit_1_18  order_active_ub_1275  -13
    visit_1_18  service_visit_def_1276  -1
    order_1_18  connected_order_arc_904  1
    order_1_18  connected_order_arc_929  1
    order_1_18  connected_order_arc_954  1
    order_1_18  connected_order_arc_979  1
    order_1_18  connected_order_arc_1004  1
    order_1_18  connected_order_arc_1029  1
    order_1_18  connected_order_arc_1054  1
    order_1_18  connected_order_arc_1079  1
    order_1_18  connected_order_arc_1104  1
    order_1_18  connected_order_arc_1113  -1
    order_1_18  connected_order_arc_1115  -1
    order_1_18  connected_order_arc_1117  -1
    order_1_18  connected_order_arc_1119  -1
    order_1_18  connected_order_arc_1121  -1
    order_1_18  connected_order_arc_1123  -1
    order_1_18  connected_order_arc_1125  -1
    order_1_18  connected_order_arc_1127  -1
    order_1_18  connected_order_arc_1129  -1
    order_1_18  connected_order_arc_1131  -1
    order_1_18  connected_order_arc_1133  -1
    order_1_18  connected_order_arc_1135  -1
    order_1_18  connected_order_arc_1156  1
    order_1_18  connected_order_arc_1181  1
    order_1_18  connected_order_arc_1206  1
    order_1_18  order_active_lb_1274  1
    order_1_18  order_active_ub_1275  1
    visit_1_19  out_degree_1278  -1
    visit_1_19  in_degree_1279  -1
    visit_1_19  order_active_lb_1280  -1
    visit_1_19  order_active_ub_1281  -13
    visit_1_19  service_visit_def_1282  -1
    order_1_19  connected_order_arc_906  1
    order_1_19  connected_order_arc_931  1
    order_1_19  connected_order_arc_956  1
    order_1_19  connected_order_arc_981  1
    order_1_19  connected_order_arc_1006  1
    order_1_19  connected_order_arc_1031  1
    order_1_19  connected_order_arc_1056  1
    order_1_19  connected_order_arc_1081  1
    order_1_19  connected_order_arc_1106  1
    order_1_19  connected_order_arc_1131  1
    order_1_19  connected_order_arc_1138  -1
    order_1_19  connected_order_arc_1140  -1
    order_1_19  connected_order_arc_1142  -1
    order_1_19  connected_order_arc_1144  -1
    order_1_19  connected_order_arc_1146  -1
    order_1_19  connected_order_arc_1148  -1
    order_1_19  connected_order_arc_1150  -1
    order_1_19  connected_order_arc_1152  -1
    order_1_19  connected_order_arc_1154  -1
    order_1_19  connected_order_arc_1156  -1
    order_1_19  connected_order_arc_1158  -1
    order_1_19  connected_order_arc_1160  -1
    order_1_19  connected_order_arc_1183  1
    order_1_19  connected_order_arc_1208  1
    order_1_19  order_active_lb_1280  1
    order_1_19  order_active_ub_1281  1
    visit_1_20  out_degree_1284  -1
    visit_1_20  in_degree_1285  -1
    visit_1_20  order_active_lb_1286  -1
    visit_1_20  order_active_ub_1287  -13
    visit_1_20  service_visit_def_1288  -1
    order_1_20  connected_order_arc_908  1
    order_1_20  connected_order_arc_933  1
    order_1_20  connected_order_arc_958  1
    order_1_20  connected_order_arc_983  1
    order_1_20  connected_order_arc_1008  1
    order_1_20  connected_order_arc_1033  1
    order_1_20  connected_order_arc_1058  1
    order_1_20  connected_order_arc_1083  1
    order_1_20  connected_order_arc_1108  1
    order_1_20  connected_order_arc_1133  1
    order_1_20  connected_order_arc_1158  1
    order_1_20  connected_order_arc_1163  -1
    order_1_20  connected_order_arc_1165  -1
    order_1_20  connected_order_arc_1167  -1
    order_1_20  connected_order_arc_1169  -1
    order_1_20  connected_order_arc_1171  -1
    order_1_20  connected_order_arc_1173  -1
    order_1_20  connected_order_arc_1175  -1
    order_1_20  connected_order_arc_1177  -1
    order_1_20  connected_order_arc_1179  -1
    order_1_20  connected_order_arc_1181  -1
    order_1_20  connected_order_arc_1183  -1
    order_1_20  connected_order_arc_1185  -1
    order_1_20  connected_order_arc_1210  1
    order_1_20  order_active_lb_1286  1
    order_1_20  order_active_ub_1287  1
    visit_1_21  out_degree_1290  -1
    visit_1_21  in_degree_1291  -1
    visit_1_21  order_active_lb_1292  -1
    visit_1_21  order_active_ub_1293  -13
    visit_1_21  service_visit_def_1294  -1
    order_1_21  connected_order_arc_910  1
    order_1_21  connected_order_arc_935  1
    order_1_21  connected_order_arc_960  1
    order_1_21  connected_order_arc_985  1
    order_1_21  connected_order_arc_1010  1
    order_1_21  connected_order_arc_1035  1
    order_1_21  connected_order_arc_1060  1
    order_1_21  connected_order_arc_1085  1
    order_1_21  connected_order_arc_1110  1
    order_1_21  connected_order_arc_1135  1
    order_1_21  connected_order_arc_1160  1
    order_1_21  connected_order_arc_1185  1
    order_1_21  connected_order_arc_1188  -1
    order_1_21  connected_order_arc_1190  -1
    order_1_21  connected_order_arc_1192  -1
    order_1_21  connected_order_arc_1194  -1
    order_1_21  connected_order_arc_1196  -1
    order_1_21  connected_order_arc_1198  -1
    order_1_21  connected_order_arc_1200  -1
    order_1_21  connected_order_arc_1202  -1
    order_1_21  connected_order_arc_1204  -1
    order_1_21  connected_order_arc_1206  -1
    order_1_21  connected_order_arc_1208  -1
    order_1_21  connected_order_arc_1210  -1
    order_1_21  order_active_lb_1292  1
    order_1_21  order_active_ub_1293  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_872  -25
    arc_1_0_0  depot_departure_or_bypass_1211  1
    arc_1_0_0  depot_return_or_bypass_1212  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_873  -25
    arc_1_0_6  depot_departure_or_bypass_1211  1
    arc_1_0_6  in_degree_1214  1
    arc_1_0_6  original_T_including_depot_unload_1300  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_873  1
    load_1_0_6  segment_load_conservation_1217  -1
    load_1_0_6  segment_prefix_lb_1218  1
    load_1_0_6  segment_prefix_ub_1219  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_874  -25
    arc_1_0_7  depot_departure_or_bypass_1211  1
    arc_1_0_7  in_degree_1221  1
    arc_1_0_7  original_T_including_depot_unload_1300  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_874  1
    load_1_0_7  segment_load_conservation_1224  -1
    load_1_0_7  segment_prefix_lb_1225  1
    load_1_0_7  segment_prefix_ub_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_875  -25
    arc_1_0_8  depot_departure_or_bypass_1211  1
    arc_1_0_8  in_degree_1228  1
    arc_1_0_8  original_T_including_depot_unload_1300  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_875  1
    load_1_0_8  segment_load_conservation_1231  -1
    load_1_0_8  segment_prefix_lb_1232  1
    load_1_0_8  segment_prefix_ub_1233  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_876  -25
    arc_1_0_9  depot_departure_or_bypass_1211  1
    arc_1_0_9  in_degree_1235  1
    arc_1_0_9  original_T_including_depot_unload_1300  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_876  1
    load_1_0_9  segment_load_conservation_1238  -1
    load_1_0_9  segment_prefix_lb_1239  1
    load_1_0_9  segment_prefix_ub_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_877  -25
    arc_1_0_10  depot_departure_or_bypass_1211  1
    arc_1_0_10  in_degree_1242  1
    arc_1_0_10  original_T_including_depot_unload_1300  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_877  1
    load_1_0_10  segment_load_conservation_1245  -1
    load_1_0_10  segment_prefix_lb_1246  1
    load_1_0_10  segment_prefix_ub_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_878  -25
    arc_1_0_14  depot_departure_or_bypass_1211  1
    arc_1_0_14  in_degree_1249  1
    arc_1_0_14  original_T_including_depot_unload_1300  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_878  1
    load_1_0_14  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_879  -25
    arc_1_0_15  depot_departure_or_bypass_1211  1
    arc_1_0_15  in_degree_1255  1
    arc_1_0_15  original_T_including_depot_unload_1300  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_879  1
    load_1_0_15  free_load_conservation_1259  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_880  -25
    arc_1_0_16  depot_departure_or_bypass_1211  1
    arc_1_0_16  in_degree_1261  1
    arc_1_0_16  original_T_including_depot_unload_1300  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_880  1
    load_1_0_16  free_load_conservation_1265  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_881  -25
    arc_1_0_17  depot_departure_or_bypass_1211  1
    arc_1_0_17  in_degree_1267  1
    arc_1_0_17  original_T_including_depot_unload_1300  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_881  1
    load_1_0_17  free_load_conservation_1271  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_882  -25
    arc_1_0_18  depot_departure_or_bypass_1211  1
    arc_1_0_18  in_degree_1273  1
    arc_1_0_18  original_T_including_depot_unload_1300  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_882  1
    load_1_0_18  free_load_conservation_1277  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_883  -25
    arc_1_0_19  depot_departure_or_bypass_1211  1
    arc_1_0_19  in_degree_1279  1
    arc_1_0_19  original_T_including_depot_unload_1300  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_883  1
    load_1_0_19  free_load_conservation_1283  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_884  -25
    arc_1_0_20  depot_departure_or_bypass_1211  1
    arc_1_0_20  in_degree_1285  1
    arc_1_0_20  original_T_including_depot_unload_1300  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_884  1
    load_1_0_20  free_load_conservation_1289  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_885  -25
    arc_1_0_21  depot_departure_or_bypass_1211  1
    arc_1_0_21  in_degree_1291  1
    arc_1_0_21  original_T_including_depot_unload_1300  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_885  1
    load_1_0_21  free_load_conservation_1295  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_886  -25
    arc_1_6_0  depot_return_or_bypass_1212  1
    arc_1_6_0  out_degree_1213  1
    arc_1_6_0  original_T_including_depot_unload_1300  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_886  1
    load_1_6_0  segment_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_887  -25
    arc_1_6_7  connected_order_arc_888  -14
    arc_1_6_7  out_degree_1213  1
    arc_1_6_7  in_degree_1221  1
    arc_1_6_7  original_T_including_depot_unload_1300  7.7248128224166851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_887  1
    load_1_6_7  segment_load_conservation_1217  1
    load_1_6_7  segment_load_conservation_1224  -1
    load_1_6_7  segment_prefix_lb_1225  1
    load_1_6_7  segment_prefix_ub_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_889  -25
    arc_1_6_8  connected_order_arc_890  -14
    arc_1_6_8  out_degree_1213  1
    arc_1_6_8  in_degree_1228  1
    arc_1_6_8  original_T_including_depot_unload_1300  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_889  1
    load_1_6_8  segment_load_conservation_1217  1
    load_1_6_8  segment_load_conservation_1231  -1
    load_1_6_8  segment_prefix_lb_1232  1
    load_1_6_8  segment_prefix_ub_1233  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_891  -25
    arc_1_6_9  connected_order_arc_892  -14
    arc_1_6_9  out_degree_1213  1
    arc_1_6_9  in_degree_1235  1
    arc_1_6_9  original_T_including_depot_unload_1300  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_891  1
    load_1_6_9  segment_load_conservation_1217  1
    load_1_6_9  segment_load_conservation_1238  -1
    load_1_6_9  segment_prefix_lb_1239  1
    load_1_6_9  segment_prefix_ub_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_10  arc_capacity_893  -25
    arc_1_6_10  connected_order_arc_894  -14
    arc_1_6_10  out_degree_1213  1
    arc_1_6_10  in_degree_1242  1
    arc_1_6_10  original_T_including_depot_unload_1300  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_10  arc_capacity_893  1
    load_1_6_10  segment_load_conservation_1217  1
    load_1_6_10  segment_load_conservation_1245  -1
    load_1_6_10  segment_prefix_lb_1246  1
    load_1_6_10  segment_prefix_ub_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_895  -25
    arc_1_6_14  connected_order_arc_896  -14
    arc_1_6_14  out_degree_1213  1
    arc_1_6_14  in_degree_1249  1
    arc_1_6_14  original_T_including_depot_unload_1300  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_895  1
    load_1_6_14  segment_load_conservation_1217  1
    load_1_6_14  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_897  -25
    arc_1_6_15  connected_order_arc_898  -14
    arc_1_6_15  out_degree_1213  1
    arc_1_6_15  in_degree_1255  1
    arc_1_6_15  original_T_including_depot_unload_1300  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_897  1
    load_1_6_15  segment_load_conservation_1217  1
    load_1_6_15  free_load_conservation_1259  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_899  -25
    arc_1_6_16  connected_order_arc_900  -14
    arc_1_6_16  out_degree_1213  1
    arc_1_6_16  in_degree_1261  1
    arc_1_6_16  original_T_including_depot_unload_1300  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_899  1
    load_1_6_16  segment_load_conservation_1217  1
    load_1_6_16  free_load_conservation_1265  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_901  -25
    arc_1_6_17  connected_order_arc_902  -14
    arc_1_6_17  out_degree_1213  1
    arc_1_6_17  in_degree_1267  1
    arc_1_6_17  original_T_including_depot_unload_1300  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_901  1
    load_1_6_17  segment_load_conservation_1217  1
    load_1_6_17  free_load_conservation_1271  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_903  -25
    arc_1_6_18  connected_order_arc_904  -14
    arc_1_6_18  out_degree_1213  1
    arc_1_6_18  in_degree_1273  1
    arc_1_6_18  original_T_including_depot_unload_1300  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_903  1
    load_1_6_18  segment_load_conservation_1217  1
    load_1_6_18  free_load_conservation_1277  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_905  -25
    arc_1_6_19  connected_order_arc_906  -14
    arc_1_6_19  out_degree_1213  1
    arc_1_6_19  in_degree_1279  1
    arc_1_6_19  original_T_including_depot_unload_1300  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_905  1
    load_1_6_19  segment_load_conservation_1217  1
    load_1_6_19  free_load_conservation_1283  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_907  -25
    arc_1_6_20  connected_order_arc_908  -14
    arc_1_6_20  out_degree_1213  1
    arc_1_6_20  in_degree_1285  1
    arc_1_6_20  original_T_including_depot_unload_1300  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_907  1
    load_1_6_20  segment_load_conservation_1217  1
    load_1_6_20  free_load_conservation_1289  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_21  arc_capacity_909  -25
    arc_1_6_21  connected_order_arc_910  -14
    arc_1_6_21  out_degree_1213  1
    arc_1_6_21  in_degree_1291  1
    arc_1_6_21  original_T_including_depot_unload_1300  7.0141209816069022e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_21  arc_capacity_909  1
    load_1_6_21  segment_load_conservation_1217  1
    load_1_6_21  free_load_conservation_1295  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_911  -25
    arc_1_7_0  depot_return_or_bypass_1212  1
    arc_1_7_0  out_degree_1220  1
    arc_1_7_0  original_T_including_depot_unload_1300  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_911  1
    load_1_7_0  segment_load_conservation_1224  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_912  -25
    arc_1_7_6  connected_order_arc_913  -14
    arc_1_7_6  in_degree_1214  1
    arc_1_7_6  out_degree_1220  1
    arc_1_7_6  original_T_including_depot_unload_1300  7.7248128224166851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_912  1
    load_1_7_6  segment_load_conservation_1217  -1
    load_1_7_6  segment_prefix_lb_1218  1
    load_1_7_6  segment_prefix_ub_1219  1
    load_1_7_6  segment_load_conservation_1224  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_914  -25
    arc_1_7_8  connected_order_arc_915  -14
    arc_1_7_8  out_degree_1220  1
    arc_1_7_8  in_degree_1228  1
    arc_1_7_8  original_T_including_depot_unload_1300  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_914  1
    load_1_7_8  segment_load_conservation_1224  1
    load_1_7_8  segment_load_conservation_1231  -1
    load_1_7_8  segment_prefix_lb_1232  1
    load_1_7_8  segment_prefix_ub_1233  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_916  -25
    arc_1_7_9  connected_order_arc_917  -14
    arc_1_7_9  out_degree_1220  1
    arc_1_7_9  in_degree_1235  1
    arc_1_7_9  original_T_including_depot_unload_1300  726.017738185843
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_916  1
    load_1_7_9  segment_load_conservation_1224  1
    load_1_7_9  segment_load_conservation_1238  -1
    load_1_7_9  segment_prefix_lb_1239  1
    load_1_7_9  segment_prefix_ub_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_918  -25
    arc_1_7_10  connected_order_arc_919  -14
    arc_1_7_10  out_degree_1220  1
    arc_1_7_10  in_degree_1242  1
    arc_1_7_10  original_T_including_depot_unload_1300  990.144803963742
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_918  1
    load_1_7_10  segment_load_conservation_1224  1
    load_1_7_10  segment_load_conservation_1245  -1
    load_1_7_10  segment_prefix_lb_1246  1
    load_1_7_10  segment_prefix_ub_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_920  -25
    arc_1_7_14  connected_order_arc_921  -14
    arc_1_7_14  out_degree_1220  1
    arc_1_7_14  in_degree_1249  1
    arc_1_7_14  original_T_including_depot_unload_1300  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_920  1
    load_1_7_14  segment_load_conservation_1224  1
    load_1_7_14  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_922  -25
    arc_1_7_15  connected_order_arc_923  -14
    arc_1_7_15  out_degree_1220  1
    arc_1_7_15  in_degree_1255  1
    arc_1_7_15  original_T_including_depot_unload_1300  8.2035300709080423e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_922  1
    load_1_7_15  segment_load_conservation_1224  1
    load_1_7_15  free_load_conservation_1259  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_924  -25
    arc_1_7_16  connected_order_arc_925  -14
    arc_1_7_16  out_degree_1220  1
    arc_1_7_16  in_degree_1261  1
    arc_1_7_16  original_T_including_depot_unload_1300  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_924  1
    load_1_7_16  segment_load_conservation_1224  1
    load_1_7_16  free_load_conservation_1265  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_926  -25
    arc_1_7_17  connected_order_arc_927  -14
    arc_1_7_17  out_degree_1220  1
    arc_1_7_17  in_degree_1267  1
    arc_1_7_17  original_T_including_depot_unload_1300  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_926  1
    load_1_7_17  segment_load_conservation_1224  1
    load_1_7_17  free_load_conservation_1271  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_928  -25
    arc_1_7_18  connected_order_arc_929  -14
    arc_1_7_18  out_degree_1220  1
    arc_1_7_18  in_degree_1273  1
    arc_1_7_18  original_T_including_depot_unload_1300  1.7211624454573559e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_928  1
    load_1_7_18  segment_load_conservation_1224  1
    load_1_7_18  free_load_conservation_1277  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_930  -25
    arc_1_7_19  connected_order_arc_931  -14
    arc_1_7_19  out_degree_1220  1
    arc_1_7_19  in_degree_1279  1
    arc_1_7_19  original_T_including_depot_unload_1300  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_930  1
    load_1_7_19  segment_load_conservation_1224  1
    load_1_7_19  free_load_conservation_1283  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_932  -25
    arc_1_7_20  connected_order_arc_933  -14
    arc_1_7_20  out_degree_1220  1
    arc_1_7_20  in_degree_1285  1
    arc_1_7_20  original_T_including_depot_unload_1300  1.1663816070445826e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_932  1
    load_1_7_20  segment_load_conservation_1224  1
    load_1_7_20  free_load_conservation_1289  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_934  -25
    arc_1_7_21  connected_order_arc_935  -14
    arc_1_7_21  out_degree_1220  1
    arc_1_7_21  in_degree_1291  1
    arc_1_7_21  original_T_including_depot_unload_1300  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_934  1
    load_1_7_21  segment_load_conservation_1224  1
    load_1_7_21  free_load_conservation_1295  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_936  -25
    arc_1_8_0  depot_return_or_bypass_1212  1
    arc_1_8_0  out_degree_1227  1
    arc_1_8_0  original_T_including_depot_unload_1300  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_936  1
    load_1_8_0  segment_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_937  -25
    arc_1_8_6  connected_order_arc_938  -14
    arc_1_8_6  in_degree_1214  1
    arc_1_8_6  out_degree_1227  1
    arc_1_8_6  original_T_including_depot_unload_1300  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_937  1
    load_1_8_6  segment_load_conservation_1217  -1
    load_1_8_6  segment_prefix_lb_1218  1
    load_1_8_6  segment_prefix_ub_1219  1
    load_1_8_6  segment_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_939  -25
    arc_1_8_7  connected_order_arc_940  -14
    arc_1_8_7  in_degree_1221  1
    arc_1_8_7  out_degree_1227  1
    arc_1_8_7  original_T_including_depot_unload_1300  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_939  1
    load_1_8_7  segment_load_conservation_1224  -1
    load_1_8_7  segment_prefix_lb_1225  1
    load_1_8_7  segment_prefix_ub_1226  1
    load_1_8_7  segment_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_941  -25
    arc_1_8_9  connected_order_arc_942  -14
    arc_1_8_9  out_degree_1227  1
    arc_1_8_9  in_degree_1235  1
    arc_1_8_9  original_T_including_depot_unload_1300  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_941  1
    load_1_8_9  segment_load_conservation_1231  1
    load_1_8_9  segment_load_conservation_1238  -1
    load_1_8_9  segment_prefix_lb_1239  1
    load_1_8_9  segment_prefix_ub_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_943  -25
    arc_1_8_10  connected_order_arc_944  -14
    arc_1_8_10  out_degree_1227  1
    arc_1_8_10  in_degree_1242  1
    arc_1_8_10  original_T_including_depot_unload_1300  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_943  1
    load_1_8_10  segment_load_conservation_1231  1
    load_1_8_10  segment_load_conservation_1245  -1
    load_1_8_10  segment_prefix_lb_1246  1
    load_1_8_10  segment_prefix_ub_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_945  -25
    arc_1_8_14  connected_order_arc_946  -14
    arc_1_8_14  out_degree_1227  1
    arc_1_8_14  in_degree_1249  1
    arc_1_8_14  original_T_including_depot_unload_1300  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_945  1
    load_1_8_14  segment_load_conservation_1231  1
    load_1_8_14  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_947  -25
    arc_1_8_15  connected_order_arc_948  -14
    arc_1_8_15  out_degree_1227  1
    arc_1_8_15  in_degree_1255  1
    arc_1_8_15  original_T_including_depot_unload_1300  9.7692852841087415e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_947  1
    load_1_8_15  segment_load_conservation_1231  1
    load_1_8_15  free_load_conservation_1259  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_949  -25
    arc_1_8_16  connected_order_arc_950  -14
    arc_1_8_16  out_degree_1227  1
    arc_1_8_16  in_degree_1261  1
    arc_1_8_16  original_T_including_depot_unload_1300  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_949  1
    load_1_8_16  segment_load_conservation_1231  1
    load_1_8_16  free_load_conservation_1265  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_951  -25
    arc_1_8_17  connected_order_arc_952  -14
    arc_1_8_17  out_degree_1227  1
    arc_1_8_17  in_degree_1267  1
    arc_1_8_17  original_T_including_depot_unload_1300  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_951  1
    load_1_8_17  segment_load_conservation_1231  1
    load_1_8_17  free_load_conservation_1271  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_953  -25
    arc_1_8_18  connected_order_arc_954  -14
    arc_1_8_18  out_degree_1227  1
    arc_1_8_18  in_degree_1273  1
    arc_1_8_18  original_T_including_depot_unload_1300  1.7225744515697754e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_953  1
    load_1_8_18  segment_load_conservation_1231  1
    load_1_8_18  free_load_conservation_1277  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_955  -25
    arc_1_8_19  connected_order_arc_956  -14
    arc_1_8_19  out_degree_1227  1
    arc_1_8_19  in_degree_1279  1
    arc_1_8_19  original_T_including_depot_unload_1300  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_955  1
    load_1_8_19  segment_load_conservation_1231  1
    load_1_8_19  free_load_conservation_1283  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_957  -25
    arc_1_8_20  connected_order_arc_958  -14
    arc_1_8_20  out_degree_1227  1
    arc_1_8_20  in_degree_1285  1
    arc_1_8_20  original_T_including_depot_unload_1300  1.2100678255370710e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_957  1
    load_1_8_20  segment_load_conservation_1231  1
    load_1_8_20  free_load_conservation_1289  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_959  -25
    arc_1_8_21  connected_order_arc_960  -14
    arc_1_8_21  out_degree_1227  1
    arc_1_8_21  in_degree_1291  1
    arc_1_8_21  original_T_including_depot_unload_1300  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_959  1
    load_1_8_21  segment_load_conservation_1231  1
    load_1_8_21  free_load_conservation_1295  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_961  -25
    arc_1_9_0  depot_return_or_bypass_1212  1
    arc_1_9_0  out_degree_1234  1
    arc_1_9_0  original_T_including_depot_unload_1300  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_961  1
    load_1_9_0  segment_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_962  -25
    arc_1_9_6  connected_order_arc_963  -14
    arc_1_9_6  in_degree_1214  1
    arc_1_9_6  out_degree_1234  1
    arc_1_9_6  original_T_including_depot_unload_1300  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_962  1
    load_1_9_6  segment_load_conservation_1217  -1
    load_1_9_6  segment_prefix_lb_1218  1
    load_1_9_6  segment_prefix_ub_1219  1
    load_1_9_6  segment_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_964  -25
    arc_1_9_7  connected_order_arc_965  -14
    arc_1_9_7  in_degree_1221  1
    arc_1_9_7  out_degree_1234  1
    arc_1_9_7  original_T_including_depot_unload_1300  7.7983683767935065e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_964  1
    load_1_9_7  segment_load_conservation_1224  -1
    load_1_9_7  segment_prefix_lb_1225  1
    load_1_9_7  segment_prefix_ub_1226  1
    load_1_9_7  segment_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_966  -25
    arc_1_9_8  connected_order_arc_967  -14
    arc_1_9_8  in_degree_1228  1
    arc_1_9_8  out_degree_1234  1
    arc_1_9_8  original_T_including_depot_unload_1300  6.7554763364087285e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_966  1
    load_1_9_8  segment_load_conservation_1231  -1
    load_1_9_8  segment_prefix_lb_1232  1
    load_1_9_8  segment_prefix_ub_1233  1
    load_1_9_8  segment_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_968  -25
    arc_1_9_10  connected_order_arc_969  -14
    arc_1_9_10  out_degree_1234  1
    arc_1_9_10  in_degree_1242  1
    arc_1_9_10  original_T_including_depot_unload_1300  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_968  1
    load_1_9_10  segment_load_conservation_1238  1
    load_1_9_10  segment_load_conservation_1245  -1
    load_1_9_10  segment_prefix_lb_1246  1
    load_1_9_10  segment_prefix_ub_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_970  -25
    arc_1_9_14  connected_order_arc_971  -14
    arc_1_9_14  out_degree_1234  1
    arc_1_9_14  in_degree_1249  1
    arc_1_9_14  original_T_including_depot_unload_1300  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_970  1
    load_1_9_14  segment_load_conservation_1238  1
    load_1_9_14  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_972  -25
    arc_1_9_15  connected_order_arc_973  -14
    arc_1_9_15  out_degree_1234  1
    arc_1_9_15  in_degree_1255  1
    arc_1_9_15  original_T_including_depot_unload_1300  1.0967168052209140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_972  1
    load_1_9_15  segment_load_conservation_1238  1
    load_1_9_15  free_load_conservation_1259  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_974  -25
    arc_1_9_16  connected_order_arc_975  -14
    arc_1_9_16  out_degree_1234  1
    arc_1_9_16  in_degree_1261  1
    arc_1_9_16  original_T_including_depot_unload_1300  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_974  1
    load_1_9_16  segment_load_conservation_1238  1
    load_1_9_16  free_load_conservation_1265  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_976  -25
    arc_1_9_17  connected_order_arc_977  -14
    arc_1_9_17  out_degree_1234  1
    arc_1_9_17  in_degree_1267  1
    arc_1_9_17  original_T_including_depot_unload_1300  1.0684489086573428e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_976  1
    load_1_9_17  segment_load_conservation_1238  1
    load_1_9_17  free_load_conservation_1271  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_978  -25
    arc_1_9_18  connected_order_arc_979  -14
    arc_1_9_18  out_degree_1234  1
    arc_1_9_18  in_degree_1273  1
    arc_1_9_18  original_T_including_depot_unload_1300  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_978  1
    load_1_9_18  segment_load_conservation_1238  1
    load_1_9_18  free_load_conservation_1277  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_980  -25
    arc_1_9_19  connected_order_arc_981  -14
    arc_1_9_19  out_degree_1234  1
    arc_1_9_19  in_degree_1279  1
    arc_1_9_19  original_T_including_depot_unload_1300  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_980  1
    load_1_9_19  segment_load_conservation_1238  1
    load_1_9_19  free_load_conservation_1283  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_982  -25
    arc_1_9_20  connected_order_arc_983  -14
    arc_1_9_20  out_degree_1234  1
    arc_1_9_20  in_degree_1285  1
    arc_1_9_20  original_T_including_depot_unload_1300  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_982  1
    load_1_9_20  segment_load_conservation_1238  1
    load_1_9_20  free_load_conservation_1289  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_984  -25
    arc_1_9_21  connected_order_arc_985  -14
    arc_1_9_21  out_degree_1234  1
    arc_1_9_21  in_degree_1291  1
    arc_1_9_21  original_T_including_depot_unload_1300  754.162661294669
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_984  1
    load_1_9_21  segment_load_conservation_1238  1
    load_1_9_21  free_load_conservation_1295  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_986  -25
    arc_1_10_0  depot_return_or_bypass_1212  1
    arc_1_10_0  out_degree_1241  1
    arc_1_10_0  original_T_including_depot_unload_1300  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_986  1
    load_1_10_0  segment_load_conservation_1245  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_6  arc_capacity_987  -25
    arc_1_10_6  connected_order_arc_988  -14
    arc_1_10_6  in_degree_1214  1
    arc_1_10_6  out_degree_1241  1
    arc_1_10_6  original_T_including_depot_unload_1300  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_6  arc_capacity_987  1
    load_1_10_6  segment_load_conservation_1217  -1
    load_1_10_6  segment_prefix_lb_1218  1
    load_1_10_6  segment_prefix_ub_1219  1
    load_1_10_6  segment_load_conservation_1245  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_989  -25
    arc_1_10_7  connected_order_arc_990  -14
    arc_1_10_7  in_degree_1221  1
    arc_1_10_7  out_degree_1241  1
    arc_1_10_7  original_T_including_depot_unload_1300  990.144803963742
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_989  1
    load_1_10_7  segment_load_conservation_1224  -1
    load_1_10_7  segment_prefix_lb_1225  1
    load_1_10_7  segment_prefix_ub_1226  1
    load_1_10_7  segment_load_conservation_1245  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_991  -25
    arc_1_10_8  connected_order_arc_992  -14
    arc_1_10_8  in_degree_1228  1
    arc_1_10_8  out_degree_1241  1
    arc_1_10_8  original_T_including_depot_unload_1300  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_991  1
    load_1_10_8  segment_load_conservation_1231  -1
    load_1_10_8  segment_prefix_lb_1232  1
    load_1_10_8  segment_prefix_ub_1233  1
    load_1_10_8  segment_load_conservation_1245  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_993  -25
    arc_1_10_9  connected_order_arc_994  -14
    arc_1_10_9  in_degree_1235  1
    arc_1_10_9  out_degree_1241  1
    arc_1_10_9  original_T_including_depot_unload_1300  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_993  1
    load_1_10_9  segment_load_conservation_1238  -1
    load_1_10_9  segment_prefix_lb_1239  1
    load_1_10_9  segment_prefix_ub_1240  1
    load_1_10_9  segment_load_conservation_1245  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_995  -25
    arc_1_10_14  connected_order_arc_996  -14
    arc_1_10_14  out_degree_1241  1
    arc_1_10_14  in_degree_1249  1
    arc_1_10_14  original_T_including_depot_unload_1300  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_995  1
    load_1_10_14  segment_load_conservation_1245  1
    load_1_10_14  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_997  -25
    arc_1_10_15  connected_order_arc_998  -14
    arc_1_10_15  out_degree_1241  1
    arc_1_10_15  in_degree_1255  1
    arc_1_10_15  original_T_including_depot_unload_1300  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_997  1
    load_1_10_15  segment_load_conservation_1245  1
    load_1_10_15  free_load_conservation_1259  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_999  -25
    arc_1_10_16  connected_order_arc_1000  -14
    arc_1_10_16  out_degree_1241  1
    arc_1_10_16  in_degree_1261  1
    arc_1_10_16  original_T_including_depot_unload_1300  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_999  1
    load_1_10_16  segment_load_conservation_1245  1
    load_1_10_16  free_load_conservation_1265  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_1001  -25
    arc_1_10_17  connected_order_arc_1002  -14
    arc_1_10_17  out_degree_1241  1
    arc_1_10_17  in_degree_1267  1
    arc_1_10_17  original_T_including_depot_unload_1300  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_1001  1
    load_1_10_17  segment_load_conservation_1245  1
    load_1_10_17  free_load_conservation_1271  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_1003  -25
    arc_1_10_18  connected_order_arc_1004  -14
    arc_1_10_18  out_degree_1241  1
    arc_1_10_18  in_degree_1273  1
    arc_1_10_18  original_T_including_depot_unload_1300  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_1003  1
    load_1_10_18  segment_load_conservation_1245  1
    load_1_10_18  free_load_conservation_1277  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_19  arc_capacity_1005  -25
    arc_1_10_19  connected_order_arc_1006  -14
    arc_1_10_19  out_degree_1241  1
    arc_1_10_19  in_degree_1279  1
    arc_1_10_19  original_T_including_depot_unload_1300  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_19  arc_capacity_1005  1
    load_1_10_19  segment_load_conservation_1245  1
    load_1_10_19  free_load_conservation_1283  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_20  arc_capacity_1007  -25
    arc_1_10_20  connected_order_arc_1008  -14
    arc_1_10_20  out_degree_1241  1
    arc_1_10_20  in_degree_1285  1
    arc_1_10_20  original_T_including_depot_unload_1300  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_20  arc_capacity_1007  1
    load_1_10_20  segment_load_conservation_1245  1
    load_1_10_20  free_load_conservation_1289  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_21  arc_capacity_1009  -25
    arc_1_10_21  connected_order_arc_1010  -14
    arc_1_10_21  out_degree_1241  1
    arc_1_10_21  in_degree_1291  1
    arc_1_10_21  original_T_including_depot_unload_1300  8.5502565124349769e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_21  arc_capacity_1009  1
    load_1_10_21  segment_load_conservation_1245  1
    load_1_10_21  free_load_conservation_1295  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1011  -25
    arc_1_14_0  depot_return_or_bypass_1212  1
    arc_1_14_0  out_degree_1248  1
    arc_1_14_0  original_T_including_depot_unload_1300  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1011  1
    load_1_14_0  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_1012  -25
    arc_1_14_6  connected_order_arc_1013  -14
    arc_1_14_6  in_degree_1214  1
    arc_1_14_6  out_degree_1248  1
    arc_1_14_6  original_T_including_depot_unload_1300  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_1012  1
    load_1_14_6  segment_load_conservation_1217  -1
    load_1_14_6  segment_prefix_lb_1218  1
    load_1_14_6  segment_prefix_ub_1219  1
    load_1_14_6  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_1014  -25
    arc_1_14_7  connected_order_arc_1015  -14
    arc_1_14_7  in_degree_1221  1
    arc_1_14_7  out_degree_1248  1
    arc_1_14_7  original_T_including_depot_unload_1300  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_1014  1
    load_1_14_7  segment_load_conservation_1224  -1
    load_1_14_7  segment_prefix_lb_1225  1
    load_1_14_7  segment_prefix_ub_1226  1
    load_1_14_7  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_1016  -25
    arc_1_14_8  connected_order_arc_1017  -14
    arc_1_14_8  in_degree_1228  1
    arc_1_14_8  out_degree_1248  1
    arc_1_14_8  original_T_including_depot_unload_1300  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_1016  1
    load_1_14_8  segment_load_conservation_1231  -1
    load_1_14_8  segment_prefix_lb_1232  1
    load_1_14_8  segment_prefix_ub_1233  1
    load_1_14_8  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1018  -25
    arc_1_14_9  connected_order_arc_1019  -14
    arc_1_14_9  in_degree_1235  1
    arc_1_14_9  out_degree_1248  1
    arc_1_14_9  original_T_including_depot_unload_1300  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1018  1
    load_1_14_9  segment_load_conservation_1238  -1
    load_1_14_9  segment_prefix_lb_1239  1
    load_1_14_9  segment_prefix_ub_1240  1
    load_1_14_9  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_1020  -25
    arc_1_14_10  connected_order_arc_1021  -14
    arc_1_14_10  in_degree_1242  1
    arc_1_14_10  out_degree_1248  1
    arc_1_14_10  original_T_including_depot_unload_1300  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_1020  1
    load_1_14_10  segment_load_conservation_1245  -1
    load_1_14_10  segment_prefix_lb_1246  1
    load_1_14_10  segment_prefix_ub_1247  1
    load_1_14_10  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1022  -25
    arc_1_14_15  connected_order_arc_1023  -14
    arc_1_14_15  out_degree_1248  1
    arc_1_14_15  in_degree_1255  1
    arc_1_14_15  original_T_including_depot_unload_1300  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1022  1
    load_1_14_15  free_load_conservation_1253  1
    load_1_14_15  free_load_conservation_1259  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1024  -25
    arc_1_14_16  connected_order_arc_1025  -14
    arc_1_14_16  out_degree_1248  1
    arc_1_14_16  in_degree_1261  1
    arc_1_14_16  original_T_including_depot_unload_1300  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1024  1
    load_1_14_16  free_load_conservation_1253  1
    load_1_14_16  free_load_conservation_1265  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_1026  -25
    arc_1_14_17  connected_order_arc_1027  -14
    arc_1_14_17  out_degree_1248  1
    arc_1_14_17  in_degree_1267  1
    arc_1_14_17  original_T_including_depot_unload_1300  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_1026  1
    load_1_14_17  free_load_conservation_1253  1
    load_1_14_17  free_load_conservation_1271  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_1028  -25
    arc_1_14_18  connected_order_arc_1029  -14
    arc_1_14_18  out_degree_1248  1
    arc_1_14_18  in_degree_1273  1
    arc_1_14_18  original_T_including_depot_unload_1300  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_1028  1
    load_1_14_18  free_load_conservation_1253  1
    load_1_14_18  free_load_conservation_1277  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_1030  -25
    arc_1_14_19  connected_order_arc_1031  -14
    arc_1_14_19  out_degree_1248  1
    arc_1_14_19  in_degree_1279  1
    arc_1_14_19  original_T_including_depot_unload_1300  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_1030  1
    load_1_14_19  free_load_conservation_1253  1
    load_1_14_19  free_load_conservation_1283  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_1032  -25
    arc_1_14_20  connected_order_arc_1033  -14
    arc_1_14_20  out_degree_1248  1
    arc_1_14_20  in_degree_1285  1
    arc_1_14_20  original_T_including_depot_unload_1300  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_1032  1
    load_1_14_20  free_load_conservation_1253  1
    load_1_14_20  free_load_conservation_1289  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_21  arc_capacity_1034  -25
    arc_1_14_21  connected_order_arc_1035  -14
    arc_1_14_21  out_degree_1248  1
    arc_1_14_21  in_degree_1291  1
    arc_1_14_21  original_T_including_depot_unload_1300  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_14_21  arc_capacity_1034  1
    load_1_14_21  free_load_conservation_1253  1
    load_1_14_21  free_load_conservation_1295  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1036  -25
    arc_1_15_0  depot_return_or_bypass_1212  1
    arc_1_15_0  out_degree_1254  1
    arc_1_15_0  original_T_including_depot_unload_1300  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1036  1
    load_1_15_0  free_load_conservation_1259  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_1037  -25
    arc_1_15_6  connected_order_arc_1038  -14
    arc_1_15_6  in_degree_1214  1
    arc_1_15_6  out_degree_1254  1
    arc_1_15_6  original_T_including_depot_unload_1300  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_1037  1
    load_1_15_6  segment_load_conservation_1217  -1
    load_1_15_6  segment_prefix_lb_1218  1
    load_1_15_6  segment_prefix_ub_1219  1
    load_1_15_6  free_load_conservation_1259  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1039  -25
    arc_1_15_7  connected_order_arc_1040  -14
    arc_1_15_7  in_degree_1221  1
    arc_1_15_7  out_degree_1254  1
    arc_1_15_7  original_T_including_depot_unload_1300  8.2035300709080423e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1039  1
    load_1_15_7  segment_load_conservation_1224  -1
    load_1_15_7  segment_prefix_lb_1225  1
    load_1_15_7  segment_prefix_ub_1226  1
    load_1_15_7  free_load_conservation_1259  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1041  -25
    arc_1_15_8  connected_order_arc_1042  -14
    arc_1_15_8  in_degree_1228  1
    arc_1_15_8  out_degree_1254  1
    arc_1_15_8  original_T_including_depot_unload_1300  9.7692852841087415e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1041  1
    load_1_15_8  segment_load_conservation_1231  -1
    load_1_15_8  segment_prefix_lb_1232  1
    load_1_15_8  segment_prefix_ub_1233  1
    load_1_15_8  free_load_conservation_1259  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1043  -25
    arc_1_15_9  connected_order_arc_1044  -14
    arc_1_15_9  in_degree_1235  1
    arc_1_15_9  out_degree_1254  1
    arc_1_15_9  original_T_including_depot_unload_1300  1.3197014959146461e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1043  1
    load_1_15_9  segment_load_conservation_1238  -1
    load_1_15_9  segment_prefix_lb_1239  1
    load_1_15_9  segment_prefix_ub_1240  1
    load_1_15_9  free_load_conservation_1259  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1045  -25
    arc_1_15_10  connected_order_arc_1046  -14
    arc_1_15_10  in_degree_1242  1
    arc_1_15_10  out_degree_1254  1
    arc_1_15_10  original_T_including_depot_unload_1300  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1045  1
    load_1_15_10  segment_load_conservation_1245  -1
    load_1_15_10  segment_prefix_lb_1246  1
    load_1_15_10  segment_prefix_ub_1247  1
    load_1_15_10  free_load_conservation_1259  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1047  -25
    arc_1_15_14  connected_order_arc_1048  -14
    arc_1_15_14  in_degree_1249  1
    arc_1_15_14  out_degree_1254  1
    arc_1_15_14  original_T_including_depot_unload_1300  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1047  1
    load_1_15_14  free_load_conservation_1253  -1
    load_1_15_14  free_load_conservation_1259  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1049  -25
    arc_1_15_16  connected_order_arc_1050  -14
    arc_1_15_16  out_degree_1254  1
    arc_1_15_16  in_degree_1261  1
    arc_1_15_16  original_T_including_depot_unload_1300  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1049  1
    load_1_15_16  free_load_conservation_1259  1
    load_1_15_16  free_load_conservation_1265  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1051  -25
    arc_1_15_17  connected_order_arc_1052  -14
    arc_1_15_17  out_degree_1254  1
    arc_1_15_17  in_degree_1267  1
    arc_1_15_17  original_T_including_depot_unload_1300  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1051  1
    load_1_15_17  free_load_conservation_1259  1
    load_1_15_17  free_load_conservation_1271  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1053  -25
    arc_1_15_18  connected_order_arc_1054  -14
    arc_1_15_18  out_degree_1254  1
    arc_1_15_18  in_degree_1273  1
    arc_1_15_18  original_T_including_depot_unload_1300  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1053  1
    load_1_15_18  free_load_conservation_1259  1
    load_1_15_18  free_load_conservation_1277  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1055  -25
    arc_1_15_19  connected_order_arc_1056  -14
    arc_1_15_19  out_degree_1254  1
    arc_1_15_19  in_degree_1279  1
    arc_1_15_19  original_T_including_depot_unload_1300  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1055  1
    load_1_15_19  free_load_conservation_1259  1
    load_1_15_19  free_load_conservation_1283  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1057  -25
    arc_1_15_20  connected_order_arc_1058  -14
    arc_1_15_20  out_degree_1254  1
    arc_1_15_20  in_degree_1285  1
    arc_1_15_20  original_T_including_depot_unload_1300  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1057  1
    load_1_15_20  free_load_conservation_1259  1
    load_1_15_20  free_load_conservation_1289  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_1059  -25
    arc_1_15_21  connected_order_arc_1060  -14
    arc_1_15_21  out_degree_1254  1
    arc_1_15_21  in_degree_1291  1
    arc_1_15_21  original_T_including_depot_unload_1300  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_1059  1
    load_1_15_21  free_load_conservation_1259  1
    load_1_15_21  free_load_conservation_1295  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1061  -25
    arc_1_16_0  depot_return_or_bypass_1212  1
    arc_1_16_0  out_degree_1260  1
    arc_1_16_0  original_T_including_depot_unload_1300  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1061  1
    load_1_16_0  free_load_conservation_1265  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_1062  -25
    arc_1_16_6  connected_order_arc_1063  -14
    arc_1_16_6  in_degree_1214  1
    arc_1_16_6  out_degree_1260  1
    arc_1_16_6  original_T_including_depot_unload_1300  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_1062  1
    load_1_16_6  segment_load_conservation_1217  -1
    load_1_16_6  segment_prefix_lb_1218  1
    load_1_16_6  segment_prefix_ub_1219  1
    load_1_16_6  free_load_conservation_1265  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1064  -25
    arc_1_16_7  connected_order_arc_1065  -14
    arc_1_16_7  in_degree_1221  1
    arc_1_16_7  out_degree_1260  1
    arc_1_16_7  original_T_including_depot_unload_1300  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1064  1
    load_1_16_7  segment_load_conservation_1224  -1
    load_1_16_7  segment_prefix_lb_1225  1
    load_1_16_7  segment_prefix_ub_1226  1
    load_1_16_7  free_load_conservation_1265  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1066  -25
    arc_1_16_8  connected_order_arc_1067  -14
    arc_1_16_8  in_degree_1228  1
    arc_1_16_8  out_degree_1260  1
    arc_1_16_8  original_T_including_depot_unload_1300  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1066  1
    load_1_16_8  segment_load_conservation_1231  -1
    load_1_16_8  segment_prefix_lb_1232  1
    load_1_16_8  segment_prefix_ub_1233  1
    load_1_16_8  free_load_conservation_1265  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1068  -25
    arc_1_16_9  connected_order_arc_1069  -14
    arc_1_16_9  in_degree_1235  1
    arc_1_16_9  out_degree_1260  1
    arc_1_16_9  original_T_including_depot_unload_1300  2.5950001064050621e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1068  1
    load_1_16_9  segment_load_conservation_1238  -1
    load_1_16_9  segment_prefix_lb_1239  1
    load_1_16_9  segment_prefix_ub_1240  1
    load_1_16_9  free_load_conservation_1265  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1070  -25
    arc_1_16_10  connected_order_arc_1071  -14
    arc_1_16_10  in_degree_1242  1
    arc_1_16_10  out_degree_1260  1
    arc_1_16_10  original_T_including_depot_unload_1300  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1070  1
    load_1_16_10  segment_load_conservation_1245  -1
    load_1_16_10  segment_prefix_lb_1246  1
    load_1_16_10  segment_prefix_ub_1247  1
    load_1_16_10  free_load_conservation_1265  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1072  -25
    arc_1_16_14  connected_order_arc_1073  -14
    arc_1_16_14  in_degree_1249  1
    arc_1_16_14  out_degree_1260  1
    arc_1_16_14  original_T_including_depot_unload_1300  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1072  1
    load_1_16_14  free_load_conservation_1253  -1
    load_1_16_14  free_load_conservation_1265  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1074  -25
    arc_1_16_15  connected_order_arc_1075  -14
    arc_1_16_15  in_degree_1255  1
    arc_1_16_15  out_degree_1260  1
    arc_1_16_15  original_T_including_depot_unload_1300  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1074  1
    load_1_16_15  free_load_conservation_1259  -1
    load_1_16_15  free_load_conservation_1265  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1076  -25
    arc_1_16_17  connected_order_arc_1077  -14
    arc_1_16_17  out_degree_1260  1
    arc_1_16_17  in_degree_1267  1
    arc_1_16_17  original_T_including_depot_unload_1300  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1076  1
    load_1_16_17  free_load_conservation_1265  1
    load_1_16_17  free_load_conservation_1271  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1078  -25
    arc_1_16_18  connected_order_arc_1079  -14
    arc_1_16_18  out_degree_1260  1
    arc_1_16_18  in_degree_1273  1
    arc_1_16_18  original_T_including_depot_unload_1300  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1078  1
    load_1_16_18  free_load_conservation_1265  1
    load_1_16_18  free_load_conservation_1277  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1080  -25
    arc_1_16_19  connected_order_arc_1081  -14
    arc_1_16_19  out_degree_1260  1
    arc_1_16_19  in_degree_1279  1
    arc_1_16_19  original_T_including_depot_unload_1300  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1080  1
    load_1_16_19  free_load_conservation_1265  1
    load_1_16_19  free_load_conservation_1283  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1082  -25
    arc_1_16_20  connected_order_arc_1083  -14
    arc_1_16_20  out_degree_1260  1
    arc_1_16_20  in_degree_1285  1
    arc_1_16_20  original_T_including_depot_unload_1300  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1082  1
    load_1_16_20  free_load_conservation_1265  1
    load_1_16_20  free_load_conservation_1289  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1084  -25
    arc_1_16_21  connected_order_arc_1085  -14
    arc_1_16_21  out_degree_1260  1
    arc_1_16_21  in_degree_1291  1
    arc_1_16_21  original_T_including_depot_unload_1300  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1084  1
    load_1_16_21  free_load_conservation_1265  1
    load_1_16_21  free_load_conservation_1295  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1086  -25
    arc_1_17_0  depot_return_or_bypass_1212  1
    arc_1_17_0  out_degree_1266  1
    arc_1_17_0  original_T_including_depot_unload_1300  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1086  1
    load_1_17_0  free_load_conservation_1271  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1087  -25
    arc_1_17_6  connected_order_arc_1088  -14
    arc_1_17_6  in_degree_1214  1
    arc_1_17_6  out_degree_1266  1
    arc_1_17_6  original_T_including_depot_unload_1300  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1087  1
    load_1_17_6  segment_load_conservation_1217  -1
    load_1_17_6  segment_prefix_lb_1218  1
    load_1_17_6  segment_prefix_ub_1219  1
    load_1_17_6  free_load_conservation_1271  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1089  -25
    arc_1_17_7  connected_order_arc_1090  -14
    arc_1_17_7  in_degree_1221  1
    arc_1_17_7  out_degree_1266  1
    arc_1_17_7  original_T_including_depot_unload_1300  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1089  1
    load_1_17_7  segment_load_conservation_1224  -1
    load_1_17_7  segment_prefix_lb_1225  1
    load_1_17_7  segment_prefix_ub_1226  1
    load_1_17_7  free_load_conservation_1271  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1091  -25
    arc_1_17_8  connected_order_arc_1092  -14
    arc_1_17_8  in_degree_1228  1
    arc_1_17_8  out_degree_1266  1
    arc_1_17_8  original_T_including_depot_unload_1300  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1091  1
    load_1_17_8  segment_load_conservation_1231  -1
    load_1_17_8  segment_prefix_lb_1232  1
    load_1_17_8  segment_prefix_ub_1233  1
    load_1_17_8  free_load_conservation_1271  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1093  -25
    arc_1_17_9  connected_order_arc_1094  -14
    arc_1_17_9  in_degree_1235  1
    arc_1_17_9  out_degree_1266  1
    arc_1_17_9  original_T_including_depot_unload_1300  1.2213551686272770e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1093  1
    load_1_17_9  segment_load_conservation_1238  -1
    load_1_17_9  segment_prefix_lb_1239  1
    load_1_17_9  segment_prefix_ub_1240  1
    load_1_17_9  free_load_conservation_1271  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1095  -25
    arc_1_17_10  connected_order_arc_1096  -14
    arc_1_17_10  in_degree_1242  1
    arc_1_17_10  out_degree_1266  1
    arc_1_17_10  original_T_including_depot_unload_1300  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1095  1
    load_1_17_10  segment_load_conservation_1245  -1
    load_1_17_10  segment_prefix_lb_1246  1
    load_1_17_10  segment_prefix_ub_1247  1
    load_1_17_10  free_load_conservation_1271  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1097  -25
    arc_1_17_14  connected_order_arc_1098  -14
    arc_1_17_14  in_degree_1249  1
    arc_1_17_14  out_degree_1266  1
    arc_1_17_14  original_T_including_depot_unload_1300  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1097  1
    load_1_17_14  free_load_conservation_1253  -1
    load_1_17_14  free_load_conservation_1271  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1099  -25
    arc_1_17_15  connected_order_arc_1100  -14
    arc_1_17_15  in_degree_1255  1
    arc_1_17_15  out_degree_1266  1
    arc_1_17_15  original_T_including_depot_unload_1300  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1099  1
    load_1_17_15  free_load_conservation_1259  -1
    load_1_17_15  free_load_conservation_1271  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1101  -25
    arc_1_17_16  connected_order_arc_1102  -14
    arc_1_17_16  in_degree_1261  1
    arc_1_17_16  out_degree_1266  1
    arc_1_17_16  original_T_including_depot_unload_1300  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1101  1
    load_1_17_16  free_load_conservation_1265  -1
    load_1_17_16  free_load_conservation_1271  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1103  -25
    arc_1_17_18  connected_order_arc_1104  -14
    arc_1_17_18  out_degree_1266  1
    arc_1_17_18  in_degree_1273  1
    arc_1_17_18  original_T_including_depot_unload_1300  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1103  1
    load_1_17_18  free_load_conservation_1271  1
    load_1_17_18  free_load_conservation_1277  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1105  -25
    arc_1_17_19  connected_order_arc_1106  -14
    arc_1_17_19  out_degree_1266  1
    arc_1_17_19  in_degree_1279  1
    arc_1_17_19  original_T_including_depot_unload_1300  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1105  1
    load_1_17_19  free_load_conservation_1271  1
    load_1_17_19  free_load_conservation_1283  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1107  -25
    arc_1_17_20  connected_order_arc_1108  -14
    arc_1_17_20  out_degree_1266  1
    arc_1_17_20  in_degree_1285  1
    arc_1_17_20  original_T_including_depot_unload_1300  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1107  1
    load_1_17_20  free_load_conservation_1271  1
    load_1_17_20  free_load_conservation_1289  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1109  -25
    arc_1_17_21  connected_order_arc_1110  -14
    arc_1_17_21  out_degree_1266  1
    arc_1_17_21  in_degree_1291  1
    arc_1_17_21  original_T_including_depot_unload_1300  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1109  1
    load_1_17_21  free_load_conservation_1271  1
    load_1_17_21  free_load_conservation_1295  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1111  -25
    arc_1_18_0  depot_return_or_bypass_1212  1
    arc_1_18_0  out_degree_1272  1
    arc_1_18_0  original_T_including_depot_unload_1300  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1111  1
    load_1_18_0  free_load_conservation_1277  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1112  -25
    arc_1_18_6  connected_order_arc_1113  -14
    arc_1_18_6  in_degree_1214  1
    arc_1_18_6  out_degree_1272  1
    arc_1_18_6  original_T_including_depot_unload_1300  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1112  1
    load_1_18_6  segment_load_conservation_1217  -1
    load_1_18_6  segment_prefix_lb_1218  1
    load_1_18_6  segment_prefix_ub_1219  1
    load_1_18_6  free_load_conservation_1277  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1114  -25
    arc_1_18_7  connected_order_arc_1115  -14
    arc_1_18_7  in_degree_1221  1
    arc_1_18_7  out_degree_1272  1
    arc_1_18_7  original_T_including_depot_unload_1300  1.7211624454573559e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1114  1
    load_1_18_7  segment_load_conservation_1224  -1
    load_1_18_7  segment_prefix_lb_1225  1
    load_1_18_7  segment_prefix_ub_1226  1
    load_1_18_7  free_load_conservation_1277  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1116  -25
    arc_1_18_8  connected_order_arc_1117  -14
    arc_1_18_8  in_degree_1228  1
    arc_1_18_8  out_degree_1272  1
    arc_1_18_8  original_T_including_depot_unload_1300  1.7225744515697754e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1116  1
    load_1_18_8  segment_load_conservation_1231  -1
    load_1_18_8  segment_prefix_lb_1232  1
    load_1_18_8  segment_prefix_ub_1233  1
    load_1_18_8  free_load_conservation_1277  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1118  -25
    arc_1_18_9  connected_order_arc_1119  -14
    arc_1_18_9  in_degree_1235  1
    arc_1_18_9  out_degree_1272  1
    arc_1_18_9  original_T_including_depot_unload_1300  1.5711351987660353e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1118  1
    load_1_18_9  segment_load_conservation_1238  -1
    load_1_18_9  segment_prefix_lb_1239  1
    load_1_18_9  segment_prefix_ub_1240  1
    load_1_18_9  free_load_conservation_1277  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1120  -25
    arc_1_18_10  connected_order_arc_1121  -14
    arc_1_18_10  in_degree_1242  1
    arc_1_18_10  out_degree_1272  1
    arc_1_18_10  original_T_including_depot_unload_1300  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1120  1
    load_1_18_10  segment_load_conservation_1245  -1
    load_1_18_10  segment_prefix_lb_1246  1
    load_1_18_10  segment_prefix_ub_1247  1
    load_1_18_10  free_load_conservation_1277  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1122  -25
    arc_1_18_14  connected_order_arc_1123  -14
    arc_1_18_14  in_degree_1249  1
    arc_1_18_14  out_degree_1272  1
    arc_1_18_14  original_T_including_depot_unload_1300  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1122  1
    load_1_18_14  free_load_conservation_1253  -1
    load_1_18_14  free_load_conservation_1277  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1124  -25
    arc_1_18_15  connected_order_arc_1125  -14
    arc_1_18_15  in_degree_1255  1
    arc_1_18_15  out_degree_1272  1
    arc_1_18_15  original_T_including_depot_unload_1300  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1124  1
    load_1_18_15  free_load_conservation_1259  -1
    load_1_18_15  free_load_conservation_1277  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1126  -25
    arc_1_18_16  connected_order_arc_1127  -14
    arc_1_18_16  in_degree_1261  1
    arc_1_18_16  out_degree_1272  1
    arc_1_18_16  original_T_including_depot_unload_1300  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1126  1
    load_1_18_16  free_load_conservation_1265  -1
    load_1_18_16  free_load_conservation_1277  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1128  -25
    arc_1_18_17  connected_order_arc_1129  -14
    arc_1_18_17  in_degree_1267  1
    arc_1_18_17  out_degree_1272  1
    arc_1_18_17  original_T_including_depot_unload_1300  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1128  1
    load_1_18_17  free_load_conservation_1271  -1
    load_1_18_17  free_load_conservation_1277  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1130  -25
    arc_1_18_19  connected_order_arc_1131  -14
    arc_1_18_19  out_degree_1272  1
    arc_1_18_19  in_degree_1279  1
    arc_1_18_19  original_T_including_depot_unload_1300  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1130  1
    load_1_18_19  free_load_conservation_1277  1
    load_1_18_19  free_load_conservation_1283  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1132  -25
    arc_1_18_20  connected_order_arc_1133  -14
    arc_1_18_20  out_degree_1272  1
    arc_1_18_20  in_degree_1285  1
    arc_1_18_20  original_T_including_depot_unload_1300  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1132  1
    load_1_18_20  free_load_conservation_1277  1
    load_1_18_20  free_load_conservation_1289  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1134  -25
    arc_1_18_21  connected_order_arc_1135  -14
    arc_1_18_21  out_degree_1272  1
    arc_1_18_21  in_degree_1291  1
    arc_1_18_21  original_T_including_depot_unload_1300  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1134  1
    load_1_18_21  free_load_conservation_1277  1
    load_1_18_21  free_load_conservation_1295  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1136  -25
    arc_1_19_0  depot_return_or_bypass_1212  1
    arc_1_19_0  out_degree_1278  1
    arc_1_19_0  original_T_including_depot_unload_1300  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1136  1
    load_1_19_0  free_load_conservation_1283  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1137  -25
    arc_1_19_6  connected_order_arc_1138  -14
    arc_1_19_6  in_degree_1214  1
    arc_1_19_6  out_degree_1278  1
    arc_1_19_6  original_T_including_depot_unload_1300  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1137  1
    load_1_19_6  segment_load_conservation_1217  -1
    load_1_19_6  segment_prefix_lb_1218  1
    load_1_19_6  segment_prefix_ub_1219  1
    load_1_19_6  free_load_conservation_1283  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1139  -25
    arc_1_19_7  connected_order_arc_1140  -14
    arc_1_19_7  in_degree_1221  1
    arc_1_19_7  out_degree_1278  1
    arc_1_19_7  original_T_including_depot_unload_1300  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1139  1
    load_1_19_7  segment_load_conservation_1224  -1
    load_1_19_7  segment_prefix_lb_1225  1
    load_1_19_7  segment_prefix_ub_1226  1
    load_1_19_7  free_load_conservation_1283  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1141  -25
    arc_1_19_8  connected_order_arc_1142  -14
    arc_1_19_8  in_degree_1228  1
    arc_1_19_8  out_degree_1278  1
    arc_1_19_8  original_T_including_depot_unload_1300  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1141  1
    load_1_19_8  segment_load_conservation_1231  -1
    load_1_19_8  segment_prefix_lb_1232  1
    load_1_19_8  segment_prefix_ub_1233  1
    load_1_19_8  free_load_conservation_1283  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1143  -25
    arc_1_19_9  connected_order_arc_1144  -14
    arc_1_19_9  in_degree_1235  1
    arc_1_19_9  out_degree_1278  1
    arc_1_19_9  original_T_including_depot_unload_1300  9.5892865701726816e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1143  1
    load_1_19_9  segment_load_conservation_1238  -1
    load_1_19_9  segment_prefix_lb_1239  1
    load_1_19_9  segment_prefix_ub_1240  1
    load_1_19_9  free_load_conservation_1283  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_10  arc_capacity_1145  -25
    arc_1_19_10  connected_order_arc_1146  -14
    arc_1_19_10  in_degree_1242  1
    arc_1_19_10  out_degree_1278  1
    arc_1_19_10  original_T_including_depot_unload_1300  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_10  arc_capacity_1145  1
    load_1_19_10  segment_load_conservation_1245  -1
    load_1_19_10  segment_prefix_lb_1246  1
    load_1_19_10  segment_prefix_ub_1247  1
    load_1_19_10  free_load_conservation_1283  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1147  -25
    arc_1_19_14  connected_order_arc_1148  -14
    arc_1_19_14  in_degree_1249  1
    arc_1_19_14  out_degree_1278  1
    arc_1_19_14  original_T_including_depot_unload_1300  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1147  1
    load_1_19_14  free_load_conservation_1253  -1
    load_1_19_14  free_load_conservation_1283  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1149  -25
    arc_1_19_15  connected_order_arc_1150  -14
    arc_1_19_15  in_degree_1255  1
    arc_1_19_15  out_degree_1278  1
    arc_1_19_15  original_T_including_depot_unload_1300  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1149  1
    load_1_19_15  free_load_conservation_1259  -1
    load_1_19_15  free_load_conservation_1283  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1151  -25
    arc_1_19_16  connected_order_arc_1152  -14
    arc_1_19_16  in_degree_1261  1
    arc_1_19_16  out_degree_1278  1
    arc_1_19_16  original_T_including_depot_unload_1300  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1151  1
    load_1_19_16  free_load_conservation_1265  -1
    load_1_19_16  free_load_conservation_1283  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1153  -25
    arc_1_19_17  connected_order_arc_1154  -14
    arc_1_19_17  in_degree_1267  1
    arc_1_19_17  out_degree_1278  1
    arc_1_19_17  original_T_including_depot_unload_1300  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1153  1
    load_1_19_17  free_load_conservation_1271  -1
    load_1_19_17  free_load_conservation_1283  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1155  -25
    arc_1_19_18  connected_order_arc_1156  -14
    arc_1_19_18  in_degree_1273  1
    arc_1_19_18  out_degree_1278  1
    arc_1_19_18  original_T_including_depot_unload_1300  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1155  1
    load_1_19_18  free_load_conservation_1277  -1
    load_1_19_18  free_load_conservation_1283  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1157  -25
    arc_1_19_20  connected_order_arc_1158  -14
    arc_1_19_20  out_degree_1278  1
    arc_1_19_20  in_degree_1285  1
    arc_1_19_20  original_T_including_depot_unload_1300  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1157  1
    load_1_19_20  free_load_conservation_1283  1
    load_1_19_20  free_load_conservation_1289  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1159  -25
    arc_1_19_21  connected_order_arc_1160  -14
    arc_1_19_21  out_degree_1278  1
    arc_1_19_21  in_degree_1291  1
    arc_1_19_21  original_T_including_depot_unload_1300  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1159  1
    load_1_19_21  free_load_conservation_1283  1
    load_1_19_21  free_load_conservation_1295  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1161  -25
    arc_1_20_0  depot_return_or_bypass_1212  1
    arc_1_20_0  out_degree_1284  1
    arc_1_20_0  original_T_including_depot_unload_1300  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1161  1
    load_1_20_0  free_load_conservation_1289  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1162  -25
    arc_1_20_6  connected_order_arc_1163  -14
    arc_1_20_6  in_degree_1214  1
    arc_1_20_6  out_degree_1284  1
    arc_1_20_6  original_T_including_depot_unload_1300  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1162  1
    load_1_20_6  segment_load_conservation_1217  -1
    load_1_20_6  segment_prefix_lb_1218  1
    load_1_20_6  segment_prefix_ub_1219  1
    load_1_20_6  free_load_conservation_1289  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1164  -25
    arc_1_20_7  connected_order_arc_1165  -14
    arc_1_20_7  in_degree_1221  1
    arc_1_20_7  out_degree_1284  1
    arc_1_20_7  original_T_including_depot_unload_1300  1.1663816070445826e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1164  1
    load_1_20_7  segment_load_conservation_1224  -1
    load_1_20_7  segment_prefix_lb_1225  1
    load_1_20_7  segment_prefix_ub_1226  1
    load_1_20_7  free_load_conservation_1289  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1166  -25
    arc_1_20_8  connected_order_arc_1167  -14
    arc_1_20_8  in_degree_1228  1
    arc_1_20_8  out_degree_1284  1
    arc_1_20_8  original_T_including_depot_unload_1300  1.2100678255370710e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1166  1
    load_1_20_8  segment_load_conservation_1231  -1
    load_1_20_8  segment_prefix_lb_1232  1
    load_1_20_8  segment_prefix_ub_1233  1
    load_1_20_8  free_load_conservation_1289  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1168  -25
    arc_1_20_9  connected_order_arc_1169  -14
    arc_1_20_9  in_degree_1235  1
    arc_1_20_9  out_degree_1284  1
    arc_1_20_9  original_T_including_depot_unload_1300  1.2253808824170035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1168  1
    load_1_20_9  segment_load_conservation_1238  -1
    load_1_20_9  segment_prefix_lb_1239  1
    load_1_20_9  segment_prefix_ub_1240  1
    load_1_20_9  free_load_conservation_1289  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_10  arc_capacity_1170  -25
    arc_1_20_10  connected_order_arc_1171  -14
    arc_1_20_10  in_degree_1242  1
    arc_1_20_10  out_degree_1284  1
    arc_1_20_10  original_T_including_depot_unload_1300  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_10  arc_capacity_1170  1
    load_1_20_10  segment_load_conservation_1245  -1
    load_1_20_10  segment_prefix_lb_1246  1
    load_1_20_10  segment_prefix_ub_1247  1
    load_1_20_10  free_load_conservation_1289  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1172  -25
    arc_1_20_14  connected_order_arc_1173  -14
    arc_1_20_14  in_degree_1249  1
    arc_1_20_14  out_degree_1284  1
    arc_1_20_14  original_T_including_depot_unload_1300  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1172  1
    load_1_20_14  free_load_conservation_1253  -1
    load_1_20_14  free_load_conservation_1289  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1174  -25
    arc_1_20_15  connected_order_arc_1175  -14
    arc_1_20_15  in_degree_1255  1
    arc_1_20_15  out_degree_1284  1
    arc_1_20_15  original_T_including_depot_unload_1300  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1174  1
    load_1_20_15  free_load_conservation_1259  -1
    load_1_20_15  free_load_conservation_1289  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1176  -25
    arc_1_20_16  connected_order_arc_1177  -14
    arc_1_20_16  in_degree_1261  1
    arc_1_20_16  out_degree_1284  1
    arc_1_20_16  original_T_including_depot_unload_1300  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1176  1
    load_1_20_16  free_load_conservation_1265  -1
    load_1_20_16  free_load_conservation_1289  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1178  -25
    arc_1_20_17  connected_order_arc_1179  -14
    arc_1_20_17  in_degree_1267  1
    arc_1_20_17  out_degree_1284  1
    arc_1_20_17  original_T_including_depot_unload_1300  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1178  1
    load_1_20_17  free_load_conservation_1271  -1
    load_1_20_17  free_load_conservation_1289  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1180  -25
    arc_1_20_18  connected_order_arc_1181  -14
    arc_1_20_18  in_degree_1273  1
    arc_1_20_18  out_degree_1284  1
    arc_1_20_18  original_T_including_depot_unload_1300  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1180  1
    load_1_20_18  free_load_conservation_1277  -1
    load_1_20_18  free_load_conservation_1289  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1182  -25
    arc_1_20_19  connected_order_arc_1183  -14
    arc_1_20_19  in_degree_1279  1
    arc_1_20_19  out_degree_1284  1
    arc_1_20_19  original_T_including_depot_unload_1300  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1182  1
    load_1_20_19  free_load_conservation_1283  -1
    load_1_20_19  free_load_conservation_1289  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1184  -25
    arc_1_20_21  connected_order_arc_1185  -14
    arc_1_20_21  out_degree_1284  1
    arc_1_20_21  in_degree_1291  1
    arc_1_20_21  original_T_including_depot_unload_1300  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1184  1
    load_1_20_21  free_load_conservation_1289  1
    load_1_20_21  free_load_conservation_1295  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1186  -25
    arc_1_21_0  depot_return_or_bypass_1212  1
    arc_1_21_0  out_degree_1290  1
    arc_1_21_0  original_T_including_depot_unload_1300  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1186  1
    load_1_21_0  free_load_conservation_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_6  arc_capacity_1187  -25
    arc_1_21_6  connected_order_arc_1188  -14
    arc_1_21_6  in_degree_1214  1
    arc_1_21_6  out_degree_1290  1
    arc_1_21_6  original_T_including_depot_unload_1300  7.0141209816069022e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_6  arc_capacity_1187  1
    load_1_21_6  segment_load_conservation_1217  -1
    load_1_21_6  segment_prefix_lb_1218  1
    load_1_21_6  segment_prefix_ub_1219  1
    load_1_21_6  free_load_conservation_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1189  -25
    arc_1_21_7  connected_order_arc_1190  -14
    arc_1_21_7  in_degree_1221  1
    arc_1_21_7  out_degree_1290  1
    arc_1_21_7  original_T_including_depot_unload_1300  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1189  1
    load_1_21_7  segment_load_conservation_1224  -1
    load_1_21_7  segment_prefix_lb_1225  1
    load_1_21_7  segment_prefix_ub_1226  1
    load_1_21_7  free_load_conservation_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1191  -25
    arc_1_21_8  connected_order_arc_1192  -14
    arc_1_21_8  in_degree_1228  1
    arc_1_21_8  out_degree_1290  1
    arc_1_21_8  original_T_including_depot_unload_1300  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1191  1
    load_1_21_8  segment_load_conservation_1231  -1
    load_1_21_8  segment_prefix_lb_1232  1
    load_1_21_8  segment_prefix_ub_1233  1
    load_1_21_8  free_load_conservation_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1193  -25
    arc_1_21_9  connected_order_arc_1194  -14
    arc_1_21_9  in_degree_1235  1
    arc_1_21_9  out_degree_1290  1
    arc_1_21_9  original_T_including_depot_unload_1300  8.6289703303586691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1193  1
    load_1_21_9  segment_load_conservation_1238  -1
    load_1_21_9  segment_prefix_lb_1239  1
    load_1_21_9  segment_prefix_ub_1240  1
    load_1_21_9  free_load_conservation_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_10  arc_capacity_1195  -25
    arc_1_21_10  connected_order_arc_1196  -14
    arc_1_21_10  in_degree_1242  1
    arc_1_21_10  out_degree_1290  1
    arc_1_21_10  original_T_including_depot_unload_1300  8.5502565124349769e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_10  arc_capacity_1195  1
    load_1_21_10  segment_load_conservation_1245  -1
    load_1_21_10  segment_prefix_lb_1246  1
    load_1_21_10  segment_prefix_ub_1247  1
    load_1_21_10  free_load_conservation_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_14  arc_capacity_1197  -25
    arc_1_21_14  connected_order_arc_1198  -14
    arc_1_21_14  in_degree_1249  1
    arc_1_21_14  out_degree_1290  1
    arc_1_21_14  original_T_including_depot_unload_1300  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_21_14  arc_capacity_1197  1
    load_1_21_14  free_load_conservation_1253  -1
    load_1_21_14  free_load_conservation_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1199  -25
    arc_1_21_15  connected_order_arc_1200  -14
    arc_1_21_15  in_degree_1255  1
    arc_1_21_15  out_degree_1290  1
    arc_1_21_15  original_T_including_depot_unload_1300  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1199  1
    load_1_21_15  free_load_conservation_1259  -1
    load_1_21_15  free_load_conservation_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1201  -25
    arc_1_21_16  connected_order_arc_1202  -14
    arc_1_21_16  in_degree_1261  1
    arc_1_21_16  out_degree_1290  1
    arc_1_21_16  original_T_including_depot_unload_1300  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1201  1
    load_1_21_16  free_load_conservation_1265  -1
    load_1_21_16  free_load_conservation_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1203  -25
    arc_1_21_17  connected_order_arc_1204  -14
    arc_1_21_17  in_degree_1267  1
    arc_1_21_17  out_degree_1290  1
    arc_1_21_17  original_T_including_depot_unload_1300  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1203  1
    load_1_21_17  free_load_conservation_1271  -1
    load_1_21_17  free_load_conservation_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1205  -25
    arc_1_21_18  connected_order_arc_1206  -14
    arc_1_21_18  in_degree_1273  1
    arc_1_21_18  out_degree_1290  1
    arc_1_21_18  original_T_including_depot_unload_1300  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1205  1
    load_1_21_18  free_load_conservation_1277  -1
    load_1_21_18  free_load_conservation_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1207  -25
    arc_1_21_19  connected_order_arc_1208  -14
    arc_1_21_19  in_degree_1279  1
    arc_1_21_19  out_degree_1290  1
    arc_1_21_19  original_T_including_depot_unload_1300  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1207  1
    load_1_21_19  free_load_conservation_1283  -1
    load_1_21_19  free_load_conservation_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1209  -25
    arc_1_21_20  connected_order_arc_1210  -14
    arc_1_21_20  in_degree_1285  1
    arc_1_21_20  out_degree_1290  1
    arc_1_21_20  original_T_including_depot_unload_1300  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1209  1
    load_1_21_20  free_load_conservation_1289  -1
    load_1_21_20  free_load_conservation_1295  1
    visit_2_11  out_degree_1546  -1
    visit_2_11  in_degree_1547  -1
    visit_2_11  order_active_lb_1548  -1
    visit_2_11  order_active_ub_1549  -11
    order_2_11  connected_order_arc_1315  -1
    order_2_11  connected_order_arc_1317  -1
    order_2_11  connected_order_arc_1319  -1
    order_2_11  connected_order_arc_1321  -1
    order_2_11  connected_order_arc_1323  -1
    order_2_11  connected_order_arc_1325  -1
    order_2_11  connected_order_arc_1327  -1
    order_2_11  connected_order_arc_1329  -1
    order_2_11  connected_order_arc_1331  -1
    order_2_11  connected_order_arc_1333  -1
    order_2_11  connected_order_arc_1336  1
    order_2_11  connected_order_arc_1357  1
    order_2_11  connected_order_arc_1378  1
    order_2_11  connected_order_arc_1399  1
    order_2_11  connected_order_arc_1420  1
    order_2_11  connected_order_arc_1441  1
    order_2_11  connected_order_arc_1462  1
    order_2_11  connected_order_arc_1483  1
    order_2_11  connected_order_arc_1504  1
    order_2_11  connected_order_arc_1525  1
    order_2_11  order_active_lb_1548  1
    order_2_11  order_active_ub_1549  1
    order_2_11  fixed_segment_relative_order_1615  -1
    visit_2_12  out_degree_1553  -1
    visit_2_12  in_degree_1554  -1
    visit_2_12  order_active_lb_1555  -1
    visit_2_12  order_active_ub_1556  -11
    order_2_12  connected_order_arc_1315  1
    order_2_12  connected_order_arc_1336  -1
    order_2_12  connected_order_arc_1338  -1
    order_2_12  connected_order_arc_1340  -1
    order_2_12  connected_order_arc_1342  -1
    order_2_12  connected_order_arc_1344  -1
    order_2_12  connected_order_arc_1346  -1
    order_2_12  connected_order_arc_1348  -1
    order_2_12  connected_order_arc_1350  -1
    order_2_12  connected_order_arc_1352  -1
    order_2_12  connected_order_arc_1354  -1
    order_2_12  connected_order_arc_1359  1
    order_2_12  connected_order_arc_1380  1
    order_2_12  connected_order_arc_1401  1
    order_2_12  connected_order_arc_1422  1
    order_2_12  connected_order_arc_1443  1
    order_2_12  connected_order_arc_1464  1
    order_2_12  connected_order_arc_1485  1
    order_2_12  connected_order_arc_1506  1
    order_2_12  connected_order_arc_1527  1
    order_2_12  order_active_lb_1555  1
    order_2_12  order_active_ub_1556  1
    order_2_12  fixed_segment_relative_order_1615  1
    order_2_12  fixed_segment_relative_order_1616  -1
    visit_2_13  out_degree_1560  -1
    visit_2_13  in_degree_1561  -1
    visit_2_13  order_active_lb_1562  -1
    visit_2_13  order_active_ub_1563  -11
    order_2_13  connected_order_arc_1317  1
    order_2_13  connected_order_arc_1338  1
    order_2_13  connected_order_arc_1357  -1
    order_2_13  connected_order_arc_1359  -1
    order_2_13  connected_order_arc_1361  -1
    order_2_13  connected_order_arc_1363  -1
    order_2_13  connected_order_arc_1365  -1
    order_2_13  connected_order_arc_1367  -1
    order_2_13  connected_order_arc_1369  -1
    order_2_13  connected_order_arc_1371  -1
    order_2_13  connected_order_arc_1373  -1
    order_2_13  connected_order_arc_1375  -1
    order_2_13  connected_order_arc_1382  1
    order_2_13  connected_order_arc_1403  1
    order_2_13  connected_order_arc_1424  1
    order_2_13  connected_order_arc_1445  1
    order_2_13  connected_order_arc_1466  1
    order_2_13  connected_order_arc_1487  1
    order_2_13  connected_order_arc_1508  1
    order_2_13  connected_order_arc_1529  1
    order_2_13  order_active_lb_1562  1
    order_2_13  order_active_ub_1563  1
    order_2_13  fixed_segment_relative_order_1616  1
    visit_2_14  out_degree_1567  -1
    visit_2_14  in_degree_1568  -1
    visit_2_14  order_active_lb_1569  -1
    visit_2_14  order_active_ub_1570  -11
    visit_2_14  service_visit_def_1571  -1
    order_2_14  connected_order_arc_1319  1
    order_2_14  connected_order_arc_1340  1
    order_2_14  connected_order_arc_1361  1
    order_2_14  connected_order_arc_1378  -1
    order_2_14  connected_order_arc_1380  -1
    order_2_14  connected_order_arc_1382  -1
    order_2_14  connected_order_arc_1384  -1
    order_2_14  connected_order_arc_1386  -1
    order_2_14  connected_order_arc_1388  -1
    order_2_14  connected_order_arc_1390  -1
    order_2_14  connected_order_arc_1392  -1
    order_2_14  connected_order_arc_1394  -1
    order_2_14  connected_order_arc_1396  -1
    order_2_14  connected_order_arc_1405  1
    order_2_14  connected_order_arc_1426  1
    order_2_14  connected_order_arc_1447  1
    order_2_14  connected_order_arc_1468  1
    order_2_14  connected_order_arc_1489  1
    order_2_14  connected_order_arc_1510  1
    order_2_14  connected_order_arc_1531  1
    order_2_14  order_active_lb_1569  1
    order_2_14  order_active_ub_1570  1
    visit_2_15  out_degree_1573  -1
    visit_2_15  in_degree_1574  -1
    visit_2_15  order_active_lb_1575  -1
    visit_2_15  order_active_ub_1576  -11
    visit_2_15  service_visit_def_1577  -1
    order_2_15  connected_order_arc_1321  1
    order_2_15  connected_order_arc_1342  1
    order_2_15  connected_order_arc_1363  1
    order_2_15  connected_order_arc_1384  1
    order_2_15  connected_order_arc_1399  -1
    order_2_15  connected_order_arc_1401  -1
    order_2_15  connected_order_arc_1403  -1
    order_2_15  connected_order_arc_1405  -1
    order_2_15  connected_order_arc_1407  -1
    order_2_15  connected_order_arc_1409  -1
    order_2_15  connected_order_arc_1411  -1
    order_2_15  connected_order_arc_1413  -1
    order_2_15  connected_order_arc_1415  -1
    order_2_15  connected_order_arc_1417  -1
    order_2_15  connected_order_arc_1428  1
    order_2_15  connected_order_arc_1449  1
    order_2_15  connected_order_arc_1470  1
    order_2_15  connected_order_arc_1491  1
    order_2_15  connected_order_arc_1512  1
    order_2_15  connected_order_arc_1533  1
    order_2_15  order_active_lb_1575  1
    order_2_15  order_active_ub_1576  1
    visit_2_16  out_degree_1579  -1
    visit_2_16  in_degree_1580  -1
    visit_2_16  order_active_lb_1581  -1
    visit_2_16  order_active_ub_1582  -11
    visit_2_16  service_visit_def_1583  -1
    order_2_16  connected_order_arc_1323  1
    order_2_16  connected_order_arc_1344  1
    order_2_16  connected_order_arc_1365  1
    order_2_16  connected_order_arc_1386  1
    order_2_16  connected_order_arc_1407  1
    order_2_16  connected_order_arc_1420  -1
    order_2_16  connected_order_arc_1422  -1
    order_2_16  connected_order_arc_1424  -1
    order_2_16  connected_order_arc_1426  -1
    order_2_16  connected_order_arc_1428  -1
    order_2_16  connected_order_arc_1430  -1
    order_2_16  connected_order_arc_1432  -1
    order_2_16  connected_order_arc_1434  -1
    order_2_16  connected_order_arc_1436  -1
    order_2_16  connected_order_arc_1438  -1
    order_2_16  connected_order_arc_1451  1
    order_2_16  connected_order_arc_1472  1
    order_2_16  connected_order_arc_1493  1
    order_2_16  connected_order_arc_1514  1
    order_2_16  connected_order_arc_1535  1
    order_2_16  order_active_lb_1581  1
    order_2_16  order_active_ub_1582  1
    visit_2_17  out_degree_1585  -1
    visit_2_17  in_degree_1586  -1
    visit_2_17  order_active_lb_1587  -1
    visit_2_17  order_active_ub_1588  -11
    visit_2_17  service_visit_def_1589  -1
    order_2_17  connected_order_arc_1325  1
    order_2_17  connected_order_arc_1346  1
    order_2_17  connected_order_arc_1367  1
    order_2_17  connected_order_arc_1388  1
    order_2_17  connected_order_arc_1409  1
    order_2_17  connected_order_arc_1430  1
    order_2_17  connected_order_arc_1441  -1
    order_2_17  connected_order_arc_1443  -1
    order_2_17  connected_order_arc_1445  -1
    order_2_17  connected_order_arc_1447  -1
    order_2_17  connected_order_arc_1449  -1
    order_2_17  connected_order_arc_1451  -1
    order_2_17  connected_order_arc_1453  -1
    order_2_17  connected_order_arc_1455  -1
    order_2_17  connected_order_arc_1457  -1
    order_2_17  connected_order_arc_1459  -1
    order_2_17  connected_order_arc_1474  1
    order_2_17  connected_order_arc_1495  1
    order_2_17  connected_order_arc_1516  1
    order_2_17  connected_order_arc_1537  1
    order_2_17  order_active_lb_1587  1
    order_2_17  order_active_ub_1588  1
    visit_2_18  out_degree_1591  -1
    visit_2_18  in_degree_1592  -1
    visit_2_18  order_active_lb_1593  -1
    visit_2_18  order_active_ub_1594  -11
    visit_2_18  service_visit_def_1595  -1
    order_2_18  connected_order_arc_1327  1
    order_2_18  connected_order_arc_1348  1
    order_2_18  connected_order_arc_1369  1
    order_2_18  connected_order_arc_1390  1
    order_2_18  connected_order_arc_1411  1
    order_2_18  connected_order_arc_1432  1
    order_2_18  connected_order_arc_1453  1
    order_2_18  connected_order_arc_1462  -1
    order_2_18  connected_order_arc_1464  -1
    order_2_18  connected_order_arc_1466  -1
    order_2_18  connected_order_arc_1468  -1
    order_2_18  connected_order_arc_1470  -1
    order_2_18  connected_order_arc_1472  -1
    order_2_18  connected_order_arc_1474  -1
    order_2_18  connected_order_arc_1476  -1
    order_2_18  connected_order_arc_1478  -1
    order_2_18  connected_order_arc_1480  -1
    order_2_18  connected_order_arc_1497  1
    order_2_18  connected_order_arc_1518  1
    order_2_18  connected_order_arc_1539  1
    order_2_18  order_active_lb_1593  1
    order_2_18  order_active_ub_1594  1
    visit_2_19  out_degree_1597  -1
    visit_2_19  in_degree_1598  -1
    visit_2_19  order_active_lb_1599  -1
    visit_2_19  order_active_ub_1600  -11
    visit_2_19  service_visit_def_1601  -1
    order_2_19  connected_order_arc_1329  1
    order_2_19  connected_order_arc_1350  1
    order_2_19  connected_order_arc_1371  1
    order_2_19  connected_order_arc_1392  1
    order_2_19  connected_order_arc_1413  1
    order_2_19  connected_order_arc_1434  1
    order_2_19  connected_order_arc_1455  1
    order_2_19  connected_order_arc_1476  1
    order_2_19  connected_order_arc_1483  -1
    order_2_19  connected_order_arc_1485  -1
    order_2_19  connected_order_arc_1487  -1
    order_2_19  connected_order_arc_1489  -1
    order_2_19  connected_order_arc_1491  -1
    order_2_19  connected_order_arc_1493  -1
    order_2_19  connected_order_arc_1495  -1
    order_2_19  connected_order_arc_1497  -1
    order_2_19  connected_order_arc_1499  -1
    order_2_19  connected_order_arc_1501  -1
    order_2_19  connected_order_arc_1520  1
    order_2_19  connected_order_arc_1541  1
    order_2_19  order_active_lb_1599  1
    order_2_19  order_active_ub_1600  1
    visit_2_20  out_degree_1603  -1
    visit_2_20  in_degree_1604  -1
    visit_2_20  order_active_lb_1605  -1
    visit_2_20  order_active_ub_1606  -11
    visit_2_20  service_visit_def_1607  -1
    order_2_20  connected_order_arc_1331  1
    order_2_20  connected_order_arc_1352  1
    order_2_20  connected_order_arc_1373  1
    order_2_20  connected_order_arc_1394  1
    order_2_20  connected_order_arc_1415  1
    order_2_20  connected_order_arc_1436  1
    order_2_20  connected_order_arc_1457  1
    order_2_20  connected_order_arc_1478  1
    order_2_20  connected_order_arc_1499  1
    order_2_20  connected_order_arc_1504  -1
    order_2_20  connected_order_arc_1506  -1
    order_2_20  connected_order_arc_1508  -1
    order_2_20  connected_order_arc_1510  -1
    order_2_20  connected_order_arc_1512  -1
    order_2_20  connected_order_arc_1514  -1
    order_2_20  connected_order_arc_1516  -1
    order_2_20  connected_order_arc_1518  -1
    order_2_20  connected_order_arc_1520  -1
    order_2_20  connected_order_arc_1522  -1
    order_2_20  connected_order_arc_1543  1
    order_2_20  order_active_lb_1605  1
    order_2_20  order_active_ub_1606  1
    visit_2_21  out_degree_1609  -1
    visit_2_21  in_degree_1610  -1
    visit_2_21  order_active_lb_1611  -1
    visit_2_21  order_active_ub_1612  -11
    visit_2_21  service_visit_def_1613  -1
    order_2_21  connected_order_arc_1333  1
    order_2_21  connected_order_arc_1354  1
    order_2_21  connected_order_arc_1375  1
    order_2_21  connected_order_arc_1396  1
    order_2_21  connected_order_arc_1417  1
    order_2_21  connected_order_arc_1438  1
    order_2_21  connected_order_arc_1459  1
    order_2_21  connected_order_arc_1480  1
    order_2_21  connected_order_arc_1501  1
    order_2_21  connected_order_arc_1522  1
    order_2_21  connected_order_arc_1525  -1
    order_2_21  connected_order_arc_1527  -1
    order_2_21  connected_order_arc_1529  -1
    order_2_21  connected_order_arc_1531  -1
    order_2_21  connected_order_arc_1533  -1
    order_2_21  connected_order_arc_1535  -1
    order_2_21  connected_order_arc_1537  -1
    order_2_21  connected_order_arc_1539  -1
    order_2_21  connected_order_arc_1541  -1
    order_2_21  connected_order_arc_1543  -1
    order_2_21  order_active_lb_1611  1
    order_2_21  order_active_ub_1612  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1301  -30
    arc_2_0_0  depot_departure_or_bypass_1544  1
    arc_2_0_0  depot_return_or_bypass_1545  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1301  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1302  -30
    arc_2_0_11  depot_departure_or_bypass_1544  1
    arc_2_0_11  in_degree_1547  1
    arc_2_0_11  original_T_including_depot_unload_1617  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1302  1
    load_2_0_11  segment_load_conservation_1550  -1
    load_2_0_11  segment_prefix_lb_1551  1
    load_2_0_11  segment_prefix_ub_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1303  -30
    arc_2_0_12  depot_departure_or_bypass_1544  1
    arc_2_0_12  in_degree_1554  1
    arc_2_0_12  original_T_including_depot_unload_1617  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1303  1
    load_2_0_12  segment_load_conservation_1557  -1
    load_2_0_12  segment_prefix_lb_1558  1
    load_2_0_12  segment_prefix_ub_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1304  -30
    arc_2_0_13  depot_departure_or_bypass_1544  1
    arc_2_0_13  in_degree_1561  1
    arc_2_0_13  original_T_including_depot_unload_1617  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1304  1
    load_2_0_13  segment_load_conservation_1564  -1
    load_2_0_13  segment_prefix_lb_1565  1
    load_2_0_13  segment_prefix_ub_1566  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1305  -30
    arc_2_0_14  depot_departure_or_bypass_1544  1
    arc_2_0_14  in_degree_1568  1
    arc_2_0_14  original_T_including_depot_unload_1617  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1305  1
    load_2_0_14  free_load_conservation_1572  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1306  -30
    arc_2_0_15  depot_departure_or_bypass_1544  1
    arc_2_0_15  in_degree_1574  1
    arc_2_0_15  original_T_including_depot_unload_1617  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1306  1
    load_2_0_15  free_load_conservation_1578  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1307  -30
    arc_2_0_16  depot_departure_or_bypass_1544  1
    arc_2_0_16  in_degree_1580  1
    arc_2_0_16  original_T_including_depot_unload_1617  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1307  1
    load_2_0_16  free_load_conservation_1584  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1308  -30
    arc_2_0_17  depot_departure_or_bypass_1544  1
    arc_2_0_17  in_degree_1586  1
    arc_2_0_17  original_T_including_depot_unload_1617  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1308  1
    load_2_0_17  free_load_conservation_1590  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1309  -30
    arc_2_0_18  depot_departure_or_bypass_1544  1
    arc_2_0_18  in_degree_1592  1
    arc_2_0_18  original_T_including_depot_unload_1617  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1309  1
    load_2_0_18  free_load_conservation_1596  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1310  -30
    arc_2_0_19  depot_departure_or_bypass_1544  1
    arc_2_0_19  in_degree_1598  1
    arc_2_0_19  original_T_including_depot_unload_1617  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1310  1
    load_2_0_19  free_load_conservation_1602  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1311  -30
    arc_2_0_20  depot_departure_or_bypass_1544  1
    arc_2_0_20  in_degree_1604  1
    arc_2_0_20  original_T_including_depot_unload_1617  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1311  1
    load_2_0_20  free_load_conservation_1608  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1312  -30
    arc_2_0_21  depot_departure_or_bypass_1544  1
    arc_2_0_21  in_degree_1610  1
    arc_2_0_21  original_T_including_depot_unload_1617  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1312  1
    load_2_0_21  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1313  -30
    arc_2_11_0  depot_return_or_bypass_1545  1
    arc_2_11_0  out_degree_1546  1
    arc_2_11_0  original_T_including_depot_unload_1617  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1313  1
    load_2_11_0  segment_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1314  -30
    arc_2_11_12  connected_order_arc_1315  -12
    arc_2_11_12  out_degree_1546  1
    arc_2_11_12  in_degree_1554  1
    arc_2_11_12  original_T_including_depot_unload_1617  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1314  1
    load_2_11_12  segment_load_conservation_1550  1
    load_2_11_12  segment_load_conservation_1557  -1
    load_2_11_12  segment_prefix_lb_1558  1
    load_2_11_12  segment_prefix_ub_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1316  -30
    arc_2_11_13  connected_order_arc_1317  -12
    arc_2_11_13  out_degree_1546  1
    arc_2_11_13  in_degree_1561  1
    arc_2_11_13  original_T_including_depot_unload_1617  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1316  1
    load_2_11_13  segment_load_conservation_1550  1
    load_2_11_13  segment_load_conservation_1564  -1
    load_2_11_13  segment_prefix_lb_1565  1
    load_2_11_13  segment_prefix_ub_1566  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1318  -30
    arc_2_11_14  connected_order_arc_1319  -12
    arc_2_11_14  out_degree_1546  1
    arc_2_11_14  in_degree_1568  1
    arc_2_11_14  original_T_including_depot_unload_1617  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1318  1
    load_2_11_14  segment_load_conservation_1550  1
    load_2_11_14  free_load_conservation_1572  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1320  -30
    arc_2_11_15  connected_order_arc_1321  -12
    arc_2_11_15  out_degree_1546  1
    arc_2_11_15  in_degree_1574  1
    arc_2_11_15  original_T_including_depot_unload_1617  1.0311494902403294e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1320  1
    load_2_11_15  segment_load_conservation_1550  1
    load_2_11_15  free_load_conservation_1578  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1322  -30
    arc_2_11_16  connected_order_arc_1323  -12
    arc_2_11_16  out_degree_1546  1
    arc_2_11_16  in_degree_1580  1
    arc_2_11_16  original_T_including_depot_unload_1617  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1322  1
    load_2_11_16  segment_load_conservation_1550  1
    load_2_11_16  free_load_conservation_1584  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1324  -30
    arc_2_11_17  connected_order_arc_1325  -12
    arc_2_11_17  out_degree_1546  1
    arc_2_11_17  in_degree_1586  1
    arc_2_11_17  original_T_including_depot_unload_1617  1.2309802293463208e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1324  1
    load_2_11_17  segment_load_conservation_1550  1
    load_2_11_17  free_load_conservation_1590  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1326  -30
    arc_2_11_18  connected_order_arc_1327  -12
    arc_2_11_18  out_degree_1546  1
    arc_2_11_18  in_degree_1592  1
    arc_2_11_18  original_T_including_depot_unload_1617  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1326  1
    load_2_11_18  segment_load_conservation_1550  1
    load_2_11_18  free_load_conservation_1596  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1328  -30
    arc_2_11_19  connected_order_arc_1329  -12
    arc_2_11_19  out_degree_1546  1
    arc_2_11_19  in_degree_1598  1
    arc_2_11_19  original_T_including_depot_unload_1617  1.1005939447212634e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1328  1
    load_2_11_19  segment_load_conservation_1550  1
    load_2_11_19  free_load_conservation_1602  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1330  -30
    arc_2_11_20  connected_order_arc_1331  -12
    arc_2_11_20  out_degree_1546  1
    arc_2_11_20  in_degree_1604  1
    arc_2_11_20  original_T_including_depot_unload_1617  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1330  1
    load_2_11_20  segment_load_conservation_1550  1
    load_2_11_20  free_load_conservation_1608  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1332  -30
    arc_2_11_21  connected_order_arc_1333  -12
    arc_2_11_21  out_degree_1546  1
    arc_2_11_21  in_degree_1610  1
    arc_2_11_21  original_T_including_depot_unload_1617  1.2442780266664952e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1332  1
    load_2_11_21  segment_load_conservation_1550  1
    load_2_11_21  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1334  -30
    arc_2_12_0  depot_return_or_bypass_1545  1
    arc_2_12_0  out_degree_1553  1
    arc_2_12_0  original_T_including_depot_unload_1617  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1334  1
    load_2_12_0  segment_load_conservation_1557  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1335  -30
    arc_2_12_11  connected_order_arc_1336  -12
    arc_2_12_11  in_degree_1547  1
    arc_2_12_11  out_degree_1553  1
    arc_2_12_11  original_T_including_depot_unload_1617  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1335  1
    load_2_12_11  segment_load_conservation_1550  -1
    load_2_12_11  segment_prefix_lb_1551  1
    load_2_12_11  segment_prefix_ub_1552  1
    load_2_12_11  segment_load_conservation_1557  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1337  -30
    arc_2_12_13  connected_order_arc_1338  -12
    arc_2_12_13  out_degree_1553  1
    arc_2_12_13  in_degree_1561  1
    arc_2_12_13  original_T_including_depot_unload_1617  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1337  1
    load_2_12_13  segment_load_conservation_1557  1
    load_2_12_13  segment_load_conservation_1564  -1
    load_2_12_13  segment_prefix_lb_1565  1
    load_2_12_13  segment_prefix_ub_1566  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1339  -30
    arc_2_12_14  connected_order_arc_1340  -12
    arc_2_12_14  out_degree_1553  1
    arc_2_12_14  in_degree_1568  1
    arc_2_12_14  original_T_including_depot_unload_1617  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1339  1
    load_2_12_14  segment_load_conservation_1557  1
    load_2_12_14  free_load_conservation_1572  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1341  -30
    arc_2_12_15  connected_order_arc_1342  -12
    arc_2_12_15  out_degree_1553  1
    arc_2_12_15  in_degree_1574  1
    arc_2_12_15  original_T_including_depot_unload_1617  1.4516198129136008e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1341  1
    load_2_12_15  segment_load_conservation_1557  1
    load_2_12_15  free_load_conservation_1578  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1343  -30
    arc_2_12_16  connected_order_arc_1344  -12
    arc_2_12_16  out_degree_1553  1
    arc_2_12_16  in_degree_1580  1
    arc_2_12_16  original_T_including_depot_unload_1617  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1343  1
    load_2_12_16  segment_load_conservation_1557  1
    load_2_12_16  free_load_conservation_1584  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1345  -30
    arc_2_12_17  connected_order_arc_1346  -12
    arc_2_12_17  out_degree_1553  1
    arc_2_12_17  in_degree_1586  1
    arc_2_12_17  original_T_including_depot_unload_1617  1.6785246977297163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1345  1
    load_2_12_17  segment_load_conservation_1557  1
    load_2_12_17  free_load_conservation_1590  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1347  -30
    arc_2_12_18  connected_order_arc_1348  -12
    arc_2_12_18  out_degree_1553  1
    arc_2_12_18  in_degree_1592  1
    arc_2_12_18  original_T_including_depot_unload_1617  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1347  1
    load_2_12_18  segment_load_conservation_1557  1
    load_2_12_18  free_load_conservation_1596  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1349  -30
    arc_2_12_19  connected_order_arc_1350  -12
    arc_2_12_19  out_degree_1553  1
    arc_2_12_19  in_degree_1598  1
    arc_2_12_19  original_T_including_depot_unload_1617  1.7809992976396034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1349  1
    load_2_12_19  segment_load_conservation_1557  1
    load_2_12_19  free_load_conservation_1602  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1351  -30
    arc_2_12_20  connected_order_arc_1352  -12
    arc_2_12_20  out_degree_1553  1
    arc_2_12_20  in_degree_1604  1
    arc_2_12_20  original_T_including_depot_unload_1617  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1351  1
    load_2_12_20  segment_load_conservation_1557  1
    load_2_12_20  free_load_conservation_1608  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1353  -30
    arc_2_12_21  connected_order_arc_1354  -12
    arc_2_12_21  out_degree_1553  1
    arc_2_12_21  in_degree_1610  1
    arc_2_12_21  original_T_including_depot_unload_1617  1.9434430494183746e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1353  1
    load_2_12_21  segment_load_conservation_1557  1
    load_2_12_21  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1355  -30
    arc_2_13_0  depot_return_or_bypass_1545  1
    arc_2_13_0  out_degree_1560  1
    arc_2_13_0  original_T_including_depot_unload_1617  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1355  1
    load_2_13_0  segment_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1356  -30
    arc_2_13_11  connected_order_arc_1357  -12
    arc_2_13_11  in_degree_1547  1
    arc_2_13_11  out_degree_1560  1
    arc_2_13_11  original_T_including_depot_unload_1617  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1356  1
    load_2_13_11  segment_load_conservation_1550  -1
    load_2_13_11  segment_prefix_lb_1551  1
    load_2_13_11  segment_prefix_ub_1552  1
    load_2_13_11  segment_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1358  -30
    arc_2_13_12  connected_order_arc_1359  -12
    arc_2_13_12  in_degree_1554  1
    arc_2_13_12  out_degree_1560  1
    arc_2_13_12  original_T_including_depot_unload_1617  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1358  1
    load_2_13_12  segment_load_conservation_1557  -1
    load_2_13_12  segment_prefix_lb_1558  1
    load_2_13_12  segment_prefix_ub_1559  1
    load_2_13_12  segment_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1360  -30
    arc_2_13_14  connected_order_arc_1361  -12
    arc_2_13_14  out_degree_1560  1
    arc_2_13_14  in_degree_1568  1
    arc_2_13_14  original_T_including_depot_unload_1617  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1360  1
    load_2_13_14  segment_load_conservation_1564  1
    load_2_13_14  free_load_conservation_1572  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1362  -30
    arc_2_13_15  connected_order_arc_1363  -12
    arc_2_13_15  out_degree_1560  1
    arc_2_13_15  in_degree_1574  1
    arc_2_13_15  original_T_including_depot_unload_1617  1.8130068061837439e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1362  1
    load_2_13_15  segment_load_conservation_1564  1
    load_2_13_15  free_load_conservation_1578  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1364  -30
    arc_2_13_16  connected_order_arc_1365  -12
    arc_2_13_16  out_degree_1560  1
    arc_2_13_16  in_degree_1580  1
    arc_2_13_16  original_T_including_depot_unload_1617  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1364  1
    load_2_13_16  segment_load_conservation_1564  1
    load_2_13_16  free_load_conservation_1584  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1366  -30
    arc_2_13_17  connected_order_arc_1367  -12
    arc_2_13_17  out_degree_1560  1
    arc_2_13_17  in_degree_1586  1
    arc_2_13_17  original_T_including_depot_unload_1617  1.9981042624472673e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1366  1
    load_2_13_17  segment_load_conservation_1564  1
    load_2_13_17  free_load_conservation_1590  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1368  -30
    arc_2_13_18  connected_order_arc_1369  -12
    arc_2_13_18  out_degree_1560  1
    arc_2_13_18  in_degree_1592  1
    arc_2_13_18  original_T_including_depot_unload_1617  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1368  1
    load_2_13_18  segment_load_conservation_1564  1
    load_2_13_18  free_load_conservation_1596  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1370  -30
    arc_2_13_19  connected_order_arc_1371  -12
    arc_2_13_19  out_degree_1560  1
    arc_2_13_19  in_degree_1598  1
    arc_2_13_19  original_T_including_depot_unload_1617  1.8269270746185791e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1370  1
    load_2_13_19  segment_load_conservation_1564  1
    load_2_13_19  free_load_conservation_1602  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1372  -30
    arc_2_13_20  connected_order_arc_1373  -12
    arc_2_13_20  out_degree_1560  1
    arc_2_13_20  in_degree_1604  1
    arc_2_13_20  original_T_including_depot_unload_1617  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1372  1
    load_2_13_20  segment_load_conservation_1564  1
    load_2_13_20  free_load_conservation_1608  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1374  -30
    arc_2_13_21  connected_order_arc_1375  -12
    arc_2_13_21  out_degree_1560  1
    arc_2_13_21  in_degree_1610  1
    arc_2_13_21  original_T_including_depot_unload_1617  1.9482201819157062e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1374  1
    load_2_13_21  segment_load_conservation_1564  1
    load_2_13_21  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1376  -30
    arc_2_14_0  depot_return_or_bypass_1545  1
    arc_2_14_0  out_degree_1567  1
    arc_2_14_0  original_T_including_depot_unload_1617  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1376  1
    load_2_14_0  free_load_conservation_1572  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1377  -30
    arc_2_14_11  connected_order_arc_1378  -12
    arc_2_14_11  in_degree_1547  1
    arc_2_14_11  out_degree_1567  1
    arc_2_14_11  original_T_including_depot_unload_1617  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1377  1
    load_2_14_11  segment_load_conservation_1550  -1
    load_2_14_11  segment_prefix_lb_1551  1
    load_2_14_11  segment_prefix_ub_1552  1
    load_2_14_11  free_load_conservation_1572  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1379  -30
    arc_2_14_12  connected_order_arc_1380  -12
    arc_2_14_12  in_degree_1554  1
    arc_2_14_12  out_degree_1567  1
    arc_2_14_12  original_T_including_depot_unload_1617  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1379  1
    load_2_14_12  segment_load_conservation_1557  -1
    load_2_14_12  segment_prefix_lb_1558  1
    load_2_14_12  segment_prefix_ub_1559  1
    load_2_14_12  free_load_conservation_1572  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1381  -30
    arc_2_14_13  connected_order_arc_1382  -12
    arc_2_14_13  in_degree_1561  1
    arc_2_14_13  out_degree_1567  1
    arc_2_14_13  original_T_including_depot_unload_1617  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1381  1
    load_2_14_13  segment_load_conservation_1564  -1
    load_2_14_13  segment_prefix_lb_1565  1
    load_2_14_13  segment_prefix_ub_1566  1
    load_2_14_13  free_load_conservation_1572  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1383  -30
    arc_2_14_15  connected_order_arc_1384  -12
    arc_2_14_15  out_degree_1567  1
    arc_2_14_15  in_degree_1574  1
    arc_2_14_15  original_T_including_depot_unload_1617  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1383  1
    load_2_14_15  free_load_conservation_1572  1
    load_2_14_15  free_load_conservation_1578  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1385  -30
    arc_2_14_16  connected_order_arc_1386  -12
    arc_2_14_16  out_degree_1567  1
    arc_2_14_16  in_degree_1580  1
    arc_2_14_16  original_T_including_depot_unload_1617  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1385  1
    load_2_14_16  free_load_conservation_1572  1
    load_2_14_16  free_load_conservation_1584  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1387  -30
    arc_2_14_17  connected_order_arc_1388  -12
    arc_2_14_17  out_degree_1567  1
    arc_2_14_17  in_degree_1586  1
    arc_2_14_17  original_T_including_depot_unload_1617  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1387  1
    load_2_14_17  free_load_conservation_1572  1
    load_2_14_17  free_load_conservation_1590  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1389  -30
    arc_2_14_18  connected_order_arc_1390  -12
    arc_2_14_18  out_degree_1567  1
    arc_2_14_18  in_degree_1592  1
    arc_2_14_18  original_T_including_depot_unload_1617  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1389  1
    load_2_14_18  free_load_conservation_1572  1
    load_2_14_18  free_load_conservation_1596  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1391  -30
    arc_2_14_19  connected_order_arc_1392  -12
    arc_2_14_19  out_degree_1567  1
    arc_2_14_19  in_degree_1598  1
    arc_2_14_19  original_T_including_depot_unload_1617  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1391  1
    load_2_14_19  free_load_conservation_1572  1
    load_2_14_19  free_load_conservation_1602  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1393  -30
    arc_2_14_20  connected_order_arc_1394  -12
    arc_2_14_20  out_degree_1567  1
    arc_2_14_20  in_degree_1604  1
    arc_2_14_20  original_T_including_depot_unload_1617  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1393  1
    load_2_14_20  free_load_conservation_1572  1
    load_2_14_20  free_load_conservation_1608  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1395  -30
    arc_2_14_21  connected_order_arc_1396  -12
    arc_2_14_21  out_degree_1567  1
    arc_2_14_21  in_degree_1610  1
    arc_2_14_21  original_T_including_depot_unload_1617  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1395  1
    load_2_14_21  free_load_conservation_1572  1
    load_2_14_21  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1397  -30
    arc_2_15_0  depot_return_or_bypass_1545  1
    arc_2_15_0  out_degree_1573  1
    arc_2_15_0  original_T_including_depot_unload_1617  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1397  1
    load_2_15_0  free_load_conservation_1578  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1398  -30
    arc_2_15_11  connected_order_arc_1399  -12
    arc_2_15_11  in_degree_1547  1
    arc_2_15_11  out_degree_1573  1
    arc_2_15_11  original_T_including_depot_unload_1617  1.0311494902403294e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1398  1
    load_2_15_11  segment_load_conservation_1550  -1
    load_2_15_11  segment_prefix_lb_1551  1
    load_2_15_11  segment_prefix_ub_1552  1
    load_2_15_11  free_load_conservation_1578  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1400  -30
    arc_2_15_12  connected_order_arc_1401  -12
    arc_2_15_12  in_degree_1554  1
    arc_2_15_12  out_degree_1573  1
    arc_2_15_12  original_T_including_depot_unload_1617  1.4516198129136008e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1400  1
    load_2_15_12  segment_load_conservation_1557  -1
    load_2_15_12  segment_prefix_lb_1558  1
    load_2_15_12  segment_prefix_ub_1559  1
    load_2_15_12  free_load_conservation_1578  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1402  -30
    arc_2_15_13  connected_order_arc_1403  -12
    arc_2_15_13  in_degree_1561  1
    arc_2_15_13  out_degree_1573  1
    arc_2_15_13  original_T_including_depot_unload_1617  1.5892857916507662e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1402  1
    load_2_15_13  segment_load_conservation_1564  -1
    load_2_15_13  segment_prefix_lb_1565  1
    load_2_15_13  segment_prefix_ub_1566  1
    load_2_15_13  free_load_conservation_1578  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1404  -30
    arc_2_15_14  connected_order_arc_1405  -12
    arc_2_15_14  in_degree_1568  1
    arc_2_15_14  out_degree_1573  1
    arc_2_15_14  original_T_including_depot_unload_1617  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1404  1
    load_2_15_14  free_load_conservation_1572  -1
    load_2_15_14  free_load_conservation_1578  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1406  -30
    arc_2_15_16  connected_order_arc_1407  -12
    arc_2_15_16  out_degree_1573  1
    arc_2_15_16  in_degree_1580  1
    arc_2_15_16  original_T_including_depot_unload_1617  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1406  1
    load_2_15_16  free_load_conservation_1578  1
    load_2_15_16  free_load_conservation_1584  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1408  -30
    arc_2_15_17  connected_order_arc_1409  -12
    arc_2_15_17  out_degree_1573  1
    arc_2_15_17  in_degree_1586  1
    arc_2_15_17  original_T_including_depot_unload_1617  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1408  1
    load_2_15_17  free_load_conservation_1578  1
    load_2_15_17  free_load_conservation_1590  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1410  -30
    arc_2_15_18  connected_order_arc_1411  -12
    arc_2_15_18  out_degree_1573  1
    arc_2_15_18  in_degree_1592  1
    arc_2_15_18  original_T_including_depot_unload_1617  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1410  1
    load_2_15_18  free_load_conservation_1578  1
    load_2_15_18  free_load_conservation_1596  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1412  -30
    arc_2_15_19  connected_order_arc_1413  -12
    arc_2_15_19  out_degree_1573  1
    arc_2_15_19  in_degree_1598  1
    arc_2_15_19  original_T_including_depot_unload_1617  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1412  1
    load_2_15_19  free_load_conservation_1578  1
    load_2_15_19  free_load_conservation_1602  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1414  -30
    arc_2_15_20  connected_order_arc_1415  -12
    arc_2_15_20  out_degree_1573  1
    arc_2_15_20  in_degree_1604  1
    arc_2_15_20  original_T_including_depot_unload_1617  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1414  1
    load_2_15_20  free_load_conservation_1578  1
    load_2_15_20  free_load_conservation_1608  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1416  -30
    arc_2_15_21  connected_order_arc_1417  -12
    arc_2_15_21  out_degree_1573  1
    arc_2_15_21  in_degree_1610  1
    arc_2_15_21  original_T_including_depot_unload_1617  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1416  1
    load_2_15_21  free_load_conservation_1578  1
    load_2_15_21  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1418  -30
    arc_2_16_0  depot_return_or_bypass_1545  1
    arc_2_16_0  out_degree_1579  1
    arc_2_16_0  original_T_including_depot_unload_1617  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1418  1
    load_2_16_0  free_load_conservation_1584  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1419  -30
    arc_2_16_11  connected_order_arc_1420  -12
    arc_2_16_11  in_degree_1547  1
    arc_2_16_11  out_degree_1579  1
    arc_2_16_11  original_T_including_depot_unload_1617  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1419  1
    load_2_16_11  segment_load_conservation_1550  -1
    load_2_16_11  segment_prefix_lb_1551  1
    load_2_16_11  segment_prefix_ub_1552  1
    load_2_16_11  free_load_conservation_1584  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1421  -30
    arc_2_16_12  connected_order_arc_1422  -12
    arc_2_16_12  in_degree_1554  1
    arc_2_16_12  out_degree_1579  1
    arc_2_16_12  original_T_including_depot_unload_1617  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1421  1
    load_2_16_12  segment_load_conservation_1557  -1
    load_2_16_12  segment_prefix_lb_1558  1
    load_2_16_12  segment_prefix_ub_1559  1
    load_2_16_12  free_load_conservation_1584  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1423  -30
    arc_2_16_13  connected_order_arc_1424  -12
    arc_2_16_13  in_degree_1561  1
    arc_2_16_13  out_degree_1579  1
    arc_2_16_13  original_T_including_depot_unload_1617  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1423  1
    load_2_16_13  segment_load_conservation_1564  -1
    load_2_16_13  segment_prefix_lb_1565  1
    load_2_16_13  segment_prefix_ub_1566  1
    load_2_16_13  free_load_conservation_1584  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1425  -30
    arc_2_16_14  connected_order_arc_1426  -12
    arc_2_16_14  in_degree_1568  1
    arc_2_16_14  out_degree_1579  1
    arc_2_16_14  original_T_including_depot_unload_1617  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1425  1
    load_2_16_14  free_load_conservation_1572  -1
    load_2_16_14  free_load_conservation_1584  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1427  -30
    arc_2_16_15  connected_order_arc_1428  -12
    arc_2_16_15  in_degree_1574  1
    arc_2_16_15  out_degree_1579  1
    arc_2_16_15  original_T_including_depot_unload_1617  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1427  1
    load_2_16_15  free_load_conservation_1578  -1
    load_2_16_15  free_load_conservation_1584  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1429  -30
    arc_2_16_17  connected_order_arc_1430  -12
    arc_2_16_17  out_degree_1579  1
    arc_2_16_17  in_degree_1586  1
    arc_2_16_17  original_T_including_depot_unload_1617  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1429  1
    load_2_16_17  free_load_conservation_1584  1
    load_2_16_17  free_load_conservation_1590  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1431  -30
    arc_2_16_18  connected_order_arc_1432  -12
    arc_2_16_18  out_degree_1579  1
    arc_2_16_18  in_degree_1592  1
    arc_2_16_18  original_T_including_depot_unload_1617  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1431  1
    load_2_16_18  free_load_conservation_1584  1
    load_2_16_18  free_load_conservation_1596  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1433  -30
    arc_2_16_19  connected_order_arc_1434  -12
    arc_2_16_19  out_degree_1579  1
    arc_2_16_19  in_degree_1598  1
    arc_2_16_19  original_T_including_depot_unload_1617  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1433  1
    load_2_16_19  free_load_conservation_1584  1
    load_2_16_19  free_load_conservation_1602  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1435  -30
    arc_2_16_20  connected_order_arc_1436  -12
    arc_2_16_20  out_degree_1579  1
    arc_2_16_20  in_degree_1604  1
    arc_2_16_20  original_T_including_depot_unload_1617  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1435  1
    load_2_16_20  free_load_conservation_1584  1
    load_2_16_20  free_load_conservation_1608  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1437  -30
    arc_2_16_21  connected_order_arc_1438  -12
    arc_2_16_21  out_degree_1579  1
    arc_2_16_21  in_degree_1610  1
    arc_2_16_21  original_T_including_depot_unload_1617  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1437  1
    load_2_16_21  free_load_conservation_1584  1
    load_2_16_21  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1439  -30
    arc_2_17_0  depot_return_or_bypass_1545  1
    arc_2_17_0  out_degree_1585  1
    arc_2_17_0  original_T_including_depot_unload_1617  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1439  1
    load_2_17_0  free_load_conservation_1590  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1440  -30
    arc_2_17_11  connected_order_arc_1441  -12
    arc_2_17_11  in_degree_1547  1
    arc_2_17_11  out_degree_1585  1
    arc_2_17_11  original_T_including_depot_unload_1617  1.2309802293463208e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1440  1
    load_2_17_11  segment_load_conservation_1550  -1
    load_2_17_11  segment_prefix_lb_1551  1
    load_2_17_11  segment_prefix_ub_1552  1
    load_2_17_11  free_load_conservation_1590  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1442  -30
    arc_2_17_12  connected_order_arc_1443  -12
    arc_2_17_12  in_degree_1554  1
    arc_2_17_12  out_degree_1585  1
    arc_2_17_12  original_T_including_depot_unload_1617  1.6785246977297163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1442  1
    load_2_17_12  segment_load_conservation_1557  -1
    load_2_17_12  segment_prefix_lb_1558  1
    load_2_17_12  segment_prefix_ub_1559  1
    load_2_17_12  free_load_conservation_1590  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1444  -30
    arc_2_17_13  connected_order_arc_1445  -12
    arc_2_17_13  in_degree_1561  1
    arc_2_17_13  out_degree_1585  1
    arc_2_17_13  original_T_including_depot_unload_1617  1.7520337176349503e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1444  1
    load_2_17_13  segment_load_conservation_1564  -1
    load_2_17_13  segment_prefix_lb_1565  1
    load_2_17_13  segment_prefix_ub_1566  1
    load_2_17_13  free_load_conservation_1590  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1446  -30
    arc_2_17_14  connected_order_arc_1447  -12
    arc_2_17_14  in_degree_1568  1
    arc_2_17_14  out_degree_1585  1
    arc_2_17_14  original_T_including_depot_unload_1617  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1446  1
    load_2_17_14  free_load_conservation_1572  -1
    load_2_17_14  free_load_conservation_1590  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1448  -30
    arc_2_17_15  connected_order_arc_1449  -12
    arc_2_17_15  in_degree_1574  1
    arc_2_17_15  out_degree_1585  1
    arc_2_17_15  original_T_including_depot_unload_1617  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1448  1
    load_2_17_15  free_load_conservation_1578  -1
    load_2_17_15  free_load_conservation_1590  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1450  -30
    arc_2_17_16  connected_order_arc_1451  -12
    arc_2_17_16  in_degree_1580  1
    arc_2_17_16  out_degree_1585  1
    arc_2_17_16  original_T_including_depot_unload_1617  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1450  1
    load_2_17_16  free_load_conservation_1584  -1
    load_2_17_16  free_load_conservation_1590  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1452  -30
    arc_2_17_18  connected_order_arc_1453  -12
    arc_2_17_18  out_degree_1585  1
    arc_2_17_18  in_degree_1592  1
    arc_2_17_18  original_T_including_depot_unload_1617  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1452  1
    load_2_17_18  free_load_conservation_1590  1
    load_2_17_18  free_load_conservation_1596  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1454  -30
    arc_2_17_19  connected_order_arc_1455  -12
    arc_2_17_19  out_degree_1585  1
    arc_2_17_19  in_degree_1598  1
    arc_2_17_19  original_T_including_depot_unload_1617  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1454  1
    load_2_17_19  free_load_conservation_1590  1
    load_2_17_19  free_load_conservation_1602  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1456  -30
    arc_2_17_20  connected_order_arc_1457  -12
    arc_2_17_20  out_degree_1585  1
    arc_2_17_20  in_degree_1604  1
    arc_2_17_20  original_T_including_depot_unload_1617  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1456  1
    load_2_17_20  free_load_conservation_1590  1
    load_2_17_20  free_load_conservation_1608  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1458  -30
    arc_2_17_21  connected_order_arc_1459  -12
    arc_2_17_21  out_degree_1585  1
    arc_2_17_21  in_degree_1610  1
    arc_2_17_21  original_T_including_depot_unload_1617  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1458  1
    load_2_17_21  free_load_conservation_1590  1
    load_2_17_21  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1460  -30
    arc_2_18_0  depot_return_or_bypass_1545  1
    arc_2_18_0  out_degree_1591  1
    arc_2_18_0  original_T_including_depot_unload_1617  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1460  1
    load_2_18_0  free_load_conservation_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1461  -30
    arc_2_18_11  connected_order_arc_1462  -12
    arc_2_18_11  in_degree_1547  1
    arc_2_18_11  out_degree_1591  1
    arc_2_18_11  original_T_including_depot_unload_1617  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1461  1
    load_2_18_11  segment_load_conservation_1550  -1
    load_2_18_11  segment_prefix_lb_1551  1
    load_2_18_11  segment_prefix_ub_1552  1
    load_2_18_11  free_load_conservation_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1463  -30
    arc_2_18_12  connected_order_arc_1464  -12
    arc_2_18_12  in_degree_1554  1
    arc_2_18_12  out_degree_1591  1
    arc_2_18_12  original_T_including_depot_unload_1617  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1463  1
    load_2_18_12  segment_load_conservation_1557  -1
    load_2_18_12  segment_prefix_lb_1558  1
    load_2_18_12  segment_prefix_ub_1559  1
    load_2_18_12  free_load_conservation_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1465  -30
    arc_2_18_13  connected_order_arc_1466  -12
    arc_2_18_13  in_degree_1561  1
    arc_2_18_13  out_degree_1591  1
    arc_2_18_13  original_T_including_depot_unload_1617  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1465  1
    load_2_18_13  segment_load_conservation_1564  -1
    load_2_18_13  segment_prefix_lb_1565  1
    load_2_18_13  segment_prefix_ub_1566  1
    load_2_18_13  free_load_conservation_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1467  -30
    arc_2_18_14  connected_order_arc_1468  -12
    arc_2_18_14  in_degree_1568  1
    arc_2_18_14  out_degree_1591  1
    arc_2_18_14  original_T_including_depot_unload_1617  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1467  1
    load_2_18_14  free_load_conservation_1572  -1
    load_2_18_14  free_load_conservation_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1469  -30
    arc_2_18_15  connected_order_arc_1470  -12
    arc_2_18_15  in_degree_1574  1
    arc_2_18_15  out_degree_1591  1
    arc_2_18_15  original_T_including_depot_unload_1617  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1469  1
    load_2_18_15  free_load_conservation_1578  -1
    load_2_18_15  free_load_conservation_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1471  -30
    arc_2_18_16  connected_order_arc_1472  -12
    arc_2_18_16  in_degree_1580  1
    arc_2_18_16  out_degree_1591  1
    arc_2_18_16  original_T_including_depot_unload_1617  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1471  1
    load_2_18_16  free_load_conservation_1584  -1
    load_2_18_16  free_load_conservation_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1473  -30
    arc_2_18_17  connected_order_arc_1474  -12
    arc_2_18_17  in_degree_1586  1
    arc_2_18_17  out_degree_1591  1
    arc_2_18_17  original_T_including_depot_unload_1617  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1473  1
    load_2_18_17  free_load_conservation_1590  -1
    load_2_18_17  free_load_conservation_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1475  -30
    arc_2_18_19  connected_order_arc_1476  -12
    arc_2_18_19  out_degree_1591  1
    arc_2_18_19  in_degree_1598  1
    arc_2_18_19  original_T_including_depot_unload_1617  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1475  1
    load_2_18_19  free_load_conservation_1596  1
    load_2_18_19  free_load_conservation_1602  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1477  -30
    arc_2_18_20  connected_order_arc_1478  -12
    arc_2_18_20  out_degree_1591  1
    arc_2_18_20  in_degree_1604  1
    arc_2_18_20  original_T_including_depot_unload_1617  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1477  1
    load_2_18_20  free_load_conservation_1596  1
    load_2_18_20  free_load_conservation_1608  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1479  -30
    arc_2_18_21  connected_order_arc_1480  -12
    arc_2_18_21  out_degree_1591  1
    arc_2_18_21  in_degree_1610  1
    arc_2_18_21  original_T_including_depot_unload_1617  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1479  1
    load_2_18_21  free_load_conservation_1596  1
    load_2_18_21  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1481  -30
    arc_2_19_0  depot_return_or_bypass_1545  1
    arc_2_19_0  out_degree_1597  1
    arc_2_19_0  original_T_including_depot_unload_1617  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1481  1
    load_2_19_0  free_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1482  -30
    arc_2_19_11  connected_order_arc_1483  -12
    arc_2_19_11  in_degree_1547  1
    arc_2_19_11  out_degree_1597  1
    arc_2_19_11  original_T_including_depot_unload_1617  1.1005939447212634e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1482  1
    load_2_19_11  segment_load_conservation_1550  -1
    load_2_19_11  segment_prefix_lb_1551  1
    load_2_19_11  segment_prefix_ub_1552  1
    load_2_19_11  free_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1484  -30
    arc_2_19_12  connected_order_arc_1485  -12
    arc_2_19_12  in_degree_1554  1
    arc_2_19_12  out_degree_1597  1
    arc_2_19_12  original_T_including_depot_unload_1617  1.7809992976396034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1484  1
    load_2_19_12  segment_load_conservation_1557  -1
    load_2_19_12  segment_prefix_lb_1558  1
    load_2_19_12  segment_prefix_ub_1559  1
    load_2_19_12  free_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1486  -30
    arc_2_19_13  connected_order_arc_1487  -12
    arc_2_19_13  in_degree_1561  1
    arc_2_19_13  out_degree_1597  1
    arc_2_19_13  original_T_including_depot_unload_1617  1.5546511874277910e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1486  1
    load_2_19_13  segment_load_conservation_1564  -1
    load_2_19_13  segment_prefix_lb_1565  1
    load_2_19_13  segment_prefix_ub_1566  1
    load_2_19_13  free_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1488  -30
    arc_2_19_14  connected_order_arc_1489  -12
    arc_2_19_14  in_degree_1568  1
    arc_2_19_14  out_degree_1597  1
    arc_2_19_14  original_T_including_depot_unload_1617  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1488  1
    load_2_19_14  free_load_conservation_1572  -1
    load_2_19_14  free_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1490  -30
    arc_2_19_15  connected_order_arc_1491  -12
    arc_2_19_15  in_degree_1574  1
    arc_2_19_15  out_degree_1597  1
    arc_2_19_15  original_T_including_depot_unload_1617  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1490  1
    load_2_19_15  free_load_conservation_1578  -1
    load_2_19_15  free_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1492  -30
    arc_2_19_16  connected_order_arc_1493  -12
    arc_2_19_16  in_degree_1580  1
    arc_2_19_16  out_degree_1597  1
    arc_2_19_16  original_T_including_depot_unload_1617  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1492  1
    load_2_19_16  free_load_conservation_1584  -1
    load_2_19_16  free_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1494  -30
    arc_2_19_17  connected_order_arc_1495  -12
    arc_2_19_17  in_degree_1586  1
    arc_2_19_17  out_degree_1597  1
    arc_2_19_17  original_T_including_depot_unload_1617  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1494  1
    load_2_19_17  free_load_conservation_1590  -1
    load_2_19_17  free_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1496  -30
    arc_2_19_18  connected_order_arc_1497  -12
    arc_2_19_18  in_degree_1592  1
    arc_2_19_18  out_degree_1597  1
    arc_2_19_18  original_T_including_depot_unload_1617  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1496  1
    load_2_19_18  free_load_conservation_1596  -1
    load_2_19_18  free_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1498  -30
    arc_2_19_20  connected_order_arc_1499  -12
    arc_2_19_20  out_degree_1597  1
    arc_2_19_20  in_degree_1604  1
    arc_2_19_20  original_T_including_depot_unload_1617  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1498  1
    load_2_19_20  free_load_conservation_1602  1
    load_2_19_20  free_load_conservation_1608  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1500  -30
    arc_2_19_21  connected_order_arc_1501  -12
    arc_2_19_21  out_degree_1597  1
    arc_2_19_21  in_degree_1610  1
    arc_2_19_21  original_T_including_depot_unload_1617  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1500  1
    load_2_19_21  free_load_conservation_1602  1
    load_2_19_21  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1502  -30
    arc_2_20_0  depot_return_or_bypass_1545  1
    arc_2_20_0  out_degree_1603  1
    arc_2_20_0  original_T_including_depot_unload_1617  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1502  1
    load_2_20_0  free_load_conservation_1608  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1503  -30
    arc_2_20_11  connected_order_arc_1504  -12
    arc_2_20_11  in_degree_1547  1
    arc_2_20_11  out_degree_1603  1
    arc_2_20_11  original_T_including_depot_unload_1617  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1503  1
    load_2_20_11  segment_load_conservation_1550  -1
    load_2_20_11  segment_prefix_lb_1551  1
    load_2_20_11  segment_prefix_ub_1552  1
    load_2_20_11  free_load_conservation_1608  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1505  -30
    arc_2_20_12  connected_order_arc_1506  -12
    arc_2_20_12  in_degree_1554  1
    arc_2_20_12  out_degree_1603  1
    arc_2_20_12  original_T_including_depot_unload_1617  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1505  1
    load_2_20_12  segment_load_conservation_1557  -1
    load_2_20_12  segment_prefix_lb_1558  1
    load_2_20_12  segment_prefix_ub_1559  1
    load_2_20_12  free_load_conservation_1608  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1507  -30
    arc_2_20_13  connected_order_arc_1508  -12
    arc_2_20_13  in_degree_1561  1
    arc_2_20_13  out_degree_1603  1
    arc_2_20_13  original_T_including_depot_unload_1617  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1507  1
    load_2_20_13  segment_load_conservation_1564  -1
    load_2_20_13  segment_prefix_lb_1565  1
    load_2_20_13  segment_prefix_ub_1566  1
    load_2_20_13  free_load_conservation_1608  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1509  -30
    arc_2_20_14  connected_order_arc_1510  -12
    arc_2_20_14  in_degree_1568  1
    arc_2_20_14  out_degree_1603  1
    arc_2_20_14  original_T_including_depot_unload_1617  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1509  1
    load_2_20_14  free_load_conservation_1572  -1
    load_2_20_14  free_load_conservation_1608  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1511  -30
    arc_2_20_15  connected_order_arc_1512  -12
    arc_2_20_15  in_degree_1574  1
    arc_2_20_15  out_degree_1603  1
    arc_2_20_15  original_T_including_depot_unload_1617  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1511  1
    load_2_20_15  free_load_conservation_1578  -1
    load_2_20_15  free_load_conservation_1608  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1513  -30
    arc_2_20_16  connected_order_arc_1514  -12
    arc_2_20_16  in_degree_1580  1
    arc_2_20_16  out_degree_1603  1
    arc_2_20_16  original_T_including_depot_unload_1617  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1513  1
    load_2_20_16  free_load_conservation_1584  -1
    load_2_20_16  free_load_conservation_1608  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1515  -30
    arc_2_20_17  connected_order_arc_1516  -12
    arc_2_20_17  in_degree_1586  1
    arc_2_20_17  out_degree_1603  1
    arc_2_20_17  original_T_including_depot_unload_1617  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1515  1
    load_2_20_17  free_load_conservation_1590  -1
    load_2_20_17  free_load_conservation_1608  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1517  -30
    arc_2_20_18  connected_order_arc_1518  -12
    arc_2_20_18  in_degree_1592  1
    arc_2_20_18  out_degree_1603  1
    arc_2_20_18  original_T_including_depot_unload_1617  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1517  1
    load_2_20_18  free_load_conservation_1596  -1
    load_2_20_18  free_load_conservation_1608  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1519  -30
    arc_2_20_19  connected_order_arc_1520  -12
    arc_2_20_19  in_degree_1598  1
    arc_2_20_19  out_degree_1603  1
    arc_2_20_19  original_T_including_depot_unload_1617  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1519  1
    load_2_20_19  free_load_conservation_1602  -1
    load_2_20_19  free_load_conservation_1608  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1521  -30
    arc_2_20_21  connected_order_arc_1522  -12
    arc_2_20_21  out_degree_1603  1
    arc_2_20_21  in_degree_1610  1
    arc_2_20_21  original_T_including_depot_unload_1617  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1521  1
    load_2_20_21  free_load_conservation_1608  1
    load_2_20_21  free_load_conservation_1614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1523  -30
    arc_2_21_0  depot_return_or_bypass_1545  1
    arc_2_21_0  out_degree_1609  1
    arc_2_21_0  original_T_including_depot_unload_1617  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1523  1
    load_2_21_0  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1524  -30
    arc_2_21_11  connected_order_arc_1525  -12
    arc_2_21_11  in_degree_1547  1
    arc_2_21_11  out_degree_1609  1
    arc_2_21_11  original_T_including_depot_unload_1617  1.2442780266664952e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1524  1
    load_2_21_11  segment_load_conservation_1550  -1
    load_2_21_11  segment_prefix_lb_1551  1
    load_2_21_11  segment_prefix_ub_1552  1
    load_2_21_11  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1526  -30
    arc_2_21_12  connected_order_arc_1527  -12
    arc_2_21_12  in_degree_1554  1
    arc_2_21_12  out_degree_1609  1
    arc_2_21_12  original_T_including_depot_unload_1617  1.9434430494183746e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1526  1
    load_2_21_12  segment_load_conservation_1557  -1
    load_2_21_12  segment_prefix_lb_1558  1
    load_2_21_12  segment_prefix_ub_1559  1
    load_2_21_12  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1528  -30
    arc_2_21_13  connected_order_arc_1529  -12
    arc_2_21_13  in_degree_1561  1
    arc_2_21_13  out_degree_1609  1
    arc_2_21_13  original_T_including_depot_unload_1617  1.6631507094436240e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1528  1
    load_2_21_13  segment_load_conservation_1564  -1
    load_2_21_13  segment_prefix_lb_1565  1
    load_2_21_13  segment_prefix_ub_1566  1
    load_2_21_13  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1530  -30
    arc_2_21_14  connected_order_arc_1531  -12
    arc_2_21_14  in_degree_1568  1
    arc_2_21_14  out_degree_1609  1
    arc_2_21_14  original_T_including_depot_unload_1617  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1530  1
    load_2_21_14  free_load_conservation_1572  -1
    load_2_21_14  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1532  -30
    arc_2_21_15  connected_order_arc_1533  -12
    arc_2_21_15  in_degree_1574  1
    arc_2_21_15  out_degree_1609  1
    arc_2_21_15  original_T_including_depot_unload_1617  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1532  1
    load_2_21_15  free_load_conservation_1578  -1
    load_2_21_15  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1534  -30
    arc_2_21_16  connected_order_arc_1535  -12
    arc_2_21_16  in_degree_1580  1
    arc_2_21_16  out_degree_1609  1
    arc_2_21_16  original_T_including_depot_unload_1617  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1534  1
    load_2_21_16  free_load_conservation_1584  -1
    load_2_21_16  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1536  -30
    arc_2_21_17  connected_order_arc_1537  -12
    arc_2_21_17  in_degree_1586  1
    arc_2_21_17  out_degree_1609  1
    arc_2_21_17  original_T_including_depot_unload_1617  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1536  1
    load_2_21_17  free_load_conservation_1590  -1
    load_2_21_17  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1538  -30
    arc_2_21_18  connected_order_arc_1539  -12
    arc_2_21_18  in_degree_1592  1
    arc_2_21_18  out_degree_1609  1
    arc_2_21_18  original_T_including_depot_unload_1617  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1538  1
    load_2_21_18  free_load_conservation_1596  -1
    load_2_21_18  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1540  -30
    arc_2_21_19  connected_order_arc_1541  -12
    arc_2_21_19  in_degree_1598  1
    arc_2_21_19  out_degree_1609  1
    arc_2_21_19  original_T_including_depot_unload_1617  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1540  1
    load_2_21_19  free_load_conservation_1602  -1
    load_2_21_19  free_load_conservation_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1542  -30
    arc_2_21_20  connected_order_arc_1543  -12
    arc_2_21_20  in_degree_1604  1
    arc_2_21_20  out_degree_1609  1
    arc_2_21_20  original_T_including_depot_unload_1617  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1542  1
    load_2_21_20  free_load_conservation_1608  -1
    load_2_21_20  free_load_conservation_1614  1
RHS
    RHS1      OBJ       -0.504
    RHS1      onehot_31_26  1
    RHS1      onehot_25_61  1
    RHS1      onehot_32_90  1
    RHS1      onehot_29_125  1
    RHS1      onehot_2_160  1
    RHS1      onehot_24_195  1
    RHS1      onehot_12_230  1
    RHS1      onehot_27_265  1
    RHS1      stock_ub_269  36
    RHS1      parent_nonstrict_scope_270  4.0021795463888010e-01
    RHS1      normalization_327  1
    RHS1      connected_order_arc_459  -13
    RHS1      connected_order_arc_461  -13
    RHS1      connected_order_arc_463  -13
    RHS1      connected_order_arc_465  -13
    RHS1      connected_order_arc_467  -13
    RHS1      connected_order_arc_469  -13
    RHS1      connected_order_arc_471  -13
    RHS1      connected_order_arc_473  -13
    RHS1      connected_order_arc_475  -13
    RHS1      connected_order_arc_477  -13
    RHS1      connected_order_arc_479  -13
    RHS1      connected_order_arc_481  -13
    RHS1      connected_order_arc_484  -13
    RHS1      connected_order_arc_486  -13
    RHS1      connected_order_arc_488  -13
    RHS1      connected_order_arc_490  -13
    RHS1      connected_order_arc_492  -13
    RHS1      connected_order_arc_494  -13
    RHS1      connected_order_arc_496  -13
    RHS1      connected_order_arc_498  -13
    RHS1      connected_order_arc_500  -13
    RHS1      connected_order_arc_502  -13
    RHS1      connected_order_arc_504  -13
    RHS1      connected_order_arc_506  -13
    RHS1      connected_order_arc_509  -13
    RHS1      connected_order_arc_511  -13
    RHS1      connected_order_arc_513  -13
    RHS1      connected_order_arc_515  -13
    RHS1      connected_order_arc_517  -13
    RHS1      connected_order_arc_519  -13
    RHS1      connected_order_arc_521  -13
    RHS1      connected_order_arc_523  -13
    RHS1      connected_order_arc_525  -13
    RHS1      connected_order_arc_527  -13
    RHS1      connected_order_arc_529  -13
    RHS1      connected_order_arc_531  -13
    RHS1      connected_order_arc_534  -13
    RHS1      connected_order_arc_536  -13
    RHS1      connected_order_arc_538  -13
    RHS1      connected_order_arc_540  -13
    RHS1      connected_order_arc_542  -13
    RHS1      connected_order_arc_544  -13
    RHS1      connected_order_arc_546  -13
    RHS1      connected_order_arc_548  -13
    RHS1      connected_order_arc_550  -13
    RHS1      connected_order_arc_552  -13
    RHS1      connected_order_arc_554  -13
    RHS1      connected_order_arc_556  -13
    RHS1      connected_order_arc_559  -13
    RHS1      connected_order_arc_561  -13
    RHS1      connected_order_arc_563  -13
    RHS1      connected_order_arc_565  -13
    RHS1      connected_order_arc_567  -13
    RHS1      connected_order_arc_569  -13
    RHS1      connected_order_arc_571  -13
    RHS1      connected_order_arc_573  -13
    RHS1      connected_order_arc_575  -13
    RHS1      connected_order_arc_577  -13
    RHS1      connected_order_arc_579  -13
    RHS1      connected_order_arc_581  -13
    RHS1      connected_order_arc_584  -13
    RHS1      connected_order_arc_586  -13
    RHS1      connected_order_arc_588  -13
    RHS1      connected_order_arc_590  -13
    RHS1      connected_order_arc_592  -13
    RHS1      connected_order_arc_594  -13
    RHS1      connected_order_arc_596  -13
    RHS1      connected_order_arc_598  -13
    RHS1      connected_order_arc_600  -13
    RHS1      connected_order_arc_602  -13
    RHS1      connected_order_arc_604  -13
    RHS1      connected_order_arc_606  -13
    RHS1      connected_order_arc_609  -13
    RHS1      connected_order_arc_611  -13
    RHS1      connected_order_arc_613  -13
    RHS1      connected_order_arc_615  -13
    RHS1      connected_order_arc_617  -13
    RHS1      connected_order_arc_619  -13
    RHS1      connected_order_arc_621  -13
    RHS1      connected_order_arc_623  -13
    RHS1      connected_order_arc_625  -13
    RHS1      connected_order_arc_627  -13
    RHS1      connected_order_arc_629  -13
    RHS1      connected_order_arc_631  -13
    RHS1      connected_order_arc_634  -13
    RHS1      connected_order_arc_636  -13
    RHS1      connected_order_arc_638  -13
    RHS1      connected_order_arc_640  -13
    RHS1      connected_order_arc_642  -13
    RHS1      connected_order_arc_644  -13
    RHS1      connected_order_arc_646  -13
    RHS1      connected_order_arc_648  -13
    RHS1      connected_order_arc_650  -13
    RHS1      connected_order_arc_652  -13
    RHS1      connected_order_arc_654  -13
    RHS1      connected_order_arc_656  -13
    RHS1      connected_order_arc_659  -13
    RHS1      connected_order_arc_661  -13
    RHS1      connected_order_arc_663  -13
    RHS1      connected_order_arc_665  -13
    RHS1      connected_order_arc_667  -13
    RHS1      connected_order_arc_669  -13
    RHS1      connected_order_arc_671  -13
    RHS1      connected_order_arc_673  -13
    RHS1      connected_order_arc_675  -13
    RHS1      connected_order_arc_677  -13
    RHS1      connected_order_arc_679  -13
    RHS1      connected_order_arc_681  -13
    RHS1      connected_order_arc_684  -13
    RHS1      connected_order_arc_686  -13
    RHS1      connected_order_arc_688  -13
    RHS1      connected_order_arc_690  -13
    RHS1      connected_order_arc_692  -13
    RHS1      connected_order_arc_694  -13
    RHS1      connected_order_arc_696  -13
    RHS1      connected_order_arc_698  -13
    RHS1      connected_order_arc_700  -13
    RHS1      connected_order_arc_702  -13
    RHS1      connected_order_arc_704  -13
    RHS1      connected_order_arc_706  -13
    RHS1      connected_order_arc_709  -13
    RHS1      connected_order_arc_711  -13
    RHS1      connected_order_arc_713  -13
    RHS1      connected_order_arc_715  -13
    RHS1      connected_order_arc_717  -13
    RHS1      connected_order_arc_719  -13
    RHS1      connected_order_arc_721  -13
    RHS1      connected_order_arc_723  -13
    RHS1      connected_order_arc_725  -13
    RHS1      connected_order_arc_727  -13
    RHS1      connected_order_arc_729  -13
    RHS1      connected_order_arc_731  -13
    RHS1      connected_order_arc_734  -13
    RHS1      connected_order_arc_736  -13
    RHS1      connected_order_arc_738  -13
    RHS1      connected_order_arc_740  -13
    RHS1      connected_order_arc_742  -13
    RHS1      connected_order_arc_744  -13
    RHS1      connected_order_arc_746  -13
    RHS1      connected_order_arc_748  -13
    RHS1      connected_order_arc_750  -13
    RHS1      connected_order_arc_752  -13
    RHS1      connected_order_arc_754  -13
    RHS1      connected_order_arc_756  -13
    RHS1      connected_order_arc_759  -13
    RHS1      connected_order_arc_761  -13
    RHS1      connected_order_arc_763  -13
    RHS1      connected_order_arc_765  -13
    RHS1      connected_order_arc_767  -13
    RHS1      connected_order_arc_769  -13
    RHS1      connected_order_arc_771  -13
    RHS1      connected_order_arc_773  -13
    RHS1      connected_order_arc_775  -13
    RHS1      connected_order_arc_777  -13
    RHS1      connected_order_arc_779  -13
    RHS1      connected_order_arc_781  -13
    RHS1      depot_departure_or_bypass_782  1
    RHS1      depot_return_or_bypass_783  1
    RHS1      segment_load_conservation_788  18
    RHS1      segment_prefix_ub_790  2
    RHS1      segment_load_conservation_795  -8
    RHS1      segment_prefix_lb_796  8
    RHS1      segment_prefix_ub_797  20
    RHS1      segment_load_conservation_802  -1
    RHS1      segment_prefix_lb_803  1
    RHS1      segment_prefix_ub_804  20
    RHS1      segment_load_conservation_809  5
    RHS1      segment_prefix_ub_811  15
    RHS1      segment_load_conservation_816  -8
    RHS1      segment_prefix_lb_817  8
    RHS1      segment_prefix_ub_818  15
    RHS1      fixed_segment_relative_order_867  1
    RHS1      fixed_segment_relative_order_868  1
    RHS1      fixed_segment_relative_order_869  1
    RHS1      fixed_segment_relative_order_870  1
    RHS1      original_T_including_depot_unload_871  2.0640868624965742e+03
    RHS1      connected_order_arc_888  -13
    RHS1      connected_order_arc_890  -13
    RHS1      connected_order_arc_892  -13
    RHS1      connected_order_arc_894  -13
    RHS1      connected_order_arc_896  -13
    RHS1      connected_order_arc_898  -13
    RHS1      connected_order_arc_900  -13
    RHS1      connected_order_arc_902  -13
    RHS1      connected_order_arc_904  -13
    RHS1      connected_order_arc_906  -13
    RHS1      connected_order_arc_908  -13
    RHS1      connected_order_arc_910  -13
    RHS1      connected_order_arc_913  -13
    RHS1      connected_order_arc_915  -13
    RHS1      connected_order_arc_917  -13
    RHS1      connected_order_arc_919  -13
    RHS1      connected_order_arc_921  -13
    RHS1      connected_order_arc_923  -13
    RHS1      connected_order_arc_925  -13
    RHS1      connected_order_arc_927  -13
    RHS1      connected_order_arc_929  -13
    RHS1      connected_order_arc_931  -13
    RHS1      connected_order_arc_933  -13
    RHS1      connected_order_arc_935  -13
    RHS1      connected_order_arc_938  -13
    RHS1      connected_order_arc_940  -13
    RHS1      connected_order_arc_942  -13
    RHS1      connected_order_arc_944  -13
    RHS1      connected_order_arc_946  -13
    RHS1      connected_order_arc_948  -13
    RHS1      connected_order_arc_950  -13
    RHS1      connected_order_arc_952  -13
    RHS1      connected_order_arc_954  -13
    RHS1      connected_order_arc_956  -13
    RHS1      connected_order_arc_958  -13
    RHS1      connected_order_arc_960  -13
    RHS1      connected_order_arc_963  -13
    RHS1      connected_order_arc_965  -13
    RHS1      connected_order_arc_967  -13
    RHS1      connected_order_arc_969  -13
    RHS1      connected_order_arc_971  -13
    RHS1      connected_order_arc_973  -13
    RHS1      connected_order_arc_975  -13
    RHS1      connected_order_arc_977  -13
    RHS1      connected_order_arc_979  -13
    RHS1      connected_order_arc_981  -13
    RHS1      connected_order_arc_983  -13
    RHS1      connected_order_arc_985  -13
    RHS1      connected_order_arc_988  -13
    RHS1      connected_order_arc_990  -13
    RHS1      connected_order_arc_992  -13
    RHS1      connected_order_arc_994  -13
    RHS1      connected_order_arc_996  -13
    RHS1      connected_order_arc_998  -13
    RHS1      connected_order_arc_1000  -13
    RHS1      connected_order_arc_1002  -13
    RHS1      connected_order_arc_1004  -13
    RHS1      connected_order_arc_1006  -13
    RHS1      connected_order_arc_1008  -13
    RHS1      connected_order_arc_1010  -13
    RHS1      connected_order_arc_1013  -13
    RHS1      connected_order_arc_1015  -13
    RHS1      connected_order_arc_1017  -13
    RHS1      connected_order_arc_1019  -13
    RHS1      connected_order_arc_1021  -13
    RHS1      connected_order_arc_1023  -13
    RHS1      connected_order_arc_1025  -13
    RHS1      connected_order_arc_1027  -13
    RHS1      connected_order_arc_1029  -13
    RHS1      connected_order_arc_1031  -13
    RHS1      connected_order_arc_1033  -13
    RHS1      connected_order_arc_1035  -13
    RHS1      connected_order_arc_1038  -13
    RHS1      connected_order_arc_1040  -13
    RHS1      connected_order_arc_1042  -13
    RHS1      connected_order_arc_1044  -13
    RHS1      connected_order_arc_1046  -13
    RHS1      connected_order_arc_1048  -13
    RHS1      connected_order_arc_1050  -13
    RHS1      connected_order_arc_1052  -13
    RHS1      connected_order_arc_1054  -13
    RHS1      connected_order_arc_1056  -13
    RHS1      connected_order_arc_1058  -13
    RHS1      connected_order_arc_1060  -13
    RHS1      connected_order_arc_1063  -13
    RHS1      connected_order_arc_1065  -13
    RHS1      connected_order_arc_1067  -13
    RHS1      connected_order_arc_1069  -13
    RHS1      connected_order_arc_1071  -13
    RHS1      connected_order_arc_1073  -13
    RHS1      connected_order_arc_1075  -13
    RHS1      connected_order_arc_1077  -13
    RHS1      connected_order_arc_1079  -13
    RHS1      connected_order_arc_1081  -13
    RHS1      connected_order_arc_1083  -13
    RHS1      connected_order_arc_1085  -13
    RHS1      connected_order_arc_1088  -13
    RHS1      connected_order_arc_1090  -13
    RHS1      connected_order_arc_1092  -13
    RHS1      connected_order_arc_1094  -13
    RHS1      connected_order_arc_1096  -13
    RHS1      connected_order_arc_1098  -13
    RHS1      connected_order_arc_1100  -13
    RHS1      connected_order_arc_1102  -13
    RHS1      connected_order_arc_1104  -13
    RHS1      connected_order_arc_1106  -13
    RHS1      connected_order_arc_1108  -13
    RHS1      connected_order_arc_1110  -13
    RHS1      connected_order_arc_1113  -13
    RHS1      connected_order_arc_1115  -13
    RHS1      connected_order_arc_1117  -13
    RHS1      connected_order_arc_1119  -13
    RHS1      connected_order_arc_1121  -13
    RHS1      connected_order_arc_1123  -13
    RHS1      connected_order_arc_1125  -13
    RHS1      connected_order_arc_1127  -13
    RHS1      connected_order_arc_1129  -13
    RHS1      connected_order_arc_1131  -13
    RHS1      connected_order_arc_1133  -13
    RHS1      connected_order_arc_1135  -13
    RHS1      connected_order_arc_1138  -13
    RHS1      connected_order_arc_1140  -13
    RHS1      connected_order_arc_1142  -13
    RHS1      connected_order_arc_1144  -13
    RHS1      connected_order_arc_1146  -13
    RHS1      connected_order_arc_1148  -13
    RHS1      connected_order_arc_1150  -13
    RHS1      connected_order_arc_1152  -13
    RHS1      connected_order_arc_1154  -13
    RHS1      connected_order_arc_1156  -13
    RHS1      connected_order_arc_1158  -13
    RHS1      connected_order_arc_1160  -13
    RHS1      connected_order_arc_1163  -13
    RHS1      connected_order_arc_1165  -13
    RHS1      connected_order_arc_1167  -13
    RHS1      connected_order_arc_1169  -13
    RHS1      connected_order_arc_1171  -13
    RHS1      connected_order_arc_1173  -13
    RHS1      connected_order_arc_1175  -13
    RHS1      connected_order_arc_1177  -13
    RHS1      connected_order_arc_1179  -13
    RHS1      connected_order_arc_1181  -13
    RHS1      connected_order_arc_1183  -13
    RHS1      connected_order_arc_1185  -13
    RHS1      connected_order_arc_1188  -13
    RHS1      connected_order_arc_1190  -13
    RHS1      connected_order_arc_1192  -13
    RHS1      connected_order_arc_1194  -13
    RHS1      connected_order_arc_1196  -13
    RHS1      connected_order_arc_1198  -13
    RHS1      connected_order_arc_1200  -13
    RHS1      connected_order_arc_1202  -13
    RHS1      connected_order_arc_1204  -13
    RHS1      connected_order_arc_1206  -13
    RHS1      connected_order_arc_1208  -13
    RHS1      connected_order_arc_1210  -13
    RHS1      depot_departure_or_bypass_1211  1
    RHS1      depot_return_or_bypass_1212  1
    RHS1      segment_load_conservation_1217  3
    RHS1      segment_prefix_ub_1219  22
    RHS1      segment_load_conservation_1224  -1
    RHS1      segment_prefix_lb_1225  1
    RHS1      segment_prefix_ub_1226  25
    RHS1      segment_load_conservation_1231  -5
    RHS1      segment_prefix_lb_1232  5
    RHS1      segment_prefix_ub_1233  25
    RHS1      segment_load_conservation_1238  -1
    RHS1      segment_prefix_lb_1239  1
    RHS1      segment_prefix_ub_1240  19
    RHS1      segment_load_conservation_1245  -2
    RHS1      segment_prefix_lb_1246  2
    RHS1      segment_prefix_ub_1247  25
    RHS1      fixed_segment_relative_order_1296  1
    RHS1      fixed_segment_relative_order_1297  1
    RHS1      fixed_segment_relative_order_1298  1
    RHS1      fixed_segment_relative_order_1299  1
    RHS1      original_T_including_depot_unload_1300  5.7189752491270210e+03
    RHS1      connected_order_arc_1315  -11
    RHS1      connected_order_arc_1317  -11
    RHS1      connected_order_arc_1319  -11
    RHS1      connected_order_arc_1321  -11
    RHS1      connected_order_arc_1323  -11
    RHS1      connected_order_arc_1325  -11
    RHS1      connected_order_arc_1327  -11
    RHS1      connected_order_arc_1329  -11
    RHS1      connected_order_arc_1331  -11
    RHS1      connected_order_arc_1333  -11
    RHS1      connected_order_arc_1336  -11
    RHS1      connected_order_arc_1338  -11
    RHS1      connected_order_arc_1340  -11
    RHS1      connected_order_arc_1342  -11
    RHS1      connected_order_arc_1344  -11
    RHS1      connected_order_arc_1346  -11
    RHS1      connected_order_arc_1348  -11
    RHS1      connected_order_arc_1350  -11
    RHS1      connected_order_arc_1352  -11
    RHS1      connected_order_arc_1354  -11
    RHS1      connected_order_arc_1357  -11
    RHS1      connected_order_arc_1359  -11
    RHS1      connected_order_arc_1361  -11
    RHS1      connected_order_arc_1363  -11
    RHS1      connected_order_arc_1365  -11
    RHS1      connected_order_arc_1367  -11
    RHS1      connected_order_arc_1369  -11
    RHS1      connected_order_arc_1371  -11
    RHS1      connected_order_arc_1373  -11
    RHS1      connected_order_arc_1375  -11
    RHS1      connected_order_arc_1378  -11
    RHS1      connected_order_arc_1380  -11
    RHS1      connected_order_arc_1382  -11
    RHS1      connected_order_arc_1384  -11
    RHS1      connected_order_arc_1386  -11
    RHS1      connected_order_arc_1388  -11
    RHS1      connected_order_arc_1390  -11
    RHS1      connected_order_arc_1392  -11
    RHS1      connected_order_arc_1394  -11
    RHS1      connected_order_arc_1396  -11
    RHS1      connected_order_arc_1399  -11
    RHS1      connected_order_arc_1401  -11
    RHS1      connected_order_arc_1403  -11
    RHS1      connected_order_arc_1405  -11
    RHS1      connected_order_arc_1407  -11
    RHS1      connected_order_arc_1409  -11
    RHS1      connected_order_arc_1411  -11
    RHS1      connected_order_arc_1413  -11
    RHS1      connected_order_arc_1415  -11
    RHS1      connected_order_arc_1417  -11
    RHS1      connected_order_arc_1420  -11
    RHS1      connected_order_arc_1422  -11
    RHS1      connected_order_arc_1424  -11
    RHS1      connected_order_arc_1426  -11
    RHS1      connected_order_arc_1428  -11
    RHS1      connected_order_arc_1430  -11
    RHS1      connected_order_arc_1432  -11
    RHS1      connected_order_arc_1434  -11
    RHS1      connected_order_arc_1436  -11
    RHS1      connected_order_arc_1438  -11
    RHS1      connected_order_arc_1441  -11
    RHS1      connected_order_arc_1443  -11
    RHS1      connected_order_arc_1445  -11
    RHS1      connected_order_arc_1447  -11
    RHS1      connected_order_arc_1449  -11
    RHS1      connected_order_arc_1451  -11
    RHS1      connected_order_arc_1453  -11
    RHS1      connected_order_arc_1455  -11
    RHS1      connected_order_arc_1457  -11
    RHS1      connected_order_arc_1459  -11
    RHS1      connected_order_arc_1462  -11
    RHS1      connected_order_arc_1464  -11
    RHS1      connected_order_arc_1466  -11
    RHS1      connected_order_arc_1468  -11
    RHS1      connected_order_arc_1470  -11
    RHS1      connected_order_arc_1472  -11
    RHS1      connected_order_arc_1474  -11
    RHS1      connected_order_arc_1476  -11
    RHS1      connected_order_arc_1478  -11
    RHS1      connected_order_arc_1480  -11
    RHS1      connected_order_arc_1483  -11
    RHS1      connected_order_arc_1485  -11
    RHS1      connected_order_arc_1487  -11
    RHS1      connected_order_arc_1489  -11
    RHS1      connected_order_arc_1491  -11
    RHS1      connected_order_arc_1493  -11
    RHS1      connected_order_arc_1495  -11
    RHS1      connected_order_arc_1497  -11
    RHS1      connected_order_arc_1499  -11
    RHS1      connected_order_arc_1501  -11
    RHS1      connected_order_arc_1504  -11
    RHS1      connected_order_arc_1506  -11
    RHS1      connected_order_arc_1508  -11
    RHS1      connected_order_arc_1510  -11
    RHS1      connected_order_arc_1512  -11
    RHS1      connected_order_arc_1514  -11
    RHS1      connected_order_arc_1516  -11
    RHS1      connected_order_arc_1518  -11
    RHS1      connected_order_arc_1520  -11
    RHS1      connected_order_arc_1522  -11
    RHS1      connected_order_arc_1525  -11
    RHS1      connected_order_arc_1527  -11
    RHS1      connected_order_arc_1529  -11
    RHS1      connected_order_arc_1531  -11
    RHS1      connected_order_arc_1533  -11
    RHS1      connected_order_arc_1535  -11
    RHS1      connected_order_arc_1537  -11
    RHS1      connected_order_arc_1539  -11
    RHS1      connected_order_arc_1541  -11
    RHS1      connected_order_arc_1543  -11
    RHS1      depot_departure_or_bypass_1544  1
    RHS1      depot_return_or_bypass_1545  1
    RHS1      segment_load_conservation_1550  2
    RHS1      segment_prefix_ub_1552  28
    RHS1      segment_load_conservation_1557  3
    RHS1      segment_prefix_ub_1559  27
    RHS1      segment_load_conservation_1564  -5
    RHS1      segment_prefix_lb_1565  5
    RHS1      segment_prefix_ub_1566  30
    RHS1      fixed_segment_relative_order_1615  1
    RHS1      fixed_segment_relative_order_1616  1
    RHS1      original_T_including_depot_unload_1617  4.3627402060403792e+03
BOUNDS
 LO BND1      t         2.4726245143034259e-02
 UP BND1      t         4.1654269562671840e-02
 UP BND1      q         5.7721795463888015e-01
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.1654269562671840e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.1654269562671840e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.1654269562671840e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.1654269562671840e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.1654269562671840e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.1654269562671840e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.1654269562671840e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.1654269562671840e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.1654269562671840e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.1654269562671840e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.1654269562671840e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.1654269562671840e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.1654269562671840e-02
 UP BND1      rho_31    1
 BV BND1      x_25_0  
 UP BND1      w_25_0    4.1654269562671840e-02
 BV BND1      x_25_1  
 UP BND1      w_25_1    4.1654269562671840e-02
 BV BND1      x_25_2  
 UP BND1      w_25_2    4.1654269562671840e-02
 BV BND1      x_25_3  
 UP BND1      w_25_3    4.1654269562671840e-02
 BV BND1      x_25_4  
 UP BND1      w_25_4    4.1654269562671840e-02
 BV BND1      x_25_5  
 UP BND1      w_25_5    4.1654269562671840e-02
 BV BND1      x_25_6  
 UP BND1      w_25_6    4.1654269562671840e-02
 BV BND1      x_25_7  
 UP BND1      w_25_7    4.1654269562671840e-02
 BV BND1      x_25_8  
 UP BND1      w_25_8    4.1654269562671840e-02
 BV BND1      x_25_9  
 UP BND1      w_25_9    4.1654269562671840e-02
 BV BND1      x_25_10 
 UP BND1      w_25_10   4.1654269562671840e-02
 BV BND1      x_25_11 
 UP BND1      w_25_11   4.1654269562671840e-02
 BV BND1      x_25_12 
 UP BND1      w_25_12   4.1654269562671840e-02
 BV BND1      x_25_13 
 UP BND1      w_25_13   4.1654269562671840e-02
 BV BND1      x_25_14 
 UP BND1      w_25_14   4.1654269562671840e-02
 BV BND1      x_25_15 
 UP BND1      w_25_15   4.1654269562671840e-02
 UP BND1      rho_25    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.1654269562671840e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.1654269562671840e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.1654269562671840e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.1654269562671840e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.1654269562671840e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.1654269562671840e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.1654269562671840e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.1654269562671840e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.1654269562671840e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.1654269562671840e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.1654269562671840e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.1654269562671840e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.1654269562671840e-02
 UP BND1      rho_32    1
 BV BND1      x_29_0  
 UP BND1      w_29_0    4.1654269562671840e-02
 BV BND1      x_29_1  
 UP BND1      w_29_1    4.1654269562671840e-02
 BV BND1      x_29_2  
 UP BND1      w_29_2    4.1654269562671840e-02
 BV BND1      x_29_3  
 UP BND1      w_29_3    4.1654269562671840e-02
 BV BND1      x_29_4  
 UP BND1      w_29_4    4.1654269562671840e-02
 BV BND1      x_29_5  
 UP BND1      w_29_5    4.1654269562671840e-02
 BV BND1      x_29_6  
 UP BND1      w_29_6    4.1654269562671840e-02
 BV BND1      x_29_7  
 UP BND1      w_29_7    4.1654269562671840e-02
 BV BND1      x_29_8  
 UP BND1      w_29_8    4.1654269562671840e-02
 BV BND1      x_29_9  
 UP BND1      w_29_9    4.1654269562671840e-02
 BV BND1      x_29_10 
 UP BND1      w_29_10   4.1654269562671840e-02
 BV BND1      x_29_11 
 UP BND1      w_29_11   4.1654269562671840e-02
 BV BND1      x_29_12 
 UP BND1      w_29_12   4.1654269562671840e-02
 BV BND1      x_29_13 
 UP BND1      w_29_13   4.1654269562671840e-02
 BV BND1      x_29_14 
 UP BND1      w_29_14   4.1654269562671840e-02
 BV BND1      x_29_15 
 UP BND1      w_29_15   4.1654269562671840e-02
 UP BND1      rho_29    1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.1654269562671840e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.1654269562671840e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.1654269562671840e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.1654269562671840e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.1654269562671840e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.1654269562671840e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.1654269562671840e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.1654269562671840e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.1654269562671840e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.1654269562671840e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.1654269562671840e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.1654269562671840e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.1654269562671840e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.1654269562671840e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.1654269562671840e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.1654269562671840e-02
 UP BND1      rho_2     1
 BV BND1      x_24_0  
 UP BND1      w_24_0    4.1654269562671840e-02
 BV BND1      x_24_1  
 UP BND1      w_24_1    4.1654269562671840e-02
 BV BND1      x_24_2  
 UP BND1      w_24_2    4.1654269562671840e-02
 BV BND1      x_24_3  
 UP BND1      w_24_3    4.1654269562671840e-02
 BV BND1      x_24_4  
 UP BND1      w_24_4    4.1654269562671840e-02
 BV BND1      x_24_5  
 UP BND1      w_24_5    4.1654269562671840e-02
 BV BND1      x_24_6  
 UP BND1      w_24_6    4.1654269562671840e-02
 BV BND1      x_24_7  
 UP BND1      w_24_7    4.1654269562671840e-02
 BV BND1      x_24_8  
 UP BND1      w_24_8    4.1654269562671840e-02
 BV BND1      x_24_9  
 UP BND1      w_24_9    4.1654269562671840e-02
 BV BND1      x_24_10 
 UP BND1      w_24_10   4.1654269562671840e-02
 BV BND1      x_24_11 
 UP BND1      w_24_11   4.1654269562671840e-02
 BV BND1      x_24_12 
 UP BND1      w_24_12   4.1654269562671840e-02
 BV BND1      x_24_13 
 UP BND1      w_24_13   4.1654269562671840e-02
 BV BND1      x_24_14 
 UP BND1      w_24_14   4.1654269562671840e-02
 BV BND1      x_24_15 
 UP BND1      w_24_15   4.1654269562671840e-02
 UP BND1      rho_24    1
 BV BND1      x_12_0  
 UP BND1      w_12_0    4.1654269562671840e-02
 BV BND1      x_12_1  
 UP BND1      w_12_1    4.1654269562671840e-02
 BV BND1      x_12_2  
 UP BND1      w_12_2    4.1654269562671840e-02
 BV BND1      x_12_3  
 UP BND1      w_12_3    4.1654269562671840e-02
 BV BND1      x_12_4  
 UP BND1      w_12_4    4.1654269562671840e-02
 BV BND1      x_12_5  
 UP BND1      w_12_5    4.1654269562671840e-02
 BV BND1      x_12_6  
 UP BND1      w_12_6    4.1654269562671840e-02
 BV BND1      x_12_7  
 UP BND1      w_12_7    4.1654269562671840e-02
 BV BND1      x_12_8  
 UP BND1      w_12_8    4.1654269562671840e-02
 BV BND1      x_12_9  
 UP BND1      w_12_9    4.1654269562671840e-02
 BV BND1      x_12_10 
 UP BND1      w_12_10   4.1654269562671840e-02
 BV BND1      x_12_11 
 UP BND1      w_12_11   4.1654269562671840e-02
 BV BND1      x_12_12 
 UP BND1      w_12_12   4.1654269562671840e-02
 BV BND1      x_12_13 
 UP BND1      w_12_13   4.1654269562671840e-02
 BV BND1      x_12_14 
 UP BND1      w_12_14   4.1654269562671840e-02
 BV BND1      x_12_15 
 UP BND1      w_12_15   4.1654269562671840e-02
 UP BND1      rho_12    1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.1654269562671840e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.1654269562671840e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.1654269562671840e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.1654269562671840e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.1654269562671840e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.1654269562671840e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.1654269562671840e-02
 BV BND1      x_27_7  
 UP BND1      w_27_7    4.1654269562671840e-02
 BV BND1      x_27_8  
 UP BND1      w_27_8    4.1654269562671840e-02
 BV BND1      x_27_9  
 UP BND1      w_27_9    4.1654269562671840e-02
 BV BND1      x_27_10 
 UP BND1      w_27_10   4.1654269562671840e-02
 BV BND1      x_27_11 
 UP BND1      w_27_11   4.1654269562671840e-02
 BV BND1      x_27_12 
 UP BND1      w_27_12   4.1654269562671840e-02
 BV BND1      x_27_13 
 UP BND1      w_27_13   4.1654269562671840e-02
 BV BND1      x_27_14 
 UP BND1      w_27_14   4.1654269562671840e-02
 BV BND1      x_27_15 
 UP BND1      w_27_15   4.1654269562671840e-02
 UP BND1      rho_27    1
 UP BND1      a_31_25   1
 UP BND1      a_31_32   1
 UP BND1      a_31_29   1
 UP BND1      a_31_2    1
 UP BND1      a_31_24   1
 UP BND1      a_31_12   1
 UP BND1      a_31_27   1
 UP BND1      a_25_32   1
 UP BND1      a_25_29   1
 UP BND1      a_25_2    1
 UP BND1      a_25_24   1
 UP BND1      a_25_12   1
 UP BND1      a_25_27   1
 UP BND1      a_32_29   1
 UP BND1      a_32_2    1
 UP BND1      a_32_24   1
 UP BND1      a_32_12   1
 UP BND1      a_32_27   1
 UP BND1      a_29_2    1
 UP BND1      a_29_24   1
 UP BND1      a_29_12   1
 UP BND1      a_29_27   1
 UP BND1      a_2_24    1
 UP BND1      a_2_12    1
 UP BND1      a_2_27    1
 UP BND1      a_24_12   1
 UP BND1      a_24_27   1
 UP BND1      a_12_27   1
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_25_0
 BV BND1      service_0_25_2
 BV BND1      service_0_25_3
 BV BND1      service_0_25_4
 BV BND1      service_0_25_5
 BV BND1      service_0_25_6
 BV BND1      service_0_25_7
 BV BND1      service_0_25_8
 BV BND1      service_0_25_9
 BV BND1      service_0_25_10
 BV BND1      service_0_25_11
 BV BND1      service_0_25_12
 BV BND1      service_0_25_13
 BV BND1      service_0_25_14
 BV BND1      service_0_25_15
 BV BND1      service_1_25_0
 BV BND1      service_1_25_2
 BV BND1      service_1_25_3
 BV BND1      service_1_25_4
 BV BND1      service_1_25_5
 BV BND1      service_1_25_6
 BV BND1      service_1_25_7
 BV BND1      service_1_25_8
 BV BND1      service_1_25_9
 BV BND1      service_1_25_10
 BV BND1      service_1_25_11
 BV BND1      service_1_25_12
 BV BND1      service_1_25_13
 BV BND1      service_1_25_14
 BV BND1      service_1_25_15
 BV BND1      service_2_25_0
 BV BND1      service_2_25_2
 BV BND1      service_2_25_3
 BV BND1      service_2_25_4
 BV BND1      service_2_25_5
 BV BND1      service_2_25_6
 BV BND1      service_2_25_7
 BV BND1      service_2_25_8
 BV BND1      service_2_25_9
 BV BND1      service_2_25_10
 BV BND1      service_2_25_11
 BV BND1      service_2_25_12
 BV BND1      service_2_25_13
 BV BND1      service_2_25_14
 BV BND1      service_2_25_15
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_29_0
 BV BND1      service_0_29_1
 BV BND1      service_0_29_2
 BV BND1      service_0_29_3
 BV BND1      service_0_29_4
 BV BND1      service_0_29_5
 BV BND1      service_0_29_6
 BV BND1      service_0_29_7
 BV BND1      service_0_29_8
 BV BND1      service_0_29_9
 BV BND1      service_0_29_10
 BV BND1      service_0_29_12
 BV BND1      service_0_29_13
 BV BND1      service_0_29_14
 BV BND1      service_0_29_15
 BV BND1      service_1_29_0
 BV BND1      service_1_29_1
 BV BND1      service_1_29_2
 BV BND1      service_1_29_3
 BV BND1      service_1_29_4
 BV BND1      service_1_29_5
 BV BND1      service_1_29_6
 BV BND1      service_1_29_7
 BV BND1      service_1_29_8
 BV BND1      service_1_29_9
 BV BND1      service_1_29_10
 BV BND1      service_1_29_12
 BV BND1      service_1_29_13
 BV BND1      service_1_29_14
 BV BND1      service_1_29_15
 BV BND1      service_2_29_0
 BV BND1      service_2_29_1
 BV BND1      service_2_29_2
 BV BND1      service_2_29_3
 BV BND1      service_2_29_4
 BV BND1      service_2_29_5
 BV BND1      service_2_29_6
 BV BND1      service_2_29_7
 BV BND1      service_2_29_8
 BV BND1      service_2_29_9
 BV BND1      service_2_29_10
 BV BND1      service_2_29_12
 BV BND1      service_2_29_13
 BV BND1      service_2_29_14
 BV BND1      service_2_29_15
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_24_0
 BV BND1      service_0_24_1
 BV BND1      service_0_24_2
 BV BND1      service_0_24_3
 BV BND1      service_0_24_4
 BV BND1      service_0_24_5
 BV BND1      service_0_24_6
 BV BND1      service_0_24_7
 BV BND1      service_0_24_8
 BV BND1      service_0_24_9
 BV BND1      service_0_24_10
 BV BND1      service_0_24_12
 BV BND1      service_0_24_13
 BV BND1      service_0_24_14
 BV BND1      service_0_24_15
 BV BND1      service_1_24_0
 BV BND1      service_1_24_1
 BV BND1      service_1_24_2
 BV BND1      service_1_24_3
 BV BND1      service_1_24_4
 BV BND1      service_1_24_5
 BV BND1      service_1_24_6
 BV BND1      service_1_24_7
 BV BND1      service_1_24_8
 BV BND1      service_1_24_9
 BV BND1      service_1_24_10
 BV BND1      service_1_24_12
 BV BND1      service_1_24_13
 BV BND1      service_1_24_14
 BV BND1      service_1_24_15
 BV BND1      service_2_24_0
 BV BND1      service_2_24_1
 BV BND1      service_2_24_2
 BV BND1      service_2_24_3
 BV BND1      service_2_24_4
 BV BND1      service_2_24_5
 BV BND1      service_2_24_6
 BV BND1      service_2_24_7
 BV BND1      service_2_24_8
 BV BND1      service_2_24_9
 BV BND1      service_2_24_10
 BV BND1      service_2_24_12
 BV BND1      service_2_24_13
 BV BND1      service_2_24_14
 BV BND1      service_2_24_15
 BV BND1      service_0_12_1
 BV BND1      service_0_12_2
 BV BND1      service_0_12_3
 BV BND1      service_0_12_4
 BV BND1      service_0_12_5
 BV BND1      service_0_12_6
 BV BND1      service_0_12_7
 BV BND1      service_0_12_8
 BV BND1      service_0_12_9
 BV BND1      service_0_12_10
 BV BND1      service_0_12_11
 BV BND1      service_0_12_12
 BV BND1      service_0_12_13
 BV BND1      service_0_12_14
 BV BND1      service_0_12_15
 BV BND1      service_1_12_1
 BV BND1      service_1_12_2
 BV BND1      service_1_12_3
 BV BND1      service_1_12_4
 BV BND1      service_1_12_5
 BV BND1      service_1_12_6
 BV BND1      service_1_12_7
 BV BND1      service_1_12_8
 BV BND1      service_1_12_9
 BV BND1      service_1_12_10
 BV BND1      service_1_12_11
 BV BND1      service_1_12_12
 BV BND1      service_1_12_13
 BV BND1      service_1_12_14
 BV BND1      service_1_12_15
 BV BND1      service_2_12_1
 BV BND1      service_2_12_2
 BV BND1      service_2_12_3
 BV BND1      service_2_12_4
 BV BND1      service_2_12_5
 BV BND1      service_2_12_6
 BV BND1      service_2_12_7
 BV BND1      service_2_12_8
 BV BND1      service_2_12_9
 BV BND1      service_2_12_10
 BV BND1      service_2_12_11
 BV BND1      service_2_12_12
 BV BND1      service_2_12_13
 BV BND1      service_2_12_14
 BV BND1      service_2_12_15
 BV BND1      service_0_27_0
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_0_27_7
 BV BND1      service_0_27_8
 BV BND1      service_0_27_9
 BV BND1      service_0_27_10
 BV BND1      service_0_27_12
 BV BND1      service_0_27_13
 BV BND1      service_0_27_14
 BV BND1      service_0_27_15
 BV BND1      service_1_27_0
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_1_27_7
 BV BND1      service_1_27_8
 BV BND1      service_1_27_9
 BV BND1      service_1_27_10
 BV BND1      service_1_27_12
 BV BND1      service_1_27_13
 BV BND1      service_1_27_14
 BV BND1      service_1_27_15
 BV BND1      service_2_27_0
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_2_27_7
 BV BND1      service_2_27_8
 BV BND1      service_2_27_9
 BV BND1      service_2_27_10
 BV BND1      service_2_27_12
 BV BND1      service_2_27_13
 BV BND1      service_2_27_14
 BV BND1      service_2_27_15
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_14_21
 UP BND1      load_0_14_21  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_14
 UP BND1      load_0_21_14  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  13
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  13
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  13
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  13
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  13
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  13
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  13
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  13
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  13
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  13
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  13
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  13
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  13
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_10
 UP BND1      load_1_6_10  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_6_21
 UP BND1      load_1_6_21  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  25
 BV BND1      arc_1_10_6
 UP BND1      load_1_10_6  25
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  25
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  25
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  25
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  25
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  25
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  25
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  25
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  25
 BV BND1      arc_1_10_19
 UP BND1      load_1_10_19  25
 BV BND1      arc_1_10_20
 UP BND1      load_1_10_20  25
 BV BND1      arc_1_10_21
 UP BND1      load_1_10_21  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_14_21
 UP BND1      load_1_14_21  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_10
 UP BND1      load_1_19_10  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_10
 UP BND1      load_1_20_10  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_6
 UP BND1      load_1_21_6  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_10
 UP BND1      load_1_21_10  25
 BV BND1      arc_1_21_14
 UP BND1      load_1_21_14  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
ENDATA
