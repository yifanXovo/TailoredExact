* Signature: 0x6ef21b4759206155
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 E  onehot_16_26
 E  normalized_mass_16_27
 E  normalized_ratio_16_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 E  onehot_11_55
 E  normalized_mass_11_56
 E  normalized_ratio_11_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 E  onehot_31_84
 E  normalized_mass_31_85
 E  normalized_ratio_31_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 E  onehot_20_113
 E  normalized_mass_20_114
 E  normalized_ratio_20_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 E  onehot_32_142
 E  normalized_mass_32_143
 E  normalized_ratio_32_144
 G  product_lb_145
 L  product_ub_146
 G  product_lb_147
 L  product_ub_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 E  onehot_21_177
 E  normalized_mass_21_178
 E  normalized_ratio_21_179
 G  product_lb_180
 L  product_ub_181
 G  product_lb_182
 L  product_ub_183
 G  product_lb_184
 L  product_ub_185
 G  product_lb_186
 L  product_ub_187
 G  product_lb_188
 L  product_ub_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 E  onehot_2_212
 E  normalized_mass_2_213
 E  normalized_ratio_2_214
 G  product_lb_215
 L  product_ub_216
 G  product_lb_217
 L  product_ub_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 E  onehot_7_251
 E  normalized_mass_7_252
 E  normalized_ratio_7_253
 G  stock_lb_254
 L  stock_ub_255
 L  parent_nonstrict_scope_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 E  normalization_313
 G  full_original_Gini_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 L  arc_capacity_422
 L  arc_capacity_423
 L  arc_capacity_424
 L  arc_capacity_425
 L  arc_capacity_426
 L  arc_capacity_427
 L  arc_capacity_428
 L  arc_capacity_429
 L  arc_capacity_430
 L  arc_capacity_431
 L  arc_capacity_432
 L  arc_capacity_433
 L  arc_capacity_434
 L  arc_capacity_435
 L  arc_capacity_436
 L  arc_capacity_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 G  connected_order_arc_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 G  connected_order_arc_748
 L  arc_capacity_749
 G  connected_order_arc_750
 L  arc_capacity_751
 G  connected_order_arc_752
 L  arc_capacity_753
 G  connected_order_arc_754
 L  arc_capacity_755
 G  connected_order_arc_756
 L  arc_capacity_757
 G  connected_order_arc_758
 L  arc_capacity_759
 G  connected_order_arc_760
 L  arc_capacity_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 L  arc_capacity_768
 G  connected_order_arc_769
 L  arc_capacity_770
 G  connected_order_arc_771
 L  arc_capacity_772
 G  connected_order_arc_773
 L  arc_capacity_774
 G  connected_order_arc_775
 L  arc_capacity_776
 G  connected_order_arc_777
 L  arc_capacity_778
 G  connected_order_arc_779
 L  arc_capacity_780
 G  connected_order_arc_781
 L  arc_capacity_782
 G  connected_order_arc_783
 L  arc_capacity_784
 G  connected_order_arc_785
 L  arc_capacity_786
 G  connected_order_arc_787
 L  arc_capacity_788
 L  arc_capacity_789
 G  connected_order_arc_790
 L  arc_capacity_791
 G  connected_order_arc_792
 L  arc_capacity_793
 G  connected_order_arc_794
 L  arc_capacity_795
 G  connected_order_arc_796
 L  arc_capacity_797
 G  connected_order_arc_798
 L  arc_capacity_799
 G  connected_order_arc_800
 L  arc_capacity_801
 G  connected_order_arc_802
 L  arc_capacity_803
 G  connected_order_arc_804
 L  arc_capacity_805
 G  connected_order_arc_806
 L  arc_capacity_807
 G  connected_order_arc_808
 L  arc_capacity_809
 G  connected_order_arc_810
 L  arc_capacity_811
 G  connected_order_arc_812
 L  arc_capacity_813
 G  connected_order_arc_814
 E  depot_departure_or_bypass_815
 E  depot_return_or_bypass_816
 E  out_degree_817
 E  in_degree_818
 G  order_active_lb_819
 L  order_active_ub_820
 E  segment_load_conservation_821
 G  segment_prefix_lb_822
 L  segment_prefix_ub_823
 E  out_degree_824
 E  in_degree_825
 G  order_active_lb_826
 L  order_active_ub_827
 E  segment_load_conservation_828
 G  segment_prefix_lb_829
 L  segment_prefix_ub_830
 E  out_degree_831
 E  in_degree_832
 G  order_active_lb_833
 L  order_active_ub_834
 E  segment_load_conservation_835
 G  segment_prefix_lb_836
 L  segment_prefix_ub_837
 E  out_degree_838
 E  in_degree_839
 G  order_active_lb_840
 L  order_active_ub_841
 E  segment_load_conservation_842
 G  segment_prefix_lb_843
 L  segment_prefix_ub_844
 E  out_degree_845
 E  in_degree_846
 G  order_active_lb_847
 L  order_active_ub_848
 E  segment_load_conservation_849
 G  segment_prefix_lb_850
 L  segment_prefix_ub_851
 E  out_degree_852
 E  in_degree_853
 G  order_active_lb_854
 L  order_active_ub_855
 E  segment_load_conservation_856
 G  segment_prefix_lb_857
 L  segment_prefix_ub_858
 E  out_degree_859
 E  in_degree_860
 G  order_active_lb_861
 L  order_active_ub_862
 E  service_visit_def_863
 E  free_load_conservation_864
 E  out_degree_865
 E  in_degree_866
 G  order_active_lb_867
 L  order_active_ub_868
 E  service_visit_def_869
 E  free_load_conservation_870
 E  out_degree_871
 E  in_degree_872
 G  order_active_lb_873
 L  order_active_ub_874
 E  service_visit_def_875
 E  free_load_conservation_876
 E  out_degree_877
 E  in_degree_878
 G  order_active_lb_879
 L  order_active_ub_880
 E  service_visit_def_881
 E  free_load_conservation_882
 E  out_degree_883
 E  in_degree_884
 G  order_active_lb_885
 L  order_active_ub_886
 E  service_visit_def_887
 E  free_load_conservation_888
 E  out_degree_889
 E  in_degree_890
 G  order_active_lb_891
 L  order_active_ub_892
 E  service_visit_def_893
 E  free_load_conservation_894
 E  out_degree_895
 E  in_degree_896
 G  order_active_lb_897
 L  order_active_ub_898
 E  service_visit_def_899
 E  free_load_conservation_900
 E  out_degree_901
 E  in_degree_902
 G  order_active_lb_903
 L  order_active_ub_904
 E  service_visit_def_905
 E  free_load_conservation_906
 G  fixed_segment_relative_order_907
 G  fixed_segment_relative_order_908
 G  fixed_segment_relative_order_909
 G  fixed_segment_relative_order_910
 G  fixed_segment_relative_order_911
 L  original_T_including_depot_unload_912
 L  arc_capacity_913
 L  arc_capacity_914
 L  arc_capacity_915
 L  arc_capacity_916
 L  arc_capacity_917
 L  arc_capacity_918
 L  arc_capacity_919
 L  arc_capacity_920
 L  arc_capacity_921
 L  arc_capacity_922
 L  arc_capacity_923
 L  arc_capacity_924
 L  arc_capacity_925
 L  arc_capacity_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 L  arc_capacity_1134
 G  connected_order_arc_1135
 L  arc_capacity_1136
 G  connected_order_arc_1137
 L  arc_capacity_1138
 G  connected_order_arc_1139
 L  arc_capacity_1140
 G  connected_order_arc_1141
 L  arc_capacity_1142
 G  connected_order_arc_1143
 L  arc_capacity_1144
 G  connected_order_arc_1145
 L  arc_capacity_1146
 G  connected_order_arc_1147
 L  arc_capacity_1148
 G  connected_order_arc_1149
 L  arc_capacity_1150
 G  connected_order_arc_1151
 L  arc_capacity_1152
 G  connected_order_arc_1153
 L  arc_capacity_1154
 G  connected_order_arc_1155
 L  arc_capacity_1156
 L  arc_capacity_1157
 G  connected_order_arc_1158
 L  arc_capacity_1159
 G  connected_order_arc_1160
 L  arc_capacity_1161
 G  connected_order_arc_1162
 L  arc_capacity_1163
 G  connected_order_arc_1164
 L  arc_capacity_1165
 G  connected_order_arc_1166
 L  arc_capacity_1167
 G  connected_order_arc_1168
 L  arc_capacity_1169
 G  connected_order_arc_1170
 L  arc_capacity_1171
 G  connected_order_arc_1172
 L  arc_capacity_1173
 G  connected_order_arc_1174
 L  arc_capacity_1175
 G  connected_order_arc_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 L  arc_capacity_1180
 G  connected_order_arc_1181
 L  arc_capacity_1182
 G  connected_order_arc_1183
 L  arc_capacity_1184
 G  connected_order_arc_1185
 L  arc_capacity_1186
 G  connected_order_arc_1187
 L  arc_capacity_1188
 G  connected_order_arc_1189
 L  arc_capacity_1190
 G  connected_order_arc_1191
 L  arc_capacity_1192
 G  connected_order_arc_1193
 L  arc_capacity_1194
 G  connected_order_arc_1195
 L  arc_capacity_1196
 G  connected_order_arc_1197
 L  arc_capacity_1198
 G  connected_order_arc_1199
 L  arc_capacity_1200
 G  connected_order_arc_1201
 E  depot_departure_or_bypass_1202
 E  depot_return_or_bypass_1203
 E  out_degree_1204
 E  in_degree_1205
 G  order_active_lb_1206
 L  order_active_ub_1207
 E  segment_load_conservation_1208
 G  segment_prefix_lb_1209
 L  segment_prefix_ub_1210
 E  out_degree_1211
 E  in_degree_1212
 G  order_active_lb_1213
 L  order_active_ub_1214
 E  segment_load_conservation_1215
 G  segment_prefix_lb_1216
 L  segment_prefix_ub_1217
 E  out_degree_1218
 E  in_degree_1219
 G  order_active_lb_1220
 L  order_active_ub_1221
 E  segment_load_conservation_1222
 G  segment_prefix_lb_1223
 L  segment_prefix_ub_1224
 E  out_degree_1225
 E  in_degree_1226
 G  order_active_lb_1227
 L  order_active_ub_1228
 E  segment_load_conservation_1229
 G  segment_prefix_lb_1230
 L  segment_prefix_ub_1231
 E  out_degree_1232
 E  in_degree_1233
 G  order_active_lb_1234
 L  order_active_ub_1235
 E  service_visit_def_1236
 E  free_load_conservation_1237
 E  out_degree_1238
 E  in_degree_1239
 G  order_active_lb_1240
 L  order_active_ub_1241
 E  service_visit_def_1242
 E  free_load_conservation_1243
 E  out_degree_1244
 E  in_degree_1245
 G  order_active_lb_1246
 L  order_active_ub_1247
 E  service_visit_def_1248
 E  free_load_conservation_1249
 E  out_degree_1250
 E  in_degree_1251
 G  order_active_lb_1252
 L  order_active_ub_1253
 E  service_visit_def_1254
 E  free_load_conservation_1255
 E  out_degree_1256
 E  in_degree_1257
 G  order_active_lb_1258
 L  order_active_ub_1259
 E  service_visit_def_1260
 E  free_load_conservation_1261
 E  out_degree_1262
 E  in_degree_1263
 G  order_active_lb_1264
 L  order_active_ub_1265
 E  service_visit_def_1266
 E  free_load_conservation_1267
 E  out_degree_1268
 E  in_degree_1269
 G  order_active_lb_1270
 L  order_active_ub_1271
 E  service_visit_def_1272
 E  free_load_conservation_1273
 E  out_degree_1274
 E  in_degree_1275
 G  order_active_lb_1276
 L  order_active_ub_1277
 E  service_visit_def_1278
 E  free_load_conservation_1279
 G  fixed_segment_relative_order_1280
 G  fixed_segment_relative_order_1281
 G  fixed_segment_relative_order_1282
 L  original_T_including_depot_unload_1283
 L  arc_capacity_1284
 L  arc_capacity_1285
 L  arc_capacity_1286
 L  arc_capacity_1287
 L  arc_capacity_1288
 L  arc_capacity_1289
 L  arc_capacity_1290
 L  arc_capacity_1291
 L  arc_capacity_1292
 L  arc_capacity_1293
 L  arc_capacity_1294
 L  arc_capacity_1295
 L  arc_capacity_1296
 L  arc_capacity_1297
 G  connected_order_arc_1298
 L  arc_capacity_1299
 G  connected_order_arc_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 G  connected_order_arc_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 L  arc_capacity_1395
 G  connected_order_arc_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 G  connected_order_arc_1415
 L  arc_capacity_1416
 G  connected_order_arc_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 L  arc_capacity_1423
 G  connected_order_arc_1424
 L  arc_capacity_1425
 G  connected_order_arc_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 G  connected_order_arc_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 G  connected_order_arc_1436
 L  arc_capacity_1437
 G  connected_order_arc_1438
 L  arc_capacity_1439
 G  connected_order_arc_1440
 L  arc_capacity_1441
 G  connected_order_arc_1442
 L  arc_capacity_1443
 L  arc_capacity_1444
 G  connected_order_arc_1445
 L  arc_capacity_1446
 G  connected_order_arc_1447
 L  arc_capacity_1448
 G  connected_order_arc_1449
 L  arc_capacity_1450
 G  connected_order_arc_1451
 L  arc_capacity_1452
 G  connected_order_arc_1453
 L  arc_capacity_1454
 G  connected_order_arc_1455
 L  arc_capacity_1456
 G  connected_order_arc_1457
 L  arc_capacity_1458
 G  connected_order_arc_1459
 L  arc_capacity_1460
 G  connected_order_arc_1461
 L  arc_capacity_1462
 G  connected_order_arc_1463
 L  arc_capacity_1464
 L  arc_capacity_1465
 G  connected_order_arc_1466
 L  arc_capacity_1467
 G  connected_order_arc_1468
 L  arc_capacity_1469
 G  connected_order_arc_1470
 L  arc_capacity_1471
 G  connected_order_arc_1472
 L  arc_capacity_1473
 G  connected_order_arc_1474
 L  arc_capacity_1475
 G  connected_order_arc_1476
 L  arc_capacity_1477
 G  connected_order_arc_1478
 L  arc_capacity_1479
 G  connected_order_arc_1480
 L  arc_capacity_1481
 G  connected_order_arc_1482
 L  arc_capacity_1483
 G  connected_order_arc_1484
 L  arc_capacity_1485
 L  arc_capacity_1486
 G  connected_order_arc_1487
 L  arc_capacity_1488
 G  connected_order_arc_1489
 L  arc_capacity_1490
 G  connected_order_arc_1491
 L  arc_capacity_1492
 G  connected_order_arc_1493
 L  arc_capacity_1494
 G  connected_order_arc_1495
 L  arc_capacity_1496
 G  connected_order_arc_1497
 L  arc_capacity_1498
 G  connected_order_arc_1499
 L  arc_capacity_1500
 G  connected_order_arc_1501
 L  arc_capacity_1502
 G  connected_order_arc_1503
 L  arc_capacity_1504
 G  connected_order_arc_1505
 L  arc_capacity_1506
 L  arc_capacity_1507
 G  connected_order_arc_1508
 L  arc_capacity_1509
 G  connected_order_arc_1510
 L  arc_capacity_1511
 G  connected_order_arc_1512
 L  arc_capacity_1513
 G  connected_order_arc_1514
 L  arc_capacity_1515
 G  connected_order_arc_1516
 L  arc_capacity_1517
 G  connected_order_arc_1518
 L  arc_capacity_1519
 G  connected_order_arc_1520
 L  arc_capacity_1521
 G  connected_order_arc_1522
 L  arc_capacity_1523
 G  connected_order_arc_1524
 L  arc_capacity_1525
 G  connected_order_arc_1526
 E  depot_departure_or_bypass_1527
 E  depot_return_or_bypass_1528
 E  out_degree_1529
 E  in_degree_1530
 G  order_active_lb_1531
 L  order_active_ub_1532
 E  segment_load_conservation_1533
 G  segment_prefix_lb_1534
 L  segment_prefix_ub_1535
 E  out_degree_1536
 E  in_degree_1537
 G  order_active_lb_1538
 L  order_active_ub_1539
 E  segment_load_conservation_1540
 G  segment_prefix_lb_1541
 L  segment_prefix_ub_1542
 E  out_degree_1543
 E  in_degree_1544
 G  order_active_lb_1545
 L  order_active_ub_1546
 E  segment_load_conservation_1547
 G  segment_prefix_lb_1548
 L  segment_prefix_ub_1549
 E  out_degree_1550
 E  in_degree_1551
 G  order_active_lb_1552
 L  order_active_ub_1553
 E  service_visit_def_1554
 E  free_load_conservation_1555
 E  out_degree_1556
 E  in_degree_1557
 G  order_active_lb_1558
 L  order_active_ub_1559
 E  service_visit_def_1560
 E  free_load_conservation_1561
 E  out_degree_1562
 E  in_degree_1563
 G  order_active_lb_1564
 L  order_active_ub_1565
 E  service_visit_def_1566
 E  free_load_conservation_1567
 E  out_degree_1568
 E  in_degree_1569
 G  order_active_lb_1570
 L  order_active_ub_1571
 E  service_visit_def_1572
 E  free_load_conservation_1573
 E  out_degree_1574
 E  in_degree_1575
 G  order_active_lb_1576
 L  order_active_ub_1577
 E  service_visit_def_1578
 E  free_load_conservation_1579
 E  out_degree_1580
 E  in_degree_1581
 G  order_active_lb_1582
 L  order_active_ub_1583
 E  service_visit_def_1584
 E  free_load_conservation_1585
 E  out_degree_1586
 E  in_degree_1587
 G  order_active_lb_1588
 L  order_active_ub_1589
 E  service_visit_def_1590
 E  free_load_conservation_1591
 E  out_degree_1592
 E  in_degree_1593
 G  order_active_lb_1594
 L  order_active_ub_1595
 E  service_visit_def_1596
 E  free_load_conservation_1597
 G  fixed_segment_relative_order_1598
 G  fixed_segment_relative_order_1599
 L  original_T_including_depot_unload_1600
COLUMNS
    t         normalized_mass_16_27  -1
    t         normalized_mass_11_56  -1
    t         normalized_mass_31_85  -1
    t         normalized_mass_20_114  -1
    t         normalized_mass_32_143  -1
    t         normalized_mass_21_178  -1
    t         normalized_mass_2_213  -1
    t         normalized_mass_7_252  -1
    t         normalization_313  2.3303571428571431e+01
    t         full_original_Gini_314  -9.7807142857142964e+01
    q         OBJ       1
    q         parent_nonstrict_scope_256  1
    q         full_original_Gini_314  35
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       0.027
    x_16_0    product_lb_0  -2.5024577710226110e-02
    x_16_0    product_ub_1  -4.2911877394678936e-02
    x_16_0    onehot_16_26  1
    x_16_0    parent_nonstrict_scope_256  0.054
    x_16_0    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_0  1
    w_16_0    product_ub_1  1
    w_16_0    normalized_mass_16_27  1
    w_16_0    full_original_Gini_314  -2.3303571428571431e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       0.018
    x_16_1    product_lb_2  -2.5024577710226110e-02
    x_16_1    product_ub_3  -4.2911877394678936e-02
    x_16_1    onehot_16_26  1
    x_16_1    stock_lb_254  1
    x_16_1    stock_ub_255  1
    x_16_1    parent_nonstrict_scope_256  0.045
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_2  1
    w_16_1    product_ub_3  1
    w_16_1    normalized_mass_16_27  1
    w_16_1    normalized_ratio_16_28  -1.6666666666666666e-01
    w_16_1    full_original_Gini_314  -1.9136904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       9.0000000000000045e-03
    x_16_2    product_lb_4  -2.5024577710226110e-02
    x_16_2    product_ub_5  -4.2911877394678936e-02
    x_16_2    onehot_16_26  1
    x_16_2    stock_lb_254  2
    x_16_2    stock_ub_255  2
    x_16_2    parent_nonstrict_scope_256  3.6000000000000004e-02
    x_16_2    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_4  1
    w_16_2    product_ub_5  1
    w_16_2    normalized_mass_16_27  1
    w_16_2    normalized_ratio_16_28  -3.3333333333333331e-01
    w_16_2    full_original_Gini_314  -1.5403571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    product_lb_6  -2.5024577710226110e-02
    x_16_3    product_ub_7  -4.2911877394678936e-02
    x_16_3    onehot_16_26  1
    x_16_3    stock_lb_254  3
    x_16_3    stock_ub_255  3
    x_16_3    parent_nonstrict_scope_256  0.027
    x_16_3    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_6  1
    w_16_3    product_ub_7  1
    w_16_3    normalized_mass_16_27  1
    w_16_3    normalized_ratio_16_28  -0.5
    w_16_3    full_original_Gini_314  -1.2103571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    OBJ       -8.9999999999999976e-03
    x_16_4    product_lb_8  -2.5024577710226110e-02
    x_16_4    product_ub_9  -4.2911877394678936e-02
    x_16_4    onehot_16_26  1
    x_16_4    stock_lb_254  4
    x_16_4    stock_ub_255  4
    x_16_4    parent_nonstrict_scope_256  1.8000000000000002e-02
    x_16_4    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_8  1
    w_16_4    product_ub_9  1
    w_16_4    normalized_mass_16_27  1
    w_16_4    normalized_ratio_16_28  -6.6666666666666663e-01
    w_16_4    full_original_Gini_314  -8.9369047619047617e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -1.7999999999999995e-02
    x_16_5    product_lb_10  -2.5024577710226110e-02
    x_16_5    product_ub_11  -4.2911877394678936e-02
    x_16_5    onehot_16_26  1
    x_16_5    stock_lb_254  5
    x_16_5    stock_ub_255  5
    x_16_5    parent_nonstrict_scope_256  9.0000000000000045e-03
    x_16_5    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_10  1
    w_16_5    product_ub_11  1
    w_16_5    normalized_mass_16_27  1
    w_16_5    normalized_ratio_16_28  -8.3333333333333326e-01
    w_16_5    full_original_Gini_314  -6.1750000000000043e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -0.027
    x_16_6    product_lb_12  -2.5024577710226110e-02
    x_16_6    product_ub_13  -4.2911877394678936e-02
    x_16_6    onehot_16_26  1
    x_16_6    stock_lb_254  6
    x_16_6    stock_ub_255  6
    x_16_6    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_12  1
    w_16_6    product_ub_13  1
    w_16_6    normalized_mass_16_27  1
    w_16_6    normalized_ratio_16_28  -1
    w_16_6    full_original_Gini_314  -4.4964285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -1.8000000000000009e-02
    x_16_7    product_lb_14  -2.5024577710226110e-02
    x_16_7    product_ub_15  -4.2911877394678936e-02
    x_16_7    onehot_16_26  1
    x_16_7    stock_lb_254  7
    x_16_7    stock_ub_255  7
    x_16_7    parent_nonstrict_scope_256  8.9999999999999924e-03
    x_16_7    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_14  1
    w_16_7    product_ub_15  1
    w_16_7    normalized_mass_16_27  1
    w_16_7    normalized_ratio_16_28  -1.1666666666666665e+00
    w_16_7    full_original_Gini_314  -8.3297619047618987e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -9.0000000000000045e-03
    x_16_8    product_lb_16  -2.5024577710226110e-02
    x_16_8    product_ub_17  -4.2911877394678936e-02
    x_16_8    onehot_16_26  1
    x_16_8    stock_lb_254  8
    x_16_8    stock_ub_255  8
    x_16_8    parent_nonstrict_scope_256  1.7999999999999995e-02
    x_16_8    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_16  1
    w_16_8    product_ub_17  1
    w_16_8    normalized_mass_16_27  1
    w_16_8    normalized_ratio_16_28  -1.3333333333333333e+00
    w_16_8    full_original_Gini_314  -1.2696428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_9    product_lb_18  -2.5024577710226110e-02
    x_16_9    product_ub_19  -4.2911877394678936e-02
    x_16_9    onehot_16_26  1
    x_16_9    stock_lb_254  9
    x_16_9    stock_ub_255  9
    x_16_9    parent_nonstrict_scope_256  0.027
    x_16_9    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_18  1
    w_16_9    product_ub_19  1
    w_16_9    normalized_mass_16_27  1
    w_16_9    normalized_ratio_16_28  -1.5
    w_16_9    full_original_Gini_314  -1.7196428571428573e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       0.00899999999999999
    x_16_10   product_lb_20  -2.5024577710226110e-02
    x_16_10   product_ub_21  -4.2911877394678936e-02
    x_16_10   onehot_16_26  1
    x_16_10   stock_lb_254  10
    x_16_10   stock_ub_255  10
    x_16_10   parent_nonstrict_scope_256  3.5999999999999990e-02
    x_16_10   unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_20  1
    w_16_10   product_ub_21  1
    w_16_10   normalized_mass_16_27  1
    w_16_10   normalized_ratio_16_28  -1.6666666666666665e+00
    w_16_10   full_original_Gini_314  -2.1696428571428573e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       0.018
    x_16_11   product_lb_22  -2.5024577710226110e-02
    x_16_11   product_ub_23  -4.2911877394678936e-02
    x_16_11   onehot_16_26  1
    x_16_11   stock_lb_254  11
    x_16_11   stock_ub_255  11
    x_16_11   parent_nonstrict_scope_256  0.045
    x_16_11   unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_22  1
    w_16_11   product_ub_23  1
    w_16_11   normalized_mass_16_27  1
    w_16_11   normalized_ratio_16_28  -1.8333333333333333e+00
    w_16_11   full_original_Gini_314  -2.6196428571428566e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   OBJ       0.027
    x_16_12   product_lb_24  -2.5024577710226110e-02
    x_16_12   product_ub_25  -4.2911877394678936e-02
    x_16_12   onehot_16_26  1
    x_16_12   stock_lb_254  12
    x_16_12   stock_ub_255  12
    x_16_12   parent_nonstrict_scope_256  0.054
    x_16_12   unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_24  1
    w_16_12   product_ub_25  1
    w_16_12   normalized_mass_16_27  1
    w_16_12   normalized_ratio_16_28  -2
    w_16_12   full_original_Gini_314  -3.0696428571428569e+01
    rho_16    normalized_ratio_16_28  1
    rho_16    block_pair_pos_271  -1
    rho_16    block_pair_neg_272  1
    rho_16    block_pair_pos_273  -1
    rho_16    block_pair_neg_274  1
    rho_16    block_pair_pos_275  -1
    rho_16    block_pair_neg_276  1
    rho_16    block_pair_pos_277  -1
    rho_16    block_pair_neg_278  1
    rho_16    block_pair_pos_279  -1
    rho_16    block_pair_neg_280  1
    rho_16    block_pair_pos_281  -1
    rho_16    block_pair_neg_282  1
    rho_16    block_pair_pos_283  -1
    rho_16    block_pair_neg_284  1
    rho_16    normalization_313  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       1.1249999999999993e-02
    x_11_0    product_lb_29  -2.5024577710226110e-02
    x_11_0    product_ub_30  -4.2911877394678936e-02
    x_11_0    onehot_11_55  1
    x_11_0    parent_nonstrict_scope_256  0.0375
    x_11_0    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_29  1
    w_11_0    product_ub_30  1
    w_11_0    normalized_mass_11_56  1
    w_11_0    full_original_Gini_314  -2.3303571428571431e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7499999999999929e-03
    x_11_1    product_lb_31  -2.5024577710226110e-02
    x_11_1    product_ub_32  -4.2911877394678936e-02
    x_11_1    onehot_11_55  1
    x_11_1    stock_lb_254  1
    x_11_1    stock_ub_255  1
    x_11_1    parent_nonstrict_scope_256  0.03
    x_11_1    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_31  1
    w_11_1    product_ub_32  1
    w_11_1    normalized_mass_11_56  1
    w_11_1    normalized_ratio_11_57  -0.2
    w_11_1    full_original_Gini_314  -1.8303571428571434e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       -3.7500000000000068e-03
    x_11_2    product_lb_33  -2.5024577710226110e-02
    x_11_2    product_ub_34  -4.2911877394678936e-02
    x_11_2    onehot_11_55  1
    x_11_2    stock_lb_254  2
    x_11_2    stock_ub_255  2
    x_11_2    parent_nonstrict_scope_256  0.0225
    x_11_2    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_33  1
    w_11_2    product_ub_34  1
    w_11_2    normalized_mass_11_56  1
    w_11_2    normalized_ratio_11_57  -0.4
    w_11_2    full_original_Gini_314  -1.4003571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       -1.1250000000000010e-02
    x_11_3    product_lb_35  -2.5024577710226110e-02
    x_11_3    product_ub_36  -4.2911877394678936e-02
    x_11_3    onehot_11_55  1
    x_11_3    stock_lb_254  3
    x_11_3    stock_ub_255  3
    x_11_3    parent_nonstrict_scope_256  1.4999999999999996e-02
    x_11_3    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_35  1
    w_11_3    product_ub_36  1
    w_11_3    normalized_mass_11_56  1
    w_11_3    normalized_ratio_11_57  -6.0000000000000009e-01
    w_11_3    full_original_Gini_314  -1.0203571428571427e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_4    OBJ       -1.8750000000000010e-02
    x_11_4    product_lb_37  -2.5024577710226110e-02
    x_11_4    product_ub_38  -4.2911877394678936e-02
    x_11_4    onehot_11_55  1
    x_11_4    stock_lb_254  4
    x_11_4    stock_ub_255  4
    x_11_4    parent_nonstrict_scope_256  7.4999999999999980e-03
    x_11_4    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_37  1
    w_11_4    product_ub_38  1
    w_11_4    normalized_mass_11_56  1
    w_11_4    normalized_ratio_11_57  -0.8
    w_11_4    full_original_Gini_314  -6.6750000000000025e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -2.6250000000000006e-02
    x_11_5    product_lb_39  -2.5024577710226110e-02
    x_11_5    product_ub_40  -4.2911877394678936e-02
    x_11_5    onehot_11_55  1
    x_11_5    stock_lb_254  5
    x_11_5    stock_ub_255  5
    x_11_5    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_39  1
    w_11_5    product_ub_40  1
    w_11_5    normalized_mass_11_56  1
    w_11_5    normalized_ratio_11_57  -1
    w_11_5    full_original_Gini_314  -4.4964285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -0.01875
    x_11_6    product_lb_41  -2.5024577710226110e-02
    x_11_6    product_ub_42  -4.2911877394678936e-02
    x_11_6    onehot_11_55  1
    x_11_6    stock_lb_254  6
    x_11_6    stock_ub_255  6
    x_11_6    parent_nonstrict_scope_256  7.5000000000000067e-03
    x_11_6    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_41  1
    w_11_6    product_ub_42  1
    w_11_6    normalized_mass_11_56  1
    w_11_6    normalized_ratio_11_57  -1.2000000000000002e+00
    w_11_6    full_original_Gini_314  -9.0964285714285751e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -1.1250000000000001e-02
    x_11_7    product_lb_43  -2.5024577710226110e-02
    x_11_7    product_ub_44  -4.2911877394678936e-02
    x_11_7    onehot_11_55  1
    x_11_7    stock_lb_254  7
    x_11_7    stock_ub_255  7
    x_11_7    parent_nonstrict_scope_256  1.5000000000000005e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_43  1
    w_11_7    product_ub_44  1
    w_11_7    normalized_mass_11_56  1
    w_11_7    normalized_ratio_11_57  -1.4000000000000001e+00
    w_11_7    full_original_Gini_314  -1.4496428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -3.7500000000000033e-03
    x_11_8    product_lb_45  -2.5024577710226110e-02
    x_11_8    product_ub_46  -4.2911877394678936e-02
    x_11_8    onehot_11_55  1
    x_11_8    stock_lb_254  8
    x_11_8    stock_ub_255  8
    x_11_8    parent_nonstrict_scope_256  2.2500000000000003e-02
    x_11_8    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_45  1
    w_11_8    product_ub_46  1
    w_11_8    normalized_mass_11_56  1
    w_11_8    normalized_ratio_11_57  -1.6
    w_11_8    full_original_Gini_314  -1.9896428571428576e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       3.7499999999999929e-03
    x_11_9    product_lb_47  -2.5024577710226110e-02
    x_11_9    product_ub_48  -4.2911877394678936e-02
    x_11_9    onehot_11_55  1
    x_11_9    stock_lb_254  9
    x_11_9    stock_ub_255  9
    x_11_9    parent_nonstrict_scope_256  0.03
    x_11_9    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_47  1
    w_11_9    product_ub_48  1
    w_11_9    normalized_mass_11_56  1
    w_11_9    normalized_ratio_11_57  -1.8
    w_11_9    full_original_Gini_314  -2.5296428571428578e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       1.1249999999999993e-02
    x_11_10   product_lb_49  -2.5024577710226110e-02
    x_11_10   product_ub_50  -4.2911877394678936e-02
    x_11_10   onehot_11_55  1
    x_11_10   stock_lb_254  10
    x_11_10   stock_ub_255  10
    x_11_10   parent_nonstrict_scope_256  0.0375
    x_11_10   unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_49  1
    w_11_10   product_ub_50  1
    w_11_10   normalized_mass_11_56  1
    w_11_10   normalized_ratio_11_57  -2
    w_11_10   full_original_Gini_314  -3.0696428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       0.01875
    x_11_11   product_lb_51  -2.5024577710226110e-02
    x_11_11   product_ub_52  -4.2911877394678936e-02
    x_11_11   onehot_11_55  1
    x_11_11   stock_lb_254  11
    x_11_11   stock_ub_255  11
    x_11_11   parent_nonstrict_scope_256  4.5000000000000005e-02
    x_11_11   unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_51  1
    w_11_11   product_ub_52  1
    w_11_11   normalized_mass_11_56  1
    w_11_11   normalized_ratio_11_57  -2.2
    w_11_11   full_original_Gini_314  -3.6096428571428568e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_12   OBJ       2.6250000000000006e-02
    x_11_12   product_lb_53  -2.5024577710226110e-02
    x_11_12   product_ub_54  -4.2911877394678936e-02
    x_11_12   onehot_11_55  1
    x_11_12   stock_lb_254  12
    x_11_12   stock_ub_255  12
    x_11_12   parent_nonstrict_scope_256  5.2500000000000012e-02
    x_11_12   unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_53  1
    w_11_12   product_ub_54  1
    w_11_12   normalized_mass_11_56  1
    w_11_12   normalized_ratio_11_57  -2.4000000000000004e+00
    w_11_12   full_original_Gini_314  -4.1496428571428567e+01
    rho_11    normalized_ratio_11_57  1
    rho_11    block_pair_pos_259  -1
    rho_11    block_pair_neg_260  1
    rho_11    block_pair_pos_261  -1
    rho_11    block_pair_neg_262  1
    rho_11    block_pair_pos_263  -1
    rho_11    block_pair_neg_264  1
    rho_11    block_pair_pos_265  -1
    rho_11    block_pair_neg_266  1
    rho_11    block_pair_pos_267  -1
    rho_11    block_pair_neg_268  1
    rho_11    block_pair_pos_269  -1
    rho_11    block_pair_neg_270  1
    rho_11    block_pair_pos_275  1
    rho_11    block_pair_neg_276  -1
    rho_11    normalization_313  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_58  -2.5024577710226110e-02
    x_31_0    product_ub_59  -4.2911877394678936e-02
    x_31_0    onehot_31_84  1
    x_31_0    parent_nonstrict_scope_256  0.0735
    x_31_0    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_58  1
    w_31_0    product_ub_59  1
    w_31_0    normalized_mass_31_85  1
    w_31_0    full_original_Gini_314  -2.3303571428571431e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_60  -2.5024577710226110e-02
    x_31_1    product_ub_61  -4.2911877394678936e-02
    x_31_1    onehot_31_84  1
    x_31_1    stock_lb_254  1
    x_31_1    stock_ub_255  1
    x_31_1    parent_nonstrict_scope_256  0.063
    x_31_1    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_60  1
    w_31_1    product_ub_61  1
    w_31_1    normalized_mass_31_85  1
    w_31_1    normalized_ratio_31_86  -1.4285714285714285e-01
    w_31_1    full_original_Gini_314  -1.9732142857142861e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_62  -2.5024577710226110e-02
    x_31_2    product_ub_63  -4.2911877394678936e-02
    x_31_2    onehot_31_84  1
    x_31_2    stock_lb_254  2
    x_31_2    stock_ub_255  2
    x_31_2    parent_nonstrict_scope_256  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_62  1
    w_31_2    product_ub_63  1
    w_31_2    normalized_mass_31_85  1
    w_31_2    normalized_ratio_31_86  -2.8571428571428570e-01
    w_31_2    full_original_Gini_314  -1.6403571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_64  -2.5024577710226110e-02
    x_31_3    product_ub_65  -4.2911877394678936e-02
    x_31_3    onehot_31_84  1
    x_31_3    stock_lb_254  3
    x_31_3    stock_ub_255  3
    x_31_3    parent_nonstrict_scope_256  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_64  1
    w_31_3    product_ub_65  1
    w_31_3    normalized_mass_31_85  1
    w_31_3    normalized_ratio_31_86  -4.2857142857142855e-01
    w_31_3    full_original_Gini_314  -1.3460714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_66  -2.5024577710226110e-02
    x_31_4    product_ub_67  -4.2911877394678936e-02
    x_31_4    onehot_31_84  1
    x_31_4    stock_lb_254  4
    x_31_4    stock_ub_255  4
    x_31_4    parent_nonstrict_scope_256  0.0315
    x_31_4    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_66  1
    w_31_4    product_ub_67  1
    w_31_4    normalized_mass_31_85  1
    w_31_4    normalized_ratio_31_86  -5.7142857142857140e-01
    w_31_4    full_original_Gini_314  -1.0746428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_68  -2.5024577710226110e-02
    x_31_5    product_ub_69  -4.2911877394678936e-02
    x_31_5    onehot_31_84  1
    x_31_5    stock_lb_254  5
    x_31_5    stock_ub_255  5
    x_31_5    parent_nonstrict_scope_256  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_68  1
    w_31_5    product_ub_69  1
    w_31_5    normalized_mass_31_85  1
    w_31_5    normalized_ratio_31_86  -7.1428571428571419e-01
    w_31_5    full_original_Gini_314  -8.0321428571428584e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_70  -2.5024577710226110e-02
    x_31_6    product_ub_71  -4.2911877394678936e-02
    x_31_6    onehot_31_84  1
    x_31_6    stock_lb_254  6
    x_31_6    stock_ub_255  6
    x_31_6    parent_nonstrict_scope_256  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_70  1
    w_31_6    product_ub_71  1
    w_31_6    normalized_mass_31_85  1
    w_31_6    normalized_ratio_31_86  -8.5714285714285710e-01
    w_31_6    full_original_Gini_314  -5.8178571428571448e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_72  -2.5024577710226110e-02
    x_31_7    product_ub_73  -4.2911877394678936e-02
    x_31_7    onehot_31_84  1
    x_31_7    stock_lb_254  7
    x_31_7    stock_ub_255  7
    x_31_7    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_72  1
    w_31_7    product_ub_73  1
    w_31_7    normalized_mass_31_85  1
    w_31_7    normalized_ratio_31_86  -1
    w_31_7    full_original_Gini_314  -4.4964285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_74  -2.5024577710226110e-02
    x_31_8    product_ub_75  -4.2911877394678936e-02
    x_31_8    onehot_31_84  1
    x_31_8    stock_lb_254  8
    x_31_8    stock_ub_255  8
    x_31_8    parent_nonstrict_scope_256  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_74  1
    w_31_8    product_ub_75  1
    w_31_8    normalized_mass_31_85  1
    w_31_8    normalized_ratio_31_86  -1.1428571428571428e+00
    w_31_8    full_original_Gini_314  -7.7821428571428530e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_76  -2.5024577710226110e-02
    x_31_9    product_ub_77  -4.2911877394678936e-02
    x_31_9    onehot_31_84  1
    x_31_9    stock_lb_254  9
    x_31_9    stock_ub_255  9
    x_31_9    parent_nonstrict_scope_256  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_76  1
    w_31_9    product_ub_77  1
    w_31_9    normalized_mass_31_85  1
    w_31_9    normalized_ratio_31_86  -1.2857142857142856e+00
    w_31_9    full_original_Gini_314  -1.1410714285714281e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_78  -2.5024577710226110e-02
    x_31_10   product_ub_79  -4.2911877394678936e-02
    x_31_10   onehot_31_84  1
    x_31_10   stock_lb_254  10
    x_31_10   stock_ub_255  10
    x_31_10   parent_nonstrict_scope_256  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_78  1
    w_31_10   product_ub_79  1
    w_31_10   normalized_mass_31_85  1
    w_31_10   normalized_ratio_31_86  -1.4285714285714284e+00
    w_31_10   full_original_Gini_314  -1.5267857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_80  -2.5024577710226110e-02
    x_31_11   product_ub_81  -4.2911877394678936e-02
    x_31_11   onehot_31_84  1
    x_31_11   stock_lb_254  11
    x_31_11   stock_ub_255  11
    x_31_11   parent_nonstrict_scope_256  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_80  1
    w_31_11   product_ub_81  1
    w_31_11   normalized_mass_31_85  1
    w_31_11   normalized_ratio_31_86  -1.5714285714285714e+00
    w_31_11   full_original_Gini_314  -1.9125000000000004e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_82  -2.5024577710226110e-02
    x_31_12   product_ub_83  -4.2911877394678936e-02
    x_31_12   onehot_31_84  1
    x_31_12   stock_lb_254  12
    x_31_12   stock_ub_255  12
    x_31_12   parent_nonstrict_scope_256  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_82  1
    w_31_12   product_ub_83  1
    w_31_12   normalized_mass_31_85  1
    w_31_12   normalized_ratio_31_86  -1.7142857142857142e+00
    w_31_12   full_original_Gini_314  -2.2982142857142854e+01
    rho_31    normalized_ratio_31_86  1
    rho_31    block_pair_pos_267  1
    rho_31    block_pair_neg_268  -1
    rho_31    block_pair_pos_281  1
    rho_31    block_pair_neg_282  -1
    rho_31    block_pair_pos_297  -1
    rho_31    block_pair_neg_298  1
    rho_31    block_pair_pos_299  -1
    rho_31    block_pair_neg_300  1
    rho_31    block_pair_pos_301  -1
    rho_31    block_pair_neg_302  1
    rho_31    block_pair_pos_303  -1
    rho_31    block_pair_neg_304  1
    rho_31    block_pair_pos_305  -1
    rho_31    block_pair_neg_306  1
    rho_31    normalization_313  1
    MARKER    'MARKER'                 'INTORG'
    x_20_0    OBJ       0.027
    x_20_0    product_lb_87  -2.5024577710226110e-02
    x_20_0    product_ub_88  -4.2911877394678936e-02
    x_20_0    onehot_20_113  1
    x_20_0    parent_nonstrict_scope_256  0.054
    x_20_0    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_0    product_lb_87  1
    w_20_0    product_ub_88  1
    w_20_0    normalized_mass_20_114  1
    w_20_0    full_original_Gini_314  -2.3303571428571431e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_1    OBJ       0.018
    x_20_1    product_lb_89  -2.5024577710226110e-02
    x_20_1    product_ub_90  -4.2911877394678936e-02
    x_20_1    onehot_20_113  1
    x_20_1    stock_lb_254  1
    x_20_1    stock_ub_255  1
    x_20_1    parent_nonstrict_scope_256  0.045
    x_20_1    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_1    product_lb_89  1
    w_20_1    product_ub_90  1
    w_20_1    normalized_mass_20_114  1
    w_20_1    normalized_ratio_20_115  -1.6666666666666666e-01
    w_20_1    full_original_Gini_314  -1.9136904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_2    OBJ       9.0000000000000045e-03
    x_20_2    product_lb_91  -2.5024577710226110e-02
    x_20_2    product_ub_92  -4.2911877394678936e-02
    x_20_2    onehot_20_113  1
    x_20_2    stock_lb_254  2
    x_20_2    stock_ub_255  2
    x_20_2    parent_nonstrict_scope_256  3.6000000000000004e-02
    x_20_2    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_2    product_lb_91  1
    w_20_2    product_ub_92  1
    w_20_2    normalized_mass_20_114  1
    w_20_2    normalized_ratio_20_115  -3.3333333333333331e-01
    w_20_2    full_original_Gini_314  -1.5403571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_3    product_lb_93  -2.5024577710226110e-02
    x_20_3    product_ub_94  -4.2911877394678936e-02
    x_20_3    onehot_20_113  1
    x_20_3    stock_lb_254  3
    x_20_3    stock_ub_255  3
    x_20_3    parent_nonstrict_scope_256  0.027
    x_20_3    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_3    product_lb_93  1
    w_20_3    product_ub_94  1
    w_20_3    normalized_mass_20_114  1
    w_20_3    normalized_ratio_20_115  -0.5
    w_20_3    full_original_Gini_314  -1.2103571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_4    OBJ       -8.9999999999999976e-03
    x_20_4    product_lb_95  -2.5024577710226110e-02
    x_20_4    product_ub_96  -4.2911877394678936e-02
    x_20_4    onehot_20_113  1
    x_20_4    stock_lb_254  4
    x_20_4    stock_ub_255  4
    x_20_4    parent_nonstrict_scope_256  1.8000000000000002e-02
    x_20_4    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_4    product_lb_95  1
    w_20_4    product_ub_96  1
    w_20_4    normalized_mass_20_114  1
    w_20_4    normalized_ratio_20_115  -6.6666666666666663e-01
    w_20_4    full_original_Gini_314  -8.9369047619047617e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_5    OBJ       -1.7999999999999995e-02
    x_20_5    product_lb_97  -2.5024577710226110e-02
    x_20_5    product_ub_98  -4.2911877394678936e-02
    x_20_5    onehot_20_113  1
    x_20_5    stock_lb_254  5
    x_20_5    stock_ub_255  5
    x_20_5    parent_nonstrict_scope_256  9.0000000000000045e-03
    x_20_5    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_5    product_lb_97  1
    w_20_5    product_ub_98  1
    w_20_5    normalized_mass_20_114  1
    w_20_5    normalized_ratio_20_115  -8.3333333333333326e-01
    w_20_5    full_original_Gini_314  -6.1750000000000043e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_6    OBJ       -0.027
    x_20_6    product_lb_99  -2.5024577710226110e-02
    x_20_6    product_ub_100  -4.2911877394678936e-02
    x_20_6    onehot_20_113  1
    x_20_6    stock_lb_254  6
    x_20_6    stock_ub_255  6
    x_20_6    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_6    product_lb_99  1
    w_20_6    product_ub_100  1
    w_20_6    normalized_mass_20_114  1
    w_20_6    normalized_ratio_20_115  -1
    w_20_6    full_original_Gini_314  -4.4964285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_7    OBJ       -1.8000000000000009e-02
    x_20_7    product_lb_101  -2.5024577710226110e-02
    x_20_7    product_ub_102  -4.2911877394678936e-02
    x_20_7    onehot_20_113  1
    x_20_7    stock_lb_254  7
    x_20_7    stock_ub_255  7
    x_20_7    parent_nonstrict_scope_256  8.9999999999999924e-03
    x_20_7    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_7    product_lb_101  1
    w_20_7    product_ub_102  1
    w_20_7    normalized_mass_20_114  1
    w_20_7    normalized_ratio_20_115  -1.1666666666666665e+00
    w_20_7    full_original_Gini_314  -8.3297619047618987e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_8    OBJ       -9.0000000000000045e-03
    x_20_8    product_lb_103  -2.5024577710226110e-02
    x_20_8    product_ub_104  -4.2911877394678936e-02
    x_20_8    onehot_20_113  1
    x_20_8    stock_lb_254  8
    x_20_8    stock_ub_255  8
    x_20_8    parent_nonstrict_scope_256  1.7999999999999995e-02
    x_20_8    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_8    product_lb_103  1
    w_20_8    product_ub_104  1
    w_20_8    normalized_mass_20_114  1
    w_20_8    normalized_ratio_20_115  -1.3333333333333333e+00
    w_20_8    full_original_Gini_314  -1.2696428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_9    product_lb_105  -2.5024577710226110e-02
    x_20_9    product_ub_106  -4.2911877394678936e-02
    x_20_9    onehot_20_113  1
    x_20_9    stock_lb_254  9
    x_20_9    stock_ub_255  9
    x_20_9    parent_nonstrict_scope_256  0.027
    MARKER    'MARKER'                 'INTEND'
    w_20_9    product_lb_105  1
    w_20_9    product_ub_106  1
    w_20_9    normalized_mass_20_114  1
    w_20_9    normalized_ratio_20_115  -1.5
    w_20_9    full_original_Gini_314  -1.7196428571428573e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_10   OBJ       0.00899999999999999
    x_20_10   product_lb_107  -2.5024577710226110e-02
    x_20_10   product_ub_108  -4.2911877394678936e-02
    x_20_10   onehot_20_113  1
    x_20_10   stock_lb_254  10
    x_20_10   stock_ub_255  10
    x_20_10   parent_nonstrict_scope_256  3.5999999999999990e-02
    x_20_10   unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_10   product_lb_107  1
    w_20_10   product_ub_108  1
    w_20_10   normalized_mass_20_114  1
    w_20_10   normalized_ratio_20_115  -1.6666666666666665e+00
    w_20_10   full_original_Gini_314  -2.1696428571428573e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_11   OBJ       0.018
    x_20_11   product_lb_109  -2.5024577710226110e-02
    x_20_11   product_ub_110  -4.2911877394678936e-02
    x_20_11   onehot_20_113  1
    x_20_11   stock_lb_254  11
    x_20_11   stock_ub_255  11
    x_20_11   parent_nonstrict_scope_256  0.045
    x_20_11   unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_11   product_lb_109  1
    w_20_11   product_ub_110  1
    w_20_11   normalized_mass_20_114  1
    w_20_11   normalized_ratio_20_115  -1.8333333333333333e+00
    w_20_11   full_original_Gini_314  -2.6196428571428566e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_12   OBJ       0.027
    x_20_12   product_lb_111  -2.5024577710226110e-02
    x_20_12   product_ub_112  -4.2911877394678936e-02
    x_20_12   onehot_20_113  1
    x_20_12   stock_lb_254  12
    x_20_12   stock_ub_255  12
    x_20_12   parent_nonstrict_scope_256  0.054
    x_20_12   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_12   product_lb_111  1
    w_20_12   product_ub_112  1
    w_20_12   normalized_mass_20_114  1
    w_20_12   normalized_ratio_20_115  -2
    w_20_12   full_original_Gini_314  -3.0696428571428569e+01
    rho_20    normalized_ratio_20_115  1
    rho_20    block_pair_pos_263  1
    rho_20    block_pair_neg_264  -1
    rho_20    block_pair_pos_277  1
    rho_20    block_pair_neg_278  -1
    rho_20    block_pair_pos_285  -1
    rho_20    block_pair_neg_286  1
    rho_20    block_pair_pos_287  -1
    rho_20    block_pair_neg_288  1
    rho_20    block_pair_pos_289  -1
    rho_20    block_pair_neg_290  1
    rho_20    block_pair_pos_291  -1
    rho_20    block_pair_neg_292  1
    rho_20    block_pair_pos_301  1
    rho_20    block_pair_neg_302  -1
    rho_20    normalization_313  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_116  -2.5024577710226110e-02
    x_32_0    product_ub_117  -4.2911877394678936e-02
    x_32_0    onehot_32_142  1
    x_32_0    parent_nonstrict_scope_256  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_116  1
    w_32_0    product_ub_117  1
    w_32_0    normalized_mass_32_143  1
    w_32_0    full_original_Gini_314  -2.3303571428571431e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_118  -2.5024577710226110e-02
    x_32_1    product_ub_119  -4.2911877394678936e-02
    x_32_1    onehot_32_142  1
    x_32_1    stock_lb_254  1
    x_32_1    stock_ub_255  1
    x_32_1    parent_nonstrict_scope_256  0.03
    x_32_1    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_118  1
    w_32_1    product_ub_119  1
    w_32_1    normalized_mass_32_143  1
    w_32_1    normalized_ratio_32_144  -0.2
    w_32_1    full_original_Gini_314  -1.8303571428571434e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_120  -2.5024577710226110e-02
    x_32_2    product_ub_121  -4.2911877394678936e-02
    x_32_2    onehot_32_142  1
    x_32_2    stock_lb_254  2
    x_32_2    stock_ub_255  2
    x_32_2    parent_nonstrict_scope_256  0.0225
    x_32_2    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_120  1
    w_32_2    product_ub_121  1
    w_32_2    normalized_mass_32_143  1
    w_32_2    normalized_ratio_32_144  -0.4
    w_32_2    full_original_Gini_314  -1.4003571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_122  -2.5024577710226110e-02
    x_32_3    product_ub_123  -4.2911877394678936e-02
    x_32_3    onehot_32_142  1
    x_32_3    stock_lb_254  3
    x_32_3    stock_ub_255  3
    x_32_3    parent_nonstrict_scope_256  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_122  1
    w_32_3    product_ub_123  1
    w_32_3    normalized_mass_32_143  1
    w_32_3    normalized_ratio_32_144  -6.0000000000000009e-01
    w_32_3    full_original_Gini_314  -1.0203571428571427e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_124  -2.5024577710226110e-02
    x_32_4    product_ub_125  -4.2911877394678936e-02
    x_32_4    onehot_32_142  1
    x_32_4    stock_lb_254  4
    x_32_4    stock_ub_255  4
    x_32_4    parent_nonstrict_scope_256  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_124  1
    w_32_4    product_ub_125  1
    w_32_4    normalized_mass_32_143  1
    w_32_4    normalized_ratio_32_144  -0.8
    w_32_4    full_original_Gini_314  -6.6750000000000025e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_126  -2.5024577710226110e-02
    x_32_5    product_ub_127  -4.2911877394678936e-02
    x_32_5    onehot_32_142  1
    x_32_5    stock_lb_254  5
    x_32_5    stock_ub_255  5
    x_32_5    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_126  1
    w_32_5    product_ub_127  1
    w_32_5    normalized_mass_32_143  1
    w_32_5    normalized_ratio_32_144  -1
    w_32_5    full_original_Gini_314  -4.4964285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_128  -2.5024577710226110e-02
    x_32_6    product_ub_129  -4.2911877394678936e-02
    x_32_6    onehot_32_142  1
    x_32_6    stock_lb_254  6
    x_32_6    stock_ub_255  6
    x_32_6    parent_nonstrict_scope_256  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_128  1
    w_32_6    product_ub_129  1
    w_32_6    normalized_mass_32_143  1
    w_32_6    normalized_ratio_32_144  -1.2000000000000002e+00
    w_32_6    full_original_Gini_314  -9.0964285714285751e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_130  -2.5024577710226110e-02
    x_32_7    product_ub_131  -4.2911877394678936e-02
    x_32_7    onehot_32_142  1
    x_32_7    stock_lb_254  7
    x_32_7    stock_ub_255  7
    x_32_7    parent_nonstrict_scope_256  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_130  1
    w_32_7    product_ub_131  1
    w_32_7    normalized_mass_32_143  1
    w_32_7    normalized_ratio_32_144  -1.4000000000000001e+00
    w_32_7    full_original_Gini_314  -1.4496428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_132  -2.5024577710226110e-02
    x_32_8    product_ub_133  -4.2911877394678936e-02
    x_32_8    onehot_32_142  1
    x_32_8    stock_lb_254  8
    x_32_8    stock_ub_255  8
    x_32_8    parent_nonstrict_scope_256  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_132  1
    w_32_8    product_ub_133  1
    w_32_8    normalized_mass_32_143  1
    w_32_8    normalized_ratio_32_144  -1.6
    w_32_8    full_original_Gini_314  -1.9896428571428576e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_134  -2.5024577710226110e-02
    x_32_9    product_ub_135  -4.2911877394678936e-02
    x_32_9    onehot_32_142  1
    x_32_9    stock_lb_254  9
    x_32_9    stock_ub_255  9
    x_32_9    parent_nonstrict_scope_256  0.03
    x_32_9    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_134  1
    w_32_9    product_ub_135  1
    w_32_9    normalized_mass_32_143  1
    w_32_9    normalized_ratio_32_144  -1.8
    w_32_9    full_original_Gini_314  -2.5296428571428578e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_136  -2.5024577710226110e-02
    x_32_10   product_ub_137  -4.2911877394678936e-02
    x_32_10   onehot_32_142  1
    x_32_10   stock_lb_254  10
    x_32_10   stock_ub_255  10
    x_32_10   parent_nonstrict_scope_256  0.0375
    x_32_10   unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_136  1
    w_32_10   product_ub_137  1
    w_32_10   normalized_mass_32_143  1
    w_32_10   normalized_ratio_32_144  -2
    w_32_10   full_original_Gini_314  -3.0696428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_138  -2.5024577710226110e-02
    x_32_11   product_ub_139  -4.2911877394678936e-02
    x_32_11   onehot_32_142  1
    x_32_11   stock_lb_254  11
    x_32_11   stock_ub_255  11
    x_32_11   parent_nonstrict_scope_256  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_138  1
    w_32_11   product_ub_139  1
    w_32_11   normalized_mass_32_143  1
    w_32_11   normalized_ratio_32_144  -2.2
    w_32_11   full_original_Gini_314  -3.6096428571428568e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_140  -2.5024577710226110e-02
    x_32_12   product_ub_141  -4.2911877394678936e-02
    x_32_12   onehot_32_142  1
    x_32_12   stock_lb_254  12
    x_32_12   stock_ub_255  12
    x_32_12   parent_nonstrict_scope_256  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_140  1
    w_32_12   product_ub_141  1
    w_32_12   normalized_mass_32_143  1
    w_32_12   normalized_ratio_32_144  -2.4000000000000004e+00
    w_32_12   full_original_Gini_314  -4.1496428571428567e+01
    rho_32    normalized_ratio_32_144  1
    rho_32    block_pair_pos_269  1
    rho_32    block_pair_neg_270  -1
    rho_32    block_pair_pos_283  1
    rho_32    block_pair_neg_284  -1
    rho_32    block_pair_pos_291  1
    rho_32    block_pair_neg_292  -1
    rho_32    block_pair_pos_305  1
    rho_32    block_pair_neg_306  -1
    rho_32    block_pair_pos_307  -1
    rho_32    block_pair_neg_308  1
    rho_32    block_pair_pos_309  -1
    rho_32    block_pair_neg_310  1
    rho_32    block_pair_pos_311  -1
    rho_32    block_pair_neg_312  1
    rho_32    normalization_313  1
    MARKER    'MARKER'                 'INTORG'
    x_21_0    OBJ       0.048
    x_21_0    product_lb_145  -2.5024577710226110e-02
    x_21_0    product_ub_146  -4.2911877394678936e-02
    x_21_0    onehot_21_177  1
    x_21_0    parent_nonstrict_scope_256  0.096
    x_21_0    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_0    product_lb_145  1
    w_21_0    product_ub_146  1
    w_21_0    normalized_mass_21_178  1
    w_21_0    full_original_Gini_314  -2.3303571428571431e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_1    OBJ       3.6000000000000004e-02
    x_21_1    product_lb_147  -2.5024577710226110e-02
    x_21_1    product_ub_148  -4.2911877394678936e-02
    x_21_1    onehot_21_177  1
    x_21_1    stock_lb_254  1
    x_21_1    stock_ub_255  1
    x_21_1    parent_nonstrict_scope_256  0.084
    MARKER    'MARKER'                 'INTEND'
    w_21_1    product_lb_147  1
    w_21_1    product_ub_148  1
    w_21_1    normalized_mass_21_178  1
    w_21_1    normalized_ratio_21_179  -0.125
    w_21_1    full_original_Gini_314  -2.0178571428571427e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_2    OBJ       2.4000000000000007e-02
    x_21_2    product_lb_149  -2.5024577710226110e-02
    x_21_2    product_ub_150  -4.2911877394678936e-02
    x_21_2    onehot_21_177  1
    x_21_2    stock_lb_254  2
    x_21_2    stock_ub_255  2
    x_21_2    parent_nonstrict_scope_256  7.2000000000000008e-02
    x_21_2    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_2    product_lb_149  1
    w_21_2    product_ub_150  1
    w_21_2    normalized_mass_21_178  1
    w_21_2    normalized_ratio_21_179  -0.25
    w_21_2    full_original_Gini_314  -1.7153571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_3    OBJ       1.1999999999999997e-02
    x_21_3    product_lb_151  -2.5024577710226110e-02
    x_21_3    product_ub_152  -4.2911877394678936e-02
    x_21_3    onehot_21_177  1
    x_21_3    stock_lb_254  3
    x_21_3    stock_ub_255  3
    x_21_3    parent_nonstrict_scope_256  0.06
    x_21_3    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_3    product_lb_151  1
    w_21_3    product_ub_152  1
    w_21_3    normalized_mass_21_178  1
    w_21_3    normalized_ratio_21_179  -0.375
    w_21_3    full_original_Gini_314  -1.4528571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_4    product_lb_153  -2.5024577710226110e-02
    x_21_4    product_ub_154  -4.2911877394678936e-02
    x_21_4    onehot_21_177  1
    x_21_4    stock_lb_254  4
    x_21_4    stock_ub_255  4
    x_21_4    parent_nonstrict_scope_256  0.048
    x_21_4    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_4    product_lb_153  1
    w_21_4    product_ub_154  1
    w_21_4    normalized_mass_21_178  1
    w_21_4    normalized_ratio_21_179  -0.5
    w_21_4    full_original_Gini_314  -1.2103571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_5    OBJ       -1.1999999999999997e-02
    x_21_5    product_lb_155  -2.5024577710226110e-02
    x_21_5    product_ub_156  -4.2911877394678936e-02
    x_21_5    onehot_21_177  1
    x_21_5    stock_lb_254  5
    x_21_5    stock_ub_255  5
    x_21_5    parent_nonstrict_scope_256  3.6000000000000004e-02
    x_21_5    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_5    product_lb_155  1
    w_21_5    product_ub_156  1
    w_21_5    normalized_mass_21_178  1
    w_21_5    normalized_ratio_21_179  -0.625
    w_21_5    full_original_Gini_314  -9.72857142857143
    MARKER    'MARKER'                 'INTORG'
    x_21_6    OBJ       -0.024
    x_21_6    product_lb_157  -2.5024577710226110e-02
    x_21_6    product_ub_158  -4.2911877394678936e-02
    x_21_6    onehot_21_177  1
    x_21_6    stock_lb_254  6
    x_21_6    stock_ub_255  6
    x_21_6    parent_nonstrict_scope_256  0.024
    x_21_6    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_6    product_lb_157  1
    w_21_6    product_ub_158  1
    w_21_6    normalized_mass_21_178  1
    w_21_6    normalized_ratio_21_179  -0.75
    w_21_6    full_original_Gini_314  -7.425
    MARKER    'MARKER'                 'INTORG'
    x_21_7    OBJ       -3.6000000000000004e-02
    x_21_7    product_lb_159  -2.5024577710226110e-02
    x_21_7    product_ub_160  -4.2911877394678936e-02
    x_21_7    onehot_21_177  1
    x_21_7    stock_lb_254  7
    x_21_7    stock_ub_255  7
    x_21_7    parent_nonstrict_scope_256  0.012
    x_21_7    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_7    product_lb_159  1
    w_21_7    product_ub_160  1
    w_21_7    normalized_mass_21_178  1
    w_21_7    normalized_ratio_21_179  -0.875
    w_21_7    full_original_Gini_314  -5.6214285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_8    OBJ       -0.048
    x_21_8    product_lb_161  -2.5024577710226110e-02
    x_21_8    product_ub_162  -4.2911877394678936e-02
    x_21_8    onehot_21_177  1
    x_21_8    stock_lb_254  8
    x_21_8    stock_ub_255  8
    x_21_8    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_8    product_lb_161  1
    w_21_8    product_ub_162  1
    w_21_8    normalized_mass_21_178  1
    w_21_8    normalized_ratio_21_179  -1
    w_21_8    full_original_Gini_314  -4.4964285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_9    OBJ       -3.6000000000000004e-02
    x_21_9    product_lb_163  -2.5024577710226110e-02
    x_21_9    product_ub_164  -4.2911877394678936e-02
    x_21_9    onehot_21_177  1
    x_21_9    stock_lb_254  9
    x_21_9    stock_ub_255  9
    x_21_9    parent_nonstrict_scope_256  0.012
    x_21_9    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_9    product_lb_163  1
    w_21_9    product_ub_164  1
    w_21_9    normalized_mass_21_178  1
    w_21_9    normalized_ratio_21_179  -1.125
    w_21_9    full_original_Gini_314  -7.3714285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_10   OBJ       -0.024
    x_21_10   product_lb_165  -2.5024577710226110e-02
    x_21_10   product_ub_166  -4.2911877394678936e-02
    x_21_10   onehot_21_177  1
    x_21_10   stock_lb_254  10
    x_21_10   stock_ub_255  10
    x_21_10   parent_nonstrict_scope_256  0.024
    x_21_10   unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_10   product_lb_165  1
    w_21_10   product_ub_166  1
    w_21_10   normalized_mass_21_178  1
    w_21_10   normalized_ratio_21_179  -1.25
    w_21_10   full_original_Gini_314  -1.0446428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_11   OBJ       -1.1999999999999997e-02
    x_21_11   product_lb_167  -2.5024577710226110e-02
    x_21_11   product_ub_168  -4.2911877394678936e-02
    x_21_11   onehot_21_177  1
    x_21_11   stock_lb_254  11
    x_21_11   stock_ub_255  11
    x_21_11   parent_nonstrict_scope_256  3.6000000000000004e-02
    x_21_11   unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_11   product_lb_167  1
    w_21_11   product_ub_168  1
    w_21_11   normalized_mass_21_178  1
    w_21_11   normalized_ratio_21_179  -1.375
    w_21_11   full_original_Gini_314  -1.3821428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_12   product_lb_169  -2.5024577710226110e-02
    x_21_12   product_ub_170  -4.2911877394678936e-02
    x_21_12   onehot_21_177  1
    x_21_12   stock_lb_254  12
    x_21_12   stock_ub_255  12
    x_21_12   parent_nonstrict_scope_256  0.048
    x_21_12   unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_12   product_lb_169  1
    w_21_12   product_ub_170  1
    w_21_12   normalized_mass_21_178  1
    w_21_12   normalized_ratio_21_179  -1.5
    w_21_12   full_original_Gini_314  -1.7196428571428573e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_13   OBJ       1.1999999999999997e-02
    x_21_13   product_lb_171  -2.5024577710226110e-02
    x_21_13   product_ub_172  -4.2911877394678936e-02
    x_21_13   onehot_21_177  1
    x_21_13   stock_lb_254  13
    x_21_13   stock_ub_255  13
    x_21_13   parent_nonstrict_scope_256  0.06
    x_21_13   unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_13   product_lb_171  1
    w_21_13   product_ub_172  1
    w_21_13   normalized_mass_21_178  1
    w_21_13   normalized_ratio_21_179  -1.625
    w_21_13   full_original_Gini_314  -2.0571428571428573e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_14   OBJ       2.4000000000000007e-02
    x_21_14   product_lb_173  -2.5024577710226110e-02
    x_21_14   product_ub_174  -4.2911877394678936e-02
    x_21_14   onehot_21_177  1
    x_21_14   stock_lb_254  14
    x_21_14   stock_ub_255  14
    x_21_14   parent_nonstrict_scope_256  7.2000000000000008e-02
    x_21_14   unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_14   product_lb_173  1
    w_21_14   product_ub_174  1
    w_21_14   normalized_mass_21_178  1
    w_21_14   normalized_ratio_21_179  -1.75
    w_21_14   full_original_Gini_314  -2.3946428571428573e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_15   OBJ       3.6000000000000004e-02
    x_21_15   product_lb_175  -2.5024577710226110e-02
    x_21_15   product_ub_176  -4.2911877394678936e-02
    x_21_15   onehot_21_177  1
    x_21_15   stock_lb_254  15
    x_21_15   stock_ub_255  15
    x_21_15   parent_nonstrict_scope_256  0.084
    x_21_15   unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_15   product_lb_175  1
    w_21_15   product_ub_176  1
    w_21_15   normalized_mass_21_178  1
    w_21_15   normalized_ratio_21_179  -1.875
    w_21_15   full_original_Gini_314  -2.7321428571428569e+01
    rho_21    normalized_ratio_21_179  1
    rho_21    block_pair_pos_265  1
    rho_21    block_pair_neg_266  -1
    rho_21    block_pair_pos_279  1
    rho_21    block_pair_neg_280  -1
    rho_21    block_pair_pos_289  1
    rho_21    block_pair_neg_290  -1
    rho_21    block_pair_pos_293  -1
    rho_21    block_pair_neg_294  1
    rho_21    block_pair_pos_295  -1
    rho_21    block_pair_neg_296  1
    rho_21    block_pair_pos_303  1
    rho_21    block_pair_neg_304  -1
    rho_21    block_pair_pos_311  1
    rho_21    block_pair_neg_312  -1
    rho_21    normalization_313  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_180  -2.5024577710226110e-02
    x_2_0     product_ub_181  -4.2911877394678936e-02
    x_2_0     onehot_2_212  1
    x_2_0     parent_nonstrict_scope_256  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_180  1
    w_2_0     product_ub_181  1
    w_2_0     normalized_mass_2_213  1
    w_2_0     full_original_Gini_314  -2.3303571428571431e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_182  -2.5024577710226110e-02
    x_2_1     product_ub_183  -4.2911877394678936e-02
    x_2_1     onehot_2_212  1
    x_2_1     stock_lb_254  1
    x_2_1     stock_ub_255  1
    x_2_1     parent_nonstrict_scope_256  0.063
    x_2_1     unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_182  1
    w_2_1     product_ub_183  1
    w_2_1     normalized_mass_2_213  1
    w_2_1     normalized_ratio_2_214  -1.4285714285714285e-01
    w_2_1     full_original_Gini_314  -1.9732142857142861e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_184  -2.5024577710226110e-02
    x_2_2     product_ub_185  -4.2911877394678936e-02
    x_2_2     onehot_2_212  1
    x_2_2     stock_lb_254  2
    x_2_2     stock_ub_255  2
    x_2_2     parent_nonstrict_scope_256  0.0525
    x_2_2     unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_184  1
    w_2_2     product_ub_185  1
    w_2_2     normalized_mass_2_213  1
    w_2_2     normalized_ratio_2_214  -2.8571428571428570e-01
    w_2_2     full_original_Gini_314  -1.6403571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_186  -2.5024577710226110e-02
    x_2_3     product_ub_187  -4.2911877394678936e-02
    x_2_3     onehot_2_212  1
    x_2_3     stock_lb_254  3
    x_2_3     stock_ub_255  3
    x_2_3     parent_nonstrict_scope_256  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_186  1
    w_2_3     product_ub_187  1
    w_2_3     normalized_mass_2_213  1
    w_2_3     normalized_ratio_2_214  -4.2857142857142855e-01
    w_2_3     full_original_Gini_314  -1.3460714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_188  -2.5024577710226110e-02
    x_2_4     product_ub_189  -4.2911877394678936e-02
    x_2_4     onehot_2_212  1
    x_2_4     stock_lb_254  4
    x_2_4     stock_ub_255  4
    x_2_4     parent_nonstrict_scope_256  0.0315
    x_2_4     unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_188  1
    w_2_4     product_ub_189  1
    w_2_4     normalized_mass_2_213  1
    w_2_4     normalized_ratio_2_214  -5.7142857142857140e-01
    w_2_4     full_original_Gini_314  -1.0746428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_190  -2.5024577710226110e-02
    x_2_5     product_ub_191  -4.2911877394678936e-02
    x_2_5     onehot_2_212  1
    x_2_5     stock_lb_254  5
    x_2_5     stock_ub_255  5
    x_2_5     parent_nonstrict_scope_256  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_190  1
    w_2_5     product_ub_191  1
    w_2_5     normalized_mass_2_213  1
    w_2_5     normalized_ratio_2_214  -7.1428571428571419e-01
    w_2_5     full_original_Gini_314  -8.0321428571428584e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_192  -2.5024577710226110e-02
    x_2_6     product_ub_193  -4.2911877394678936e-02
    x_2_6     onehot_2_212  1
    x_2_6     stock_lb_254  6
    x_2_6     stock_ub_255  6
    x_2_6     parent_nonstrict_scope_256  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_192  1
    w_2_6     product_ub_193  1
    w_2_6     normalized_mass_2_213  1
    w_2_6     normalized_ratio_2_214  -8.5714285714285710e-01
    w_2_6     full_original_Gini_314  -5.8178571428571448e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_194  -2.5024577710226110e-02
    x_2_7     product_ub_195  -4.2911877394678936e-02
    x_2_7     onehot_2_212  1
    x_2_7     stock_lb_254  7
    x_2_7     stock_ub_255  7
    x_2_7     unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_194  1
    w_2_7     product_ub_195  1
    w_2_7     normalized_mass_2_213  1
    w_2_7     normalized_ratio_2_214  -1
    w_2_7     full_original_Gini_314  -4.4964285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_196  -2.5024577710226110e-02
    x_2_8     product_ub_197  -4.2911877394678936e-02
    x_2_8     onehot_2_212  1
    x_2_8     stock_lb_254  8
    x_2_8     stock_ub_255  8
    x_2_8     parent_nonstrict_scope_256  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_196  1
    w_2_8     product_ub_197  1
    w_2_8     normalized_mass_2_213  1
    w_2_8     normalized_ratio_2_214  -1.1428571428571428e+00
    w_2_8     full_original_Gini_314  -7.7821428571428530e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_198  -2.5024577710226110e-02
    x_2_9     product_ub_199  -4.2911877394678936e-02
    x_2_9     onehot_2_212  1
    x_2_9     stock_lb_254  9
    x_2_9     stock_ub_255  9
    x_2_9     parent_nonstrict_scope_256  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_198  1
    w_2_9     product_ub_199  1
    w_2_9     normalized_mass_2_213  1
    w_2_9     normalized_ratio_2_214  -1.2857142857142856e+00
    w_2_9     full_original_Gini_314  -1.1410714285714281e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_200  -2.5024577710226110e-02
    x_2_10    product_ub_201  -4.2911877394678936e-02
    x_2_10    onehot_2_212  1
    x_2_10    stock_lb_254  10
    x_2_10    stock_ub_255  10
    x_2_10    parent_nonstrict_scope_256  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_200  1
    w_2_10    product_ub_201  1
    w_2_10    normalized_mass_2_213  1
    w_2_10    normalized_ratio_2_214  -1.4285714285714284e+00
    w_2_10    full_original_Gini_314  -1.5267857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_202  -2.5024577710226110e-02
    x_2_11    product_ub_203  -4.2911877394678936e-02
    x_2_11    onehot_2_212  1
    x_2_11    stock_lb_254  11
    x_2_11    stock_ub_255  11
    x_2_11    parent_nonstrict_scope_256  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_202  1
    w_2_11    product_ub_203  1
    w_2_11    normalized_mass_2_213  1
    w_2_11    normalized_ratio_2_214  -1.5714285714285714e+00
    w_2_11    full_original_Gini_314  -1.9125000000000004e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_204  -2.5024577710226110e-02
    x_2_12    product_ub_205  -4.2911877394678936e-02
    x_2_12    onehot_2_212  1
    x_2_12    stock_lb_254  12
    x_2_12    stock_ub_255  12
    x_2_12    parent_nonstrict_scope_256  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_204  1
    w_2_12    product_ub_205  1
    w_2_12    normalized_mass_2_213  1
    w_2_12    normalized_ratio_2_214  -1.7142857142857142e+00
    w_2_12    full_original_Gini_314  -2.2982142857142854e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_206  -2.5024577710226110e-02
    x_2_13    product_ub_207  -4.2911877394678936e-02
    x_2_13    onehot_2_212  1
    x_2_13    stock_lb_254  13
    x_2_13    stock_ub_255  13
    x_2_13    parent_nonstrict_scope_256  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_206  1
    w_2_13    product_ub_207  1
    w_2_13    normalized_mass_2_213  1
    w_2_13    normalized_ratio_2_214  -1.8571428571428570e+00
    w_2_13    full_original_Gini_314  -2.6839285714285719e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_208  -2.5024577710226110e-02
    x_2_14    product_ub_209  -4.2911877394678936e-02
    x_2_14    onehot_2_212  1
    x_2_14    stock_lb_254  14
    x_2_14    stock_ub_255  14
    x_2_14    parent_nonstrict_scope_256  0.0735
    x_2_14    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_208  1
    w_2_14    product_ub_209  1
    w_2_14    normalized_mass_2_213  1
    w_2_14    normalized_ratio_2_214  -2
    w_2_14    full_original_Gini_314  -3.0696428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_210  -2.5024577710226110e-02
    x_2_15    product_ub_211  -4.2911877394678936e-02
    x_2_15    onehot_2_212  1
    x_2_15    stock_lb_254  15
    x_2_15    stock_ub_255  15
    x_2_15    parent_nonstrict_scope_256  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_210  1
    w_2_15    product_ub_211  1
    w_2_15    normalized_mass_2_213  1
    w_2_15    normalized_ratio_2_214  -2.1428571428571428e+00
    w_2_15    full_original_Gini_314  -3.4553571428571423e+01
    rho_2     normalized_ratio_2_214  1
    rho_2     block_pair_pos_257  -1
    rho_2     block_pair_neg_258  1
    rho_2     block_pair_pos_259  1
    rho_2     block_pair_neg_260  -1
    rho_2     block_pair_pos_271  1
    rho_2     block_pair_neg_272  -1
    rho_2     block_pair_pos_285  1
    rho_2     block_pair_neg_286  -1
    rho_2     block_pair_pos_293  1
    rho_2     block_pair_neg_294  -1
    rho_2     block_pair_pos_297  1
    rho_2     block_pair_neg_298  -1
    rho_2     block_pair_pos_307  1
    rho_2     block_pair_neg_308  -1
    rho_2     normalization_313  1
    MARKER    'MARKER'                 'INTORG'
    x_7_0     OBJ       0.042
    x_7_0     product_lb_215  -2.5024577710226110e-02
    x_7_0     product_ub_216  -4.2911877394678936e-02
    x_7_0     onehot_7_251  1
    x_7_0     parent_nonstrict_scope_256  0.096
    x_7_0     unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_0     product_lb_215  1
    w_7_0     product_ub_216  1
    w_7_0     normalized_mass_7_252  1
    w_7_0     full_original_Gini_314  -2.3303571428571431e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_1     OBJ       3.0000000000000006e-02
    x_7_1     product_lb_217  -2.5024577710226110e-02
    x_7_1     product_ub_218  -4.2911877394678936e-02
    x_7_1     onehot_7_251  1
    x_7_1     stock_lb_254  1
    x_7_1     stock_ub_255  1
    x_7_1     parent_nonstrict_scope_256  0.084
    x_7_1     unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_1     product_lb_217  1
    w_7_1     product_ub_218  1
    w_7_1     normalized_mass_7_252  1
    w_7_1     normalized_ratio_7_253  -0.125
    w_7_1     full_original_Gini_314  -2.0178571428571427e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_2     OBJ       1.8000000000000009e-02
    x_7_2     product_lb_219  -2.5024577710226110e-02
    x_7_2     product_ub_220  -4.2911877394678936e-02
    x_7_2     onehot_7_251  1
    x_7_2     stock_lb_254  2
    x_7_2     stock_ub_255  2
    x_7_2     parent_nonstrict_scope_256  7.2000000000000008e-02
    x_7_2     unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_2     product_lb_219  1
    w_7_2     product_ub_220  1
    w_7_2     normalized_mass_7_252  1
    w_7_2     normalized_ratio_7_253  -0.25
    w_7_2     full_original_Gini_314  -1.7153571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_3     OBJ       5.9999999999999984e-03
    x_7_3     product_lb_221  -2.5024577710226110e-02
    x_7_3     product_ub_222  -4.2911877394678936e-02
    x_7_3     onehot_7_251  1
    x_7_3     stock_lb_254  3
    x_7_3     stock_ub_255  3
    x_7_3     parent_nonstrict_scope_256  0.06
    x_7_3     unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_3     product_lb_221  1
    w_7_3     product_ub_222  1
    w_7_3     normalized_mass_7_252  1
    w_7_3     normalized_ratio_7_253  -0.375
    w_7_3     full_original_Gini_314  -1.4528571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_4     OBJ       -5.9999999999999984e-03
    x_7_4     product_lb_223  -2.5024577710226110e-02
    x_7_4     product_ub_224  -4.2911877394678936e-02
    x_7_4     onehot_7_251  1
    x_7_4     stock_lb_254  4
    x_7_4     stock_ub_255  4
    x_7_4     parent_nonstrict_scope_256  0.048
    x_7_4     unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_4     product_lb_223  1
    w_7_4     product_ub_224  1
    w_7_4     normalized_mass_7_252  1
    w_7_4     normalized_ratio_7_253  -0.5
    w_7_4     full_original_Gini_314  -1.2103571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_5     OBJ       -1.7999999999999995e-02
    x_7_5     product_lb_225  -2.5024577710226110e-02
    x_7_5     product_ub_226  -4.2911877394678936e-02
    x_7_5     onehot_7_251  1
    x_7_5     stock_lb_254  5
    x_7_5     stock_ub_255  5
    x_7_5     parent_nonstrict_scope_256  3.6000000000000004e-02
    x_7_5     unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_5     product_lb_225  1
    w_7_5     product_ub_226  1
    w_7_5     normalized_mass_7_252  1
    w_7_5     normalized_ratio_7_253  -0.625
    w_7_5     full_original_Gini_314  -9.72857142857143
    MARKER    'MARKER'                 'INTORG'
    x_7_6     OBJ       -0.03
    x_7_6     product_lb_227  -2.5024577710226110e-02
    x_7_6     product_ub_228  -4.2911877394678936e-02
    x_7_6     onehot_7_251  1
    x_7_6     stock_lb_254  6
    x_7_6     stock_ub_255  6
    x_7_6     parent_nonstrict_scope_256  0.024
    x_7_6     unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_6     product_lb_227  1
    w_7_6     product_ub_228  1
    w_7_6     normalized_mass_7_252  1
    w_7_6     normalized_ratio_7_253  -0.75
    w_7_6     full_original_Gini_314  -7.425
    MARKER    'MARKER'                 'INTORG'
    x_7_7     OBJ       -4.1999999999999996e-02
    x_7_7     product_lb_229  -2.5024577710226110e-02
    x_7_7     product_ub_230  -4.2911877394678936e-02
    x_7_7     onehot_7_251  1
    x_7_7     stock_lb_254  7
    x_7_7     stock_ub_255  7
    x_7_7     parent_nonstrict_scope_256  0.012
    x_7_7     unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_7     product_lb_229  1
    w_7_7     product_ub_230  1
    w_7_7     normalized_mass_7_252  1
    w_7_7     normalized_ratio_7_253  -0.875
    w_7_7     full_original_Gini_314  -5.6214285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_8     OBJ       -0.054
    x_7_8     product_lb_231  -2.5024577710226110e-02
    x_7_8     product_ub_232  -4.2911877394678936e-02
    x_7_8     onehot_7_251  1
    x_7_8     stock_lb_254  8
    x_7_8     stock_ub_255  8
    x_7_8     unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_8     product_lb_231  1
    w_7_8     product_ub_232  1
    w_7_8     normalized_mass_7_252  1
    w_7_8     normalized_ratio_7_253  -1
    w_7_8     full_original_Gini_314  -4.4964285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_9     OBJ       -4.1999999999999996e-02
    x_7_9     product_lb_233  -2.5024577710226110e-02
    x_7_9     product_ub_234  -4.2911877394678936e-02
    x_7_9     onehot_7_251  1
    x_7_9     stock_lb_254  9
    x_7_9     stock_ub_255  9
    x_7_9     parent_nonstrict_scope_256  0.012
    x_7_9     unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_9     product_lb_233  1
    w_7_9     product_ub_234  1
    w_7_9     normalized_mass_7_252  1
    w_7_9     normalized_ratio_7_253  -1.125
    w_7_9     full_original_Gini_314  -7.3714285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_10    OBJ       -0.03
    x_7_10    product_lb_235  -2.5024577710226110e-02
    x_7_10    product_ub_236  -4.2911877394678936e-02
    x_7_10    onehot_7_251  1
    x_7_10    stock_lb_254  10
    x_7_10    stock_ub_255  10
    x_7_10    parent_nonstrict_scope_256  0.024
    x_7_10    unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_10    product_lb_235  1
    w_7_10    product_ub_236  1
    w_7_10    normalized_mass_7_252  1
    w_7_10    normalized_ratio_7_253  -1.25
    w_7_10    full_original_Gini_314  -1.0446428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_11    OBJ       -1.7999999999999995e-02
    x_7_11    product_lb_237  -2.5024577710226110e-02
    x_7_11    product_ub_238  -4.2911877394678936e-02
    x_7_11    onehot_7_251  1
    x_7_11    stock_lb_254  11
    x_7_11    stock_ub_255  11
    x_7_11    parent_nonstrict_scope_256  3.6000000000000004e-02
    x_7_11    unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_11    product_lb_237  1
    w_7_11    product_ub_238  1
    w_7_11    normalized_mass_7_252  1
    w_7_11    normalized_ratio_7_253  -1.375
    w_7_11    full_original_Gini_314  -1.3821428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_12    OBJ       -5.9999999999999984e-03
    x_7_12    product_lb_239  -2.5024577710226110e-02
    x_7_12    product_ub_240  -4.2911877394678936e-02
    x_7_12    onehot_7_251  1
    x_7_12    stock_lb_254  12
    x_7_12    stock_ub_255  12
    x_7_12    parent_nonstrict_scope_256  0.048
    MARKER    'MARKER'                 'INTEND'
    w_7_12    product_lb_239  1
    w_7_12    product_ub_240  1
    w_7_12    normalized_mass_7_252  1
    w_7_12    normalized_ratio_7_253  -1.5
    w_7_12    full_original_Gini_314  -1.7196428571428573e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_13    OBJ       5.9999999999999984e-03
    x_7_13    product_lb_241  -2.5024577710226110e-02
    x_7_13    product_ub_242  -4.2911877394678936e-02
    x_7_13    onehot_7_251  1
    x_7_13    stock_lb_254  13
    x_7_13    stock_ub_255  13
    x_7_13    parent_nonstrict_scope_256  0.06
    x_7_13    unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_13    product_lb_241  1
    w_7_13    product_ub_242  1
    w_7_13    normalized_mass_7_252  1
    w_7_13    normalized_ratio_7_253  -1.625
    w_7_13    full_original_Gini_314  -2.0571428571428573e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_14    OBJ       1.8000000000000009e-02
    x_7_14    product_lb_243  -2.5024577710226110e-02
    x_7_14    product_ub_244  -4.2911877394678936e-02
    x_7_14    onehot_7_251  1
    x_7_14    stock_lb_254  14
    x_7_14    stock_ub_255  14
    x_7_14    parent_nonstrict_scope_256  7.2000000000000008e-02
    x_7_14    unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_14    product_lb_243  1
    w_7_14    product_ub_244  1
    w_7_14    normalized_mass_7_252  1
    w_7_14    normalized_ratio_7_253  -1.75
    w_7_14    full_original_Gini_314  -2.3946428571428573e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_15    OBJ       3.0000000000000006e-02
    x_7_15    product_lb_245  -2.5024577710226110e-02
    x_7_15    product_ub_246  -4.2911877394678936e-02
    x_7_15    onehot_7_251  1
    x_7_15    stock_lb_254  15
    x_7_15    stock_ub_255  15
    x_7_15    parent_nonstrict_scope_256  0.084
    x_7_15    unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_15    product_lb_245  1
    w_7_15    product_ub_246  1
    w_7_15    normalized_mass_7_252  1
    w_7_15    normalized_ratio_7_253  -1.875
    w_7_15    full_original_Gini_314  -2.7321428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_16    OBJ       0.042
    x_7_16    product_lb_247  -2.5024577710226110e-02
    x_7_16    product_ub_248  -4.2911877394678936e-02
    x_7_16    onehot_7_251  1
    x_7_16    stock_lb_254  16
    x_7_16    stock_ub_255  16
    x_7_16    parent_nonstrict_scope_256  0.096
    x_7_16    unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_16    product_lb_247  1
    w_7_16    product_ub_248  1
    w_7_16    normalized_mass_7_252  1
    w_7_16    normalized_ratio_7_253  -2
    w_7_16    full_original_Gini_314  -3.0696428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_17    OBJ       0.054
    x_7_17    product_lb_249  -2.5024577710226110e-02
    x_7_17    product_ub_250  -4.2911877394678936e-02
    x_7_17    onehot_7_251  1
    x_7_17    stock_lb_254  17
    x_7_17    stock_ub_255  17
    x_7_17    parent_nonstrict_scope_256  0.108
    x_7_17    unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_17    product_lb_249  1
    w_7_17    product_ub_250  1
    w_7_17    normalized_mass_7_252  1
    w_7_17    normalized_ratio_7_253  -2.125
    w_7_17    full_original_Gini_314  -3.4071428571428569e+01
    rho_7     normalized_ratio_7_253  1
    rho_7     block_pair_pos_257  1
    rho_7     block_pair_neg_258  -1
    rho_7     block_pair_pos_261  1
    rho_7     block_pair_neg_262  -1
    rho_7     block_pair_pos_273  1
    rho_7     block_pair_neg_274  -1
    rho_7     block_pair_pos_287  1
    rho_7     block_pair_neg_288  -1
    rho_7     block_pair_pos_295  1
    rho_7     block_pair_neg_296  -1
    rho_7     block_pair_pos_299  1
    rho_7     block_pair_neg_300  -1
    rho_7     block_pair_pos_309  1
    rho_7     block_pair_neg_310  -1
    rho_7     normalization_313  1
    a_16_11   block_pair_pos_275  1
    a_16_11   block_pair_neg_276  1
    a_16_11   full_original_Gini_314  -1
    a_16_31   block_pair_pos_281  1
    a_16_31   block_pair_neg_282  1
    a_16_31   full_original_Gini_314  -1
    a_16_20   block_pair_pos_277  1
    a_16_20   block_pair_neg_278  1
    a_16_20   full_original_Gini_314  -1
    a_16_32   block_pair_pos_283  1
    a_16_32   block_pair_neg_284  1
    a_16_32   full_original_Gini_314  -1
    a_16_21   block_pair_pos_279  1
    a_16_21   block_pair_neg_280  1
    a_16_21   full_original_Gini_314  -1
    a_16_2    block_pair_pos_271  1
    a_16_2    block_pair_neg_272  1
    a_16_2    full_original_Gini_314  -1
    a_16_7    block_pair_pos_273  1
    a_16_7    block_pair_neg_274  1
    a_16_7    full_original_Gini_314  -1
    a_11_31   block_pair_pos_267  1
    a_11_31   block_pair_neg_268  1
    a_11_31   full_original_Gini_314  -1
    a_11_20   block_pair_pos_263  1
    a_11_20   block_pair_neg_264  1
    a_11_20   full_original_Gini_314  -1
    a_11_32   block_pair_pos_269  1
    a_11_32   block_pair_neg_270  1
    a_11_32   full_original_Gini_314  -1
    a_11_21   block_pair_pos_265  1
    a_11_21   block_pair_neg_266  1
    a_11_21   full_original_Gini_314  -1
    a_11_2    block_pair_pos_259  1
    a_11_2    block_pair_neg_260  1
    a_11_2    full_original_Gini_314  -1
    a_11_7    block_pair_pos_261  1
    a_11_7    block_pair_neg_262  1
    a_11_7    full_original_Gini_314  -1
    a_31_20   block_pair_pos_301  1
    a_31_20   block_pair_neg_302  1
    a_31_20   full_original_Gini_314  -1
    a_31_32   block_pair_pos_305  1
    a_31_32   block_pair_neg_306  1
    a_31_32   full_original_Gini_314  -1
    a_31_21   block_pair_pos_303  1
    a_31_21   block_pair_neg_304  1
    a_31_21   full_original_Gini_314  -1
    a_31_2    block_pair_pos_297  1
    a_31_2    block_pair_neg_298  1
    a_31_2    full_original_Gini_314  -1
    a_31_7    block_pair_pos_299  1
    a_31_7    block_pair_neg_300  1
    a_31_7    full_original_Gini_314  -1
    a_20_32   block_pair_pos_291  1
    a_20_32   block_pair_neg_292  1
    a_20_32   full_original_Gini_314  -1
    a_20_21   block_pair_pos_289  1
    a_20_21   block_pair_neg_290  1
    a_20_21   full_original_Gini_314  -1
    a_20_2    block_pair_pos_285  1
    a_20_2    block_pair_neg_286  1
    a_20_2    full_original_Gini_314  -1
    a_20_7    block_pair_pos_287  1
    a_20_7    block_pair_neg_288  1
    a_20_7    full_original_Gini_314  -1
    a_32_21   block_pair_pos_311  1
    a_32_21   block_pair_neg_312  1
    a_32_21   full_original_Gini_314  -1
    a_32_2    block_pair_pos_307  1
    a_32_2    block_pair_neg_308  1
    a_32_2    full_original_Gini_314  -1
    a_32_7    block_pair_pos_309  1
    a_32_7    block_pair_neg_310  1
    a_32_7    full_original_Gini_314  -1
    a_21_2    block_pair_pos_293  1
    a_21_2    block_pair_neg_294  1
    a_21_2    full_original_Gini_314  -1
    a_21_7    block_pair_pos_295  1
    a_21_7    block_pair_neg_296  1
    a_21_7    full_original_Gini_314  -1
    a_2_7     block_pair_pos_257  1
    a_2_7     block_pair_neg_258  1
    a_2_7     full_original_Gini_314  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_16_0  unique_nonzero_owner_315  1
    service_0_16_0  service_visit_def_863  1
    service_0_16_0  free_load_conservation_864  -1
    service_0_16_0  original_T_including_depot_unload_912  120
    service_0_16_2  unique_nonzero_owner_316  1
    service_0_16_2  service_visit_def_863  1
    service_0_16_2  free_load_conservation_864  1
    service_0_16_3  unique_nonzero_owner_317  1
    service_0_16_3  service_visit_def_863  1
    service_0_16_3  free_load_conservation_864  2
    service_0_16_4  unique_nonzero_owner_318  1
    service_0_16_4  service_visit_def_863  1
    service_0_16_4  free_load_conservation_864  3
    service_0_16_5  unique_nonzero_owner_319  1
    service_0_16_5  service_visit_def_863  1
    service_0_16_5  free_load_conservation_864  4
    service_0_16_6  unique_nonzero_owner_320  1
    service_0_16_6  service_visit_def_863  1
    service_0_16_6  free_load_conservation_864  5
    service_0_16_7  unique_nonzero_owner_321  1
    service_0_16_7  service_visit_def_863  1
    service_0_16_7  free_load_conservation_864  6
    service_0_16_8  unique_nonzero_owner_322  1
    service_0_16_8  service_visit_def_863  1
    service_0_16_8  free_load_conservation_864  7
    service_0_16_9  unique_nonzero_owner_323  1
    service_0_16_9  service_visit_def_863  1
    service_0_16_9  free_load_conservation_864  8
    service_0_16_10  unique_nonzero_owner_324  1
    service_0_16_10  service_visit_def_863  1
    service_0_16_10  free_load_conservation_864  9
    service_0_16_11  unique_nonzero_owner_325  1
    service_0_16_11  service_visit_def_863  1
    service_0_16_11  free_load_conservation_864  10
    service_0_16_12  unique_nonzero_owner_326  1
    service_0_16_12  service_visit_def_863  1
    service_0_16_12  free_load_conservation_864  11
    service_1_16_0  unique_nonzero_owner_315  1
    service_1_16_0  service_visit_def_1236  1
    service_1_16_0  free_load_conservation_1237  -1
    service_1_16_0  original_T_including_depot_unload_1283  120
    service_1_16_2  unique_nonzero_owner_316  1
    service_1_16_2  service_visit_def_1236  1
    service_1_16_2  free_load_conservation_1237  1
    service_1_16_3  unique_nonzero_owner_317  1
    service_1_16_3  service_visit_def_1236  1
    service_1_16_3  free_load_conservation_1237  2
    service_1_16_4  unique_nonzero_owner_318  1
    service_1_16_4  service_visit_def_1236  1
    service_1_16_4  free_load_conservation_1237  3
    service_1_16_5  unique_nonzero_owner_319  1
    service_1_16_5  service_visit_def_1236  1
    service_1_16_5  free_load_conservation_1237  4
    service_1_16_6  unique_nonzero_owner_320  1
    service_1_16_6  service_visit_def_1236  1
    service_1_16_6  free_load_conservation_1237  5
    service_1_16_7  unique_nonzero_owner_321  1
    service_1_16_7  service_visit_def_1236  1
    service_1_16_7  free_load_conservation_1237  6
    service_1_16_8  unique_nonzero_owner_322  1
    service_1_16_8  service_visit_def_1236  1
    service_1_16_8  free_load_conservation_1237  7
    service_1_16_9  unique_nonzero_owner_323  1
    service_1_16_9  service_visit_def_1236  1
    service_1_16_9  free_load_conservation_1237  8
    service_1_16_10  unique_nonzero_owner_324  1
    service_1_16_10  service_visit_def_1236  1
    service_1_16_10  free_load_conservation_1237  9
    service_1_16_11  unique_nonzero_owner_325  1
    service_1_16_11  service_visit_def_1236  1
    service_1_16_11  free_load_conservation_1237  10
    service_1_16_12  unique_nonzero_owner_326  1
    service_1_16_12  service_visit_def_1236  1
    service_1_16_12  free_load_conservation_1237  11
    service_2_16_0  unique_nonzero_owner_315  1
    service_2_16_0  service_visit_def_1554  1
    service_2_16_0  free_load_conservation_1555  -1
    service_2_16_0  original_T_including_depot_unload_1600  120
    service_2_16_2  unique_nonzero_owner_316  1
    service_2_16_2  service_visit_def_1554  1
    service_2_16_2  free_load_conservation_1555  1
    service_2_16_3  unique_nonzero_owner_317  1
    service_2_16_3  service_visit_def_1554  1
    service_2_16_3  free_load_conservation_1555  2
    service_2_16_4  unique_nonzero_owner_318  1
    service_2_16_4  service_visit_def_1554  1
    service_2_16_4  free_load_conservation_1555  3
    service_2_16_5  unique_nonzero_owner_319  1
    service_2_16_5  service_visit_def_1554  1
    service_2_16_5  free_load_conservation_1555  4
    service_2_16_6  unique_nonzero_owner_320  1
    service_2_16_6  service_visit_def_1554  1
    service_2_16_6  free_load_conservation_1555  5
    service_2_16_7  unique_nonzero_owner_321  1
    service_2_16_7  service_visit_def_1554  1
    service_2_16_7  free_load_conservation_1555  6
    service_2_16_8  unique_nonzero_owner_322  1
    service_2_16_8  service_visit_def_1554  1
    service_2_16_8  free_load_conservation_1555  7
    service_2_16_9  unique_nonzero_owner_323  1
    service_2_16_9  service_visit_def_1554  1
    service_2_16_9  free_load_conservation_1555  8
    service_2_16_10  unique_nonzero_owner_324  1
    service_2_16_10  service_visit_def_1554  1
    service_2_16_10  free_load_conservation_1555  9
    service_2_16_11  unique_nonzero_owner_325  1
    service_2_16_11  service_visit_def_1554  1
    service_2_16_11  free_load_conservation_1555  10
    service_2_16_12  unique_nonzero_owner_326  1
    service_2_16_12  service_visit_def_1554  1
    service_2_16_12  free_load_conservation_1555  11
    service_0_11_0  unique_nonzero_owner_327  1
    service_0_11_0  service_visit_def_869  1
    service_0_11_0  free_load_conservation_870  -7
    service_0_11_0  original_T_including_depot_unload_912  840
    service_0_11_1  unique_nonzero_owner_328  1
    service_0_11_1  service_visit_def_869  1
    service_0_11_1  free_load_conservation_870  -6
    service_0_11_1  original_T_including_depot_unload_912  720
    service_0_11_2  unique_nonzero_owner_329  1
    service_0_11_2  service_visit_def_869  1
    service_0_11_2  free_load_conservation_870  -5
    service_0_11_2  original_T_including_depot_unload_912  600
    service_0_11_3  unique_nonzero_owner_330  1
    service_0_11_3  service_visit_def_869  1
    service_0_11_3  free_load_conservation_870  -4
    service_0_11_3  original_T_including_depot_unload_912  480
    service_0_11_4  unique_nonzero_owner_331  1
    service_0_11_4  service_visit_def_869  1
    service_0_11_4  free_load_conservation_870  -3
    service_0_11_4  original_T_including_depot_unload_912  360
    service_0_11_5  unique_nonzero_owner_332  1
    service_0_11_5  service_visit_def_869  1
    service_0_11_5  free_load_conservation_870  -2
    service_0_11_5  original_T_including_depot_unload_912  240
    service_0_11_6  unique_nonzero_owner_333  1
    service_0_11_6  service_visit_def_869  1
    service_0_11_6  free_load_conservation_870  -1
    service_0_11_6  original_T_including_depot_unload_912  120
    service_0_11_8  unique_nonzero_owner_334  1
    service_0_11_8  service_visit_def_869  1
    service_0_11_8  free_load_conservation_870  1
    service_0_11_9  unique_nonzero_owner_335  1
    service_0_11_9  service_visit_def_869  1
    service_0_11_9  free_load_conservation_870  2
    service_0_11_10  unique_nonzero_owner_336  1
    service_0_11_10  service_visit_def_869  1
    service_0_11_10  free_load_conservation_870  3
    service_0_11_11  unique_nonzero_owner_337  1
    service_0_11_11  service_visit_def_869  1
    service_0_11_11  free_load_conservation_870  4
    service_0_11_12  unique_nonzero_owner_338  1
    service_0_11_12  service_visit_def_869  1
    service_0_11_12  free_load_conservation_870  5
    service_1_11_0  unique_nonzero_owner_327  1
    service_1_11_0  service_visit_def_1242  1
    service_1_11_0  free_load_conservation_1243  -7
    service_1_11_0  original_T_including_depot_unload_1283  840
    service_1_11_1  unique_nonzero_owner_328  1
    service_1_11_1  service_visit_def_1242  1
    service_1_11_1  free_load_conservation_1243  -6
    service_1_11_1  original_T_including_depot_unload_1283  720
    service_1_11_2  unique_nonzero_owner_329  1
    service_1_11_2  service_visit_def_1242  1
    service_1_11_2  free_load_conservation_1243  -5
    service_1_11_2  original_T_including_depot_unload_1283  600
    service_1_11_3  unique_nonzero_owner_330  1
    service_1_11_3  service_visit_def_1242  1
    service_1_11_3  free_load_conservation_1243  -4
    service_1_11_3  original_T_including_depot_unload_1283  480
    service_1_11_4  unique_nonzero_owner_331  1
    service_1_11_4  service_visit_def_1242  1
    service_1_11_4  free_load_conservation_1243  -3
    service_1_11_4  original_T_including_depot_unload_1283  360
    service_1_11_5  unique_nonzero_owner_332  1
    service_1_11_5  service_visit_def_1242  1
    service_1_11_5  free_load_conservation_1243  -2
    service_1_11_5  original_T_including_depot_unload_1283  240
    service_1_11_6  unique_nonzero_owner_333  1
    service_1_11_6  service_visit_def_1242  1
    service_1_11_6  free_load_conservation_1243  -1
    service_1_11_6  original_T_including_depot_unload_1283  120
    service_1_11_8  unique_nonzero_owner_334  1
    service_1_11_8  service_visit_def_1242  1
    service_1_11_8  free_load_conservation_1243  1
    service_1_11_9  unique_nonzero_owner_335  1
    service_1_11_9  service_visit_def_1242  1
    service_1_11_9  free_load_conservation_1243  2
    service_1_11_10  unique_nonzero_owner_336  1
    service_1_11_10  service_visit_def_1242  1
    service_1_11_10  free_load_conservation_1243  3
    service_1_11_11  unique_nonzero_owner_337  1
    service_1_11_11  service_visit_def_1242  1
    service_1_11_11  free_load_conservation_1243  4
    service_1_11_12  unique_nonzero_owner_338  1
    service_1_11_12  service_visit_def_1242  1
    service_1_11_12  free_load_conservation_1243  5
    service_2_11_0  unique_nonzero_owner_327  1
    service_2_11_0  service_visit_def_1560  1
    service_2_11_0  free_load_conservation_1561  -7
    service_2_11_0  original_T_including_depot_unload_1600  840
    service_2_11_1  unique_nonzero_owner_328  1
    service_2_11_1  service_visit_def_1560  1
    service_2_11_1  free_load_conservation_1561  -6
    service_2_11_1  original_T_including_depot_unload_1600  720
    service_2_11_2  unique_nonzero_owner_329  1
    service_2_11_2  service_visit_def_1560  1
    service_2_11_2  free_load_conservation_1561  -5
    service_2_11_2  original_T_including_depot_unload_1600  600
    service_2_11_3  unique_nonzero_owner_330  1
    service_2_11_3  service_visit_def_1560  1
    service_2_11_3  free_load_conservation_1561  -4
    service_2_11_3  original_T_including_depot_unload_1600  480
    service_2_11_4  unique_nonzero_owner_331  1
    service_2_11_4  service_visit_def_1560  1
    service_2_11_4  free_load_conservation_1561  -3
    service_2_11_4  original_T_including_depot_unload_1600  360
    service_2_11_5  unique_nonzero_owner_332  1
    service_2_11_5  service_visit_def_1560  1
    service_2_11_5  free_load_conservation_1561  -2
    service_2_11_5  original_T_including_depot_unload_1600  240
    service_2_11_6  unique_nonzero_owner_333  1
    service_2_11_6  service_visit_def_1560  1
    service_2_11_6  free_load_conservation_1561  -1
    service_2_11_6  original_T_including_depot_unload_1600  120
    service_2_11_8  unique_nonzero_owner_334  1
    service_2_11_8  service_visit_def_1560  1
    service_2_11_8  free_load_conservation_1561  1
    service_2_11_9  unique_nonzero_owner_335  1
    service_2_11_9  service_visit_def_1560  1
    service_2_11_9  free_load_conservation_1561  2
    service_2_11_10  unique_nonzero_owner_336  1
    service_2_11_10  service_visit_def_1560  1
    service_2_11_10  free_load_conservation_1561  3
    service_2_11_11  unique_nonzero_owner_337  1
    service_2_11_11  service_visit_def_1560  1
    service_2_11_11  free_load_conservation_1561  4
    service_2_11_12  unique_nonzero_owner_338  1
    service_2_11_12  service_visit_def_1560  1
    service_2_11_12  free_load_conservation_1561  5
    service_0_31_0  unique_nonzero_owner_339  1
    service_0_31_0  service_visit_def_875  1
    service_0_31_0  free_load_conservation_876  -2
    service_0_31_0  original_T_including_depot_unload_912  240
    service_0_31_1  unique_nonzero_owner_340  1
    service_0_31_1  service_visit_def_875  1
    service_0_31_1  free_load_conservation_876  -1
    service_0_31_1  original_T_including_depot_unload_912  120
    service_0_31_3  unique_nonzero_owner_341  1
    service_0_31_3  service_visit_def_875  1
    service_0_31_3  free_load_conservation_876  1
    service_0_31_4  unique_nonzero_owner_342  1
    service_0_31_4  service_visit_def_875  1
    service_0_31_4  free_load_conservation_876  2
    service_0_31_5  unique_nonzero_owner_343  1
    service_0_31_5  service_visit_def_875  1
    service_0_31_5  free_load_conservation_876  3
    service_0_31_6  unique_nonzero_owner_344  1
    service_0_31_6  service_visit_def_875  1
    service_0_31_6  free_load_conservation_876  4
    service_0_31_7  unique_nonzero_owner_345  1
    service_0_31_7  service_visit_def_875  1
    service_0_31_7  free_load_conservation_876  5
    service_0_31_8  unique_nonzero_owner_346  1
    service_0_31_8  service_visit_def_875  1
    service_0_31_8  free_load_conservation_876  6
    service_0_31_9  unique_nonzero_owner_347  1
    service_0_31_9  service_visit_def_875  1
    service_0_31_9  free_load_conservation_876  7
    service_0_31_10  unique_nonzero_owner_348  1
    service_0_31_10  service_visit_def_875  1
    service_0_31_10  free_load_conservation_876  8
    service_0_31_11  unique_nonzero_owner_349  1
    service_0_31_11  service_visit_def_875  1
    service_0_31_11  free_load_conservation_876  9
    service_0_31_12  unique_nonzero_owner_350  1
    service_0_31_12  service_visit_def_875  1
    service_0_31_12  free_load_conservation_876  10
    service_1_31_0  unique_nonzero_owner_339  1
    service_1_31_0  service_visit_def_1248  1
    service_1_31_0  free_load_conservation_1249  -2
    service_1_31_0  original_T_including_depot_unload_1283  240
    service_1_31_1  unique_nonzero_owner_340  1
    service_1_31_1  service_visit_def_1248  1
    service_1_31_1  free_load_conservation_1249  -1
    service_1_31_1  original_T_including_depot_unload_1283  120
    service_1_31_3  unique_nonzero_owner_341  1
    service_1_31_3  service_visit_def_1248  1
    service_1_31_3  free_load_conservation_1249  1
    service_1_31_4  unique_nonzero_owner_342  1
    service_1_31_4  service_visit_def_1248  1
    service_1_31_4  free_load_conservation_1249  2
    service_1_31_5  unique_nonzero_owner_343  1
    service_1_31_5  service_visit_def_1248  1
    service_1_31_5  free_load_conservation_1249  3
    service_1_31_6  unique_nonzero_owner_344  1
    service_1_31_6  service_visit_def_1248  1
    service_1_31_6  free_load_conservation_1249  4
    service_1_31_7  unique_nonzero_owner_345  1
    service_1_31_7  service_visit_def_1248  1
    service_1_31_7  free_load_conservation_1249  5
    service_1_31_8  unique_nonzero_owner_346  1
    service_1_31_8  service_visit_def_1248  1
    service_1_31_8  free_load_conservation_1249  6
    service_1_31_9  unique_nonzero_owner_347  1
    service_1_31_9  service_visit_def_1248  1
    service_1_31_9  free_load_conservation_1249  7
    service_1_31_10  unique_nonzero_owner_348  1
    service_1_31_10  service_visit_def_1248  1
    service_1_31_10  free_load_conservation_1249  8
    service_1_31_11  unique_nonzero_owner_349  1
    service_1_31_11  service_visit_def_1248  1
    service_1_31_11  free_load_conservation_1249  9
    service_1_31_12  unique_nonzero_owner_350  1
    service_1_31_12  service_visit_def_1248  1
    service_1_31_12  free_load_conservation_1249  10
    service_2_31_0  unique_nonzero_owner_339  1
    service_2_31_0  service_visit_def_1566  1
    service_2_31_0  free_load_conservation_1567  -2
    service_2_31_0  original_T_including_depot_unload_1600  240
    service_2_31_1  unique_nonzero_owner_340  1
    service_2_31_1  service_visit_def_1566  1
    service_2_31_1  free_load_conservation_1567  -1
    service_2_31_1  original_T_including_depot_unload_1600  120
    service_2_31_3  unique_nonzero_owner_341  1
    service_2_31_3  service_visit_def_1566  1
    service_2_31_3  free_load_conservation_1567  1
    service_2_31_4  unique_nonzero_owner_342  1
    service_2_31_4  service_visit_def_1566  1
    service_2_31_4  free_load_conservation_1567  2
    service_2_31_5  unique_nonzero_owner_343  1
    service_2_31_5  service_visit_def_1566  1
    service_2_31_5  free_load_conservation_1567  3
    service_2_31_6  unique_nonzero_owner_344  1
    service_2_31_6  service_visit_def_1566  1
    service_2_31_6  free_load_conservation_1567  4
    service_2_31_7  unique_nonzero_owner_345  1
    service_2_31_7  service_visit_def_1566  1
    service_2_31_7  free_load_conservation_1567  5
    service_2_31_8  unique_nonzero_owner_346  1
    service_2_31_8  service_visit_def_1566  1
    service_2_31_8  free_load_conservation_1567  6
    service_2_31_9  unique_nonzero_owner_347  1
    service_2_31_9  service_visit_def_1566  1
    service_2_31_9  free_load_conservation_1567  7
    service_2_31_10  unique_nonzero_owner_348  1
    service_2_31_10  service_visit_def_1566  1
    service_2_31_10  free_load_conservation_1567  8
    service_2_31_11  unique_nonzero_owner_349  1
    service_2_31_11  service_visit_def_1566  1
    service_2_31_11  free_load_conservation_1567  9
    service_2_31_12  unique_nonzero_owner_350  1
    service_2_31_12  service_visit_def_1566  1
    service_2_31_12  free_load_conservation_1567  10
    service_0_20_0  unique_nonzero_owner_351  1
    service_0_20_0  service_visit_def_881  1
    service_0_20_0  free_load_conservation_882  -9
    service_0_20_0  original_T_including_depot_unload_912  1080
    service_0_20_1  unique_nonzero_owner_352  1
    service_0_20_1  service_visit_def_881  1
    service_0_20_1  free_load_conservation_882  -8
    service_0_20_1  original_T_including_depot_unload_912  960
    service_0_20_2  unique_nonzero_owner_353  1
    service_0_20_2  service_visit_def_881  1
    service_0_20_2  free_load_conservation_882  -7
    service_0_20_2  original_T_including_depot_unload_912  840
    service_0_20_3  unique_nonzero_owner_354  1
    service_0_20_3  service_visit_def_881  1
    service_0_20_3  free_load_conservation_882  -6
    service_0_20_3  original_T_including_depot_unload_912  720
    service_0_20_4  unique_nonzero_owner_355  1
    service_0_20_4  service_visit_def_881  1
    service_0_20_4  free_load_conservation_882  -5
    service_0_20_4  original_T_including_depot_unload_912  600
    service_0_20_5  unique_nonzero_owner_356  1
    service_0_20_5  service_visit_def_881  1
    service_0_20_5  free_load_conservation_882  -4
    service_0_20_5  original_T_including_depot_unload_912  480
    service_0_20_6  unique_nonzero_owner_357  1
    service_0_20_6  service_visit_def_881  1
    service_0_20_6  free_load_conservation_882  -3
    service_0_20_6  original_T_including_depot_unload_912  360
    service_0_20_7  unique_nonzero_owner_358  1
    service_0_20_7  service_visit_def_881  1
    service_0_20_7  free_load_conservation_882  -2
    service_0_20_7  original_T_including_depot_unload_912  240
    service_0_20_8  unique_nonzero_owner_359  1
    service_0_20_8  service_visit_def_881  1
    service_0_20_8  free_load_conservation_882  -1
    service_0_20_8  original_T_including_depot_unload_912  120
    service_0_20_10  unique_nonzero_owner_360  1
    service_0_20_10  service_visit_def_881  1
    service_0_20_10  free_load_conservation_882  1
    service_0_20_11  unique_nonzero_owner_361  1
    service_0_20_11  service_visit_def_881  1
    service_0_20_11  free_load_conservation_882  2
    service_0_20_12  unique_nonzero_owner_362  1
    service_0_20_12  service_visit_def_881  1
    service_0_20_12  free_load_conservation_882  3
    service_1_20_0  unique_nonzero_owner_351  1
    service_1_20_0  service_visit_def_1254  1
    service_1_20_0  free_load_conservation_1255  -9
    service_1_20_0  original_T_including_depot_unload_1283  1080
    service_1_20_1  unique_nonzero_owner_352  1
    service_1_20_1  service_visit_def_1254  1
    service_1_20_1  free_load_conservation_1255  -8
    service_1_20_1  original_T_including_depot_unload_1283  960
    service_1_20_2  unique_nonzero_owner_353  1
    service_1_20_2  service_visit_def_1254  1
    service_1_20_2  free_load_conservation_1255  -7
    service_1_20_2  original_T_including_depot_unload_1283  840
    service_1_20_3  unique_nonzero_owner_354  1
    service_1_20_3  service_visit_def_1254  1
    service_1_20_3  free_load_conservation_1255  -6
    service_1_20_3  original_T_including_depot_unload_1283  720
    service_1_20_4  unique_nonzero_owner_355  1
    service_1_20_4  service_visit_def_1254  1
    service_1_20_4  free_load_conservation_1255  -5
    service_1_20_4  original_T_including_depot_unload_1283  600
    service_1_20_5  unique_nonzero_owner_356  1
    service_1_20_5  service_visit_def_1254  1
    service_1_20_5  free_load_conservation_1255  -4
    service_1_20_5  original_T_including_depot_unload_1283  480
    service_1_20_6  unique_nonzero_owner_357  1
    service_1_20_6  service_visit_def_1254  1
    service_1_20_6  free_load_conservation_1255  -3
    service_1_20_6  original_T_including_depot_unload_1283  360
    service_1_20_7  unique_nonzero_owner_358  1
    service_1_20_7  service_visit_def_1254  1
    service_1_20_7  free_load_conservation_1255  -2
    service_1_20_7  original_T_including_depot_unload_1283  240
    service_1_20_8  unique_nonzero_owner_359  1
    service_1_20_8  service_visit_def_1254  1
    service_1_20_8  free_load_conservation_1255  -1
    service_1_20_8  original_T_including_depot_unload_1283  120
    service_1_20_10  unique_nonzero_owner_360  1
    service_1_20_10  service_visit_def_1254  1
    service_1_20_10  free_load_conservation_1255  1
    service_1_20_11  unique_nonzero_owner_361  1
    service_1_20_11  service_visit_def_1254  1
    service_1_20_11  free_load_conservation_1255  2
    service_1_20_12  unique_nonzero_owner_362  1
    service_1_20_12  service_visit_def_1254  1
    service_1_20_12  free_load_conservation_1255  3
    service_2_20_0  unique_nonzero_owner_351  1
    service_2_20_0  service_visit_def_1572  1
    service_2_20_0  free_load_conservation_1573  -9
    service_2_20_0  original_T_including_depot_unload_1600  1080
    service_2_20_1  unique_nonzero_owner_352  1
    service_2_20_1  service_visit_def_1572  1
    service_2_20_1  free_load_conservation_1573  -8
    service_2_20_1  original_T_including_depot_unload_1600  960
    service_2_20_2  unique_nonzero_owner_353  1
    service_2_20_2  service_visit_def_1572  1
    service_2_20_2  free_load_conservation_1573  -7
    service_2_20_2  original_T_including_depot_unload_1600  840
    service_2_20_3  unique_nonzero_owner_354  1
    service_2_20_3  service_visit_def_1572  1
    service_2_20_3  free_load_conservation_1573  -6
    service_2_20_3  original_T_including_depot_unload_1600  720
    service_2_20_4  unique_nonzero_owner_355  1
    service_2_20_4  service_visit_def_1572  1
    service_2_20_4  free_load_conservation_1573  -5
    service_2_20_4  original_T_including_depot_unload_1600  600
    service_2_20_5  unique_nonzero_owner_356  1
    service_2_20_5  service_visit_def_1572  1
    service_2_20_5  free_load_conservation_1573  -4
    service_2_20_5  original_T_including_depot_unload_1600  480
    service_2_20_6  unique_nonzero_owner_357  1
    service_2_20_6  service_visit_def_1572  1
    service_2_20_6  free_load_conservation_1573  -3
    service_2_20_6  original_T_including_depot_unload_1600  360
    service_2_20_7  unique_nonzero_owner_358  1
    service_2_20_7  service_visit_def_1572  1
    service_2_20_7  free_load_conservation_1573  -2
    service_2_20_7  original_T_including_depot_unload_1600  240
    service_2_20_8  unique_nonzero_owner_359  1
    service_2_20_8  service_visit_def_1572  1
    service_2_20_8  free_load_conservation_1573  -1
    service_2_20_8  original_T_including_depot_unload_1600  120
    service_2_20_10  unique_nonzero_owner_360  1
    service_2_20_10  service_visit_def_1572  1
    service_2_20_10  free_load_conservation_1573  1
    service_2_20_11  unique_nonzero_owner_361  1
    service_2_20_11  service_visit_def_1572  1
    service_2_20_11  free_load_conservation_1573  2
    service_2_20_12  unique_nonzero_owner_362  1
    service_2_20_12  service_visit_def_1572  1
    service_2_20_12  free_load_conservation_1573  3
    service_0_32_1  unique_nonzero_owner_363  1
    service_0_32_1  service_visit_def_887  1
    service_0_32_1  free_load_conservation_888  1
    service_0_32_2  unique_nonzero_owner_364  1
    service_0_32_2  service_visit_def_887  1
    service_0_32_2  free_load_conservation_888  2
    service_0_32_3  unique_nonzero_owner_365  1
    service_0_32_3  service_visit_def_887  1
    service_0_32_3  free_load_conservation_888  3
    service_0_32_4  unique_nonzero_owner_366  1
    service_0_32_4  service_visit_def_887  1
    service_0_32_4  free_load_conservation_888  4
    service_0_32_5  unique_nonzero_owner_367  1
    service_0_32_5  service_visit_def_887  1
    service_0_32_5  free_load_conservation_888  5
    service_0_32_6  unique_nonzero_owner_368  1
    service_0_32_6  service_visit_def_887  1
    service_0_32_6  free_load_conservation_888  6
    service_0_32_7  unique_nonzero_owner_369  1
    service_0_32_7  service_visit_def_887  1
    service_0_32_7  free_load_conservation_888  7
    service_0_32_8  unique_nonzero_owner_370  1
    service_0_32_8  service_visit_def_887  1
    service_0_32_8  free_load_conservation_888  8
    service_0_32_9  unique_nonzero_owner_371  1
    service_0_32_9  service_visit_def_887  1
    service_0_32_9  free_load_conservation_888  9
    service_0_32_10  unique_nonzero_owner_372  1
    service_0_32_10  service_visit_def_887  1
    service_0_32_10  free_load_conservation_888  10
    service_0_32_11  unique_nonzero_owner_373  1
    service_0_32_11  service_visit_def_887  1
    service_0_32_11  free_load_conservation_888  11
    service_0_32_12  unique_nonzero_owner_374  1
    service_0_32_12  service_visit_def_887  1
    service_0_32_12  free_load_conservation_888  12
    service_1_32_1  unique_nonzero_owner_363  1
    service_1_32_1  service_visit_def_1260  1
    service_1_32_1  free_load_conservation_1261  1
    service_1_32_2  unique_nonzero_owner_364  1
    service_1_32_2  service_visit_def_1260  1
    service_1_32_2  free_load_conservation_1261  2
    service_1_32_3  unique_nonzero_owner_365  1
    service_1_32_3  service_visit_def_1260  1
    service_1_32_3  free_load_conservation_1261  3
    service_1_32_4  unique_nonzero_owner_366  1
    service_1_32_4  service_visit_def_1260  1
    service_1_32_4  free_load_conservation_1261  4
    service_1_32_5  unique_nonzero_owner_367  1
    service_1_32_5  service_visit_def_1260  1
    service_1_32_5  free_load_conservation_1261  5
    service_1_32_6  unique_nonzero_owner_368  1
    service_1_32_6  service_visit_def_1260  1
    service_1_32_6  free_load_conservation_1261  6
    service_1_32_7  unique_nonzero_owner_369  1
    service_1_32_7  service_visit_def_1260  1
    service_1_32_7  free_load_conservation_1261  7
    service_1_32_8  unique_nonzero_owner_370  1
    service_1_32_8  service_visit_def_1260  1
    service_1_32_8  free_load_conservation_1261  8
    service_1_32_9  unique_nonzero_owner_371  1
    service_1_32_9  service_visit_def_1260  1
    service_1_32_9  free_load_conservation_1261  9
    service_1_32_10  unique_nonzero_owner_372  1
    service_1_32_10  service_visit_def_1260  1
    service_1_32_10  free_load_conservation_1261  10
    service_1_32_11  unique_nonzero_owner_373  1
    service_1_32_11  service_visit_def_1260  1
    service_1_32_11  free_load_conservation_1261  11
    service_1_32_12  unique_nonzero_owner_374  1
    service_1_32_12  service_visit_def_1260  1
    service_1_32_12  free_load_conservation_1261  12
    service_2_32_1  unique_nonzero_owner_363  1
    service_2_32_1  service_visit_def_1578  1
    service_2_32_1  free_load_conservation_1579  1
    service_2_32_2  unique_nonzero_owner_364  1
    service_2_32_2  service_visit_def_1578  1
    service_2_32_2  free_load_conservation_1579  2
    service_2_32_3  unique_nonzero_owner_365  1
    service_2_32_3  service_visit_def_1578  1
    service_2_32_3  free_load_conservation_1579  3
    service_2_32_4  unique_nonzero_owner_366  1
    service_2_32_4  service_visit_def_1578  1
    service_2_32_4  free_load_conservation_1579  4
    service_2_32_5  unique_nonzero_owner_367  1
    service_2_32_5  service_visit_def_1578  1
    service_2_32_5  free_load_conservation_1579  5
    service_2_32_6  unique_nonzero_owner_368  1
    service_2_32_6  service_visit_def_1578  1
    service_2_32_6  free_load_conservation_1579  6
    service_2_32_7  unique_nonzero_owner_369  1
    service_2_32_7  service_visit_def_1578  1
    service_2_32_7  free_load_conservation_1579  7
    service_2_32_8  unique_nonzero_owner_370  1
    service_2_32_8  service_visit_def_1578  1
    service_2_32_8  free_load_conservation_1579  8
    service_2_32_9  unique_nonzero_owner_371  1
    service_2_32_9  service_visit_def_1578  1
    service_2_32_9  free_load_conservation_1579  9
    service_2_32_10  unique_nonzero_owner_372  1
    service_2_32_10  service_visit_def_1578  1
    service_2_32_10  free_load_conservation_1579  10
    service_2_32_11  unique_nonzero_owner_373  1
    service_2_32_11  service_visit_def_1578  1
    service_2_32_11  free_load_conservation_1579  11
    service_2_32_12  unique_nonzero_owner_374  1
    service_2_32_12  service_visit_def_1578  1
    service_2_32_12  free_load_conservation_1579  12
    service_0_21_0  unique_nonzero_owner_375  1
    service_0_21_0  service_visit_def_893  1
    service_0_21_0  free_load_conservation_894  -1
    service_0_21_0  original_T_including_depot_unload_912  120
    service_0_21_2  unique_nonzero_owner_376  1
    service_0_21_2  service_visit_def_893  1
    service_0_21_2  free_load_conservation_894  1
    service_0_21_3  unique_nonzero_owner_377  1
    service_0_21_3  service_visit_def_893  1
    service_0_21_3  free_load_conservation_894  2
    service_0_21_4  unique_nonzero_owner_378  1
    service_0_21_4  service_visit_def_893  1
    service_0_21_4  free_load_conservation_894  3
    service_0_21_5  unique_nonzero_owner_379  1
    service_0_21_5  service_visit_def_893  1
    service_0_21_5  free_load_conservation_894  4
    service_0_21_6  unique_nonzero_owner_380  1
    service_0_21_6  service_visit_def_893  1
    service_0_21_6  free_load_conservation_894  5
    service_0_21_7  unique_nonzero_owner_381  1
    service_0_21_7  service_visit_def_893  1
    service_0_21_7  free_load_conservation_894  6
    service_0_21_8  unique_nonzero_owner_382  1
    service_0_21_8  service_visit_def_893  1
    service_0_21_8  free_load_conservation_894  7
    service_0_21_9  unique_nonzero_owner_383  1
    service_0_21_9  service_visit_def_893  1
    service_0_21_9  free_load_conservation_894  8
    service_0_21_10  unique_nonzero_owner_384  1
    service_0_21_10  service_visit_def_893  1
    service_0_21_10  free_load_conservation_894  9
    service_0_21_11  unique_nonzero_owner_385  1
    service_0_21_11  service_visit_def_893  1
    service_0_21_11  free_load_conservation_894  10
    service_0_21_12  unique_nonzero_owner_386  1
    service_0_21_12  service_visit_def_893  1
    service_0_21_12  free_load_conservation_894  11
    service_0_21_13  unique_nonzero_owner_387  1
    service_0_21_13  service_visit_def_893  1
    service_0_21_13  free_load_conservation_894  12
    service_0_21_14  unique_nonzero_owner_388  1
    service_0_21_14  service_visit_def_893  1
    service_0_21_14  free_load_conservation_894  13
    service_0_21_15  unique_nonzero_owner_389  1
    service_0_21_15  service_visit_def_893  1
    service_0_21_15  free_load_conservation_894  14
    service_1_21_0  unique_nonzero_owner_375  1
    service_1_21_0  service_visit_def_1266  1
    service_1_21_0  free_load_conservation_1267  -1
    service_1_21_0  original_T_including_depot_unload_1283  120
    service_1_21_2  unique_nonzero_owner_376  1
    service_1_21_2  service_visit_def_1266  1
    service_1_21_2  free_load_conservation_1267  1
    service_1_21_3  unique_nonzero_owner_377  1
    service_1_21_3  service_visit_def_1266  1
    service_1_21_3  free_load_conservation_1267  2
    service_1_21_4  unique_nonzero_owner_378  1
    service_1_21_4  service_visit_def_1266  1
    service_1_21_4  free_load_conservation_1267  3
    service_1_21_5  unique_nonzero_owner_379  1
    service_1_21_5  service_visit_def_1266  1
    service_1_21_5  free_load_conservation_1267  4
    service_1_21_6  unique_nonzero_owner_380  1
    service_1_21_6  service_visit_def_1266  1
    service_1_21_6  free_load_conservation_1267  5
    service_1_21_7  unique_nonzero_owner_381  1
    service_1_21_7  service_visit_def_1266  1
    service_1_21_7  free_load_conservation_1267  6
    service_1_21_8  unique_nonzero_owner_382  1
    service_1_21_8  service_visit_def_1266  1
    service_1_21_8  free_load_conservation_1267  7
    service_1_21_9  unique_nonzero_owner_383  1
    service_1_21_9  service_visit_def_1266  1
    service_1_21_9  free_load_conservation_1267  8
    service_1_21_10  unique_nonzero_owner_384  1
    service_1_21_10  service_visit_def_1266  1
    service_1_21_10  free_load_conservation_1267  9
    service_1_21_11  unique_nonzero_owner_385  1
    service_1_21_11  service_visit_def_1266  1
    service_1_21_11  free_load_conservation_1267  10
    service_1_21_12  unique_nonzero_owner_386  1
    service_1_21_12  service_visit_def_1266  1
    service_1_21_12  free_load_conservation_1267  11
    service_1_21_13  unique_nonzero_owner_387  1
    service_1_21_13  service_visit_def_1266  1
    service_1_21_13  free_load_conservation_1267  12
    service_1_21_14  unique_nonzero_owner_388  1
    service_1_21_14  service_visit_def_1266  1
    service_1_21_14  free_load_conservation_1267  13
    service_1_21_15  unique_nonzero_owner_389  1
    service_1_21_15  service_visit_def_1266  1
    service_1_21_15  free_load_conservation_1267  14
    service_2_21_0  unique_nonzero_owner_375  1
    service_2_21_0  service_visit_def_1584  1
    service_2_21_0  free_load_conservation_1585  -1
    service_2_21_0  original_T_including_depot_unload_1600  120
    service_2_21_2  unique_nonzero_owner_376  1
    service_2_21_2  service_visit_def_1584  1
    service_2_21_2  free_load_conservation_1585  1
    service_2_21_3  unique_nonzero_owner_377  1
    service_2_21_3  service_visit_def_1584  1
    service_2_21_3  free_load_conservation_1585  2
    service_2_21_4  unique_nonzero_owner_378  1
    service_2_21_4  service_visit_def_1584  1
    service_2_21_4  free_load_conservation_1585  3
    service_2_21_5  unique_nonzero_owner_379  1
    service_2_21_5  service_visit_def_1584  1
    service_2_21_5  free_load_conservation_1585  4
    service_2_21_6  unique_nonzero_owner_380  1
    service_2_21_6  service_visit_def_1584  1
    service_2_21_6  free_load_conservation_1585  5
    service_2_21_7  unique_nonzero_owner_381  1
    service_2_21_7  service_visit_def_1584  1
    service_2_21_7  free_load_conservation_1585  6
    service_2_21_8  unique_nonzero_owner_382  1
    service_2_21_8  service_visit_def_1584  1
    service_2_21_8  free_load_conservation_1585  7
    service_2_21_9  unique_nonzero_owner_383  1
    service_2_21_9  service_visit_def_1584  1
    service_2_21_9  free_load_conservation_1585  8
    service_2_21_10  unique_nonzero_owner_384  1
    service_2_21_10  service_visit_def_1584  1
    service_2_21_10  free_load_conservation_1585  9
    service_2_21_11  unique_nonzero_owner_385  1
    service_2_21_11  service_visit_def_1584  1
    service_2_21_11  free_load_conservation_1585  10
    service_2_21_12  unique_nonzero_owner_386  1
    service_2_21_12  service_visit_def_1584  1
    service_2_21_12  free_load_conservation_1585  11
    service_2_21_13  unique_nonzero_owner_387  1
    service_2_21_13  service_visit_def_1584  1
    service_2_21_13  free_load_conservation_1585  12
    service_2_21_14  unique_nonzero_owner_388  1
    service_2_21_14  service_visit_def_1584  1
    service_2_21_14  free_load_conservation_1585  13
    service_2_21_15  unique_nonzero_owner_389  1
    service_2_21_15  service_visit_def_1584  1
    service_2_21_15  free_load_conservation_1585  14
    service_0_2_1  unique_nonzero_owner_390  1
    service_0_2_1  service_visit_def_899  1
    service_0_2_1  free_load_conservation_900  1
    service_0_2_2  unique_nonzero_owner_391  1
    service_0_2_2  service_visit_def_899  1
    service_0_2_2  free_load_conservation_900  2
    service_0_2_3  unique_nonzero_owner_392  1
    service_0_2_3  service_visit_def_899  1
    service_0_2_3  free_load_conservation_900  3
    service_0_2_4  unique_nonzero_owner_393  1
    service_0_2_4  service_visit_def_899  1
    service_0_2_4  free_load_conservation_900  4
    service_0_2_5  unique_nonzero_owner_394  1
    service_0_2_5  service_visit_def_899  1
    service_0_2_5  free_load_conservation_900  5
    service_0_2_6  unique_nonzero_owner_395  1
    service_0_2_6  service_visit_def_899  1
    service_0_2_6  free_load_conservation_900  6
    service_0_2_7  unique_nonzero_owner_396  1
    service_0_2_7  service_visit_def_899  1
    service_0_2_7  free_load_conservation_900  7
    service_0_2_8  unique_nonzero_owner_397  1
    service_0_2_8  service_visit_def_899  1
    service_0_2_8  free_load_conservation_900  8
    service_0_2_9  unique_nonzero_owner_398  1
    service_0_2_9  service_visit_def_899  1
    service_0_2_9  free_load_conservation_900  9
    service_0_2_10  unique_nonzero_owner_399  1
    service_0_2_10  service_visit_def_899  1
    service_0_2_10  free_load_conservation_900  10
    service_0_2_11  unique_nonzero_owner_400  1
    service_0_2_11  service_visit_def_899  1
    service_0_2_11  free_load_conservation_900  11
    service_0_2_12  unique_nonzero_owner_401  1
    service_0_2_12  service_visit_def_899  1
    service_0_2_12  free_load_conservation_900  12
    service_0_2_13  unique_nonzero_owner_402  1
    service_0_2_13  service_visit_def_899  1
    service_0_2_13  free_load_conservation_900  13
    service_0_2_14  unique_nonzero_owner_403  1
    service_0_2_14  service_visit_def_899  1
    service_0_2_14  free_load_conservation_900  14
    service_0_2_15  unique_nonzero_owner_404  1
    service_0_2_15  service_visit_def_899  1
    service_0_2_15  free_load_conservation_900  15
    service_1_2_1  unique_nonzero_owner_390  1
    service_1_2_1  service_visit_def_1272  1
    service_1_2_1  free_load_conservation_1273  1
    service_1_2_2  unique_nonzero_owner_391  1
    service_1_2_2  service_visit_def_1272  1
    service_1_2_2  free_load_conservation_1273  2
    service_1_2_3  unique_nonzero_owner_392  1
    service_1_2_3  service_visit_def_1272  1
    service_1_2_3  free_load_conservation_1273  3
    service_1_2_4  unique_nonzero_owner_393  1
    service_1_2_4  service_visit_def_1272  1
    service_1_2_4  free_load_conservation_1273  4
    service_1_2_5  unique_nonzero_owner_394  1
    service_1_2_5  service_visit_def_1272  1
    service_1_2_5  free_load_conservation_1273  5
    service_1_2_6  unique_nonzero_owner_395  1
    service_1_2_6  service_visit_def_1272  1
    service_1_2_6  free_load_conservation_1273  6
    service_1_2_7  unique_nonzero_owner_396  1
    service_1_2_7  service_visit_def_1272  1
    service_1_2_7  free_load_conservation_1273  7
    service_1_2_8  unique_nonzero_owner_397  1
    service_1_2_8  service_visit_def_1272  1
    service_1_2_8  free_load_conservation_1273  8
    service_1_2_9  unique_nonzero_owner_398  1
    service_1_2_9  service_visit_def_1272  1
    service_1_2_9  free_load_conservation_1273  9
    service_1_2_10  unique_nonzero_owner_399  1
    service_1_2_10  service_visit_def_1272  1
    service_1_2_10  free_load_conservation_1273  10
    service_1_2_11  unique_nonzero_owner_400  1
    service_1_2_11  service_visit_def_1272  1
    service_1_2_11  free_load_conservation_1273  11
    service_1_2_12  unique_nonzero_owner_401  1
    service_1_2_12  service_visit_def_1272  1
    service_1_2_12  free_load_conservation_1273  12
    service_1_2_13  unique_nonzero_owner_402  1
    service_1_2_13  service_visit_def_1272  1
    service_1_2_13  free_load_conservation_1273  13
    service_1_2_14  unique_nonzero_owner_403  1
    service_1_2_14  service_visit_def_1272  1
    service_1_2_14  free_load_conservation_1273  14
    service_1_2_15  unique_nonzero_owner_404  1
    service_1_2_15  service_visit_def_1272  1
    service_1_2_15  free_load_conservation_1273  15
    service_2_2_1  unique_nonzero_owner_390  1
    service_2_2_1  service_visit_def_1590  1
    service_2_2_1  free_load_conservation_1591  1
    service_2_2_2  unique_nonzero_owner_391  1
    service_2_2_2  service_visit_def_1590  1
    service_2_2_2  free_load_conservation_1591  2
    service_2_2_3  unique_nonzero_owner_392  1
    service_2_2_3  service_visit_def_1590  1
    service_2_2_3  free_load_conservation_1591  3
    service_2_2_4  unique_nonzero_owner_393  1
    service_2_2_4  service_visit_def_1590  1
    service_2_2_4  free_load_conservation_1591  4
    service_2_2_5  unique_nonzero_owner_394  1
    service_2_2_5  service_visit_def_1590  1
    service_2_2_5  free_load_conservation_1591  5
    service_2_2_6  unique_nonzero_owner_395  1
    service_2_2_6  service_visit_def_1590  1
    service_2_2_6  free_load_conservation_1591  6
    service_2_2_7  unique_nonzero_owner_396  1
    service_2_2_7  service_visit_def_1590  1
    service_2_2_7  free_load_conservation_1591  7
    service_2_2_8  unique_nonzero_owner_397  1
    service_2_2_8  service_visit_def_1590  1
    service_2_2_8  free_load_conservation_1591  8
    service_2_2_9  unique_nonzero_owner_398  1
    service_2_2_9  service_visit_def_1590  1
    service_2_2_9  free_load_conservation_1591  9
    service_2_2_10  unique_nonzero_owner_399  1
    service_2_2_10  service_visit_def_1590  1
    service_2_2_10  free_load_conservation_1591  10
    service_2_2_11  unique_nonzero_owner_400  1
    service_2_2_11  service_visit_def_1590  1
    service_2_2_11  free_load_conservation_1591  11
    service_2_2_12  unique_nonzero_owner_401  1
    service_2_2_12  service_visit_def_1590  1
    service_2_2_12  free_load_conservation_1591  12
    service_2_2_13  unique_nonzero_owner_402  1
    service_2_2_13  service_visit_def_1590  1
    service_2_2_13  free_load_conservation_1591  13
    service_2_2_14  unique_nonzero_owner_403  1
    service_2_2_14  service_visit_def_1590  1
    service_2_2_14  free_load_conservation_1591  14
    service_2_2_15  unique_nonzero_owner_404  1
    service_2_2_15  service_visit_def_1590  1
    service_2_2_15  free_load_conservation_1591  15
    service_0_7_0  unique_nonzero_owner_405  1
    service_0_7_0  service_visit_def_905  1
    service_0_7_0  free_load_conservation_906  -12
    service_0_7_0  original_T_including_depot_unload_912  1440
    service_0_7_1  unique_nonzero_owner_406  1
    service_0_7_1  service_visit_def_905  1
    service_0_7_1  free_load_conservation_906  -11
    service_0_7_1  original_T_including_depot_unload_912  1320
    service_0_7_2  unique_nonzero_owner_407  1
    service_0_7_2  service_visit_def_905  1
    service_0_7_2  free_load_conservation_906  -10
    service_0_7_2  original_T_including_depot_unload_912  1200
    service_0_7_3  unique_nonzero_owner_408  1
    service_0_7_3  service_visit_def_905  1
    service_0_7_3  free_load_conservation_906  -9
    service_0_7_3  original_T_including_depot_unload_912  1080
    service_0_7_4  unique_nonzero_owner_409  1
    service_0_7_4  service_visit_def_905  1
    service_0_7_4  free_load_conservation_906  -8
    service_0_7_4  original_T_including_depot_unload_912  960
    service_0_7_5  unique_nonzero_owner_410  1
    service_0_7_5  service_visit_def_905  1
    service_0_7_5  free_load_conservation_906  -7
    service_0_7_5  original_T_including_depot_unload_912  840
    service_0_7_6  unique_nonzero_owner_411  1
    service_0_7_6  service_visit_def_905  1
    service_0_7_6  free_load_conservation_906  -6
    service_0_7_6  original_T_including_depot_unload_912  720
    service_0_7_7  unique_nonzero_owner_412  1
    service_0_7_7  service_visit_def_905  1
    service_0_7_7  free_load_conservation_906  -5
    service_0_7_7  original_T_including_depot_unload_912  600
    service_0_7_8  unique_nonzero_owner_413  1
    service_0_7_8  service_visit_def_905  1
    service_0_7_8  free_load_conservation_906  -4
    service_0_7_8  original_T_including_depot_unload_912  480
    service_0_7_9  unique_nonzero_owner_414  1
    service_0_7_9  service_visit_def_905  1
    service_0_7_9  free_load_conservation_906  -3
    service_0_7_9  original_T_including_depot_unload_912  360
    service_0_7_10  unique_nonzero_owner_415  1
    service_0_7_10  service_visit_def_905  1
    service_0_7_10  free_load_conservation_906  -2
    service_0_7_10  original_T_including_depot_unload_912  240
    service_0_7_11  unique_nonzero_owner_416  1
    service_0_7_11  service_visit_def_905  1
    service_0_7_11  free_load_conservation_906  -1
    service_0_7_11  original_T_including_depot_unload_912  120
    service_0_7_13  unique_nonzero_owner_417  1
    service_0_7_13  service_visit_def_905  1
    service_0_7_13  free_load_conservation_906  1
    service_0_7_14  unique_nonzero_owner_418  1
    service_0_7_14  service_visit_def_905  1
    service_0_7_14  free_load_conservation_906  2
    service_0_7_15  unique_nonzero_owner_419  1
    service_0_7_15  service_visit_def_905  1
    service_0_7_15  free_load_conservation_906  3
    service_0_7_16  unique_nonzero_owner_420  1
    service_0_7_16  service_visit_def_905  1
    service_0_7_16  free_load_conservation_906  4
    service_0_7_17  unique_nonzero_owner_421  1
    service_0_7_17  service_visit_def_905  1
    service_0_7_17  free_load_conservation_906  5
    service_1_7_0  unique_nonzero_owner_405  1
    service_1_7_0  service_visit_def_1278  1
    service_1_7_0  free_load_conservation_1279  -12
    service_1_7_0  original_T_including_depot_unload_1283  1440
    service_1_7_1  unique_nonzero_owner_406  1
    service_1_7_1  service_visit_def_1278  1
    service_1_7_1  free_load_conservation_1279  -11
    service_1_7_1  original_T_including_depot_unload_1283  1320
    service_1_7_2  unique_nonzero_owner_407  1
    service_1_7_2  service_visit_def_1278  1
    service_1_7_2  free_load_conservation_1279  -10
    service_1_7_2  original_T_including_depot_unload_1283  1200
    service_1_7_3  unique_nonzero_owner_408  1
    service_1_7_3  service_visit_def_1278  1
    service_1_7_3  free_load_conservation_1279  -9
    service_1_7_3  original_T_including_depot_unload_1283  1080
    service_1_7_4  unique_nonzero_owner_409  1
    service_1_7_4  service_visit_def_1278  1
    service_1_7_4  free_load_conservation_1279  -8
    service_1_7_4  original_T_including_depot_unload_1283  960
    service_1_7_5  unique_nonzero_owner_410  1
    service_1_7_5  service_visit_def_1278  1
    service_1_7_5  free_load_conservation_1279  -7
    service_1_7_5  original_T_including_depot_unload_1283  840
    service_1_7_6  unique_nonzero_owner_411  1
    service_1_7_6  service_visit_def_1278  1
    service_1_7_6  free_load_conservation_1279  -6
    service_1_7_6  original_T_including_depot_unload_1283  720
    service_1_7_7  unique_nonzero_owner_412  1
    service_1_7_7  service_visit_def_1278  1
    service_1_7_7  free_load_conservation_1279  -5
    service_1_7_7  original_T_including_depot_unload_1283  600
    service_1_7_8  unique_nonzero_owner_413  1
    service_1_7_8  service_visit_def_1278  1
    service_1_7_8  free_load_conservation_1279  -4
    service_1_7_8  original_T_including_depot_unload_1283  480
    service_1_7_9  unique_nonzero_owner_414  1
    service_1_7_9  service_visit_def_1278  1
    service_1_7_9  free_load_conservation_1279  -3
    service_1_7_9  original_T_including_depot_unload_1283  360
    service_1_7_10  unique_nonzero_owner_415  1
    service_1_7_10  service_visit_def_1278  1
    service_1_7_10  free_load_conservation_1279  -2
    service_1_7_10  original_T_including_depot_unload_1283  240
    service_1_7_11  unique_nonzero_owner_416  1
    service_1_7_11  service_visit_def_1278  1
    service_1_7_11  free_load_conservation_1279  -1
    service_1_7_11  original_T_including_depot_unload_1283  120
    service_1_7_13  unique_nonzero_owner_417  1
    service_1_7_13  service_visit_def_1278  1
    service_1_7_13  free_load_conservation_1279  1
    service_1_7_14  unique_nonzero_owner_418  1
    service_1_7_14  service_visit_def_1278  1
    service_1_7_14  free_load_conservation_1279  2
    service_1_7_15  unique_nonzero_owner_419  1
    service_1_7_15  service_visit_def_1278  1
    service_1_7_15  free_load_conservation_1279  3
    service_1_7_16  unique_nonzero_owner_420  1
    service_1_7_16  service_visit_def_1278  1
    service_1_7_16  free_load_conservation_1279  4
    service_1_7_17  unique_nonzero_owner_421  1
    service_1_7_17  service_visit_def_1278  1
    service_1_7_17  free_load_conservation_1279  5
    service_2_7_0  unique_nonzero_owner_405  1
    service_2_7_0  service_visit_def_1596  1
    service_2_7_0  free_load_conservation_1597  -12
    service_2_7_0  original_T_including_depot_unload_1600  1440
    service_2_7_1  unique_nonzero_owner_406  1
    service_2_7_1  service_visit_def_1596  1
    service_2_7_1  free_load_conservation_1597  -11
    service_2_7_1  original_T_including_depot_unload_1600  1320
    service_2_7_2  unique_nonzero_owner_407  1
    service_2_7_2  service_visit_def_1596  1
    service_2_7_2  free_load_conservation_1597  -10
    service_2_7_2  original_T_including_depot_unload_1600  1200
    service_2_7_3  unique_nonzero_owner_408  1
    service_2_7_3  service_visit_def_1596  1
    service_2_7_3  free_load_conservation_1597  -9
    service_2_7_3  original_T_including_depot_unload_1600  1080
    service_2_7_4  unique_nonzero_owner_409  1
    service_2_7_4  service_visit_def_1596  1
    service_2_7_4  free_load_conservation_1597  -8
    service_2_7_4  original_T_including_depot_unload_1600  960
    service_2_7_5  unique_nonzero_owner_410  1
    service_2_7_5  service_visit_def_1596  1
    service_2_7_5  free_load_conservation_1597  -7
    service_2_7_5  original_T_including_depot_unload_1600  840
    service_2_7_6  unique_nonzero_owner_411  1
    service_2_7_6  service_visit_def_1596  1
    service_2_7_6  free_load_conservation_1597  -6
    service_2_7_6  original_T_including_depot_unload_1600  720
    service_2_7_7  unique_nonzero_owner_412  1
    service_2_7_7  service_visit_def_1596  1
    service_2_7_7  free_load_conservation_1597  -5
    service_2_7_7  original_T_including_depot_unload_1600  600
    service_2_7_8  unique_nonzero_owner_413  1
    service_2_7_8  service_visit_def_1596  1
    service_2_7_8  free_load_conservation_1597  -4
    service_2_7_8  original_T_including_depot_unload_1600  480
    service_2_7_9  unique_nonzero_owner_414  1
    service_2_7_9  service_visit_def_1596  1
    service_2_7_9  free_load_conservation_1597  -3
    service_2_7_9  original_T_including_depot_unload_1600  360
    service_2_7_10  unique_nonzero_owner_415  1
    service_2_7_10  service_visit_def_1596  1
    service_2_7_10  free_load_conservation_1597  -2
    service_2_7_10  original_T_including_depot_unload_1600  240
    service_2_7_11  unique_nonzero_owner_416  1
    service_2_7_11  service_visit_def_1596  1
    service_2_7_11  free_load_conservation_1597  -1
    service_2_7_11  original_T_including_depot_unload_1600  120
    service_2_7_13  unique_nonzero_owner_417  1
    service_2_7_13  service_visit_def_1596  1
    service_2_7_13  free_load_conservation_1597  1
    service_2_7_14  unique_nonzero_owner_418  1
    service_2_7_14  service_visit_def_1596  1
    service_2_7_14  free_load_conservation_1597  2
    service_2_7_15  unique_nonzero_owner_419  1
    service_2_7_15  service_visit_def_1596  1
    service_2_7_15  free_load_conservation_1597  3
    service_2_7_16  unique_nonzero_owner_420  1
    service_2_7_16  service_visit_def_1596  1
    service_2_7_16  free_load_conservation_1597  4
    service_2_7_17  unique_nonzero_owner_421  1
    service_2_7_17  service_visit_def_1596  1
    service_2_7_17  free_load_conservation_1597  5
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_817  -1
    visit_0_1  in_degree_818  -1
    visit_0_1  order_active_lb_819  -1
    visit_0_1  order_active_ub_820  -14
    order_0_1  connected_order_arc_439  -1
    order_0_1  connected_order_arc_441  -1
    order_0_1  connected_order_arc_443  -1
    order_0_1  connected_order_arc_445  -1
    order_0_1  connected_order_arc_447  -1
    order_0_1  connected_order_arc_449  -1
    order_0_1  connected_order_arc_451  -1
    order_0_1  connected_order_arc_453  -1
    order_0_1  connected_order_arc_455  -1
    order_0_1  connected_order_arc_457  -1
    order_0_1  connected_order_arc_459  -1
    order_0_1  connected_order_arc_461  -1
    order_0_1  connected_order_arc_463  -1
    order_0_1  connected_order_arc_466  1
    order_0_1  connected_order_arc_493  1
    order_0_1  connected_order_arc_520  1
    order_0_1  connected_order_arc_547  1
    order_0_1  connected_order_arc_574  1
    order_0_1  connected_order_arc_601  1
    order_0_1  connected_order_arc_628  1
    order_0_1  connected_order_arc_655  1
    order_0_1  connected_order_arc_682  1
    order_0_1  connected_order_arc_709  1
    order_0_1  connected_order_arc_736  1
    order_0_1  connected_order_arc_763  1
    order_0_1  connected_order_arc_790  1
    order_0_1  order_active_lb_819  1
    order_0_1  order_active_ub_820  1
    order_0_1  fixed_segment_relative_order_907  -1
    visit_0_2  out_degree_824  -1
    visit_0_2  in_degree_825  -1
    visit_0_2  order_active_lb_826  -1
    visit_0_2  order_active_ub_827  -14
    order_0_2  connected_order_arc_439  1
    order_0_2  connected_order_arc_466  -1
    order_0_2  connected_order_arc_468  -1
    order_0_2  connected_order_arc_470  -1
    order_0_2  connected_order_arc_472  -1
    order_0_2  connected_order_arc_474  -1
    order_0_2  connected_order_arc_476  -1
    order_0_2  connected_order_arc_478  -1
    order_0_2  connected_order_arc_480  -1
    order_0_2  connected_order_arc_482  -1
    order_0_2  connected_order_arc_484  -1
    order_0_2  connected_order_arc_486  -1
    order_0_2  connected_order_arc_488  -1
    order_0_2  connected_order_arc_490  -1
    order_0_2  connected_order_arc_495  1
    order_0_2  connected_order_arc_522  1
    order_0_2  connected_order_arc_549  1
    order_0_2  connected_order_arc_576  1
    order_0_2  connected_order_arc_603  1
    order_0_2  connected_order_arc_630  1
    order_0_2  connected_order_arc_657  1
    order_0_2  connected_order_arc_684  1
    order_0_2  connected_order_arc_711  1
    order_0_2  connected_order_arc_738  1
    order_0_2  connected_order_arc_765  1
    order_0_2  connected_order_arc_792  1
    order_0_2  order_active_lb_826  1
    order_0_2  order_active_ub_827  1
    order_0_2  fixed_segment_relative_order_907  1
    order_0_2  fixed_segment_relative_order_908  -1
    visit_0_3  out_degree_831  -1
    visit_0_3  in_degree_832  -1
    visit_0_3  order_active_lb_833  -1
    visit_0_3  order_active_ub_834  -14
    order_0_3  connected_order_arc_441  1
    order_0_3  connected_order_arc_468  1
    order_0_3  connected_order_arc_493  -1
    order_0_3  connected_order_arc_495  -1
    order_0_3  connected_order_arc_497  -1
    order_0_3  connected_order_arc_499  -1
    order_0_3  connected_order_arc_501  -1
    order_0_3  connected_order_arc_503  -1
    order_0_3  connected_order_arc_505  -1
    order_0_3  connected_order_arc_507  -1
    order_0_3  connected_order_arc_509  -1
    order_0_3  connected_order_arc_511  -1
    order_0_3  connected_order_arc_513  -1
    order_0_3  connected_order_arc_515  -1
    order_0_3  connected_order_arc_517  -1
    order_0_3  connected_order_arc_524  1
    order_0_3  connected_order_arc_551  1
    order_0_3  connected_order_arc_578  1
    order_0_3  connected_order_arc_605  1
    order_0_3  connected_order_arc_632  1
    order_0_3  connected_order_arc_659  1
    order_0_3  connected_order_arc_686  1
    order_0_3  connected_order_arc_713  1
    order_0_3  connected_order_arc_740  1
    order_0_3  connected_order_arc_767  1
    order_0_3  connected_order_arc_794  1
    order_0_3  order_active_lb_833  1
    order_0_3  order_active_ub_834  1
    order_0_3  fixed_segment_relative_order_908  1
    order_0_3  fixed_segment_relative_order_909  -1
    visit_0_4  out_degree_838  -1
    visit_0_4  in_degree_839  -1
    visit_0_4  order_active_lb_840  -1
    visit_0_4  order_active_ub_841  -14
    order_0_4  connected_order_arc_443  1
    order_0_4  connected_order_arc_470  1
    order_0_4  connected_order_arc_497  1
    order_0_4  connected_order_arc_520  -1
    order_0_4  connected_order_arc_522  -1
    order_0_4  connected_order_arc_524  -1
    order_0_4  connected_order_arc_526  -1
    order_0_4  connected_order_arc_528  -1
    order_0_4  connected_order_arc_530  -1
    order_0_4  connected_order_arc_532  -1
    order_0_4  connected_order_arc_534  -1
    order_0_4  connected_order_arc_536  -1
    order_0_4  connected_order_arc_538  -1
    order_0_4  connected_order_arc_540  -1
    order_0_4  connected_order_arc_542  -1
    order_0_4  connected_order_arc_544  -1
    order_0_4  connected_order_arc_553  1
    order_0_4  connected_order_arc_580  1
    order_0_4  connected_order_arc_607  1
    order_0_4  connected_order_arc_634  1
    order_0_4  connected_order_arc_661  1
    order_0_4  connected_order_arc_688  1
    order_0_4  connected_order_arc_715  1
    order_0_4  connected_order_arc_742  1
    order_0_4  connected_order_arc_769  1
    order_0_4  connected_order_arc_796  1
    order_0_4  order_active_lb_840  1
    order_0_4  order_active_ub_841  1
    order_0_4  fixed_segment_relative_order_909  1
    order_0_4  fixed_segment_relative_order_910  -1
    visit_0_5  out_degree_845  -1
    visit_0_5  in_degree_846  -1
    visit_0_5  order_active_lb_847  -1
    visit_0_5  order_active_ub_848  -14
    order_0_5  connected_order_arc_445  1
    order_0_5  connected_order_arc_472  1
    order_0_5  connected_order_arc_499  1
    order_0_5  connected_order_arc_526  1
    order_0_5  connected_order_arc_547  -1
    order_0_5  connected_order_arc_549  -1
    order_0_5  connected_order_arc_551  -1
    order_0_5  connected_order_arc_553  -1
    order_0_5  connected_order_arc_555  -1
    order_0_5  connected_order_arc_557  -1
    order_0_5  connected_order_arc_559  -1
    order_0_5  connected_order_arc_561  -1
    order_0_5  connected_order_arc_563  -1
    order_0_5  connected_order_arc_565  -1
    order_0_5  connected_order_arc_567  -1
    order_0_5  connected_order_arc_569  -1
    order_0_5  connected_order_arc_571  -1
    order_0_5  connected_order_arc_582  1
    order_0_5  connected_order_arc_609  1
    order_0_5  connected_order_arc_636  1
    order_0_5  connected_order_arc_663  1
    order_0_5  connected_order_arc_690  1
    order_0_5  connected_order_arc_717  1
    order_0_5  connected_order_arc_744  1
    order_0_5  connected_order_arc_771  1
    order_0_5  connected_order_arc_798  1
    order_0_5  order_active_lb_847  1
    order_0_5  order_active_ub_848  1
    order_0_5  fixed_segment_relative_order_910  1
    order_0_5  fixed_segment_relative_order_911  -1
    visit_0_6  out_degree_852  -1
    visit_0_6  in_degree_853  -1
    visit_0_6  order_active_lb_854  -1
    visit_0_6  order_active_ub_855  -14
    order_0_6  connected_order_arc_447  1
    order_0_6  connected_order_arc_474  1
    order_0_6  connected_order_arc_501  1
    order_0_6  connected_order_arc_528  1
    order_0_6  connected_order_arc_555  1
    order_0_6  connected_order_arc_574  -1
    order_0_6  connected_order_arc_576  -1
    order_0_6  connected_order_arc_578  -1
    order_0_6  connected_order_arc_580  -1
    order_0_6  connected_order_arc_582  -1
    order_0_6  connected_order_arc_584  -1
    order_0_6  connected_order_arc_586  -1
    order_0_6  connected_order_arc_588  -1
    order_0_6  connected_order_arc_590  -1
    order_0_6  connected_order_arc_592  -1
    order_0_6  connected_order_arc_594  -1
    order_0_6  connected_order_arc_596  -1
    order_0_6  connected_order_arc_598  -1
    order_0_6  connected_order_arc_611  1
    order_0_6  connected_order_arc_638  1
    order_0_6  connected_order_arc_665  1
    order_0_6  connected_order_arc_692  1
    order_0_6  connected_order_arc_719  1
    order_0_6  connected_order_arc_746  1
    order_0_6  connected_order_arc_773  1
    order_0_6  connected_order_arc_800  1
    order_0_6  order_active_lb_854  1
    order_0_6  order_active_ub_855  1
    order_0_6  fixed_segment_relative_order_911  1
    visit_0_14  out_degree_859  -1
    visit_0_14  in_degree_860  -1
    visit_0_14  order_active_lb_861  -1
    visit_0_14  order_active_ub_862  -14
    visit_0_14  service_visit_def_863  -1
    order_0_14  connected_order_arc_449  1
    order_0_14  connected_order_arc_476  1
    order_0_14  connected_order_arc_503  1
    order_0_14  connected_order_arc_530  1
    order_0_14  connected_order_arc_557  1
    order_0_14  connected_order_arc_584  1
    order_0_14  connected_order_arc_601  -1
    order_0_14  connected_order_arc_603  -1
    order_0_14  connected_order_arc_605  -1
    order_0_14  connected_order_arc_607  -1
    order_0_14  connected_order_arc_609  -1
    order_0_14  connected_order_arc_611  -1
    order_0_14  connected_order_arc_613  -1
    order_0_14  connected_order_arc_615  -1
    order_0_14  connected_order_arc_617  -1
    order_0_14  connected_order_arc_619  -1
    order_0_14  connected_order_arc_621  -1
    order_0_14  connected_order_arc_623  -1
    order_0_14  connected_order_arc_625  -1
    order_0_14  connected_order_arc_640  1
    order_0_14  connected_order_arc_667  1
    order_0_14  connected_order_arc_694  1
    order_0_14  connected_order_arc_721  1
    order_0_14  connected_order_arc_748  1
    order_0_14  connected_order_arc_775  1
    order_0_14  connected_order_arc_802  1
    order_0_14  order_active_lb_861  1
    order_0_14  order_active_ub_862  1
    visit_0_15  out_degree_865  -1
    visit_0_15  in_degree_866  -1
    visit_0_15  order_active_lb_867  -1
    visit_0_15  order_active_ub_868  -14
    visit_0_15  service_visit_def_869  -1
    order_0_15  connected_order_arc_451  1
    order_0_15  connected_order_arc_478  1
    order_0_15  connected_order_arc_505  1
    order_0_15  connected_order_arc_532  1
    order_0_15  connected_order_arc_559  1
    order_0_15  connected_order_arc_586  1
    order_0_15  connected_order_arc_613  1
    order_0_15  connected_order_arc_628  -1
    order_0_15  connected_order_arc_630  -1
    order_0_15  connected_order_arc_632  -1
    order_0_15  connected_order_arc_634  -1
    order_0_15  connected_order_arc_636  -1
    order_0_15  connected_order_arc_638  -1
    order_0_15  connected_order_arc_640  -1
    order_0_15  connected_order_arc_642  -1
    order_0_15  connected_order_arc_644  -1
    order_0_15  connected_order_arc_646  -1
    order_0_15  connected_order_arc_648  -1
    order_0_15  connected_order_arc_650  -1
    order_0_15  connected_order_arc_652  -1
    order_0_15  connected_order_arc_669  1
    order_0_15  connected_order_arc_696  1
    order_0_15  connected_order_arc_723  1
    order_0_15  connected_order_arc_750  1
    order_0_15  connected_order_arc_777  1
    order_0_15  connected_order_arc_804  1
    order_0_15  order_active_lb_867  1
    order_0_15  order_active_ub_868  1
    visit_0_16  out_degree_871  -1
    visit_0_16  in_degree_872  -1
    visit_0_16  order_active_lb_873  -1
    visit_0_16  order_active_ub_874  -14
    visit_0_16  service_visit_def_875  -1
    order_0_16  connected_order_arc_453  1
    order_0_16  connected_order_arc_480  1
    order_0_16  connected_order_arc_507  1
    order_0_16  connected_order_arc_534  1
    order_0_16  connected_order_arc_561  1
    order_0_16  connected_order_arc_588  1
    order_0_16  connected_order_arc_615  1
    order_0_16  connected_order_arc_642  1
    order_0_16  connected_order_arc_655  -1
    order_0_16  connected_order_arc_657  -1
    order_0_16  connected_order_arc_659  -1
    order_0_16  connected_order_arc_661  -1
    order_0_16  connected_order_arc_663  -1
    order_0_16  connected_order_arc_665  -1
    order_0_16  connected_order_arc_667  -1
    order_0_16  connected_order_arc_669  -1
    order_0_16  connected_order_arc_671  -1
    order_0_16  connected_order_arc_673  -1
    order_0_16  connected_order_arc_675  -1
    order_0_16  connected_order_arc_677  -1
    order_0_16  connected_order_arc_679  -1
    order_0_16  connected_order_arc_698  1
    order_0_16  connected_order_arc_725  1
    order_0_16  connected_order_arc_752  1
    order_0_16  connected_order_arc_779  1
    order_0_16  connected_order_arc_806  1
    order_0_16  order_active_lb_873  1
    order_0_16  order_active_ub_874  1
    visit_0_17  out_degree_877  -1
    visit_0_17  in_degree_878  -1
    visit_0_17  order_active_lb_879  -1
    visit_0_17  order_active_ub_880  -14
    visit_0_17  service_visit_def_881  -1
    order_0_17  connected_order_arc_455  1
    order_0_17  connected_order_arc_482  1
    order_0_17  connected_order_arc_509  1
    order_0_17  connected_order_arc_536  1
    order_0_17  connected_order_arc_563  1
    order_0_17  connected_order_arc_590  1
    order_0_17  connected_order_arc_617  1
    order_0_17  connected_order_arc_644  1
    order_0_17  connected_order_arc_671  1
    order_0_17  connected_order_arc_682  -1
    order_0_17  connected_order_arc_684  -1
    order_0_17  connected_order_arc_686  -1
    order_0_17  connected_order_arc_688  -1
    order_0_17  connected_order_arc_690  -1
    order_0_17  connected_order_arc_692  -1
    order_0_17  connected_order_arc_694  -1
    order_0_17  connected_order_arc_696  -1
    order_0_17  connected_order_arc_698  -1
    order_0_17  connected_order_arc_700  -1
    order_0_17  connected_order_arc_702  -1
    order_0_17  connected_order_arc_704  -1
    order_0_17  connected_order_arc_706  -1
    order_0_17  connected_order_arc_727  1
    order_0_17  connected_order_arc_754  1
    order_0_17  connected_order_arc_781  1
    order_0_17  connected_order_arc_808  1
    order_0_17  order_active_lb_879  1
    order_0_17  order_active_ub_880  1
    visit_0_18  out_degree_883  -1
    visit_0_18  in_degree_884  -1
    visit_0_18  order_active_lb_885  -1
    visit_0_18  order_active_ub_886  -14
    visit_0_18  service_visit_def_887  -1
    order_0_18  connected_order_arc_457  1
    order_0_18  connected_order_arc_484  1
    order_0_18  connected_order_arc_511  1
    order_0_18  connected_order_arc_538  1
    order_0_18  connected_order_arc_565  1
    order_0_18  connected_order_arc_592  1
    order_0_18  connected_order_arc_619  1
    order_0_18  connected_order_arc_646  1
    order_0_18  connected_order_arc_673  1
    order_0_18  connected_order_arc_700  1
    order_0_18  connected_order_arc_709  -1
    order_0_18  connected_order_arc_711  -1
    order_0_18  connected_order_arc_713  -1
    order_0_18  connected_order_arc_715  -1
    order_0_18  connected_order_arc_717  -1
    order_0_18  connected_order_arc_719  -1
    order_0_18  connected_order_arc_721  -1
    order_0_18  connected_order_arc_723  -1
    order_0_18  connected_order_arc_725  -1
    order_0_18  connected_order_arc_727  -1
    order_0_18  connected_order_arc_729  -1
    order_0_18  connected_order_arc_731  -1
    order_0_18  connected_order_arc_733  -1
    order_0_18  connected_order_arc_756  1
    order_0_18  connected_order_arc_783  1
    order_0_18  connected_order_arc_810  1
    order_0_18  order_active_lb_885  1
    order_0_18  order_active_ub_886  1
    visit_0_19  out_degree_889  -1
    visit_0_19  in_degree_890  -1
    visit_0_19  order_active_lb_891  -1
    visit_0_19  order_active_ub_892  -14
    visit_0_19  service_visit_def_893  -1
    order_0_19  connected_order_arc_459  1
    order_0_19  connected_order_arc_486  1
    order_0_19  connected_order_arc_513  1
    order_0_19  connected_order_arc_540  1
    order_0_19  connected_order_arc_567  1
    order_0_19  connected_order_arc_594  1
    order_0_19  connected_order_arc_621  1
    order_0_19  connected_order_arc_648  1
    order_0_19  connected_order_arc_675  1
    order_0_19  connected_order_arc_702  1
    order_0_19  connected_order_arc_729  1
    order_0_19  connected_order_arc_736  -1
    order_0_19  connected_order_arc_738  -1
    order_0_19  connected_order_arc_740  -1
    order_0_19  connected_order_arc_742  -1
    order_0_19  connected_order_arc_744  -1
    order_0_19  connected_order_arc_746  -1
    order_0_19  connected_order_arc_748  -1
    order_0_19  connected_order_arc_750  -1
    order_0_19  connected_order_arc_752  -1
    order_0_19  connected_order_arc_754  -1
    order_0_19  connected_order_arc_756  -1
    order_0_19  connected_order_arc_758  -1
    order_0_19  connected_order_arc_760  -1
    order_0_19  connected_order_arc_785  1
    order_0_19  connected_order_arc_812  1
    order_0_19  order_active_lb_891  1
    order_0_19  order_active_ub_892  1
    visit_0_20  out_degree_895  -1
    visit_0_20  in_degree_896  -1
    visit_0_20  order_active_lb_897  -1
    visit_0_20  order_active_ub_898  -14
    visit_0_20  service_visit_def_899  -1
    order_0_20  connected_order_arc_461  1
    order_0_20  connected_order_arc_488  1
    order_0_20  connected_order_arc_515  1
    order_0_20  connected_order_arc_542  1
    order_0_20  connected_order_arc_569  1
    order_0_20  connected_order_arc_596  1
    order_0_20  connected_order_arc_623  1
    order_0_20  connected_order_arc_650  1
    order_0_20  connected_order_arc_677  1
    order_0_20  connected_order_arc_704  1
    order_0_20  connected_order_arc_731  1
    order_0_20  connected_order_arc_758  1
    order_0_20  connected_order_arc_763  -1
    order_0_20  connected_order_arc_765  -1
    order_0_20  connected_order_arc_767  -1
    order_0_20  connected_order_arc_769  -1
    order_0_20  connected_order_arc_771  -1
    order_0_20  connected_order_arc_773  -1
    order_0_20  connected_order_arc_775  -1
    order_0_20  connected_order_arc_777  -1
    order_0_20  connected_order_arc_779  -1
    order_0_20  connected_order_arc_781  -1
    order_0_20  connected_order_arc_783  -1
    order_0_20  connected_order_arc_785  -1
    order_0_20  connected_order_arc_787  -1
    order_0_20  connected_order_arc_814  1
    order_0_20  order_active_lb_897  1
    order_0_20  order_active_ub_898  1
    visit_0_21  out_degree_901  -1
    visit_0_21  in_degree_902  -1
    visit_0_21  order_active_lb_903  -1
    visit_0_21  order_active_ub_904  -14
    visit_0_21  service_visit_def_905  -1
    order_0_21  connected_order_arc_463  1
    order_0_21  connected_order_arc_490  1
    order_0_21  connected_order_arc_517  1
    order_0_21  connected_order_arc_544  1
    order_0_21  connected_order_arc_571  1
    order_0_21  connected_order_arc_598  1
    order_0_21  connected_order_arc_625  1
    order_0_21  connected_order_arc_652  1
    order_0_21  connected_order_arc_679  1
    order_0_21  connected_order_arc_706  1
    order_0_21  connected_order_arc_733  1
    order_0_21  connected_order_arc_760  1
    order_0_21  connected_order_arc_787  1
    order_0_21  connected_order_arc_790  -1
    order_0_21  connected_order_arc_792  -1
    order_0_21  connected_order_arc_794  -1
    order_0_21  connected_order_arc_796  -1
    order_0_21  connected_order_arc_798  -1
    order_0_21  connected_order_arc_800  -1
    order_0_21  connected_order_arc_802  -1
    order_0_21  connected_order_arc_804  -1
    order_0_21  connected_order_arc_806  -1
    order_0_21  connected_order_arc_808  -1
    order_0_21  connected_order_arc_810  -1
    order_0_21  connected_order_arc_812  -1
    order_0_21  connected_order_arc_814  -1
    order_0_21  order_active_lb_903  1
    order_0_21  order_active_ub_904  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_422  -20
    arc_0_0_0  depot_departure_or_bypass_815  1
    arc_0_0_0  depot_return_or_bypass_816  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_422  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_423  -20
    arc_0_0_1  depot_departure_or_bypass_815  1
    arc_0_0_1  in_degree_818  1
    arc_0_0_1  original_T_including_depot_unload_912  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_423  1
    load_0_0_1  segment_load_conservation_821  -1
    load_0_0_1  segment_prefix_lb_822  1
    load_0_0_1  segment_prefix_ub_823  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_424  -20
    arc_0_0_2  depot_departure_or_bypass_815  1
    arc_0_0_2  in_degree_825  1
    arc_0_0_2  original_T_including_depot_unload_912  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_424  1
    load_0_0_2  segment_load_conservation_828  -1
    load_0_0_2  segment_prefix_lb_829  1
    load_0_0_2  segment_prefix_ub_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_425  -20
    arc_0_0_3  depot_departure_or_bypass_815  1
    arc_0_0_3  in_degree_832  1
    arc_0_0_3  original_T_including_depot_unload_912  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_425  1
    load_0_0_3  segment_load_conservation_835  -1
    load_0_0_3  segment_prefix_lb_836  1
    load_0_0_3  segment_prefix_ub_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_426  -20
    arc_0_0_4  depot_departure_or_bypass_815  1
    arc_0_0_4  in_degree_839  1
    arc_0_0_4  original_T_including_depot_unload_912  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_426  1
    load_0_0_4  segment_load_conservation_842  -1
    load_0_0_4  segment_prefix_lb_843  1
    load_0_0_4  segment_prefix_ub_844  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_427  -20
    arc_0_0_5  depot_departure_or_bypass_815  1
    arc_0_0_5  in_degree_846  1
    arc_0_0_5  original_T_including_depot_unload_912  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_427  1
    load_0_0_5  segment_load_conservation_849  -1
    load_0_0_5  segment_prefix_lb_850  1
    load_0_0_5  segment_prefix_ub_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_428  -20
    arc_0_0_6  depot_departure_or_bypass_815  1
    arc_0_0_6  in_degree_853  1
    arc_0_0_6  original_T_including_depot_unload_912  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_428  1
    load_0_0_6  segment_load_conservation_856  -1
    load_0_0_6  segment_prefix_lb_857  1
    load_0_0_6  segment_prefix_ub_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_429  -20
    arc_0_0_14  depot_departure_or_bypass_815  1
    arc_0_0_14  in_degree_860  1
    arc_0_0_14  original_T_including_depot_unload_912  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_429  1
    load_0_0_14  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_430  -20
    arc_0_0_15  depot_departure_or_bypass_815  1
    arc_0_0_15  in_degree_866  1
    arc_0_0_15  original_T_including_depot_unload_912  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_430  1
    load_0_0_15  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_431  -20
    arc_0_0_16  depot_departure_or_bypass_815  1
    arc_0_0_16  in_degree_872  1
    arc_0_0_16  original_T_including_depot_unload_912  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_431  1
    load_0_0_16  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_432  -20
    arc_0_0_17  depot_departure_or_bypass_815  1
    arc_0_0_17  in_degree_878  1
    arc_0_0_17  original_T_including_depot_unload_912  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_432  1
    load_0_0_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_433  -20
    arc_0_0_18  depot_departure_or_bypass_815  1
    arc_0_0_18  in_degree_884  1
    arc_0_0_18  original_T_including_depot_unload_912  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_433  1
    load_0_0_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_434  -20
    arc_0_0_19  depot_departure_or_bypass_815  1
    arc_0_0_19  in_degree_890  1
    arc_0_0_19  original_T_including_depot_unload_912  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_434  1
    load_0_0_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_435  -20
    arc_0_0_20  depot_departure_or_bypass_815  1
    arc_0_0_20  in_degree_896  1
    arc_0_0_20  original_T_including_depot_unload_912  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_435  1
    load_0_0_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_436  -20
    arc_0_0_21  depot_departure_or_bypass_815  1
    arc_0_0_21  in_degree_902  1
    arc_0_0_21  original_T_including_depot_unload_912  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_436  1
    load_0_0_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_437  -20
    arc_0_1_0  depot_return_or_bypass_816  1
    arc_0_1_0  out_degree_817  1
    arc_0_1_0  original_T_including_depot_unload_912  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_437  1
    load_0_1_0  segment_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_438  -20
    arc_0_1_2  connected_order_arc_439  -15
    arc_0_1_2  out_degree_817  1
    arc_0_1_2  in_degree_825  1
    arc_0_1_2  original_T_including_depot_unload_912  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_438  1
    load_0_1_2  segment_load_conservation_821  1
    load_0_1_2  segment_load_conservation_828  -1
    load_0_1_2  segment_prefix_lb_829  1
    load_0_1_2  segment_prefix_ub_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_440  -20
    arc_0_1_3  connected_order_arc_441  -15
    arc_0_1_3  out_degree_817  1
    arc_0_1_3  in_degree_832  1
    arc_0_1_3  original_T_including_depot_unload_912  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_440  1
    load_0_1_3  segment_load_conservation_821  1
    load_0_1_3  segment_load_conservation_835  -1
    load_0_1_3  segment_prefix_lb_836  1
    load_0_1_3  segment_prefix_ub_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_442  -20
    arc_0_1_4  connected_order_arc_443  -15
    arc_0_1_4  out_degree_817  1
    arc_0_1_4  in_degree_839  1
    arc_0_1_4  original_T_including_depot_unload_912  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_442  1
    load_0_1_4  segment_load_conservation_821  1
    load_0_1_4  segment_load_conservation_842  -1
    load_0_1_4  segment_prefix_lb_843  1
    load_0_1_4  segment_prefix_ub_844  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_444  -20
    arc_0_1_5  connected_order_arc_445  -15
    arc_0_1_5  out_degree_817  1
    arc_0_1_5  in_degree_846  1
    arc_0_1_5  original_T_including_depot_unload_912  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_444  1
    load_0_1_5  segment_load_conservation_821  1
    load_0_1_5  segment_load_conservation_849  -1
    load_0_1_5  segment_prefix_lb_850  1
    load_0_1_5  segment_prefix_ub_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_446  -20
    arc_0_1_6  connected_order_arc_447  -15
    arc_0_1_6  out_degree_817  1
    arc_0_1_6  in_degree_853  1
    arc_0_1_6  original_T_including_depot_unload_912  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_446  1
    load_0_1_6  segment_load_conservation_821  1
    load_0_1_6  segment_load_conservation_856  -1
    load_0_1_6  segment_prefix_lb_857  1
    load_0_1_6  segment_prefix_ub_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_448  -20
    arc_0_1_14  connected_order_arc_449  -15
    arc_0_1_14  out_degree_817  1
    arc_0_1_14  in_degree_860  1
    arc_0_1_14  original_T_including_depot_unload_912  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_448  1
    load_0_1_14  segment_load_conservation_821  1
    load_0_1_14  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_450  -20
    arc_0_1_15  connected_order_arc_451  -15
    arc_0_1_15  out_degree_817  1
    arc_0_1_15  in_degree_866  1
    arc_0_1_15  original_T_including_depot_unload_912  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_450  1
    load_0_1_15  segment_load_conservation_821  1
    load_0_1_15  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_452  -20
    arc_0_1_16  connected_order_arc_453  -15
    arc_0_1_16  out_degree_817  1
    arc_0_1_16  in_degree_872  1
    arc_0_1_16  original_T_including_depot_unload_912  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_452  1
    load_0_1_16  segment_load_conservation_821  1
    load_0_1_16  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_454  -20
    arc_0_1_17  connected_order_arc_455  -15
    arc_0_1_17  out_degree_817  1
    arc_0_1_17  in_degree_878  1
    arc_0_1_17  original_T_including_depot_unload_912  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_454  1
    load_0_1_17  segment_load_conservation_821  1
    load_0_1_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_456  -20
    arc_0_1_18  connected_order_arc_457  -15
    arc_0_1_18  out_degree_817  1
    arc_0_1_18  in_degree_884  1
    arc_0_1_18  original_T_including_depot_unload_912  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_456  1
    load_0_1_18  segment_load_conservation_821  1
    load_0_1_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_458  -20
    arc_0_1_19  connected_order_arc_459  -15
    arc_0_1_19  out_degree_817  1
    arc_0_1_19  in_degree_890  1
    arc_0_1_19  original_T_including_depot_unload_912  7.8495921746600118e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_458  1
    load_0_1_19  segment_load_conservation_821  1
    load_0_1_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_460  -20
    arc_0_1_20  connected_order_arc_461  -15
    arc_0_1_20  out_degree_817  1
    arc_0_1_20  in_degree_896  1
    arc_0_1_20  original_T_including_depot_unload_912  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_460  1
    load_0_1_20  segment_load_conservation_821  1
    load_0_1_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_462  -20
    arc_0_1_21  connected_order_arc_463  -15
    arc_0_1_21  out_degree_817  1
    arc_0_1_21  in_degree_902  1
    arc_0_1_21  original_T_including_depot_unload_912  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_462  1
    load_0_1_21  segment_load_conservation_821  1
    load_0_1_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_464  -20
    arc_0_2_0  depot_return_or_bypass_816  1
    arc_0_2_0  out_degree_824  1
    arc_0_2_0  original_T_including_depot_unload_912  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_464  1
    load_0_2_0  segment_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_465  -20
    arc_0_2_1  connected_order_arc_466  -15
    arc_0_2_1  in_degree_818  1
    arc_0_2_1  out_degree_824  1
    arc_0_2_1  original_T_including_depot_unload_912  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_465  1
    load_0_2_1  segment_load_conservation_821  -1
    load_0_2_1  segment_prefix_lb_822  1
    load_0_2_1  segment_prefix_ub_823  1
    load_0_2_1  segment_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_467  -20
    arc_0_2_3  connected_order_arc_468  -15
    arc_0_2_3  out_degree_824  1
    arc_0_2_3  in_degree_832  1
    arc_0_2_3  original_T_including_depot_unload_912  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_467  1
    load_0_2_3  segment_load_conservation_828  1
    load_0_2_3  segment_load_conservation_835  -1
    load_0_2_3  segment_prefix_lb_836  1
    load_0_2_3  segment_prefix_ub_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_469  -20
    arc_0_2_4  connected_order_arc_470  -15
    arc_0_2_4  out_degree_824  1
    arc_0_2_4  in_degree_839  1
    arc_0_2_4  original_T_including_depot_unload_912  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_469  1
    load_0_2_4  segment_load_conservation_828  1
    load_0_2_4  segment_load_conservation_842  -1
    load_0_2_4  segment_prefix_lb_843  1
    load_0_2_4  segment_prefix_ub_844  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_471  -20
    arc_0_2_5  connected_order_arc_472  -15
    arc_0_2_5  out_degree_824  1
    arc_0_2_5  in_degree_846  1
    arc_0_2_5  original_T_including_depot_unload_912  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_471  1
    load_0_2_5  segment_load_conservation_828  1
    load_0_2_5  segment_load_conservation_849  -1
    load_0_2_5  segment_prefix_lb_850  1
    load_0_2_5  segment_prefix_ub_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_473  -20
    arc_0_2_6  connected_order_arc_474  -15
    arc_0_2_6  out_degree_824  1
    arc_0_2_6  in_degree_853  1
    arc_0_2_6  original_T_including_depot_unload_912  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_473  1
    load_0_2_6  segment_load_conservation_828  1
    load_0_2_6  segment_load_conservation_856  -1
    load_0_2_6  segment_prefix_lb_857  1
    load_0_2_6  segment_prefix_ub_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_475  -20
    arc_0_2_14  connected_order_arc_476  -15
    arc_0_2_14  out_degree_824  1
    arc_0_2_14  in_degree_860  1
    arc_0_2_14  original_T_including_depot_unload_912  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_475  1
    load_0_2_14  segment_load_conservation_828  1
    load_0_2_14  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_477  -20
    arc_0_2_15  connected_order_arc_478  -15
    arc_0_2_15  out_degree_824  1
    arc_0_2_15  in_degree_866  1
    arc_0_2_15  original_T_including_depot_unload_912  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_477  1
    load_0_2_15  segment_load_conservation_828  1
    load_0_2_15  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_479  -20
    arc_0_2_16  connected_order_arc_480  -15
    arc_0_2_16  out_degree_824  1
    arc_0_2_16  in_degree_872  1
    arc_0_2_16  original_T_including_depot_unload_912  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_479  1
    load_0_2_16  segment_load_conservation_828  1
    load_0_2_16  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_481  -20
    arc_0_2_17  connected_order_arc_482  -15
    arc_0_2_17  out_degree_824  1
    arc_0_2_17  in_degree_878  1
    arc_0_2_17  original_T_including_depot_unload_912  6.7959844792905335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_481  1
    load_0_2_17  segment_load_conservation_828  1
    load_0_2_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_483  -20
    arc_0_2_18  connected_order_arc_484  -15
    arc_0_2_18  out_degree_824  1
    arc_0_2_18  in_degree_884  1
    arc_0_2_18  original_T_including_depot_unload_912  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_483  1
    load_0_2_18  segment_load_conservation_828  1
    load_0_2_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_485  -20
    arc_0_2_19  connected_order_arc_486  -15
    arc_0_2_19  out_degree_824  1
    arc_0_2_19  in_degree_890  1
    arc_0_2_19  original_T_including_depot_unload_912  7.1006591329511764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_485  1
    load_0_2_19  segment_load_conservation_828  1
    load_0_2_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_487  -20
    arc_0_2_20  connected_order_arc_488  -15
    arc_0_2_20  out_degree_824  1
    arc_0_2_20  in_degree_896  1
    arc_0_2_20  original_T_including_depot_unload_912  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_487  1
    load_0_2_20  segment_load_conservation_828  1
    load_0_2_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_489  -20
    arc_0_2_21  connected_order_arc_490  -15
    arc_0_2_21  out_degree_824  1
    arc_0_2_21  in_degree_902  1
    arc_0_2_21  original_T_including_depot_unload_912  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_489  1
    load_0_2_21  segment_load_conservation_828  1
    load_0_2_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_491  -20
    arc_0_3_0  depot_return_or_bypass_816  1
    arc_0_3_0  out_degree_831  1
    arc_0_3_0  original_T_including_depot_unload_912  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_491  1
    load_0_3_0  segment_load_conservation_835  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_492  -20
    arc_0_3_1  connected_order_arc_493  -15
    arc_0_3_1  in_degree_818  1
    arc_0_3_1  out_degree_831  1
    arc_0_3_1  original_T_including_depot_unload_912  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_492  1
    load_0_3_1  segment_load_conservation_821  -1
    load_0_3_1  segment_prefix_lb_822  1
    load_0_3_1  segment_prefix_ub_823  1
    load_0_3_1  segment_load_conservation_835  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_494  -20
    arc_0_3_2  connected_order_arc_495  -15
    arc_0_3_2  in_degree_825  1
    arc_0_3_2  out_degree_831  1
    arc_0_3_2  original_T_including_depot_unload_912  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_494  1
    load_0_3_2  segment_load_conservation_828  -1
    load_0_3_2  segment_prefix_lb_829  1
    load_0_3_2  segment_prefix_ub_830  1
    load_0_3_2  segment_load_conservation_835  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_496  -20
    arc_0_3_4  connected_order_arc_497  -15
    arc_0_3_4  out_degree_831  1
    arc_0_3_4  in_degree_839  1
    arc_0_3_4  original_T_including_depot_unload_912  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_496  1
    load_0_3_4  segment_load_conservation_835  1
    load_0_3_4  segment_load_conservation_842  -1
    load_0_3_4  segment_prefix_lb_843  1
    load_0_3_4  segment_prefix_ub_844  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_498  -20
    arc_0_3_5  connected_order_arc_499  -15
    arc_0_3_5  out_degree_831  1
    arc_0_3_5  in_degree_846  1
    arc_0_3_5  original_T_including_depot_unload_912  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_498  1
    load_0_3_5  segment_load_conservation_835  1
    load_0_3_5  segment_load_conservation_849  -1
    load_0_3_5  segment_prefix_lb_850  1
    load_0_3_5  segment_prefix_ub_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_500  -20
    arc_0_3_6  connected_order_arc_501  -15
    arc_0_3_6  out_degree_831  1
    arc_0_3_6  in_degree_853  1
    arc_0_3_6  original_T_including_depot_unload_912  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_500  1
    load_0_3_6  segment_load_conservation_835  1
    load_0_3_6  segment_load_conservation_856  -1
    load_0_3_6  segment_prefix_lb_857  1
    load_0_3_6  segment_prefix_ub_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_502  -20
    arc_0_3_14  connected_order_arc_503  -15
    arc_0_3_14  out_degree_831  1
    arc_0_3_14  in_degree_860  1
    arc_0_3_14  original_T_including_depot_unload_912  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_502  1
    load_0_3_14  segment_load_conservation_835  1
    load_0_3_14  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_504  -20
    arc_0_3_15  connected_order_arc_505  -15
    arc_0_3_15  out_degree_831  1
    arc_0_3_15  in_degree_866  1
    arc_0_3_15  original_T_including_depot_unload_912  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_504  1
    load_0_3_15  segment_load_conservation_835  1
    load_0_3_15  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_506  -20
    arc_0_3_16  connected_order_arc_507  -15
    arc_0_3_16  out_degree_831  1
    arc_0_3_16  in_degree_872  1
    arc_0_3_16  original_T_including_depot_unload_912  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_506  1
    load_0_3_16  segment_load_conservation_835  1
    load_0_3_16  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_508  -20
    arc_0_3_17  connected_order_arc_509  -15
    arc_0_3_17  out_degree_831  1
    arc_0_3_17  in_degree_878  1
    arc_0_3_17  original_T_including_depot_unload_912  8.5807018379884664e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_508  1
    load_0_3_17  segment_load_conservation_835  1
    load_0_3_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_510  -20
    arc_0_3_18  connected_order_arc_511  -15
    arc_0_3_18  out_degree_831  1
    arc_0_3_18  in_degree_884  1
    arc_0_3_18  original_T_including_depot_unload_912  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_510  1
    load_0_3_18  segment_load_conservation_835  1
    load_0_3_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_512  -20
    arc_0_3_19  connected_order_arc_513  -15
    arc_0_3_19  out_degree_831  1
    arc_0_3_19  in_degree_890  1
    arc_0_3_19  original_T_including_depot_unload_912  9.2153450304618127e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_512  1
    load_0_3_19  segment_load_conservation_835  1
    load_0_3_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_514  -20
    arc_0_3_20  connected_order_arc_515  -15
    arc_0_3_20  out_degree_831  1
    arc_0_3_20  in_degree_896  1
    arc_0_3_20  original_T_including_depot_unload_912  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_514  1
    load_0_3_20  segment_load_conservation_835  1
    load_0_3_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_516  -20
    arc_0_3_21  connected_order_arc_517  -15
    arc_0_3_21  out_degree_831  1
    arc_0_3_21  in_degree_902  1
    arc_0_3_21  original_T_including_depot_unload_912  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_516  1
    load_0_3_21  segment_load_conservation_835  1
    load_0_3_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_518  -20
    arc_0_4_0  depot_return_or_bypass_816  1
    arc_0_4_0  out_degree_838  1
    arc_0_4_0  original_T_including_depot_unload_912  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_518  1
    load_0_4_0  segment_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_519  -20
    arc_0_4_1  connected_order_arc_520  -15
    arc_0_4_1  in_degree_818  1
    arc_0_4_1  out_degree_838  1
    arc_0_4_1  original_T_including_depot_unload_912  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_519  1
    load_0_4_1  segment_load_conservation_821  -1
    load_0_4_1  segment_prefix_lb_822  1
    load_0_4_1  segment_prefix_ub_823  1
    load_0_4_1  segment_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_521  -20
    arc_0_4_2  connected_order_arc_522  -15
    arc_0_4_2  in_degree_825  1
    arc_0_4_2  out_degree_838  1
    arc_0_4_2  original_T_including_depot_unload_912  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_521  1
    load_0_4_2  segment_load_conservation_828  -1
    load_0_4_2  segment_prefix_lb_829  1
    load_0_4_2  segment_prefix_ub_830  1
    load_0_4_2  segment_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_523  -20
    arc_0_4_3  connected_order_arc_524  -15
    arc_0_4_3  in_degree_832  1
    arc_0_4_3  out_degree_838  1
    arc_0_4_3  original_T_including_depot_unload_912  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_523  1
    load_0_4_3  segment_load_conservation_835  -1
    load_0_4_3  segment_prefix_lb_836  1
    load_0_4_3  segment_prefix_ub_837  1
    load_0_4_3  segment_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_525  -20
    arc_0_4_5  connected_order_arc_526  -15
    arc_0_4_5  out_degree_838  1
    arc_0_4_5  in_degree_846  1
    arc_0_4_5  original_T_including_depot_unload_912  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_525  1
    load_0_4_5  segment_load_conservation_842  1
    load_0_4_5  segment_load_conservation_849  -1
    load_0_4_5  segment_prefix_lb_850  1
    load_0_4_5  segment_prefix_ub_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_527  -20
    arc_0_4_6  connected_order_arc_528  -15
    arc_0_4_6  out_degree_838  1
    arc_0_4_6  in_degree_853  1
    arc_0_4_6  original_T_including_depot_unload_912  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_527  1
    load_0_4_6  segment_load_conservation_842  1
    load_0_4_6  segment_load_conservation_856  -1
    load_0_4_6  segment_prefix_lb_857  1
    load_0_4_6  segment_prefix_ub_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_529  -20
    arc_0_4_14  connected_order_arc_530  -15
    arc_0_4_14  out_degree_838  1
    arc_0_4_14  in_degree_860  1
    arc_0_4_14  original_T_including_depot_unload_912  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_529  1
    load_0_4_14  segment_load_conservation_842  1
    load_0_4_14  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_531  -20
    arc_0_4_15  connected_order_arc_532  -15
    arc_0_4_15  out_degree_838  1
    arc_0_4_15  in_degree_866  1
    arc_0_4_15  original_T_including_depot_unload_912  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_531  1
    load_0_4_15  segment_load_conservation_842  1
    load_0_4_15  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_533  -20
    arc_0_4_16  connected_order_arc_534  -15
    arc_0_4_16  out_degree_838  1
    arc_0_4_16  in_degree_872  1
    arc_0_4_16  original_T_including_depot_unload_912  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_533  1
    load_0_4_16  segment_load_conservation_842  1
    load_0_4_16  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_535  -20
    arc_0_4_17  connected_order_arc_536  -15
    arc_0_4_17  out_degree_838  1
    arc_0_4_17  in_degree_878  1
    arc_0_4_17  original_T_including_depot_unload_912  9.4424191477021122e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_535  1
    load_0_4_17  segment_load_conservation_842  1
    load_0_4_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_537  -20
    arc_0_4_18  connected_order_arc_538  -15
    arc_0_4_18  out_degree_838  1
    arc_0_4_18  in_degree_884  1
    arc_0_4_18  original_T_including_depot_unload_912  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_537  1
    load_0_4_18  segment_load_conservation_842  1
    load_0_4_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_539  -20
    arc_0_4_19  connected_order_arc_540  -15
    arc_0_4_19  out_degree_838  1
    arc_0_4_19  in_degree_890  1
    arc_0_4_19  original_T_including_depot_unload_912  1.0213043329444467e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_539  1
    load_0_4_19  segment_load_conservation_842  1
    load_0_4_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_541  -20
    arc_0_4_20  connected_order_arc_542  -15
    arc_0_4_20  out_degree_838  1
    arc_0_4_20  in_degree_896  1
    arc_0_4_20  original_T_including_depot_unload_912  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_541  1
    load_0_4_20  segment_load_conservation_842  1
    load_0_4_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_543  -20
    arc_0_4_21  connected_order_arc_544  -15
    arc_0_4_21  out_degree_838  1
    arc_0_4_21  in_degree_902  1
    arc_0_4_21  original_T_including_depot_unload_912  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_543  1
    load_0_4_21  segment_load_conservation_842  1
    load_0_4_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_545  -20
    arc_0_5_0  depot_return_or_bypass_816  1
    arc_0_5_0  out_degree_845  1
    arc_0_5_0  original_T_including_depot_unload_912  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_545  1
    load_0_5_0  segment_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_546  -20
    arc_0_5_1  connected_order_arc_547  -15
    arc_0_5_1  in_degree_818  1
    arc_0_5_1  out_degree_845  1
    arc_0_5_1  original_T_including_depot_unload_912  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_546  1
    load_0_5_1  segment_load_conservation_821  -1
    load_0_5_1  segment_prefix_lb_822  1
    load_0_5_1  segment_prefix_ub_823  1
    load_0_5_1  segment_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_548  -20
    arc_0_5_2  connected_order_arc_549  -15
    arc_0_5_2  in_degree_825  1
    arc_0_5_2  out_degree_845  1
    arc_0_5_2  original_T_including_depot_unload_912  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_548  1
    load_0_5_2  segment_load_conservation_828  -1
    load_0_5_2  segment_prefix_lb_829  1
    load_0_5_2  segment_prefix_ub_830  1
    load_0_5_2  segment_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_550  -20
    arc_0_5_3  connected_order_arc_551  -15
    arc_0_5_3  in_degree_832  1
    arc_0_5_3  out_degree_845  1
    arc_0_5_3  original_T_including_depot_unload_912  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_550  1
    load_0_5_3  segment_load_conservation_835  -1
    load_0_5_3  segment_prefix_lb_836  1
    load_0_5_3  segment_prefix_ub_837  1
    load_0_5_3  segment_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_552  -20
    arc_0_5_4  connected_order_arc_553  -15
    arc_0_5_4  in_degree_839  1
    arc_0_5_4  out_degree_845  1
    arc_0_5_4  original_T_including_depot_unload_912  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_552  1
    load_0_5_4  segment_load_conservation_842  -1
    load_0_5_4  segment_prefix_lb_843  1
    load_0_5_4  segment_prefix_ub_844  1
    load_0_5_4  segment_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_554  -20
    arc_0_5_6  connected_order_arc_555  -15
    arc_0_5_6  out_degree_845  1
    arc_0_5_6  in_degree_853  1
    arc_0_5_6  original_T_including_depot_unload_912  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_554  1
    load_0_5_6  segment_load_conservation_849  1
    load_0_5_6  segment_load_conservation_856  -1
    load_0_5_6  segment_prefix_lb_857  1
    load_0_5_6  segment_prefix_ub_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_556  -20
    arc_0_5_14  connected_order_arc_557  -15
    arc_0_5_14  out_degree_845  1
    arc_0_5_14  in_degree_860  1
    arc_0_5_14  original_T_including_depot_unload_912  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_556  1
    load_0_5_14  segment_load_conservation_849  1
    load_0_5_14  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_558  -20
    arc_0_5_15  connected_order_arc_559  -15
    arc_0_5_15  out_degree_845  1
    arc_0_5_15  in_degree_866  1
    arc_0_5_15  original_T_including_depot_unload_912  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_558  1
    load_0_5_15  segment_load_conservation_849  1
    load_0_5_15  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_560  -20
    arc_0_5_16  connected_order_arc_561  -15
    arc_0_5_16  out_degree_845  1
    arc_0_5_16  in_degree_872  1
    arc_0_5_16  original_T_including_depot_unload_912  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_560  1
    load_0_5_16  segment_load_conservation_849  1
    load_0_5_16  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_562  -20
    arc_0_5_17  connected_order_arc_563  -15
    arc_0_5_17  out_degree_845  1
    arc_0_5_17  in_degree_878  1
    arc_0_5_17  original_T_including_depot_unload_912  1.1952607376785465e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_562  1
    load_0_5_17  segment_load_conservation_849  1
    load_0_5_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_564  -20
    arc_0_5_18  connected_order_arc_565  -15
    arc_0_5_18  out_degree_845  1
    arc_0_5_18  in_degree_884  1
    arc_0_5_18  original_T_including_depot_unload_912  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_564  1
    load_0_5_18  segment_load_conservation_849  1
    load_0_5_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_566  -20
    arc_0_5_19  connected_order_arc_567  -15
    arc_0_5_19  out_degree_845  1
    arc_0_5_19  in_degree_890  1
    arc_0_5_19  original_T_including_depot_unload_912  1.2628291878233333e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_566  1
    load_0_5_19  segment_load_conservation_849  1
    load_0_5_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_568  -20
    arc_0_5_20  connected_order_arc_569  -15
    arc_0_5_20  out_degree_845  1
    arc_0_5_20  in_degree_896  1
    arc_0_5_20  original_T_including_depot_unload_912  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_568  1
    load_0_5_20  segment_load_conservation_849  1
    load_0_5_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_570  -20
    arc_0_5_21  connected_order_arc_571  -15
    arc_0_5_21  out_degree_845  1
    arc_0_5_21  in_degree_902  1
    arc_0_5_21  original_T_including_depot_unload_912  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_570  1
    load_0_5_21  segment_load_conservation_849  1
    load_0_5_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_572  -20
    arc_0_6_0  depot_return_or_bypass_816  1
    arc_0_6_0  out_degree_852  1
    arc_0_6_0  original_T_including_depot_unload_912  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_572  1
    load_0_6_0  segment_load_conservation_856  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_573  -20
    arc_0_6_1  connected_order_arc_574  -15
    arc_0_6_1  in_degree_818  1
    arc_0_6_1  out_degree_852  1
    arc_0_6_1  original_T_including_depot_unload_912  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_573  1
    load_0_6_1  segment_load_conservation_821  -1
    load_0_6_1  segment_prefix_lb_822  1
    load_0_6_1  segment_prefix_ub_823  1
    load_0_6_1  segment_load_conservation_856  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_575  -20
    arc_0_6_2  connected_order_arc_576  -15
    arc_0_6_2  in_degree_825  1
    arc_0_6_2  out_degree_852  1
    arc_0_6_2  original_T_including_depot_unload_912  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_575  1
    load_0_6_2  segment_load_conservation_828  -1
    load_0_6_2  segment_prefix_lb_829  1
    load_0_6_2  segment_prefix_ub_830  1
    load_0_6_2  segment_load_conservation_856  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_577  -20
    arc_0_6_3  connected_order_arc_578  -15
    arc_0_6_3  in_degree_832  1
    arc_0_6_3  out_degree_852  1
    arc_0_6_3  original_T_including_depot_unload_912  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_577  1
    load_0_6_3  segment_load_conservation_835  -1
    load_0_6_3  segment_prefix_lb_836  1
    load_0_6_3  segment_prefix_ub_837  1
    load_0_6_3  segment_load_conservation_856  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_579  -20
    arc_0_6_4  connected_order_arc_580  -15
    arc_0_6_4  in_degree_839  1
    arc_0_6_4  out_degree_852  1
    arc_0_6_4  original_T_including_depot_unload_912  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_579  1
    load_0_6_4  segment_load_conservation_842  -1
    load_0_6_4  segment_prefix_lb_843  1
    load_0_6_4  segment_prefix_ub_844  1
    load_0_6_4  segment_load_conservation_856  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_581  -20
    arc_0_6_5  connected_order_arc_582  -15
    arc_0_6_5  in_degree_846  1
    arc_0_6_5  out_degree_852  1
    arc_0_6_5  original_T_including_depot_unload_912  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_581  1
    load_0_6_5  segment_load_conservation_849  -1
    load_0_6_5  segment_prefix_lb_850  1
    load_0_6_5  segment_prefix_ub_851  1
    load_0_6_5  segment_load_conservation_856  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_14  arc_capacity_583  -20
    arc_0_6_14  connected_order_arc_584  -15
    arc_0_6_14  out_degree_852  1
    arc_0_6_14  in_degree_860  1
    arc_0_6_14  original_T_including_depot_unload_912  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_14  arc_capacity_583  1
    load_0_6_14  segment_load_conservation_856  1
    load_0_6_14  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_585  -20
    arc_0_6_15  connected_order_arc_586  -15
    arc_0_6_15  out_degree_852  1
    arc_0_6_15  in_degree_866  1
    arc_0_6_15  original_T_including_depot_unload_912  9.2985081319651772e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_585  1
    load_0_6_15  segment_load_conservation_856  1
    load_0_6_15  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_587  -20
    arc_0_6_16  connected_order_arc_588  -15
    arc_0_6_16  out_degree_852  1
    arc_0_6_16  in_degree_872  1
    arc_0_6_16  original_T_including_depot_unload_912  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_587  1
    load_0_6_16  segment_load_conservation_856  1
    load_0_6_16  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_17  arc_capacity_589  -20
    arc_0_6_17  connected_order_arc_590  -15
    arc_0_6_17  out_degree_852  1
    arc_0_6_17  in_degree_878  1
    arc_0_6_17  original_T_including_depot_unload_912  1.2399741997148888e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_17  arc_capacity_589  1
    load_0_6_17  segment_load_conservation_856  1
    load_0_6_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_18  arc_capacity_591  -20
    arc_0_6_18  connected_order_arc_592  -15
    arc_0_6_18  out_degree_852  1
    arc_0_6_18  in_degree_884  1
    arc_0_6_18  original_T_including_depot_unload_912  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_18  arc_capacity_591  1
    load_0_6_18  segment_load_conservation_856  1
    load_0_6_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_19  arc_capacity_593  -20
    arc_0_6_19  connected_order_arc_594  -15
    arc_0_6_19  out_degree_852  1
    arc_0_6_19  in_degree_890  1
    arc_0_6_19  original_T_including_depot_unload_912  1.3473492742338772e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_19  arc_capacity_593  1
    load_0_6_19  segment_load_conservation_856  1
    load_0_6_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_20  arc_capacity_595  -20
    arc_0_6_20  connected_order_arc_596  -15
    arc_0_6_20  out_degree_852  1
    arc_0_6_20  in_degree_896  1
    arc_0_6_20  original_T_including_depot_unload_912  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_20  arc_capacity_595  1
    load_0_6_20  segment_load_conservation_856  1
    load_0_6_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_21  arc_capacity_597  -20
    arc_0_6_21  connected_order_arc_598  -15
    arc_0_6_21  out_degree_852  1
    arc_0_6_21  in_degree_902  1
    arc_0_6_21  original_T_including_depot_unload_912  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_21  arc_capacity_597  1
    load_0_6_21  segment_load_conservation_856  1
    load_0_6_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_599  -20
    arc_0_14_0  depot_return_or_bypass_816  1
    arc_0_14_0  out_degree_859  1
    arc_0_14_0  original_T_including_depot_unload_912  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_599  1
    load_0_14_0  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_600  -20
    arc_0_14_1  connected_order_arc_601  -15
    arc_0_14_1  in_degree_818  1
    arc_0_14_1  out_degree_859  1
    arc_0_14_1  original_T_including_depot_unload_912  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_600  1
    load_0_14_1  segment_load_conservation_821  -1
    load_0_14_1  segment_prefix_lb_822  1
    load_0_14_1  segment_prefix_ub_823  1
    load_0_14_1  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_602  -20
    arc_0_14_2  connected_order_arc_603  -15
    arc_0_14_2  in_degree_825  1
    arc_0_14_2  out_degree_859  1
    arc_0_14_2  original_T_including_depot_unload_912  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_602  1
    load_0_14_2  segment_load_conservation_828  -1
    load_0_14_2  segment_prefix_lb_829  1
    load_0_14_2  segment_prefix_ub_830  1
    load_0_14_2  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_604  -20
    arc_0_14_3  connected_order_arc_605  -15
    arc_0_14_3  in_degree_832  1
    arc_0_14_3  out_degree_859  1
    arc_0_14_3  original_T_including_depot_unload_912  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_604  1
    load_0_14_3  segment_load_conservation_835  -1
    load_0_14_3  segment_prefix_lb_836  1
    load_0_14_3  segment_prefix_ub_837  1
    load_0_14_3  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_606  -20
    arc_0_14_4  connected_order_arc_607  -15
    arc_0_14_4  in_degree_839  1
    arc_0_14_4  out_degree_859  1
    arc_0_14_4  original_T_including_depot_unload_912  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_606  1
    load_0_14_4  segment_load_conservation_842  -1
    load_0_14_4  segment_prefix_lb_843  1
    load_0_14_4  segment_prefix_ub_844  1
    load_0_14_4  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_608  -20
    arc_0_14_5  connected_order_arc_609  -15
    arc_0_14_5  in_degree_846  1
    arc_0_14_5  out_degree_859  1
    arc_0_14_5  original_T_including_depot_unload_912  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_608  1
    load_0_14_5  segment_load_conservation_849  -1
    load_0_14_5  segment_prefix_lb_850  1
    load_0_14_5  segment_prefix_ub_851  1
    load_0_14_5  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_6  arc_capacity_610  -20
    arc_0_14_6  connected_order_arc_611  -15
    arc_0_14_6  in_degree_853  1
    arc_0_14_6  out_degree_859  1
    arc_0_14_6  original_T_including_depot_unload_912  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_6  arc_capacity_610  1
    load_0_14_6  segment_load_conservation_856  -1
    load_0_14_6  segment_prefix_lb_857  1
    load_0_14_6  segment_prefix_ub_858  1
    load_0_14_6  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_612  -20
    arc_0_14_15  connected_order_arc_613  -15
    arc_0_14_15  out_degree_859  1
    arc_0_14_15  in_degree_866  1
    arc_0_14_15  original_T_including_depot_unload_912  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_612  1
    load_0_14_15  free_load_conservation_864  1
    load_0_14_15  free_load_conservation_870  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_614  -20
    arc_0_14_16  connected_order_arc_615  -15
    arc_0_14_16  out_degree_859  1
    arc_0_14_16  in_degree_872  1
    arc_0_14_16  original_T_including_depot_unload_912  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_614  1
    load_0_14_16  free_load_conservation_864  1
    load_0_14_16  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_616  -20
    arc_0_14_17  connected_order_arc_617  -15
    arc_0_14_17  out_degree_859  1
    arc_0_14_17  in_degree_878  1
    arc_0_14_17  original_T_including_depot_unload_912  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_616  1
    load_0_14_17  free_load_conservation_864  1
    load_0_14_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_618  -20
    arc_0_14_18  connected_order_arc_619  -15
    arc_0_14_18  out_degree_859  1
    arc_0_14_18  in_degree_884  1
    arc_0_14_18  original_T_including_depot_unload_912  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_618  1
    load_0_14_18  free_load_conservation_864  1
    load_0_14_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_620  -20
    arc_0_14_19  connected_order_arc_621  -15
    arc_0_14_19  out_degree_859  1
    arc_0_14_19  in_degree_890  1
    arc_0_14_19  original_T_including_depot_unload_912  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_620  1
    load_0_14_19  free_load_conservation_864  1
    load_0_14_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_622  -20
    arc_0_14_20  connected_order_arc_623  -15
    arc_0_14_20  out_degree_859  1
    arc_0_14_20  in_degree_896  1
    arc_0_14_20  original_T_including_depot_unload_912  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_622  1
    load_0_14_20  free_load_conservation_864  1
    load_0_14_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_21  arc_capacity_624  -20
    arc_0_14_21  connected_order_arc_625  -15
    arc_0_14_21  out_degree_859  1
    arc_0_14_21  in_degree_902  1
    arc_0_14_21  original_T_including_depot_unload_912  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_21  arc_capacity_624  1
    load_0_14_21  free_load_conservation_864  1
    load_0_14_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_626  -20
    arc_0_15_0  depot_return_or_bypass_816  1
    arc_0_15_0  out_degree_865  1
    arc_0_15_0  original_T_including_depot_unload_912  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_626  1
    load_0_15_0  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_627  -20
    arc_0_15_1  connected_order_arc_628  -15
    arc_0_15_1  in_degree_818  1
    arc_0_15_1  out_degree_865  1
    arc_0_15_1  original_T_including_depot_unload_912  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_627  1
    load_0_15_1  segment_load_conservation_821  -1
    load_0_15_1  segment_prefix_lb_822  1
    load_0_15_1  segment_prefix_ub_823  1
    load_0_15_1  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_629  -20
    arc_0_15_2  connected_order_arc_630  -15
    arc_0_15_2  in_degree_825  1
    arc_0_15_2  out_degree_865  1
    arc_0_15_2  original_T_including_depot_unload_912  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_629  1
    load_0_15_2  segment_load_conservation_828  -1
    load_0_15_2  segment_prefix_lb_829  1
    load_0_15_2  segment_prefix_ub_830  1
    load_0_15_2  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_631  -20
    arc_0_15_3  connected_order_arc_632  -15
    arc_0_15_3  in_degree_832  1
    arc_0_15_3  out_degree_865  1
    arc_0_15_3  original_T_including_depot_unload_912  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_631  1
    load_0_15_3  segment_load_conservation_835  -1
    load_0_15_3  segment_prefix_lb_836  1
    load_0_15_3  segment_prefix_ub_837  1
    load_0_15_3  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_633  -20
    arc_0_15_4  connected_order_arc_634  -15
    arc_0_15_4  in_degree_839  1
    arc_0_15_4  out_degree_865  1
    arc_0_15_4  original_T_including_depot_unload_912  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_633  1
    load_0_15_4  segment_load_conservation_842  -1
    load_0_15_4  segment_prefix_lb_843  1
    load_0_15_4  segment_prefix_ub_844  1
    load_0_15_4  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_635  -20
    arc_0_15_5  connected_order_arc_636  -15
    arc_0_15_5  in_degree_846  1
    arc_0_15_5  out_degree_865  1
    arc_0_15_5  original_T_including_depot_unload_912  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_635  1
    load_0_15_5  segment_load_conservation_849  -1
    load_0_15_5  segment_prefix_lb_850  1
    load_0_15_5  segment_prefix_ub_851  1
    load_0_15_5  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_637  -20
    arc_0_15_6  connected_order_arc_638  -15
    arc_0_15_6  in_degree_853  1
    arc_0_15_6  out_degree_865  1
    arc_0_15_6  original_T_including_depot_unload_912  9.1345700487521981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_637  1
    load_0_15_6  segment_load_conservation_856  -1
    load_0_15_6  segment_prefix_lb_857  1
    load_0_15_6  segment_prefix_ub_858  1
    load_0_15_6  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_639  -20
    arc_0_15_14  connected_order_arc_640  -15
    arc_0_15_14  in_degree_860  1
    arc_0_15_14  out_degree_865  1
    arc_0_15_14  original_T_including_depot_unload_912  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_639  1
    load_0_15_14  free_load_conservation_864  -1
    load_0_15_14  free_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_641  -20
    arc_0_15_16  connected_order_arc_642  -15
    arc_0_15_16  out_degree_865  1
    arc_0_15_16  in_degree_872  1
    arc_0_15_16  original_T_including_depot_unload_912  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_641  1
    load_0_15_16  free_load_conservation_870  1
    load_0_15_16  free_load_conservation_876  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_643  -20
    arc_0_15_17  connected_order_arc_644  -15
    arc_0_15_17  out_degree_865  1
    arc_0_15_17  in_degree_878  1
    arc_0_15_17  original_T_including_depot_unload_912  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_643  1
    load_0_15_17  free_load_conservation_870  1
    load_0_15_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_645  -20
    arc_0_15_18  connected_order_arc_646  -15
    arc_0_15_18  out_degree_865  1
    arc_0_15_18  in_degree_884  1
    arc_0_15_18  original_T_including_depot_unload_912  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_645  1
    load_0_15_18  free_load_conservation_870  1
    load_0_15_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_647  -20
    arc_0_15_19  connected_order_arc_648  -15
    arc_0_15_19  out_degree_865  1
    arc_0_15_19  in_degree_890  1
    arc_0_15_19  original_T_including_depot_unload_912  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_647  1
    load_0_15_19  free_load_conservation_870  1
    load_0_15_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_649  -20
    arc_0_15_20  connected_order_arc_650  -15
    arc_0_15_20  out_degree_865  1
    arc_0_15_20  in_degree_896  1
    arc_0_15_20  original_T_including_depot_unload_912  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_649  1
    load_0_15_20  free_load_conservation_870  1
    load_0_15_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_651  -20
    arc_0_15_21  connected_order_arc_652  -15
    arc_0_15_21  out_degree_865  1
    arc_0_15_21  in_degree_902  1
    arc_0_15_21  original_T_including_depot_unload_912  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_651  1
    load_0_15_21  free_load_conservation_870  1
    load_0_15_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_653  -20
    arc_0_16_0  depot_return_or_bypass_816  1
    arc_0_16_0  out_degree_871  1
    arc_0_16_0  original_T_including_depot_unload_912  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_653  1
    load_0_16_0  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_654  -20
    arc_0_16_1  connected_order_arc_655  -15
    arc_0_16_1  in_degree_818  1
    arc_0_16_1  out_degree_871  1
    arc_0_16_1  original_T_including_depot_unload_912  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_654  1
    load_0_16_1  segment_load_conservation_821  -1
    load_0_16_1  segment_prefix_lb_822  1
    load_0_16_1  segment_prefix_ub_823  1
    load_0_16_1  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_656  -20
    arc_0_16_2  connected_order_arc_657  -15
    arc_0_16_2  in_degree_825  1
    arc_0_16_2  out_degree_871  1
    arc_0_16_2  original_T_including_depot_unload_912  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_656  1
    load_0_16_2  segment_load_conservation_828  -1
    load_0_16_2  segment_prefix_lb_829  1
    load_0_16_2  segment_prefix_ub_830  1
    load_0_16_2  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_658  -20
    arc_0_16_3  connected_order_arc_659  -15
    arc_0_16_3  in_degree_832  1
    arc_0_16_3  out_degree_871  1
    arc_0_16_3  original_T_including_depot_unload_912  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_658  1
    load_0_16_3  segment_load_conservation_835  -1
    load_0_16_3  segment_prefix_lb_836  1
    load_0_16_3  segment_prefix_ub_837  1
    load_0_16_3  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_660  -20
    arc_0_16_4  connected_order_arc_661  -15
    arc_0_16_4  in_degree_839  1
    arc_0_16_4  out_degree_871  1
    arc_0_16_4  original_T_including_depot_unload_912  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_660  1
    load_0_16_4  segment_load_conservation_842  -1
    load_0_16_4  segment_prefix_lb_843  1
    load_0_16_4  segment_prefix_ub_844  1
    load_0_16_4  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_662  -20
    arc_0_16_5  connected_order_arc_663  -15
    arc_0_16_5  in_degree_846  1
    arc_0_16_5  out_degree_871  1
    arc_0_16_5  original_T_including_depot_unload_912  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_662  1
    load_0_16_5  segment_load_conservation_849  -1
    load_0_16_5  segment_prefix_lb_850  1
    load_0_16_5  segment_prefix_ub_851  1
    load_0_16_5  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_664  -20
    arc_0_16_6  connected_order_arc_665  -15
    arc_0_16_6  in_degree_853  1
    arc_0_16_6  out_degree_871  1
    arc_0_16_6  original_T_including_depot_unload_912  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_664  1
    load_0_16_6  segment_load_conservation_856  -1
    load_0_16_6  segment_prefix_lb_857  1
    load_0_16_6  segment_prefix_ub_858  1
    load_0_16_6  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_666  -20
    arc_0_16_14  connected_order_arc_667  -15
    arc_0_16_14  in_degree_860  1
    arc_0_16_14  out_degree_871  1
    arc_0_16_14  original_T_including_depot_unload_912  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_666  1
    load_0_16_14  free_load_conservation_864  -1
    load_0_16_14  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_668  -20
    arc_0_16_15  connected_order_arc_669  -15
    arc_0_16_15  in_degree_866  1
    arc_0_16_15  out_degree_871  1
    arc_0_16_15  original_T_including_depot_unload_912  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_668  1
    load_0_16_15  free_load_conservation_870  -1
    load_0_16_15  free_load_conservation_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_670  -20
    arc_0_16_17  connected_order_arc_671  -15
    arc_0_16_17  out_degree_871  1
    arc_0_16_17  in_degree_878  1
    arc_0_16_17  original_T_including_depot_unload_912  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_670  1
    load_0_16_17  free_load_conservation_876  1
    load_0_16_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_672  -20
    arc_0_16_18  connected_order_arc_673  -15
    arc_0_16_18  out_degree_871  1
    arc_0_16_18  in_degree_884  1
    arc_0_16_18  original_T_including_depot_unload_912  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_672  1
    load_0_16_18  free_load_conservation_876  1
    load_0_16_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_674  -20
    arc_0_16_19  connected_order_arc_675  -15
    arc_0_16_19  out_degree_871  1
    arc_0_16_19  in_degree_890  1
    arc_0_16_19  original_T_including_depot_unload_912  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_674  1
    load_0_16_19  free_load_conservation_876  1
    load_0_16_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_676  -20
    arc_0_16_20  connected_order_arc_677  -15
    arc_0_16_20  out_degree_871  1
    arc_0_16_20  in_degree_896  1
    arc_0_16_20  original_T_including_depot_unload_912  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_676  1
    load_0_16_20  free_load_conservation_876  1
    load_0_16_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_678  -20
    arc_0_16_21  connected_order_arc_679  -15
    arc_0_16_21  out_degree_871  1
    arc_0_16_21  in_degree_902  1
    arc_0_16_21  original_T_including_depot_unload_912  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_678  1
    load_0_16_21  free_load_conservation_876  1
    load_0_16_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_680  -20
    arc_0_17_0  depot_return_or_bypass_816  1
    arc_0_17_0  out_degree_877  1
    arc_0_17_0  original_T_including_depot_unload_912  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_680  1
    load_0_17_0  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_681  -20
    arc_0_17_1  connected_order_arc_682  -15
    arc_0_17_1  in_degree_818  1
    arc_0_17_1  out_degree_877  1
    arc_0_17_1  original_T_including_depot_unload_912  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_681  1
    load_0_17_1  segment_load_conservation_821  -1
    load_0_17_1  segment_prefix_lb_822  1
    load_0_17_1  segment_prefix_ub_823  1
    load_0_17_1  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_683  -20
    arc_0_17_2  connected_order_arc_684  -15
    arc_0_17_2  in_degree_825  1
    arc_0_17_2  out_degree_877  1
    arc_0_17_2  original_T_including_depot_unload_912  6.7959844792905335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_683  1
    load_0_17_2  segment_load_conservation_828  -1
    load_0_17_2  segment_prefix_lb_829  1
    load_0_17_2  segment_prefix_ub_830  1
    load_0_17_2  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_685  -20
    arc_0_17_3  connected_order_arc_686  -15
    arc_0_17_3  in_degree_832  1
    arc_0_17_3  out_degree_877  1
    arc_0_17_3  original_T_including_depot_unload_912  8.5807018379884664e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_685  1
    load_0_17_3  segment_load_conservation_835  -1
    load_0_17_3  segment_prefix_lb_836  1
    load_0_17_3  segment_prefix_ub_837  1
    load_0_17_3  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_687  -20
    arc_0_17_4  connected_order_arc_688  -15
    arc_0_17_4  in_degree_839  1
    arc_0_17_4  out_degree_877  1
    arc_0_17_4  original_T_including_depot_unload_912  9.4424191477021122e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_687  1
    load_0_17_4  segment_load_conservation_842  -1
    load_0_17_4  segment_prefix_lb_843  1
    load_0_17_4  segment_prefix_ub_844  1
    load_0_17_4  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_689  -20
    arc_0_17_5  connected_order_arc_690  -15
    arc_0_17_5  in_degree_846  1
    arc_0_17_5  out_degree_877  1
    arc_0_17_5  original_T_including_depot_unload_912  1.1952607376785465e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_689  1
    load_0_17_5  segment_load_conservation_849  -1
    load_0_17_5  segment_prefix_lb_850  1
    load_0_17_5  segment_prefix_ub_851  1
    load_0_17_5  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_6  arc_capacity_691  -20
    arc_0_17_6  connected_order_arc_692  -15
    arc_0_17_6  in_degree_853  1
    arc_0_17_6  out_degree_877  1
    arc_0_17_6  original_T_including_depot_unload_912  1.3251252487627862e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_6  arc_capacity_691  1
    load_0_17_6  segment_load_conservation_856  -1
    load_0_17_6  segment_prefix_lb_857  1
    load_0_17_6  segment_prefix_ub_858  1
    load_0_17_6  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_693  -20
    arc_0_17_14  connected_order_arc_694  -15
    arc_0_17_14  in_degree_860  1
    arc_0_17_14  out_degree_877  1
    arc_0_17_14  original_T_including_depot_unload_912  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_693  1
    load_0_17_14  free_load_conservation_864  -1
    load_0_17_14  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_695  -20
    arc_0_17_15  connected_order_arc_696  -15
    arc_0_17_15  in_degree_866  1
    arc_0_17_15  out_degree_877  1
    arc_0_17_15  original_T_including_depot_unload_912  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_695  1
    load_0_17_15  free_load_conservation_870  -1
    load_0_17_15  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_697  -20
    arc_0_17_16  connected_order_arc_698  -15
    arc_0_17_16  in_degree_872  1
    arc_0_17_16  out_degree_877  1
    arc_0_17_16  original_T_including_depot_unload_912  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_697  1
    load_0_17_16  free_load_conservation_876  -1
    load_0_17_16  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_699  -20
    arc_0_17_18  connected_order_arc_700  -15
    arc_0_17_18  out_degree_877  1
    arc_0_17_18  in_degree_884  1
    arc_0_17_18  original_T_including_depot_unload_912  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_699  1
    load_0_17_18  free_load_conservation_882  1
    load_0_17_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_701  -20
    arc_0_17_19  connected_order_arc_702  -15
    arc_0_17_19  out_degree_877  1
    arc_0_17_19  in_degree_890  1
    arc_0_17_19  original_T_including_depot_unload_912  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_701  1
    load_0_17_19  free_load_conservation_882  1
    load_0_17_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_703  -20
    arc_0_17_20  connected_order_arc_704  -15
    arc_0_17_20  out_degree_877  1
    arc_0_17_20  in_degree_896  1
    arc_0_17_20  original_T_including_depot_unload_912  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_703  1
    load_0_17_20  free_load_conservation_882  1
    load_0_17_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_705  -20
    arc_0_17_21  connected_order_arc_706  -15
    arc_0_17_21  out_degree_877  1
    arc_0_17_21  in_degree_902  1
    arc_0_17_21  original_T_including_depot_unload_912  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_705  1
    load_0_17_21  free_load_conservation_882  1
    load_0_17_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_707  -20
    arc_0_18_0  depot_return_or_bypass_816  1
    arc_0_18_0  out_degree_883  1
    arc_0_18_0  original_T_including_depot_unload_912  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_707  1
    load_0_18_0  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_708  -20
    arc_0_18_1  connected_order_arc_709  -15
    arc_0_18_1  in_degree_818  1
    arc_0_18_1  out_degree_883  1
    arc_0_18_1  original_T_including_depot_unload_912  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_708  1
    load_0_18_1  segment_load_conservation_821  -1
    load_0_18_1  segment_prefix_lb_822  1
    load_0_18_1  segment_prefix_ub_823  1
    load_0_18_1  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_710  -20
    arc_0_18_2  connected_order_arc_711  -15
    arc_0_18_2  in_degree_825  1
    arc_0_18_2  out_degree_883  1
    arc_0_18_2  original_T_including_depot_unload_912  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_710  1
    load_0_18_2  segment_load_conservation_828  -1
    load_0_18_2  segment_prefix_lb_829  1
    load_0_18_2  segment_prefix_ub_830  1
    load_0_18_2  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_712  -20
    arc_0_18_3  connected_order_arc_713  -15
    arc_0_18_3  in_degree_832  1
    arc_0_18_3  out_degree_883  1
    arc_0_18_3  original_T_including_depot_unload_912  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_712  1
    load_0_18_3  segment_load_conservation_835  -1
    load_0_18_3  segment_prefix_lb_836  1
    load_0_18_3  segment_prefix_ub_837  1
    load_0_18_3  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_714  -20
    arc_0_18_4  connected_order_arc_715  -15
    arc_0_18_4  in_degree_839  1
    arc_0_18_4  out_degree_883  1
    arc_0_18_4  original_T_including_depot_unload_912  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_714  1
    load_0_18_4  segment_load_conservation_842  -1
    load_0_18_4  segment_prefix_lb_843  1
    load_0_18_4  segment_prefix_ub_844  1
    load_0_18_4  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_716  -20
    arc_0_18_5  connected_order_arc_717  -15
    arc_0_18_5  in_degree_846  1
    arc_0_18_5  out_degree_883  1
    arc_0_18_5  original_T_including_depot_unload_912  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_716  1
    load_0_18_5  segment_load_conservation_849  -1
    load_0_18_5  segment_prefix_lb_850  1
    load_0_18_5  segment_prefix_ub_851  1
    load_0_18_5  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_6  arc_capacity_718  -20
    arc_0_18_6  connected_order_arc_719  -15
    arc_0_18_6  in_degree_853  1
    arc_0_18_6  out_degree_883  1
    arc_0_18_6  original_T_including_depot_unload_912  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_6  arc_capacity_718  1
    load_0_18_6  segment_load_conservation_856  -1
    load_0_18_6  segment_prefix_lb_857  1
    load_0_18_6  segment_prefix_ub_858  1
    load_0_18_6  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_720  -20
    arc_0_18_14  connected_order_arc_721  -15
    arc_0_18_14  in_degree_860  1
    arc_0_18_14  out_degree_883  1
    arc_0_18_14  original_T_including_depot_unload_912  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_720  1
    load_0_18_14  free_load_conservation_864  -1
    load_0_18_14  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_722  -20
    arc_0_18_15  connected_order_arc_723  -15
    arc_0_18_15  in_degree_866  1
    arc_0_18_15  out_degree_883  1
    arc_0_18_15  original_T_including_depot_unload_912  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_722  1
    load_0_18_15  free_load_conservation_870  -1
    load_0_18_15  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_724  -20
    arc_0_18_16  connected_order_arc_725  -15
    arc_0_18_16  in_degree_872  1
    arc_0_18_16  out_degree_883  1
    arc_0_18_16  original_T_including_depot_unload_912  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_724  1
    load_0_18_16  free_load_conservation_876  -1
    load_0_18_16  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_726  -20
    arc_0_18_17  connected_order_arc_727  -15
    arc_0_18_17  in_degree_878  1
    arc_0_18_17  out_degree_883  1
    arc_0_18_17  original_T_including_depot_unload_912  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_726  1
    load_0_18_17  free_load_conservation_882  -1
    load_0_18_17  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_728  -20
    arc_0_18_19  connected_order_arc_729  -15
    arc_0_18_19  out_degree_883  1
    arc_0_18_19  in_degree_890  1
    arc_0_18_19  original_T_including_depot_unload_912  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_728  1
    load_0_18_19  free_load_conservation_888  1
    load_0_18_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_730  -20
    arc_0_18_20  connected_order_arc_731  -15
    arc_0_18_20  out_degree_883  1
    arc_0_18_20  in_degree_896  1
    arc_0_18_20  original_T_including_depot_unload_912  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_730  1
    load_0_18_20  free_load_conservation_888  1
    load_0_18_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_732  -20
    arc_0_18_21  connected_order_arc_733  -15
    arc_0_18_21  out_degree_883  1
    arc_0_18_21  in_degree_902  1
    arc_0_18_21  original_T_including_depot_unload_912  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_732  1
    load_0_18_21  free_load_conservation_888  1
    load_0_18_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_734  -20
    arc_0_19_0  depot_return_or_bypass_816  1
    arc_0_19_0  out_degree_889  1
    arc_0_19_0  original_T_including_depot_unload_912  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_734  1
    load_0_19_0  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_735  -20
    arc_0_19_1  connected_order_arc_736  -15
    arc_0_19_1  in_degree_818  1
    arc_0_19_1  out_degree_889  1
    arc_0_19_1  original_T_including_depot_unload_912  7.8495921746600118e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_735  1
    load_0_19_1  segment_load_conservation_821  -1
    load_0_19_1  segment_prefix_lb_822  1
    load_0_19_1  segment_prefix_ub_823  1
    load_0_19_1  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_737  -20
    arc_0_19_2  connected_order_arc_738  -15
    arc_0_19_2  in_degree_825  1
    arc_0_19_2  out_degree_889  1
    arc_0_19_2  original_T_including_depot_unload_912  7.1006591329511764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_737  1
    load_0_19_2  segment_load_conservation_828  -1
    load_0_19_2  segment_prefix_lb_829  1
    load_0_19_2  segment_prefix_ub_830  1
    load_0_19_2  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_739  -20
    arc_0_19_3  connected_order_arc_740  -15
    arc_0_19_3  in_degree_832  1
    arc_0_19_3  out_degree_889  1
    arc_0_19_3  original_T_including_depot_unload_912  9.2153450304618127e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_739  1
    load_0_19_3  segment_load_conservation_835  -1
    load_0_19_3  segment_prefix_lb_836  1
    load_0_19_3  segment_prefix_ub_837  1
    load_0_19_3  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_741  -20
    arc_0_19_4  connected_order_arc_742  -15
    arc_0_19_4  in_degree_839  1
    arc_0_19_4  out_degree_889  1
    arc_0_19_4  original_T_including_depot_unload_912  1.0213043329444467e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_741  1
    load_0_19_4  segment_load_conservation_842  -1
    load_0_19_4  segment_prefix_lb_843  1
    load_0_19_4  segment_prefix_ub_844  1
    load_0_19_4  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_743  -20
    arc_0_19_5  connected_order_arc_744  -15
    arc_0_19_5  in_degree_846  1
    arc_0_19_5  out_degree_889  1
    arc_0_19_5  original_T_including_depot_unload_912  1.2628291878233333e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_743  1
    load_0_19_5  segment_load_conservation_849  -1
    load_0_19_5  segment_prefix_lb_850  1
    load_0_19_5  segment_prefix_ub_851  1
    load_0_19_5  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_6  arc_capacity_745  -20
    arc_0_19_6  connected_order_arc_746  -15
    arc_0_19_6  in_degree_853  1
    arc_0_19_6  out_degree_889  1
    arc_0_19_6  original_T_including_depot_unload_912  1.4099802576911704e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_6  arc_capacity_745  1
    load_0_19_6  segment_load_conservation_856  -1
    load_0_19_6  segment_prefix_lb_857  1
    load_0_19_6  segment_prefix_ub_858  1
    load_0_19_6  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_747  -20
    arc_0_19_14  connected_order_arc_748  -15
    arc_0_19_14  in_degree_860  1
    arc_0_19_14  out_degree_889  1
    arc_0_19_14  original_T_including_depot_unload_912  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_747  1
    load_0_19_14  free_load_conservation_864  -1
    load_0_19_14  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_749  -20
    arc_0_19_15  connected_order_arc_750  -15
    arc_0_19_15  in_degree_866  1
    arc_0_19_15  out_degree_889  1
    arc_0_19_15  original_T_including_depot_unload_912  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_749  1
    load_0_19_15  free_load_conservation_870  -1
    load_0_19_15  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_751  -20
    arc_0_19_16  connected_order_arc_752  -15
    arc_0_19_16  in_degree_872  1
    arc_0_19_16  out_degree_889  1
    arc_0_19_16  original_T_including_depot_unload_912  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_751  1
    load_0_19_16  free_load_conservation_876  -1
    load_0_19_16  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_753  -20
    arc_0_19_17  connected_order_arc_754  -15
    arc_0_19_17  in_degree_878  1
    arc_0_19_17  out_degree_889  1
    arc_0_19_17  original_T_including_depot_unload_912  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_753  1
    load_0_19_17  free_load_conservation_882  -1
    load_0_19_17  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_755  -20
    arc_0_19_18  connected_order_arc_756  -15
    arc_0_19_18  in_degree_884  1
    arc_0_19_18  out_degree_889  1
    arc_0_19_18  original_T_including_depot_unload_912  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_755  1
    load_0_19_18  free_load_conservation_888  -1
    load_0_19_18  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_757  -20
    arc_0_19_20  connected_order_arc_758  -15
    arc_0_19_20  out_degree_889  1
    arc_0_19_20  in_degree_896  1
    arc_0_19_20  original_T_including_depot_unload_912  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_757  1
    load_0_19_20  free_load_conservation_894  1
    load_0_19_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_759  -20
    arc_0_19_21  connected_order_arc_760  -15
    arc_0_19_21  out_degree_889  1
    arc_0_19_21  in_degree_902  1
    arc_0_19_21  original_T_including_depot_unload_912  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_759  1
    load_0_19_21  free_load_conservation_894  1
    load_0_19_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_761  -20
    arc_0_20_0  depot_return_or_bypass_816  1
    arc_0_20_0  out_degree_895  1
    arc_0_20_0  original_T_including_depot_unload_912  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_761  1
    load_0_20_0  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_762  -20
    arc_0_20_1  connected_order_arc_763  -15
    arc_0_20_1  in_degree_818  1
    arc_0_20_1  out_degree_895  1
    arc_0_20_1  original_T_including_depot_unload_912  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_762  1
    load_0_20_1  segment_load_conservation_821  -1
    load_0_20_1  segment_prefix_lb_822  1
    load_0_20_1  segment_prefix_ub_823  1
    load_0_20_1  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_764  -20
    arc_0_20_2  connected_order_arc_765  -15
    arc_0_20_2  in_degree_825  1
    arc_0_20_2  out_degree_895  1
    arc_0_20_2  original_T_including_depot_unload_912  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_764  1
    load_0_20_2  segment_load_conservation_828  -1
    load_0_20_2  segment_prefix_lb_829  1
    load_0_20_2  segment_prefix_ub_830  1
    load_0_20_2  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_766  -20
    arc_0_20_3  connected_order_arc_767  -15
    arc_0_20_3  in_degree_832  1
    arc_0_20_3  out_degree_895  1
    arc_0_20_3  original_T_including_depot_unload_912  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_766  1
    load_0_20_3  segment_load_conservation_835  -1
    load_0_20_3  segment_prefix_lb_836  1
    load_0_20_3  segment_prefix_ub_837  1
    load_0_20_3  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_768  -20
    arc_0_20_4  connected_order_arc_769  -15
    arc_0_20_4  in_degree_839  1
    arc_0_20_4  out_degree_895  1
    arc_0_20_4  original_T_including_depot_unload_912  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_768  1
    load_0_20_4  segment_load_conservation_842  -1
    load_0_20_4  segment_prefix_lb_843  1
    load_0_20_4  segment_prefix_ub_844  1
    load_0_20_4  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_770  -20
    arc_0_20_5  connected_order_arc_771  -15
    arc_0_20_5  in_degree_846  1
    arc_0_20_5  out_degree_895  1
    arc_0_20_5  original_T_including_depot_unload_912  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_770  1
    load_0_20_5  segment_load_conservation_849  -1
    load_0_20_5  segment_prefix_lb_850  1
    load_0_20_5  segment_prefix_ub_851  1
    load_0_20_5  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_6  arc_capacity_772  -20
    arc_0_20_6  connected_order_arc_773  -15
    arc_0_20_6  in_degree_853  1
    arc_0_20_6  out_degree_895  1
    arc_0_20_6  original_T_including_depot_unload_912  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_6  arc_capacity_772  1
    load_0_20_6  segment_load_conservation_856  -1
    load_0_20_6  segment_prefix_lb_857  1
    load_0_20_6  segment_prefix_ub_858  1
    load_0_20_6  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_774  -20
    arc_0_20_14  connected_order_arc_775  -15
    arc_0_20_14  in_degree_860  1
    arc_0_20_14  out_degree_895  1
    arc_0_20_14  original_T_including_depot_unload_912  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_774  1
    load_0_20_14  free_load_conservation_864  -1
    load_0_20_14  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_776  -20
    arc_0_20_15  connected_order_arc_777  -15
    arc_0_20_15  in_degree_866  1
    arc_0_20_15  out_degree_895  1
    arc_0_20_15  original_T_including_depot_unload_912  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_776  1
    load_0_20_15  free_load_conservation_870  -1
    load_0_20_15  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_778  -20
    arc_0_20_16  connected_order_arc_779  -15
    arc_0_20_16  in_degree_872  1
    arc_0_20_16  out_degree_895  1
    arc_0_20_16  original_T_including_depot_unload_912  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_778  1
    load_0_20_16  free_load_conservation_876  -1
    load_0_20_16  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_780  -20
    arc_0_20_17  connected_order_arc_781  -15
    arc_0_20_17  in_degree_878  1
    arc_0_20_17  out_degree_895  1
    arc_0_20_17  original_T_including_depot_unload_912  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_780  1
    load_0_20_17  free_load_conservation_882  -1
    load_0_20_17  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_782  -20
    arc_0_20_18  connected_order_arc_783  -15
    arc_0_20_18  in_degree_884  1
    arc_0_20_18  out_degree_895  1
    arc_0_20_18  original_T_including_depot_unload_912  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_782  1
    load_0_20_18  free_load_conservation_888  -1
    load_0_20_18  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_784  -20
    arc_0_20_19  connected_order_arc_785  -15
    arc_0_20_19  in_degree_890  1
    arc_0_20_19  out_degree_895  1
    arc_0_20_19  original_T_including_depot_unload_912  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_784  1
    load_0_20_19  free_load_conservation_894  -1
    load_0_20_19  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_786  -20
    arc_0_20_21  connected_order_arc_787  -15
    arc_0_20_21  out_degree_895  1
    arc_0_20_21  in_degree_902  1
    arc_0_20_21  original_T_including_depot_unload_912  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_786  1
    load_0_20_21  free_load_conservation_900  1
    load_0_20_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_788  -20
    arc_0_21_0  depot_return_or_bypass_816  1
    arc_0_21_0  out_degree_901  1
    arc_0_21_0  original_T_including_depot_unload_912  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_788  1
    load_0_21_0  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_789  -20
    arc_0_21_1  connected_order_arc_790  -15
    arc_0_21_1  in_degree_818  1
    arc_0_21_1  out_degree_901  1
    arc_0_21_1  original_T_including_depot_unload_912  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_789  1
    load_0_21_1  segment_load_conservation_821  -1
    load_0_21_1  segment_prefix_lb_822  1
    load_0_21_1  segment_prefix_ub_823  1
    load_0_21_1  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_791  -20
    arc_0_21_2  connected_order_arc_792  -15
    arc_0_21_2  in_degree_825  1
    arc_0_21_2  out_degree_901  1
    arc_0_21_2  original_T_including_depot_unload_912  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_791  1
    load_0_21_2  segment_load_conservation_828  -1
    load_0_21_2  segment_prefix_lb_829  1
    load_0_21_2  segment_prefix_ub_830  1
    load_0_21_2  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_793  -20
    arc_0_21_3  connected_order_arc_794  -15
    arc_0_21_3  in_degree_832  1
    arc_0_21_3  out_degree_901  1
    arc_0_21_3  original_T_including_depot_unload_912  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_793  1
    load_0_21_3  segment_load_conservation_835  -1
    load_0_21_3  segment_prefix_lb_836  1
    load_0_21_3  segment_prefix_ub_837  1
    load_0_21_3  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_795  -20
    arc_0_21_4  connected_order_arc_796  -15
    arc_0_21_4  in_degree_839  1
    arc_0_21_4  out_degree_901  1
    arc_0_21_4  original_T_including_depot_unload_912  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_795  1
    load_0_21_4  segment_load_conservation_842  -1
    load_0_21_4  segment_prefix_lb_843  1
    load_0_21_4  segment_prefix_ub_844  1
    load_0_21_4  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_797  -20
    arc_0_21_5  connected_order_arc_798  -15
    arc_0_21_5  in_degree_846  1
    arc_0_21_5  out_degree_901  1
    arc_0_21_5  original_T_including_depot_unload_912  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_797  1
    load_0_21_5  segment_load_conservation_849  -1
    load_0_21_5  segment_prefix_lb_850  1
    load_0_21_5  segment_prefix_ub_851  1
    load_0_21_5  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_6  arc_capacity_799  -20
    arc_0_21_6  connected_order_arc_800  -15
    arc_0_21_6  in_degree_853  1
    arc_0_21_6  out_degree_901  1
    arc_0_21_6  original_T_including_depot_unload_912  750.067997850428
    MARKER    'MARKER'                 'INTEND'
    load_0_21_6  arc_capacity_799  1
    load_0_21_6  segment_load_conservation_856  -1
    load_0_21_6  segment_prefix_lb_857  1
    load_0_21_6  segment_prefix_ub_858  1
    load_0_21_6  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_14  arc_capacity_801  -20
    arc_0_21_14  connected_order_arc_802  -15
    arc_0_21_14  in_degree_860  1
    arc_0_21_14  out_degree_901  1
    arc_0_21_14  original_T_including_depot_unload_912  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_14  arc_capacity_801  1
    load_0_21_14  free_load_conservation_864  -1
    load_0_21_14  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_803  -20
    arc_0_21_15  connected_order_arc_804  -15
    arc_0_21_15  in_degree_866  1
    arc_0_21_15  out_degree_901  1
    arc_0_21_15  original_T_including_depot_unload_912  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_803  1
    load_0_21_15  free_load_conservation_870  -1
    load_0_21_15  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_805  -20
    arc_0_21_16  connected_order_arc_806  -15
    arc_0_21_16  in_degree_872  1
    arc_0_21_16  out_degree_901  1
    arc_0_21_16  original_T_including_depot_unload_912  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_805  1
    load_0_21_16  free_load_conservation_876  -1
    load_0_21_16  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_807  -20
    arc_0_21_17  connected_order_arc_808  -15
    arc_0_21_17  in_degree_878  1
    arc_0_21_17  out_degree_901  1
    arc_0_21_17  original_T_including_depot_unload_912  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_807  1
    load_0_21_17  free_load_conservation_882  -1
    load_0_21_17  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_809  -20
    arc_0_21_18  connected_order_arc_810  -15
    arc_0_21_18  in_degree_884  1
    arc_0_21_18  out_degree_901  1
    arc_0_21_18  original_T_including_depot_unload_912  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_809  1
    load_0_21_18  free_load_conservation_888  -1
    load_0_21_18  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_811  -20
    arc_0_21_19  connected_order_arc_812  -15
    arc_0_21_19  in_degree_890  1
    arc_0_21_19  out_degree_901  1
    arc_0_21_19  original_T_including_depot_unload_912  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_811  1
    load_0_21_19  free_load_conservation_894  -1
    load_0_21_19  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_813  -20
    arc_0_21_20  connected_order_arc_814  -15
    arc_0_21_20  in_degree_896  1
    arc_0_21_20  out_degree_901  1
    arc_0_21_20  original_T_including_depot_unload_912  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_813  1
    load_0_21_20  free_load_conservation_900  -1
    load_0_21_20  free_load_conservation_906  1
    visit_1_7  out_degree_1204  -1
    visit_1_7  in_degree_1205  -1
    visit_1_7  order_active_lb_1206  -1
    visit_1_7  order_active_ub_1207  -12
    order_1_7  connected_order_arc_928  -1
    order_1_7  connected_order_arc_930  -1
    order_1_7  connected_order_arc_932  -1
    order_1_7  connected_order_arc_934  -1
    order_1_7  connected_order_arc_936  -1
    order_1_7  connected_order_arc_938  -1
    order_1_7  connected_order_arc_940  -1
    order_1_7  connected_order_arc_942  -1
    order_1_7  connected_order_arc_944  -1
    order_1_7  connected_order_arc_946  -1
    order_1_7  connected_order_arc_948  -1
    order_1_7  connected_order_arc_951  1
    order_1_7  connected_order_arc_974  1
    order_1_7  connected_order_arc_997  1
    order_1_7  connected_order_arc_1020  1
    order_1_7  connected_order_arc_1043  1
    order_1_7  connected_order_arc_1066  1
    order_1_7  connected_order_arc_1089  1
    order_1_7  connected_order_arc_1112  1
    order_1_7  connected_order_arc_1135  1
    order_1_7  connected_order_arc_1158  1
    order_1_7  connected_order_arc_1181  1
    order_1_7  order_active_lb_1206  1
    order_1_7  order_active_ub_1207  1
    order_1_7  fixed_segment_relative_order_1280  -1
    visit_1_8  out_degree_1211  -1
    visit_1_8  in_degree_1212  -1
    visit_1_8  order_active_lb_1213  -1
    visit_1_8  order_active_ub_1214  -12
    order_1_8  connected_order_arc_928  1
    order_1_8  connected_order_arc_951  -1
    order_1_8  connected_order_arc_953  -1
    order_1_8  connected_order_arc_955  -1
    order_1_8  connected_order_arc_957  -1
    order_1_8  connected_order_arc_959  -1
    order_1_8  connected_order_arc_961  -1
    order_1_8  connected_order_arc_963  -1
    order_1_8  connected_order_arc_965  -1
    order_1_8  connected_order_arc_967  -1
    order_1_8  connected_order_arc_969  -1
    order_1_8  connected_order_arc_971  -1
    order_1_8  connected_order_arc_976  1
    order_1_8  connected_order_arc_999  1
    order_1_8  connected_order_arc_1022  1
    order_1_8  connected_order_arc_1045  1
    order_1_8  connected_order_arc_1068  1
    order_1_8  connected_order_arc_1091  1
    order_1_8  connected_order_arc_1114  1
    order_1_8  connected_order_arc_1137  1
    order_1_8  connected_order_arc_1160  1
    order_1_8  connected_order_arc_1183  1
    order_1_8  order_active_lb_1213  1
    order_1_8  order_active_ub_1214  1
    order_1_8  fixed_segment_relative_order_1280  1
    order_1_8  fixed_segment_relative_order_1281  -1
    visit_1_9  out_degree_1218  -1
    visit_1_9  in_degree_1219  -1
    visit_1_9  order_active_lb_1220  -1
    visit_1_9  order_active_ub_1221  -12
    order_1_9  connected_order_arc_930  1
    order_1_9  connected_order_arc_953  1
    order_1_9  connected_order_arc_974  -1
    order_1_9  connected_order_arc_976  -1
    order_1_9  connected_order_arc_978  -1
    order_1_9  connected_order_arc_980  -1
    order_1_9  connected_order_arc_982  -1
    order_1_9  connected_order_arc_984  -1
    order_1_9  connected_order_arc_986  -1
    order_1_9  connected_order_arc_988  -1
    order_1_9  connected_order_arc_990  -1
    order_1_9  connected_order_arc_992  -1
    order_1_9  connected_order_arc_994  -1
    order_1_9  connected_order_arc_1001  1
    order_1_9  connected_order_arc_1024  1
    order_1_9  connected_order_arc_1047  1
    order_1_9  connected_order_arc_1070  1
    order_1_9  connected_order_arc_1093  1
    order_1_9  connected_order_arc_1116  1
    order_1_9  connected_order_arc_1139  1
    order_1_9  connected_order_arc_1162  1
    order_1_9  connected_order_arc_1185  1
    order_1_9  order_active_lb_1220  1
    order_1_9  order_active_ub_1221  1
    order_1_9  fixed_segment_relative_order_1281  1
    order_1_9  fixed_segment_relative_order_1282  -1
    visit_1_10  out_degree_1225  -1
    visit_1_10  in_degree_1226  -1
    visit_1_10  order_active_lb_1227  -1
    visit_1_10  order_active_ub_1228  -12
    order_1_10  connected_order_arc_932  1
    order_1_10  connected_order_arc_955  1
    order_1_10  connected_order_arc_978  1
    order_1_10  connected_order_arc_997  -1
    order_1_10  connected_order_arc_999  -1
    order_1_10  connected_order_arc_1001  -1
    order_1_10  connected_order_arc_1003  -1
    order_1_10  connected_order_arc_1005  -1
    order_1_10  connected_order_arc_1007  -1
    order_1_10  connected_order_arc_1009  -1
    order_1_10  connected_order_arc_1011  -1
    order_1_10  connected_order_arc_1013  -1
    order_1_10  connected_order_arc_1015  -1
    order_1_10  connected_order_arc_1017  -1
    order_1_10  connected_order_arc_1026  1
    order_1_10  connected_order_arc_1049  1
    order_1_10  connected_order_arc_1072  1
    order_1_10  connected_order_arc_1095  1
    order_1_10  connected_order_arc_1118  1
    order_1_10  connected_order_arc_1141  1
    order_1_10  connected_order_arc_1164  1
    order_1_10  connected_order_arc_1187  1
    order_1_10  order_active_lb_1227  1
    order_1_10  order_active_ub_1228  1
    order_1_10  fixed_segment_relative_order_1282  1
    visit_1_14  out_degree_1232  -1
    visit_1_14  in_degree_1233  -1
    visit_1_14  order_active_lb_1234  -1
    visit_1_14  order_active_ub_1235  -12
    visit_1_14  service_visit_def_1236  -1
    order_1_14  connected_order_arc_934  1
    order_1_14  connected_order_arc_957  1
    order_1_14  connected_order_arc_980  1
    order_1_14  connected_order_arc_1003  1
    order_1_14  connected_order_arc_1020  -1
    order_1_14  connected_order_arc_1022  -1
    order_1_14  connected_order_arc_1024  -1
    order_1_14  connected_order_arc_1026  -1
    order_1_14  connected_order_arc_1028  -1
    order_1_14  connected_order_arc_1030  -1
    order_1_14  connected_order_arc_1032  -1
    order_1_14  connected_order_arc_1034  -1
    order_1_14  connected_order_arc_1036  -1
    order_1_14  connected_order_arc_1038  -1
    order_1_14  connected_order_arc_1040  -1
    order_1_14  connected_order_arc_1051  1
    order_1_14  connected_order_arc_1074  1
    order_1_14  connected_order_arc_1097  1
    order_1_14  connected_order_arc_1120  1
    order_1_14  connected_order_arc_1143  1
    order_1_14  connected_order_arc_1166  1
    order_1_14  connected_order_arc_1189  1
    order_1_14  order_active_lb_1234  1
    order_1_14  order_active_ub_1235  1
    visit_1_15  out_degree_1238  -1
    visit_1_15  in_degree_1239  -1
    visit_1_15  order_active_lb_1240  -1
    visit_1_15  order_active_ub_1241  -12
    visit_1_15  service_visit_def_1242  -1
    order_1_15  connected_order_arc_936  1
    order_1_15  connected_order_arc_959  1
    order_1_15  connected_order_arc_982  1
    order_1_15  connected_order_arc_1005  1
    order_1_15  connected_order_arc_1028  1
    order_1_15  connected_order_arc_1043  -1
    order_1_15  connected_order_arc_1045  -1
    order_1_15  connected_order_arc_1047  -1
    order_1_15  connected_order_arc_1049  -1
    order_1_15  connected_order_arc_1051  -1
    order_1_15  connected_order_arc_1053  -1
    order_1_15  connected_order_arc_1055  -1
    order_1_15  connected_order_arc_1057  -1
    order_1_15  connected_order_arc_1059  -1
    order_1_15  connected_order_arc_1061  -1
    order_1_15  connected_order_arc_1063  -1
    order_1_15  connected_order_arc_1076  1
    order_1_15  connected_order_arc_1099  1
    order_1_15  connected_order_arc_1122  1
    order_1_15  connected_order_arc_1145  1
    order_1_15  connected_order_arc_1168  1
    order_1_15  connected_order_arc_1191  1
    order_1_15  order_active_lb_1240  1
    order_1_15  order_active_ub_1241  1
    visit_1_16  out_degree_1244  -1
    visit_1_16  in_degree_1245  -1
    visit_1_16  order_active_lb_1246  -1
    visit_1_16  order_active_ub_1247  -12
    visit_1_16  service_visit_def_1248  -1
    order_1_16  connected_order_arc_938  1
    order_1_16  connected_order_arc_961  1
    order_1_16  connected_order_arc_984  1
    order_1_16  connected_order_arc_1007  1
    order_1_16  connected_order_arc_1030  1
    order_1_16  connected_order_arc_1053  1
    order_1_16  connected_order_arc_1066  -1
    order_1_16  connected_order_arc_1068  -1
    order_1_16  connected_order_arc_1070  -1
    order_1_16  connected_order_arc_1072  -1
    order_1_16  connected_order_arc_1074  -1
    order_1_16  connected_order_arc_1076  -1
    order_1_16  connected_order_arc_1078  -1
    order_1_16  connected_order_arc_1080  -1
    order_1_16  connected_order_arc_1082  -1
    order_1_16  connected_order_arc_1084  -1
    order_1_16  connected_order_arc_1086  -1
    order_1_16  connected_order_arc_1101  1
    order_1_16  connected_order_arc_1124  1
    order_1_16  connected_order_arc_1147  1
    order_1_16  connected_order_arc_1170  1
    order_1_16  connected_order_arc_1193  1
    order_1_16  order_active_lb_1246  1
    order_1_16  order_active_ub_1247  1
    visit_1_17  out_degree_1250  -1
    visit_1_17  in_degree_1251  -1
    visit_1_17  order_active_lb_1252  -1
    visit_1_17  order_active_ub_1253  -12
    visit_1_17  service_visit_def_1254  -1
    order_1_17  connected_order_arc_940  1
    order_1_17  connected_order_arc_963  1
    order_1_17  connected_order_arc_986  1
    order_1_17  connected_order_arc_1009  1
    order_1_17  connected_order_arc_1032  1
    order_1_17  connected_order_arc_1055  1
    order_1_17  connected_order_arc_1078  1
    order_1_17  connected_order_arc_1089  -1
    order_1_17  connected_order_arc_1091  -1
    order_1_17  connected_order_arc_1093  -1
    order_1_17  connected_order_arc_1095  -1
    order_1_17  connected_order_arc_1097  -1
    order_1_17  connected_order_arc_1099  -1
    order_1_17  connected_order_arc_1101  -1
    order_1_17  connected_order_arc_1103  -1
    order_1_17  connected_order_arc_1105  -1
    order_1_17  connected_order_arc_1107  -1
    order_1_17  connected_order_arc_1109  -1
    order_1_17  connected_order_arc_1126  1
    order_1_17  connected_order_arc_1149  1
    order_1_17  connected_order_arc_1172  1
    order_1_17  connected_order_arc_1195  1
    order_1_17  order_active_lb_1252  1
    order_1_17  order_active_ub_1253  1
    visit_1_18  out_degree_1256  -1
    visit_1_18  in_degree_1257  -1
    visit_1_18  order_active_lb_1258  -1
    visit_1_18  order_active_ub_1259  -12
    visit_1_18  service_visit_def_1260  -1
    order_1_18  connected_order_arc_942  1
    order_1_18  connected_order_arc_965  1
    order_1_18  connected_order_arc_988  1
    order_1_18  connected_order_arc_1011  1
    order_1_18  connected_order_arc_1034  1
    order_1_18  connected_order_arc_1057  1
    order_1_18  connected_order_arc_1080  1
    order_1_18  connected_order_arc_1103  1
    order_1_18  connected_order_arc_1112  -1
    order_1_18  connected_order_arc_1114  -1
    order_1_18  connected_order_arc_1116  -1
    order_1_18  connected_order_arc_1118  -1
    order_1_18  connected_order_arc_1120  -1
    order_1_18  connected_order_arc_1122  -1
    order_1_18  connected_order_arc_1124  -1
    order_1_18  connected_order_arc_1126  -1
    order_1_18  connected_order_arc_1128  -1
    order_1_18  connected_order_arc_1130  -1
    order_1_18  connected_order_arc_1132  -1
    order_1_18  connected_order_arc_1151  1
    order_1_18  connected_order_arc_1174  1
    order_1_18  connected_order_arc_1197  1
    order_1_18  order_active_lb_1258  1
    order_1_18  order_active_ub_1259  1
    visit_1_19  out_degree_1262  -1
    visit_1_19  in_degree_1263  -1
    visit_1_19  order_active_lb_1264  -1
    visit_1_19  order_active_ub_1265  -12
    visit_1_19  service_visit_def_1266  -1
    order_1_19  connected_order_arc_944  1
    order_1_19  connected_order_arc_967  1
    order_1_19  connected_order_arc_990  1
    order_1_19  connected_order_arc_1013  1
    order_1_19  connected_order_arc_1036  1
    order_1_19  connected_order_arc_1059  1
    order_1_19  connected_order_arc_1082  1
    order_1_19  connected_order_arc_1105  1
    order_1_19  connected_order_arc_1128  1
    order_1_19  connected_order_arc_1135  -1
    order_1_19  connected_order_arc_1137  -1
    order_1_19  connected_order_arc_1139  -1
    order_1_19  connected_order_arc_1141  -1
    order_1_19  connected_order_arc_1143  -1
    order_1_19  connected_order_arc_1145  -1
    order_1_19  connected_order_arc_1147  -1
    order_1_19  connected_order_arc_1149  -1
    order_1_19  connected_order_arc_1151  -1
    order_1_19  connected_order_arc_1153  -1
    order_1_19  connected_order_arc_1155  -1
    order_1_19  connected_order_arc_1176  1
    order_1_19  connected_order_arc_1199  1
    order_1_19  order_active_lb_1264  1
    order_1_19  order_active_ub_1265  1
    visit_1_20  out_degree_1268  -1
    visit_1_20  in_degree_1269  -1
    visit_1_20  order_active_lb_1270  -1
    visit_1_20  order_active_ub_1271  -12
    visit_1_20  service_visit_def_1272  -1
    order_1_20  connected_order_arc_946  1
    order_1_20  connected_order_arc_969  1
    order_1_20  connected_order_arc_992  1
    order_1_20  connected_order_arc_1015  1
    order_1_20  connected_order_arc_1038  1
    order_1_20  connected_order_arc_1061  1
    order_1_20  connected_order_arc_1084  1
    order_1_20  connected_order_arc_1107  1
    order_1_20  connected_order_arc_1130  1
    order_1_20  connected_order_arc_1153  1
    order_1_20  connected_order_arc_1158  -1
    order_1_20  connected_order_arc_1160  -1
    order_1_20  connected_order_arc_1162  -1
    order_1_20  connected_order_arc_1164  -1
    order_1_20  connected_order_arc_1166  -1
    order_1_20  connected_order_arc_1168  -1
    order_1_20  connected_order_arc_1170  -1
    order_1_20  connected_order_arc_1172  -1
    order_1_20  connected_order_arc_1174  -1
    order_1_20  connected_order_arc_1176  -1
    order_1_20  connected_order_arc_1178  -1
    order_1_20  connected_order_arc_1201  1
    order_1_20  order_active_lb_1270  1
    order_1_20  order_active_ub_1271  1
    visit_1_21  out_degree_1274  -1
    visit_1_21  in_degree_1275  -1
    visit_1_21  order_active_lb_1276  -1
    visit_1_21  order_active_ub_1277  -12
    visit_1_21  service_visit_def_1278  -1
    order_1_21  connected_order_arc_948  1
    order_1_21  connected_order_arc_971  1
    order_1_21  connected_order_arc_994  1
    order_1_21  connected_order_arc_1017  1
    order_1_21  connected_order_arc_1040  1
    order_1_21  connected_order_arc_1063  1
    order_1_21  connected_order_arc_1086  1
    order_1_21  connected_order_arc_1109  1
    order_1_21  connected_order_arc_1132  1
    order_1_21  connected_order_arc_1155  1
    order_1_21  connected_order_arc_1178  1
    order_1_21  connected_order_arc_1181  -1
    order_1_21  connected_order_arc_1183  -1
    order_1_21  connected_order_arc_1185  -1
    order_1_21  connected_order_arc_1187  -1
    order_1_21  connected_order_arc_1189  -1
    order_1_21  connected_order_arc_1191  -1
    order_1_21  connected_order_arc_1193  -1
    order_1_21  connected_order_arc_1195  -1
    order_1_21  connected_order_arc_1197  -1
    order_1_21  connected_order_arc_1199  -1
    order_1_21  connected_order_arc_1201  -1
    order_1_21  order_active_lb_1276  1
    order_1_21  order_active_ub_1277  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_913  -25
    arc_1_0_0  depot_departure_or_bypass_1202  1
    arc_1_0_0  depot_return_or_bypass_1203  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_913  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_914  -25
    arc_1_0_7  depot_departure_or_bypass_1202  1
    arc_1_0_7  in_degree_1205  1
    arc_1_0_7  original_T_including_depot_unload_1283  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_914  1
    load_1_0_7  segment_load_conservation_1208  -1
    load_1_0_7  segment_prefix_lb_1209  1
    load_1_0_7  segment_prefix_ub_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_915  -25
    arc_1_0_8  depot_departure_or_bypass_1202  1
    arc_1_0_8  in_degree_1212  1
    arc_1_0_8  original_T_including_depot_unload_1283  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_915  1
    load_1_0_8  segment_load_conservation_1215  -1
    load_1_0_8  segment_prefix_lb_1216  1
    load_1_0_8  segment_prefix_ub_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_916  -25
    arc_1_0_9  depot_departure_or_bypass_1202  1
    arc_1_0_9  in_degree_1219  1
    arc_1_0_9  original_T_including_depot_unload_1283  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_916  1
    load_1_0_9  segment_load_conservation_1222  -1
    load_1_0_9  segment_prefix_lb_1223  1
    load_1_0_9  segment_prefix_ub_1224  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_917  -25
    arc_1_0_10  depot_departure_or_bypass_1202  1
    arc_1_0_10  in_degree_1226  1
    arc_1_0_10  original_T_including_depot_unload_1283  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_917  1
    load_1_0_10  segment_load_conservation_1229  -1
    load_1_0_10  segment_prefix_lb_1230  1
    load_1_0_10  segment_prefix_ub_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_918  -25
    arc_1_0_14  depot_departure_or_bypass_1202  1
    arc_1_0_14  in_degree_1233  1
    arc_1_0_14  original_T_including_depot_unload_1283  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_918  1
    load_1_0_14  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_919  -25
    arc_1_0_15  depot_departure_or_bypass_1202  1
    arc_1_0_15  in_degree_1239  1
    arc_1_0_15  original_T_including_depot_unload_1283  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_919  1
    load_1_0_15  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_920  -25
    arc_1_0_16  depot_departure_or_bypass_1202  1
    arc_1_0_16  in_degree_1245  1
    arc_1_0_16  original_T_including_depot_unload_1283  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_920  1
    load_1_0_16  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_921  -25
    arc_1_0_17  depot_departure_or_bypass_1202  1
    arc_1_0_17  in_degree_1251  1
    arc_1_0_17  original_T_including_depot_unload_1283  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_921  1
    load_1_0_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_922  -25
    arc_1_0_18  depot_departure_or_bypass_1202  1
    arc_1_0_18  in_degree_1257  1
    arc_1_0_18  original_T_including_depot_unload_1283  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_922  1
    load_1_0_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_923  -25
    arc_1_0_19  depot_departure_or_bypass_1202  1
    arc_1_0_19  in_degree_1263  1
    arc_1_0_19  original_T_including_depot_unload_1283  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_923  1
    load_1_0_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_924  -25
    arc_1_0_20  depot_departure_or_bypass_1202  1
    arc_1_0_20  in_degree_1269  1
    arc_1_0_20  original_T_including_depot_unload_1283  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_924  1
    load_1_0_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_925  -25
    arc_1_0_21  depot_departure_or_bypass_1202  1
    arc_1_0_21  in_degree_1275  1
    arc_1_0_21  original_T_including_depot_unload_1283  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_925  1
    load_1_0_21  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_926  -25
    arc_1_7_0  depot_return_or_bypass_1203  1
    arc_1_7_0  out_degree_1204  1
    arc_1_7_0  original_T_including_depot_unload_1283  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_926  1
    load_1_7_0  segment_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_927  -25
    arc_1_7_8  connected_order_arc_928  -13
    arc_1_7_8  out_degree_1204  1
    arc_1_7_8  in_degree_1212  1
    arc_1_7_8  original_T_including_depot_unload_1283  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_927  1
    load_1_7_8  segment_load_conservation_1208  1
    load_1_7_8  segment_load_conservation_1215  -1
    load_1_7_8  segment_prefix_lb_1216  1
    load_1_7_8  segment_prefix_ub_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_929  -25
    arc_1_7_9  connected_order_arc_930  -13
    arc_1_7_9  out_degree_1204  1
    arc_1_7_9  in_degree_1219  1
    arc_1_7_9  original_T_including_depot_unload_1283  1.2213551686272770e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_929  1
    load_1_7_9  segment_load_conservation_1208  1
    load_1_7_9  segment_load_conservation_1222  -1
    load_1_7_9  segment_prefix_lb_1223  1
    load_1_7_9  segment_prefix_ub_1224  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_931  -25
    arc_1_7_10  connected_order_arc_932  -13
    arc_1_7_10  out_degree_1204  1
    arc_1_7_10  in_degree_1226  1
    arc_1_7_10  original_T_including_depot_unload_1283  1.0854925215530507e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_931  1
    load_1_7_10  segment_load_conservation_1208  1
    load_1_7_10  segment_load_conservation_1229  -1
    load_1_7_10  segment_prefix_lb_1230  1
    load_1_7_10  segment_prefix_ub_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_933  -25
    arc_1_7_14  connected_order_arc_934  -13
    arc_1_7_14  out_degree_1204  1
    arc_1_7_14  in_degree_1233  1
    arc_1_7_14  original_T_including_depot_unload_1283  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_933  1
    load_1_7_14  segment_load_conservation_1208  1
    load_1_7_14  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_935  -25
    arc_1_7_15  connected_order_arc_936  -13
    arc_1_7_15  out_degree_1204  1
    arc_1_7_15  in_degree_1239  1
    arc_1_7_15  original_T_including_depot_unload_1283  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_935  1
    load_1_7_15  segment_load_conservation_1208  1
    load_1_7_15  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_937  -25
    arc_1_7_16  connected_order_arc_938  -13
    arc_1_7_16  out_degree_1204  1
    arc_1_7_16  in_degree_1245  1
    arc_1_7_16  original_T_including_depot_unload_1283  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_937  1
    load_1_7_16  segment_load_conservation_1208  1
    load_1_7_16  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_939  -25
    arc_1_7_17  connected_order_arc_940  -13
    arc_1_7_17  out_degree_1204  1
    arc_1_7_17  in_degree_1251  1
    arc_1_7_17  original_T_including_depot_unload_1283  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_939  1
    load_1_7_17  segment_load_conservation_1208  1
    load_1_7_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_941  -25
    arc_1_7_18  connected_order_arc_942  -13
    arc_1_7_18  out_degree_1204  1
    arc_1_7_18  in_degree_1257  1
    arc_1_7_18  original_T_including_depot_unload_1283  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_941  1
    load_1_7_18  segment_load_conservation_1208  1
    load_1_7_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_943  -25
    arc_1_7_19  connected_order_arc_944  -13
    arc_1_7_19  out_degree_1204  1
    arc_1_7_19  in_degree_1263  1
    arc_1_7_19  original_T_including_depot_unload_1283  1.0684489086573428e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_943  1
    load_1_7_19  segment_load_conservation_1208  1
    load_1_7_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_945  -25
    arc_1_7_20  connected_order_arc_946  -13
    arc_1_7_20  out_degree_1204  1
    arc_1_7_20  in_degree_1269  1
    arc_1_7_20  original_T_including_depot_unload_1283  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_945  1
    load_1_7_20  segment_load_conservation_1208  1
    load_1_7_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_947  -25
    arc_1_7_21  connected_order_arc_948  -13
    arc_1_7_21  out_degree_1204  1
    arc_1_7_21  in_degree_1275  1
    arc_1_7_21  original_T_including_depot_unload_1283  1.3473071485321755e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_947  1
    load_1_7_21  segment_load_conservation_1208  1
    load_1_7_21  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_949  -25
    arc_1_8_0  depot_return_or_bypass_1203  1
    arc_1_8_0  out_degree_1211  1
    arc_1_8_0  original_T_including_depot_unload_1283  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_949  1
    load_1_8_0  segment_load_conservation_1215  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_950  -25
    arc_1_8_7  connected_order_arc_951  -13
    arc_1_8_7  in_degree_1205  1
    arc_1_8_7  out_degree_1211  1
    arc_1_8_7  original_T_including_depot_unload_1283  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_950  1
    load_1_8_7  segment_load_conservation_1208  -1
    load_1_8_7  segment_prefix_lb_1209  1
    load_1_8_7  segment_prefix_ub_1210  1
    load_1_8_7  segment_load_conservation_1215  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_952  -25
    arc_1_8_9  connected_order_arc_953  -13
    arc_1_8_9  out_degree_1211  1
    arc_1_8_9  in_degree_1219  1
    arc_1_8_9  original_T_including_depot_unload_1283  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_952  1
    load_1_8_9  segment_load_conservation_1215  1
    load_1_8_9  segment_load_conservation_1222  -1
    load_1_8_9  segment_prefix_lb_1223  1
    load_1_8_9  segment_prefix_ub_1224  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_954  -25
    arc_1_8_10  connected_order_arc_955  -13
    arc_1_8_10  out_degree_1211  1
    arc_1_8_10  in_degree_1226  1
    arc_1_8_10  original_T_including_depot_unload_1283  6.0870346483367848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_954  1
    load_1_8_10  segment_load_conservation_1215  1
    load_1_8_10  segment_load_conservation_1229  -1
    load_1_8_10  segment_prefix_lb_1230  1
    load_1_8_10  segment_prefix_ub_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_956  -25
    arc_1_8_14  connected_order_arc_957  -13
    arc_1_8_14  out_degree_1211  1
    arc_1_8_14  in_degree_1233  1
    arc_1_8_14  original_T_including_depot_unload_1283  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_956  1
    load_1_8_14  segment_load_conservation_1215  1
    load_1_8_14  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_958  -25
    arc_1_8_15  connected_order_arc_959  -13
    arc_1_8_15  out_degree_1211  1
    arc_1_8_15  in_degree_1239  1
    arc_1_8_15  original_T_including_depot_unload_1283  1.0910343836035740e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_958  1
    load_1_8_15  segment_load_conservation_1215  1
    load_1_8_15  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_960  -25
    arc_1_8_16  connected_order_arc_961  -13
    arc_1_8_16  out_degree_1211  1
    arc_1_8_16  in_degree_1245  1
    arc_1_8_16  original_T_including_depot_unload_1283  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_960  1
    load_1_8_16  segment_load_conservation_1215  1
    load_1_8_16  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_962  -25
    arc_1_8_17  connected_order_arc_963  -13
    arc_1_8_17  out_degree_1211  1
    arc_1_8_17  in_degree_1251  1
    arc_1_8_17  original_T_including_depot_unload_1283  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_962  1
    load_1_8_17  segment_load_conservation_1215  1
    load_1_8_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_964  -25
    arc_1_8_18  connected_order_arc_965  -13
    arc_1_8_18  out_degree_1211  1
    arc_1_8_18  in_degree_1257  1
    arc_1_8_18  original_T_including_depot_unload_1283  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_964  1
    load_1_8_18  segment_load_conservation_1215  1
    load_1_8_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_966  -25
    arc_1_8_19  connected_order_arc_967  -13
    arc_1_8_19  out_degree_1211  1
    arc_1_8_19  in_degree_1263  1
    arc_1_8_19  original_T_including_depot_unload_1283  6.7554763364087285e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_966  1
    load_1_8_19  segment_load_conservation_1215  1
    load_1_8_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_968  -25
    arc_1_8_20  connected_order_arc_969  -13
    arc_1_8_20  out_degree_1211  1
    arc_1_8_20  in_degree_1269  1
    arc_1_8_20  original_T_including_depot_unload_1283  1.7225744515697754e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_968  1
    load_1_8_20  segment_load_conservation_1215  1
    load_1_8_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_970  -25
    arc_1_8_21  connected_order_arc_971  -13
    arc_1_8_21  out_degree_1211  1
    arc_1_8_21  in_degree_1275  1
    arc_1_8_21  original_T_including_depot_unload_1283  1.3082661182285894e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_970  1
    load_1_8_21  segment_load_conservation_1215  1
    load_1_8_21  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_972  -25
    arc_1_9_0  depot_return_or_bypass_1203  1
    arc_1_9_0  out_degree_1218  1
    arc_1_9_0  original_T_including_depot_unload_1283  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_972  1
    load_1_9_0  segment_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_973  -25
    arc_1_9_7  connected_order_arc_974  -13
    arc_1_9_7  in_degree_1205  1
    arc_1_9_7  out_degree_1218  1
    arc_1_9_7  original_T_including_depot_unload_1283  9.5892865701726816e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_973  1
    load_1_9_7  segment_load_conservation_1208  -1
    load_1_9_7  segment_prefix_lb_1209  1
    load_1_9_7  segment_prefix_ub_1210  1
    load_1_9_7  segment_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_975  -25
    arc_1_9_8  connected_order_arc_976  -13
    arc_1_9_8  in_degree_1212  1
    arc_1_9_8  out_degree_1218  1
    arc_1_9_8  original_T_including_depot_unload_1283  1.3197014959146461e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_975  1
    load_1_9_8  segment_load_conservation_1215  -1
    load_1_9_8  segment_prefix_lb_1216  1
    load_1_9_8  segment_prefix_ub_1217  1
    load_1_9_8  segment_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_977  -25
    arc_1_9_10  connected_order_arc_978  -13
    arc_1_9_10  out_degree_1218  1
    arc_1_9_10  in_degree_1226  1
    arc_1_9_10  original_T_including_depot_unload_1283  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_977  1
    load_1_9_10  segment_load_conservation_1222  1
    load_1_9_10  segment_load_conservation_1229  -1
    load_1_9_10  segment_prefix_lb_1230  1
    load_1_9_10  segment_prefix_ub_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_979  -25
    arc_1_9_14  connected_order_arc_980  -13
    arc_1_9_14  out_degree_1218  1
    arc_1_9_14  in_degree_1233  1
    arc_1_9_14  original_T_including_depot_unload_1283  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_979  1
    load_1_9_14  segment_load_conservation_1222  1
    load_1_9_14  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_981  -25
    arc_1_9_15  connected_order_arc_982  -13
    arc_1_9_15  out_degree_1218  1
    arc_1_9_15  in_degree_1239  1
    arc_1_9_15  original_T_including_depot_unload_1283  8.9356126423557316e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_981  1
    load_1_9_15  segment_load_conservation_1222  1
    load_1_9_15  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_983  -25
    arc_1_9_16  connected_order_arc_984  -13
    arc_1_9_16  out_degree_1218  1
    arc_1_9_16  in_degree_1245  1
    arc_1_9_16  original_T_including_depot_unload_1283  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_983  1
    load_1_9_16  segment_load_conservation_1222  1
    load_1_9_16  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_985  -25
    arc_1_9_17  connected_order_arc_986  -13
    arc_1_9_17  out_degree_1218  1
    arc_1_9_17  in_degree_1251  1
    arc_1_9_17  original_T_including_depot_unload_1283  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_985  1
    load_1_9_17  segment_load_conservation_1222  1
    load_1_9_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_987  -25
    arc_1_9_18  connected_order_arc_988  -13
    arc_1_9_18  out_degree_1218  1
    arc_1_9_18  in_degree_1257  1
    arc_1_9_18  original_T_including_depot_unload_1283  2.5950001064050621e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_987  1
    load_1_9_18  segment_load_conservation_1222  1
    load_1_9_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_989  -25
    arc_1_9_19  connected_order_arc_990  -13
    arc_1_9_19  out_degree_1218  1
    arc_1_9_19  in_degree_1263  1
    arc_1_9_19  original_T_including_depot_unload_1283  4.0010881633455318e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_989  1
    load_1_9_19  segment_load_conservation_1222  1
    load_1_9_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_991  -25
    arc_1_9_20  connected_order_arc_992  -13
    arc_1_9_20  out_degree_1218  1
    arc_1_9_20  in_degree_1269  1
    arc_1_9_20  original_T_including_depot_unload_1283  1.5711351987660353e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_991  1
    load_1_9_20  segment_load_conservation_1222  1
    load_1_9_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_993  -25
    arc_1_9_21  connected_order_arc_994  -13
    arc_1_9_21  out_degree_1218  1
    arc_1_9_21  in_degree_1275  1
    arc_1_9_21  original_T_including_depot_unload_1283  1.0744643606639036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_993  1
    load_1_9_21  segment_load_conservation_1222  1
    load_1_9_21  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_995  -25
    arc_1_10_0  depot_return_or_bypass_1203  1
    arc_1_10_0  out_degree_1225  1
    arc_1_10_0  original_T_including_depot_unload_1283  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_995  1
    load_1_10_0  segment_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_996  -25
    arc_1_10_7  connected_order_arc_997  -13
    arc_1_10_7  in_degree_1205  1
    arc_1_10_7  out_degree_1225  1
    arc_1_10_7  original_T_including_depot_unload_1283  8.0195161088934185e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_996  1
    load_1_10_7  segment_load_conservation_1208  -1
    load_1_10_7  segment_prefix_lb_1209  1
    load_1_10_7  segment_prefix_ub_1210  1
    load_1_10_7  segment_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_998  -25
    arc_1_10_8  connected_order_arc_999  -13
    arc_1_10_8  in_degree_1212  1
    arc_1_10_8  out_degree_1225  1
    arc_1_10_8  original_T_including_depot_unload_1283  1.1360772387139011e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_998  1
    load_1_10_8  segment_load_conservation_1215  -1
    load_1_10_8  segment_prefix_lb_1216  1
    load_1_10_8  segment_prefix_ub_1217  1
    load_1_10_8  segment_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_1000  -25
    arc_1_10_9  connected_order_arc_1001  -13
    arc_1_10_9  in_degree_1219  1
    arc_1_10_9  out_degree_1225  1
    arc_1_10_9  original_T_including_depot_unload_1283  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_1000  1
    load_1_10_9  segment_load_conservation_1222  -1
    load_1_10_9  segment_prefix_lb_1223  1
    load_1_10_9  segment_prefix_ub_1224  1
    load_1_10_9  segment_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_1002  -25
    arc_1_10_14  connected_order_arc_1003  -13
    arc_1_10_14  out_degree_1225  1
    arc_1_10_14  in_degree_1233  1
    arc_1_10_14  original_T_including_depot_unload_1283  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_1002  1
    load_1_10_14  segment_load_conservation_1229  1
    load_1_10_14  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_1004  -25
    arc_1_10_15  connected_order_arc_1005  -13
    arc_1_10_15  out_degree_1225  1
    arc_1_10_15  in_degree_1239  1
    arc_1_10_15  original_T_including_depot_unload_1283  6.0342879231962252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_1004  1
    load_1_10_15  segment_load_conservation_1229  1
    load_1_10_15  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_1006  -25
    arc_1_10_16  connected_order_arc_1007  -13
    arc_1_10_16  out_degree_1225  1
    arc_1_10_16  in_degree_1245  1
    arc_1_10_16  original_T_including_depot_unload_1283  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_1006  1
    load_1_10_16  segment_load_conservation_1229  1
    load_1_10_16  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_1008  -25
    arc_1_10_17  connected_order_arc_1009  -13
    arc_1_10_17  out_degree_1225  1
    arc_1_10_17  in_degree_1251  1
    arc_1_10_17  original_T_including_depot_unload_1283  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_1008  1
    load_1_10_17  segment_load_conservation_1229  1
    load_1_10_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_1010  -25
    arc_1_10_18  connected_order_arc_1011  -13
    arc_1_10_18  out_degree_1225  1
    arc_1_10_18  in_degree_1257  1
    arc_1_10_18  original_T_including_depot_unload_1283  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_1010  1
    load_1_10_18  segment_load_conservation_1229  1
    load_1_10_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_19  arc_capacity_1012  -25
    arc_1_10_19  connected_order_arc_1013  -13
    arc_1_10_19  out_degree_1225  1
    arc_1_10_19  in_degree_1263  1
    arc_1_10_19  original_T_including_depot_unload_1283  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_19  arc_capacity_1012  1
    load_1_10_19  segment_load_conservation_1229  1
    load_1_10_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_20  arc_capacity_1014  -25
    arc_1_10_20  connected_order_arc_1015  -13
    arc_1_10_20  out_degree_1225  1
    arc_1_10_20  in_degree_1269  1
    arc_1_10_20  original_T_including_depot_unload_1283  1.2814005706654932e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_20  arc_capacity_1014  1
    load_1_10_20  segment_load_conservation_1229  1
    load_1_10_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_21  arc_capacity_1016  -25
    arc_1_10_21  connected_order_arc_1017  -13
    arc_1_10_21  out_degree_1225  1
    arc_1_10_21  in_degree_1275  1
    arc_1_10_21  original_T_including_depot_unload_1283  7.9428057689531045e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_21  arc_capacity_1016  1
    load_1_10_21  segment_load_conservation_1229  1
    load_1_10_21  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1018  -25
    arc_1_14_0  depot_return_or_bypass_1203  1
    arc_1_14_0  out_degree_1232  1
    arc_1_14_0  original_T_including_depot_unload_1283  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1018  1
    load_1_14_0  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_1019  -25
    arc_1_14_7  connected_order_arc_1020  -13
    arc_1_14_7  in_degree_1205  1
    arc_1_14_7  out_degree_1232  1
    arc_1_14_7  original_T_including_depot_unload_1283  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_1019  1
    load_1_14_7  segment_load_conservation_1208  -1
    load_1_14_7  segment_prefix_lb_1209  1
    load_1_14_7  segment_prefix_ub_1210  1
    load_1_14_7  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_1021  -25
    arc_1_14_8  connected_order_arc_1022  -13
    arc_1_14_8  in_degree_1212  1
    arc_1_14_8  out_degree_1232  1
    arc_1_14_8  original_T_including_depot_unload_1283  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_1021  1
    load_1_14_8  segment_load_conservation_1215  -1
    load_1_14_8  segment_prefix_lb_1216  1
    load_1_14_8  segment_prefix_ub_1217  1
    load_1_14_8  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1023  -25
    arc_1_14_9  connected_order_arc_1024  -13
    arc_1_14_9  in_degree_1219  1
    arc_1_14_9  out_degree_1232  1
    arc_1_14_9  original_T_including_depot_unload_1283  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1023  1
    load_1_14_9  segment_load_conservation_1222  -1
    load_1_14_9  segment_prefix_lb_1223  1
    load_1_14_9  segment_prefix_ub_1224  1
    load_1_14_9  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_1025  -25
    arc_1_14_10  connected_order_arc_1026  -13
    arc_1_14_10  in_degree_1226  1
    arc_1_14_10  out_degree_1232  1
    arc_1_14_10  original_T_including_depot_unload_1283  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_1025  1
    load_1_14_10  segment_load_conservation_1229  -1
    load_1_14_10  segment_prefix_lb_1230  1
    load_1_14_10  segment_prefix_ub_1231  1
    load_1_14_10  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1027  -25
    arc_1_14_15  connected_order_arc_1028  -13
    arc_1_14_15  out_degree_1232  1
    arc_1_14_15  in_degree_1239  1
    arc_1_14_15  original_T_including_depot_unload_1283  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1027  1
    load_1_14_15  free_load_conservation_1237  1
    load_1_14_15  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1029  -25
    arc_1_14_16  connected_order_arc_1030  -13
    arc_1_14_16  out_degree_1232  1
    arc_1_14_16  in_degree_1245  1
    arc_1_14_16  original_T_including_depot_unload_1283  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1029  1
    load_1_14_16  free_load_conservation_1237  1
    load_1_14_16  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_1031  -25
    arc_1_14_17  connected_order_arc_1032  -13
    arc_1_14_17  out_degree_1232  1
    arc_1_14_17  in_degree_1251  1
    arc_1_14_17  original_T_including_depot_unload_1283  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_1031  1
    load_1_14_17  free_load_conservation_1237  1
    load_1_14_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_1033  -25
    arc_1_14_18  connected_order_arc_1034  -13
    arc_1_14_18  out_degree_1232  1
    arc_1_14_18  in_degree_1257  1
    arc_1_14_18  original_T_including_depot_unload_1283  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_1033  1
    load_1_14_18  free_load_conservation_1237  1
    load_1_14_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_1035  -25
    arc_1_14_19  connected_order_arc_1036  -13
    arc_1_14_19  out_degree_1232  1
    arc_1_14_19  in_degree_1263  1
    arc_1_14_19  original_T_including_depot_unload_1283  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_1035  1
    load_1_14_19  free_load_conservation_1237  1
    load_1_14_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_1037  -25
    arc_1_14_20  connected_order_arc_1038  -13
    arc_1_14_20  out_degree_1232  1
    arc_1_14_20  in_degree_1269  1
    arc_1_14_20  original_T_including_depot_unload_1283  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_1037  1
    load_1_14_20  free_load_conservation_1237  1
    load_1_14_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_21  arc_capacity_1039  -25
    arc_1_14_21  connected_order_arc_1040  -13
    arc_1_14_21  out_degree_1232  1
    arc_1_14_21  in_degree_1275  1
    arc_1_14_21  original_T_including_depot_unload_1283  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_21  arc_capacity_1039  1
    load_1_14_21  free_load_conservation_1237  1
    load_1_14_21  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1041  -25
    arc_1_15_0  depot_return_or_bypass_1203  1
    arc_1_15_0  out_degree_1238  1
    arc_1_15_0  original_T_including_depot_unload_1283  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1041  1
    load_1_15_0  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1042  -25
    arc_1_15_7  connected_order_arc_1043  -13
    arc_1_15_7  in_degree_1205  1
    arc_1_15_7  out_degree_1238  1
    arc_1_15_7  original_T_including_depot_unload_1283  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1042  1
    load_1_15_7  segment_load_conservation_1208  -1
    load_1_15_7  segment_prefix_lb_1209  1
    load_1_15_7  segment_prefix_ub_1210  1
    load_1_15_7  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1044  -25
    arc_1_15_8  connected_order_arc_1045  -13
    arc_1_15_8  in_degree_1212  1
    arc_1_15_8  out_degree_1238  1
    arc_1_15_8  original_T_including_depot_unload_1283  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1044  1
    load_1_15_8  segment_load_conservation_1215  -1
    load_1_15_8  segment_prefix_lb_1216  1
    load_1_15_8  segment_prefix_ub_1217  1
    load_1_15_8  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1046  -25
    arc_1_15_9  connected_order_arc_1047  -13
    arc_1_15_9  in_degree_1219  1
    arc_1_15_9  out_degree_1238  1
    arc_1_15_9  original_T_including_depot_unload_1283  8.9356126423557316e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1046  1
    load_1_15_9  segment_load_conservation_1222  -1
    load_1_15_9  segment_prefix_lb_1223  1
    load_1_15_9  segment_prefix_ub_1224  1
    load_1_15_9  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1048  -25
    arc_1_15_10  connected_order_arc_1049  -13
    arc_1_15_10  in_degree_1226  1
    arc_1_15_10  out_degree_1238  1
    arc_1_15_10  original_T_including_depot_unload_1283  6.0342879231962252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1048  1
    load_1_15_10  segment_load_conservation_1229  -1
    load_1_15_10  segment_prefix_lb_1230  1
    load_1_15_10  segment_prefix_ub_1231  1
    load_1_15_10  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1050  -25
    arc_1_15_14  connected_order_arc_1051  -13
    arc_1_15_14  in_degree_1233  1
    arc_1_15_14  out_degree_1238  1
    arc_1_15_14  original_T_including_depot_unload_1283  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1050  1
    load_1_15_14  free_load_conservation_1237  -1
    load_1_15_14  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1052  -25
    arc_1_15_16  connected_order_arc_1053  -13
    arc_1_15_16  out_degree_1238  1
    arc_1_15_16  in_degree_1245  1
    arc_1_15_16  original_T_including_depot_unload_1283  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1052  1
    load_1_15_16  free_load_conservation_1243  1
    load_1_15_16  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1054  -25
    arc_1_15_17  connected_order_arc_1055  -13
    arc_1_15_17  out_degree_1238  1
    arc_1_15_17  in_degree_1251  1
    arc_1_15_17  original_T_including_depot_unload_1283  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1054  1
    load_1_15_17  free_load_conservation_1243  1
    load_1_15_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1056  -25
    arc_1_15_18  connected_order_arc_1057  -13
    arc_1_15_18  out_degree_1238  1
    arc_1_15_18  in_degree_1257  1
    arc_1_15_18  original_T_including_depot_unload_1283  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1056  1
    load_1_15_18  free_load_conservation_1243  1
    load_1_15_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1058  -25
    arc_1_15_19  connected_order_arc_1059  -13
    arc_1_15_19  out_degree_1238  1
    arc_1_15_19  in_degree_1263  1
    arc_1_15_19  original_T_including_depot_unload_1283  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1058  1
    load_1_15_19  free_load_conservation_1243  1
    load_1_15_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1060  -25
    arc_1_15_20  connected_order_arc_1061  -13
    arc_1_15_20  out_degree_1238  1
    arc_1_15_20  in_degree_1269  1
    arc_1_15_20  original_T_including_depot_unload_1283  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1060  1
    load_1_15_20  free_load_conservation_1243  1
    load_1_15_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_1062  -25
    arc_1_15_21  connected_order_arc_1063  -13
    arc_1_15_21  out_degree_1238  1
    arc_1_15_21  in_degree_1275  1
    arc_1_15_21  original_T_including_depot_unload_1283  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_1062  1
    load_1_15_21  free_load_conservation_1243  1
    load_1_15_21  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1064  -25
    arc_1_16_0  depot_return_or_bypass_1203  1
    arc_1_16_0  out_degree_1244  1
    arc_1_16_0  original_T_including_depot_unload_1283  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1064  1
    load_1_16_0  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1065  -25
    arc_1_16_7  connected_order_arc_1066  -13
    arc_1_16_7  in_degree_1205  1
    arc_1_16_7  out_degree_1244  1
    arc_1_16_7  original_T_including_depot_unload_1283  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1065  1
    load_1_16_7  segment_load_conservation_1208  -1
    load_1_16_7  segment_prefix_lb_1209  1
    load_1_16_7  segment_prefix_ub_1210  1
    load_1_16_7  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1067  -25
    arc_1_16_8  connected_order_arc_1068  -13
    arc_1_16_8  in_degree_1212  1
    arc_1_16_8  out_degree_1244  1
    arc_1_16_8  original_T_including_depot_unload_1283  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1067  1
    load_1_16_8  segment_load_conservation_1215  -1
    load_1_16_8  segment_prefix_lb_1216  1
    load_1_16_8  segment_prefix_ub_1217  1
    load_1_16_8  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1069  -25
    arc_1_16_9  connected_order_arc_1070  -13
    arc_1_16_9  in_degree_1219  1
    arc_1_16_9  out_degree_1244  1
    arc_1_16_9  original_T_including_depot_unload_1283  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1069  1
    load_1_16_9  segment_load_conservation_1222  -1
    load_1_16_9  segment_prefix_lb_1223  1
    load_1_16_9  segment_prefix_ub_1224  1
    load_1_16_9  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1071  -25
    arc_1_16_10  connected_order_arc_1072  -13
    arc_1_16_10  in_degree_1226  1
    arc_1_16_10  out_degree_1244  1
    arc_1_16_10  original_T_including_depot_unload_1283  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1071  1
    load_1_16_10  segment_load_conservation_1229  -1
    load_1_16_10  segment_prefix_lb_1230  1
    load_1_16_10  segment_prefix_ub_1231  1
    load_1_16_10  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1073  -25
    arc_1_16_14  connected_order_arc_1074  -13
    arc_1_16_14  in_degree_1233  1
    arc_1_16_14  out_degree_1244  1
    arc_1_16_14  original_T_including_depot_unload_1283  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1073  1
    load_1_16_14  free_load_conservation_1237  -1
    load_1_16_14  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1075  -25
    arc_1_16_15  connected_order_arc_1076  -13
    arc_1_16_15  in_degree_1239  1
    arc_1_16_15  out_degree_1244  1
    arc_1_16_15  original_T_including_depot_unload_1283  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1075  1
    load_1_16_15  free_load_conservation_1243  -1
    load_1_16_15  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1077  -25
    arc_1_16_17  connected_order_arc_1078  -13
    arc_1_16_17  out_degree_1244  1
    arc_1_16_17  in_degree_1251  1
    arc_1_16_17  original_T_including_depot_unload_1283  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1077  1
    load_1_16_17  free_load_conservation_1249  1
    load_1_16_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1079  -25
    arc_1_16_18  connected_order_arc_1080  -13
    arc_1_16_18  out_degree_1244  1
    arc_1_16_18  in_degree_1257  1
    arc_1_16_18  original_T_including_depot_unload_1283  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1079  1
    load_1_16_18  free_load_conservation_1249  1
    load_1_16_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1081  -25
    arc_1_16_19  connected_order_arc_1082  -13
    arc_1_16_19  out_degree_1244  1
    arc_1_16_19  in_degree_1263  1
    arc_1_16_19  original_T_including_depot_unload_1283  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1081  1
    load_1_16_19  free_load_conservation_1249  1
    load_1_16_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1083  -25
    arc_1_16_20  connected_order_arc_1084  -13
    arc_1_16_20  out_degree_1244  1
    arc_1_16_20  in_degree_1269  1
    arc_1_16_20  original_T_including_depot_unload_1283  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1083  1
    load_1_16_20  free_load_conservation_1249  1
    load_1_16_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1085  -25
    arc_1_16_21  connected_order_arc_1086  -13
    arc_1_16_21  out_degree_1244  1
    arc_1_16_21  in_degree_1275  1
    arc_1_16_21  original_T_including_depot_unload_1283  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1085  1
    load_1_16_21  free_load_conservation_1249  1
    load_1_16_21  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1087  -25
    arc_1_17_0  depot_return_or_bypass_1203  1
    arc_1_17_0  out_degree_1250  1
    arc_1_17_0  original_T_including_depot_unload_1283  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1087  1
    load_1_17_0  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1088  -25
    arc_1_17_7  connected_order_arc_1089  -13
    arc_1_17_7  in_degree_1205  1
    arc_1_17_7  out_degree_1250  1
    arc_1_17_7  original_T_including_depot_unload_1283  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1088  1
    load_1_17_7  segment_load_conservation_1208  -1
    load_1_17_7  segment_prefix_lb_1209  1
    load_1_17_7  segment_prefix_ub_1210  1
    load_1_17_7  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1090  -25
    arc_1_17_8  connected_order_arc_1091  -13
    arc_1_17_8  in_degree_1212  1
    arc_1_17_8  out_degree_1250  1
    arc_1_17_8  original_T_including_depot_unload_1283  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1090  1
    load_1_17_8  segment_load_conservation_1215  -1
    load_1_17_8  segment_prefix_lb_1216  1
    load_1_17_8  segment_prefix_ub_1217  1
    load_1_17_8  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1092  -25
    arc_1_17_9  connected_order_arc_1093  -13
    arc_1_17_9  in_degree_1219  1
    arc_1_17_9  out_degree_1250  1
    arc_1_17_9  original_T_including_depot_unload_1283  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1092  1
    load_1_17_9  segment_load_conservation_1222  -1
    load_1_17_9  segment_prefix_lb_1223  1
    load_1_17_9  segment_prefix_ub_1224  1
    load_1_17_9  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1094  -25
    arc_1_17_10  connected_order_arc_1095  -13
    arc_1_17_10  in_degree_1226  1
    arc_1_17_10  out_degree_1250  1
    arc_1_17_10  original_T_including_depot_unload_1283  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1094  1
    load_1_17_10  segment_load_conservation_1229  -1
    load_1_17_10  segment_prefix_lb_1230  1
    load_1_17_10  segment_prefix_ub_1231  1
    load_1_17_10  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1096  -25
    arc_1_17_14  connected_order_arc_1097  -13
    arc_1_17_14  in_degree_1233  1
    arc_1_17_14  out_degree_1250  1
    arc_1_17_14  original_T_including_depot_unload_1283  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1096  1
    load_1_17_14  free_load_conservation_1237  -1
    load_1_17_14  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1098  -25
    arc_1_17_15  connected_order_arc_1099  -13
    arc_1_17_15  in_degree_1239  1
    arc_1_17_15  out_degree_1250  1
    arc_1_17_15  original_T_including_depot_unload_1283  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1098  1
    load_1_17_15  free_load_conservation_1243  -1
    load_1_17_15  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1100  -25
    arc_1_17_16  connected_order_arc_1101  -13
    arc_1_17_16  in_degree_1245  1
    arc_1_17_16  out_degree_1250  1
    arc_1_17_16  original_T_including_depot_unload_1283  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1100  1
    load_1_17_16  free_load_conservation_1249  -1
    load_1_17_16  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1102  -25
    arc_1_17_18  connected_order_arc_1103  -13
    arc_1_17_18  out_degree_1250  1
    arc_1_17_18  in_degree_1257  1
    arc_1_17_18  original_T_including_depot_unload_1283  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1102  1
    load_1_17_18  free_load_conservation_1255  1
    load_1_17_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1104  -25
    arc_1_17_19  connected_order_arc_1105  -13
    arc_1_17_19  out_degree_1250  1
    arc_1_17_19  in_degree_1263  1
    arc_1_17_19  original_T_including_depot_unload_1283  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1104  1
    load_1_17_19  free_load_conservation_1255  1
    load_1_17_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1106  -25
    arc_1_17_20  connected_order_arc_1107  -13
    arc_1_17_20  out_degree_1250  1
    arc_1_17_20  in_degree_1269  1
    arc_1_17_20  original_T_including_depot_unload_1283  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1106  1
    load_1_17_20  free_load_conservation_1255  1
    load_1_17_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1108  -25
    arc_1_17_21  connected_order_arc_1109  -13
    arc_1_17_21  out_degree_1250  1
    arc_1_17_21  in_degree_1275  1
    arc_1_17_21  original_T_including_depot_unload_1283  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1108  1
    load_1_17_21  free_load_conservation_1255  1
    load_1_17_21  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1110  -25
    arc_1_18_0  depot_return_or_bypass_1203  1
    arc_1_18_0  out_degree_1256  1
    arc_1_18_0  original_T_including_depot_unload_1283  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1110  1
    load_1_18_0  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1111  -25
    arc_1_18_7  connected_order_arc_1112  -13
    arc_1_18_7  in_degree_1205  1
    arc_1_18_7  out_degree_1256  1
    arc_1_18_7  original_T_including_depot_unload_1283  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1111  1
    load_1_18_7  segment_load_conservation_1208  -1
    load_1_18_7  segment_prefix_lb_1209  1
    load_1_18_7  segment_prefix_ub_1210  1
    load_1_18_7  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1113  -25
    arc_1_18_8  connected_order_arc_1114  -13
    arc_1_18_8  in_degree_1212  1
    arc_1_18_8  out_degree_1256  1
    arc_1_18_8  original_T_including_depot_unload_1283  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1113  1
    load_1_18_8  segment_load_conservation_1215  -1
    load_1_18_8  segment_prefix_lb_1216  1
    load_1_18_8  segment_prefix_ub_1217  1
    load_1_18_8  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1115  -25
    arc_1_18_9  connected_order_arc_1116  -13
    arc_1_18_9  in_degree_1219  1
    arc_1_18_9  out_degree_1256  1
    arc_1_18_9  original_T_including_depot_unload_1283  2.5950001064050621e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1115  1
    load_1_18_9  segment_load_conservation_1222  -1
    load_1_18_9  segment_prefix_lb_1223  1
    load_1_18_9  segment_prefix_ub_1224  1
    load_1_18_9  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1117  -25
    arc_1_18_10  connected_order_arc_1118  -13
    arc_1_18_10  in_degree_1226  1
    arc_1_18_10  out_degree_1256  1
    arc_1_18_10  original_T_including_depot_unload_1283  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1117  1
    load_1_18_10  segment_load_conservation_1229  -1
    load_1_18_10  segment_prefix_lb_1230  1
    load_1_18_10  segment_prefix_ub_1231  1
    load_1_18_10  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1119  -25
    arc_1_18_14  connected_order_arc_1120  -13
    arc_1_18_14  in_degree_1233  1
    arc_1_18_14  out_degree_1256  1
    arc_1_18_14  original_T_including_depot_unload_1283  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1119  1
    load_1_18_14  free_load_conservation_1237  -1
    load_1_18_14  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1121  -25
    arc_1_18_15  connected_order_arc_1122  -13
    arc_1_18_15  in_degree_1239  1
    arc_1_18_15  out_degree_1256  1
    arc_1_18_15  original_T_including_depot_unload_1283  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1121  1
    load_1_18_15  free_load_conservation_1243  -1
    load_1_18_15  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1123  -25
    arc_1_18_16  connected_order_arc_1124  -13
    arc_1_18_16  in_degree_1245  1
    arc_1_18_16  out_degree_1256  1
    arc_1_18_16  original_T_including_depot_unload_1283  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1123  1
    load_1_18_16  free_load_conservation_1249  -1
    load_1_18_16  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1125  -25
    arc_1_18_17  connected_order_arc_1126  -13
    arc_1_18_17  in_degree_1251  1
    arc_1_18_17  out_degree_1256  1
    arc_1_18_17  original_T_including_depot_unload_1283  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1125  1
    load_1_18_17  free_load_conservation_1255  -1
    load_1_18_17  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1127  -25
    arc_1_18_19  connected_order_arc_1128  -13
    arc_1_18_19  out_degree_1256  1
    arc_1_18_19  in_degree_1263  1
    arc_1_18_19  original_T_including_depot_unload_1283  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1127  1
    load_1_18_19  free_load_conservation_1261  1
    load_1_18_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1129  -25
    arc_1_18_20  connected_order_arc_1130  -13
    arc_1_18_20  out_degree_1256  1
    arc_1_18_20  in_degree_1269  1
    arc_1_18_20  original_T_including_depot_unload_1283  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1129  1
    load_1_18_20  free_load_conservation_1261  1
    load_1_18_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1131  -25
    arc_1_18_21  connected_order_arc_1132  -13
    arc_1_18_21  out_degree_1256  1
    arc_1_18_21  in_degree_1275  1
    arc_1_18_21  original_T_including_depot_unload_1283  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1131  1
    load_1_18_21  free_load_conservation_1261  1
    load_1_18_21  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1133  -25
    arc_1_19_0  depot_return_or_bypass_1203  1
    arc_1_19_0  out_degree_1262  1
    arc_1_19_0  original_T_including_depot_unload_1283  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1133  1
    load_1_19_0  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1134  -25
    arc_1_19_7  connected_order_arc_1135  -13
    arc_1_19_7  in_degree_1205  1
    arc_1_19_7  out_degree_1262  1
    arc_1_19_7  original_T_including_depot_unload_1283  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1134  1
    load_1_19_7  segment_load_conservation_1208  -1
    load_1_19_7  segment_prefix_lb_1209  1
    load_1_19_7  segment_prefix_ub_1210  1
    load_1_19_7  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1136  -25
    arc_1_19_8  connected_order_arc_1137  -13
    arc_1_19_8  in_degree_1212  1
    arc_1_19_8  out_degree_1262  1
    arc_1_19_8  original_T_including_depot_unload_1283  1.0967168052209140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1136  1
    load_1_19_8  segment_load_conservation_1215  -1
    load_1_19_8  segment_prefix_lb_1216  1
    load_1_19_8  segment_prefix_ub_1217  1
    load_1_19_8  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1138  -25
    arc_1_19_9  connected_order_arc_1139  -13
    arc_1_19_9  in_degree_1219  1
    arc_1_19_9  out_degree_1262  1
    arc_1_19_9  original_T_including_depot_unload_1283  4.0010881633455318e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1138  1
    load_1_19_9  segment_load_conservation_1222  -1
    load_1_19_9  segment_prefix_lb_1223  1
    load_1_19_9  segment_prefix_ub_1224  1
    load_1_19_9  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_10  arc_capacity_1140  -25
    arc_1_19_10  connected_order_arc_1141  -13
    arc_1_19_10  in_degree_1226  1
    arc_1_19_10  out_degree_1262  1
    arc_1_19_10  original_T_including_depot_unload_1283  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_10  arc_capacity_1140  1
    load_1_19_10  segment_load_conservation_1229  -1
    load_1_19_10  segment_prefix_lb_1230  1
    load_1_19_10  segment_prefix_ub_1231  1
    load_1_19_10  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1142  -25
    arc_1_19_14  connected_order_arc_1143  -13
    arc_1_19_14  in_degree_1233  1
    arc_1_19_14  out_degree_1262  1
    arc_1_19_14  original_T_including_depot_unload_1283  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1142  1
    load_1_19_14  free_load_conservation_1237  -1
    load_1_19_14  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1144  -25
    arc_1_19_15  connected_order_arc_1145  -13
    arc_1_19_15  in_degree_1239  1
    arc_1_19_15  out_degree_1262  1
    arc_1_19_15  original_T_including_depot_unload_1283  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1144  1
    load_1_19_15  free_load_conservation_1243  -1
    load_1_19_15  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1146  -25
    arc_1_19_16  connected_order_arc_1147  -13
    arc_1_19_16  in_degree_1245  1
    arc_1_19_16  out_degree_1262  1
    arc_1_19_16  original_T_including_depot_unload_1283  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1146  1
    load_1_19_16  free_load_conservation_1249  -1
    load_1_19_16  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1148  -25
    arc_1_19_17  connected_order_arc_1149  -13
    arc_1_19_17  in_degree_1251  1
    arc_1_19_17  out_degree_1262  1
    arc_1_19_17  original_T_including_depot_unload_1283  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1148  1
    load_1_19_17  free_load_conservation_1255  -1
    load_1_19_17  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1150  -25
    arc_1_19_18  connected_order_arc_1151  -13
    arc_1_19_18  in_degree_1257  1
    arc_1_19_18  out_degree_1262  1
    arc_1_19_18  original_T_including_depot_unload_1283  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1150  1
    load_1_19_18  free_load_conservation_1261  -1
    load_1_19_18  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1152  -25
    arc_1_19_20  connected_order_arc_1153  -13
    arc_1_19_20  out_degree_1262  1
    arc_1_19_20  in_degree_1269  1
    arc_1_19_20  original_T_including_depot_unload_1283  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1152  1
    load_1_19_20  free_load_conservation_1267  1
    load_1_19_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1154  -25
    arc_1_19_21  connected_order_arc_1155  -13
    arc_1_19_21  out_degree_1262  1
    arc_1_19_21  in_degree_1275  1
    arc_1_19_21  original_T_including_depot_unload_1283  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1154  1
    load_1_19_21  free_load_conservation_1267  1
    load_1_19_21  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1156  -25
    arc_1_20_0  depot_return_or_bypass_1203  1
    arc_1_20_0  out_degree_1268  1
    arc_1_20_0  original_T_including_depot_unload_1283  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1156  1
    load_1_20_0  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1157  -25
    arc_1_20_7  connected_order_arc_1158  -13
    arc_1_20_7  in_degree_1205  1
    arc_1_20_7  out_degree_1268  1
    arc_1_20_7  original_T_including_depot_unload_1283  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1157  1
    load_1_20_7  segment_load_conservation_1208  -1
    load_1_20_7  segment_prefix_lb_1209  1
    load_1_20_7  segment_prefix_ub_1210  1
    load_1_20_7  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1159  -25
    arc_1_20_8  connected_order_arc_1160  -13
    arc_1_20_8  in_degree_1212  1
    arc_1_20_8  out_degree_1268  1
    arc_1_20_8  original_T_including_depot_unload_1283  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1159  1
    load_1_20_8  segment_load_conservation_1215  -1
    load_1_20_8  segment_prefix_lb_1216  1
    load_1_20_8  segment_prefix_ub_1217  1
    load_1_20_8  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1161  -25
    arc_1_20_9  connected_order_arc_1162  -13
    arc_1_20_9  in_degree_1219  1
    arc_1_20_9  out_degree_1268  1
    arc_1_20_9  original_T_including_depot_unload_1283  1.5711351987660353e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1161  1
    load_1_20_9  segment_load_conservation_1222  -1
    load_1_20_9  segment_prefix_lb_1223  1
    load_1_20_9  segment_prefix_ub_1224  1
    load_1_20_9  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_10  arc_capacity_1163  -25
    arc_1_20_10  connected_order_arc_1164  -13
    arc_1_20_10  in_degree_1226  1
    arc_1_20_10  out_degree_1268  1
    arc_1_20_10  original_T_including_depot_unload_1283  1.2814005706654932e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_10  arc_capacity_1163  1
    load_1_20_10  segment_load_conservation_1229  -1
    load_1_20_10  segment_prefix_lb_1230  1
    load_1_20_10  segment_prefix_ub_1231  1
    load_1_20_10  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1165  -25
    arc_1_20_14  connected_order_arc_1166  -13
    arc_1_20_14  in_degree_1233  1
    arc_1_20_14  out_degree_1268  1
    arc_1_20_14  original_T_including_depot_unload_1283  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1165  1
    load_1_20_14  free_load_conservation_1237  -1
    load_1_20_14  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1167  -25
    arc_1_20_15  connected_order_arc_1168  -13
    arc_1_20_15  in_degree_1239  1
    arc_1_20_15  out_degree_1268  1
    arc_1_20_15  original_T_including_depot_unload_1283  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1167  1
    load_1_20_15  free_load_conservation_1243  -1
    load_1_20_15  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1169  -25
    arc_1_20_16  connected_order_arc_1170  -13
    arc_1_20_16  in_degree_1245  1
    arc_1_20_16  out_degree_1268  1
    arc_1_20_16  original_T_including_depot_unload_1283  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1169  1
    load_1_20_16  free_load_conservation_1249  -1
    load_1_20_16  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1171  -25
    arc_1_20_17  connected_order_arc_1172  -13
    arc_1_20_17  in_degree_1251  1
    arc_1_20_17  out_degree_1268  1
    arc_1_20_17  original_T_including_depot_unload_1283  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1171  1
    load_1_20_17  free_load_conservation_1255  -1
    load_1_20_17  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1173  -25
    arc_1_20_18  connected_order_arc_1174  -13
    arc_1_20_18  in_degree_1257  1
    arc_1_20_18  out_degree_1268  1
    arc_1_20_18  original_T_including_depot_unload_1283  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1173  1
    load_1_20_18  free_load_conservation_1261  -1
    load_1_20_18  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1175  -25
    arc_1_20_19  connected_order_arc_1176  -13
    arc_1_20_19  in_degree_1263  1
    arc_1_20_19  out_degree_1268  1
    arc_1_20_19  original_T_including_depot_unload_1283  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1175  1
    load_1_20_19  free_load_conservation_1267  -1
    load_1_20_19  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1177  -25
    arc_1_20_21  connected_order_arc_1178  -13
    arc_1_20_21  out_degree_1268  1
    arc_1_20_21  in_degree_1275  1
    arc_1_20_21  original_T_including_depot_unload_1283  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1177  1
    load_1_20_21  free_load_conservation_1273  1
    load_1_20_21  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1179  -25
    arc_1_21_0  depot_return_or_bypass_1203  1
    arc_1_21_0  out_degree_1274  1
    arc_1_21_0  original_T_including_depot_unload_1283  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1179  1
    load_1_21_0  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1180  -25
    arc_1_21_7  connected_order_arc_1181  -13
    arc_1_21_7  in_degree_1205  1
    arc_1_21_7  out_degree_1274  1
    arc_1_21_7  original_T_including_depot_unload_1283  1.1017171222416982e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1180  1
    load_1_21_7  segment_load_conservation_1208  -1
    load_1_21_7  segment_prefix_lb_1209  1
    load_1_21_7  segment_prefix_ub_1210  1
    load_1_21_7  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1182  -25
    arc_1_21_8  connected_order_arc_1183  -13
    arc_1_21_8  in_degree_1212  1
    arc_1_21_8  out_degree_1274  1
    arc_1_21_8  original_T_including_depot_unload_1283  1.2434091529834902e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1182  1
    load_1_21_8  segment_load_conservation_1215  -1
    load_1_21_8  segment_prefix_lb_1216  1
    load_1_21_8  segment_prefix_ub_1217  1
    load_1_21_8  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1184  -25
    arc_1_21_9  connected_order_arc_1185  -13
    arc_1_21_9  in_degree_1219  1
    arc_1_21_9  out_degree_1274  1
    arc_1_21_9  original_T_including_depot_unload_1283  1.0744643606639036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1184  1
    load_1_21_9  segment_load_conservation_1222  -1
    load_1_21_9  segment_prefix_lb_1223  1
    load_1_21_9  segment_prefix_ub_1224  1
    load_1_21_9  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_10  arc_capacity_1186  -25
    arc_1_21_10  connected_order_arc_1187  -13
    arc_1_21_10  in_degree_1226  1
    arc_1_21_10  out_degree_1274  1
    arc_1_21_10  original_T_including_depot_unload_1283  7.9428057689531045e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_10  arc_capacity_1186  1
    load_1_21_10  segment_load_conservation_1229  -1
    load_1_21_10  segment_prefix_lb_1230  1
    load_1_21_10  segment_prefix_ub_1231  1
    load_1_21_10  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_14  arc_capacity_1188  -25
    arc_1_21_14  connected_order_arc_1189  -13
    arc_1_21_14  in_degree_1233  1
    arc_1_21_14  out_degree_1274  1
    arc_1_21_14  original_T_including_depot_unload_1283  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_14  arc_capacity_1188  1
    load_1_21_14  free_load_conservation_1237  -1
    load_1_21_14  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1190  -25
    arc_1_21_15  connected_order_arc_1191  -13
    arc_1_21_15  in_degree_1239  1
    arc_1_21_15  out_degree_1274  1
    arc_1_21_15  original_T_including_depot_unload_1283  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1190  1
    load_1_21_15  free_load_conservation_1243  -1
    load_1_21_15  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1192  -25
    arc_1_21_16  connected_order_arc_1193  -13
    arc_1_21_16  in_degree_1245  1
    arc_1_21_16  out_degree_1274  1
    arc_1_21_16  original_T_including_depot_unload_1283  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1192  1
    load_1_21_16  free_load_conservation_1249  -1
    load_1_21_16  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1194  -25
    arc_1_21_17  connected_order_arc_1195  -13
    arc_1_21_17  in_degree_1251  1
    arc_1_21_17  out_degree_1274  1
    arc_1_21_17  original_T_including_depot_unload_1283  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1194  1
    load_1_21_17  free_load_conservation_1255  -1
    load_1_21_17  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1196  -25
    arc_1_21_18  connected_order_arc_1197  -13
    arc_1_21_18  in_degree_1257  1
    arc_1_21_18  out_degree_1274  1
    arc_1_21_18  original_T_including_depot_unload_1283  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1196  1
    load_1_21_18  free_load_conservation_1261  -1
    load_1_21_18  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1198  -25
    arc_1_21_19  connected_order_arc_1199  -13
    arc_1_21_19  in_degree_1263  1
    arc_1_21_19  out_degree_1274  1
    arc_1_21_19  original_T_including_depot_unload_1283  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1198  1
    load_1_21_19  free_load_conservation_1267  -1
    load_1_21_19  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1200  -25
    arc_1_21_20  connected_order_arc_1201  -13
    arc_1_21_20  in_degree_1269  1
    arc_1_21_20  out_degree_1274  1
    arc_1_21_20  original_T_including_depot_unload_1283  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1200  1
    load_1_21_20  free_load_conservation_1273  -1
    load_1_21_20  free_load_conservation_1279  1
    visit_2_11  out_degree_1529  -1
    visit_2_11  in_degree_1530  -1
    visit_2_11  order_active_lb_1531  -1
    visit_2_11  order_active_ub_1532  -11
    order_2_11  connected_order_arc_1298  -1
    order_2_11  connected_order_arc_1300  -1
    order_2_11  connected_order_arc_1302  -1
    order_2_11  connected_order_arc_1304  -1
    order_2_11  connected_order_arc_1306  -1
    order_2_11  connected_order_arc_1308  -1
    order_2_11  connected_order_arc_1310  -1
    order_2_11  connected_order_arc_1312  -1
    order_2_11  connected_order_arc_1314  -1
    order_2_11  connected_order_arc_1316  -1
    order_2_11  connected_order_arc_1319  1
    order_2_11  connected_order_arc_1340  1
    order_2_11  connected_order_arc_1361  1
    order_2_11  connected_order_arc_1382  1
    order_2_11  connected_order_arc_1403  1
    order_2_11  connected_order_arc_1424  1
    order_2_11  connected_order_arc_1445  1
    order_2_11  connected_order_arc_1466  1
    order_2_11  connected_order_arc_1487  1
    order_2_11  connected_order_arc_1508  1
    order_2_11  order_active_lb_1531  1
    order_2_11  order_active_ub_1532  1
    order_2_11  fixed_segment_relative_order_1598  -1
    visit_2_12  out_degree_1536  -1
    visit_2_12  in_degree_1537  -1
    visit_2_12  order_active_lb_1538  -1
    visit_2_12  order_active_ub_1539  -11
    order_2_12  connected_order_arc_1298  1
    order_2_12  connected_order_arc_1319  -1
    order_2_12  connected_order_arc_1321  -1
    order_2_12  connected_order_arc_1323  -1
    order_2_12  connected_order_arc_1325  -1
    order_2_12  connected_order_arc_1327  -1
    order_2_12  connected_order_arc_1329  -1
    order_2_12  connected_order_arc_1331  -1
    order_2_12  connected_order_arc_1333  -1
    order_2_12  connected_order_arc_1335  -1
    order_2_12  connected_order_arc_1337  -1
    order_2_12  connected_order_arc_1342  1
    order_2_12  connected_order_arc_1363  1
    order_2_12  connected_order_arc_1384  1
    order_2_12  connected_order_arc_1405  1
    order_2_12  connected_order_arc_1426  1
    order_2_12  connected_order_arc_1447  1
    order_2_12  connected_order_arc_1468  1
    order_2_12  connected_order_arc_1489  1
    order_2_12  connected_order_arc_1510  1
    order_2_12  order_active_lb_1538  1
    order_2_12  order_active_ub_1539  1
    order_2_12  fixed_segment_relative_order_1598  1
    order_2_12  fixed_segment_relative_order_1599  -1
    visit_2_13  out_degree_1543  -1
    visit_2_13  in_degree_1544  -1
    visit_2_13  order_active_lb_1545  -1
    visit_2_13  order_active_ub_1546  -11
    order_2_13  connected_order_arc_1300  1
    order_2_13  connected_order_arc_1321  1
    order_2_13  connected_order_arc_1340  -1
    order_2_13  connected_order_arc_1342  -1
    order_2_13  connected_order_arc_1344  -1
    order_2_13  connected_order_arc_1346  -1
    order_2_13  connected_order_arc_1348  -1
    order_2_13  connected_order_arc_1350  -1
    order_2_13  connected_order_arc_1352  -1
    order_2_13  connected_order_arc_1354  -1
    order_2_13  connected_order_arc_1356  -1
    order_2_13  connected_order_arc_1358  -1
    order_2_13  connected_order_arc_1365  1
    order_2_13  connected_order_arc_1386  1
    order_2_13  connected_order_arc_1407  1
    order_2_13  connected_order_arc_1428  1
    order_2_13  connected_order_arc_1449  1
    order_2_13  connected_order_arc_1470  1
    order_2_13  connected_order_arc_1491  1
    order_2_13  connected_order_arc_1512  1
    order_2_13  order_active_lb_1545  1
    order_2_13  order_active_ub_1546  1
    order_2_13  fixed_segment_relative_order_1599  1
    visit_2_14  out_degree_1550  -1
    visit_2_14  in_degree_1551  -1
    visit_2_14  order_active_lb_1552  -1
    visit_2_14  order_active_ub_1553  -11
    visit_2_14  service_visit_def_1554  -1
    order_2_14  connected_order_arc_1302  1
    order_2_14  connected_order_arc_1323  1
    order_2_14  connected_order_arc_1344  1
    order_2_14  connected_order_arc_1361  -1
    order_2_14  connected_order_arc_1363  -1
    order_2_14  connected_order_arc_1365  -1
    order_2_14  connected_order_arc_1367  -1
    order_2_14  connected_order_arc_1369  -1
    order_2_14  connected_order_arc_1371  -1
    order_2_14  connected_order_arc_1373  -1
    order_2_14  connected_order_arc_1375  -1
    order_2_14  connected_order_arc_1377  -1
    order_2_14  connected_order_arc_1379  -1
    order_2_14  connected_order_arc_1388  1
    order_2_14  connected_order_arc_1409  1
    order_2_14  connected_order_arc_1430  1
    order_2_14  connected_order_arc_1451  1
    order_2_14  connected_order_arc_1472  1
    order_2_14  connected_order_arc_1493  1
    order_2_14  connected_order_arc_1514  1
    order_2_14  order_active_lb_1552  1
    order_2_14  order_active_ub_1553  1
    visit_2_15  out_degree_1556  -1
    visit_2_15  in_degree_1557  -1
    visit_2_15  order_active_lb_1558  -1
    visit_2_15  order_active_ub_1559  -11
    visit_2_15  service_visit_def_1560  -1
    order_2_15  connected_order_arc_1304  1
    order_2_15  connected_order_arc_1325  1
    order_2_15  connected_order_arc_1346  1
    order_2_15  connected_order_arc_1367  1
    order_2_15  connected_order_arc_1382  -1
    order_2_15  connected_order_arc_1384  -1
    order_2_15  connected_order_arc_1386  -1
    order_2_15  connected_order_arc_1388  -1
    order_2_15  connected_order_arc_1390  -1
    order_2_15  connected_order_arc_1392  -1
    order_2_15  connected_order_arc_1394  -1
    order_2_15  connected_order_arc_1396  -1
    order_2_15  connected_order_arc_1398  -1
    order_2_15  connected_order_arc_1400  -1
    order_2_15  connected_order_arc_1411  1
    order_2_15  connected_order_arc_1432  1
    order_2_15  connected_order_arc_1453  1
    order_2_15  connected_order_arc_1474  1
    order_2_15  connected_order_arc_1495  1
    order_2_15  connected_order_arc_1516  1
    order_2_15  order_active_lb_1558  1
    order_2_15  order_active_ub_1559  1
    visit_2_16  out_degree_1562  -1
    visit_2_16  in_degree_1563  -1
    visit_2_16  order_active_lb_1564  -1
    visit_2_16  order_active_ub_1565  -11
    visit_2_16  service_visit_def_1566  -1
    order_2_16  connected_order_arc_1306  1
    order_2_16  connected_order_arc_1327  1
    order_2_16  connected_order_arc_1348  1
    order_2_16  connected_order_arc_1369  1
    order_2_16  connected_order_arc_1390  1
    order_2_16  connected_order_arc_1403  -1
    order_2_16  connected_order_arc_1405  -1
    order_2_16  connected_order_arc_1407  -1
    order_2_16  connected_order_arc_1409  -1
    order_2_16  connected_order_arc_1411  -1
    order_2_16  connected_order_arc_1413  -1
    order_2_16  connected_order_arc_1415  -1
    order_2_16  connected_order_arc_1417  -1
    order_2_16  connected_order_arc_1419  -1
    order_2_16  connected_order_arc_1421  -1
    order_2_16  connected_order_arc_1434  1
    order_2_16  connected_order_arc_1455  1
    order_2_16  connected_order_arc_1476  1
    order_2_16  connected_order_arc_1497  1
    order_2_16  connected_order_arc_1518  1
    order_2_16  order_active_lb_1564  1
    order_2_16  order_active_ub_1565  1
    visit_2_17  out_degree_1568  -1
    visit_2_17  in_degree_1569  -1
    visit_2_17  order_active_lb_1570  -1
    visit_2_17  order_active_ub_1571  -11
    visit_2_17  service_visit_def_1572  -1
    order_2_17  connected_order_arc_1308  1
    order_2_17  connected_order_arc_1329  1
    order_2_17  connected_order_arc_1350  1
    order_2_17  connected_order_arc_1371  1
    order_2_17  connected_order_arc_1392  1
    order_2_17  connected_order_arc_1413  1
    order_2_17  connected_order_arc_1424  -1
    order_2_17  connected_order_arc_1426  -1
    order_2_17  connected_order_arc_1428  -1
    order_2_17  connected_order_arc_1430  -1
    order_2_17  connected_order_arc_1432  -1
    order_2_17  connected_order_arc_1434  -1
    order_2_17  connected_order_arc_1436  -1
    order_2_17  connected_order_arc_1438  -1
    order_2_17  connected_order_arc_1440  -1
    order_2_17  connected_order_arc_1442  -1
    order_2_17  connected_order_arc_1457  1
    order_2_17  connected_order_arc_1478  1
    order_2_17  connected_order_arc_1499  1
    order_2_17  connected_order_arc_1520  1
    order_2_17  order_active_lb_1570  1
    order_2_17  order_active_ub_1571  1
    visit_2_18  out_degree_1574  -1
    visit_2_18  in_degree_1575  -1
    visit_2_18  order_active_lb_1576  -1
    visit_2_18  order_active_ub_1577  -11
    visit_2_18  service_visit_def_1578  -1
    order_2_18  connected_order_arc_1310  1
    order_2_18  connected_order_arc_1331  1
    order_2_18  connected_order_arc_1352  1
    order_2_18  connected_order_arc_1373  1
    order_2_18  connected_order_arc_1394  1
    order_2_18  connected_order_arc_1415  1
    order_2_18  connected_order_arc_1436  1
    order_2_18  connected_order_arc_1445  -1
    order_2_18  connected_order_arc_1447  -1
    order_2_18  connected_order_arc_1449  -1
    order_2_18  connected_order_arc_1451  -1
    order_2_18  connected_order_arc_1453  -1
    order_2_18  connected_order_arc_1455  -1
    order_2_18  connected_order_arc_1457  -1
    order_2_18  connected_order_arc_1459  -1
    order_2_18  connected_order_arc_1461  -1
    order_2_18  connected_order_arc_1463  -1
    order_2_18  connected_order_arc_1480  1
    order_2_18  connected_order_arc_1501  1
    order_2_18  connected_order_arc_1522  1
    order_2_18  order_active_lb_1576  1
    order_2_18  order_active_ub_1577  1
    visit_2_19  out_degree_1580  -1
    visit_2_19  in_degree_1581  -1
    visit_2_19  order_active_lb_1582  -1
    visit_2_19  order_active_ub_1583  -11
    visit_2_19  service_visit_def_1584  -1
    order_2_19  connected_order_arc_1312  1
    order_2_19  connected_order_arc_1333  1
    order_2_19  connected_order_arc_1354  1
    order_2_19  connected_order_arc_1375  1
    order_2_19  connected_order_arc_1396  1
    order_2_19  connected_order_arc_1417  1
    order_2_19  connected_order_arc_1438  1
    order_2_19  connected_order_arc_1459  1
    order_2_19  connected_order_arc_1466  -1
    order_2_19  connected_order_arc_1468  -1
    order_2_19  connected_order_arc_1470  -1
    order_2_19  connected_order_arc_1472  -1
    order_2_19  connected_order_arc_1474  -1
    order_2_19  connected_order_arc_1476  -1
    order_2_19  connected_order_arc_1478  -1
    order_2_19  connected_order_arc_1480  -1
    order_2_19  connected_order_arc_1482  -1
    order_2_19  connected_order_arc_1484  -1
    order_2_19  connected_order_arc_1503  1
    order_2_19  connected_order_arc_1524  1
    order_2_19  order_active_lb_1582  1
    order_2_19  order_active_ub_1583  1
    visit_2_20  out_degree_1586  -1
    visit_2_20  in_degree_1587  -1
    visit_2_20  order_active_lb_1588  -1
    visit_2_20  order_active_ub_1589  -11
    visit_2_20  service_visit_def_1590  -1
    order_2_20  connected_order_arc_1314  1
    order_2_20  connected_order_arc_1335  1
    order_2_20  connected_order_arc_1356  1
    order_2_20  connected_order_arc_1377  1
    order_2_20  connected_order_arc_1398  1
    order_2_20  connected_order_arc_1419  1
    order_2_20  connected_order_arc_1440  1
    order_2_20  connected_order_arc_1461  1
    order_2_20  connected_order_arc_1482  1
    order_2_20  connected_order_arc_1487  -1
    order_2_20  connected_order_arc_1489  -1
    order_2_20  connected_order_arc_1491  -1
    order_2_20  connected_order_arc_1493  -1
    order_2_20  connected_order_arc_1495  -1
    order_2_20  connected_order_arc_1497  -1
    order_2_20  connected_order_arc_1499  -1
    order_2_20  connected_order_arc_1501  -1
    order_2_20  connected_order_arc_1503  -1
    order_2_20  connected_order_arc_1505  -1
    order_2_20  connected_order_arc_1526  1
    order_2_20  order_active_lb_1588  1
    order_2_20  order_active_ub_1589  1
    visit_2_21  out_degree_1592  -1
    visit_2_21  in_degree_1593  -1
    visit_2_21  order_active_lb_1594  -1
    visit_2_21  order_active_ub_1595  -11
    visit_2_21  service_visit_def_1596  -1
    order_2_21  connected_order_arc_1316  1
    order_2_21  connected_order_arc_1337  1
    order_2_21  connected_order_arc_1358  1
    order_2_21  connected_order_arc_1379  1
    order_2_21  connected_order_arc_1400  1
    order_2_21  connected_order_arc_1421  1
    order_2_21  connected_order_arc_1442  1
    order_2_21  connected_order_arc_1463  1
    order_2_21  connected_order_arc_1484  1
    order_2_21  connected_order_arc_1505  1
    order_2_21  connected_order_arc_1508  -1
    order_2_21  connected_order_arc_1510  -1
    order_2_21  connected_order_arc_1512  -1
    order_2_21  connected_order_arc_1514  -1
    order_2_21  connected_order_arc_1516  -1
    order_2_21  connected_order_arc_1518  -1
    order_2_21  connected_order_arc_1520  -1
    order_2_21  connected_order_arc_1522  -1
    order_2_21  connected_order_arc_1524  -1
    order_2_21  connected_order_arc_1526  -1
    order_2_21  order_active_lb_1594  1
    order_2_21  order_active_ub_1595  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1284  -30
    arc_2_0_0  depot_departure_or_bypass_1527  1
    arc_2_0_0  depot_return_or_bypass_1528  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1284  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1285  -30
    arc_2_0_11  depot_departure_or_bypass_1527  1
    arc_2_0_11  in_degree_1530  1
    arc_2_0_11  original_T_including_depot_unload_1600  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1285  1
    load_2_0_11  segment_load_conservation_1533  -1
    load_2_0_11  segment_prefix_lb_1534  1
    load_2_0_11  segment_prefix_ub_1535  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1286  -30
    arc_2_0_12  depot_departure_or_bypass_1527  1
    arc_2_0_12  in_degree_1537  1
    arc_2_0_12  original_T_including_depot_unload_1600  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1286  1
    load_2_0_12  segment_load_conservation_1540  -1
    load_2_0_12  segment_prefix_lb_1541  1
    load_2_0_12  segment_prefix_ub_1542  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1287  -30
    arc_2_0_13  depot_departure_or_bypass_1527  1
    arc_2_0_13  in_degree_1544  1
    arc_2_0_13  original_T_including_depot_unload_1600  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1287  1
    load_2_0_13  segment_load_conservation_1547  -1
    load_2_0_13  segment_prefix_lb_1548  1
    load_2_0_13  segment_prefix_ub_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1288  -30
    arc_2_0_14  depot_departure_or_bypass_1527  1
    arc_2_0_14  in_degree_1551  1
    arc_2_0_14  original_T_including_depot_unload_1600  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1288  1
    load_2_0_14  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1289  -30
    arc_2_0_15  depot_departure_or_bypass_1527  1
    arc_2_0_15  in_degree_1557  1
    arc_2_0_15  original_T_including_depot_unload_1600  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1289  1
    load_2_0_15  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1290  -30
    arc_2_0_16  depot_departure_or_bypass_1527  1
    arc_2_0_16  in_degree_1563  1
    arc_2_0_16  original_T_including_depot_unload_1600  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1290  1
    load_2_0_16  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1291  -30
    arc_2_0_17  depot_departure_or_bypass_1527  1
    arc_2_0_17  in_degree_1569  1
    arc_2_0_17  original_T_including_depot_unload_1600  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1291  1
    load_2_0_17  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1292  -30
    arc_2_0_18  depot_departure_or_bypass_1527  1
    arc_2_0_18  in_degree_1575  1
    arc_2_0_18  original_T_including_depot_unload_1600  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1292  1
    load_2_0_18  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1293  -30
    arc_2_0_19  depot_departure_or_bypass_1527  1
    arc_2_0_19  in_degree_1581  1
    arc_2_0_19  original_T_including_depot_unload_1600  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1293  1
    load_2_0_19  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1294  -30
    arc_2_0_20  depot_departure_or_bypass_1527  1
    arc_2_0_20  in_degree_1587  1
    arc_2_0_20  original_T_including_depot_unload_1600  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1294  1
    load_2_0_20  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1295  -30
    arc_2_0_21  depot_departure_or_bypass_1527  1
    arc_2_0_21  in_degree_1593  1
    arc_2_0_21  original_T_including_depot_unload_1600  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1295  1
    load_2_0_21  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1296  -30
    arc_2_11_0  depot_return_or_bypass_1528  1
    arc_2_11_0  out_degree_1529  1
    arc_2_11_0  original_T_including_depot_unload_1600  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1296  1
    load_2_11_0  segment_load_conservation_1533  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1297  -30
    arc_2_11_12  connected_order_arc_1298  -12
    arc_2_11_12  out_degree_1529  1
    arc_2_11_12  in_degree_1537  1
    arc_2_11_12  original_T_including_depot_unload_1600  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1297  1
    load_2_11_12  segment_load_conservation_1533  1
    load_2_11_12  segment_load_conservation_1540  -1
    load_2_11_12  segment_prefix_lb_1541  1
    load_2_11_12  segment_prefix_ub_1542  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1299  -30
    arc_2_11_13  connected_order_arc_1300  -12
    arc_2_11_13  out_degree_1529  1
    arc_2_11_13  in_degree_1544  1
    arc_2_11_13  original_T_including_depot_unload_1600  1.1077505469776054e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1299  1
    load_2_11_13  segment_load_conservation_1533  1
    load_2_11_13  segment_load_conservation_1547  -1
    load_2_11_13  segment_prefix_lb_1548  1
    load_2_11_13  segment_prefix_ub_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1301  -30
    arc_2_11_14  connected_order_arc_1302  -12
    arc_2_11_14  out_degree_1529  1
    arc_2_11_14  in_degree_1551  1
    arc_2_11_14  original_T_including_depot_unload_1600  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1301  1
    load_2_11_14  segment_load_conservation_1533  1
    load_2_11_14  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1303  -30
    arc_2_11_15  connected_order_arc_1304  -12
    arc_2_11_15  out_degree_1529  1
    arc_2_11_15  in_degree_1557  1
    arc_2_11_15  original_T_including_depot_unload_1600  7.0350721341213284e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1303  1
    load_2_11_15  segment_load_conservation_1533  1
    load_2_11_15  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1305  -30
    arc_2_11_16  connected_order_arc_1306  -12
    arc_2_11_16  out_degree_1529  1
    arc_2_11_16  in_degree_1563  1
    arc_2_11_16  original_T_including_depot_unload_1600  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1305  1
    load_2_11_16  segment_load_conservation_1533  1
    load_2_11_16  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1307  -30
    arc_2_11_17  connected_order_arc_1308  -12
    arc_2_11_17  out_degree_1529  1
    arc_2_11_17  in_degree_1569  1
    arc_2_11_17  original_T_including_depot_unload_1600  1.0453757248865720e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1307  1
    load_2_11_17  segment_load_conservation_1533  1
    load_2_11_17  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1309  -30
    arc_2_11_18  connected_order_arc_1310  -12
    arc_2_11_18  out_degree_1529  1
    arc_2_11_18  in_degree_1575  1
    arc_2_11_18  original_T_including_depot_unload_1600  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1309  1
    load_2_11_18  segment_load_conservation_1533  1
    load_2_11_18  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1311  -30
    arc_2_11_19  connected_order_arc_1312  -12
    arc_2_11_19  out_degree_1529  1
    arc_2_11_19  in_degree_1581  1
    arc_2_11_19  original_T_including_depot_unload_1600  1.1485840683203917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1311  1
    load_2_11_19  segment_load_conservation_1533  1
    load_2_11_19  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1313  -30
    arc_2_11_20  connected_order_arc_1314  -12
    arc_2_11_20  out_degree_1529  1
    arc_2_11_20  in_degree_1587  1
    arc_2_11_20  original_T_including_depot_unload_1600  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1313  1
    load_2_11_20  segment_load_conservation_1533  1
    load_2_11_20  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1315  -30
    arc_2_11_21  connected_order_arc_1316  -12
    arc_2_11_21  out_degree_1529  1
    arc_2_11_21  in_degree_1593  1
    arc_2_11_21  original_T_including_depot_unload_1600  6.5332321619697848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1315  1
    load_2_11_21  segment_load_conservation_1533  1
    load_2_11_21  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1317  -30
    arc_2_12_0  depot_return_or_bypass_1528  1
    arc_2_12_0  out_degree_1536  1
    arc_2_12_0  original_T_including_depot_unload_1600  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1317  1
    load_2_12_0  segment_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1318  -30
    arc_2_12_11  connected_order_arc_1319  -12
    arc_2_12_11  in_degree_1530  1
    arc_2_12_11  out_degree_1536  1
    arc_2_12_11  original_T_including_depot_unload_1600  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1318  1
    load_2_12_11  segment_load_conservation_1533  -1
    load_2_12_11  segment_prefix_lb_1534  1
    load_2_12_11  segment_prefix_ub_1535  1
    load_2_12_11  segment_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1320  -30
    arc_2_12_13  connected_order_arc_1321  -12
    arc_2_12_13  out_degree_1536  1
    arc_2_12_13  in_degree_1544  1
    arc_2_12_13  original_T_including_depot_unload_1600  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1320  1
    load_2_12_13  segment_load_conservation_1540  1
    load_2_12_13  segment_load_conservation_1547  -1
    load_2_12_13  segment_prefix_lb_1548  1
    load_2_12_13  segment_prefix_ub_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1322  -30
    arc_2_12_14  connected_order_arc_1323  -12
    arc_2_12_14  out_degree_1536  1
    arc_2_12_14  in_degree_1551  1
    arc_2_12_14  original_T_including_depot_unload_1600  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1322  1
    load_2_12_14  segment_load_conservation_1540  1
    load_2_12_14  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1324  -30
    arc_2_12_15  connected_order_arc_1325  -12
    arc_2_12_15  out_degree_1536  1
    arc_2_12_15  in_degree_1557  1
    arc_2_12_15  original_T_including_depot_unload_1600  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1324  1
    load_2_12_15  segment_load_conservation_1540  1
    load_2_12_15  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1326  -30
    arc_2_12_16  connected_order_arc_1327  -12
    arc_2_12_16  out_degree_1536  1
    arc_2_12_16  in_degree_1563  1
    arc_2_12_16  original_T_including_depot_unload_1600  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1326  1
    load_2_12_16  segment_load_conservation_1540  1
    load_2_12_16  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1328  -30
    arc_2_12_17  connected_order_arc_1329  -12
    arc_2_12_17  out_degree_1536  1
    arc_2_12_17  in_degree_1569  1
    arc_2_12_17  original_T_including_depot_unload_1600  1.5230919127946252e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1328  1
    load_2_12_17  segment_load_conservation_1540  1
    load_2_12_17  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1330  -30
    arc_2_12_18  connected_order_arc_1331  -12
    arc_2_12_18  out_degree_1536  1
    arc_2_12_18  in_degree_1575  1
    arc_2_12_18  original_T_including_depot_unload_1600  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1330  1
    load_2_12_18  segment_load_conservation_1540  1
    load_2_12_18  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1332  -30
    arc_2_12_19  connected_order_arc_1333  -12
    arc_2_12_19  out_degree_1536  1
    arc_2_12_19  in_degree_1581  1
    arc_2_12_19  original_T_including_depot_unload_1600  1.5942479163822793e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1332  1
    load_2_12_19  segment_load_conservation_1540  1
    load_2_12_19  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1334  -30
    arc_2_12_20  connected_order_arc_1335  -12
    arc_2_12_20  out_degree_1536  1
    arc_2_12_20  in_degree_1587  1
    arc_2_12_20  original_T_including_depot_unload_1600  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1334  1
    load_2_12_20  segment_load_conservation_1540  1
    load_2_12_20  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1336  -30
    arc_2_12_21  connected_order_arc_1337  -12
    arc_2_12_21  out_degree_1536  1
    arc_2_12_21  in_degree_1593  1
    arc_2_12_21  original_T_including_depot_unload_1600  904.837890445026
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1336  1
    load_2_12_21  segment_load_conservation_1540  1
    load_2_12_21  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1338  -30
    arc_2_13_0  depot_return_or_bypass_1528  1
    arc_2_13_0  out_degree_1543  1
    arc_2_13_0  original_T_including_depot_unload_1600  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1338  1
    load_2_13_0  segment_load_conservation_1547  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1339  -30
    arc_2_13_11  connected_order_arc_1340  -12
    arc_2_13_11  in_degree_1530  1
    arc_2_13_11  out_degree_1543  1
    arc_2_13_11  original_T_including_depot_unload_1600  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1339  1
    load_2_13_11  segment_load_conservation_1533  -1
    load_2_13_11  segment_prefix_lb_1534  1
    load_2_13_11  segment_prefix_ub_1535  1
    load_2_13_11  segment_load_conservation_1547  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1341  -30
    arc_2_13_12  connected_order_arc_1342  -12
    arc_2_13_12  in_degree_1537  1
    arc_2_13_12  out_degree_1543  1
    arc_2_13_12  original_T_including_depot_unload_1600  1.4593103211867947e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1341  1
    load_2_13_12  segment_load_conservation_1540  -1
    load_2_13_12  segment_prefix_lb_1541  1
    load_2_13_12  segment_prefix_ub_1542  1
    load_2_13_12  segment_load_conservation_1547  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1343  -30
    arc_2_13_14  connected_order_arc_1344  -12
    arc_2_13_14  out_degree_1543  1
    arc_2_13_14  in_degree_1551  1
    arc_2_13_14  original_T_including_depot_unload_1600  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1343  1
    load_2_13_14  segment_load_conservation_1547  1
    load_2_13_14  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1345  -30
    arc_2_13_15  connected_order_arc_1346  -12
    arc_2_13_15  out_degree_1543  1
    arc_2_13_15  in_degree_1557  1
    arc_2_13_15  original_T_including_depot_unload_1600  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1345  1
    load_2_13_15  segment_load_conservation_1547  1
    load_2_13_15  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1347  -30
    arc_2_13_16  connected_order_arc_1348  -12
    arc_2_13_16  out_degree_1543  1
    arc_2_13_16  in_degree_1563  1
    arc_2_13_16  original_T_including_depot_unload_1600  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1347  1
    load_2_13_16  segment_load_conservation_1547  1
    load_2_13_16  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1349  -30
    arc_2_13_17  connected_order_arc_1350  -12
    arc_2_13_17  out_degree_1543  1
    arc_2_13_17  in_degree_1569  1
    arc_2_13_17  original_T_including_depot_unload_1600  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1349  1
    load_2_13_17  segment_load_conservation_1547  1
    load_2_13_17  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1351  -30
    arc_2_13_18  connected_order_arc_1352  -12
    arc_2_13_18  out_degree_1543  1
    arc_2_13_18  in_degree_1575  1
    arc_2_13_18  original_T_including_depot_unload_1600  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1351  1
    load_2_13_18  segment_load_conservation_1547  1
    load_2_13_18  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1353  -30
    arc_2_13_19  connected_order_arc_1354  -12
    arc_2_13_19  out_degree_1543  1
    arc_2_13_19  in_degree_1581  1
    arc_2_13_19  original_T_including_depot_unload_1600  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1353  1
    load_2_13_19  segment_load_conservation_1547  1
    load_2_13_19  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1355  -30
    arc_2_13_20  connected_order_arc_1356  -12
    arc_2_13_20  out_degree_1543  1
    arc_2_13_20  in_degree_1587  1
    arc_2_13_20  original_T_including_depot_unload_1600  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1355  1
    load_2_13_20  segment_load_conservation_1547  1
    load_2_13_20  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1357  -30
    arc_2_13_21  connected_order_arc_1358  -12
    arc_2_13_21  out_degree_1543  1
    arc_2_13_21  in_degree_1593  1
    arc_2_13_21  original_T_including_depot_unload_1600  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1357  1
    load_2_13_21  segment_load_conservation_1547  1
    load_2_13_21  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1359  -30
    arc_2_14_0  depot_return_or_bypass_1528  1
    arc_2_14_0  out_degree_1550  1
    arc_2_14_0  original_T_including_depot_unload_1600  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1359  1
    load_2_14_0  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1360  -30
    arc_2_14_11  connected_order_arc_1361  -12
    arc_2_14_11  in_degree_1530  1
    arc_2_14_11  out_degree_1550  1
    arc_2_14_11  original_T_including_depot_unload_1600  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1360  1
    load_2_14_11  segment_load_conservation_1533  -1
    load_2_14_11  segment_prefix_lb_1534  1
    load_2_14_11  segment_prefix_ub_1535  1
    load_2_14_11  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1362  -30
    arc_2_14_12  connected_order_arc_1363  -12
    arc_2_14_12  in_degree_1537  1
    arc_2_14_12  out_degree_1550  1
    arc_2_14_12  original_T_including_depot_unload_1600  1.4088953223409719e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1362  1
    load_2_14_12  segment_load_conservation_1540  -1
    load_2_14_12  segment_prefix_lb_1541  1
    load_2_14_12  segment_prefix_ub_1542  1
    load_2_14_12  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1364  -30
    arc_2_14_13  connected_order_arc_1365  -12
    arc_2_14_13  in_degree_1544  1
    arc_2_14_13  out_degree_1550  1
    arc_2_14_13  original_T_including_depot_unload_1600  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1364  1
    load_2_14_13  segment_load_conservation_1547  -1
    load_2_14_13  segment_prefix_lb_1548  1
    load_2_14_13  segment_prefix_ub_1549  1
    load_2_14_13  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1366  -30
    arc_2_14_15  connected_order_arc_1367  -12
    arc_2_14_15  out_degree_1550  1
    arc_2_14_15  in_degree_1557  1
    arc_2_14_15  original_T_including_depot_unload_1600  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1366  1
    load_2_14_15  free_load_conservation_1555  1
    load_2_14_15  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1368  -30
    arc_2_14_16  connected_order_arc_1369  -12
    arc_2_14_16  out_degree_1550  1
    arc_2_14_16  in_degree_1563  1
    arc_2_14_16  original_T_including_depot_unload_1600  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1368  1
    load_2_14_16  free_load_conservation_1555  1
    load_2_14_16  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1370  -30
    arc_2_14_17  connected_order_arc_1371  -12
    arc_2_14_17  out_degree_1550  1
    arc_2_14_17  in_degree_1569  1
    arc_2_14_17  original_T_including_depot_unload_1600  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1370  1
    load_2_14_17  free_load_conservation_1555  1
    load_2_14_17  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1372  -30
    arc_2_14_18  connected_order_arc_1373  -12
    arc_2_14_18  out_degree_1550  1
    arc_2_14_18  in_degree_1575  1
    arc_2_14_18  original_T_including_depot_unload_1600  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1372  1
    load_2_14_18  free_load_conservation_1555  1
    load_2_14_18  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1374  -30
    arc_2_14_19  connected_order_arc_1375  -12
    arc_2_14_19  out_degree_1550  1
    arc_2_14_19  in_degree_1581  1
    arc_2_14_19  original_T_including_depot_unload_1600  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1374  1
    load_2_14_19  free_load_conservation_1555  1
    load_2_14_19  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1376  -30
    arc_2_14_20  connected_order_arc_1377  -12
    arc_2_14_20  out_degree_1550  1
    arc_2_14_20  in_degree_1587  1
    arc_2_14_20  original_T_including_depot_unload_1600  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1376  1
    load_2_14_20  free_load_conservation_1555  1
    load_2_14_20  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1378  -30
    arc_2_14_21  connected_order_arc_1379  -12
    arc_2_14_21  out_degree_1550  1
    arc_2_14_21  in_degree_1593  1
    arc_2_14_21  original_T_including_depot_unload_1600  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1378  1
    load_2_14_21  free_load_conservation_1555  1
    load_2_14_21  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1380  -30
    arc_2_15_0  depot_return_or_bypass_1528  1
    arc_2_15_0  out_degree_1556  1
    arc_2_15_0  original_T_including_depot_unload_1600  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1380  1
    load_2_15_0  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1381  -30
    arc_2_15_11  connected_order_arc_1382  -12
    arc_2_15_11  in_degree_1530  1
    arc_2_15_11  out_degree_1556  1
    arc_2_15_11  original_T_including_depot_unload_1600  7.0350721341213284e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1381  1
    load_2_15_11  segment_load_conservation_1533  -1
    load_2_15_11  segment_prefix_lb_1534  1
    load_2_15_11  segment_prefix_ub_1535  1
    load_2_15_11  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1383  -30
    arc_2_15_12  connected_order_arc_1384  -12
    arc_2_15_12  in_degree_1537  1
    arc_2_15_12  out_degree_1556  1
    arc_2_15_12  original_T_including_depot_unload_1600  1.2686001679750689e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1383  1
    load_2_15_12  segment_load_conservation_1540  -1
    load_2_15_12  segment_prefix_lb_1541  1
    load_2_15_12  segment_prefix_ub_1542  1
    load_2_15_12  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1385  -30
    arc_2_15_13  connected_order_arc_1386  -12
    arc_2_15_13  in_degree_1544  1
    arc_2_15_13  out_degree_1556  1
    arc_2_15_13  original_T_including_depot_unload_1600  1.7644788835951622e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1385  1
    load_2_15_13  segment_load_conservation_1547  -1
    load_2_15_13  segment_prefix_lb_1548  1
    load_2_15_13  segment_prefix_ub_1549  1
    load_2_15_13  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1387  -30
    arc_2_15_14  connected_order_arc_1388  -12
    arc_2_15_14  in_degree_1551  1
    arc_2_15_14  out_degree_1556  1
    arc_2_15_14  original_T_including_depot_unload_1600  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1387  1
    load_2_15_14  free_load_conservation_1555  -1
    load_2_15_14  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1389  -30
    arc_2_15_16  connected_order_arc_1390  -12
    arc_2_15_16  out_degree_1556  1
    arc_2_15_16  in_degree_1563  1
    arc_2_15_16  original_T_including_depot_unload_1600  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1389  1
    load_2_15_16  free_load_conservation_1561  1
    load_2_15_16  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1391  -30
    arc_2_15_17  connected_order_arc_1392  -12
    arc_2_15_17  out_degree_1556  1
    arc_2_15_17  in_degree_1569  1
    arc_2_15_17  original_T_including_depot_unload_1600  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1391  1
    load_2_15_17  free_load_conservation_1561  1
    load_2_15_17  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1393  -30
    arc_2_15_18  connected_order_arc_1394  -12
    arc_2_15_18  out_degree_1556  1
    arc_2_15_18  in_degree_1575  1
    arc_2_15_18  original_T_including_depot_unload_1600  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1393  1
    load_2_15_18  free_load_conservation_1561  1
    load_2_15_18  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1395  -30
    arc_2_15_19  connected_order_arc_1396  -12
    arc_2_15_19  out_degree_1556  1
    arc_2_15_19  in_degree_1581  1
    arc_2_15_19  original_T_including_depot_unload_1600  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1395  1
    load_2_15_19  free_load_conservation_1561  1
    load_2_15_19  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1397  -30
    arc_2_15_20  connected_order_arc_1398  -12
    arc_2_15_20  out_degree_1556  1
    arc_2_15_20  in_degree_1587  1
    arc_2_15_20  original_T_including_depot_unload_1600  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1397  1
    load_2_15_20  free_load_conservation_1561  1
    load_2_15_20  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1399  -30
    arc_2_15_21  connected_order_arc_1400  -12
    arc_2_15_21  out_degree_1556  1
    arc_2_15_21  in_degree_1593  1
    arc_2_15_21  original_T_including_depot_unload_1600  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1399  1
    load_2_15_21  free_load_conservation_1561  1
    load_2_15_21  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1401  -30
    arc_2_16_0  depot_return_or_bypass_1528  1
    arc_2_16_0  out_degree_1562  1
    arc_2_16_0  original_T_including_depot_unload_1600  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1401  1
    load_2_16_0  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1402  -30
    arc_2_16_11  connected_order_arc_1403  -12
    arc_2_16_11  in_degree_1530  1
    arc_2_16_11  out_degree_1562  1
    arc_2_16_11  original_T_including_depot_unload_1600  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1402  1
    load_2_16_11  segment_load_conservation_1533  -1
    load_2_16_11  segment_prefix_lb_1534  1
    load_2_16_11  segment_prefix_ub_1535  1
    load_2_16_11  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1404  -30
    arc_2_16_12  connected_order_arc_1405  -12
    arc_2_16_12  in_degree_1537  1
    arc_2_16_12  out_degree_1562  1
    arc_2_16_12  original_T_including_depot_unload_1600  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1404  1
    load_2_16_12  segment_load_conservation_1540  -1
    load_2_16_12  segment_prefix_lb_1541  1
    load_2_16_12  segment_prefix_ub_1542  1
    load_2_16_12  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1406  -30
    arc_2_16_13  connected_order_arc_1407  -12
    arc_2_16_13  in_degree_1544  1
    arc_2_16_13  out_degree_1562  1
    arc_2_16_13  original_T_including_depot_unload_1600  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1406  1
    load_2_16_13  segment_load_conservation_1547  -1
    load_2_16_13  segment_prefix_lb_1548  1
    load_2_16_13  segment_prefix_ub_1549  1
    load_2_16_13  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1408  -30
    arc_2_16_14  connected_order_arc_1409  -12
    arc_2_16_14  in_degree_1551  1
    arc_2_16_14  out_degree_1562  1
    arc_2_16_14  original_T_including_depot_unload_1600  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1408  1
    load_2_16_14  free_load_conservation_1555  -1
    load_2_16_14  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1410  -30
    arc_2_16_15  connected_order_arc_1411  -12
    arc_2_16_15  in_degree_1557  1
    arc_2_16_15  out_degree_1562  1
    arc_2_16_15  original_T_including_depot_unload_1600  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1410  1
    load_2_16_15  free_load_conservation_1561  -1
    load_2_16_15  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1412  -30
    arc_2_16_17  connected_order_arc_1413  -12
    arc_2_16_17  out_degree_1562  1
    arc_2_16_17  in_degree_1569  1
    arc_2_16_17  original_T_including_depot_unload_1600  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1412  1
    load_2_16_17  free_load_conservation_1567  1
    load_2_16_17  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1414  -30
    arc_2_16_18  connected_order_arc_1415  -12
    arc_2_16_18  out_degree_1562  1
    arc_2_16_18  in_degree_1575  1
    arc_2_16_18  original_T_including_depot_unload_1600  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1414  1
    load_2_16_18  free_load_conservation_1567  1
    load_2_16_18  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1416  -30
    arc_2_16_19  connected_order_arc_1417  -12
    arc_2_16_19  out_degree_1562  1
    arc_2_16_19  in_degree_1581  1
    arc_2_16_19  original_T_including_depot_unload_1600  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1416  1
    load_2_16_19  free_load_conservation_1567  1
    load_2_16_19  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1418  -30
    arc_2_16_20  connected_order_arc_1419  -12
    arc_2_16_20  out_degree_1562  1
    arc_2_16_20  in_degree_1587  1
    arc_2_16_20  original_T_including_depot_unload_1600  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1418  1
    load_2_16_20  free_load_conservation_1567  1
    load_2_16_20  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1420  -30
    arc_2_16_21  connected_order_arc_1421  -12
    arc_2_16_21  out_degree_1562  1
    arc_2_16_21  in_degree_1593  1
    arc_2_16_21  original_T_including_depot_unload_1600  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1420  1
    load_2_16_21  free_load_conservation_1567  1
    load_2_16_21  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1422  -30
    arc_2_17_0  depot_return_or_bypass_1528  1
    arc_2_17_0  out_degree_1568  1
    arc_2_17_0  original_T_including_depot_unload_1600  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1422  1
    load_2_17_0  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1423  -30
    arc_2_17_11  connected_order_arc_1424  -12
    arc_2_17_11  in_degree_1530  1
    arc_2_17_11  out_degree_1568  1
    arc_2_17_11  original_T_including_depot_unload_1600  1.0453757248865720e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1423  1
    load_2_17_11  segment_load_conservation_1533  -1
    load_2_17_11  segment_prefix_lb_1534  1
    load_2_17_11  segment_prefix_ub_1535  1
    load_2_17_11  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1425  -30
    arc_2_17_12  connected_order_arc_1426  -12
    arc_2_17_12  in_degree_1537  1
    arc_2_17_12  out_degree_1568  1
    arc_2_17_12  original_T_including_depot_unload_1600  1.6461188122693993e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1425  1
    load_2_17_12  segment_load_conservation_1540  -1
    load_2_17_12  segment_prefix_lb_1541  1
    load_2_17_12  segment_prefix_ub_1542  1
    load_2_17_12  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1427  -30
    arc_2_17_13  connected_order_arc_1428  -12
    arc_2_17_13  in_degree_1544  1
    arc_2_17_13  out_degree_1568  1
    arc_2_17_13  original_T_including_depot_unload_1600  2.0027314450664605e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1427  1
    load_2_17_13  segment_load_conservation_1547  -1
    load_2_17_13  segment_prefix_lb_1548  1
    load_2_17_13  segment_prefix_ub_1549  1
    load_2_17_13  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1429  -30
    arc_2_17_14  connected_order_arc_1430  -12
    arc_2_17_14  in_degree_1551  1
    arc_2_17_14  out_degree_1568  1
    arc_2_17_14  original_T_including_depot_unload_1600  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1429  1
    load_2_17_14  free_load_conservation_1555  -1
    load_2_17_14  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1431  -30
    arc_2_17_15  connected_order_arc_1432  -12
    arc_2_17_15  in_degree_1557  1
    arc_2_17_15  out_degree_1568  1
    arc_2_17_15  original_T_including_depot_unload_1600  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1431  1
    load_2_17_15  free_load_conservation_1561  -1
    load_2_17_15  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1433  -30
    arc_2_17_16  connected_order_arc_1434  -12
    arc_2_17_16  in_degree_1563  1
    arc_2_17_16  out_degree_1568  1
    arc_2_17_16  original_T_including_depot_unload_1600  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1433  1
    load_2_17_16  free_load_conservation_1567  -1
    load_2_17_16  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1435  -30
    arc_2_17_18  connected_order_arc_1436  -12
    arc_2_17_18  out_degree_1568  1
    arc_2_17_18  in_degree_1575  1
    arc_2_17_18  original_T_including_depot_unload_1600  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1435  1
    load_2_17_18  free_load_conservation_1573  1
    load_2_17_18  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1437  -30
    arc_2_17_19  connected_order_arc_1438  -12
    arc_2_17_19  out_degree_1568  1
    arc_2_17_19  in_degree_1581  1
    arc_2_17_19  original_T_including_depot_unload_1600  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1437  1
    load_2_17_19  free_load_conservation_1573  1
    load_2_17_19  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1439  -30
    arc_2_17_20  connected_order_arc_1440  -12
    arc_2_17_20  out_degree_1568  1
    arc_2_17_20  in_degree_1587  1
    arc_2_17_20  original_T_including_depot_unload_1600  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1439  1
    load_2_17_20  free_load_conservation_1573  1
    load_2_17_20  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1441  -30
    arc_2_17_21  connected_order_arc_1442  -12
    arc_2_17_21  out_degree_1568  1
    arc_2_17_21  in_degree_1593  1
    arc_2_17_21  original_T_including_depot_unload_1600  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1441  1
    load_2_17_21  free_load_conservation_1573  1
    load_2_17_21  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1443  -30
    arc_2_18_0  depot_return_or_bypass_1528  1
    arc_2_18_0  out_degree_1574  1
    arc_2_18_0  original_T_including_depot_unload_1600  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1443  1
    load_2_18_0  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1444  -30
    arc_2_18_11  connected_order_arc_1445  -12
    arc_2_18_11  in_degree_1530  1
    arc_2_18_11  out_degree_1574  1
    arc_2_18_11  original_T_including_depot_unload_1600  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1444  1
    load_2_18_11  segment_load_conservation_1533  -1
    load_2_18_11  segment_prefix_lb_1534  1
    load_2_18_11  segment_prefix_ub_1535  1
    load_2_18_11  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1446  -30
    arc_2_18_12  connected_order_arc_1447  -12
    arc_2_18_12  in_degree_1537  1
    arc_2_18_12  out_degree_1574  1
    arc_2_18_12  original_T_including_depot_unload_1600  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1446  1
    load_2_18_12  segment_load_conservation_1540  -1
    load_2_18_12  segment_prefix_lb_1541  1
    load_2_18_12  segment_prefix_ub_1542  1
    load_2_18_12  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1448  -30
    arc_2_18_13  connected_order_arc_1449  -12
    arc_2_18_13  in_degree_1544  1
    arc_2_18_13  out_degree_1574  1
    arc_2_18_13  original_T_including_depot_unload_1600  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1448  1
    load_2_18_13  segment_load_conservation_1547  -1
    load_2_18_13  segment_prefix_lb_1548  1
    load_2_18_13  segment_prefix_ub_1549  1
    load_2_18_13  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1450  -30
    arc_2_18_14  connected_order_arc_1451  -12
    arc_2_18_14  in_degree_1551  1
    arc_2_18_14  out_degree_1574  1
    arc_2_18_14  original_T_including_depot_unload_1600  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1450  1
    load_2_18_14  free_load_conservation_1555  -1
    load_2_18_14  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1452  -30
    arc_2_18_15  connected_order_arc_1453  -12
    arc_2_18_15  in_degree_1557  1
    arc_2_18_15  out_degree_1574  1
    arc_2_18_15  original_T_including_depot_unload_1600  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1452  1
    load_2_18_15  free_load_conservation_1561  -1
    load_2_18_15  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1454  -30
    arc_2_18_16  connected_order_arc_1455  -12
    arc_2_18_16  in_degree_1563  1
    arc_2_18_16  out_degree_1574  1
    arc_2_18_16  original_T_including_depot_unload_1600  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1454  1
    load_2_18_16  free_load_conservation_1567  -1
    load_2_18_16  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1456  -30
    arc_2_18_17  connected_order_arc_1457  -12
    arc_2_18_17  in_degree_1569  1
    arc_2_18_17  out_degree_1574  1
    arc_2_18_17  original_T_including_depot_unload_1600  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1456  1
    load_2_18_17  free_load_conservation_1573  -1
    load_2_18_17  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1458  -30
    arc_2_18_19  connected_order_arc_1459  -12
    arc_2_18_19  out_degree_1574  1
    arc_2_18_19  in_degree_1581  1
    arc_2_18_19  original_T_including_depot_unload_1600  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1458  1
    load_2_18_19  free_load_conservation_1579  1
    load_2_18_19  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1460  -30
    arc_2_18_20  connected_order_arc_1461  -12
    arc_2_18_20  out_degree_1574  1
    arc_2_18_20  in_degree_1587  1
    arc_2_18_20  original_T_including_depot_unload_1600  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1460  1
    load_2_18_20  free_load_conservation_1579  1
    load_2_18_20  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1462  -30
    arc_2_18_21  connected_order_arc_1463  -12
    arc_2_18_21  out_degree_1574  1
    arc_2_18_21  in_degree_1593  1
    arc_2_18_21  original_T_including_depot_unload_1600  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1462  1
    load_2_18_21  free_load_conservation_1579  1
    load_2_18_21  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1464  -30
    arc_2_19_0  depot_return_or_bypass_1528  1
    arc_2_19_0  out_degree_1580  1
    arc_2_19_0  original_T_including_depot_unload_1600  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1464  1
    load_2_19_0  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1465  -30
    arc_2_19_11  connected_order_arc_1466  -12
    arc_2_19_11  in_degree_1530  1
    arc_2_19_11  out_degree_1580  1
    arc_2_19_11  original_T_including_depot_unload_1600  1.1485840683203917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1465  1
    load_2_19_11  segment_load_conservation_1533  -1
    load_2_19_11  segment_prefix_lb_1534  1
    load_2_19_11  segment_prefix_ub_1535  1
    load_2_19_11  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1467  -30
    arc_2_19_12  connected_order_arc_1468  -12
    arc_2_19_12  in_degree_1537  1
    arc_2_19_12  out_degree_1580  1
    arc_2_19_12  original_T_including_depot_unload_1600  1.6809955292555005e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1467  1
    load_2_19_12  segment_load_conservation_1540  -1
    load_2_19_12  segment_prefix_lb_1541  1
    load_2_19_12  segment_prefix_ub_1542  1
    load_2_19_12  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1469  -30
    arc_2_19_13  connected_order_arc_1470  -12
    arc_2_19_13  in_degree_1544  1
    arc_2_19_13  out_degree_1580  1
    arc_2_19_13  original_T_including_depot_unload_1600  2.1139218026901112e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1469  1
    load_2_19_13  segment_load_conservation_1547  -1
    load_2_19_13  segment_prefix_lb_1548  1
    load_2_19_13  segment_prefix_ub_1549  1
    load_2_19_13  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1471  -30
    arc_2_19_14  connected_order_arc_1472  -12
    arc_2_19_14  in_degree_1551  1
    arc_2_19_14  out_degree_1580  1
    arc_2_19_14  original_T_including_depot_unload_1600  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1471  1
    load_2_19_14  free_load_conservation_1555  -1
    load_2_19_14  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1473  -30
    arc_2_19_15  connected_order_arc_1474  -12
    arc_2_19_15  in_degree_1557  1
    arc_2_19_15  out_degree_1580  1
    arc_2_19_15  original_T_including_depot_unload_1600  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1473  1
    load_2_19_15  free_load_conservation_1561  -1
    load_2_19_15  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1475  -30
    arc_2_19_16  connected_order_arc_1476  -12
    arc_2_19_16  in_degree_1563  1
    arc_2_19_16  out_degree_1580  1
    arc_2_19_16  original_T_including_depot_unload_1600  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1475  1
    load_2_19_16  free_load_conservation_1567  -1
    load_2_19_16  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1477  -30
    arc_2_19_17  connected_order_arc_1478  -12
    arc_2_19_17  in_degree_1569  1
    arc_2_19_17  out_degree_1580  1
    arc_2_19_17  original_T_including_depot_unload_1600  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1477  1
    load_2_19_17  free_load_conservation_1573  -1
    load_2_19_17  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1479  -30
    arc_2_19_18  connected_order_arc_1480  -12
    arc_2_19_18  in_degree_1575  1
    arc_2_19_18  out_degree_1580  1
    arc_2_19_18  original_T_including_depot_unload_1600  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1479  1
    load_2_19_18  free_load_conservation_1579  -1
    load_2_19_18  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1481  -30
    arc_2_19_20  connected_order_arc_1482  -12
    arc_2_19_20  out_degree_1580  1
    arc_2_19_20  in_degree_1587  1
    arc_2_19_20  original_T_including_depot_unload_1600  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1481  1
    load_2_19_20  free_load_conservation_1585  1
    load_2_19_20  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1483  -30
    arc_2_19_21  connected_order_arc_1484  -12
    arc_2_19_21  out_degree_1580  1
    arc_2_19_21  in_degree_1593  1
    arc_2_19_21  original_T_including_depot_unload_1600  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1483  1
    load_2_19_21  free_load_conservation_1585  1
    load_2_19_21  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1485  -30
    arc_2_20_0  depot_return_or_bypass_1528  1
    arc_2_20_0  out_degree_1586  1
    arc_2_20_0  original_T_including_depot_unload_1600  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1485  1
    load_2_20_0  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1486  -30
    arc_2_20_11  connected_order_arc_1487  -12
    arc_2_20_11  in_degree_1530  1
    arc_2_20_11  out_degree_1586  1
    arc_2_20_11  original_T_including_depot_unload_1600  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1486  1
    load_2_20_11  segment_load_conservation_1533  -1
    load_2_20_11  segment_prefix_lb_1534  1
    load_2_20_11  segment_prefix_ub_1535  1
    load_2_20_11  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1488  -30
    arc_2_20_12  connected_order_arc_1489  -12
    arc_2_20_12  in_degree_1537  1
    arc_2_20_12  out_degree_1586  1
    arc_2_20_12  original_T_including_depot_unload_1600  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1488  1
    load_2_20_12  segment_load_conservation_1540  -1
    load_2_20_12  segment_prefix_lb_1541  1
    load_2_20_12  segment_prefix_ub_1542  1
    load_2_20_12  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1490  -30
    arc_2_20_13  connected_order_arc_1491  -12
    arc_2_20_13  in_degree_1544  1
    arc_2_20_13  out_degree_1586  1
    arc_2_20_13  original_T_including_depot_unload_1600  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1490  1
    load_2_20_13  segment_load_conservation_1547  -1
    load_2_20_13  segment_prefix_lb_1548  1
    load_2_20_13  segment_prefix_ub_1549  1
    load_2_20_13  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1492  -30
    arc_2_20_14  connected_order_arc_1493  -12
    arc_2_20_14  in_degree_1551  1
    arc_2_20_14  out_degree_1586  1
    arc_2_20_14  original_T_including_depot_unload_1600  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1492  1
    load_2_20_14  free_load_conservation_1555  -1
    load_2_20_14  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1494  -30
    arc_2_20_15  connected_order_arc_1495  -12
    arc_2_20_15  in_degree_1557  1
    arc_2_20_15  out_degree_1586  1
    arc_2_20_15  original_T_including_depot_unload_1600  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1494  1
    load_2_20_15  free_load_conservation_1561  -1
    load_2_20_15  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1496  -30
    arc_2_20_16  connected_order_arc_1497  -12
    arc_2_20_16  in_degree_1563  1
    arc_2_20_16  out_degree_1586  1
    arc_2_20_16  original_T_including_depot_unload_1600  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1496  1
    load_2_20_16  free_load_conservation_1567  -1
    load_2_20_16  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1498  -30
    arc_2_20_17  connected_order_arc_1499  -12
    arc_2_20_17  in_degree_1569  1
    arc_2_20_17  out_degree_1586  1
    arc_2_20_17  original_T_including_depot_unload_1600  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1498  1
    load_2_20_17  free_load_conservation_1573  -1
    load_2_20_17  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1500  -30
    arc_2_20_18  connected_order_arc_1501  -12
    arc_2_20_18  in_degree_1575  1
    arc_2_20_18  out_degree_1586  1
    arc_2_20_18  original_T_including_depot_unload_1600  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1500  1
    load_2_20_18  free_load_conservation_1579  -1
    load_2_20_18  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1502  -30
    arc_2_20_19  connected_order_arc_1503  -12
    arc_2_20_19  in_degree_1581  1
    arc_2_20_19  out_degree_1586  1
    arc_2_20_19  original_T_including_depot_unload_1600  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1502  1
    load_2_20_19  free_load_conservation_1585  -1
    load_2_20_19  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1504  -30
    arc_2_20_21  connected_order_arc_1505  -12
    arc_2_20_21  out_degree_1586  1
    arc_2_20_21  in_degree_1593  1
    arc_2_20_21  original_T_including_depot_unload_1600  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1504  1
    load_2_20_21  free_load_conservation_1591  1
    load_2_20_21  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1506  -30
    arc_2_21_0  depot_return_or_bypass_1528  1
    arc_2_21_0  out_degree_1592  1
    arc_2_21_0  original_T_including_depot_unload_1600  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1506  1
    load_2_21_0  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1507  -30
    arc_2_21_11  connected_order_arc_1508  -12
    arc_2_21_11  in_degree_1530  1
    arc_2_21_11  out_degree_1592  1
    arc_2_21_11  original_T_including_depot_unload_1600  6.5332321619697848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1507  1
    load_2_21_11  segment_load_conservation_1533  -1
    load_2_21_11  segment_prefix_lb_1534  1
    load_2_21_11  segment_prefix_ub_1535  1
    load_2_21_11  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1509  -30
    arc_2_21_12  connected_order_arc_1510  -12
    arc_2_21_12  in_degree_1537  1
    arc_2_21_12  out_degree_1592  1
    arc_2_21_12  original_T_including_depot_unload_1600  1.0510800781097112e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1509  1
    load_2_21_12  segment_load_conservation_1540  -1
    load_2_21_12  segment_prefix_lb_1541  1
    load_2_21_12  segment_prefix_ub_1542  1
    load_2_21_12  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1511  -30
    arc_2_21_13  connected_order_arc_1512  -12
    arc_2_21_13  in_degree_1544  1
    arc_2_21_13  out_degree_1592  1
    arc_2_21_13  original_T_including_depot_unload_1600  1.7563534000055533e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1511  1
    load_2_21_13  segment_load_conservation_1547  -1
    load_2_21_13  segment_prefix_lb_1548  1
    load_2_21_13  segment_prefix_ub_1549  1
    load_2_21_13  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1513  -30
    arc_2_21_14  connected_order_arc_1514  -12
    arc_2_21_14  in_degree_1551  1
    arc_2_21_14  out_degree_1592  1
    arc_2_21_14  original_T_including_depot_unload_1600  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1513  1
    load_2_21_14  free_load_conservation_1555  -1
    load_2_21_14  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1515  -30
    arc_2_21_15  connected_order_arc_1516  -12
    arc_2_21_15  in_degree_1557  1
    arc_2_21_15  out_degree_1592  1
    arc_2_21_15  original_T_including_depot_unload_1600  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1515  1
    load_2_21_15  free_load_conservation_1561  -1
    load_2_21_15  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1517  -30
    arc_2_21_16  connected_order_arc_1518  -12
    arc_2_21_16  in_degree_1563  1
    arc_2_21_16  out_degree_1592  1
    arc_2_21_16  original_T_including_depot_unload_1600  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1517  1
    load_2_21_16  free_load_conservation_1567  -1
    load_2_21_16  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1519  -30
    arc_2_21_17  connected_order_arc_1520  -12
    arc_2_21_17  in_degree_1569  1
    arc_2_21_17  out_degree_1592  1
    arc_2_21_17  original_T_including_depot_unload_1600  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1519  1
    load_2_21_17  free_load_conservation_1573  -1
    load_2_21_17  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1521  -30
    arc_2_21_18  connected_order_arc_1522  -12
    arc_2_21_18  in_degree_1575  1
    arc_2_21_18  out_degree_1592  1
    arc_2_21_18  original_T_including_depot_unload_1600  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1521  1
    load_2_21_18  free_load_conservation_1579  -1
    load_2_21_18  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1523  -30
    arc_2_21_19  connected_order_arc_1524  -12
    arc_2_21_19  in_degree_1581  1
    arc_2_21_19  out_degree_1592  1
    arc_2_21_19  original_T_including_depot_unload_1600  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1523  1
    load_2_21_19  free_load_conservation_1585  -1
    load_2_21_19  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1525  -30
    arc_2_21_20  connected_order_arc_1526  -12
    arc_2_21_20  in_degree_1587  1
    arc_2_21_20  out_degree_1592  1
    arc_2_21_20  original_T_including_depot_unload_1600  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1525  1
    load_2_21_20  free_load_conservation_1591  -1
    load_2_21_20  free_load_conservation_1597  1
RHS
    RHS1      OBJ       -4.7474999999999995e-01
    RHS1      onehot_16_26  1
    RHS1      onehot_11_55  1
    RHS1      onehot_31_84  1
    RHS1      onehot_20_113  1
    RHS1      onehot_32_142  1
    RHS1      onehot_21_177  1
    RHS1      onehot_2_212  1
    RHS1      onehot_7_251  1
    RHS1      stock_ub_255  36
    RHS1      parent_nonstrict_scope_256  3.6533100117025263e-01
    RHS1      normalization_313  1
    RHS1      connected_order_arc_439  -14
    RHS1      connected_order_arc_441  -14
    RHS1      connected_order_arc_443  -14
    RHS1      connected_order_arc_445  -14
    RHS1      connected_order_arc_447  -14
    RHS1      connected_order_arc_449  -14
    RHS1      connected_order_arc_451  -14
    RHS1      connected_order_arc_453  -14
    RHS1      connected_order_arc_455  -14
    RHS1      connected_order_arc_457  -14
    RHS1      connected_order_arc_459  -14
    RHS1      connected_order_arc_461  -14
    RHS1      connected_order_arc_463  -14
    RHS1      connected_order_arc_466  -14
    RHS1      connected_order_arc_468  -14
    RHS1      connected_order_arc_470  -14
    RHS1      connected_order_arc_472  -14
    RHS1      connected_order_arc_474  -14
    RHS1      connected_order_arc_476  -14
    RHS1      connected_order_arc_478  -14
    RHS1      connected_order_arc_480  -14
    RHS1      connected_order_arc_482  -14
    RHS1      connected_order_arc_484  -14
    RHS1      connected_order_arc_486  -14
    RHS1      connected_order_arc_488  -14
    RHS1      connected_order_arc_490  -14
    RHS1      connected_order_arc_493  -14
    RHS1      connected_order_arc_495  -14
    RHS1      connected_order_arc_497  -14
    RHS1      connected_order_arc_499  -14
    RHS1      connected_order_arc_501  -14
    RHS1      connected_order_arc_503  -14
    RHS1      connected_order_arc_505  -14
    RHS1      connected_order_arc_507  -14
    RHS1      connected_order_arc_509  -14
    RHS1      connected_order_arc_511  -14
    RHS1      connected_order_arc_513  -14
    RHS1      connected_order_arc_515  -14
    RHS1      connected_order_arc_517  -14
    RHS1      connected_order_arc_520  -14
    RHS1      connected_order_arc_522  -14
    RHS1      connected_order_arc_524  -14
    RHS1      connected_order_arc_526  -14
    RHS1      connected_order_arc_528  -14
    RHS1      connected_order_arc_530  -14
    RHS1      connected_order_arc_532  -14
    RHS1      connected_order_arc_534  -14
    RHS1      connected_order_arc_536  -14
    RHS1      connected_order_arc_538  -14
    RHS1      connected_order_arc_540  -14
    RHS1      connected_order_arc_542  -14
    RHS1      connected_order_arc_544  -14
    RHS1      connected_order_arc_547  -14
    RHS1      connected_order_arc_549  -14
    RHS1      connected_order_arc_551  -14
    RHS1      connected_order_arc_553  -14
    RHS1      connected_order_arc_555  -14
    RHS1      connected_order_arc_557  -14
    RHS1      connected_order_arc_559  -14
    RHS1      connected_order_arc_561  -14
    RHS1      connected_order_arc_563  -14
    RHS1      connected_order_arc_565  -14
    RHS1      connected_order_arc_567  -14
    RHS1      connected_order_arc_569  -14
    RHS1      connected_order_arc_571  -14
    RHS1      connected_order_arc_574  -14
    RHS1      connected_order_arc_576  -14
    RHS1      connected_order_arc_578  -14
    RHS1      connected_order_arc_580  -14
    RHS1      connected_order_arc_582  -14
    RHS1      connected_order_arc_584  -14
    RHS1      connected_order_arc_586  -14
    RHS1      connected_order_arc_588  -14
    RHS1      connected_order_arc_590  -14
    RHS1      connected_order_arc_592  -14
    RHS1      connected_order_arc_594  -14
    RHS1      connected_order_arc_596  -14
    RHS1      connected_order_arc_598  -14
    RHS1      connected_order_arc_601  -14
    RHS1      connected_order_arc_603  -14
    RHS1      connected_order_arc_605  -14
    RHS1      connected_order_arc_607  -14
    RHS1      connected_order_arc_609  -14
    RHS1      connected_order_arc_611  -14
    RHS1      connected_order_arc_613  -14
    RHS1      connected_order_arc_615  -14
    RHS1      connected_order_arc_617  -14
    RHS1      connected_order_arc_619  -14
    RHS1      connected_order_arc_621  -14
    RHS1      connected_order_arc_623  -14
    RHS1      connected_order_arc_625  -14
    RHS1      connected_order_arc_628  -14
    RHS1      connected_order_arc_630  -14
    RHS1      connected_order_arc_632  -14
    RHS1      connected_order_arc_634  -14
    RHS1      connected_order_arc_636  -14
    RHS1      connected_order_arc_638  -14
    RHS1      connected_order_arc_640  -14
    RHS1      connected_order_arc_642  -14
    RHS1      connected_order_arc_644  -14
    RHS1      connected_order_arc_646  -14
    RHS1      connected_order_arc_648  -14
    RHS1      connected_order_arc_650  -14
    RHS1      connected_order_arc_652  -14
    RHS1      connected_order_arc_655  -14
    RHS1      connected_order_arc_657  -14
    RHS1      connected_order_arc_659  -14
    RHS1      connected_order_arc_661  -14
    RHS1      connected_order_arc_663  -14
    RHS1      connected_order_arc_665  -14
    RHS1      connected_order_arc_667  -14
    RHS1      connected_order_arc_669  -14
    RHS1      connected_order_arc_671  -14
    RHS1      connected_order_arc_673  -14
    RHS1      connected_order_arc_675  -14
    RHS1      connected_order_arc_677  -14
    RHS1      connected_order_arc_679  -14
    RHS1      connected_order_arc_682  -14
    RHS1      connected_order_arc_684  -14
    RHS1      connected_order_arc_686  -14
    RHS1      connected_order_arc_688  -14
    RHS1      connected_order_arc_690  -14
    RHS1      connected_order_arc_692  -14
    RHS1      connected_order_arc_694  -14
    RHS1      connected_order_arc_696  -14
    RHS1      connected_order_arc_698  -14
    RHS1      connected_order_arc_700  -14
    RHS1      connected_order_arc_702  -14
    RHS1      connected_order_arc_704  -14
    RHS1      connected_order_arc_706  -14
    RHS1      connected_order_arc_709  -14
    RHS1      connected_order_arc_711  -14
    RHS1      connected_order_arc_713  -14
    RHS1      connected_order_arc_715  -14
    RHS1      connected_order_arc_717  -14
    RHS1      connected_order_arc_719  -14
    RHS1      connected_order_arc_721  -14
    RHS1      connected_order_arc_723  -14
    RHS1      connected_order_arc_725  -14
    RHS1      connected_order_arc_727  -14
    RHS1      connected_order_arc_729  -14
    RHS1      connected_order_arc_731  -14
    RHS1      connected_order_arc_733  -14
    RHS1      connected_order_arc_736  -14
    RHS1      connected_order_arc_738  -14
    RHS1      connected_order_arc_740  -14
    RHS1      connected_order_arc_742  -14
    RHS1      connected_order_arc_744  -14
    RHS1      connected_order_arc_746  -14
    RHS1      connected_order_arc_748  -14
    RHS1      connected_order_arc_750  -14
    RHS1      connected_order_arc_752  -14
    RHS1      connected_order_arc_754  -14
    RHS1      connected_order_arc_756  -14
    RHS1      connected_order_arc_758  -14
    RHS1      connected_order_arc_760  -14
    RHS1      connected_order_arc_763  -14
    RHS1      connected_order_arc_765  -14
    RHS1      connected_order_arc_767  -14
    RHS1      connected_order_arc_769  -14
    RHS1      connected_order_arc_771  -14
    RHS1      connected_order_arc_773  -14
    RHS1      connected_order_arc_775  -14
    RHS1      connected_order_arc_777  -14
    RHS1      connected_order_arc_779  -14
    RHS1      connected_order_arc_781  -14
    RHS1      connected_order_arc_783  -14
    RHS1      connected_order_arc_785  -14
    RHS1      connected_order_arc_787  -14
    RHS1      connected_order_arc_790  -14
    RHS1      connected_order_arc_792  -14
    RHS1      connected_order_arc_794  -14
    RHS1      connected_order_arc_796  -14
    RHS1      connected_order_arc_798  -14
    RHS1      connected_order_arc_800  -14
    RHS1      connected_order_arc_802  -14
    RHS1      connected_order_arc_804  -14
    RHS1      connected_order_arc_806  -14
    RHS1      connected_order_arc_808  -14
    RHS1      connected_order_arc_810  -14
    RHS1      connected_order_arc_812  -14
    RHS1      connected_order_arc_814  -14
    RHS1      depot_departure_or_bypass_815  1
    RHS1      depot_return_or_bypass_816  1
    RHS1      segment_load_conservation_821  4
    RHS1      segment_prefix_ub_823  16
    RHS1      segment_load_conservation_828  5
    RHS1      segment_prefix_ub_830  15
    RHS1      segment_load_conservation_835  4
    RHS1      segment_prefix_ub_837  16
    RHS1      segment_load_conservation_842  -8
    RHS1      segment_prefix_lb_843  8
    RHS1      segment_prefix_ub_844  20
    RHS1      segment_load_conservation_849  -4
    RHS1      segment_prefix_lb_850  4
    RHS1      segment_prefix_ub_851  20
    RHS1      segment_load_conservation_856  -3
    RHS1      segment_prefix_lb_857  3
    RHS1      segment_prefix_ub_858  10
    RHS1      fixed_segment_relative_order_907  1
    RHS1      fixed_segment_relative_order_908  1
    RHS1      fixed_segment_relative_order_909  1
    RHS1      fixed_segment_relative_order_910  1
    RHS1      fixed_segment_relative_order_911  1
    RHS1      original_T_including_depot_unload_912  3.3987045443215020e+03
    RHS1      connected_order_arc_928  -12
    RHS1      connected_order_arc_930  -12
    RHS1      connected_order_arc_932  -12
    RHS1      connected_order_arc_934  -12
    RHS1      connected_order_arc_936  -12
    RHS1      connected_order_arc_938  -12
    RHS1      connected_order_arc_940  -12
    RHS1      connected_order_arc_942  -12
    RHS1      connected_order_arc_944  -12
    RHS1      connected_order_arc_946  -12
    RHS1      connected_order_arc_948  -12
    RHS1      connected_order_arc_951  -12
    RHS1      connected_order_arc_953  -12
    RHS1      connected_order_arc_955  -12
    RHS1      connected_order_arc_957  -12
    RHS1      connected_order_arc_959  -12
    RHS1      connected_order_arc_961  -12
    RHS1      connected_order_arc_963  -12
    RHS1      connected_order_arc_965  -12
    RHS1      connected_order_arc_967  -12
    RHS1      connected_order_arc_969  -12
    RHS1      connected_order_arc_971  -12
    RHS1      connected_order_arc_974  -12
    RHS1      connected_order_arc_976  -12
    RHS1      connected_order_arc_978  -12
    RHS1      connected_order_arc_980  -12
    RHS1      connected_order_arc_982  -12
    RHS1      connected_order_arc_984  -12
    RHS1      connected_order_arc_986  -12
    RHS1      connected_order_arc_988  -12
    RHS1      connected_order_arc_990  -12
    RHS1      connected_order_arc_992  -12
    RHS1      connected_order_arc_994  -12
    RHS1      connected_order_arc_997  -12
    RHS1      connected_order_arc_999  -12
    RHS1      connected_order_arc_1001  -12
    RHS1      connected_order_arc_1003  -12
    RHS1      connected_order_arc_1005  -12
    RHS1      connected_order_arc_1007  -12
    RHS1      connected_order_arc_1009  -12
    RHS1      connected_order_arc_1011  -12
    RHS1      connected_order_arc_1013  -12
    RHS1      connected_order_arc_1015  -12
    RHS1      connected_order_arc_1017  -12
    RHS1      connected_order_arc_1020  -12
    RHS1      connected_order_arc_1022  -12
    RHS1      connected_order_arc_1024  -12
    RHS1      connected_order_arc_1026  -12
    RHS1      connected_order_arc_1028  -12
    RHS1      connected_order_arc_1030  -12
    RHS1      connected_order_arc_1032  -12
    RHS1      connected_order_arc_1034  -12
    RHS1      connected_order_arc_1036  -12
    RHS1      connected_order_arc_1038  -12
    RHS1      connected_order_arc_1040  -12
    RHS1      connected_order_arc_1043  -12
    RHS1      connected_order_arc_1045  -12
    RHS1      connected_order_arc_1047  -12
    RHS1      connected_order_arc_1049  -12
    RHS1      connected_order_arc_1051  -12
    RHS1      connected_order_arc_1053  -12
    RHS1      connected_order_arc_1055  -12
    RHS1      connected_order_arc_1057  -12
    RHS1      connected_order_arc_1059  -12
    RHS1      connected_order_arc_1061  -12
    RHS1      connected_order_arc_1063  -12
    RHS1      connected_order_arc_1066  -12
    RHS1      connected_order_arc_1068  -12
    RHS1      connected_order_arc_1070  -12
    RHS1      connected_order_arc_1072  -12
    RHS1      connected_order_arc_1074  -12
    RHS1      connected_order_arc_1076  -12
    RHS1      connected_order_arc_1078  -12
    RHS1      connected_order_arc_1080  -12
    RHS1      connected_order_arc_1082  -12
    RHS1      connected_order_arc_1084  -12
    RHS1      connected_order_arc_1086  -12
    RHS1      connected_order_arc_1089  -12
    RHS1      connected_order_arc_1091  -12
    RHS1      connected_order_arc_1093  -12
    RHS1      connected_order_arc_1095  -12
    RHS1      connected_order_arc_1097  -12
    RHS1      connected_order_arc_1099  -12
    RHS1      connected_order_arc_1101  -12
    RHS1      connected_order_arc_1103  -12
    RHS1      connected_order_arc_1105  -12
    RHS1      connected_order_arc_1107  -12
    RHS1      connected_order_arc_1109  -12
    RHS1      connected_order_arc_1112  -12
    RHS1      connected_order_arc_1114  -12
    RHS1      connected_order_arc_1116  -12
    RHS1      connected_order_arc_1118  -12
    RHS1      connected_order_arc_1120  -12
    RHS1      connected_order_arc_1122  -12
    RHS1      connected_order_arc_1124  -12
    RHS1      connected_order_arc_1126  -12
    RHS1      connected_order_arc_1128  -12
    RHS1      connected_order_arc_1130  -12
    RHS1      connected_order_arc_1132  -12
    RHS1      connected_order_arc_1135  -12
    RHS1      connected_order_arc_1137  -12
    RHS1      connected_order_arc_1139  -12
    RHS1      connected_order_arc_1141  -12
    RHS1      connected_order_arc_1143  -12
    RHS1      connected_order_arc_1145  -12
    RHS1      connected_order_arc_1147  -12
    RHS1      connected_order_arc_1149  -12
    RHS1      connected_order_arc_1151  -12
    RHS1      connected_order_arc_1153  -12
    RHS1      connected_order_arc_1155  -12
    RHS1      connected_order_arc_1158  -12
    RHS1      connected_order_arc_1160  -12
    RHS1      connected_order_arc_1162  -12
    RHS1      connected_order_arc_1164  -12
    RHS1      connected_order_arc_1166  -12
    RHS1      connected_order_arc_1168  -12
    RHS1      connected_order_arc_1170  -12
    RHS1      connected_order_arc_1172  -12
    RHS1      connected_order_arc_1174  -12
    RHS1      connected_order_arc_1176  -12
    RHS1      connected_order_arc_1178  -12
    RHS1      connected_order_arc_1181  -12
    RHS1      connected_order_arc_1183  -12
    RHS1      connected_order_arc_1185  -12
    RHS1      connected_order_arc_1187  -12
    RHS1      connected_order_arc_1189  -12
    RHS1      connected_order_arc_1191  -12
    RHS1      connected_order_arc_1193  -12
    RHS1      connected_order_arc_1195  -12
    RHS1      connected_order_arc_1197  -12
    RHS1      connected_order_arc_1199  -12
    RHS1      connected_order_arc_1201  -12
    RHS1      depot_departure_or_bypass_1202  1
    RHS1      depot_return_or_bypass_1203  1
    RHS1      segment_load_conservation_1208  6
    RHS1      segment_prefix_ub_1210  19
    RHS1      segment_load_conservation_1215  -6
    RHS1      segment_prefix_lb_1216  6
    RHS1      segment_prefix_ub_1217  25
    RHS1      segment_load_conservation_1222  5
    RHS1      segment_prefix_ub_1224  20
    RHS1      segment_load_conservation_1229  1
    RHS1      segment_prefix_ub_1231  24
    RHS1      fixed_segment_relative_order_1280  1
    RHS1      fixed_segment_relative_order_1281  1
    RHS1      fixed_segment_relative_order_1282  1
    RHS1      original_T_including_depot_unload_1283  3.9607220700993348e+03
    RHS1      connected_order_arc_1298  -11
    RHS1      connected_order_arc_1300  -11
    RHS1      connected_order_arc_1302  -11
    RHS1      connected_order_arc_1304  -11
    RHS1      connected_order_arc_1306  -11
    RHS1      connected_order_arc_1308  -11
    RHS1      connected_order_arc_1310  -11
    RHS1      connected_order_arc_1312  -11
    RHS1      connected_order_arc_1314  -11
    RHS1      connected_order_arc_1316  -11
    RHS1      connected_order_arc_1319  -11
    RHS1      connected_order_arc_1321  -11
    RHS1      connected_order_arc_1323  -11
    RHS1      connected_order_arc_1325  -11
    RHS1      connected_order_arc_1327  -11
    RHS1      connected_order_arc_1329  -11
    RHS1      connected_order_arc_1331  -11
    RHS1      connected_order_arc_1333  -11
    RHS1      connected_order_arc_1335  -11
    RHS1      connected_order_arc_1337  -11
    RHS1      connected_order_arc_1340  -11
    RHS1      connected_order_arc_1342  -11
    RHS1      connected_order_arc_1344  -11
    RHS1      connected_order_arc_1346  -11
    RHS1      connected_order_arc_1348  -11
    RHS1      connected_order_arc_1350  -11
    RHS1      connected_order_arc_1352  -11
    RHS1      connected_order_arc_1354  -11
    RHS1      connected_order_arc_1356  -11
    RHS1      connected_order_arc_1358  -11
    RHS1      connected_order_arc_1361  -11
    RHS1      connected_order_arc_1363  -11
    RHS1      connected_order_arc_1365  -11
    RHS1      connected_order_arc_1367  -11
    RHS1      connected_order_arc_1369  -11
    RHS1      connected_order_arc_1371  -11
    RHS1      connected_order_arc_1373  -11
    RHS1      connected_order_arc_1375  -11
    RHS1      connected_order_arc_1377  -11
    RHS1      connected_order_arc_1379  -11
    RHS1      connected_order_arc_1382  -11
    RHS1      connected_order_arc_1384  -11
    RHS1      connected_order_arc_1386  -11
    RHS1      connected_order_arc_1388  -11
    RHS1      connected_order_arc_1390  -11
    RHS1      connected_order_arc_1392  -11
    RHS1      connected_order_arc_1394  -11
    RHS1      connected_order_arc_1396  -11
    RHS1      connected_order_arc_1398  -11
    RHS1      connected_order_arc_1400  -11
    RHS1      connected_order_arc_1403  -11
    RHS1      connected_order_arc_1405  -11
    RHS1      connected_order_arc_1407  -11
    RHS1      connected_order_arc_1409  -11
    RHS1      connected_order_arc_1411  -11
    RHS1      connected_order_arc_1413  -11
    RHS1      connected_order_arc_1415  -11
    RHS1      connected_order_arc_1417  -11
    RHS1      connected_order_arc_1419  -11
    RHS1      connected_order_arc_1421  -11
    RHS1      connected_order_arc_1424  -11
    RHS1      connected_order_arc_1426  -11
    RHS1      connected_order_arc_1428  -11
    RHS1      connected_order_arc_1430  -11
    RHS1      connected_order_arc_1432  -11
    RHS1      connected_order_arc_1434  -11
    RHS1      connected_order_arc_1436  -11
    RHS1      connected_order_arc_1438  -11
    RHS1      connected_order_arc_1440  -11
    RHS1      connected_order_arc_1442  -11
    RHS1      connected_order_arc_1445  -11
    RHS1      connected_order_arc_1447  -11
    RHS1      connected_order_arc_1449  -11
    RHS1      connected_order_arc_1451  -11
    RHS1      connected_order_arc_1453  -11
    RHS1      connected_order_arc_1455  -11
    RHS1      connected_order_arc_1457  -11
    RHS1      connected_order_arc_1459  -11
    RHS1      connected_order_arc_1461  -11
    RHS1      connected_order_arc_1463  -11
    RHS1      connected_order_arc_1466  -11
    RHS1      connected_order_arc_1468  -11
    RHS1      connected_order_arc_1470  -11
    RHS1      connected_order_arc_1472  -11
    RHS1      connected_order_arc_1474  -11
    RHS1      connected_order_arc_1476  -11
    RHS1      connected_order_arc_1478  -11
    RHS1      connected_order_arc_1480  -11
    RHS1      connected_order_arc_1482  -11
    RHS1      connected_order_arc_1484  -11
    RHS1      connected_order_arc_1487  -11
    RHS1      connected_order_arc_1489  -11
    RHS1      connected_order_arc_1491  -11
    RHS1      connected_order_arc_1493  -11
    RHS1      connected_order_arc_1495  -11
    RHS1      connected_order_arc_1497  -11
    RHS1      connected_order_arc_1499  -11
    RHS1      connected_order_arc_1501  -11
    RHS1      connected_order_arc_1503  -11
    RHS1      connected_order_arc_1505  -11
    RHS1      connected_order_arc_1508  -11
    RHS1      connected_order_arc_1510  -11
    RHS1      connected_order_arc_1512  -11
    RHS1      connected_order_arc_1514  -11
    RHS1      connected_order_arc_1516  -11
    RHS1      connected_order_arc_1518  -11
    RHS1      connected_order_arc_1520  -11
    RHS1      connected_order_arc_1522  -11
    RHS1      connected_order_arc_1524  -11
    RHS1      connected_order_arc_1526  -11
    RHS1      depot_departure_or_bypass_1527  1
    RHS1      depot_return_or_bypass_1528  1
    RHS1      segment_load_conservation_1533  2
    RHS1      segment_prefix_ub_1535  28
    RHS1      segment_prefix_ub_1542  25
    RHS1      segment_load_conservation_1547  -2
    RHS1      segment_prefix_lb_1548  2
    RHS1      segment_prefix_ub_1549  26
    RHS1      fixed_segment_relative_order_1598  1
    RHS1      fixed_segment_relative_order_1599  1
    RHS1      original_T_including_depot_unload_1600  3.2584505903333484e+03
BOUNDS
 LO BND1      t         2.5024577710226110e-02
 UP BND1      t         4.2911877394678936e-02
 UP BND1      q         5.5283100117025263e-01
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.2911877394678936e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.2911877394678936e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.2911877394678936e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.2911877394678936e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.2911877394678936e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.2911877394678936e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.2911877394678936e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.2911877394678936e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.2911877394678936e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.2911877394678936e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.2911877394678936e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.2911877394678936e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.2911877394678936e-02
 UP BND1      rho_16    1
 BV BND1      x_11_0  
 UP BND1      w_11_0    4.2911877394678936e-02
 BV BND1      x_11_1  
 UP BND1      w_11_1    4.2911877394678936e-02
 BV BND1      x_11_2  
 UP BND1      w_11_2    4.2911877394678936e-02
 BV BND1      x_11_3  
 UP BND1      w_11_3    4.2911877394678936e-02
 BV BND1      x_11_4  
 UP BND1      w_11_4    4.2911877394678936e-02
 BV BND1      x_11_5  
 UP BND1      w_11_5    4.2911877394678936e-02
 BV BND1      x_11_6  
 UP BND1      w_11_6    4.2911877394678936e-02
 BV BND1      x_11_7  
 UP BND1      w_11_7    4.2911877394678936e-02
 BV BND1      x_11_8  
 UP BND1      w_11_8    4.2911877394678936e-02
 BV BND1      x_11_9  
 UP BND1      w_11_9    4.2911877394678936e-02
 BV BND1      x_11_10 
 UP BND1      w_11_10   4.2911877394678936e-02
 BV BND1      x_11_11 
 UP BND1      w_11_11   4.2911877394678936e-02
 BV BND1      x_11_12 
 UP BND1      w_11_12   4.2911877394678936e-02
 UP BND1      rho_11    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.2911877394678936e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.2911877394678936e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.2911877394678936e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.2911877394678936e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.2911877394678936e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.2911877394678936e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.2911877394678936e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.2911877394678936e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.2911877394678936e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.2911877394678936e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.2911877394678936e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.2911877394678936e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.2911877394678936e-02
 UP BND1      rho_31    1
 BV BND1      x_20_0  
 UP BND1      w_20_0    4.2911877394678936e-02
 BV BND1      x_20_1  
 UP BND1      w_20_1    4.2911877394678936e-02
 BV BND1      x_20_2  
 UP BND1      w_20_2    4.2911877394678936e-02
 BV BND1      x_20_3  
 UP BND1      w_20_3    4.2911877394678936e-02
 BV BND1      x_20_4  
 UP BND1      w_20_4    4.2911877394678936e-02
 BV BND1      x_20_5  
 UP BND1      w_20_5    4.2911877394678936e-02
 BV BND1      x_20_6  
 UP BND1      w_20_6    4.2911877394678936e-02
 BV BND1      x_20_7  
 UP BND1      w_20_7    4.2911877394678936e-02
 BV BND1      x_20_8  
 UP BND1      w_20_8    4.2911877394678936e-02
 BV BND1      x_20_9  
 UP BND1      w_20_9    4.2911877394678936e-02
 BV BND1      x_20_10 
 UP BND1      w_20_10   4.2911877394678936e-02
 BV BND1      x_20_11 
 UP BND1      w_20_11   4.2911877394678936e-02
 BV BND1      x_20_12 
 UP BND1      w_20_12   4.2911877394678936e-02
 UP BND1      rho_20    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.2911877394678936e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.2911877394678936e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.2911877394678936e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.2911877394678936e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.2911877394678936e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.2911877394678936e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.2911877394678936e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.2911877394678936e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.2911877394678936e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.2911877394678936e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.2911877394678936e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.2911877394678936e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.2911877394678936e-02
 UP BND1      rho_32    1
 BV BND1      x_21_0  
 UP BND1      w_21_0    4.2911877394678936e-02
 BV BND1      x_21_1  
 UP BND1      w_21_1    4.2911877394678936e-02
 BV BND1      x_21_2  
 UP BND1      w_21_2    4.2911877394678936e-02
 BV BND1      x_21_3  
 UP BND1      w_21_3    4.2911877394678936e-02
 BV BND1      x_21_4  
 UP BND1      w_21_4    4.2911877394678936e-02
 BV BND1      x_21_5  
 UP BND1      w_21_5    4.2911877394678936e-02
 BV BND1      x_21_6  
 UP BND1      w_21_6    4.2911877394678936e-02
 BV BND1      x_21_7  
 UP BND1      w_21_7    4.2911877394678936e-02
 BV BND1      x_21_8  
 UP BND1      w_21_8    4.2911877394678936e-02
 BV BND1      x_21_9  
 UP BND1      w_21_9    4.2911877394678936e-02
 BV BND1      x_21_10 
 UP BND1      w_21_10   4.2911877394678936e-02
 BV BND1      x_21_11 
 UP BND1      w_21_11   4.2911877394678936e-02
 BV BND1      x_21_12 
 UP BND1      w_21_12   4.2911877394678936e-02
 BV BND1      x_21_13 
 UP BND1      w_21_13   4.2911877394678936e-02
 BV BND1      x_21_14 
 UP BND1      w_21_14   4.2911877394678936e-02
 BV BND1      x_21_15 
 UP BND1      w_21_15   4.2911877394678936e-02
 UP BND1      rho_21    1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.2911877394678936e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.2911877394678936e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.2911877394678936e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.2911877394678936e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.2911877394678936e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.2911877394678936e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.2911877394678936e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.2911877394678936e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.2911877394678936e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.2911877394678936e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.2911877394678936e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.2911877394678936e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.2911877394678936e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.2911877394678936e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.2911877394678936e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.2911877394678936e-02
 UP BND1      rho_2     1
 BV BND1      x_7_0   
 UP BND1      w_7_0     4.2911877394678936e-02
 BV BND1      x_7_1   
 UP BND1      w_7_1     4.2911877394678936e-02
 BV BND1      x_7_2   
 UP BND1      w_7_2     4.2911877394678936e-02
 BV BND1      x_7_3   
 UP BND1      w_7_3     4.2911877394678936e-02
 BV BND1      x_7_4   
 UP BND1      w_7_4     4.2911877394678936e-02
 BV BND1      x_7_5   
 UP BND1      w_7_5     4.2911877394678936e-02
 BV BND1      x_7_6   
 UP BND1      w_7_6     4.2911877394678936e-02
 BV BND1      x_7_7   
 UP BND1      w_7_7     4.2911877394678936e-02
 BV BND1      x_7_8   
 UP BND1      w_7_8     4.2911877394678936e-02
 BV BND1      x_7_9   
 UP BND1      w_7_9     4.2911877394678936e-02
 BV BND1      x_7_10  
 UP BND1      w_7_10    4.2911877394678936e-02
 BV BND1      x_7_11  
 UP BND1      w_7_11    4.2911877394678936e-02
 BV BND1      x_7_12  
 UP BND1      w_7_12    4.2911877394678936e-02
 BV BND1      x_7_13  
 UP BND1      w_7_13    4.2911877394678936e-02
 BV BND1      x_7_14  
 UP BND1      w_7_14    4.2911877394678936e-02
 BV BND1      x_7_15  
 UP BND1      w_7_15    4.2911877394678936e-02
 BV BND1      x_7_16  
 UP BND1      w_7_16    4.2911877394678936e-02
 BV BND1      x_7_17  
 UP BND1      w_7_17    4.2911877394678936e-02
 UP BND1      rho_7     1
 UP BND1      a_16_11   1
 UP BND1      a_16_31   1
 UP BND1      a_16_20   1
 UP BND1      a_16_32   1
 UP BND1      a_16_21   1
 UP BND1      a_16_2    1
 UP BND1      a_16_7    1
 UP BND1      a_11_31   1
 UP BND1      a_11_20   1
 UP BND1      a_11_32   1
 UP BND1      a_11_21   1
 UP BND1      a_11_2    1
 UP BND1      a_11_7    1
 UP BND1      a_31_20   1
 UP BND1      a_31_32   1
 UP BND1      a_31_21   1
 UP BND1      a_31_2    1
 UP BND1      a_31_7    1
 UP BND1      a_20_32   1
 UP BND1      a_20_21   1
 UP BND1      a_20_2    1
 UP BND1      a_20_7    1
 UP BND1      a_32_21   1
 UP BND1      a_32_2    1
 UP BND1      a_32_7    1
 UP BND1      a_21_2    1
 UP BND1      a_21_7    1
 UP BND1      a_2_7     1
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_2_16_0
 BV BND1      service_2_16_2
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_0_11_0
 BV BND1      service_0_11_1
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_1_11_0
 BV BND1      service_1_11_1
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_2_11_0
 BV BND1      service_2_11_1
 BV BND1      service_2_11_2
 BV BND1      service_2_11_3
 BV BND1      service_2_11_4
 BV BND1      service_2_11_5
 BV BND1      service_2_11_6
 BV BND1      service_2_11_8
 BV BND1      service_2_11_9
 BV BND1      service_2_11_10
 BV BND1      service_2_11_11
 BV BND1      service_2_11_12
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_20_0
 BV BND1      service_0_20_1
 BV BND1      service_0_20_2
 BV BND1      service_0_20_3
 BV BND1      service_0_20_4
 BV BND1      service_0_20_5
 BV BND1      service_0_20_6
 BV BND1      service_0_20_7
 BV BND1      service_0_20_8
 BV BND1      service_0_20_10
 BV BND1      service_0_20_11
 BV BND1      service_0_20_12
 BV BND1      service_1_20_0
 BV BND1      service_1_20_1
 BV BND1      service_1_20_2
 BV BND1      service_1_20_3
 BV BND1      service_1_20_4
 BV BND1      service_1_20_5
 BV BND1      service_1_20_6
 BV BND1      service_1_20_7
 BV BND1      service_1_20_8
 BV BND1      service_1_20_10
 BV BND1      service_1_20_11
 BV BND1      service_1_20_12
 BV BND1      service_2_20_0
 BV BND1      service_2_20_1
 BV BND1      service_2_20_2
 BV BND1      service_2_20_3
 BV BND1      service_2_20_4
 BV BND1      service_2_20_5
 BV BND1      service_2_20_6
 BV BND1      service_2_20_7
 BV BND1      service_2_20_8
 BV BND1      service_2_20_10
 BV BND1      service_2_20_11
 BV BND1      service_2_20_12
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_21_0
 BV BND1      service_0_21_2
 BV BND1      service_0_21_3
 BV BND1      service_0_21_4
 BV BND1      service_0_21_5
 BV BND1      service_0_21_6
 BV BND1      service_0_21_7
 BV BND1      service_0_21_8
 BV BND1      service_0_21_9
 BV BND1      service_0_21_10
 BV BND1      service_0_21_11
 BV BND1      service_0_21_12
 BV BND1      service_0_21_13
 BV BND1      service_0_21_14
 BV BND1      service_0_21_15
 BV BND1      service_1_21_0
 BV BND1      service_1_21_2
 BV BND1      service_1_21_3
 BV BND1      service_1_21_4
 BV BND1      service_1_21_5
 BV BND1      service_1_21_6
 BV BND1      service_1_21_7
 BV BND1      service_1_21_8
 BV BND1      service_1_21_9
 BV BND1      service_1_21_10
 BV BND1      service_1_21_11
 BV BND1      service_1_21_12
 BV BND1      service_1_21_13
 BV BND1      service_1_21_14
 BV BND1      service_1_21_15
 BV BND1      service_2_21_0
 BV BND1      service_2_21_2
 BV BND1      service_2_21_3
 BV BND1      service_2_21_4
 BV BND1      service_2_21_5
 BV BND1      service_2_21_6
 BV BND1      service_2_21_7
 BV BND1      service_2_21_8
 BV BND1      service_2_21_9
 BV BND1      service_2_21_10
 BV BND1      service_2_21_11
 BV BND1      service_2_21_12
 BV BND1      service_2_21_13
 BV BND1      service_2_21_14
 BV BND1      service_2_21_15
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_7_0
 BV BND1      service_0_7_1
 BV BND1      service_0_7_2
 BV BND1      service_0_7_3
 BV BND1      service_0_7_4
 BV BND1      service_0_7_5
 BV BND1      service_0_7_6
 BV BND1      service_0_7_7
 BV BND1      service_0_7_8
 BV BND1      service_0_7_9
 BV BND1      service_0_7_10
 BV BND1      service_0_7_11
 BV BND1      service_0_7_13
 BV BND1      service_0_7_14
 BV BND1      service_0_7_15
 BV BND1      service_0_7_16
 BV BND1      service_0_7_17
 BV BND1      service_1_7_0
 BV BND1      service_1_7_1
 BV BND1      service_1_7_2
 BV BND1      service_1_7_3
 BV BND1      service_1_7_4
 BV BND1      service_1_7_5
 BV BND1      service_1_7_6
 BV BND1      service_1_7_7
 BV BND1      service_1_7_8
 BV BND1      service_1_7_9
 BV BND1      service_1_7_10
 BV BND1      service_1_7_11
 BV BND1      service_1_7_13
 BV BND1      service_1_7_14
 BV BND1      service_1_7_15
 BV BND1      service_1_7_16
 BV BND1      service_1_7_17
 BV BND1      service_2_7_0
 BV BND1      service_2_7_1
 BV BND1      service_2_7_2
 BV BND1      service_2_7_3
 BV BND1      service_2_7_4
 BV BND1      service_2_7_5
 BV BND1      service_2_7_6
 BV BND1      service_2_7_7
 BV BND1      service_2_7_8
 BV BND1      service_2_7_9
 BV BND1      service_2_7_10
 BV BND1      service_2_7_11
 BV BND1      service_2_7_13
 BV BND1      service_2_7_14
 BV BND1      service_2_7_15
 BV BND1      service_2_7_16
 BV BND1      service_2_7_17
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  14
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  14
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  14
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  14
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  14
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  14
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  14
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  20
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  20
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  20
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  20
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  20
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  20
 BV BND1      arc_0_6_14
 UP BND1      load_0_6_14  20
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  20
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  20
 BV BND1      arc_0_6_17
 UP BND1      load_0_6_17  20
 BV BND1      arc_0_6_18
 UP BND1      load_0_6_18  20
 BV BND1      arc_0_6_19
 UP BND1      load_0_6_19  20
 BV BND1      arc_0_6_20
 UP BND1      load_0_6_20  20
 BV BND1      arc_0_6_21
 UP BND1      load_0_6_21  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_6
 UP BND1      load_0_14_6  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_14_21
 UP BND1      load_0_14_21  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_6
 UP BND1      load_0_17_6  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_6
 UP BND1      load_0_18_6  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_6
 UP BND1      load_0_19_6  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_6
 UP BND1      load_0_20_6  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_6
 UP BND1      load_0_21_6  20
 BV BND1      arc_0_21_14
 UP BND1      load_0_21_14  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  25
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  25
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  25
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  25
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  25
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  25
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  25
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  25
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  25
 BV BND1      arc_1_10_19
 UP BND1      load_1_10_19  25
 BV BND1      arc_1_10_20
 UP BND1      load_1_10_20  25
 BV BND1      arc_1_10_21
 UP BND1      load_1_10_21  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_14_21
 UP BND1      load_1_14_21  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_10
 UP BND1      load_1_19_10  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_10
 UP BND1      load_1_20_10  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_10
 UP BND1      load_1_21_10  25
 BV BND1      arc_1_21_14
 UP BND1      load_1_21_14  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
ENDATA
