* Signature: 0x8bded3e419baa393
NAME obj
ROWS
 N  OBJ
 L  c1      
 G  c2      
 L  c3      
 L  c4      
 L  c5      
 L  c6      
 L  c7      
 L  c8      
 L  c9      
 G  c10     
 L  c11     
 L  c12     
 G  c13     
 G  c14     
 L  c15     
 L  c16     
 L  c17     
 E  c18     
 L  c19     
 E  c20     
 E  c21     
 E  c22     
 E  c23     
 L  c24     
 L  c25     
 L  c26     
 L  c27     
 L  c28     
 L  c29     
 E  c30     
 E  c31     
 E  c32     
 L  c33     
 L  c34     
 L  c35     
 G  c36     
 L  c37     
 L  c38     
 G  c39     
 L  c40     
 G  c41     
 L  c42     
 L  c43     
 L  c44     
 L  c45     
 L  c46     
 L  c47     
 L  c48     
 L  c49     
 G  c50     
 L  c51     
 L  c52     
 L  c53     
 L  c54     
 L  c55     
 L  c56     
 G  c57     
 L  c58     
 L  c59     
 G  c60     
 L  c61     
 G  c62     
 L  c63     
 G  c64     
 L  c65     
 G  c66     
 G  c67     
 L  c68     
 L  c69     
 E  c70     
 E  c71     
 G  c72     
 G  c73     
 E  c74     
 E  c75     
 G  c76     
 G  c77     
 L  c78     
 L  c79     
 L  c80     
 L  c81     
 L  c82     
 G  c83     
 G  c84     
 G  c85     
 L  c86     
 G  c87     
 L  c88     
 E  c89     
 E  c90     
 E  c91     
 E  c92     
 E  c93     
 E  c94     
 G  c95     
 L  c96     
 G  c97     
 L  c98     
 E  c99     
 E  c100    
 E  c101    
 E  c102    
 E  c103    
 E  c104    
 G  c105    
COLUMNS
    G         OBJ       1
    G         c8        1
    G         c93       -1
    G         c103      -1
    e_1       OBJ       0.1
    e_1       c8        0.1
    e_1       c9        0.5
    e_1       c10       1
    e_1       c11       1
    e_1       c13       -1
    e_1       c14       -2.5
    e_1       c15       -2.5
    e_1       c16       -1
    e_1       c72       1
    e_1       c73       1
    e_2       OBJ       0.1
    e_2       c8        0.1
    e_2       c9        0.5
    e_2       c10       1
    e_2       c12       1
    e_2       c13       -1
    e_2       c14       -2.5
    e_2       c15       -2.5
    e_2       c16       -1
    e_2       c76       1
    e_2       c77       1
    h_1_2     c1        1
    h_1_2     c2        1
    h_1_2     c3        1
    h_1_2     c9        1
    h_1_2     c17       1
    h_1_2     c83       1
    h_1_2     c84       1
    h_1_2     c105      -1
    r_1       c1        -1
    r_1       c3        -1
    r_1       c4        1
    r_1       c5        -1
    r_1       c7        -2
    r_1       c13       -0.5
    r_1       c14       -2
    r_1       c15       -0.5
    r_1       c16       -2
    r_1       c17       -1.4000000000000001e+00
    r_1       c71       1
    r_1       c72       -1
    r_1       c73       1
    r_1       c83       -1
    r_1       c84       1
    r_2       c1        -1
    r_2       c3        -1
    r_2       c4        -1
    r_2       c5        1
    r_2       c6        -2
    r_2       c13       -0.5
    r_2       c14       -2
    r_2       c15       -0.5
    r_2       c16       -2
    r_2       c17       -1.4000000000000001e+00
    r_2       c75       1
    r_2       c76       -1
    r_2       c77       1
    r_2       c83       1
    r_2       c84       -1
    W_SP      c13       1
    W_SP      c14       1
    W_SP      c15       1
    W_SP      c16       1
    W_SP      c17       0.2
    MARKER    'MARKER'                 'INTORG'
    x_0_0_1   c18       1
    x_0_0_1   c19       1
    x_0_0_1   c20       1
    x_0_0_1   c24       -2
    x_0_0_1   c59       1
    x_0_0_1   c60       -1
    x_0_0_2   c18       1
    x_0_0_2   c19       1
    x_0_0_2   c22       1
    x_0_0_2   c25       -2
    x_0_0_2   c61       1
    x_0_0_2   c62       -1
    x_0_1_0   c18       -1
    x_0_1_0   c21       1
    x_0_1_0   c26       -2
    x_0_2_0   c18       -1
    x_0_2_0   c23       1
    x_0_2_0   c28       -2
    x_0_2_1   c20       1
    x_0_2_1   c23       1
    x_0_2_1   c29       -2
    x_0_2_1   c44       2
    x_0_2_1   c65       1
    x_0_2_1   c66       -1
    z_0_1     c20       -1
    z_0_1     c21       -1
    z_0_1     c30       -1
    z_0_1     c32       -1
    z_0_1     c33       1
    z_0_1     c39       -1
    z_0_1     c40       -2
    z_0_1     c45       -1
    z_0_1     c47       -1
    z_0_1     c50       -1
    z_0_1     c51       -1
    z_0_1     c69       105
    z_0_1     c79       -2
    z_0_1     c90       1
    x_0_1_2   c21       1
    x_0_1_2   c22       1
    x_0_1_2   c27       -2
    x_0_1_2   c43       2
    x_0_1_2   c63       1
    x_0_1_2   c64       -1
    z_0_2     c22       -1
    z_0_2     c23       -1
    z_0_2     c31       -1
    z_0_2     c32       -1
    z_0_2     c34       1
    z_0_2     c41       -1
    z_0_2     c42       -2
    z_0_2     c53       -1
    z_0_2     c54       -1
    z_0_2     c56       -1
    z_0_2     c57       -1
    z_0_2     c58       -1
    z_0_2     c69       105
    z_0_2     c80       -2
    z_0_2     c100      1
    MARKER    'MARKER'                 'INTEND'
    conn_0_0_1  c24       1
    conn_0_0_1  c30       1
    conn_0_0_1  c32       1
    conn_0_0_2  c25       1
    conn_0_0_2  c31       1
    conn_0_0_2  c32       1
    conn_0_1_0  c26       1
    conn_0_1_0  c30       -1
    conn_0_1_0  c32       -1
    conn_0_1_2  c27       1
    conn_0_1_2  c30       -1
    conn_0_1_2  c31       1
    conn_0_2_0  c28       1
    conn_0_2_0  c31       -1
    conn_0_2_0  c32       -1
    conn_0_2_1  c29       1
    conn_0_2_1  c30       1
    conn_0_2_1  c31       -1
    MARKER    'MARKER'                 'INTORG'
    Y_1       c35       1
    Y_1       c36       1
    Y_1       c70       1
    Y_1       c71       -1
    Y_1       c78       1
    Y_1       c79       -1
    Y_1       c92       1
    Y_2       c35       1
    Y_2       c36       1
    Y_2       c74       1
    Y_2       c75       -0.5
    Y_2       c80       1
    Y_2       c81       -1
    Y_2       c102      1
    MARKER    'MARKER'                 'INTEND'
    d_0_1     c37       1
    d_0_1     c46       1
    d_0_1     c49       1
    d_0_1     c50       1
    d_0_1     c59       1
    d_0_1     c60       1
    d_0_1     c65       1
    d_0_1     c66       1
    d_0_1     c67       -1
    d_0_1     c70       -1
    d_0_1     c89       1
    p_0_2     c37       -1
    p_0_2     c52       1
    p_0_2     c55       1
    p_0_2     c57       1
    p_0_2     c61       -1
    p_0_2     c62       -1
    p_0_2     c63       -1
    p_0_2     c64       -1
    p_0_2     c67       1
    p_0_2     c68       5
    p_0_2     c69       5
    p_0_2     c74       1
    p_0_2     c82       5
    p_0_2     c99       1
    d_0_2     c38       1
    d_0_2     c53       1
    d_0_2     c56       1
    d_0_2     c57       1
    d_0_2     c61       1
    d_0_2     c62       1
    d_0_2     c63       1
    d_0_2     c64       1
    d_0_2     c67       -1
    d_0_2     c74       -1
    d_0_2     c99       1
    p_0_1     c38       -1
    p_0_1     c45       1
    p_0_1     c48       1
    p_0_1     c50       1
    p_0_1     c59       -1
    p_0_1     c60       -1
    p_0_1     c65       -1
    p_0_1     c66       -1
    p_0_1     c67       1
    p_0_1     c68       5
    p_0_1     c69       5
    p_0_1     c70       1
    p_0_1     c82       5
    p_0_1     c89       1
    ord_0_1   c39       1
    ord_0_1   c40       1
    ord_0_1   c43       1
    ord_0_1   c44       -1
    ord_0_2   c41       1
    ord_0_2   c42       1
    ord_0_2   c43       -1
    ord_0_2   c44       1
    MARKER    'MARKER'                 'INTORG'
    mode_0_1  c47       1
    mode_0_1  c48       -1
    load_0_1  c51       1
    load_0_1  c59       1
    load_0_1  c60       1
    load_0_1  c63       -1
    load_0_1  c64       -1
    load_0_1  c65       1
    load_0_1  c66       1
    mode_0_2  c54       1
    mode_0_2  c56       1
    load_0_2  c58       1
    load_0_2  c61       1
    load_0_2  c62       1
    load_0_2  c63       1
    load_0_2  c64       1
    load_0_2  c65       -1
    load_0_2  c66       -1
    MARKER    'MARKER'                 'INTEND'
    state_g_1_1  c85       1
    state_g_1_1  c86       1
    state_g_1_1  c93       1
    state_g_1_1  c94       -1
    MARKER    'MARKER'                 'INTORG'
    state_1_1  c86       -5.0000000000000011e-01
    state_1_1  c89       -1
    state_1_1  c91       1
    state_1_1  c92       -1
    MARKER    'MARKER'                 'INTEND'
    state_g_1_2  c87       1
    state_g_1_2  c88       1
    state_g_1_2  c93       1
    state_g_1_2  c94       -2
    MARKER    'MARKER'                 'INTORG'
    state_1_2  c88       -5.0000000000000011e-01
    state_1_2  c90       1
    state_1_2  c91       1
    state_1_2  c92       -2
    MARKER    'MARKER'                 'INTEND'
    zprod_1   c94       1
    zprod_1   c105      2
    state_g_2_0  c95       1
    state_g_2_0  c96       1
    state_g_2_0  c103      1
    MARKER    'MARKER'                 'INTORG'
    state_2_0  c96       -5.0000000000000011e-01
    state_2_0  c100      1
    state_2_0  c101      1
    MARKER    'MARKER'                 'INTEND'
    state_g_2_1  c97       1
    state_g_2_1  c98       1
    state_g_2_1  c103      1
    state_g_2_1  c104      -1
    MARKER    'MARKER'                 'INTORG'
    state_2_1  c98       -5.0000000000000011e-01
    state_2_1  c99       -1
    state_2_1  c101      1
    state_2_1  c102      -1
    MARKER    'MARKER'                 'INTEND'
    zprod_2   c104      1
    zprod_2   c105      1
    r_max     OBJ       0
    r_min     OBJ       0
RHS
    RHS1      c4        2.5000000000000004e+00
    RHS1      c5        2.5000000000000004e+00
    RHS1      c8        7.0000000000000007e-01
    RHS1      c9        3.5000000000000004e+00
    RHS1      c10       0.5
    RHS1      c11       7
    RHS1      c12       7
    RHS1      c13       -0.5
    RHS1      c14       -5
    RHS1      c15       -1.25
    RHS1      c16       -2
    RHS1      c19       1
    RHS1      c33       1
    RHS1      c34       1
    RHS1      c35       2
    RHS1      c36       1
    RHS1      c43       1
    RHS1      c44       1
    RHS1      c59       1
    RHS1      c60       -1
    RHS1      c61       1
    RHS1      c62       -1
    RHS1      c63       1
    RHS1      c64       -1
    RHS1      c65       1
    RHS1      c66       -1
    RHS1      c68       100
    RHS1      c69       310
    RHS1      c70       2
    RHS1      c72       -1
    RHS1      c73       1
    RHS1      c76       -1
    RHS1      c77       1
    RHS1      c78       2
    RHS1      c79       -2
    RHS1      c82       100
    RHS1      c90       1
    RHS1      c91       1
    RHS1      c100      1
    RHS1      c101      1
BOUNDS
 UP BND1      G         5.0000000000000011e-01
 UP BND1      e_1       1
 UP BND1      e_2       1
 UP BND1      h_1_2     3
 UP BND1      r_1       2
 UP BND1      r_2       1
 LO BND1      W_SP      0.5
 UP BND1      W_SP      5
 BV BND1      x_0_0_1 
 BV BND1      x_0_0_2 
 BV BND1      x_0_1_0 
 BV BND1      x_0_2_0 
 BV BND1      x_0_2_1 
 BV BND1      z_0_1   
 BV BND1      x_0_1_2 
 BV BND1      z_0_2   
 UP BND1      conn_0_0_1  2
 UP BND1      conn_0_0_2  2
 UP BND1      conn_0_1_0  2
 UP BND1      conn_0_1_2  2
 UP BND1      conn_0_2_0  2
 UP BND1      conn_0_2_1  2
 LO BND1      Y_1       1
 UP BND1      Y_1       2
 UP BND1      Y_2       1
 FX BND1      d_0_1     0
 FX BND1      p_0_2     0
 UP BND1      d_0_2     1
 UP BND1      p_0_1     1
 UP BND1      ord_0_1   2
 UP BND1      ord_0_2   2
 BV BND1      mode_0_1
 UP BND1      load_0_1  1
 BV BND1      mode_0_2
 UP BND1      load_0_2  1
 UP BND1      state_g_1_1  5.0000000000000011e-01
 BV BND1      state_1_1
 UP BND1      state_g_1_2  5.0000000000000011e-01
 BV BND1      state_1_2
 UP BND1      zprod_1   2
 UP BND1      state_g_2_0  5.0000000000000011e-01
 BV BND1      state_2_0
 UP BND1      state_g_2_1  5.0000000000000011e-01
 BV BND1      state_2_1
 UP BND1      zprod_2   2
 UP BND1      r_max     2
 UP BND1      r_min     2
ENDATA
