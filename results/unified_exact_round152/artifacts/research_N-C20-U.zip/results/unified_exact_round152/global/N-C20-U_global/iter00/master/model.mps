* Signature: 0xdcd3d96415b3b6a0
NAME 
OBJSENSE MAX
ROWS
 N  OBJ
 L  column_0
 L  column_1
 L  column_2
 L  column_3
 L  column_4
 L  column_5
 L  column_6
 L  column_7
 L  column_8
 L  column_9
 L  column_10
 L  column_11
 L  column_12
 L  column_13
 L  column_14
 L  column_15
 L  column_16
 L  column_17
 L  column_18
 L  column_19
 L  column_20
 L  column_21
 L  column_22
 L  column_23
 L  column_24
 L  column_25
 L  column_26
 L  column_27
 L  column_28
 L  column_29
 L  column_30
 L  column_31
 L  column_32
 L  column_33
 L  column_34
COLUMNS
    psi[1,0]  OBJ       0
    psi[1,1]  OBJ       0
    psi[1,2]  OBJ       0
    psi[1,3]  OBJ       0
    psi[1,4]  OBJ       0
    psi[1,5]  OBJ       0
    psi[1,6]  OBJ       0
    psi[1,7]  OBJ       0
    psi[1,8]  OBJ       0
    psi[1,9]  OBJ       0
    psi[1,10]  OBJ       0
    psi[1,11]  OBJ       1
    psi[1,11]  column_0  1
    psi[1,11]  column_1  1
    psi[1,11]  column_2  1
    psi[1,11]  column_3  1
    psi[1,11]  column_4  1
    psi[1,11]  column_5  1
    psi[1,11]  column_6  1
    psi[1,11]  column_7  1
    psi[1,11]  column_8  1
    psi[1,11]  column_9  1
    psi[1,11]  column_10  1
    psi[1,11]  column_11  1
    psi[1,11]  column_12  1
    psi[1,11]  column_13  1
    psi[1,11]  column_14  1
    psi[1,11]  column_15  1
    psi[1,11]  column_16  1
    psi[1,11]  column_17  1
    psi[1,11]  column_18  1
    psi[1,11]  column_19  1
    psi[1,11]  column_20  1
    psi[1,11]  column_21  1
    psi[1,11]  column_22  1
    psi[1,11]  column_23  1
    psi[1,11]  column_24  1
    psi[1,11]  column_25  1
    psi[1,11]  column_26  1
    psi[1,11]  column_27  1
    psi[1,11]  column_28  1
    psi[1,11]  column_29  1
    psi[1,11]  column_30  1
    psi[1,11]  column_31  1
    psi[1,11]  column_32  1
    psi[1,11]  column_33  1
    psi[1,11]  column_34  1
    psi[1,12]  OBJ       0
    psi[1,13]  OBJ       0
    psi[1,14]  OBJ       0
    psi[1,15]  OBJ       0
    psi[1,16]  OBJ       0
    psi[1,17]  OBJ       0
    psi[1,18]  OBJ       0
    psi[1,19]  OBJ       0
    psi[1,20]  OBJ       0
    psi[1,21]  OBJ       0
    psi[1,22]  OBJ       0
    psi[1,23]  OBJ       0
    psi[1,24]  OBJ       0
    psi[2,0]  OBJ       0
    psi[2,1]  OBJ       0
    psi[2,2]  OBJ       0
    psi[2,3]  OBJ       0
    psi[2,4]  OBJ       0
    psi[2,5]  OBJ       0
    psi[2,6]  OBJ       0
    psi[2,7]  OBJ       0
    psi[2,8]  OBJ       0
    psi[2,9]  OBJ       0
    psi[2,10]  OBJ       0
    psi[2,11]  OBJ       0
    psi[2,12]  OBJ       0
    psi[2,13]  OBJ       0
    psi[2,14]  OBJ       1
    psi[2,14]  column_0  1
    psi[2,14]  column_1  1
    psi[2,14]  column_2  1
    psi[2,14]  column_3  1
    psi[2,14]  column_4  1
    psi[2,14]  column_5  1
    psi[2,14]  column_6  1
    psi[2,14]  column_7  1
    psi[2,14]  column_8  1
    psi[2,14]  column_9  1
    psi[2,14]  column_10  1
    psi[2,14]  column_11  1
    psi[2,14]  column_12  1
    psi[2,14]  column_13  1
    psi[2,14]  column_14  1
    psi[2,14]  column_15  1
    psi[2,14]  column_16  1
    psi[2,14]  column_17  1
    psi[2,14]  column_18  1
    psi[2,14]  column_19  1
    psi[2,14]  column_20  1
    psi[2,14]  column_21  1
    psi[2,14]  column_22  1
    psi[2,14]  column_23  1
    psi[2,14]  column_24  1
    psi[2,14]  column_25  1
    psi[2,14]  column_26  1
    psi[2,14]  column_27  1
    psi[2,14]  column_28  1
    psi[2,14]  column_29  1
    psi[2,14]  column_30  1
    psi[2,14]  column_31  1
    psi[2,14]  column_32  1
    psi[2,14]  column_33  1
    psi[2,14]  column_34  1
    psi[2,15]  OBJ       0
    psi[2,16]  OBJ       0
    psi[2,17]  OBJ       0
    psi[2,18]  OBJ       0
    psi[2,19]  OBJ       0
    psi[2,20]  OBJ       0
    psi[2,21]  OBJ       0
    psi[2,22]  OBJ       0
    psi[2,23]  OBJ       0
    psi[2,24]  OBJ       0
    psi[2,25]  OBJ       0
    psi[3,0]  OBJ       0
    psi[3,1]  OBJ       0
    psi[3,2]  OBJ       0
    psi[3,3]  OBJ       0
    psi[3,4]  OBJ       0
    psi[3,5]  OBJ       0
    psi[3,6]  OBJ       0
    psi[3,7]  OBJ       0
    psi[3,8]  OBJ       0
    psi[3,9]  OBJ       0
    psi[3,10]  OBJ       0
    psi[3,11]  OBJ       0
    psi[3,12]  OBJ       0
    psi[3,13]  OBJ       0
    psi[3,14]  OBJ       0
    psi[3,15]  OBJ       1
    psi[3,15]  column_0  1
    psi[3,15]  column_1  1
    psi[3,15]  column_2  1
    psi[3,15]  column_3  1
    psi[3,15]  column_4  1
    psi[3,15]  column_5  1
    psi[3,15]  column_6  1
    psi[3,15]  column_7  1
    psi[3,15]  column_8  1
    psi[3,15]  column_9  1
    psi[3,15]  column_10  1
    psi[3,15]  column_11  1
    psi[3,15]  column_12  1
    psi[3,15]  column_13  1
    psi[3,15]  column_14  1
    psi[3,15]  column_15  1
    psi[3,15]  column_16  1
    psi[3,15]  column_17  1
    psi[3,15]  column_18  1
    psi[3,15]  column_19  1
    psi[3,15]  column_20  1
    psi[3,15]  column_21  1
    psi[3,15]  column_22  1
    psi[3,15]  column_23  1
    psi[3,15]  column_24  1
    psi[3,15]  column_25  1
    psi[3,15]  column_26  1
    psi[3,15]  column_27  1
    psi[3,15]  column_28  1
    psi[3,15]  column_29  1
    psi[3,15]  column_30  1
    psi[3,15]  column_31  1
    psi[3,16]  OBJ       0
    psi[3,17]  OBJ       0
    psi[3,18]  OBJ       0
    psi[3,19]  OBJ       0
    psi[3,20]  OBJ       0
    psi[3,21]  OBJ       0
    psi[3,22]  OBJ       0
    psi[3,23]  OBJ       0
    psi[3,24]  column_32  1
    psi[3,24]  column_33  1
    psi[3,24]  column_34  1
    psi[3,25]  OBJ       0
    psi[3,26]  OBJ       0
    psi[3,27]  OBJ       0
    psi[4,0]  OBJ       0
    psi[4,1]  OBJ       0
    psi[4,2]  OBJ       0
    psi[4,3]  OBJ       0
    psi[4,4]  OBJ       0
    psi[4,5]  OBJ       0
    psi[4,6]  OBJ       0
    psi[4,7]  OBJ       0
    psi[4,8]  OBJ       0
    psi[4,9]  OBJ       0
    psi[4,10]  OBJ       0
    psi[4,11]  OBJ       1
    psi[4,11]  column_0  1
    psi[4,11]  column_1  1
    psi[4,11]  column_2  1
    psi[4,11]  column_3  1
    psi[4,11]  column_4  1
    psi[4,11]  column_5  1
    psi[4,11]  column_6  1
    psi[4,11]  column_7  1
    psi[4,11]  column_8  1
    psi[4,11]  column_9  1
    psi[4,11]  column_10  1
    psi[4,11]  column_11  1
    psi[4,11]  column_12  1
    psi[4,11]  column_13  1
    psi[4,11]  column_14  1
    psi[4,11]  column_15  1
    psi[4,11]  column_16  1
    psi[4,11]  column_17  1
    psi[4,11]  column_18  1
    psi[4,11]  column_19  1
    psi[4,11]  column_20  1
    psi[4,11]  column_21  1
    psi[4,11]  column_22  1
    psi[4,11]  column_23  1
    psi[4,11]  column_24  1
    psi[4,11]  column_25  1
    psi[4,11]  column_26  1
    psi[4,11]  column_27  1
    psi[4,11]  column_28  1
    psi[4,11]  column_29  1
    psi[4,11]  column_30  1
    psi[4,11]  column_31  1
    psi[4,11]  column_32  1
    psi[4,11]  column_33  1
    psi[4,11]  column_34  1
    psi[4,12]  OBJ       0
    psi[4,13]  OBJ       0
    psi[4,14]  OBJ       0
    psi[4,15]  OBJ       0
    psi[4,16]  OBJ       0
    psi[4,17]  OBJ       0
    psi[4,18]  OBJ       0
    psi[4,19]  OBJ       0
    psi[4,20]  OBJ       0
    psi[4,21]  OBJ       0
    psi[4,22]  OBJ       0
    psi[4,23]  OBJ       0
    psi[4,24]  OBJ       0
    psi[5,0]  OBJ       0
    psi[5,1]  OBJ       0
    psi[5,2]  OBJ       0
    psi[5,3]  OBJ       0
    psi[5,4]  OBJ       0
    psi[5,5]  OBJ       0
    psi[5,6]  OBJ       0
    psi[5,7]  OBJ       0
    psi[5,8]  OBJ       0
    psi[5,9]  OBJ       0
    psi[5,10]  OBJ       0
    psi[5,11]  OBJ       6.1900427668443081e-01
    psi[5,11]  column_0  1
    psi[5,11]  column_1  1
    psi[5,11]  column_2  1
    psi[5,11]  column_3  1
    psi[5,11]  column_4  1
    psi[5,11]  column_5  1
    psi[5,11]  column_6  1
    psi[5,11]  column_7  1
    psi[5,11]  column_8  1
    psi[5,11]  column_9  1
    psi[5,11]  column_10  1
    psi[5,11]  column_11  1
    psi[5,11]  column_12  1
    psi[5,11]  column_13  1
    psi[5,11]  column_14  1
    psi[5,11]  column_15  1
    psi[5,11]  column_16  1
    psi[5,11]  column_17  1
    psi[5,11]  column_32  1
    psi[5,11]  column_33  1
    psi[5,12]  column_18  1
    psi[5,12]  column_19  1
    psi[5,12]  column_20  1
    psi[5,12]  column_21  1
    psi[5,12]  column_22  1
    psi[5,13]  OBJ       0
    psi[5,14]  OBJ       0
    psi[5,15]  OBJ       0
    psi[5,16]  OBJ       0
    psi[5,17]  OBJ       0
    psi[5,18]  OBJ       3.8099572331556913e-01
    psi[5,18]  column_23  1
    psi[5,18]  column_24  1
    psi[5,18]  column_25  1
    psi[5,18]  column_26  1
    psi[5,18]  column_27  1
    psi[5,18]  column_28  1
    psi[5,18]  column_29  1
    psi[5,18]  column_30  1
    psi[5,18]  column_31  1
    psi[5,18]  column_34  1
    psi[5,19]  OBJ       0
    psi[5,20]  OBJ       0
    psi[5,21]  OBJ       0
    psi[6,0]  OBJ       0
    psi[6,1]  OBJ       0
    psi[6,2]  OBJ       0
    psi[6,3]  OBJ       0
    psi[6,4]  OBJ       0
    psi[6,5]  OBJ       0
    psi[6,6]  OBJ       0
    psi[6,7]  OBJ       0
    psi[6,8]  OBJ       0
    psi[6,9]  OBJ       0
    psi[6,10]  OBJ       0
    psi[6,11]  OBJ       7.0366999297677968e-01
    psi[6,11]  column_0  1
    psi[6,11]  column_1  1
    psi[6,11]  column_2  1
    psi[6,11]  column_3  1
    psi[6,11]  column_4  1
    psi[6,11]  column_5  1
    psi[6,11]  column_6  1
    psi[6,11]  column_7  1
    psi[6,11]  column_8  1
    psi[6,11]  column_9  1
    psi[6,11]  column_18  1
    psi[6,11]  column_19  1
    psi[6,11]  column_20  1
    psi[6,11]  column_21  1
    psi[6,11]  column_23  1
    psi[6,11]  column_24  1
    psi[6,11]  column_25  1
    psi[6,11]  column_26  1
    psi[6,11]  column_27  1
    psi[6,11]  column_32  1
    psi[6,11]  column_33  1
    psi[6,11]  column_34  1
    psi[6,12]  column_10  1
    psi[6,13]  OBJ       0
    psi[6,14]  OBJ       0
    psi[6,15]  OBJ       0
    psi[6,16]  OBJ       0
    psi[6,17]  OBJ       0
    psi[6,18]  OBJ       0
    psi[6,19]  OBJ       0
    psi[6,20]  OBJ       2.9633000702322032e-01
    psi[6,20]  column_11  1
    psi[6,20]  column_12  1
    psi[6,20]  column_13  1
    psi[6,20]  column_14  1
    psi[6,20]  column_15  1
    psi[6,20]  column_16  1
    psi[6,20]  column_17  1
    psi[6,20]  column_22  1
    psi[6,20]  column_28  1
    psi[6,20]  column_29  1
    psi[6,20]  column_30  1
    psi[6,20]  column_31  1
    psi[6,21]  OBJ       0
    psi[6,22]  OBJ       0
    psi[6,23]  OBJ       0
    psi[6,24]  OBJ       0
    psi[7,0]  OBJ       0
    psi[7,1]  OBJ       0
    psi[7,2]  OBJ       0
    psi[7,3]  OBJ       0
    psi[7,4]  OBJ       0
    psi[7,5]  OBJ       0
    psi[7,6]  OBJ       0
    psi[7,7]  OBJ       0
    psi[7,8]  OBJ       0
    psi[7,9]  OBJ       0
    psi[7,10]  OBJ       1
    psi[7,10]  column_0  1
    psi[7,10]  column_1  1
    psi[7,10]  column_2  1
    psi[7,10]  column_3  1
    psi[7,10]  column_4  1
    psi[7,10]  column_5  1
    psi[7,10]  column_6  1
    psi[7,10]  column_7  1
    psi[7,10]  column_8  1
    psi[7,10]  column_9  1
    psi[7,10]  column_10  1
    psi[7,10]  column_11  1
    psi[7,10]  column_12  1
    psi[7,10]  column_13  1
    psi[7,10]  column_14  1
    psi[7,10]  column_15  1
    psi[7,10]  column_16  1
    psi[7,10]  column_17  1
    psi[7,10]  column_18  1
    psi[7,10]  column_19  1
    psi[7,10]  column_20  1
    psi[7,10]  column_21  1
    psi[7,10]  column_22  1
    psi[7,10]  column_23  1
    psi[7,10]  column_24  1
    psi[7,10]  column_25  1
    psi[7,10]  column_26  1
    psi[7,10]  column_27  1
    psi[7,10]  column_28  1
    psi[7,10]  column_29  1
    psi[7,10]  column_30  1
    psi[7,10]  column_31  1
    psi[7,10]  column_32  1
    psi[7,10]  column_33  1
    psi[7,10]  column_34  1
    psi[7,11]  OBJ       0
    psi[7,12]  OBJ       0
    psi[7,13]  OBJ       0
    psi[7,14]  OBJ       0
    psi[7,15]  OBJ       0
    psi[7,16]  OBJ       0
    psi[7,17]  OBJ       0
    psi[7,18]  OBJ       0
    psi[7,19]  OBJ       0
    psi[7,20]  OBJ       0
    psi[7,21]  OBJ       0
    psi[7,22]  OBJ       0
    psi[8,0]  OBJ       0
    psi[8,1]  OBJ       0
    psi[8,2]  OBJ       0
    psi[8,3]  OBJ       0
    psi[8,4]  OBJ       0
    psi[8,5]  OBJ       0
    psi[8,6]  OBJ       0
    psi[8,7]  OBJ       0
    psi[8,8]  OBJ       0
    psi[8,9]  OBJ       0
    psi[8,10]  OBJ       0
    psi[8,11]  OBJ       1
    psi[8,11]  column_0  1
    psi[8,11]  column_1  1
    psi[8,11]  column_2  1
    psi[8,11]  column_3  1
    psi[8,11]  column_4  1
    psi[8,11]  column_5  1
    psi[8,11]  column_6  1
    psi[8,11]  column_7  1
    psi[8,11]  column_8  1
    psi[8,11]  column_9  1
    psi[8,11]  column_10  1
    psi[8,11]  column_11  1
    psi[8,11]  column_12  1
    psi[8,11]  column_13  1
    psi[8,11]  column_14  1
    psi[8,11]  column_15  1
    psi[8,11]  column_16  1
    psi[8,11]  column_17  1
    psi[8,11]  column_18  1
    psi[8,11]  column_19  1
    psi[8,11]  column_20  1
    psi[8,11]  column_21  1
    psi[8,11]  column_22  1
    psi[8,11]  column_23  1
    psi[8,11]  column_24  1
    psi[8,11]  column_25  1
    psi[8,11]  column_26  1
    psi[8,11]  column_27  1
    psi[8,11]  column_28  1
    psi[8,11]  column_29  1
    psi[8,11]  column_30  1
    psi[8,11]  column_31  1
    psi[8,11]  column_32  1
    psi[8,11]  column_33  1
    psi[8,11]  column_34  1
    psi[8,12]  OBJ       0
    psi[8,13]  OBJ       0
    psi[8,14]  OBJ       0
    psi[8,15]  OBJ       0
    psi[8,16]  OBJ       0
    psi[8,17]  OBJ       0
    psi[8,18]  OBJ       0
    psi[8,19]  OBJ       0
    psi[8,20]  OBJ       0
    psi[8,21]  OBJ       0
    psi[9,0]  OBJ       0
    psi[9,1]  OBJ       0
    psi[9,2]  OBJ       0
    psi[9,3]  OBJ       0
    psi[9,4]  OBJ       0
    psi[9,5]  OBJ       0
    psi[9,6]  OBJ       0
    psi[9,7]  OBJ       0
    psi[9,8]  OBJ       0
    psi[9,9]  OBJ       1
    psi[9,9]  column_0  1
    psi[9,9]  column_1  1
    psi[9,9]  column_2  1
    psi[9,9]  column_3  1
    psi[9,9]  column_4  1
    psi[9,9]  column_5  1
    psi[9,9]  column_6  1
    psi[9,9]  column_7  1
    psi[9,9]  column_8  1
    psi[9,9]  column_9  1
    psi[9,9]  column_10  1
    psi[9,9]  column_11  1
    psi[9,9]  column_12  1
    psi[9,9]  column_13  1
    psi[9,9]  column_14  1
    psi[9,9]  column_15  1
    psi[9,9]  column_16  1
    psi[9,9]  column_17  1
    psi[9,9]  column_18  1
    psi[9,9]  column_19  1
    psi[9,9]  column_20  1
    psi[9,9]  column_21  1
    psi[9,9]  column_22  1
    psi[9,9]  column_23  1
    psi[9,9]  column_24  1
    psi[9,9]  column_25  1
    psi[9,9]  column_26  1
    psi[9,9]  column_27  1
    psi[9,9]  column_28  1
    psi[9,9]  column_29  1
    psi[9,9]  column_30  1
    psi[9,9]  column_31  1
    psi[9,9]  column_32  1
    psi[9,9]  column_33  1
    psi[9,9]  column_34  1
    psi[9,10]  OBJ       0
    psi[9,11]  OBJ       0
    psi[9,12]  OBJ       0
    psi[9,13]  OBJ       0
    psi[9,14]  OBJ       0
    psi[9,15]  OBJ       0
    psi[9,16]  OBJ       0
    psi[9,17]  OBJ       0
    psi[9,18]  OBJ       0
    psi[9,19]  OBJ       0
    psi[10,0]  OBJ       0
    psi[10,1]  OBJ       0
    psi[10,2]  OBJ       0
    psi[10,3]  OBJ       0
    psi[10,4]  OBJ       0
    psi[10,5]  OBJ       0
    psi[10,6]  OBJ       0
    psi[10,7]  OBJ       0
    psi[10,8]  OBJ       0
    psi[10,9]  OBJ       0
    psi[10,10]  OBJ       0
    psi[10,11]  OBJ       0
    psi[10,12]  OBJ       0
    psi[10,13]  OBJ       0
    psi[10,14]  OBJ       0
    psi[10,15]  OBJ       0
    psi[10,16]  OBJ       1
    psi[10,16]  column_0  1
    psi[10,16]  column_1  1
    psi[10,16]  column_2  1
    psi[10,16]  column_3  1
    psi[10,16]  column_4  1
    psi[10,16]  column_5  1
    psi[10,16]  column_6  1
    psi[10,16]  column_7  1
    psi[10,16]  column_8  1
    psi[10,16]  column_9  1
    psi[10,16]  column_10  1
    psi[10,16]  column_11  1
    psi[10,16]  column_12  1
    psi[10,16]  column_13  1
    psi[10,16]  column_14  1
    psi[10,16]  column_15  1
    psi[10,16]  column_16  1
    psi[10,16]  column_17  1
    psi[10,16]  column_18  1
    psi[10,16]  column_19  1
    psi[10,16]  column_20  1
    psi[10,16]  column_21  1
    psi[10,16]  column_22  1
    psi[10,16]  column_23  1
    psi[10,16]  column_24  1
    psi[10,16]  column_25  1
    psi[10,16]  column_26  1
    psi[10,16]  column_27  1
    psi[10,16]  column_28  1
    psi[10,16]  column_29  1
    psi[10,16]  column_30  1
    psi[10,16]  column_31  1
    psi[10,16]  column_32  1
    psi[10,16]  column_33  1
    psi[10,16]  column_34  1
    psi[10,17]  OBJ       0
    psi[10,18]  OBJ       0
    psi[10,19]  OBJ       0
    psi[10,20]  OBJ       0
    psi[10,21]  OBJ       0
    psi[10,22]  OBJ       0
    psi[10,23]  OBJ       0
    psi[10,24]  OBJ       0
    psi[10,25]  OBJ       0
    psi[10,26]  OBJ       0
    psi[10,27]  OBJ       0
    psi[10,28]  OBJ       0
    psi[10,29]  OBJ       0
    psi[11,0]  OBJ       0
    psi[11,1]  OBJ       0
    psi[11,2]  OBJ       0
    psi[11,3]  OBJ       0
    psi[11,4]  OBJ       0
    psi[11,5]  OBJ       0
    psi[11,6]  OBJ       0
    psi[11,7]  OBJ       0
    psi[11,8]  OBJ       0
    psi[11,9]  OBJ       0
    psi[11,10]  OBJ       0
    psi[11,11]  OBJ       0
    psi[11,12]  OBJ       0
    psi[11,13]  OBJ       0
    psi[11,14]  OBJ       0
    psi[11,15]  OBJ       0
    psi[11,16]  OBJ       0
    psi[11,17]  OBJ       1
    psi[11,17]  column_0  1
    psi[11,17]  column_1  1
    psi[11,17]  column_2  1
    psi[11,17]  column_3  1
    psi[11,17]  column_4  1
    psi[11,17]  column_5  1
    psi[11,17]  column_6  1
    psi[11,17]  column_7  1
    psi[11,17]  column_8  1
    psi[11,17]  column_9  1
    psi[11,17]  column_10  1
    psi[11,17]  column_11  1
    psi[11,17]  column_12  1
    psi[11,17]  column_13  1
    psi[11,17]  column_14  1
    psi[11,17]  column_15  1
    psi[11,17]  column_16  1
    psi[11,17]  column_17  1
    psi[11,17]  column_18  1
    psi[11,17]  column_19  1
    psi[11,17]  column_20  1
    psi[11,17]  column_21  1
    psi[11,17]  column_22  1
    psi[11,17]  column_23  1
    psi[11,17]  column_24  1
    psi[11,17]  column_25  1
    psi[11,17]  column_26  1
    psi[11,17]  column_27  1
    psi[11,17]  column_28  1
    psi[11,17]  column_29  1
    psi[11,17]  column_30  1
    psi[11,17]  column_31  1
    psi[11,17]  column_32  1
    psi[11,17]  column_33  1
    psi[11,17]  column_34  1
    psi[11,18]  OBJ       0
    psi[11,19]  OBJ       0
    psi[11,20]  OBJ       0
    psi[11,21]  OBJ       0
    psi[11,22]  OBJ       0
    psi[11,23]  OBJ       0
    psi[11,24]  OBJ       0
    psi[11,25]  OBJ       0
    psi[11,26]  OBJ       0
    psi[11,27]  OBJ       0
    psi[11,28]  OBJ       0
    psi[11,29]  OBJ       0
    psi[11,30]  OBJ       0
    psi[11,31]  OBJ       0
    psi[12,0]  OBJ       0
    psi[12,1]  OBJ       0
    psi[12,2]  OBJ       0
    psi[12,3]  OBJ       0
    psi[12,4]  OBJ       0
    psi[12,5]  OBJ       0
    psi[12,6]  OBJ       0
    psi[12,7]  OBJ       0
    psi[12,8]  OBJ       0
    psi[12,9]  OBJ       0
    psi[12,10]  OBJ       6.9693522008988817e-01
    psi[12,10]  column_0  1
    psi[12,10]  column_1  1
    psi[12,10]  column_2  1
    psi[12,10]  column_3  1
    psi[12,10]  column_4  1
    psi[12,10]  column_5  1
    psi[12,10]  column_11  1
    psi[12,10]  column_12  1
    psi[12,10]  column_18  1
    psi[12,10]  column_22  1
    psi[12,10]  column_23  1
    psi[12,10]  column_24  1
    psi[12,10]  column_25  1
    psi[12,10]  column_26  1
    psi[12,10]  column_28  1
    psi[12,10]  column_29  1
    psi[12,10]  column_30  1
    psi[12,10]  column_32  1
    psi[12,10]  column_33  1
    psi[12,10]  column_34  1
    psi[12,11]  OBJ       0
    psi[12,12]  OBJ       0
    psi[12,13]  OBJ       0
    psi[12,14]  OBJ       0
    psi[12,15]  OBJ       0
    psi[12,16]  OBJ       0
    psi[12,17]  OBJ       0
    psi[12,18]  OBJ       3.0306477991011188e-01
    psi[12,18]  column_6  1
    psi[12,18]  column_7  1
    psi[12,18]  column_8  1
    psi[12,18]  column_9  1
    psi[12,18]  column_10  1
    psi[12,18]  column_13  1
    psi[12,18]  column_14  1
    psi[12,18]  column_15  1
    psi[12,18]  column_16  1
    psi[12,18]  column_17  1
    psi[12,18]  column_19  1
    psi[12,18]  column_20  1
    psi[12,18]  column_21  1
    psi[12,18]  column_27  1
    psi[12,18]  column_31  1
    psi[12,19]  OBJ       0
    psi[13,0]  OBJ       0
    psi[13,1]  OBJ       0
    psi[13,2]  OBJ       0
    psi[13,3]  OBJ       0
    psi[13,4]  OBJ       0
    psi[13,5]  OBJ       0
    psi[13,6]  OBJ       0
    psi[13,7]  OBJ       0
    psi[13,8]  OBJ       0
    psi[13,9]  OBJ       0
    psi[13,10]  OBJ       0
    psi[13,11]  OBJ       0
    psi[13,12]  OBJ       0
    psi[13,13]  OBJ       1
    psi[13,13]  column_0  1
    psi[13,13]  column_1  1
    psi[13,13]  column_2  1
    psi[13,13]  column_3  1
    psi[13,13]  column_4  1
    psi[13,13]  column_5  1
    psi[13,13]  column_6  1
    psi[13,13]  column_7  1
    psi[13,13]  column_8  1
    psi[13,13]  column_9  1
    psi[13,13]  column_10  1
    psi[13,13]  column_11  1
    psi[13,13]  column_12  1
    psi[13,13]  column_13  1
    psi[13,13]  column_14  1
    psi[13,13]  column_15  1
    psi[13,13]  column_16  1
    psi[13,13]  column_17  1
    psi[13,13]  column_18  1
    psi[13,13]  column_19  1
    psi[13,13]  column_20  1
    psi[13,13]  column_21  1
    psi[13,13]  column_22  1
    psi[13,13]  column_23  1
    psi[13,13]  column_24  1
    psi[13,13]  column_25  1
    psi[13,13]  column_26  1
    psi[13,13]  column_27  1
    psi[13,13]  column_28  1
    psi[13,13]  column_29  1
    psi[13,13]  column_30  1
    psi[13,13]  column_31  1
    psi[13,13]  column_32  1
    psi[13,13]  column_33  1
    psi[13,13]  column_34  1
    psi[13,14]  OBJ       0
    psi[13,15]  OBJ       0
    psi[13,16]  OBJ       0
    psi[13,17]  OBJ       0
    psi[13,18]  OBJ       0
    psi[13,19]  OBJ       0
    psi[13,20]  OBJ       0
    psi[13,21]  OBJ       0
    psi[13,22]  OBJ       0
    psi[13,23]  OBJ       0
    psi[13,24]  OBJ       0
    psi[13,25]  OBJ       0
    psi[14,0]  OBJ       0
    psi[14,1]  OBJ       0
    psi[14,2]  OBJ       0
    psi[14,3]  OBJ       0
    psi[14,4]  OBJ       0
    psi[14,5]  OBJ       0
    psi[14,6]  OBJ       0
    psi[14,7]  OBJ       0
    psi[14,8]  OBJ       0
    psi[14,9]  OBJ       0
    psi[14,10]  OBJ       0
    psi[14,11]  OBJ       0
    psi[14,12]  OBJ       0
    psi[14,13]  OBJ       1
    psi[14,13]  column_0  1
    psi[14,13]  column_1  1
    psi[14,13]  column_2  1
    psi[14,13]  column_3  1
    psi[14,13]  column_4  1
    psi[14,13]  column_5  1
    psi[14,13]  column_6  1
    psi[14,13]  column_7  1
    psi[14,13]  column_8  1
    psi[14,13]  column_9  1
    psi[14,13]  column_10  1
    psi[14,13]  column_11  1
    psi[14,13]  column_12  1
    psi[14,13]  column_13  1
    psi[14,13]  column_14  1
    psi[14,13]  column_15  1
    psi[14,13]  column_16  1
    psi[14,13]  column_17  1
    psi[14,13]  column_18  1
    psi[14,13]  column_19  1
    psi[14,13]  column_20  1
    psi[14,13]  column_21  1
    psi[14,13]  column_22  1
    psi[14,13]  column_23  1
    psi[14,13]  column_24  1
    psi[14,13]  column_25  1
    psi[14,13]  column_26  1
    psi[14,13]  column_27  1
    psi[14,13]  column_28  1
    psi[14,13]  column_29  1
    psi[14,13]  column_30  1
    psi[14,13]  column_31  1
    psi[14,13]  column_32  1
    psi[14,13]  column_33  1
    psi[14,13]  column_34  1
    psi[14,14]  OBJ       0
    psi[14,15]  OBJ       0
    psi[14,16]  OBJ       0
    psi[14,17]  OBJ       0
    psi[14,18]  OBJ       0
    psi[14,19]  OBJ       0
    psi[14,20]  OBJ       0
    psi[14,21]  OBJ       0
    psi[14,22]  OBJ       0
    psi[14,23]  OBJ       0
    psi[15,0]  OBJ       0
    psi[15,1]  OBJ       0
    psi[15,2]  OBJ       0
    psi[15,3]  OBJ       0
    psi[15,4]  OBJ       0
    psi[15,5]  OBJ       0
    psi[15,6]  OBJ       0
    psi[15,7]  OBJ       0
    psi[15,8]  OBJ       0
    psi[15,9]  OBJ       0
    psi[15,10]  OBJ       0
    psi[15,11]  OBJ       0
    psi[15,12]  OBJ       0
    psi[15,13]  OBJ       0
    psi[15,14]  OBJ       1
    psi[15,14]  column_0  1
    psi[15,14]  column_1  1
    psi[15,14]  column_2  1
    psi[15,14]  column_3  1
    psi[15,14]  column_4  1
    psi[15,14]  column_5  1
    psi[15,14]  column_6  1
    psi[15,14]  column_7  1
    psi[15,14]  column_8  1
    psi[15,14]  column_9  1
    psi[15,14]  column_10  1
    psi[15,14]  column_11  1
    psi[15,14]  column_12  1
    psi[15,14]  column_13  1
    psi[15,14]  column_14  1
    psi[15,14]  column_15  1
    psi[15,14]  column_16  1
    psi[15,14]  column_17  1
    psi[15,14]  column_18  1
    psi[15,14]  column_19  1
    psi[15,14]  column_20  1
    psi[15,14]  column_21  1
    psi[15,14]  column_22  1
    psi[15,14]  column_23  1
    psi[15,14]  column_24  1
    psi[15,14]  column_25  1
    psi[15,14]  column_26  1
    psi[15,14]  column_27  1
    psi[15,14]  column_28  1
    psi[15,14]  column_29  1
    psi[15,14]  column_30  1
    psi[15,14]  column_31  1
    psi[15,14]  column_32  1
    psi[15,14]  column_33  1
    psi[15,14]  column_34  1
    psi[15,15]  OBJ       0
    psi[15,16]  OBJ       0
    psi[15,17]  OBJ       0
    psi[15,18]  OBJ       0
    psi[15,19]  OBJ       0
    psi[15,20]  OBJ       0
    psi[15,21]  OBJ       0
    psi[15,22]  OBJ       0
    psi[15,23]  OBJ       0
    psi[15,24]  OBJ       0
    psi[15,25]  OBJ       0
    psi[15,26]  OBJ       0
    psi[15,27]  OBJ       0
    psi[16,0]  OBJ       0
    psi[16,1]  OBJ       0
    psi[16,2]  OBJ       0
    psi[16,3]  OBJ       0
    psi[16,4]  OBJ       0
    psi[16,5]  OBJ       0
    psi[16,6]  OBJ       0
    psi[16,7]  OBJ       0
    psi[16,8]  OBJ       0
    psi[16,9]  OBJ       0
    psi[16,10]  OBJ       0
    psi[16,11]  OBJ       0
    psi[16,12]  OBJ       6.7673090142921388e-01
    psi[16,12]  column_0  1
    psi[16,12]  column_1  1
    psi[16,12]  column_2  1
    psi[16,12]  column_6  1
    psi[16,12]  column_10  1
    psi[16,12]  column_11  1
    psi[16,12]  column_12  1
    psi[16,12]  column_13  1
    psi[16,12]  column_14  1
    psi[16,12]  column_19  1
    psi[16,12]  column_23  1
    psi[16,12]  column_24  1
    psi[16,12]  column_25  1
    psi[16,12]  column_26  1
    psi[16,12]  column_34  1
    psi[16,13]  column_3  1
    psi[16,13]  column_7  1
    psi[16,13]  column_15  1
    psi[16,13]  column_20  1
    psi[16,13]  column_21  1
    psi[16,13]  column_22  1
    psi[16,13]  column_28  1
    psi[16,13]  column_29  1
    psi[16,13]  column_31  1
    psi[16,13]  column_32  1
    psi[16,14]  OBJ       0
    psi[16,15]  OBJ       0
    psi[16,16]  OBJ       0
    psi[16,17]  OBJ       0
    psi[16,18]  OBJ       0
    psi[16,19]  OBJ       0
    psi[16,20]  OBJ       0
    psi[16,21]  OBJ       3.2326909857078612e-01
    psi[16,21]  column_4  1
    psi[16,21]  column_5  1
    psi[16,21]  column_8  1
    psi[16,21]  column_9  1
    psi[16,21]  column_16  1
    psi[16,21]  column_17  1
    psi[16,21]  column_18  1
    psi[16,21]  column_27  1
    psi[16,21]  column_30  1
    psi[16,21]  column_33  1
    psi[16,22]  OBJ       0
    psi[17,0]  OBJ       0
    psi[17,1]  OBJ       0
    psi[17,2]  OBJ       0
    psi[17,3]  OBJ       0
    psi[17,4]  OBJ       0
    psi[17,5]  OBJ       0
    psi[17,6]  OBJ       0
    psi[17,7]  OBJ       0
    psi[17,8]  OBJ       7.5754817607191050e-01
    psi[17,8]  column_0  1
    psi[17,8]  column_1  1
    psi[17,8]  column_3  1
    psi[17,8]  column_4  1
    psi[17,8]  column_6  1
    psi[17,8]  column_13  1
    psi[17,8]  column_16  1
    psi[17,8]  column_23  1
    psi[17,8]  column_24  1
    psi[17,8]  column_25  1
    psi[17,8]  column_27  1
    psi[17,8]  column_28  1
    psi[17,8]  column_30  1
    psi[17,8]  column_31  1
    psi[17,8]  column_33  1
    psi[17,9]  column_5  1
    psi[17,9]  column_8  1
    psi[17,9]  column_11  1
    psi[17,9]  column_17  1
    psi[17,9]  column_18  1
    psi[17,9]  column_29  1
    psi[17,10]  OBJ       0
    psi[17,11]  OBJ       0
    psi[17,12]  OBJ       0
    psi[17,13]  OBJ       0
    psi[17,14]  OBJ       0
    psi[17,15]  OBJ       0
    psi[17,16]  OBJ       2.4245182392808950e-01
    psi[17,16]  column_2  1
    psi[17,16]  column_7  1
    psi[17,16]  column_9  1
    psi[17,16]  column_10  1
    psi[17,16]  column_12  1
    psi[17,16]  column_14  1
    psi[17,16]  column_15  1
    psi[17,16]  column_19  1
    psi[17,16]  column_20  1
    psi[17,16]  column_21  1
    psi[17,16]  column_22  1
    psi[17,16]  column_26  1
    psi[17,16]  column_32  1
    psi[17,16]  column_34  1
    psi[17,17]  OBJ       0
    psi[17,18]  OBJ       0
    psi[17,19]  OBJ       0
    psi[18,0]  OBJ       0
    psi[18,1]  OBJ       0
    psi[18,2]  OBJ       0
    psi[18,3]  OBJ       0
    psi[18,4]  OBJ       0
    psi[18,5]  OBJ       0
    psi[18,6]  OBJ       0
    psi[18,7]  OBJ       0
    psi[18,8]  OBJ       0
    psi[18,9]  OBJ       0
    psi[18,10]  OBJ       0
    psi[18,11]  OBJ       7.0366999297677957e-01
    psi[18,11]  column_0  1
    psi[18,11]  column_1  1
    psi[18,11]  column_3  1
    psi[18,11]  column_4  1
    psi[18,11]  column_5  1
    psi[18,11]  column_7  1
    psi[18,11]  column_8  1
    psi[18,11]  column_9  1
    psi[18,11]  column_11  1
    psi[18,11]  column_12  1
    psi[18,11]  column_13  1
    psi[18,11]  column_14  1
    psi[18,11]  column_15  1
    psi[18,11]  column_16  1
    psi[18,11]  column_17  1
    psi[18,11]  column_18  1
    psi[18,11]  column_19  1
    psi[18,11]  column_20  1
    psi[18,11]  column_22  1
    psi[18,11]  column_23  1
    psi[18,11]  column_24  1
    psi[18,11]  column_26  1
    psi[18,11]  column_27  1
    psi[18,11]  column_28  1
    psi[18,11]  column_29  1
    psi[18,11]  column_30  1
    psi[18,11]  column_31  1
    psi[18,11]  column_32  1
    psi[18,11]  column_33  1
    psi[18,11]  column_34  1
    psi[18,12]  OBJ       0
    psi[18,13]  OBJ       0
    psi[18,14]  OBJ       0
    psi[18,15]  OBJ       0
    psi[18,16]  OBJ       0
    psi[18,17]  OBJ       0
    psi[18,18]  OBJ       0
    psi[18,19]  OBJ       0
    psi[18,20]  OBJ       2.9633000702322043e-01
    psi[18,20]  column_2  1
    psi[18,20]  column_6  1
    psi[18,20]  column_10  1
    psi[18,20]  column_21  1
    psi[18,20]  column_25  1
    psi[18,21]  OBJ       0
    psi[18,22]  OBJ       0
    psi[19,0]  OBJ       0
    psi[19,1]  OBJ       0
    psi[19,2]  OBJ       0
    psi[19,3]  OBJ       0
    psi[19,4]  OBJ       0
    psi[19,5]  OBJ       0
    psi[19,6]  OBJ       0
    psi[19,7]  OBJ       0
    psi[19,8]  OBJ       0
    psi[19,9]  OBJ       0
    psi[19,10]  OBJ       0
    psi[19,11]  OBJ       0
    psi[19,12]  OBJ       6.3632226410786630e-01
    psi[19,12]  column_0  1
    psi[19,12]  column_3  1
    psi[19,12]  column_8  1
    psi[19,12]  column_9  1
    psi[19,12]  column_10  1
    psi[19,12]  column_11  1
    psi[19,12]  column_12  1
    psi[19,12]  column_13  1
    psi[19,12]  column_14  1
    psi[19,12]  column_15  1
    psi[19,12]  column_16  1
    psi[19,12]  column_17  1
    psi[19,12]  column_20  1
    psi[19,12]  column_21  1
    psi[19,12]  column_23  1
    psi[19,12]  column_25  1
    psi[19,12]  column_27  1
    psi[19,12]  column_28  1
    psi[19,12]  column_29  1
    psi[19,12]  column_30  1
    psi[19,12]  column_31  1
    psi[19,12]  column_32  1
    psi[19,12]  column_33  1
    psi[19,12]  column_34  1
    psi[19,13]  column_7  1
    psi[19,14]  OBJ       0
    psi[19,15]  OBJ       0
    psi[19,16]  OBJ       0
    psi[19,17]  OBJ       0
    psi[19,18]  OBJ       0
    psi[19,19]  OBJ       0
    psi[19,20]  OBJ       3.6367773589213376e-01
    psi[19,20]  column_1  1
    psi[19,20]  column_2  1
    psi[19,20]  column_4  1
    psi[19,20]  column_5  1
    psi[19,20]  column_6  1
    psi[19,20]  column_18  1
    psi[19,20]  column_19  1
    psi[19,20]  column_22  1
    psi[19,20]  column_24  1
    psi[19,20]  column_26  1
    psi[19,21]  OBJ       0
    psi[19,22]  OBJ       0
    psi[19,23]  OBJ       0
    psi[20,0]  OBJ       0
    psi[20,1]  OBJ       0
    psi[20,2]  OBJ       0
    psi[20,3]  OBJ       0
    psi[20,4]  OBJ       0
    psi[20,5]  OBJ       0
    psi[20,6]  OBJ       0
    psi[20,7]  OBJ       0
    psi[20,8]  OBJ       0
    psi[20,9]  OBJ       0
    psi[20,10]  OBJ       0
    psi[20,11]  OBJ       0
    psi[20,12]  OBJ       0
    psi[20,13]  OBJ       6.0601578611685425e-01
    psi[20,13]  column_0  1
    psi[20,13]  column_2  1
    psi[20,13]  column_3  1
    psi[20,13]  column_6  1
    psi[20,13]  column_9  1
    psi[20,13]  column_10  1
    psi[20,13]  column_14  1
    psi[20,13]  column_15  1
    psi[20,13]  column_16  1
    psi[20,13]  column_17  1
    psi[20,13]  column_19  1
    psi[20,13]  column_22  1
    psi[20,13]  column_26  1
    psi[20,13]  column_27  1
    psi[20,13]  column_30  1
    psi[20,13]  column_31  1
    psi[20,13]  column_34  1
    psi[20,14]  column_21  1
    psi[20,15]  OBJ       0
    psi[20,16]  OBJ       0
    psi[20,17]  OBJ       0
    psi[20,18]  OBJ       0
    psi[20,19]  OBJ       0
    psi[20,20]  OBJ       0
    psi[20,21]  OBJ       3.9398421388314575e-01
    psi[20,21]  column_1  1
    psi[20,21]  column_4  1
    psi[20,21]  column_5  1
    psi[20,21]  column_7  1
    psi[20,21]  column_8  1
    psi[20,21]  column_11  1
    psi[20,21]  column_12  1
    psi[20,21]  column_13  1
    psi[20,21]  column_18  1
    psi[20,21]  column_20  1
    psi[20,21]  column_23  1
    psi[20,21]  column_24  1
    psi[20,21]  column_25  1
    psi[20,21]  column_28  1
    psi[20,21]  column_29  1
    psi[20,21]  column_32  1
    psi[20,21]  column_33  1
    psi[20,22]  OBJ       0
    psi[20,23]  OBJ       0
    a         OBJ       1
    a         column_0  1
    a         column_1  1
    a         column_2  1
    a         column_3  1
    a         column_4  1
    a         column_5  1
    a         column_6  1
    a         column_7  1
    a         column_8  1
    a         column_9  1
    a         column_10  1
    a         column_11  1
    a         column_12  1
    a         column_13  1
    a         column_14  1
    a         column_15  1
    a         column_16  1
    a         column_17  1
    a         column_18  1
    a         column_19  1
    a         column_20  1
    a         column_21  1
    a         column_22  1
    a         column_23  1
    a         column_24  1
    a         column_25  1
    a         column_26  1
    a         column_27  1
    a         column_28  1
    a         column_29  1
    a         column_30  1
    a         column_31  1
    a         column_32  1
    a         column_33  1
    a         column_34  1
RHS
    RHS1      column_0  2.3037127760972e-17
    RHS1      column_1  5.4337349397590377e-02
    RHS1      column_2  9.5417789757412413e-02
    RHS1      column_3  3.9419087136929633e-03
    RHS1      column_4  0.0790078556881001
    RHS1      column_5  8.2229133516563011e-02
    RHS1      column_6  8.7829752515637766e-02
    RHS1      column_7  9.7047802884069514e-02
    RHS1      column_8  8.7045983953067063e-02
    RHS1      column_9  9.7228381374722853e-02
    RHS1      column_10  1.0148118494795839e-01
    RHS1      column_11  0.0646656935490411
    RHS1      column_12  9.3921446384039931e-02
    RHS1      column_13  8.6302447002579136e-02
    RHS1      column_14  9.9276527331189732e-02
    RHS1      column_15  1.0129813788960824e-01
    RHS1      column_16  9.0296687665108746e-02
    RHS1      column_17  0.0934070930585026
    RHS1      column_18  8.4140527797786663e-02
    RHS1      column_19  9.7044599677592713e-02
    RHS1      column_20  9.7233243386871282e-02
    RHS1      column_21  1.0428781106824520e-01
    RHS1      column_22  9.9314610498161163e-02
    RHS1      column_23  5.3060217176702888e-02
    RHS1      column_24  7.4630437094544311e-02
    RHS1      column_25  8.0640050697084950e-02
    RHS1      column_26  0.0894021739130435
    RHS1      column_27  8.4501126818274971e-02
    RHS1      column_28  0.0827817966592135
    RHS1      column_29  0.0855903163787128
    RHS1      column_30  8.5209825997952932e-02
    RHS1      column_31  8.9028691582445932e-02
    RHS1      column_32  8.8670729603863643e-02
    RHS1      column_33  0.0767378742777097
    RHS1      column_34  8.7285363859362253e-02
BOUNDS
 LO BND1      psi[1,0]  -0.05
 UP BND1      psi[1,0]  0.05
 LO BND1      psi[1,1]  -0.05
 UP BND1      psi[1,1]  0.05
 LO BND1      psi[1,2]  -0.05
 UP BND1      psi[1,2]  0.05
 LO BND1      psi[1,3]  -0.05
 UP BND1      psi[1,3]  0.05
 LO BND1      psi[1,4]  -0.05
 UP BND1      psi[1,4]  0.05
 LO BND1      psi[1,5]  -0.05
 UP BND1      psi[1,5]  0.05
 LO BND1      psi[1,6]  -0.05
 UP BND1      psi[1,6]  0.05
 LO BND1      psi[1,7]  -0.05
 UP BND1      psi[1,7]  0.05
 LO BND1      psi[1,8]  -0.05
 UP BND1      psi[1,8]  0.05
 LO BND1      psi[1,9]  -0.05
 UP BND1      psi[1,9]  0.05
 LO BND1      psi[1,10]  -0.05
 UP BND1      psi[1,10]  0.05
 FX BND1      psi[1,11]  0
 LO BND1      psi[1,12]  -0.05
 UP BND1      psi[1,12]  0.05
 LO BND1      psi[1,13]  -0.05
 UP BND1      psi[1,13]  0.05
 LO BND1      psi[1,14]  -0.05
 UP BND1      psi[1,14]  0.05
 LO BND1      psi[1,15]  -0.05
 UP BND1      psi[1,15]  0.05
 LO BND1      psi[1,16]  -0.05
 UP BND1      psi[1,16]  0.05
 LO BND1      psi[1,17]  -0.05
 UP BND1      psi[1,17]  0.05
 LO BND1      psi[1,18]  -0.05
 UP BND1      psi[1,18]  0.05
 LO BND1      psi[1,19]  -0.05
 UP BND1      psi[1,19]  0.05
 LO BND1      psi[1,20]  -0.05
 UP BND1      psi[1,20]  0.05
 LO BND1      psi[1,21]  -0.05
 UP BND1      psi[1,21]  0.05
 LO BND1      psi[1,22]  -0.05
 UP BND1      psi[1,22]  0.05
 LO BND1      psi[1,23]  -0.05
 UP BND1      psi[1,23]  0.05
 LO BND1      psi[1,24]  -0.05
 UP BND1      psi[1,24]  0.05
 LO BND1      psi[2,0]  -0.05
 UP BND1      psi[2,0]  0.05
 LO BND1      psi[2,1]  -0.05
 UP BND1      psi[2,1]  0.05
 LO BND1      psi[2,2]  -0.05
 UP BND1      psi[2,2]  0.05
 LO BND1      psi[2,3]  -0.05
 UP BND1      psi[2,3]  0.05
 LO BND1      psi[2,4]  -0.05
 UP BND1      psi[2,4]  0.05
 LO BND1      psi[2,5]  -0.05
 UP BND1      psi[2,5]  0.05
 LO BND1      psi[2,6]  -0.05
 UP BND1      psi[2,6]  0.05
 LO BND1      psi[2,7]  -0.05
 UP BND1      psi[2,7]  0.05
 LO BND1      psi[2,8]  -0.05
 UP BND1      psi[2,8]  0.05
 LO BND1      psi[2,9]  -0.05
 UP BND1      psi[2,9]  0.05
 LO BND1      psi[2,10]  -0.05
 UP BND1      psi[2,10]  0.05
 LO BND1      psi[2,11]  -0.05
 UP BND1      psi[2,11]  0.05
 LO BND1      psi[2,12]  -0.05
 UP BND1      psi[2,12]  0.05
 LO BND1      psi[2,13]  -0.05
 UP BND1      psi[2,13]  0.05
 FX BND1      psi[2,14]  0
 LO BND1      psi[2,15]  -0.05
 UP BND1      psi[2,15]  0.05
 LO BND1      psi[2,16]  -0.05
 UP BND1      psi[2,16]  0.05
 LO BND1      psi[2,17]  -0.05
 UP BND1      psi[2,17]  0.05
 LO BND1      psi[2,18]  -0.05
 UP BND1      psi[2,18]  0.05
 LO BND1      psi[2,19]  -0.05
 UP BND1      psi[2,19]  0.05
 LO BND1      psi[2,20]  -0.05
 UP BND1      psi[2,20]  0.05
 LO BND1      psi[2,21]  -0.05
 UP BND1      psi[2,21]  0.05
 LO BND1      psi[2,22]  -0.05
 UP BND1      psi[2,22]  0.05
 LO BND1      psi[2,23]  -0.05
 UP BND1      psi[2,23]  0.05
 LO BND1      psi[2,24]  -0.05
 UP BND1      psi[2,24]  0.05
 LO BND1      psi[2,25]  -0.05
 UP BND1      psi[2,25]  0.05
 LO BND1      psi[3,0]  -0.05
 UP BND1      psi[3,0]  0.05
 LO BND1      psi[3,1]  -0.05
 UP BND1      psi[3,1]  0.05
 LO BND1      psi[3,2]  -0.05
 UP BND1      psi[3,2]  0.05
 LO BND1      psi[3,3]  -0.05
 UP BND1      psi[3,3]  0.05
 LO BND1      psi[3,4]  -0.05
 UP BND1      psi[3,4]  0.05
 LO BND1      psi[3,5]  -0.05
 UP BND1      psi[3,5]  0.05
 LO BND1      psi[3,6]  -0.05
 UP BND1      psi[3,6]  0.05
 LO BND1      psi[3,7]  -0.05
 UP BND1      psi[3,7]  0.05
 LO BND1      psi[3,8]  -0.05
 UP BND1      psi[3,8]  0.05
 LO BND1      psi[3,9]  -0.05
 UP BND1      psi[3,9]  0.05
 LO BND1      psi[3,10]  -0.05
 UP BND1      psi[3,10]  0.05
 LO BND1      psi[3,11]  -0.05
 UP BND1      psi[3,11]  0.05
 LO BND1      psi[3,12]  -0.05
 UP BND1      psi[3,12]  0.05
 LO BND1      psi[3,13]  -0.05
 UP BND1      psi[3,13]  0.05
 LO BND1      psi[3,14]  -0.05
 UP BND1      psi[3,14]  0.05
 FX BND1      psi[3,15]  0
 LO BND1      psi[3,16]  -0.05
 UP BND1      psi[3,16]  0.05
 LO BND1      psi[3,17]  -0.05
 UP BND1      psi[3,17]  0.05
 LO BND1      psi[3,18]  -0.05
 UP BND1      psi[3,18]  0.05
 LO BND1      psi[3,19]  -0.05
 UP BND1      psi[3,19]  0.05
 LO BND1      psi[3,20]  -0.05
 UP BND1      psi[3,20]  0.05
 LO BND1      psi[3,21]  -0.05
 UP BND1      psi[3,21]  0.05
 LO BND1      psi[3,22]  -0.05
 UP BND1      psi[3,22]  0.05
 LO BND1      psi[3,23]  -0.05
 UP BND1      psi[3,23]  0.05
 LO BND1      psi[3,24]  -0.05
 UP BND1      psi[3,24]  0.05
 LO BND1      psi[3,25]  -0.05
 UP BND1      psi[3,25]  0.05
 LO BND1      psi[3,26]  -0.05
 UP BND1      psi[3,26]  0.05
 LO BND1      psi[3,27]  -0.05
 UP BND1      psi[3,27]  0.05
 LO BND1      psi[4,0]  -0.05
 UP BND1      psi[4,0]  0.05
 LO BND1      psi[4,1]  -0.05
 UP BND1      psi[4,1]  0.05
 LO BND1      psi[4,2]  -0.05
 UP BND1      psi[4,2]  0.05
 LO BND1      psi[4,3]  -0.05
 UP BND1      psi[4,3]  0.05
 LO BND1      psi[4,4]  -0.05
 UP BND1      psi[4,4]  0.05
 LO BND1      psi[4,5]  -0.05
 UP BND1      psi[4,5]  0.05
 LO BND1      psi[4,6]  -0.05
 UP BND1      psi[4,6]  0.05
 LO BND1      psi[4,7]  -0.05
 UP BND1      psi[4,7]  0.05
 LO BND1      psi[4,8]  -0.05
 UP BND1      psi[4,8]  0.05
 LO BND1      psi[4,9]  -0.05
 UP BND1      psi[4,9]  0.05
 LO BND1      psi[4,10]  -0.05
 UP BND1      psi[4,10]  0.05
 FX BND1      psi[4,11]  0
 LO BND1      psi[4,12]  -0.05
 UP BND1      psi[4,12]  0.05
 LO BND1      psi[4,13]  -0.05
 UP BND1      psi[4,13]  0.05
 LO BND1      psi[4,14]  -0.05
 UP BND1      psi[4,14]  0.05
 LO BND1      psi[4,15]  -0.05
 UP BND1      psi[4,15]  0.05
 LO BND1      psi[4,16]  -0.05
 UP BND1      psi[4,16]  0.05
 LO BND1      psi[4,17]  -0.05
 UP BND1      psi[4,17]  0.05
 LO BND1      psi[4,18]  -0.05
 UP BND1      psi[4,18]  0.05
 LO BND1      psi[4,19]  -0.05
 UP BND1      psi[4,19]  0.05
 LO BND1      psi[4,20]  -0.05
 UP BND1      psi[4,20]  0.05
 LO BND1      psi[4,21]  -0.05
 UP BND1      psi[4,21]  0.05
 LO BND1      psi[4,22]  -0.05
 UP BND1      psi[4,22]  0.05
 LO BND1      psi[4,23]  -0.05
 UP BND1      psi[4,23]  0.05
 LO BND1      psi[4,24]  -0.05
 UP BND1      psi[4,24]  0.05
 LO BND1      psi[5,0]  -0.05
 UP BND1      psi[5,0]  0.05
 LO BND1      psi[5,1]  -0.05
 UP BND1      psi[5,1]  0.05
 LO BND1      psi[5,2]  -0.05
 UP BND1      psi[5,2]  0.05
 LO BND1      psi[5,3]  -0.05
 UP BND1      psi[5,3]  0.05
 LO BND1      psi[5,4]  -0.05
 UP BND1      psi[5,4]  0.05
 LO BND1      psi[5,5]  -0.05
 UP BND1      psi[5,5]  0.05
 LO BND1      psi[5,6]  -0.05
 UP BND1      psi[5,6]  0.05
 LO BND1      psi[5,7]  -0.05
 UP BND1      psi[5,7]  0.05
 LO BND1      psi[5,8]  -0.05
 UP BND1      psi[5,8]  0.05
 LO BND1      psi[5,9]  -0.05
 UP BND1      psi[5,9]  0.05
 LO BND1      psi[5,10]  -0.05
 UP BND1      psi[5,10]  0.05
 FX BND1      psi[5,11]  0
 LO BND1      psi[5,12]  -0.05
 UP BND1      psi[5,12]  0.05
 LO BND1      psi[5,13]  -0.05
 UP BND1      psi[5,13]  0.05
 LO BND1      psi[5,14]  -0.05
 UP BND1      psi[5,14]  0.05
 LO BND1      psi[5,15]  -0.05
 UP BND1      psi[5,15]  0.05
 LO BND1      psi[5,16]  -0.05
 UP BND1      psi[5,16]  0.05
 LO BND1      psi[5,17]  -0.05
 UP BND1      psi[5,17]  0.05
 LO BND1      psi[5,18]  -0.05
 UP BND1      psi[5,18]  0.05
 LO BND1      psi[5,19]  -0.05
 UP BND1      psi[5,19]  0.05
 LO BND1      psi[5,20]  -0.05
 UP BND1      psi[5,20]  0.05
 LO BND1      psi[5,21]  -0.05
 UP BND1      psi[5,21]  0.05
 LO BND1      psi[6,0]  -0.05
 UP BND1      psi[6,0]  0.05
 LO BND1      psi[6,1]  -0.05
 UP BND1      psi[6,1]  0.05
 LO BND1      psi[6,2]  -0.05
 UP BND1      psi[6,2]  0.05
 LO BND1      psi[6,3]  -0.05
 UP BND1      psi[6,3]  0.05
 LO BND1      psi[6,4]  -0.05
 UP BND1      psi[6,4]  0.05
 LO BND1      psi[6,5]  -0.05
 UP BND1      psi[6,5]  0.05
 LO BND1      psi[6,6]  -0.05
 UP BND1      psi[6,6]  0.05
 LO BND1      psi[6,7]  -0.05
 UP BND1      psi[6,7]  0.05
 LO BND1      psi[6,8]  -0.05
 UP BND1      psi[6,8]  0.05
 LO BND1      psi[6,9]  -0.05
 UP BND1      psi[6,9]  0.05
 LO BND1      psi[6,10]  -0.05
 UP BND1      psi[6,10]  0.05
 FX BND1      psi[6,11]  0
 LO BND1      psi[6,12]  -0.05
 UP BND1      psi[6,12]  0.05
 LO BND1      psi[6,13]  -0.05
 UP BND1      psi[6,13]  0.05
 LO BND1      psi[6,14]  -0.05
 UP BND1      psi[6,14]  0.05
 LO BND1      psi[6,15]  -0.05
 UP BND1      psi[6,15]  0.05
 LO BND1      psi[6,16]  -0.05
 UP BND1      psi[6,16]  0.05
 LO BND1      psi[6,17]  -0.05
 UP BND1      psi[6,17]  0.05
 LO BND1      psi[6,18]  -0.05
 UP BND1      psi[6,18]  0.05
 LO BND1      psi[6,19]  -0.05
 UP BND1      psi[6,19]  0.05
 LO BND1      psi[6,20]  -0.05
 UP BND1      psi[6,20]  0.05
 LO BND1      psi[6,21]  -0.05
 UP BND1      psi[6,21]  0.05
 LO BND1      psi[6,22]  -0.05
 UP BND1      psi[6,22]  0.05
 LO BND1      psi[6,23]  -0.05
 UP BND1      psi[6,23]  0.05
 LO BND1      psi[6,24]  -0.05
 UP BND1      psi[6,24]  0.05
 LO BND1      psi[7,0]  -0.05
 UP BND1      psi[7,0]  0.05
 LO BND1      psi[7,1]  -0.05
 UP BND1      psi[7,1]  0.05
 LO BND1      psi[7,2]  -0.05
 UP BND1      psi[7,2]  0.05
 LO BND1      psi[7,3]  -0.05
 UP BND1      psi[7,3]  0.05
 LO BND1      psi[7,4]  -0.05
 UP BND1      psi[7,4]  0.05
 LO BND1      psi[7,5]  -0.05
 UP BND1      psi[7,5]  0.05
 LO BND1      psi[7,6]  -0.05
 UP BND1      psi[7,6]  0.05
 LO BND1      psi[7,7]  -0.05
 UP BND1      psi[7,7]  0.05
 LO BND1      psi[7,8]  -0.05
 UP BND1      psi[7,8]  0.05
 LO BND1      psi[7,9]  -0.05
 UP BND1      psi[7,9]  0.05
 FX BND1      psi[7,10]  0
 LO BND1      psi[7,11]  -0.05
 UP BND1      psi[7,11]  0.05
 LO BND1      psi[7,12]  -0.05
 UP BND1      psi[7,12]  0.05
 LO BND1      psi[7,13]  -0.05
 UP BND1      psi[7,13]  0.05
 LO BND1      psi[7,14]  -0.05
 UP BND1      psi[7,14]  0.05
 LO BND1      psi[7,15]  -0.05
 UP BND1      psi[7,15]  0.05
 LO BND1      psi[7,16]  -0.05
 UP BND1      psi[7,16]  0.05
 LO BND1      psi[7,17]  -0.05
 UP BND1      psi[7,17]  0.05
 LO BND1      psi[7,18]  -0.05
 UP BND1      psi[7,18]  0.05
 LO BND1      psi[7,19]  -0.05
 UP BND1      psi[7,19]  0.05
 LO BND1      psi[7,20]  -0.05
 UP BND1      psi[7,20]  0.05
 LO BND1      psi[7,21]  -0.05
 UP BND1      psi[7,21]  0.05
 LO BND1      psi[7,22]  -0.05
 UP BND1      psi[7,22]  0.05
 LO BND1      psi[8,0]  -0.05
 UP BND1      psi[8,0]  0.05
 LO BND1      psi[8,1]  -0.05
 UP BND1      psi[8,1]  0.05
 LO BND1      psi[8,2]  -0.05
 UP BND1      psi[8,2]  0.05
 LO BND1      psi[8,3]  -0.05
 UP BND1      psi[8,3]  0.05
 LO BND1      psi[8,4]  -0.05
 UP BND1      psi[8,4]  0.05
 LO BND1      psi[8,5]  -0.05
 UP BND1      psi[8,5]  0.05
 LO BND1      psi[8,6]  -0.05
 UP BND1      psi[8,6]  0.05
 LO BND1      psi[8,7]  -0.05
 UP BND1      psi[8,7]  0.05
 LO BND1      psi[8,8]  -0.05
 UP BND1      psi[8,8]  0.05
 LO BND1      psi[8,9]  -0.05
 UP BND1      psi[8,9]  0.05
 LO BND1      psi[8,10]  -0.05
 UP BND1      psi[8,10]  0.05
 FX BND1      psi[8,11]  0
 LO BND1      psi[8,12]  -0.05
 UP BND1      psi[8,12]  0.05
 LO BND1      psi[8,13]  -0.05
 UP BND1      psi[8,13]  0.05
 LO BND1      psi[8,14]  -0.05
 UP BND1      psi[8,14]  0.05
 LO BND1      psi[8,15]  -0.05
 UP BND1      psi[8,15]  0.05
 LO BND1      psi[8,16]  -0.05
 UP BND1      psi[8,16]  0.05
 LO BND1      psi[8,17]  -0.05
 UP BND1      psi[8,17]  0.05
 LO BND1      psi[8,18]  -0.05
 UP BND1      psi[8,18]  0.05
 LO BND1      psi[8,19]  -0.05
 UP BND1      psi[8,19]  0.05
 LO BND1      psi[8,20]  -0.05
 UP BND1      psi[8,20]  0.05
 LO BND1      psi[8,21]  -0.05
 UP BND1      psi[8,21]  0.05
 LO BND1      psi[9,0]  -0.05
 UP BND1      psi[9,0]  0.05
 LO BND1      psi[9,1]  -0.05
 UP BND1      psi[9,1]  0.05
 LO BND1      psi[9,2]  -0.05
 UP BND1      psi[9,2]  0.05
 LO BND1      psi[9,3]  -0.05
 UP BND1      psi[9,3]  0.05
 LO BND1      psi[9,4]  -0.05
 UP BND1      psi[9,4]  0.05
 LO BND1      psi[9,5]  -0.05
 UP BND1      psi[9,5]  0.05
 LO BND1      psi[9,6]  -0.05
 UP BND1      psi[9,6]  0.05
 LO BND1      psi[9,7]  -0.05
 UP BND1      psi[9,7]  0.05
 LO BND1      psi[9,8]  -0.05
 UP BND1      psi[9,8]  0.05
 FX BND1      psi[9,9]  0
 LO BND1      psi[9,10]  -0.05
 UP BND1      psi[9,10]  0.05
 LO BND1      psi[9,11]  -0.05
 UP BND1      psi[9,11]  0.05
 LO BND1      psi[9,12]  -0.05
 UP BND1      psi[9,12]  0.05
 LO BND1      psi[9,13]  -0.05
 UP BND1      psi[9,13]  0.05
 LO BND1      psi[9,14]  -0.05
 UP BND1      psi[9,14]  0.05
 LO BND1      psi[9,15]  -0.05
 UP BND1      psi[9,15]  0.05
 LO BND1      psi[9,16]  -0.05
 UP BND1      psi[9,16]  0.05
 LO BND1      psi[9,17]  -0.05
 UP BND1      psi[9,17]  0.05
 LO BND1      psi[9,18]  -0.05
 UP BND1      psi[9,18]  0.05
 LO BND1      psi[9,19]  -0.05
 UP BND1      psi[9,19]  0.05
 LO BND1      psi[10,0]  -0.05
 UP BND1      psi[10,0]  0.05
 LO BND1      psi[10,1]  -0.05
 UP BND1      psi[10,1]  0.05
 LO BND1      psi[10,2]  -0.05
 UP BND1      psi[10,2]  0.05
 LO BND1      psi[10,3]  -0.05
 UP BND1      psi[10,3]  0.05
 LO BND1      psi[10,4]  -0.05
 UP BND1      psi[10,4]  0.05
 LO BND1      psi[10,5]  -0.05
 UP BND1      psi[10,5]  0.05
 LO BND1      psi[10,6]  -0.05
 UP BND1      psi[10,6]  0.05
 LO BND1      psi[10,7]  -0.05
 UP BND1      psi[10,7]  0.05
 LO BND1      psi[10,8]  -0.05
 UP BND1      psi[10,8]  0.05
 LO BND1      psi[10,9]  -0.05
 UP BND1      psi[10,9]  0.05
 LO BND1      psi[10,10]  -0.05
 UP BND1      psi[10,10]  0.05
 LO BND1      psi[10,11]  -0.05
 UP BND1      psi[10,11]  0.05
 LO BND1      psi[10,12]  -0.05
 UP BND1      psi[10,12]  0.05
 LO BND1      psi[10,13]  -0.05
 UP BND1      psi[10,13]  0.05
 LO BND1      psi[10,14]  -0.05
 UP BND1      psi[10,14]  0.05
 LO BND1      psi[10,15]  -0.05
 UP BND1      psi[10,15]  0.05
 FX BND1      psi[10,16]  0
 LO BND1      psi[10,17]  -0.05
 UP BND1      psi[10,17]  0.05
 LO BND1      psi[10,18]  -0.05
 UP BND1      psi[10,18]  0.05
 LO BND1      psi[10,19]  -0.05
 UP BND1      psi[10,19]  0.05
 LO BND1      psi[10,20]  -0.05
 UP BND1      psi[10,20]  0.05
 LO BND1      psi[10,21]  -0.05
 UP BND1      psi[10,21]  0.05
 LO BND1      psi[10,22]  -0.05
 UP BND1      psi[10,22]  0.05
 LO BND1      psi[10,23]  -0.05
 UP BND1      psi[10,23]  0.05
 LO BND1      psi[10,24]  -0.05
 UP BND1      psi[10,24]  0.05
 LO BND1      psi[10,25]  -0.05
 UP BND1      psi[10,25]  0.05
 LO BND1      psi[10,26]  -0.05
 UP BND1      psi[10,26]  0.05
 LO BND1      psi[10,27]  -0.05
 UP BND1      psi[10,27]  0.05
 LO BND1      psi[10,28]  -0.05
 UP BND1      psi[10,28]  0.05
 LO BND1      psi[10,29]  -0.05
 UP BND1      psi[10,29]  0.05
 LO BND1      psi[11,0]  -0.05
 UP BND1      psi[11,0]  0.05
 LO BND1      psi[11,1]  -0.05
 UP BND1      psi[11,1]  0.05
 LO BND1      psi[11,2]  -0.05
 UP BND1      psi[11,2]  0.05
 LO BND1      psi[11,3]  -0.05
 UP BND1      psi[11,3]  0.05
 LO BND1      psi[11,4]  -0.05
 UP BND1      psi[11,4]  0.05
 LO BND1      psi[11,5]  -0.05
 UP BND1      psi[11,5]  0.05
 LO BND1      psi[11,6]  -0.05
 UP BND1      psi[11,6]  0.05
 LO BND1      psi[11,7]  -0.05
 UP BND1      psi[11,7]  0.05
 LO BND1      psi[11,8]  -0.05
 UP BND1      psi[11,8]  0.05
 LO BND1      psi[11,9]  -0.05
 UP BND1      psi[11,9]  0.05
 LO BND1      psi[11,10]  -0.05
 UP BND1      psi[11,10]  0.05
 LO BND1      psi[11,11]  -0.05
 UP BND1      psi[11,11]  0.05
 LO BND1      psi[11,12]  -0.05
 UP BND1      psi[11,12]  0.05
 LO BND1      psi[11,13]  -0.05
 UP BND1      psi[11,13]  0.05
 LO BND1      psi[11,14]  -0.05
 UP BND1      psi[11,14]  0.05
 LO BND1      psi[11,15]  -0.05
 UP BND1      psi[11,15]  0.05
 LO BND1      psi[11,16]  -0.05
 UP BND1      psi[11,16]  0.05
 FX BND1      psi[11,17]  0
 LO BND1      psi[11,18]  -0.05
 UP BND1      psi[11,18]  0.05
 LO BND1      psi[11,19]  -0.05
 UP BND1      psi[11,19]  0.05
 LO BND1      psi[11,20]  -0.05
 UP BND1      psi[11,20]  0.05
 LO BND1      psi[11,21]  -0.05
 UP BND1      psi[11,21]  0.05
 LO BND1      psi[11,22]  -0.05
 UP BND1      psi[11,22]  0.05
 LO BND1      psi[11,23]  -0.05
 UP BND1      psi[11,23]  0.05
 LO BND1      psi[11,24]  -0.05
 UP BND1      psi[11,24]  0.05
 LO BND1      psi[11,25]  -0.05
 UP BND1      psi[11,25]  0.05
 LO BND1      psi[11,26]  -0.05
 UP BND1      psi[11,26]  0.05
 LO BND1      psi[11,27]  -0.05
 UP BND1      psi[11,27]  0.05
 LO BND1      psi[11,28]  -0.05
 UP BND1      psi[11,28]  0.05
 LO BND1      psi[11,29]  -0.05
 UP BND1      psi[11,29]  0.05
 LO BND1      psi[11,30]  -0.05
 UP BND1      psi[11,30]  0.05
 LO BND1      psi[11,31]  -0.05
 UP BND1      psi[11,31]  0.05
 LO BND1      psi[12,0]  -0.05
 UP BND1      psi[12,0]  0.05
 LO BND1      psi[12,1]  -0.05
 UP BND1      psi[12,1]  0.05
 LO BND1      psi[12,2]  -0.05
 UP BND1      psi[12,2]  0.05
 LO BND1      psi[12,3]  -0.05
 UP BND1      psi[12,3]  0.05
 LO BND1      psi[12,4]  -0.05
 UP BND1      psi[12,4]  0.05
 LO BND1      psi[12,5]  -0.05
 UP BND1      psi[12,5]  0.05
 LO BND1      psi[12,6]  -0.05
 UP BND1      psi[12,6]  0.05
 LO BND1      psi[12,7]  -0.05
 UP BND1      psi[12,7]  0.05
 LO BND1      psi[12,8]  -0.05
 UP BND1      psi[12,8]  0.05
 LO BND1      psi[12,9]  -0.05
 UP BND1      psi[12,9]  0.05
 FX BND1      psi[12,10]  0
 LO BND1      psi[12,11]  -0.05
 UP BND1      psi[12,11]  0.05
 LO BND1      psi[12,12]  -0.05
 UP BND1      psi[12,12]  0.05
 LO BND1      psi[12,13]  -0.05
 UP BND1      psi[12,13]  0.05
 LO BND1      psi[12,14]  -0.05
 UP BND1      psi[12,14]  0.05
 LO BND1      psi[12,15]  -0.05
 UP BND1      psi[12,15]  0.05
 LO BND1      psi[12,16]  -0.05
 UP BND1      psi[12,16]  0.05
 LO BND1      psi[12,17]  -0.05
 UP BND1      psi[12,17]  0.05
 LO BND1      psi[12,18]  -0.05
 UP BND1      psi[12,18]  0.05
 LO BND1      psi[12,19]  -0.05
 UP BND1      psi[12,19]  0.05
 LO BND1      psi[13,0]  -0.05
 UP BND1      psi[13,0]  0.05
 LO BND1      psi[13,1]  -0.05
 UP BND1      psi[13,1]  0.05
 LO BND1      psi[13,2]  -0.05
 UP BND1      psi[13,2]  0.05
 LO BND1      psi[13,3]  -0.05
 UP BND1      psi[13,3]  0.05
 LO BND1      psi[13,4]  -0.05
 UP BND1      psi[13,4]  0.05
 LO BND1      psi[13,5]  -0.05
 UP BND1      psi[13,5]  0.05
 LO BND1      psi[13,6]  -0.05
 UP BND1      psi[13,6]  0.05
 LO BND1      psi[13,7]  -0.05
 UP BND1      psi[13,7]  0.05
 LO BND1      psi[13,8]  -0.05
 UP BND1      psi[13,8]  0.05
 LO BND1      psi[13,9]  -0.05
 UP BND1      psi[13,9]  0.05
 LO BND1      psi[13,10]  -0.05
 UP BND1      psi[13,10]  0.05
 LO BND1      psi[13,11]  -0.05
 UP BND1      psi[13,11]  0.05
 LO BND1      psi[13,12]  -0.05
 UP BND1      psi[13,12]  0.05
 FX BND1      psi[13,13]  0
 LO BND1      psi[13,14]  -0.05
 UP BND1      psi[13,14]  0.05
 LO BND1      psi[13,15]  -0.05
 UP BND1      psi[13,15]  0.05
 LO BND1      psi[13,16]  -0.05
 UP BND1      psi[13,16]  0.05
 LO BND1      psi[13,17]  -0.05
 UP BND1      psi[13,17]  0.05
 LO BND1      psi[13,18]  -0.05
 UP BND1      psi[13,18]  0.05
 LO BND1      psi[13,19]  -0.05
 UP BND1      psi[13,19]  0.05
 LO BND1      psi[13,20]  -0.05
 UP BND1      psi[13,20]  0.05
 LO BND1      psi[13,21]  -0.05
 UP BND1      psi[13,21]  0.05
 LO BND1      psi[13,22]  -0.05
 UP BND1      psi[13,22]  0.05
 LO BND1      psi[13,23]  -0.05
 UP BND1      psi[13,23]  0.05
 LO BND1      psi[13,24]  -0.05
 UP BND1      psi[13,24]  0.05
 LO BND1      psi[13,25]  -0.05
 UP BND1      psi[13,25]  0.05
 LO BND1      psi[14,0]  -0.05
 UP BND1      psi[14,0]  0.05
 LO BND1      psi[14,1]  -0.05
 UP BND1      psi[14,1]  0.05
 LO BND1      psi[14,2]  -0.05
 UP BND1      psi[14,2]  0.05
 LO BND1      psi[14,3]  -0.05
 UP BND1      psi[14,3]  0.05
 LO BND1      psi[14,4]  -0.05
 UP BND1      psi[14,4]  0.05
 LO BND1      psi[14,5]  -0.05
 UP BND1      psi[14,5]  0.05
 LO BND1      psi[14,6]  -0.05
 UP BND1      psi[14,6]  0.05
 LO BND1      psi[14,7]  -0.05
 UP BND1      psi[14,7]  0.05
 LO BND1      psi[14,8]  -0.05
 UP BND1      psi[14,8]  0.05
 LO BND1      psi[14,9]  -0.05
 UP BND1      psi[14,9]  0.05
 LO BND1      psi[14,10]  -0.05
 UP BND1      psi[14,10]  0.05
 LO BND1      psi[14,11]  -0.05
 UP BND1      psi[14,11]  0.05
 LO BND1      psi[14,12]  -0.05
 UP BND1      psi[14,12]  0.05
 FX BND1      psi[14,13]  0
 LO BND1      psi[14,14]  -0.05
 UP BND1      psi[14,14]  0.05
 LO BND1      psi[14,15]  -0.05
 UP BND1      psi[14,15]  0.05
 LO BND1      psi[14,16]  -0.05
 UP BND1      psi[14,16]  0.05
 LO BND1      psi[14,17]  -0.05
 UP BND1      psi[14,17]  0.05
 LO BND1      psi[14,18]  -0.05
 UP BND1      psi[14,18]  0.05
 LO BND1      psi[14,19]  -0.05
 UP BND1      psi[14,19]  0.05
 LO BND1      psi[14,20]  -0.05
 UP BND1      psi[14,20]  0.05
 LO BND1      psi[14,21]  -0.05
 UP BND1      psi[14,21]  0.05
 LO BND1      psi[14,22]  -0.05
 UP BND1      psi[14,22]  0.05
 LO BND1      psi[14,23]  -0.05
 UP BND1      psi[14,23]  0.05
 LO BND1      psi[15,0]  -0.05
 UP BND1      psi[15,0]  0.05
 LO BND1      psi[15,1]  -0.05
 UP BND1      psi[15,1]  0.05
 LO BND1      psi[15,2]  -0.05
 UP BND1      psi[15,2]  0.05
 LO BND1      psi[15,3]  -0.05
 UP BND1      psi[15,3]  0.05
 LO BND1      psi[15,4]  -0.05
 UP BND1      psi[15,4]  0.05
 LO BND1      psi[15,5]  -0.05
 UP BND1      psi[15,5]  0.05
 LO BND1      psi[15,6]  -0.05
 UP BND1      psi[15,6]  0.05
 LO BND1      psi[15,7]  -0.05
 UP BND1      psi[15,7]  0.05
 LO BND1      psi[15,8]  -0.05
 UP BND1      psi[15,8]  0.05
 LO BND1      psi[15,9]  -0.05
 UP BND1      psi[15,9]  0.05
 LO BND1      psi[15,10]  -0.05
 UP BND1      psi[15,10]  0.05
 LO BND1      psi[15,11]  -0.05
 UP BND1      psi[15,11]  0.05
 LO BND1      psi[15,12]  -0.05
 UP BND1      psi[15,12]  0.05
 LO BND1      psi[15,13]  -0.05
 UP BND1      psi[15,13]  0.05
 FX BND1      psi[15,14]  0
 LO BND1      psi[15,15]  -0.05
 UP BND1      psi[15,15]  0.05
 LO BND1      psi[15,16]  -0.05
 UP BND1      psi[15,16]  0.05
 LO BND1      psi[15,17]  -0.05
 UP BND1      psi[15,17]  0.05
 LO BND1      psi[15,18]  -0.05
 UP BND1      psi[15,18]  0.05
 LO BND1      psi[15,19]  -0.05
 UP BND1      psi[15,19]  0.05
 LO BND1      psi[15,20]  -0.05
 UP BND1      psi[15,20]  0.05
 LO BND1      psi[15,21]  -0.05
 UP BND1      psi[15,21]  0.05
 LO BND1      psi[15,22]  -0.05
 UP BND1      psi[15,22]  0.05
 LO BND1      psi[15,23]  -0.05
 UP BND1      psi[15,23]  0.05
 LO BND1      psi[15,24]  -0.05
 UP BND1      psi[15,24]  0.05
 LO BND1      psi[15,25]  -0.05
 UP BND1      psi[15,25]  0.05
 LO BND1      psi[15,26]  -0.05
 UP BND1      psi[15,26]  0.05
 LO BND1      psi[15,27]  -0.05
 UP BND1      psi[15,27]  0.05
 LO BND1      psi[16,0]  -0.05
 UP BND1      psi[16,0]  0.05
 LO BND1      psi[16,1]  -0.05
 UP BND1      psi[16,1]  0.05
 LO BND1      psi[16,2]  -0.05
 UP BND1      psi[16,2]  0.05
 LO BND1      psi[16,3]  -0.05
 UP BND1      psi[16,3]  0.05
 LO BND1      psi[16,4]  -0.05
 UP BND1      psi[16,4]  0.05
 LO BND1      psi[16,5]  -0.05
 UP BND1      psi[16,5]  0.05
 LO BND1      psi[16,6]  -0.05
 UP BND1      psi[16,6]  0.05
 LO BND1      psi[16,7]  -0.05
 UP BND1      psi[16,7]  0.05
 LO BND1      psi[16,8]  -0.05
 UP BND1      psi[16,8]  0.05
 LO BND1      psi[16,9]  -0.05
 UP BND1      psi[16,9]  0.05
 LO BND1      psi[16,10]  -0.05
 UP BND1      psi[16,10]  0.05
 LO BND1      psi[16,11]  -0.05
 UP BND1      psi[16,11]  0.05
 FX BND1      psi[16,12]  0
 LO BND1      psi[16,13]  -0.05
 UP BND1      psi[16,13]  0.05
 LO BND1      psi[16,14]  -0.05
 UP BND1      psi[16,14]  0.05
 LO BND1      psi[16,15]  -0.05
 UP BND1      psi[16,15]  0.05
 LO BND1      psi[16,16]  -0.05
 UP BND1      psi[16,16]  0.05
 LO BND1      psi[16,17]  -0.05
 UP BND1      psi[16,17]  0.05
 LO BND1      psi[16,18]  -0.05
 UP BND1      psi[16,18]  0.05
 LO BND1      psi[16,19]  -0.05
 UP BND1      psi[16,19]  0.05
 LO BND1      psi[16,20]  -0.05
 UP BND1      psi[16,20]  0.05
 LO BND1      psi[16,21]  -0.05
 UP BND1      psi[16,21]  0.05
 LO BND1      psi[16,22]  -0.05
 UP BND1      psi[16,22]  0.05
 LO BND1      psi[17,0]  -0.05
 UP BND1      psi[17,0]  0.05
 LO BND1      psi[17,1]  -0.05
 UP BND1      psi[17,1]  0.05
 LO BND1      psi[17,2]  -0.05
 UP BND1      psi[17,2]  0.05
 LO BND1      psi[17,3]  -0.05
 UP BND1      psi[17,3]  0.05
 LO BND1      psi[17,4]  -0.05
 UP BND1      psi[17,4]  0.05
 LO BND1      psi[17,5]  -0.05
 UP BND1      psi[17,5]  0.05
 LO BND1      psi[17,6]  -0.05
 UP BND1      psi[17,6]  0.05
 LO BND1      psi[17,7]  -0.05
 UP BND1      psi[17,7]  0.05
 FX BND1      psi[17,8]  0
 LO BND1      psi[17,9]  -0.05
 UP BND1      psi[17,9]  0.05
 LO BND1      psi[17,10]  -0.05
 UP BND1      psi[17,10]  0.05
 LO BND1      psi[17,11]  -0.05
 UP BND1      psi[17,11]  0.05
 LO BND1      psi[17,12]  -0.05
 UP BND1      psi[17,12]  0.05
 LO BND1      psi[17,13]  -0.05
 UP BND1      psi[17,13]  0.05
 LO BND1      psi[17,14]  -0.05
 UP BND1      psi[17,14]  0.05
 LO BND1      psi[17,15]  -0.05
 UP BND1      psi[17,15]  0.05
 LO BND1      psi[17,16]  -0.05
 UP BND1      psi[17,16]  0.05
 LO BND1      psi[17,17]  -0.05
 UP BND1      psi[17,17]  0.05
 LO BND1      psi[17,18]  -0.05
 UP BND1      psi[17,18]  0.05
 LO BND1      psi[17,19]  -0.05
 UP BND1      psi[17,19]  0.05
 LO BND1      psi[18,0]  -0.05
 UP BND1      psi[18,0]  0.05
 LO BND1      psi[18,1]  -0.05
 UP BND1      psi[18,1]  0.05
 LO BND1      psi[18,2]  -0.05
 UP BND1      psi[18,2]  0.05
 LO BND1      psi[18,3]  -0.05
 UP BND1      psi[18,3]  0.05
 LO BND1      psi[18,4]  -0.05
 UP BND1      psi[18,4]  0.05
 LO BND1      psi[18,5]  -0.05
 UP BND1      psi[18,5]  0.05
 LO BND1      psi[18,6]  -0.05
 UP BND1      psi[18,6]  0.05
 LO BND1      psi[18,7]  -0.05
 UP BND1      psi[18,7]  0.05
 LO BND1      psi[18,8]  -0.05
 UP BND1      psi[18,8]  0.05
 LO BND1      psi[18,9]  -0.05
 UP BND1      psi[18,9]  0.05
 LO BND1      psi[18,10]  -0.05
 UP BND1      psi[18,10]  0.05
 FX BND1      psi[18,11]  0
 LO BND1      psi[18,12]  -0.05
 UP BND1      psi[18,12]  0.05
 LO BND1      psi[18,13]  -0.05
 UP BND1      psi[18,13]  0.05
 LO BND1      psi[18,14]  -0.05
 UP BND1      psi[18,14]  0.05
 LO BND1      psi[18,15]  -0.05
 UP BND1      psi[18,15]  0.05
 LO BND1      psi[18,16]  -0.05
 UP BND1      psi[18,16]  0.05
 LO BND1      psi[18,17]  -0.05
 UP BND1      psi[18,17]  0.05
 LO BND1      psi[18,18]  -0.05
 UP BND1      psi[18,18]  0.05
 LO BND1      psi[18,19]  -0.05
 UP BND1      psi[18,19]  0.05
 LO BND1      psi[18,20]  -0.05
 UP BND1      psi[18,20]  0.05
 LO BND1      psi[18,21]  -0.05
 UP BND1      psi[18,21]  0.05
 LO BND1      psi[18,22]  -0.05
 UP BND1      psi[18,22]  0.05
 LO BND1      psi[19,0]  -0.05
 UP BND1      psi[19,0]  0.05
 LO BND1      psi[19,1]  -0.05
 UP BND1      psi[19,1]  0.05
 LO BND1      psi[19,2]  -0.05
 UP BND1      psi[19,2]  0.05
 LO BND1      psi[19,3]  -0.05
 UP BND1      psi[19,3]  0.05
 LO BND1      psi[19,4]  -0.05
 UP BND1      psi[19,4]  0.05
 LO BND1      psi[19,5]  -0.05
 UP BND1      psi[19,5]  0.05
 LO BND1      psi[19,6]  -0.05
 UP BND1      psi[19,6]  0.05
 LO BND1      psi[19,7]  -0.05
 UP BND1      psi[19,7]  0.05
 LO BND1      psi[19,8]  -0.05
 UP BND1      psi[19,8]  0.05
 LO BND1      psi[19,9]  -0.05
 UP BND1      psi[19,9]  0.05
 LO BND1      psi[19,10]  -0.05
 UP BND1      psi[19,10]  0.05
 LO BND1      psi[19,11]  -0.05
 UP BND1      psi[19,11]  0.05
 FX BND1      psi[19,12]  0
 LO BND1      psi[19,13]  -0.05
 UP BND1      psi[19,13]  0.05
 LO BND1      psi[19,14]  -0.05
 UP BND1      psi[19,14]  0.05
 LO BND1      psi[19,15]  -0.05
 UP BND1      psi[19,15]  0.05
 LO BND1      psi[19,16]  -0.05
 UP BND1      psi[19,16]  0.05
 LO BND1      psi[19,17]  -0.05
 UP BND1      psi[19,17]  0.05
 LO BND1      psi[19,18]  -0.05
 UP BND1      psi[19,18]  0.05
 LO BND1      psi[19,19]  -0.05
 UP BND1      psi[19,19]  0.05
 LO BND1      psi[19,20]  -0.05
 UP BND1      psi[19,20]  0.05
 LO BND1      psi[19,21]  -0.05
 UP BND1      psi[19,21]  0.05
 LO BND1      psi[19,22]  -0.05
 UP BND1      psi[19,22]  0.05
 LO BND1      psi[19,23]  -0.05
 UP BND1      psi[19,23]  0.05
 LO BND1      psi[20,0]  -0.05
 UP BND1      psi[20,0]  0.05
 LO BND1      psi[20,1]  -0.05
 UP BND1      psi[20,1]  0.05
 LO BND1      psi[20,2]  -0.05
 UP BND1      psi[20,2]  0.05
 LO BND1      psi[20,3]  -0.05
 UP BND1      psi[20,3]  0.05
 LO BND1      psi[20,4]  -0.05
 UP BND1      psi[20,4]  0.05
 LO BND1      psi[20,5]  -0.05
 UP BND1      psi[20,5]  0.05
 LO BND1      psi[20,6]  -0.05
 UP BND1      psi[20,6]  0.05
 LO BND1      psi[20,7]  -0.05
 UP BND1      psi[20,7]  0.05
 LO BND1      psi[20,8]  -0.05
 UP BND1      psi[20,8]  0.05
 LO BND1      psi[20,9]  -0.05
 UP BND1      psi[20,9]  0.05
 LO BND1      psi[20,10]  -0.05
 UP BND1      psi[20,10]  0.05
 LO BND1      psi[20,11]  -0.05
 UP BND1      psi[20,11]  0.05
 LO BND1      psi[20,12]  -0.05
 UP BND1      psi[20,12]  0.05
 FX BND1      psi[20,13]  0
 LO BND1      psi[20,14]  -0.05
 UP BND1      psi[20,14]  0.05
 LO BND1      psi[20,15]  -0.05
 UP BND1      psi[20,15]  0.05
 LO BND1      psi[20,16]  -0.05
 UP BND1      psi[20,16]  0.05
 LO BND1      psi[20,17]  -0.05
 UP BND1      psi[20,17]  0.05
 LO BND1      psi[20,18]  -0.05
 UP BND1      psi[20,18]  0.05
 LO BND1      psi[20,19]  -0.05
 UP BND1      psi[20,19]  0.05
 LO BND1      psi[20,20]  -0.05
 UP BND1      psi[20,20]  0.05
 LO BND1      psi[20,21]  -0.05
 UP BND1      psi[20,21]  0.05
 LO BND1      psi[20,22]  -0.05
 UP BND1      psi[20,22]  0.05
 LO BND1      psi[20,23]  -0.05
 UP BND1      psi[20,23]  0.05
 FR BND1      a       
ENDATA
