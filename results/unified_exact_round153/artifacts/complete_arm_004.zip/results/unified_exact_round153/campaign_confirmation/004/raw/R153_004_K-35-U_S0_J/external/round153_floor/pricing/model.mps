* Signature: 0x7bc06f78d8560c21
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  mass_1  
 G  w_lb_1_4
 L  w_ub_1_4
 E  normalized_inventory_1
 E  normalized_ratio_1
 E  onehot_2
 E  mass_2  
 G  w_lb_2_0
 L  w_ub_2_0
 G  w_lb_2_1
 L  w_ub_2_1
 G  w_lb_2_2
 L  w_ub_2_2
 G  w_lb_2_3
 L  w_ub_2_3
 G  w_lb_2_4
 L  w_ub_2_4
 G  w_lb_2_5
 L  w_ub_2_5
 G  w_lb_2_6
 L  w_ub_2_6
 G  w_lb_2_7
 L  w_ub_2_7
 G  w_lb_2_8
 L  w_ub_2_8
 G  w_lb_2_9
 L  w_ub_2_9
 G  w_lb_2_10
 L  w_ub_2_10
 G  w_lb_2_11
 L  w_ub_2_11
 G  w_lb_2_12
 L  w_ub_2_12
 G  w_lb_2_13
 L  w_ub_2_13
 G  w_lb_2_14
 L  w_ub_2_14
 G  w_lb_2_15
 L  w_ub_2_15
 G  w_lb_2_16
 L  w_ub_2_16
 G  w_lb_2_17
 L  w_ub_2_17
 G  w_lb_2_18
 L  w_ub_2_18
 G  w_lb_2_19
 L  w_ub_2_19
 G  w_lb_2_20
 L  w_ub_2_20
 G  w_lb_2_21
 L  w_ub_2_21
 G  w_lb_2_22
 L  w_ub_2_22
 G  w_lb_2_23
 L  w_ub_2_23
 E  normalized_inventory_2
 E  normalized_ratio_2
 E  onehot_3
 E  mass_3  
 G  w_lb_3_13
 L  w_ub_3_13
 E  normalized_inventory_3
 E  normalized_ratio_3
 E  onehot_4
 E  mass_4  
 G  w_lb_4_0
 L  w_ub_4_0
 G  w_lb_4_1
 L  w_ub_4_1
 G  w_lb_4_2
 L  w_ub_4_2
 G  w_lb_4_3
 L  w_ub_4_3
 G  w_lb_4_4
 L  w_ub_4_4
 G  w_lb_4_5
 L  w_ub_4_5
 G  w_lb_4_6
 L  w_ub_4_6
 G  w_lb_4_7
 L  w_ub_4_7
 G  w_lb_4_8
 L  w_ub_4_8
 G  w_lb_4_9
 L  w_ub_4_9
 G  w_lb_4_10
 L  w_ub_4_10
 G  w_lb_4_11
 L  w_ub_4_11
 G  w_lb_4_12
 L  w_ub_4_12
 G  w_lb_4_13
 L  w_ub_4_13
 G  w_lb_4_14
 L  w_ub_4_14
 G  w_lb_4_15
 L  w_ub_4_15
 E  normalized_inventory_4
 E  normalized_ratio_4
 E  onehot_5
 E  mass_5  
 G  w_lb_5_0
 L  w_ub_5_0
 G  w_lb_5_1
 L  w_ub_5_1
 G  w_lb_5_2
 L  w_ub_5_2
 G  w_lb_5_3
 L  w_ub_5_3
 G  w_lb_5_4
 L  w_ub_5_4
 G  w_lb_5_5
 L  w_ub_5_5
 G  w_lb_5_6
 L  w_ub_5_6
 G  w_lb_5_7
 L  w_ub_5_7
 G  w_lb_5_8
 L  w_ub_5_8
 G  w_lb_5_9
 L  w_ub_5_9
 G  w_lb_5_10
 L  w_ub_5_10
 G  w_lb_5_11
 L  w_ub_5_11
 G  w_lb_5_12
 L  w_ub_5_12
 G  w_lb_5_13
 L  w_ub_5_13
 G  w_lb_5_14
 L  w_ub_5_14
 G  w_lb_5_15
 L  w_ub_5_15
 E  normalized_inventory_5
 E  normalized_ratio_5
 E  onehot_6
 E  mass_6  
 G  w_lb_6_4
 L  w_ub_6_4
 E  normalized_inventory_6
 E  normalized_ratio_6
 E  onehot_7
 E  mass_7  
 G  w_lb_7_0
 L  w_ub_7_0
 G  w_lb_7_1
 L  w_ub_7_1
 G  w_lb_7_2
 L  w_ub_7_2
 G  w_lb_7_3
 L  w_ub_7_3
 G  w_lb_7_4
 L  w_ub_7_4
 G  w_lb_7_5
 L  w_ub_7_5
 G  w_lb_7_6
 L  w_ub_7_6
 G  w_lb_7_7
 L  w_ub_7_7
 G  w_lb_7_8
 L  w_ub_7_8
 G  w_lb_7_9
 L  w_ub_7_9
 G  w_lb_7_10
 L  w_ub_7_10
 G  w_lb_7_11
 L  w_ub_7_11
 G  w_lb_7_12
 L  w_ub_7_12
 G  w_lb_7_13
 L  w_ub_7_13
 G  w_lb_7_14
 L  w_ub_7_14
 G  w_lb_7_15
 L  w_ub_7_15
 G  w_lb_7_16
 L  w_ub_7_16
 G  w_lb_7_17
 L  w_ub_7_17
 G  w_lb_7_18
 L  w_ub_7_18
 G  w_lb_7_19
 L  w_ub_7_19
 E  normalized_inventory_7
 E  normalized_ratio_7
 E  onehot_8
 E  mass_8  
 G  w_lb_8_0
 L  w_ub_8_0
 G  w_lb_8_1
 L  w_ub_8_1
 G  w_lb_8_2
 L  w_ub_8_2
 G  w_lb_8_3
 L  w_ub_8_3
 G  w_lb_8_4
 L  w_ub_8_4
 G  w_lb_8_5
 L  w_ub_8_5
 G  w_lb_8_6
 L  w_ub_8_6
 G  w_lb_8_7
 L  w_ub_8_7
 G  w_lb_8_8
 L  w_ub_8_8
 G  w_lb_8_9
 L  w_ub_8_9
 G  w_lb_8_10
 L  w_ub_8_10
 G  w_lb_8_11
 L  w_ub_8_11
 G  w_lb_8_12
 L  w_ub_8_12
 G  w_lb_8_13
 L  w_ub_8_13
 G  w_lb_8_14
 L  w_ub_8_14
 G  w_lb_8_15
 L  w_ub_8_15
 E  normalized_inventory_8
 E  normalized_ratio_8
 E  onehot_9
 E  mass_9  
 G  w_lb_9_0
 L  w_ub_9_0
 G  w_lb_9_1
 L  w_ub_9_1
 G  w_lb_9_2
 L  w_ub_9_2
 G  w_lb_9_3
 L  w_ub_9_3
 G  w_lb_9_4
 L  w_ub_9_4
 G  w_lb_9_5
 L  w_ub_9_5
 G  w_lb_9_6
 L  w_ub_9_6
 G  w_lb_9_7
 L  w_ub_9_7
 G  w_lb_9_8
 L  w_ub_9_8
 G  w_lb_9_9
 L  w_ub_9_9
 G  w_lb_9_10
 L  w_ub_9_10
 G  w_lb_9_11
 L  w_ub_9_11
 G  w_lb_9_12
 L  w_ub_9_12
 G  w_lb_9_13
 L  w_ub_9_13
 G  w_lb_9_14
 L  w_ub_9_14
 E  normalized_inventory_9
 E  normalized_ratio_9
 E  onehot_10
 E  mass_10 
 G  w_lb_10_0
 L  w_ub_10_0
 G  w_lb_10_1
 L  w_ub_10_1
 G  w_lb_10_2
 L  w_ub_10_2
 G  w_lb_10_3
 L  w_ub_10_3
 G  w_lb_10_4
 L  w_ub_10_4
 G  w_lb_10_5
 L  w_ub_10_5
 G  w_lb_10_6
 L  w_ub_10_6
 G  w_lb_10_7
 L  w_ub_10_7
 G  w_lb_10_8
 L  w_ub_10_8
 G  w_lb_10_9
 L  w_ub_10_9
 G  w_lb_10_10
 L  w_ub_10_10
 G  w_lb_10_11
 L  w_ub_10_11
 E  normalized_inventory_10
 E  normalized_ratio_10
 E  onehot_11
 E  mass_11 
 G  w_lb_11_0
 L  w_ub_11_0
 G  w_lb_11_1
 L  w_ub_11_1
 G  w_lb_11_2
 L  w_ub_11_2
 G  w_lb_11_3
 L  w_ub_11_3
 G  w_lb_11_4
 L  w_ub_11_4
 G  w_lb_11_5
 L  w_ub_11_5
 G  w_lb_11_6
 L  w_ub_11_6
 G  w_lb_11_7
 L  w_ub_11_7
 G  w_lb_11_8
 L  w_ub_11_8
 G  w_lb_11_9
 L  w_ub_11_9
 G  w_lb_11_10
 L  w_ub_11_10
 G  w_lb_11_11
 L  w_ub_11_11
 G  w_lb_11_12
 L  w_ub_11_12
 G  w_lb_11_13
 L  w_ub_11_13
 G  w_lb_11_14
 L  w_ub_11_14
 G  w_lb_11_15
 L  w_ub_11_15
 E  normalized_inventory_11
 E  normalized_ratio_11
 E  onehot_12
 E  mass_12 
 G  w_lb_12_0
 L  w_ub_12_0
 G  w_lb_12_1
 L  w_ub_12_1
 G  w_lb_12_2
 L  w_ub_12_2
 G  w_lb_12_3
 L  w_ub_12_3
 G  w_lb_12_4
 L  w_ub_12_4
 G  w_lb_12_5
 L  w_ub_12_5
 G  w_lb_12_6
 L  w_ub_12_6
 G  w_lb_12_7
 L  w_ub_12_7
 G  w_lb_12_8
 L  w_ub_12_8
 G  w_lb_12_9
 L  w_ub_12_9
 G  w_lb_12_10
 L  w_ub_12_10
 G  w_lb_12_11
 L  w_ub_12_11
 G  w_lb_12_12
 L  w_ub_12_12
 G  w_lb_12_13
 L  w_ub_12_13
 G  w_lb_12_14
 L  w_ub_12_14
 G  w_lb_12_15
 L  w_ub_12_15
 E  normalized_inventory_12
 E  normalized_ratio_12
 E  onehot_13
 E  mass_13 
 G  w_lb_13_0
 L  w_ub_13_0
 G  w_lb_13_1
 L  w_ub_13_1
 G  w_lb_13_2
 L  w_ub_13_2
 G  w_lb_13_3
 L  w_ub_13_3
 G  w_lb_13_4
 L  w_ub_13_4
 G  w_lb_13_5
 L  w_ub_13_5
 G  w_lb_13_6
 L  w_ub_13_6
 G  w_lb_13_7
 L  w_ub_13_7
 G  w_lb_13_8
 L  w_ub_13_8
 G  w_lb_13_9
 L  w_ub_13_9
 G  w_lb_13_10
 L  w_ub_13_10
 G  w_lb_13_11
 L  w_ub_13_11
 G  w_lb_13_12
 L  w_ub_13_12
 G  w_lb_13_13
 L  w_ub_13_13
 G  w_lb_13_14
 L  w_ub_13_14
 G  w_lb_13_15
 L  w_ub_13_15
 G  w_lb_13_16
 L  w_ub_13_16
 G  w_lb_13_17
 L  w_ub_13_17
 G  w_lb_13_18
 L  w_ub_13_18
 G  w_lb_13_19
 L  w_ub_13_19
 E  normalized_inventory_13
 E  normalized_ratio_13
 E  onehot_14
 E  mass_14 
 G  w_lb_14_0
 L  w_ub_14_0
 G  w_lb_14_1
 L  w_ub_14_1
 G  w_lb_14_2
 L  w_ub_14_2
 G  w_lb_14_3
 L  w_ub_14_3
 G  w_lb_14_4
 L  w_ub_14_4
 G  w_lb_14_5
 L  w_ub_14_5
 G  w_lb_14_6
 L  w_ub_14_6
 G  w_lb_14_7
 L  w_ub_14_7
 G  w_lb_14_8
 L  w_ub_14_8
 G  w_lb_14_9
 L  w_ub_14_9
 G  w_lb_14_10
 L  w_ub_14_10
 G  w_lb_14_11
 L  w_ub_14_11
 G  w_lb_14_12
 L  w_ub_14_12
 G  w_lb_14_13
 L  w_ub_14_13
 G  w_lb_14_14
 L  w_ub_14_14
 G  w_lb_14_15
 L  w_ub_14_15
 G  w_lb_14_16
 L  w_ub_14_16
 G  w_lb_14_17
 L  w_ub_14_17
 G  w_lb_14_18
 L  w_ub_14_18
 E  normalized_inventory_14
 E  normalized_ratio_14
 E  onehot_15
 E  mass_15 
 G  w_lb_15_0
 L  w_ub_15_0
 G  w_lb_15_1
 L  w_ub_15_1
 G  w_lb_15_2
 L  w_ub_15_2
 G  w_lb_15_3
 L  w_ub_15_3
 G  w_lb_15_4
 L  w_ub_15_4
 G  w_lb_15_5
 L  w_ub_15_5
 G  w_lb_15_6
 L  w_ub_15_6
 G  w_lb_15_7
 L  w_ub_15_7
 G  w_lb_15_8
 L  w_ub_15_8
 G  w_lb_15_9
 L  w_ub_15_9
 G  w_lb_15_10
 L  w_ub_15_10
 G  w_lb_15_11
 L  w_ub_15_11
 G  w_lb_15_12
 L  w_ub_15_12
 G  w_lb_15_13
 L  w_ub_15_13
 G  w_lb_15_14
 L  w_ub_15_14
 G  w_lb_15_15
 L  w_ub_15_15
 G  w_lb_15_16
 L  w_ub_15_16
 G  w_lb_15_17
 L  w_ub_15_17
 G  w_lb_15_18
 L  w_ub_15_18
 G  w_lb_15_19
 L  w_ub_15_19
 E  normalized_inventory_15
 E  normalized_ratio_15
 E  onehot_16
 E  mass_16 
 G  w_lb_16_0
 L  w_ub_16_0
 G  w_lb_16_1
 L  w_ub_16_1
 G  w_lb_16_2
 L  w_ub_16_2
 G  w_lb_16_3
 L  w_ub_16_3
 G  w_lb_16_4
 L  w_ub_16_4
 G  w_lb_16_5
 L  w_ub_16_5
 G  w_lb_16_6
 L  w_ub_16_6
 G  w_lb_16_7
 L  w_ub_16_7
 G  w_lb_16_8
 L  w_ub_16_8
 G  w_lb_16_9
 L  w_ub_16_9
 G  w_lb_16_10
 L  w_ub_16_10
 G  w_lb_16_11
 L  w_ub_16_11
 E  normalized_inventory_16
 E  normalized_ratio_16
 E  onehot_17
 E  mass_17 
 G  w_lb_17_16
 L  w_ub_17_16
 E  normalized_inventory_17
 E  normalized_ratio_17
 E  onehot_18
 E  mass_18 
 G  w_lb_18_0
 L  w_ub_18_0
 G  w_lb_18_1
 L  w_ub_18_1
 G  w_lb_18_2
 L  w_ub_18_2
 G  w_lb_18_3
 L  w_ub_18_3
 G  w_lb_18_4
 L  w_ub_18_4
 G  w_lb_18_5
 L  w_ub_18_5
 G  w_lb_18_6
 L  w_ub_18_6
 G  w_lb_18_7
 L  w_ub_18_7
 G  w_lb_18_8
 L  w_ub_18_8
 G  w_lb_18_9
 L  w_ub_18_9
 G  w_lb_18_10
 L  w_ub_18_10
 G  w_lb_18_11
 L  w_ub_18_11
 G  w_lb_18_12
 L  w_ub_18_12
 G  w_lb_18_13
 L  w_ub_18_13
 G  w_lb_18_14
 L  w_ub_18_14
 G  w_lb_18_15
 L  w_ub_18_15
 E  normalized_inventory_18
 E  normalized_ratio_18
 E  onehot_19
 E  mass_19 
 G  w_lb_19_0
 L  w_ub_19_0
 G  w_lb_19_1
 L  w_ub_19_1
 G  w_lb_19_2
 L  w_ub_19_2
 G  w_lb_19_3
 L  w_ub_19_3
 G  w_lb_19_4
 L  w_ub_19_4
 G  w_lb_19_5
 L  w_ub_19_5
 G  w_lb_19_6
 L  w_ub_19_6
 G  w_lb_19_7
 L  w_ub_19_7
 G  w_lb_19_8
 L  w_ub_19_8
 G  w_lb_19_9
 L  w_ub_19_9
 G  w_lb_19_10
 L  w_ub_19_10
 G  w_lb_19_11
 L  w_ub_19_11
 G  w_lb_19_12
 L  w_ub_19_12
 G  w_lb_19_13
 L  w_ub_19_13
 G  w_lb_19_14
 L  w_ub_19_14
 G  w_lb_19_15
 L  w_ub_19_15
 G  w_lb_19_16
 L  w_ub_19_16
 G  w_lb_19_17
 L  w_ub_19_17
 G  w_lb_19_18
 L  w_ub_19_18
 G  w_lb_19_19
 L  w_ub_19_19
 E  normalized_inventory_19
 E  normalized_ratio_19
 E  onehot_20
 E  mass_20 
 G  w_lb_20_0
 L  w_ub_20_0
 G  w_lb_20_1
 L  w_ub_20_1
 G  w_lb_20_2
 L  w_ub_20_2
 G  w_lb_20_3
 L  w_ub_20_3
 G  w_lb_20_4
 L  w_ub_20_4
 G  w_lb_20_5
 L  w_ub_20_5
 G  w_lb_20_6
 L  w_ub_20_6
 G  w_lb_20_7
 L  w_ub_20_7
 G  w_lb_20_8
 L  w_ub_20_8
 G  w_lb_20_9
 L  w_ub_20_9
 G  w_lb_20_10
 L  w_ub_20_10
 G  w_lb_20_11
 L  w_ub_20_11
 G  w_lb_20_12
 L  w_ub_20_12
 G  w_lb_20_13
 L  w_ub_20_13
 G  w_lb_20_14
 L  w_ub_20_14
 G  w_lb_20_15
 L  w_ub_20_15
 E  normalized_inventory_20
 E  normalized_ratio_20
 E  onehot_21
 E  mass_21 
 G  w_lb_21_0
 L  w_ub_21_0
 G  w_lb_21_1
 L  w_ub_21_1
 G  w_lb_21_2
 L  w_ub_21_2
 G  w_lb_21_3
 L  w_ub_21_3
 G  w_lb_21_4
 L  w_ub_21_4
 G  w_lb_21_5
 L  w_ub_21_5
 G  w_lb_21_6
 L  w_ub_21_6
 G  w_lb_21_7
 L  w_ub_21_7
 G  w_lb_21_8
 L  w_ub_21_8
 G  w_lb_21_9
 L  w_ub_21_9
 G  w_lb_21_10
 L  w_ub_21_10
 G  w_lb_21_11
 L  w_ub_21_11
 G  w_lb_21_12
 L  w_ub_21_12
 G  w_lb_21_13
 L  w_ub_21_13
 G  w_lb_21_14
 L  w_ub_21_14
 G  w_lb_21_15
 L  w_ub_21_15
 G  w_lb_21_16
 L  w_ub_21_16
 G  w_lb_21_17
 L  w_ub_21_17
 G  w_lb_21_18
 L  w_ub_21_18
 G  w_lb_21_19
 L  w_ub_21_19
 E  normalized_inventory_21
 E  normalized_ratio_21
 E  onehot_22
 E  mass_22 
 G  w_lb_22_0
 L  w_ub_22_0
 G  w_lb_22_1
 L  w_ub_22_1
 G  w_lb_22_2
 L  w_ub_22_2
 G  w_lb_22_3
 L  w_ub_22_3
 G  w_lb_22_4
 L  w_ub_22_4
 G  w_lb_22_5
 L  w_ub_22_5
 G  w_lb_22_6
 L  w_ub_22_6
 G  w_lb_22_7
 L  w_ub_22_7
 G  w_lb_22_8
 L  w_ub_22_8
 G  w_lb_22_9
 L  w_ub_22_9
 G  w_lb_22_10
 L  w_ub_22_10
 G  w_lb_22_11
 L  w_ub_22_11
 G  w_lb_22_12
 L  w_ub_22_12
 G  w_lb_22_13
 L  w_ub_22_13
 G  w_lb_22_14
 L  w_ub_22_14
 G  w_lb_22_15
 L  w_ub_22_15
 G  w_lb_22_16
 L  w_ub_22_16
 G  w_lb_22_17
 L  w_ub_22_17
 G  w_lb_22_18
 L  w_ub_22_18
 G  w_lb_22_19
 L  w_ub_22_19
 E  normalized_inventory_22
 E  normalized_ratio_22
 E  onehot_23
 E  mass_23 
 G  w_lb_23_0
 L  w_ub_23_0
 G  w_lb_23_1
 L  w_ub_23_1
 G  w_lb_23_2
 L  w_ub_23_2
 G  w_lb_23_3
 L  w_ub_23_3
 G  w_lb_23_4
 L  w_ub_23_4
 G  w_lb_23_5
 L  w_ub_23_5
 G  w_lb_23_6
 L  w_ub_23_6
 G  w_lb_23_7
 L  w_ub_23_7
 G  w_lb_23_8
 L  w_ub_23_8
 G  w_lb_23_9
 L  w_ub_23_9
 G  w_lb_23_10
 L  w_ub_23_10
 G  w_lb_23_11
 L  w_ub_23_11
 G  w_lb_23_12
 L  w_ub_23_12
 G  w_lb_23_13
 L  w_ub_23_13
 G  w_lb_23_14
 L  w_ub_23_14
 G  w_lb_23_15
 L  w_ub_23_15
 E  normalized_inventory_23
 E  normalized_ratio_23
 E  onehot_24
 E  mass_24 
 G  w_lb_24_0
 L  w_ub_24_0
 G  w_lb_24_1
 L  w_ub_24_1
 G  w_lb_24_2
 L  w_ub_24_2
 G  w_lb_24_3
 L  w_ub_24_3
 G  w_lb_24_4
 L  w_ub_24_4
 G  w_lb_24_5
 L  w_ub_24_5
 G  w_lb_24_6
 L  w_ub_24_6
 G  w_lb_24_7
 L  w_ub_24_7
 G  w_lb_24_8
 L  w_ub_24_8
 E  normalized_inventory_24
 E  normalized_ratio_24
 E  onehot_25
 E  mass_25 
 G  w_lb_25_0
 L  w_ub_25_0
 G  w_lb_25_1
 L  w_ub_25_1
 G  w_lb_25_2
 L  w_ub_25_2
 G  w_lb_25_3
 L  w_ub_25_3
 G  w_lb_25_4
 L  w_ub_25_4
 G  w_lb_25_5
 L  w_ub_25_5
 G  w_lb_25_6
 L  w_ub_25_6
 G  w_lb_25_7
 L  w_ub_25_7
 G  w_lb_25_8
 L  w_ub_25_8
 G  w_lb_25_9
 L  w_ub_25_9
 G  w_lb_25_10
 L  w_ub_25_10
 G  w_lb_25_11
 L  w_ub_25_11
 G  w_lb_25_12
 L  w_ub_25_12
 G  w_lb_25_13
 L  w_ub_25_13
 G  w_lb_25_14
 L  w_ub_25_14
 G  w_lb_25_15
 L  w_ub_25_15
 E  normalized_inventory_25
 E  normalized_ratio_25
 E  onehot_26
 E  mass_26 
 G  w_lb_26_0
 L  w_ub_26_0
 G  w_lb_26_1
 L  w_ub_26_1
 G  w_lb_26_2
 L  w_ub_26_2
 G  w_lb_26_3
 L  w_ub_26_3
 G  w_lb_26_4
 L  w_ub_26_4
 G  w_lb_26_5
 L  w_ub_26_5
 G  w_lb_26_6
 L  w_ub_26_6
 G  w_lb_26_7
 L  w_ub_26_7
 G  w_lb_26_8
 L  w_ub_26_8
 G  w_lb_26_9
 L  w_ub_26_9
 G  w_lb_26_10
 L  w_ub_26_10
 G  w_lb_26_11
 L  w_ub_26_11
 G  w_lb_26_12
 L  w_ub_26_12
 G  w_lb_26_13
 L  w_ub_26_13
 G  w_lb_26_14
 L  w_ub_26_14
 G  w_lb_26_15
 L  w_ub_26_15
 E  normalized_inventory_26
 E  normalized_ratio_26
 E  onehot_27
 E  mass_27 
 G  w_lb_27_0
 L  w_ub_27_0
 G  w_lb_27_1
 L  w_ub_27_1
 G  w_lb_27_2
 L  w_ub_27_2
 G  w_lb_27_3
 L  w_ub_27_3
 G  w_lb_27_4
 L  w_ub_27_4
 G  w_lb_27_5
 L  w_ub_27_5
 G  w_lb_27_6
 L  w_ub_27_6
 G  w_lb_27_7
 L  w_ub_27_7
 G  w_lb_27_8
 L  w_ub_27_8
 G  w_lb_27_9
 L  w_ub_27_9
 G  w_lb_27_10
 L  w_ub_27_10
 G  w_lb_27_11
 L  w_ub_27_11
 G  w_lb_27_12
 L  w_ub_27_12
 G  w_lb_27_13
 L  w_ub_27_13
 G  w_lb_27_14
 L  w_ub_27_14
 G  w_lb_27_15
 L  w_ub_27_15
 G  w_lb_27_16
 L  w_ub_27_16
 G  w_lb_27_17
 L  w_ub_27_17
 G  w_lb_27_18
 L  w_ub_27_18
 G  w_lb_27_19
 L  w_ub_27_19
 E  normalized_inventory_27
 E  normalized_ratio_27
 E  onehot_28
 E  mass_28 
 G  w_lb_28_0
 L  w_ub_28_0
 G  w_lb_28_1
 L  w_ub_28_1
 G  w_lb_28_2
 L  w_ub_28_2
 G  w_lb_28_3
 L  w_ub_28_3
 G  w_lb_28_4
 L  w_ub_28_4
 G  w_lb_28_5
 L  w_ub_28_5
 G  w_lb_28_6
 L  w_ub_28_6
 G  w_lb_28_7
 L  w_ub_28_7
 G  w_lb_28_8
 L  w_ub_28_8
 G  w_lb_28_9
 L  w_ub_28_9
 G  w_lb_28_10
 L  w_ub_28_10
 G  w_lb_28_11
 L  w_ub_28_11
 G  w_lb_28_12
 L  w_ub_28_12
 G  w_lb_28_13
 L  w_ub_28_13
 G  w_lb_28_14
 L  w_ub_28_14
 G  w_lb_28_15
 L  w_ub_28_15
 E  normalized_inventory_28
 E  normalized_ratio_28
 E  onehot_29
 E  mass_29 
 G  w_lb_29_0
 L  w_ub_29_0
 G  w_lb_29_1
 L  w_ub_29_1
 G  w_lb_29_2
 L  w_ub_29_2
 G  w_lb_29_3
 L  w_ub_29_3
 G  w_lb_29_4
 L  w_ub_29_4
 G  w_lb_29_5
 L  w_ub_29_5
 G  w_lb_29_6
 L  w_ub_29_6
 G  w_lb_29_7
 L  w_ub_29_7
 G  w_lb_29_8
 L  w_ub_29_8
 G  w_lb_29_9
 L  w_ub_29_9
 G  w_lb_29_10
 L  w_ub_29_10
 G  w_lb_29_11
 L  w_ub_29_11
 G  w_lb_29_12
 L  w_ub_29_12
 G  w_lb_29_13
 L  w_ub_29_13
 G  w_lb_29_14
 L  w_ub_29_14
 G  w_lb_29_15
 L  w_ub_29_15
 E  normalized_inventory_29
 E  normalized_ratio_29
 E  onehot_30
 E  mass_30 
 G  w_lb_30_0
 L  w_ub_30_0
 G  w_lb_30_1
 L  w_ub_30_1
 G  w_lb_30_2
 L  w_ub_30_2
 G  w_lb_30_3
 L  w_ub_30_3
 G  w_lb_30_4
 L  w_ub_30_4
 G  w_lb_30_5
 L  w_ub_30_5
 G  w_lb_30_6
 L  w_ub_30_6
 G  w_lb_30_7
 L  w_ub_30_7
 G  w_lb_30_8
 L  w_ub_30_8
 G  w_lb_30_9
 L  w_ub_30_9
 G  w_lb_30_10
 L  w_ub_30_10
 G  w_lb_30_11
 L  w_ub_30_11
 G  w_lb_30_12
 L  w_ub_30_12
 G  w_lb_30_13
 L  w_ub_30_13
 G  w_lb_30_14
 L  w_ub_30_14
 G  w_lb_30_15
 L  w_ub_30_15
 G  w_lb_30_16
 L  w_ub_30_16
 G  w_lb_30_17
 L  w_ub_30_17
 G  w_lb_30_18
 L  w_ub_30_18
 G  w_lb_30_19
 L  w_ub_30_19
 G  w_lb_30_20
 L  w_ub_30_20
 E  normalized_inventory_30
 E  normalized_ratio_30
 E  onehot_31
 E  mass_31 
 G  w_lb_31_0
 L  w_ub_31_0
 G  w_lb_31_1
 L  w_ub_31_1
 G  w_lb_31_2
 L  w_ub_31_2
 G  w_lb_31_3
 L  w_ub_31_3
 G  w_lb_31_4
 L  w_ub_31_4
 G  w_lb_31_5
 L  w_ub_31_5
 G  w_lb_31_6
 L  w_ub_31_6
 G  w_lb_31_7
 L  w_ub_31_7
 G  w_lb_31_8
 L  w_ub_31_8
 G  w_lb_31_9
 L  w_ub_31_9
 G  w_lb_31_10
 L  w_ub_31_10
 G  w_lb_31_11
 L  w_ub_31_11
 G  w_lb_31_12
 L  w_ub_31_12
 G  w_lb_31_13
 L  w_ub_31_13
 G  w_lb_31_14
 L  w_ub_31_14
 G  w_lb_31_15
 L  w_ub_31_15
 E  normalized_inventory_31
 E  normalized_ratio_31
 E  onehot_32
 E  mass_32 
 G  w_lb_32_0
 L  w_ub_32_0
 G  w_lb_32_1
 L  w_ub_32_1
 G  w_lb_32_2
 L  w_ub_32_2
 G  w_lb_32_3
 L  w_ub_32_3
 G  w_lb_32_4
 L  w_ub_32_4
 G  w_lb_32_5
 L  w_ub_32_5
 G  w_lb_32_6
 L  w_ub_32_6
 G  w_lb_32_7
 L  w_ub_32_7
 G  w_lb_32_8
 L  w_ub_32_8
 G  w_lb_32_9
 L  w_ub_32_9
 G  w_lb_32_10
 L  w_ub_32_10
 G  w_lb_32_11
 L  w_ub_32_11
 G  w_lb_32_12
 L  w_ub_32_12
 G  w_lb_32_13
 L  w_ub_32_13
 G  w_lb_32_14
 L  w_ub_32_14
 G  w_lb_32_15
 L  w_ub_32_15
 E  normalized_inventory_32
 E  normalized_ratio_32
 E  onehot_33
 E  mass_33 
 G  w_lb_33_0
 L  w_ub_33_0
 G  w_lb_33_1
 L  w_ub_33_1
 G  w_lb_33_2
 L  w_ub_33_2
 G  w_lb_33_3
 L  w_ub_33_3
 G  w_lb_33_4
 L  w_ub_33_4
 G  w_lb_33_5
 L  w_ub_33_5
 G  w_lb_33_6
 L  w_ub_33_6
 G  w_lb_33_7
 L  w_ub_33_7
 G  w_lb_33_8
 L  w_ub_33_8
 G  w_lb_33_9
 L  w_ub_33_9
 G  w_lb_33_10
 L  w_ub_33_10
 G  w_lb_33_11
 L  w_ub_33_11
 G  w_lb_33_12
 L  w_ub_33_12
 G  w_lb_33_13
 L  w_ub_33_13
 G  w_lb_33_14
 L  w_ub_33_14
 G  w_lb_33_15
 L  w_ub_33_15
 G  w_lb_33_16
 L  w_ub_33_16
 G  w_lb_33_17
 L  w_ub_33_17
 G  w_lb_33_18
 L  w_ub_33_18
 G  w_lb_33_19
 L  w_ub_33_19
 G  w_lb_33_20
 L  w_ub_33_20
 G  w_lb_33_21
 L  w_ub_33_21
 G  w_lb_33_22
 L  w_ub_33_22
 G  w_lb_33_23
 L  w_ub_33_23
 G  w_lb_33_24
 L  w_ub_33_24
 E  normalized_inventory_33
 E  normalized_ratio_33
 E  onehot_34
 E  mass_34 
 G  w_lb_34_0
 L  w_ub_34_0
 G  w_lb_34_1
 L  w_ub_34_1
 G  w_lb_34_2
 L  w_ub_34_2
 G  w_lb_34_3
 L  w_ub_34_3
 G  w_lb_34_4
 L  w_ub_34_4
 G  w_lb_34_5
 L  w_ub_34_5
 G  w_lb_34_6
 L  w_ub_34_6
 G  w_lb_34_7
 L  w_ub_34_7
 G  w_lb_34_8
 L  w_ub_34_8
 G  w_lb_34_9
 L  w_ub_34_9
 G  w_lb_34_10
 L  w_ub_34_10
 G  w_lb_34_11
 L  w_ub_34_11
 G  w_lb_34_12
 L  w_ub_34_12
 G  w_lb_34_13
 L  w_ub_34_13
 G  w_lb_34_14
 L  w_ub_34_14
 G  w_lb_34_15
 L  w_ub_34_15
 E  normalized_inventory_34
 E  normalized_ratio_34
 E  onehot_35
 E  mass_35 
 G  w_lb_35_0
 L  w_ub_35_0
 G  w_lb_35_1
 L  w_ub_35_1
 G  w_lb_35_2
 L  w_ub_35_2
 G  w_lb_35_3
 L  w_ub_35_3
 G  w_lb_35_4
 L  w_ub_35_4
 G  w_lb_35_5
 L  w_ub_35_5
 G  w_lb_35_6
 L  w_ub_35_6
 G  w_lb_35_7
 L  w_ub_35_7
 G  w_lb_35_8
 L  w_ub_35_8
 G  w_lb_35_9
 L  w_ub_35_9
 G  w_lb_35_10
 L  w_ub_35_10
 G  w_lb_35_11
 L  w_ub_35_11
 G  w_lb_35_12
 L  w_ub_35_12
 G  w_lb_35_13
 L  w_ub_35_13
 G  w_lb_35_14
 L  w_ub_35_14
 G  w_lb_35_15
 L  w_ub_35_15
 G  w_lb_35_16
 L  w_ub_35_16
 G  w_lb_35_17
 L  w_ub_35_17
 E  normalized_inventory_35
 E  normalized_ratio_35
 G  hard_lower
 L  hard_upper
 E  normalization
 G  scaled_stock_lower
 L  scaled_stock_upper
 G  abs_p_1_2
 G  abs_m_1_2
 G  abs_p_1_3
 G  abs_m_1_3
 G  abs_p_1_4
 G  abs_m_1_4
 G  abs_p_1_5
 G  abs_m_1_5
 G  abs_p_1_6
 G  abs_m_1_6
 G  abs_p_1_7
 G  abs_m_1_7
 G  abs_p_1_8
 G  abs_m_1_8
 G  abs_p_1_9
 G  abs_m_1_9
 G  abs_p_1_10
 G  abs_m_1_10
 G  abs_p_1_11
 G  abs_m_1_11
 G  abs_p_1_12
 G  abs_m_1_12
 G  abs_p_1_13
 G  abs_m_1_13
 G  abs_p_1_14
 G  abs_m_1_14
 G  abs_p_1_15
 G  abs_m_1_15
 G  abs_p_1_16
 G  abs_m_1_16
 G  abs_p_1_17
 G  abs_m_1_17
 G  abs_p_1_18
 G  abs_m_1_18
 G  abs_p_1_19
 G  abs_m_1_19
 G  abs_p_1_20
 G  abs_m_1_20
 G  abs_p_1_21
 G  abs_m_1_21
 G  abs_p_1_22
 G  abs_m_1_22
 G  abs_p_1_23
 G  abs_m_1_23
 G  abs_p_1_24
 G  abs_m_1_24
 G  abs_p_1_25
 G  abs_m_1_25
 G  abs_p_1_26
 G  abs_m_1_26
 G  abs_p_1_27
 G  abs_m_1_27
 G  abs_p_1_28
 G  abs_m_1_28
 G  abs_p_1_29
 G  abs_m_1_29
 G  abs_p_1_30
 G  abs_m_1_30
 G  abs_p_1_31
 G  abs_m_1_31
 G  abs_p_1_32
 G  abs_m_1_32
 G  abs_p_1_33
 G  abs_m_1_33
 G  abs_p_1_34
 G  abs_m_1_34
 G  abs_p_1_35
 G  abs_m_1_35
 G  abs_p_2_3
 G  abs_m_2_3
 G  abs_p_2_4
 G  abs_m_2_4
 G  abs_p_2_5
 G  abs_m_2_5
 G  abs_p_2_6
 G  abs_m_2_6
 G  abs_p_2_7
 G  abs_m_2_7
 G  abs_p_2_8
 G  abs_m_2_8
 G  abs_p_2_9
 G  abs_m_2_9
 G  abs_p_2_10
 G  abs_m_2_10
 G  abs_p_2_11
 G  abs_m_2_11
 G  abs_p_2_12
 G  abs_m_2_12
 G  abs_p_2_13
 G  abs_m_2_13
 G  abs_p_2_14
 G  abs_m_2_14
 G  abs_p_2_15
 G  abs_m_2_15
 G  abs_p_2_16
 G  abs_m_2_16
 G  abs_p_2_17
 G  abs_m_2_17
 G  abs_p_2_18
 G  abs_m_2_18
 G  abs_p_2_19
 G  abs_m_2_19
 G  abs_p_2_20
 G  abs_m_2_20
 G  abs_p_2_21
 G  abs_m_2_21
 G  abs_p_2_22
 G  abs_m_2_22
 G  abs_p_2_23
 G  abs_m_2_23
 G  abs_p_2_24
 G  abs_m_2_24
 G  abs_p_2_25
 G  abs_m_2_25
 G  abs_p_2_26
 G  abs_m_2_26
 G  abs_p_2_27
 G  abs_m_2_27
 G  abs_p_2_28
 G  abs_m_2_28
 G  abs_p_2_29
 G  abs_m_2_29
 G  abs_p_2_30
 G  abs_m_2_30
 G  abs_p_2_31
 G  abs_m_2_31
 G  abs_p_2_32
 G  abs_m_2_32
 G  abs_p_2_33
 G  abs_m_2_33
 G  abs_p_2_34
 G  abs_m_2_34
 G  abs_p_2_35
 G  abs_m_2_35
 G  abs_p_3_4
 G  abs_m_3_4
 G  abs_p_3_5
 G  abs_m_3_5
 G  abs_p_3_6
 G  abs_m_3_6
 G  abs_p_3_7
 G  abs_m_3_7
 G  abs_p_3_8
 G  abs_m_3_8
 G  abs_p_3_9
 G  abs_m_3_9
 G  abs_p_3_10
 G  abs_m_3_10
 G  abs_p_3_11
 G  abs_m_3_11
 G  abs_p_3_12
 G  abs_m_3_12
 G  abs_p_3_13
 G  abs_m_3_13
 G  abs_p_3_14
 G  abs_m_3_14
 G  abs_p_3_15
 G  abs_m_3_15
 G  abs_p_3_16
 G  abs_m_3_16
 G  abs_p_3_17
 G  abs_m_3_17
 G  abs_p_3_18
 G  abs_m_3_18
 G  abs_p_3_19
 G  abs_m_3_19
 G  abs_p_3_20
 G  abs_m_3_20
 G  abs_p_3_21
 G  abs_m_3_21
 G  abs_p_3_22
 G  abs_m_3_22
 G  abs_p_3_23
 G  abs_m_3_23
 G  abs_p_3_24
 G  abs_m_3_24
 G  abs_p_3_25
 G  abs_m_3_25
 G  abs_p_3_26
 G  abs_m_3_26
 G  abs_p_3_27
 G  abs_m_3_27
 G  abs_p_3_28
 G  abs_m_3_28
 G  abs_p_3_29
 G  abs_m_3_29
 G  abs_p_3_30
 G  abs_m_3_30
 G  abs_p_3_31
 G  abs_m_3_31
 G  abs_p_3_32
 G  abs_m_3_32
 G  abs_p_3_33
 G  abs_m_3_33
 G  abs_p_3_34
 G  abs_m_3_34
 G  abs_p_3_35
 G  abs_m_3_35
 G  abs_p_4_5
 G  abs_m_4_5
 G  abs_p_4_6
 G  abs_m_4_6
 G  abs_p_4_7
 G  abs_m_4_7
 G  abs_p_4_8
 G  abs_m_4_8
 G  abs_p_4_9
 G  abs_m_4_9
 G  abs_p_4_10
 G  abs_m_4_10
 G  abs_p_4_11
 G  abs_m_4_11
 G  abs_p_4_12
 G  abs_m_4_12
 G  abs_p_4_13
 G  abs_m_4_13
 G  abs_p_4_14
 G  abs_m_4_14
 G  abs_p_4_15
 G  abs_m_4_15
 G  abs_p_4_16
 G  abs_m_4_16
 G  abs_p_4_17
 G  abs_m_4_17
 G  abs_p_4_18
 G  abs_m_4_18
 G  abs_p_4_19
 G  abs_m_4_19
 G  abs_p_4_20
 G  abs_m_4_20
 G  abs_p_4_21
 G  abs_m_4_21
 G  abs_p_4_22
 G  abs_m_4_22
 G  abs_p_4_23
 G  abs_m_4_23
 G  abs_p_4_24
 G  abs_m_4_24
 G  abs_p_4_25
 G  abs_m_4_25
 G  abs_p_4_26
 G  abs_m_4_26
 G  abs_p_4_27
 G  abs_m_4_27
 G  abs_p_4_28
 G  abs_m_4_28
 G  abs_p_4_29
 G  abs_m_4_29
 G  abs_p_4_30
 G  abs_m_4_30
 G  abs_p_4_31
 G  abs_m_4_31
 G  abs_p_4_32
 G  abs_m_4_32
 G  abs_p_4_33
 G  abs_m_4_33
 G  abs_p_4_34
 G  abs_m_4_34
 G  abs_p_4_35
 G  abs_m_4_35
 G  abs_p_5_6
 G  abs_m_5_6
 G  abs_p_5_7
 G  abs_m_5_7
 G  abs_p_5_8
 G  abs_m_5_8
 G  abs_p_5_9
 G  abs_m_5_9
 G  abs_p_5_10
 G  abs_m_5_10
 G  abs_p_5_11
 G  abs_m_5_11
 G  abs_p_5_12
 G  abs_m_5_12
 G  abs_p_5_13
 G  abs_m_5_13
 G  abs_p_5_14
 G  abs_m_5_14
 G  abs_p_5_15
 G  abs_m_5_15
 G  abs_p_5_16
 G  abs_m_5_16
 G  abs_p_5_17
 G  abs_m_5_17
 G  abs_p_5_18
 G  abs_m_5_18
 G  abs_p_5_19
 G  abs_m_5_19
 G  abs_p_5_20
 G  abs_m_5_20
 G  abs_p_5_21
 G  abs_m_5_21
 G  abs_p_5_22
 G  abs_m_5_22
 G  abs_p_5_23
 G  abs_m_5_23
 G  abs_p_5_24
 G  abs_m_5_24
 G  abs_p_5_25
 G  abs_m_5_25
 G  abs_p_5_26
 G  abs_m_5_26
 G  abs_p_5_27
 G  abs_m_5_27
 G  abs_p_5_28
 G  abs_m_5_28
 G  abs_p_5_29
 G  abs_m_5_29
 G  abs_p_5_30
 G  abs_m_5_30
 G  abs_p_5_31
 G  abs_m_5_31
 G  abs_p_5_32
 G  abs_m_5_32
 G  abs_p_5_33
 G  abs_m_5_33
 G  abs_p_5_34
 G  abs_m_5_34
 G  abs_p_5_35
 G  abs_m_5_35
 G  abs_p_6_7
 G  abs_m_6_7
 G  abs_p_6_8
 G  abs_m_6_8
 G  abs_p_6_9
 G  abs_m_6_9
 G  abs_p_6_10
 G  abs_m_6_10
 G  abs_p_6_11
 G  abs_m_6_11
 G  abs_p_6_12
 G  abs_m_6_12
 G  abs_p_6_13
 G  abs_m_6_13
 G  abs_p_6_14
 G  abs_m_6_14
 G  abs_p_6_15
 G  abs_m_6_15
 G  abs_p_6_16
 G  abs_m_6_16
 G  abs_p_6_17
 G  abs_m_6_17
 G  abs_p_6_18
 G  abs_m_6_18
 G  abs_p_6_19
 G  abs_m_6_19
 G  abs_p_6_20
 G  abs_m_6_20
 G  abs_p_6_21
 G  abs_m_6_21
 G  abs_p_6_22
 G  abs_m_6_22
 G  abs_p_6_23
 G  abs_m_6_23
 G  abs_p_6_24
 G  abs_m_6_24
 G  abs_p_6_25
 G  abs_m_6_25
 G  abs_p_6_26
 G  abs_m_6_26
 G  abs_p_6_27
 G  abs_m_6_27
 G  abs_p_6_28
 G  abs_m_6_28
 G  abs_p_6_29
 G  abs_m_6_29
 G  abs_p_6_30
 G  abs_m_6_30
 G  abs_p_6_31
 G  abs_m_6_31
 G  abs_p_6_32
 G  abs_m_6_32
 G  abs_p_6_33
 G  abs_m_6_33
 G  abs_p_6_34
 G  abs_m_6_34
 G  abs_p_6_35
 G  abs_m_6_35
 G  abs_p_7_8
 G  abs_m_7_8
 G  abs_p_7_9
 G  abs_m_7_9
 G  abs_p_7_10
 G  abs_m_7_10
 G  abs_p_7_11
 G  abs_m_7_11
 G  abs_p_7_12
 G  abs_m_7_12
 G  abs_p_7_13
 G  abs_m_7_13
 G  abs_p_7_14
 G  abs_m_7_14
 G  abs_p_7_15
 G  abs_m_7_15
 G  abs_p_7_16
 G  abs_m_7_16
 G  abs_p_7_17
 G  abs_m_7_17
 G  abs_p_7_18
 G  abs_m_7_18
 G  abs_p_7_19
 G  abs_m_7_19
 G  abs_p_7_20
 G  abs_m_7_20
 G  abs_p_7_21
 G  abs_m_7_21
 G  abs_p_7_22
 G  abs_m_7_22
 G  abs_p_7_23
 G  abs_m_7_23
 G  abs_p_7_24
 G  abs_m_7_24
 G  abs_p_7_25
 G  abs_m_7_25
 G  abs_p_7_26
 G  abs_m_7_26
 G  abs_p_7_27
 G  abs_m_7_27
 G  abs_p_7_28
 G  abs_m_7_28
 G  abs_p_7_29
 G  abs_m_7_29
 G  abs_p_7_30
 G  abs_m_7_30
 G  abs_p_7_31
 G  abs_m_7_31
 G  abs_p_7_32
 G  abs_m_7_32
 G  abs_p_7_33
 G  abs_m_7_33
 G  abs_p_7_34
 G  abs_m_7_34
 G  abs_p_7_35
 G  abs_m_7_35
 G  abs_p_8_9
 G  abs_m_8_9
 G  abs_p_8_10
 G  abs_m_8_10
 G  abs_p_8_11
 G  abs_m_8_11
 G  abs_p_8_12
 G  abs_m_8_12
 G  abs_p_8_13
 G  abs_m_8_13
 G  abs_p_8_14
 G  abs_m_8_14
 G  abs_p_8_15
 G  abs_m_8_15
 G  abs_p_8_16
 G  abs_m_8_16
 G  abs_p_8_17
 G  abs_m_8_17
 G  abs_p_8_18
 G  abs_m_8_18
 G  abs_p_8_19
 G  abs_m_8_19
 G  abs_p_8_20
 G  abs_m_8_20
 G  abs_p_8_21
 G  abs_m_8_21
 G  abs_p_8_22
 G  abs_m_8_22
 G  abs_p_8_23
 G  abs_m_8_23
 G  abs_p_8_24
 G  abs_m_8_24
 G  abs_p_8_25
 G  abs_m_8_25
 G  abs_p_8_26
 G  abs_m_8_26
 G  abs_p_8_27
 G  abs_m_8_27
 G  abs_p_8_28
 G  abs_m_8_28
 G  abs_p_8_29
 G  abs_m_8_29
 G  abs_p_8_30
 G  abs_m_8_30
 G  abs_p_8_31
 G  abs_m_8_31
 G  abs_p_8_32
 G  abs_m_8_32
 G  abs_p_8_33
 G  abs_m_8_33
 G  abs_p_8_34
 G  abs_m_8_34
 G  abs_p_8_35
 G  abs_m_8_35
 G  abs_p_9_10
 G  abs_m_9_10
 G  abs_p_9_11
 G  abs_m_9_11
 G  abs_p_9_12
 G  abs_m_9_12
 G  abs_p_9_13
 G  abs_m_9_13
 G  abs_p_9_14
 G  abs_m_9_14
 G  abs_p_9_15
 G  abs_m_9_15
 G  abs_p_9_16
 G  abs_m_9_16
 G  abs_p_9_17
 G  abs_m_9_17
 G  abs_p_9_18
 G  abs_m_9_18
 G  abs_p_9_19
 G  abs_m_9_19
 G  abs_p_9_20
 G  abs_m_9_20
 G  abs_p_9_21
 G  abs_m_9_21
 G  abs_p_9_22
 G  abs_m_9_22
 G  abs_p_9_23
 G  abs_m_9_23
 G  abs_p_9_24
 G  abs_m_9_24
 G  abs_p_9_25
 G  abs_m_9_25
 G  abs_p_9_26
 G  abs_m_9_26
 G  abs_p_9_27
 G  abs_m_9_27
 G  abs_p_9_28
 G  abs_m_9_28
 G  abs_p_9_29
 G  abs_m_9_29
 G  abs_p_9_30
 G  abs_m_9_30
 G  abs_p_9_31
 G  abs_m_9_31
 G  abs_p_9_32
 G  abs_m_9_32
 G  abs_p_9_33
 G  abs_m_9_33
 G  abs_p_9_34
 G  abs_m_9_34
 G  abs_p_9_35
 G  abs_m_9_35
 G  abs_p_10_11
 G  abs_m_10_11
 G  abs_p_10_12
 G  abs_m_10_12
 G  abs_p_10_13
 G  abs_m_10_13
 G  abs_p_10_14
 G  abs_m_10_14
 G  abs_p_10_15
 G  abs_m_10_15
 G  abs_p_10_16
 G  abs_m_10_16
 G  abs_p_10_17
 G  abs_m_10_17
 G  abs_p_10_18
 G  abs_m_10_18
 G  abs_p_10_19
 G  abs_m_10_19
 G  abs_p_10_20
 G  abs_m_10_20
 G  abs_p_10_21
 G  abs_m_10_21
 G  abs_p_10_22
 G  abs_m_10_22
 G  abs_p_10_23
 G  abs_m_10_23
 G  abs_p_10_24
 G  abs_m_10_24
 G  abs_p_10_25
 G  abs_m_10_25
 G  abs_p_10_26
 G  abs_m_10_26
 G  abs_p_10_27
 G  abs_m_10_27
 G  abs_p_10_28
 G  abs_m_10_28
 G  abs_p_10_29
 G  abs_m_10_29
 G  abs_p_10_30
 G  abs_m_10_30
 G  abs_p_10_31
 G  abs_m_10_31
 G  abs_p_10_32
 G  abs_m_10_32
 G  abs_p_10_33
 G  abs_m_10_33
 G  abs_p_10_34
 G  abs_m_10_34
 G  abs_p_10_35
 G  abs_m_10_35
 G  abs_p_11_12
 G  abs_m_11_12
 G  abs_p_11_13
 G  abs_m_11_13
 G  abs_p_11_14
 G  abs_m_11_14
 G  abs_p_11_15
 G  abs_m_11_15
 G  abs_p_11_16
 G  abs_m_11_16
 G  abs_p_11_17
 G  abs_m_11_17
 G  abs_p_11_18
 G  abs_m_11_18
 G  abs_p_11_19
 G  abs_m_11_19
 G  abs_p_11_20
 G  abs_m_11_20
 G  abs_p_11_21
 G  abs_m_11_21
 G  abs_p_11_22
 G  abs_m_11_22
 G  abs_p_11_23
 G  abs_m_11_23
 G  abs_p_11_24
 G  abs_m_11_24
 G  abs_p_11_25
 G  abs_m_11_25
 G  abs_p_11_26
 G  abs_m_11_26
 G  abs_p_11_27
 G  abs_m_11_27
 G  abs_p_11_28
 G  abs_m_11_28
 G  abs_p_11_29
 G  abs_m_11_29
 G  abs_p_11_30
 G  abs_m_11_30
 G  abs_p_11_31
 G  abs_m_11_31
 G  abs_p_11_32
 G  abs_m_11_32
 G  abs_p_11_33
 G  abs_m_11_33
 G  abs_p_11_34
 G  abs_m_11_34
 G  abs_p_11_35
 G  abs_m_11_35
 G  abs_p_12_13
 G  abs_m_12_13
 G  abs_p_12_14
 G  abs_m_12_14
 G  abs_p_12_15
 G  abs_m_12_15
 G  abs_p_12_16
 G  abs_m_12_16
 G  abs_p_12_17
 G  abs_m_12_17
 G  abs_p_12_18
 G  abs_m_12_18
 G  abs_p_12_19
 G  abs_m_12_19
 G  abs_p_12_20
 G  abs_m_12_20
 G  abs_p_12_21
 G  abs_m_12_21
 G  abs_p_12_22
 G  abs_m_12_22
 G  abs_p_12_23
 G  abs_m_12_23
 G  abs_p_12_24
 G  abs_m_12_24
 G  abs_p_12_25
 G  abs_m_12_25
 G  abs_p_12_26
 G  abs_m_12_26
 G  abs_p_12_27
 G  abs_m_12_27
 G  abs_p_12_28
 G  abs_m_12_28
 G  abs_p_12_29
 G  abs_m_12_29
 G  abs_p_12_30
 G  abs_m_12_30
 G  abs_p_12_31
 G  abs_m_12_31
 G  abs_p_12_32
 G  abs_m_12_32
 G  abs_p_12_33
 G  abs_m_12_33
 G  abs_p_12_34
 G  abs_m_12_34
 G  abs_p_12_35
 G  abs_m_12_35
 G  abs_p_13_14
 G  abs_m_13_14
 G  abs_p_13_15
 G  abs_m_13_15
 G  abs_p_13_16
 G  abs_m_13_16
 G  abs_p_13_17
 G  abs_m_13_17
 G  abs_p_13_18
 G  abs_m_13_18
 G  abs_p_13_19
 G  abs_m_13_19
 G  abs_p_13_20
 G  abs_m_13_20
 G  abs_p_13_21
 G  abs_m_13_21
 G  abs_p_13_22
 G  abs_m_13_22
 G  abs_p_13_23
 G  abs_m_13_23
 G  abs_p_13_24
 G  abs_m_13_24
 G  abs_p_13_25
 G  abs_m_13_25
 G  abs_p_13_26
 G  abs_m_13_26
 G  abs_p_13_27
 G  abs_m_13_27
 G  abs_p_13_28
 G  abs_m_13_28
 G  abs_p_13_29
 G  abs_m_13_29
 G  abs_p_13_30
 G  abs_m_13_30
 G  abs_p_13_31
 G  abs_m_13_31
 G  abs_p_13_32
 G  abs_m_13_32
 G  abs_p_13_33
 G  abs_m_13_33
 G  abs_p_13_34
 G  abs_m_13_34
 G  abs_p_13_35
 G  abs_m_13_35
 G  abs_p_14_15
 G  abs_m_14_15
 G  abs_p_14_16
 G  abs_m_14_16
 G  abs_p_14_17
 G  abs_m_14_17
 G  abs_p_14_18
 G  abs_m_14_18
 G  abs_p_14_19
 G  abs_m_14_19
 G  abs_p_14_20
 G  abs_m_14_20
 G  abs_p_14_21
 G  abs_m_14_21
 G  abs_p_14_22
 G  abs_m_14_22
 G  abs_p_14_23
 G  abs_m_14_23
 G  abs_p_14_24
 G  abs_m_14_24
 G  abs_p_14_25
 G  abs_m_14_25
 G  abs_p_14_26
 G  abs_m_14_26
 G  abs_p_14_27
 G  abs_m_14_27
 G  abs_p_14_28
 G  abs_m_14_28
 G  abs_p_14_29
 G  abs_m_14_29
 G  abs_p_14_30
 G  abs_m_14_30
 G  abs_p_14_31
 G  abs_m_14_31
 G  abs_p_14_32
 G  abs_m_14_32
 G  abs_p_14_33
 G  abs_m_14_33
 G  abs_p_14_34
 G  abs_m_14_34
 G  abs_p_14_35
 G  abs_m_14_35
 G  abs_p_15_16
 G  abs_m_15_16
 G  abs_p_15_17
 G  abs_m_15_17
 G  abs_p_15_18
 G  abs_m_15_18
 G  abs_p_15_19
 G  abs_m_15_19
 G  abs_p_15_20
 G  abs_m_15_20
 G  abs_p_15_21
 G  abs_m_15_21
 G  abs_p_15_22
 G  abs_m_15_22
 G  abs_p_15_23
 G  abs_m_15_23
 G  abs_p_15_24
 G  abs_m_15_24
 G  abs_p_15_25
 G  abs_m_15_25
 G  abs_p_15_26
 G  abs_m_15_26
 G  abs_p_15_27
 G  abs_m_15_27
 G  abs_p_15_28
 G  abs_m_15_28
 G  abs_p_15_29
 G  abs_m_15_29
 G  abs_p_15_30
 G  abs_m_15_30
 G  abs_p_15_31
 G  abs_m_15_31
 G  abs_p_15_32
 G  abs_m_15_32
 G  abs_p_15_33
 G  abs_m_15_33
 G  abs_p_15_34
 G  abs_m_15_34
 G  abs_p_15_35
 G  abs_m_15_35
 G  abs_p_16_17
 G  abs_m_16_17
 G  abs_p_16_18
 G  abs_m_16_18
 G  abs_p_16_19
 G  abs_m_16_19
 G  abs_p_16_20
 G  abs_m_16_20
 G  abs_p_16_21
 G  abs_m_16_21
 G  abs_p_16_22
 G  abs_m_16_22
 G  abs_p_16_23
 G  abs_m_16_23
 G  abs_p_16_24
 G  abs_m_16_24
 G  abs_p_16_25
 G  abs_m_16_25
 G  abs_p_16_26
 G  abs_m_16_26
 G  abs_p_16_27
 G  abs_m_16_27
 G  abs_p_16_28
 G  abs_m_16_28
 G  abs_p_16_29
 G  abs_m_16_29
 G  abs_p_16_30
 G  abs_m_16_30
 G  abs_p_16_31
 G  abs_m_16_31
 G  abs_p_16_32
 G  abs_m_16_32
 G  abs_p_16_33
 G  abs_m_16_33
 G  abs_p_16_34
 G  abs_m_16_34
 G  abs_p_16_35
 G  abs_m_16_35
 G  abs_p_17_18
 G  abs_m_17_18
 G  abs_p_17_19
 G  abs_m_17_19
 G  abs_p_17_20
 G  abs_m_17_20
 G  abs_p_17_21
 G  abs_m_17_21
 G  abs_p_17_22
 G  abs_m_17_22
 G  abs_p_17_23
 G  abs_m_17_23
 G  abs_p_17_24
 G  abs_m_17_24
 G  abs_p_17_25
 G  abs_m_17_25
 G  abs_p_17_26
 G  abs_m_17_26
 G  abs_p_17_27
 G  abs_m_17_27
 G  abs_p_17_28
 G  abs_m_17_28
 G  abs_p_17_29
 G  abs_m_17_29
 G  abs_p_17_30
 G  abs_m_17_30
 G  abs_p_17_31
 G  abs_m_17_31
 G  abs_p_17_32
 G  abs_m_17_32
 G  abs_p_17_33
 G  abs_m_17_33
 G  abs_p_17_34
 G  abs_m_17_34
 G  abs_p_17_35
 G  abs_m_17_35
 G  abs_p_18_19
 G  abs_m_18_19
 G  abs_p_18_20
 G  abs_m_18_20
 G  abs_p_18_21
 G  abs_m_18_21
 G  abs_p_18_22
 G  abs_m_18_22
 G  abs_p_18_23
 G  abs_m_18_23
 G  abs_p_18_24
 G  abs_m_18_24
 G  abs_p_18_25
 G  abs_m_18_25
 G  abs_p_18_26
 G  abs_m_18_26
 G  abs_p_18_27
 G  abs_m_18_27
 G  abs_p_18_28
 G  abs_m_18_28
 G  abs_p_18_29
 G  abs_m_18_29
 G  abs_p_18_30
 G  abs_m_18_30
 G  abs_p_18_31
 G  abs_m_18_31
 G  abs_p_18_32
 G  abs_m_18_32
 G  abs_p_18_33
 G  abs_m_18_33
 G  abs_p_18_34
 G  abs_m_18_34
 G  abs_p_18_35
 G  abs_m_18_35
 G  abs_p_19_20
 G  abs_m_19_20
 G  abs_p_19_21
 G  abs_m_19_21
 G  abs_p_19_22
 G  abs_m_19_22
 G  abs_p_19_23
 G  abs_m_19_23
 G  abs_p_19_24
 G  abs_m_19_24
 G  abs_p_19_25
 G  abs_m_19_25
 G  abs_p_19_26
 G  abs_m_19_26
 G  abs_p_19_27
 G  abs_m_19_27
 G  abs_p_19_28
 G  abs_m_19_28
 G  abs_p_19_29
 G  abs_m_19_29
 G  abs_p_19_30
 G  abs_m_19_30
 G  abs_p_19_31
 G  abs_m_19_31
 G  abs_p_19_32
 G  abs_m_19_32
 G  abs_p_19_33
 G  abs_m_19_33
 G  abs_p_19_34
 G  abs_m_19_34
 G  abs_p_19_35
 G  abs_m_19_35
 G  abs_p_20_21
 G  abs_m_20_21
 G  abs_p_20_22
 G  abs_m_20_22
 G  abs_p_20_23
 G  abs_m_20_23
 G  abs_p_20_24
 G  abs_m_20_24
 G  abs_p_20_25
 G  abs_m_20_25
 G  abs_p_20_26
 G  abs_m_20_26
 G  abs_p_20_27
 G  abs_m_20_27
 G  abs_p_20_28
 G  abs_m_20_28
 G  abs_p_20_29
 G  abs_m_20_29
 G  abs_p_20_30
 G  abs_m_20_30
 G  abs_p_20_31
 G  abs_m_20_31
 G  abs_p_20_32
 G  abs_m_20_32
 G  abs_p_20_33
 G  abs_m_20_33
 G  abs_p_20_34
 G  abs_m_20_34
 G  abs_p_20_35
 G  abs_m_20_35
 G  abs_p_21_22
 G  abs_m_21_22
 G  abs_p_21_23
 G  abs_m_21_23
 G  abs_p_21_24
 G  abs_m_21_24
 G  abs_p_21_25
 G  abs_m_21_25
 G  abs_p_21_26
 G  abs_m_21_26
 G  abs_p_21_27
 G  abs_m_21_27
 G  abs_p_21_28
 G  abs_m_21_28
 G  abs_p_21_29
 G  abs_m_21_29
 G  abs_p_21_30
 G  abs_m_21_30
 G  abs_p_21_31
 G  abs_m_21_31
 G  abs_p_21_32
 G  abs_m_21_32
 G  abs_p_21_33
 G  abs_m_21_33
 G  abs_p_21_34
 G  abs_m_21_34
 G  abs_p_21_35
 G  abs_m_21_35
 G  abs_p_22_23
 G  abs_m_22_23
 G  abs_p_22_24
 G  abs_m_22_24
 G  abs_p_22_25
 G  abs_m_22_25
 G  abs_p_22_26
 G  abs_m_22_26
 G  abs_p_22_27
 G  abs_m_22_27
 G  abs_p_22_28
 G  abs_m_22_28
 G  abs_p_22_29
 G  abs_m_22_29
 G  abs_p_22_30
 G  abs_m_22_30
 G  abs_p_22_31
 G  abs_m_22_31
 G  abs_p_22_32
 G  abs_m_22_32
 G  abs_p_22_33
 G  abs_m_22_33
 G  abs_p_22_34
 G  abs_m_22_34
 G  abs_p_22_35
 G  abs_m_22_35
 G  abs_p_23_24
 G  abs_m_23_24
 G  abs_p_23_25
 G  abs_m_23_25
 G  abs_p_23_26
 G  abs_m_23_26
 G  abs_p_23_27
 G  abs_m_23_27
 G  abs_p_23_28
 G  abs_m_23_28
 G  abs_p_23_29
 G  abs_m_23_29
 G  abs_p_23_30
 G  abs_m_23_30
 G  abs_p_23_31
 G  abs_m_23_31
 G  abs_p_23_32
 G  abs_m_23_32
 G  abs_p_23_33
 G  abs_m_23_33
 G  abs_p_23_34
 G  abs_m_23_34
 G  abs_p_23_35
 G  abs_m_23_35
 G  abs_p_24_25
 G  abs_m_24_25
 G  abs_p_24_26
 G  abs_m_24_26
 G  abs_p_24_27
 G  abs_m_24_27
 G  abs_p_24_28
 G  abs_m_24_28
 G  abs_p_24_29
 G  abs_m_24_29
 G  abs_p_24_30
 G  abs_m_24_30
 G  abs_p_24_31
 G  abs_m_24_31
 G  abs_p_24_32
 G  abs_m_24_32
 G  abs_p_24_33
 G  abs_m_24_33
 G  abs_p_24_34
 G  abs_m_24_34
 G  abs_p_24_35
 G  abs_m_24_35
 G  abs_p_25_26
 G  abs_m_25_26
 G  abs_p_25_27
 G  abs_m_25_27
 G  abs_p_25_28
 G  abs_m_25_28
 G  abs_p_25_29
 G  abs_m_25_29
 G  abs_p_25_30
 G  abs_m_25_30
 G  abs_p_25_31
 G  abs_m_25_31
 G  abs_p_25_32
 G  abs_m_25_32
 G  abs_p_25_33
 G  abs_m_25_33
 G  abs_p_25_34
 G  abs_m_25_34
 G  abs_p_25_35
 G  abs_m_25_35
 G  abs_p_26_27
 G  abs_m_26_27
 G  abs_p_26_28
 G  abs_m_26_28
 G  abs_p_26_29
 G  abs_m_26_29
 G  abs_p_26_30
 G  abs_m_26_30
 G  abs_p_26_31
 G  abs_m_26_31
 G  abs_p_26_32
 G  abs_m_26_32
 G  abs_p_26_33
 G  abs_m_26_33
 G  abs_p_26_34
 G  abs_m_26_34
 G  abs_p_26_35
 G  abs_m_26_35
 G  abs_p_27_28
 G  abs_m_27_28
 G  abs_p_27_29
 G  abs_m_27_29
 G  abs_p_27_30
 G  abs_m_27_30
 G  abs_p_27_31
 G  abs_m_27_31
 G  abs_p_27_32
 G  abs_m_27_32
 G  abs_p_27_33
 G  abs_m_27_33
 G  abs_p_27_34
 G  abs_m_27_34
 G  abs_p_27_35
 G  abs_m_27_35
 G  abs_p_28_29
 G  abs_m_28_29
 G  abs_p_28_30
 G  abs_m_28_30
 G  abs_p_28_31
 G  abs_m_28_31
 G  abs_p_28_32
 G  abs_m_28_32
 G  abs_p_28_33
 G  abs_m_28_33
 G  abs_p_28_34
 G  abs_m_28_34
 G  abs_p_28_35
 G  abs_m_28_35
 G  abs_p_29_30
 G  abs_m_29_30
 G  abs_p_29_31
 G  abs_m_29_31
 G  abs_p_29_32
 G  abs_m_29_32
 G  abs_p_29_33
 G  abs_m_29_33
 G  abs_p_29_34
 G  abs_m_29_34
 G  abs_p_29_35
 G  abs_m_29_35
 G  abs_p_30_31
 G  abs_m_30_31
 G  abs_p_30_32
 G  abs_m_30_32
 G  abs_p_30_33
 G  abs_m_30_33
 G  abs_p_30_34
 G  abs_m_30_34
 G  abs_p_30_35
 G  abs_m_30_35
 G  abs_p_31_32
 G  abs_m_31_32
 G  abs_p_31_33
 G  abs_m_31_33
 G  abs_p_31_34
 G  abs_m_31_34
 G  abs_p_31_35
 G  abs_m_31_35
 G  abs_p_32_33
 G  abs_m_32_33
 G  abs_p_32_34
 G  abs_m_32_34
 G  abs_p_32_35
 G  abs_m_32_35
 G  abs_p_33_34
 G  abs_m_33_34
 G  abs_p_33_35
 G  abs_m_33_35
 G  abs_p_34_35
 G  abs_m_34_35
 L  true_G_epigraph
 L  physical_G_upper
 G  old_normalized_TC
 G  old_normalized_TC2
 G  old_TS1 
 G  old_TS2 
 L  old_TS3 
 L  old_TS4 
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,4]    onehot_1  1
    x[1,4]    w_lb_1_4  -2.2258731252318614e-02
    x[1,4]    w_ub_1_4  -3.9535535354550462e-02
    x[1,4]    hard_lower  4
    x[1,4]    hard_upper  4
    x[1,4]    old_TS1   -8.9034925009274457e-02
    x[1,4]    old_TS2   -1.5814214141820185e-01
    x[1,4]    old_TS3   -1.5814214141820185e-01
    x[1,4]    old_TS4   -8.9034925009274457e-02
    x[2,0]    OBJ       6.3905324999999985e-02
    x[2,0]    onehot_2  1
    x[2,0]    w_lb_2_0  -2.2258731252318614e-02
    x[2,0]    w_ub_2_0  -3.9535535354550462e-02
    x[2,1]    OBJ       5.3254437499999994e-02
    x[2,1]    onehot_2  1
    x[2,1]    w_lb_2_1  -2.2258731252318614e-02
    x[2,1]    w_ub_2_1  -3.9535535354550462e-02
    x[2,1]    hard_lower  1
    x[2,1]    hard_upper  1
    x[2,1]    old_TS1   -2.2258731252318614e-02
    x[2,1]    old_TS2   -3.9535535354550462e-02
    x[2,1]    old_TS3   -3.9535535354550462e-02
    x[2,1]    old_TS4   -2.2258731252318614e-02
    x[2,2]    OBJ       4.2603549999999990e-02
    x[2,2]    onehot_2  1
    x[2,2]    w_lb_2_2  -2.2258731252318614e-02
    x[2,2]    w_ub_2_2  -3.9535535354550462e-02
    x[2,2]    hard_lower  2
    x[2,2]    hard_upper  2
    x[2,2]    old_TS1   -4.4517462504637229e-02
    x[2,2]    old_TS2   -7.9071070709100924e-02
    x[2,2]    old_TS3   -7.9071070709100924e-02
    x[2,2]    old_TS4   -4.4517462504637229e-02
    x[2,3]    OBJ       3.1952662499999993e-02
    x[2,3]    onehot_2  1
    x[2,3]    w_lb_2_3  -2.2258731252318614e-02
    x[2,3]    w_ub_2_3  -3.9535535354550462e-02
    x[2,3]    hard_lower  3
    x[2,3]    hard_upper  3
    x[2,3]    old_TS1   -6.6776193756955843e-02
    x[2,3]    old_TS2   -1.1860660606365139e-01
    x[2,3]    old_TS3   -1.1860660606365139e-01
    x[2,3]    old_TS4   -6.6776193756955843e-02
    x[2,4]    OBJ       2.1301774999999995e-02
    x[2,4]    onehot_2  1
    x[2,4]    w_lb_2_4  -2.2258731252318614e-02
    x[2,4]    w_ub_2_4  -3.9535535354550462e-02
    x[2,4]    hard_lower  4
    x[2,4]    hard_upper  4
    x[2,4]    old_TS1   -8.9034925009274457e-02
    x[2,4]    old_TS2   -1.5814214141820185e-01
    x[2,4]    old_TS3   -1.5814214141820185e-01
    x[2,4]    old_TS4   -8.9034925009274457e-02
    x[2,5]    OBJ       1.0650887499999998e-02
    x[2,5]    onehot_2  1
    x[2,5]    w_lb_2_5  -2.2258731252318614e-02
    x[2,5]    w_ub_2_5  -3.9535535354550462e-02
    x[2,5]    hard_lower  5
    x[2,5]    hard_upper  5
    x[2,5]    old_TS1   -1.1129365626159307e-01
    x[2,5]    old_TS2   -1.9767767677275230e-01
    x[2,5]    old_TS3   -1.9767767677275230e-01
    x[2,5]    old_TS4   -1.1129365626159307e-01
    x[2,6]    onehot_2  1
    x[2,6]    w_lb_2_6  -2.2258731252318614e-02
    x[2,6]    w_ub_2_6  -3.9535535354550462e-02
    x[2,6]    hard_lower  6
    x[2,6]    hard_upper  6
    x[2,6]    old_TS1   -1.3355238751391169e-01
    x[2,6]    old_TS2   -2.3721321212730279e-01
    x[2,6]    old_TS3   -2.3721321212730279e-01
    x[2,6]    old_TS4   -1.3355238751391169e-01
    x[2,7]    OBJ       -0.0106508875
    x[2,7]    onehot_2  1
    x[2,7]    w_lb_2_7  -2.2258731252318614e-02
    x[2,7]    w_ub_2_7  -3.9535535354550462e-02
    x[2,7]    hard_lower  7
    x[2,7]    hard_upper  7
    x[2,7]    old_TS1   -1.5581111876623030e-01
    x[2,7]    old_TS2   -2.7674874748185324e-01
    x[2,7]    old_TS3   -2.7674874748185324e-01
    x[2,7]    old_TS4   -1.5581111876623030e-01
    x[2,8]    OBJ       -0.021301775
    x[2,8]    onehot_2  1
    x[2,8]    w_lb_2_8  -2.2258731252318614e-02
    x[2,8]    w_ub_2_8  -3.9535535354550462e-02
    x[2,8]    hard_lower  8
    x[2,8]    hard_upper  8
    x[2,8]    old_TS1   -1.7806985001854891e-01
    x[2,8]    old_TS2   -3.1628428283640370e-01
    x[2,8]    old_TS3   -3.1628428283640370e-01
    x[2,8]    old_TS4   -1.7806985001854891e-01
    x[2,9]    OBJ       -0.0319526625
    x[2,9]    onehot_2  1
    x[2,9]    w_lb_2_9  -2.2258731252318614e-02
    x[2,9]    w_ub_2_9  -3.9535535354550462e-02
    x[2,9]    hard_lower  9
    x[2,9]    hard_upper  9
    x[2,9]    old_TS1   -2.0032858127086753e-01
    x[2,9]    old_TS2   -3.5581981819095415e-01
    x[2,9]    old_TS3   -3.5581981819095415e-01
    x[2,9]    old_TS4   -2.0032858127086753e-01
    x[2,10]   OBJ       -0.04260355
    x[2,10]   onehot_2  1
    x[2,10]   w_lb_2_10  -2.2258731252318614e-02
    x[2,10]   w_ub_2_10  -3.9535535354550462e-02
    x[2,10]   hard_lower  10
    x[2,10]   hard_upper  10
    x[2,10]   old_TS1   -2.2258731252318614e-01
    x[2,10]   old_TS2   -3.9535535354550461e-01
    x[2,10]   old_TS3   -3.9535535354550461e-01
    x[2,10]   old_TS4   -2.2258731252318614e-01
    x[2,11]   OBJ       -0.0532544375
    x[2,11]   onehot_2  1
    x[2,11]   w_lb_2_11  -2.2258731252318614e-02
    x[2,11]   w_ub_2_11  -3.9535535354550462e-02
    x[2,11]   hard_lower  11
    x[2,11]   hard_upper  11
    x[2,11]   old_TS1   -2.4484604377550476e-01
    x[2,11]   old_TS2   -4.3489088890005506e-01
    x[2,11]   old_TS3   -4.3489088890005506e-01
    x[2,11]   old_TS4   -2.4484604377550476e-01
    x[2,12]   OBJ       -0.063905325
    x[2,12]   onehot_2  1
    x[2,12]   w_lb_2_12  -2.2258731252318614e-02
    x[2,12]   w_ub_2_12  -3.9535535354550462e-02
    x[2,12]   hard_lower  12
    x[2,12]   hard_upper  12
    x[2,12]   old_TS1   -2.6710477502782337e-01
    x[2,12]   old_TS2   -4.7442642425460557e-01
    x[2,12]   old_TS3   -4.7442642425460557e-01
    x[2,12]   old_TS4   -2.6710477502782337e-01
    x[2,13]   OBJ       -5.3254437500000015e-02
    x[2,13]   onehot_2  1
    x[2,13]   w_lb_2_13  -2.2258731252318614e-02
    x[2,13]   w_ub_2_13  -3.9535535354550462e-02
    x[2,13]   hard_lower  13
    x[2,13]   hard_upper  13
    x[2,13]   old_TS1   -2.8936350628014196e-01
    x[2,13]   old_TS2   -0.513961959609156
    x[2,13]   old_TS3   -0.513961959609156
    x[2,13]   old_TS4   -2.8936350628014196e-01
    x[2,14]   OBJ       -4.2603550000000018e-02
    x[2,14]   onehot_2  1
    x[2,14]   w_lb_2_14  -2.2258731252318614e-02
    x[2,14]   w_ub_2_14  -3.9535535354550462e-02
    x[2,14]   hard_lower  14
    x[2,14]   hard_upper  14
    x[2,14]   old_TS1   -3.1162223753246060e-01
    x[2,14]   old_TS2   -5.5349749496370648e-01
    x[2,14]   old_TS3   -5.5349749496370648e-01
    x[2,14]   old_TS4   -3.1162223753246060e-01
    x[2,15]   OBJ       -3.1952662500000013e-02
    x[2,15]   onehot_2  1
    x[2,15]   w_lb_2_15  -2.2258731252318614e-02
    x[2,15]   w_ub_2_15  -3.9535535354550462e-02
    x[2,15]   hard_lower  15
    x[2,15]   hard_upper  15
    x[2,15]   old_TS1   -3.3388096878477924e-01
    x[2,15]   old_TS2   -5.9303303031825694e-01
    x[2,15]   old_TS3   -5.9303303031825694e-01
    x[2,15]   old_TS4   -3.3388096878477924e-01
    x[2,16]   OBJ       -2.1301775000000016e-02
    x[2,16]   onehot_2  1
    x[2,16]   w_lb_2_16  -2.2258731252318614e-02
    x[2,16]   w_ub_2_16  -3.9535535354550462e-02
    x[2,16]   hard_lower  16
    x[2,16]   hard_upper  16
    x[2,16]   old_TS1   -3.5613970003709783e-01
    x[2,16]   old_TS2   -6.3256856567280739e-01
    x[2,16]   old_TS3   -6.3256856567280739e-01
    x[2,16]   old_TS4   -3.5613970003709783e-01
    x[2,17]   OBJ       -1.0650887500000015e-02
    x[2,17]   onehot_2  1
    x[2,17]   w_lb_2_17  -2.2258731252318614e-02
    x[2,17]   w_ub_2_17  -3.9535535354550462e-02
    x[2,17]   hard_lower  17
    x[2,17]   hard_upper  17
    x[2,17]   old_TS1   -3.7839843128941641e-01
    x[2,17]   old_TS2   -6.7210410102735785e-01
    x[2,17]   old_TS3   -6.7210410102735785e-01
    x[2,17]   old_TS4   -3.7839843128941641e-01
    x[2,18]   OBJ       -1.4189832642230726e-17
    x[2,18]   onehot_2  1
    x[2,18]   w_lb_2_18  -2.2258731252318614e-02
    x[2,18]   w_ub_2_18  -3.9535535354550462e-02
    x[2,18]   hard_lower  18
    x[2,18]   hard_upper  18
    x[2,18]   old_TS1   -4.0065716254173506e-01
    x[2,18]   old_TS2   -7.1163963638190830e-01
    x[2,18]   old_TS3   -7.1163963638190830e-01
    x[2,18]   old_TS4   -4.0065716254173506e-01
    x[2,19]   OBJ       1.0650887499999984e-02
    x[2,19]   onehot_2  1
    x[2,19]   w_lb_2_19  -2.2258731252318614e-02
    x[2,19]   w_ub_2_19  -3.9535535354550462e-02
    x[2,19]   hard_lower  19
    x[2,19]   hard_upper  19
    x[2,19]   old_TS1   -4.2291589379405370e-01
    x[2,19]   old_TS2   -7.5117517173645876e-01
    x[2,19]   old_TS3   -7.5117517173645876e-01
    x[2,19]   old_TS4   -4.2291589379405370e-01
    x[2,20]   OBJ       2.1301774999999981e-02
    x[2,20]   onehot_2  1
    x[2,20]   w_lb_2_20  -2.2258731252318614e-02
    x[2,20]   w_ub_2_20  -3.9535535354550462e-02
    x[2,20]   hard_lower  20
    x[2,20]   hard_upper  20
    x[2,20]   old_TS1   -4.4517462504637229e-01
    x[2,20]   old_TS2   -7.9071070709100921e-01
    x[2,20]   old_TS3   -7.9071070709100921e-01
    x[2,20]   old_TS4   -4.4517462504637229e-01
    x[2,21]   OBJ       3.1952662499999979e-02
    x[2,21]   onehot_2  1
    x[2,21]   w_lb_2_21  -2.2258731252318614e-02
    x[2,21]   w_ub_2_21  -3.9535535354550462e-02
    x[2,21]   hard_lower  21
    x[2,21]   hard_upper  21
    x[2,21]   old_TS1   -4.6743335629869087e-01
    x[2,21]   old_TS2   -8.3024624244555967e-01
    x[2,21]   old_TS3   -8.3024624244555967e-01
    x[2,21]   old_TS4   -4.6743335629869087e-01
    x[2,22]   OBJ       4.2603549999999976e-02
    x[2,22]   onehot_2  1
    x[2,22]   w_lb_2_22  -2.2258731252318614e-02
    x[2,22]   w_ub_2_22  -3.9535535354550462e-02
    x[2,22]   hard_lower  22
    x[2,22]   hard_upper  22
    x[2,22]   old_TS1   -4.8969208755100951e-01
    x[2,22]   old_TS2   -8.6978177780011012e-01
    x[2,22]   old_TS3   -8.6978177780011012e-01
    x[2,22]   old_TS4   -4.8969208755100951e-01
    x[2,23]   OBJ       5.3254437499999981e-02
    x[2,23]   onehot_2  1
    x[2,23]   w_lb_2_23  -2.2258731252318614e-02
    x[2,23]   w_ub_2_23  -3.9535535354550462e-02
    x[2,23]   hard_lower  23
    x[2,23]   hard_upper  23
    x[2,23]   old_TS1   -5.1195081880332816e-01
    x[2,23]   old_TS2   -9.0931731315466058e-01
    x[2,23]   old_TS3   -9.0931731315466058e-01
    x[2,23]   old_TS4   -5.1195081880332816e-01
    x[3,13]   onehot_3  1
    x[3,13]   w_lb_3_13  -2.2258731252318614e-02
    x[3,13]   w_ub_3_13  -3.9535535354550462e-02
    x[3,13]   hard_lower  13
    x[3,13]   hard_upper  13
    x[3,13]   old_TS1   -2.8936350628014196e-01
    x[3,13]   old_TS2   -0.513961959609156
    x[3,13]   old_TS3   -0.513961959609156
    x[3,13]   old_TS4   -2.8936350628014196e-01
    x[4,0]    OBJ       1.8639064285714286e-02
    x[4,0]    onehot_4  1
    x[4,0]    w_lb_4_0  -2.2258731252318614e-02
    x[4,0]    w_ub_4_0  -3.9535535354550462e-02
    x[4,1]    OBJ       1.2426042857142858e-02
    x[4,1]    onehot_4  1
    x[4,1]    w_lb_4_1  -2.2258731252318614e-02
    x[4,1]    w_ub_4_1  -3.9535535354550462e-02
    x[4,1]    hard_lower  1
    x[4,1]    hard_upper  1
    x[4,1]    old_TS1   -2.2258731252318614e-02
    x[4,1]    old_TS2   -3.9535535354550462e-02
    x[4,1]    old_TS3   -3.9535535354550462e-02
    x[4,1]    old_TS4   -2.2258731252318614e-02
    x[4,2]    OBJ       0.00621302142857143
    x[4,2]    onehot_4  1
    x[4,2]    w_lb_4_2  -2.2258731252318614e-02
    x[4,2]    w_ub_4_2  -3.9535535354550462e-02
    x[4,2]    hard_lower  2
    x[4,2]    hard_upper  2
    x[4,2]    old_TS1   -4.4517462504637229e-02
    x[4,2]    old_TS2   -7.9071070709100924e-02
    x[4,2]    old_TS3   -7.9071070709100924e-02
    x[4,2]    old_TS4   -4.4517462504637229e-02
    x[4,3]    OBJ       2.4142438048713188e-18
    x[4,3]    onehot_4  1
    x[4,3]    w_lb_4_3  -2.2258731252318614e-02
    x[4,3]    w_ub_4_3  -3.9535535354550462e-02
    x[4,3]    hard_lower  3
    x[4,3]    hard_upper  3
    x[4,3]    old_TS1   -6.6776193756955843e-02
    x[4,3]    old_TS2   -1.1860660606365139e-01
    x[4,3]    old_TS3   -1.1860660606365139e-01
    x[4,3]    old_TS4   -6.6776193756955843e-02
    x[4,4]    OBJ       -6.2130214285714257e-03
    x[4,4]    onehot_4  1
    x[4,4]    w_lb_4_4  -2.2258731252318614e-02
    x[4,4]    w_ub_4_4  -3.9535535354550462e-02
    x[4,4]    hard_lower  4
    x[4,4]    hard_upper  4
    x[4,4]    old_TS1   -8.9034925009274457e-02
    x[4,4]    old_TS2   -1.5814214141820185e-01
    x[4,4]    old_TS3   -1.5814214141820185e-01
    x[4,4]    old_TS4   -8.9034925009274457e-02
    x[4,5]    OBJ       -1.2426042857142855e-02
    x[4,5]    onehot_4  1
    x[4,5]    w_lb_4_5  -2.2258731252318614e-02
    x[4,5]    w_ub_4_5  -3.9535535354550462e-02
    x[4,5]    hard_lower  5
    x[4,5]    hard_upper  5
    x[4,5]    old_TS1   -1.1129365626159307e-01
    x[4,5]    old_TS2   -1.9767767677275230e-01
    x[4,5]    old_TS3   -1.9767767677275230e-01
    x[4,5]    old_TS4   -1.1129365626159307e-01
    x[4,6]    OBJ       -1.8639064285714282e-02
    x[4,6]    onehot_4  1
    x[4,6]    w_lb_4_6  -2.2258731252318614e-02
    x[4,6]    w_ub_4_6  -3.9535535354550462e-02
    x[4,6]    hard_lower  6
    x[4,6]    hard_upper  6
    x[4,6]    old_TS1   -1.3355238751391169e-01
    x[4,6]    old_TS2   -2.3721321212730279e-01
    x[4,6]    old_TS3   -2.3721321212730279e-01
    x[4,6]    old_TS4   -1.3355238751391169e-01
    x[4,7]    OBJ       -2.4852085714285713e-02
    x[4,7]    onehot_4  1
    x[4,7]    w_lb_4_7  -2.2258731252318614e-02
    x[4,7]    w_ub_4_7  -3.9535535354550462e-02
    x[4,7]    hard_lower  7
    x[4,7]    hard_upper  7
    x[4,7]    old_TS1   -1.5581111876623030e-01
    x[4,7]    old_TS2   -2.7674874748185324e-01
    x[4,7]    old_TS3   -2.7674874748185324e-01
    x[4,7]    old_TS4   -1.5581111876623030e-01
    x[4,8]    OBJ       -1.8639064285714289e-02
    x[4,8]    onehot_4  1
    x[4,8]    w_lb_4_8  -2.2258731252318614e-02
    x[4,8]    w_ub_4_8  -3.9535535354550462e-02
    x[4,8]    hard_lower  8
    x[4,8]    hard_upper  8
    x[4,8]    old_TS1   -1.7806985001854891e-01
    x[4,8]    old_TS2   -3.1628428283640370e-01
    x[4,8]    old_TS3   -3.1628428283640370e-01
    x[4,8]    old_TS4   -1.7806985001854891e-01
    x[4,9]    OBJ       -1.2426042857142860e-02
    x[4,9]    onehot_4  1
    x[4,9]    w_lb_4_9  -2.2258731252318614e-02
    x[4,9]    w_ub_4_9  -3.9535535354550462e-02
    x[4,9]    hard_lower  9
    x[4,9]    hard_upper  9
    x[4,9]    old_TS1   -2.0032858127086753e-01
    x[4,9]    old_TS2   -3.5581981819095415e-01
    x[4,9]    old_TS3   -3.5581981819095415e-01
    x[4,9]    old_TS4   -2.0032858127086753e-01
    x[4,10]   OBJ       -6.2130214285714309e-03
    x[4,10]   onehot_4  1
    x[4,10]   w_lb_4_10  -2.2258731252318614e-02
    x[4,10]   w_ub_4_10  -3.9535535354550462e-02
    x[4,10]   hard_lower  10
    x[4,10]   hard_upper  10
    x[4,10]   old_TS1   -2.2258731252318614e-01
    x[4,10]   old_TS2   -3.9535535354550461e-01
    x[4,10]   old_TS3   -3.9535535354550461e-01
    x[4,10]   old_TS4   -2.2258731252318614e-01
    x[4,11]   OBJ       -2.4142438048713188e-18
    x[4,11]   onehot_4  1
    x[4,11]   w_lb_4_11  -2.2258731252318614e-02
    x[4,11]   w_ub_4_11  -3.9535535354550462e-02
    x[4,11]   hard_lower  11
    x[4,11]   hard_upper  11
    x[4,11]   old_TS1   -2.4484604377550476e-01
    x[4,11]   old_TS2   -4.3489088890005506e-01
    x[4,11]   old_TS3   -4.3489088890005506e-01
    x[4,11]   old_TS4   -2.4484604377550476e-01
    x[4,12]   OBJ       6.2130214285714249e-03
    x[4,12]   onehot_4  1
    x[4,12]   w_lb_4_12  -2.2258731252318614e-02
    x[4,12]   w_ub_4_12  -3.9535535354550462e-02
    x[4,12]   hard_lower  12
    x[4,12]   hard_upper  12
    x[4,12]   old_TS1   -2.6710477502782337e-01
    x[4,12]   old_TS2   -4.7442642425460557e-01
    x[4,12]   old_TS3   -4.7442642425460557e-01
    x[4,12]   old_TS4   -2.6710477502782337e-01
    x[4,13]   OBJ       1.2426042857142853e-02
    x[4,13]   onehot_4  1
    x[4,13]   w_lb_4_13  -2.2258731252318614e-02
    x[4,13]   w_ub_4_13  -3.9535535354550462e-02
    x[4,13]   hard_lower  13
    x[4,13]   hard_upper  13
    x[4,13]   old_TS1   -2.8936350628014196e-01
    x[4,13]   old_TS2   -0.513961959609156
    x[4,13]   old_TS3   -0.513961959609156
    x[4,13]   old_TS4   -2.8936350628014196e-01
    x[4,14]   OBJ       1.8639064285714279e-02
    x[4,14]   onehot_4  1
    x[4,14]   w_lb_4_14  -2.2258731252318614e-02
    x[4,14]   w_ub_4_14  -3.9535535354550462e-02
    x[4,14]   hard_lower  14
    x[4,14]   hard_upper  14
    x[4,14]   old_TS1   -3.1162223753246060e-01
    x[4,14]   old_TS2   -5.5349749496370648e-01
    x[4,14]   old_TS3   -5.5349749496370648e-01
    x[4,14]   old_TS4   -3.1162223753246060e-01
    x[4,15]   OBJ       2.4852085714285710e-02
    x[4,15]   onehot_4  1
    x[4,15]   w_lb_4_15  -2.2258731252318614e-02
    x[4,15]   w_ub_4_15  -3.9535535354550462e-02
    x[4,15]   hard_lower  15
    x[4,15]   hard_upper  15
    x[4,15]   old_TS1   -3.3388096878477924e-01
    x[4,15]   old_TS2   -5.9303303031825694e-01
    x[4,15]   old_TS3   -5.9303303031825694e-01
    x[4,15]   old_TS4   -3.3388096878477924e-01
    x[5,0]    OBJ       2.8402349999999996e-02
    x[5,0]    onehot_5  1
    x[5,0]    w_lb_5_0  -2.2258731252318614e-02
    x[5,0]    w_ub_5_0  -3.9535535354550462e-02
    x[5,1]    OBJ       2.1301762499999995e-02
    x[5,1]    onehot_5  1
    x[5,1]    w_lb_5_1  -2.2258731252318614e-02
    x[5,1]    w_ub_5_1  -3.9535535354550462e-02
    x[5,1]    hard_lower  1
    x[5,1]    hard_upper  1
    x[5,1]    old_TS1   -2.2258731252318614e-02
    x[5,1]    old_TS2   -3.9535535354550462e-02
    x[5,1]    old_TS3   -3.9535535354550462e-02
    x[5,1]    old_TS4   -2.2258731252318614e-02
    x[5,2]    OBJ       1.4201174999999998e-02
    x[5,2]    onehot_5  1
    x[5,2]    w_lb_5_2  -2.2258731252318614e-02
    x[5,2]    w_ub_5_2  -3.9535535354550462e-02
    x[5,2]    hard_lower  2
    x[5,2]    hard_upper  2
    x[5,2]    old_TS1   -4.4517462504637229e-02
    x[5,2]    old_TS2   -7.9071070709100924e-02
    x[5,2]    old_TS3   -7.9071070709100924e-02
    x[5,2]    old_TS4   -4.4517462504637229e-02
    x[5,3]    OBJ       7.1005874999999991e-03
    x[5,3]    onehot_5  1
    x[5,3]    w_lb_5_3  -2.2258731252318614e-02
    x[5,3]    w_ub_5_3  -3.9535535354550462e-02
    x[5,3]    hard_lower  3
    x[5,3]    hard_upper  3
    x[5,3]    old_TS1   -6.6776193756955843e-02
    x[5,3]    old_TS2   -1.1860660606365139e-01
    x[5,3]    old_TS3   -1.1860660606365139e-01
    x[5,3]    old_TS4   -6.6776193756955843e-02
    x[5,4]    onehot_5  1
    x[5,4]    w_lb_5_4  -2.2258731252318614e-02
    x[5,4]    w_ub_5_4  -3.9535535354550462e-02
    x[5,4]    hard_lower  4
    x[5,4]    hard_upper  4
    x[5,4]    old_TS1   -8.9034925009274457e-02
    x[5,4]    old_TS2   -1.5814214141820185e-01
    x[5,4]    old_TS3   -1.5814214141820185e-01
    x[5,4]    old_TS4   -8.9034925009274457e-02
    x[5,5]    OBJ       -7.1005874999999991e-03
    x[5,5]    onehot_5  1
    x[5,5]    w_lb_5_5  -2.2258731252318614e-02
    x[5,5]    w_ub_5_5  -3.9535535354550462e-02
    x[5,5]    hard_lower  5
    x[5,5]    hard_upper  5
    x[5,5]    old_TS1   -1.1129365626159307e-01
    x[5,5]    old_TS2   -1.9767767677275230e-01
    x[5,5]    old_TS3   -1.9767767677275230e-01
    x[5,5]    old_TS4   -1.1129365626159307e-01
    x[5,6]    OBJ       -1.4201174999999998e-02
    x[5,6]    onehot_5  1
    x[5,6]    w_lb_5_6  -2.2258731252318614e-02
    x[5,6]    w_ub_5_6  -3.9535535354550462e-02
    x[5,6]    hard_lower  6
    x[5,6]    hard_upper  6
    x[5,6]    old_TS1   -1.3355238751391169e-01
    x[5,6]    old_TS2   -2.3721321212730279e-01
    x[5,6]    old_TS3   -2.3721321212730279e-01
    x[5,6]    old_TS4   -1.3355238751391169e-01
    x[5,7]    OBJ       -2.1301762499999998e-02
    x[5,7]    onehot_5  1
    x[5,7]    w_lb_5_7  -2.2258731252318614e-02
    x[5,7]    w_ub_5_7  -3.9535535354550462e-02
    x[5,7]    hard_lower  7
    x[5,7]    hard_upper  7
    x[5,7]    old_TS1   -1.5581111876623030e-01
    x[5,7]    old_TS2   -2.7674874748185324e-01
    x[5,7]    old_TS3   -2.7674874748185324e-01
    x[5,7]    old_TS4   -1.5581111876623030e-01
    x[5,8]    OBJ       -2.8402349999999996e-02
    x[5,8]    onehot_5  1
    x[5,8]    w_lb_5_8  -2.2258731252318614e-02
    x[5,8]    w_ub_5_8  -3.9535535354550462e-02
    x[5,8]    hard_lower  8
    x[5,8]    hard_upper  8
    x[5,8]    old_TS1   -1.7806985001854891e-01
    x[5,8]    old_TS2   -3.1628428283640370e-01
    x[5,8]    old_TS3   -3.1628428283640370e-01
    x[5,8]    old_TS4   -1.7806985001854891e-01
    x[5,9]    OBJ       -2.1301762499999998e-02
    x[5,9]    onehot_5  1
    x[5,9]    w_lb_5_9  -2.2258731252318614e-02
    x[5,9]    w_ub_5_9  -3.9535535354550462e-02
    x[5,9]    hard_lower  9
    x[5,9]    hard_upper  9
    x[5,9]    old_TS1   -2.0032858127086753e-01
    x[5,9]    old_TS2   -3.5581981819095415e-01
    x[5,9]    old_TS3   -3.5581981819095415e-01
    x[5,9]    old_TS4   -2.0032858127086753e-01
    x[5,10]   OBJ       -1.4201174999999998e-02
    x[5,10]   onehot_5  1
    x[5,10]   w_lb_5_10  -2.2258731252318614e-02
    x[5,10]   w_ub_5_10  -3.9535535354550462e-02
    x[5,10]   hard_lower  10
    x[5,10]   hard_upper  10
    x[5,10]   old_TS1   -2.2258731252318614e-01
    x[5,10]   old_TS2   -3.9535535354550461e-01
    x[5,10]   old_TS3   -3.9535535354550461e-01
    x[5,10]   old_TS4   -2.2258731252318614e-01
    x[5,11]   OBJ       -7.1005874999999991e-03
    x[5,11]   onehot_5  1
    x[5,11]   w_lb_5_11  -2.2258731252318614e-02
    x[5,11]   w_ub_5_11  -3.9535535354550462e-02
    x[5,11]   hard_lower  11
    x[5,11]   hard_upper  11
    x[5,11]   old_TS1   -2.4484604377550476e-01
    x[5,11]   old_TS2   -4.3489088890005506e-01
    x[5,11]   old_TS3   -4.3489088890005506e-01
    x[5,11]   old_TS4   -2.4484604377550476e-01
    x[5,12]   onehot_5  1
    x[5,12]   w_lb_5_12  -2.2258731252318614e-02
    x[5,12]   w_ub_5_12  -3.9535535354550462e-02
    x[5,12]   hard_lower  12
    x[5,12]   hard_upper  12
    x[5,12]   old_TS1   -2.6710477502782337e-01
    x[5,12]   old_TS2   -4.7442642425460557e-01
    x[5,12]   old_TS3   -4.7442642425460557e-01
    x[5,12]   old_TS4   -2.6710477502782337e-01
    x[5,13]   OBJ       7.1005874999999991e-03
    x[5,13]   onehot_5  1
    x[5,13]   w_lb_5_13  -2.2258731252318614e-02
    x[5,13]   w_ub_5_13  -3.9535535354550462e-02
    x[5,13]   hard_lower  13
    x[5,13]   hard_upper  13
    x[5,13]   old_TS1   -2.8936350628014196e-01
    x[5,13]   old_TS2   -0.513961959609156
    x[5,13]   old_TS3   -0.513961959609156
    x[5,13]   old_TS4   -2.8936350628014196e-01
    x[5,14]   OBJ       1.4201174999999998e-02
    x[5,14]   onehot_5  1
    x[5,14]   w_lb_5_14  -2.2258731252318614e-02
    x[5,14]   w_ub_5_14  -3.9535535354550462e-02
    x[5,14]   hard_lower  14
    x[5,14]   hard_upper  14
    x[5,14]   old_TS1   -3.1162223753246060e-01
    x[5,14]   old_TS2   -5.5349749496370648e-01
    x[5,14]   old_TS3   -5.5349749496370648e-01
    x[5,14]   old_TS4   -3.1162223753246060e-01
    x[5,15]   OBJ       2.1301762499999995e-02
    x[5,15]   onehot_5  1
    x[5,15]   w_lb_5_15  -2.2258731252318614e-02
    x[5,15]   w_ub_5_15  -3.9535535354550462e-02
    x[5,15]   hard_lower  15
    x[5,15]   hard_upper  15
    x[5,15]   old_TS1   -3.3388096878477924e-01
    x[5,15]   old_TS2   -5.9303303031825694e-01
    x[5,15]   old_TS3   -5.9303303031825694e-01
    x[5,15]   old_TS4   -3.3388096878477924e-01
    x[6,4]    onehot_6  1
    x[6,4]    w_lb_6_4  -2.2258731252318614e-02
    x[6,4]    w_ub_6_4  -3.9535535354550462e-02
    x[6,4]    hard_lower  4
    x[6,4]    hard_upper  4
    x[6,4]    old_TS1   -8.9034925009274457e-02
    x[6,4]    old_TS2   -1.5814214141820185e-01
    x[6,4]    old_TS3   -1.5814214141820185e-01
    x[6,4]    old_TS4   -8.9034925009274457e-02
    x[7,0]    OBJ       4.4378699999999993e-02
    x[7,0]    onehot_7  1
    x[7,0]    w_lb_7_0  -2.2258731252318614e-02
    x[7,0]    w_ub_7_0  -3.9535535354550462e-02
    x[7,1]    OBJ       3.5502959999999993e-02
    x[7,1]    onehot_7  1
    x[7,1]    w_lb_7_1  -2.2258731252318614e-02
    x[7,1]    w_ub_7_1  -3.9535535354550462e-02
    x[7,1]    hard_lower  1
    x[7,1]    hard_upper  1
    x[7,1]    old_TS1   -2.2258731252318614e-02
    x[7,1]    old_TS2   -3.9535535354550462e-02
    x[7,1]    old_TS3   -3.9535535354550462e-02
    x[7,1]    old_TS4   -2.2258731252318614e-02
    x[7,2]    OBJ       2.6627219999999997e-02
    x[7,2]    onehot_7  1
    x[7,2]    w_lb_7_2  -2.2258731252318614e-02
    x[7,2]    w_ub_7_2  -3.9535535354550462e-02
    x[7,2]    hard_lower  2
    x[7,2]    hard_upper  2
    x[7,2]    old_TS1   -4.4517462504637229e-02
    x[7,2]    old_TS2   -7.9071070709100924e-02
    x[7,2]    old_TS3   -7.9071070709100924e-02
    x[7,2]    old_TS4   -4.4517462504637229e-02
    x[7,3]    OBJ       1.7751479999999993e-02
    x[7,3]    onehot_7  1
    x[7,3]    w_lb_7_3  -2.2258731252318614e-02
    x[7,3]    w_ub_7_3  -3.9535535354550462e-02
    x[7,3]    hard_lower  3
    x[7,3]    hard_upper  3
    x[7,3]    old_TS1   -6.6776193756955843e-02
    x[7,3]    old_TS2   -1.1860660606365139e-01
    x[7,3]    old_TS3   -1.1860660606365139e-01
    x[7,3]    old_TS4   -6.6776193756955843e-02
    x[7,4]    OBJ       8.8757399999999948e-03
    x[7,4]    onehot_7  1
    x[7,4]    w_lb_7_4  -2.2258731252318614e-02
    x[7,4]    w_ub_7_4  -3.9535535354550462e-02
    x[7,4]    hard_lower  4
    x[7,4]    hard_upper  4
    x[7,4]    old_TS1   -8.9034925009274457e-02
    x[7,4]    old_TS2   -1.5814214141820185e-01
    x[7,4]    old_TS3   -1.5814214141820185e-01
    x[7,4]    old_TS4   -8.9034925009274457e-02
    x[7,5]    OBJ       -4.9270254542932435e-18
    x[7,5]    onehot_7  1
    x[7,5]    w_lb_7_5  -2.2258731252318614e-02
    x[7,5]    w_ub_7_5  -3.9535535354550462e-02
    x[7,5]    hard_lower  5
    x[7,5]    hard_upper  5
    x[7,5]    old_TS1   -1.1129365626159307e-01
    x[7,5]    old_TS2   -1.9767767677275230e-01
    x[7,5]    old_TS3   -1.9767767677275230e-01
    x[7,5]    old_TS4   -1.1129365626159307e-01
    x[7,6]    OBJ       -8.8757400000000070e-03
    x[7,6]    onehot_7  1
    x[7,6]    w_lb_7_6  -2.2258731252318614e-02
    x[7,6]    w_ub_7_6  -3.9535535354550462e-02
    x[7,6]    hard_lower  6
    x[7,6]    hard_upper  6
    x[7,6]    old_TS1   -1.3355238751391169e-01
    x[7,6]    old_TS2   -2.3721321212730279e-01
    x[7,6]    old_TS3   -2.3721321212730279e-01
    x[7,6]    old_TS4   -1.3355238751391169e-01
    x[7,7]    OBJ       -1.7751480000000007e-02
    x[7,7]    onehot_7  1
    x[7,7]    w_lb_7_7  -2.2258731252318614e-02
    x[7,7]    w_ub_7_7  -3.9535535354550462e-02
    x[7,7]    hard_lower  7
    x[7,7]    hard_upper  7
    x[7,7]    old_TS1   -1.5581111876623030e-01
    x[7,7]    old_TS2   -2.7674874748185324e-01
    x[7,7]    old_TS3   -2.7674874748185324e-01
    x[7,7]    old_TS4   -1.5581111876623030e-01
    x[7,8]    OBJ       -2.6627220000000007e-02
    x[7,8]    onehot_7  1
    x[7,8]    w_lb_7_8  -2.2258731252318614e-02
    x[7,8]    w_ub_7_8  -3.9535535354550462e-02
    x[7,8]    hard_lower  8
    x[7,8]    hard_upper  8
    x[7,8]    old_TS1   -1.7806985001854891e-01
    x[7,8]    old_TS2   -3.1628428283640370e-01
    x[7,8]    old_TS3   -3.1628428283640370e-01
    x[7,8]    old_TS4   -1.7806985001854891e-01
    x[7,9]    OBJ       -3.5502960000000007e-02
    x[7,9]    onehot_7  1
    x[7,9]    w_lb_7_9  -2.2258731252318614e-02
    x[7,9]    w_ub_7_9  -3.9535535354550462e-02
    x[7,9]    hard_lower  9
    x[7,9]    hard_upper  9
    x[7,9]    old_TS1   -2.0032858127086753e-01
    x[7,9]    old_TS2   -3.5581981819095415e-01
    x[7,9]    old_TS3   -3.5581981819095415e-01
    x[7,9]    old_TS4   -2.0032858127086753e-01
    x[7,10]   OBJ       -0.0443787
    x[7,10]   onehot_7  1
    x[7,10]   w_lb_7_10  -2.2258731252318614e-02
    x[7,10]   w_ub_7_10  -3.9535535354550462e-02
    x[7,10]   hard_lower  10
    x[7,10]   hard_upper  10
    x[7,10]   old_TS1   -2.2258731252318614e-01
    x[7,10]   old_TS2   -3.9535535354550461e-01
    x[7,10]   old_TS3   -3.9535535354550461e-01
    x[7,10]   old_TS4   -2.2258731252318614e-01
    x[7,11]   OBJ       -0.03550296
    x[7,11]   onehot_7  1
    x[7,11]   w_lb_7_11  -2.2258731252318614e-02
    x[7,11]   w_ub_7_11  -3.9535535354550462e-02
    x[7,11]   hard_lower  11
    x[7,11]   hard_upper  11
    x[7,11]   old_TS1   -2.4484604377550476e-01
    x[7,11]   old_TS2   -4.3489088890005506e-01
    x[7,11]   old_TS3   -4.3489088890005506e-01
    x[7,11]   old_TS4   -2.4484604377550476e-01
    x[7,12]   OBJ       -0.02662722
    x[7,12]   onehot_7  1
    x[7,12]   w_lb_7_12  -2.2258731252318614e-02
    x[7,12]   w_ub_7_12  -3.9535535354550462e-02
    x[7,12]   hard_lower  12
    x[7,12]   hard_upper  12
    x[7,12]   old_TS1   -2.6710477502782337e-01
    x[7,12]   old_TS2   -4.7442642425460557e-01
    x[7,12]   old_TS3   -4.7442642425460557e-01
    x[7,12]   old_TS4   -2.6710477502782337e-01
    x[7,13]   OBJ       -1.7751479999999997e-02
    x[7,13]   onehot_7  1
    x[7,13]   w_lb_7_13  -2.2258731252318614e-02
    x[7,13]   w_ub_7_13  -3.9535535354550462e-02
    x[7,13]   hard_lower  13
    x[7,13]   hard_upper  13
    x[7,13]   old_TS1   -2.8936350628014196e-01
    x[7,13]   old_TS2   -0.513961959609156
    x[7,13]   old_TS3   -0.513961959609156
    x[7,13]   old_TS4   -2.8936350628014196e-01
    x[7,14]   OBJ       -8.8757399999999965e-03
    x[7,14]   onehot_7  1
    x[7,14]   w_lb_7_14  -2.2258731252318614e-02
    x[7,14]   w_ub_7_14  -3.9535535354550462e-02
    x[7,14]   hard_lower  14
    x[7,14]   hard_upper  14
    x[7,14]   old_TS1   -3.1162223753246060e-01
    x[7,14]   old_TS2   -5.5349749496370648e-01
    x[7,14]   old_TS3   -5.5349749496370648e-01
    x[7,14]   old_TS4   -3.1162223753246060e-01
    x[7,15]   OBJ       4.9270254542932435e-18
    x[7,15]   onehot_7  1
    x[7,15]   w_lb_7_15  -2.2258731252318614e-02
    x[7,15]   w_ub_7_15  -3.9535535354550462e-02
    x[7,15]   hard_lower  15
    x[7,15]   hard_upper  15
    x[7,15]   old_TS1   -3.3388096878477924e-01
    x[7,15]   old_TS2   -5.9303303031825694e-01
    x[7,15]   old_TS3   -5.9303303031825694e-01
    x[7,15]   old_TS4   -3.3388096878477924e-01
    x[7,16]   OBJ       8.8757400000000052e-03
    x[7,16]   onehot_7  1
    x[7,16]   w_lb_7_16  -2.2258731252318614e-02
    x[7,16]   w_ub_7_16  -3.9535535354550462e-02
    x[7,16]   hard_lower  16
    x[7,16]   hard_upper  16
    x[7,16]   old_TS1   -3.5613970003709783e-01
    x[7,16]   old_TS2   -6.3256856567280739e-01
    x[7,16]   old_TS3   -6.3256856567280739e-01
    x[7,16]   old_TS4   -3.5613970003709783e-01
    x[7,17]   OBJ       1.7751480000000004e-02
    x[7,17]   onehot_7  1
    x[7,17]   w_lb_7_17  -2.2258731252318614e-02
    x[7,17]   w_ub_7_17  -3.9535535354550462e-02
    x[7,17]   hard_lower  17
    x[7,17]   hard_upper  17
    x[7,17]   old_TS1   -3.7839843128941641e-01
    x[7,17]   old_TS2   -6.7210410102735785e-01
    x[7,17]   old_TS3   -6.7210410102735785e-01
    x[7,17]   old_TS4   -3.7839843128941641e-01
    x[7,18]   OBJ       2.6627220000000004e-02
    x[7,18]   onehot_7  1
    x[7,18]   w_lb_7_18  -2.2258731252318614e-02
    x[7,18]   w_ub_7_18  -3.9535535354550462e-02
    x[7,18]   hard_lower  18
    x[7,18]   hard_upper  18
    x[7,18]   old_TS1   -4.0065716254173506e-01
    x[7,18]   old_TS2   -7.1163963638190830e-01
    x[7,18]   old_TS3   -7.1163963638190830e-01
    x[7,18]   old_TS4   -4.0065716254173506e-01
    x[7,19]   OBJ       0.03550296
    x[7,19]   onehot_7  1
    x[7,19]   w_lb_7_19  -2.2258731252318614e-02
    x[7,19]   w_ub_7_19  -3.9535535354550462e-02
    x[7,19]   hard_lower  19
    x[7,19]   hard_upper  19
    x[7,19]   old_TS1   -4.2291589379405370e-01
    x[7,19]   old_TS2   -7.5117517173645876e-01
    x[7,19]   old_TS3   -7.5117517173645876e-01
    x[7,19]   old_TS4   -4.2291589379405370e-01
    x[8,0]    OBJ       1.8639064285714286e-02
    x[8,0]    onehot_8  1
    x[8,0]    w_lb_8_0  -2.2258731252318614e-02
    x[8,0]    w_ub_8_0  -3.9535535354550462e-02
    x[8,1]    OBJ       1.2426042857142858e-02
    x[8,1]    onehot_8  1
    x[8,1]    w_lb_8_1  -2.2258731252318614e-02
    x[8,1]    w_ub_8_1  -3.9535535354550462e-02
    x[8,1]    hard_lower  1
    x[8,1]    hard_upper  1
    x[8,1]    old_TS1   -2.2258731252318614e-02
    x[8,1]    old_TS2   -3.9535535354550462e-02
    x[8,1]    old_TS3   -3.9535535354550462e-02
    x[8,1]    old_TS4   -2.2258731252318614e-02
    x[8,2]    OBJ       0.00621302142857143
    x[8,2]    onehot_8  1
    x[8,2]    w_lb_8_2  -2.2258731252318614e-02
    x[8,2]    w_ub_8_2  -3.9535535354550462e-02
    x[8,2]    hard_lower  2
    x[8,2]    hard_upper  2
    x[8,2]    old_TS1   -4.4517462504637229e-02
    x[8,2]    old_TS2   -7.9071070709100924e-02
    x[8,2]    old_TS3   -7.9071070709100924e-02
    x[8,2]    old_TS4   -4.4517462504637229e-02
    x[8,3]    OBJ       2.4142438048713188e-18
    x[8,3]    onehot_8  1
    x[8,3]    w_lb_8_3  -2.2258731252318614e-02
    x[8,3]    w_ub_8_3  -3.9535535354550462e-02
    x[8,3]    hard_lower  3
    x[8,3]    hard_upper  3
    x[8,3]    old_TS1   -6.6776193756955843e-02
    x[8,3]    old_TS2   -1.1860660606365139e-01
    x[8,3]    old_TS3   -1.1860660606365139e-01
    x[8,3]    old_TS4   -6.6776193756955843e-02
    x[8,4]    OBJ       -6.2130214285714257e-03
    x[8,4]    onehot_8  1
    x[8,4]    w_lb_8_4  -2.2258731252318614e-02
    x[8,4]    w_ub_8_4  -3.9535535354550462e-02
    x[8,4]    hard_lower  4
    x[8,4]    hard_upper  4
    x[8,4]    old_TS1   -8.9034925009274457e-02
    x[8,4]    old_TS2   -1.5814214141820185e-01
    x[8,4]    old_TS3   -1.5814214141820185e-01
    x[8,4]    old_TS4   -8.9034925009274457e-02
    x[8,5]    OBJ       -1.2426042857142855e-02
    x[8,5]    onehot_8  1
    x[8,5]    w_lb_8_5  -2.2258731252318614e-02
    x[8,5]    w_ub_8_5  -3.9535535354550462e-02
    x[8,5]    hard_lower  5
    x[8,5]    hard_upper  5
    x[8,5]    old_TS1   -1.1129365626159307e-01
    x[8,5]    old_TS2   -1.9767767677275230e-01
    x[8,5]    old_TS3   -1.9767767677275230e-01
    x[8,5]    old_TS4   -1.1129365626159307e-01
    x[8,6]    OBJ       -1.8639064285714282e-02
    x[8,6]    onehot_8  1
    x[8,6]    w_lb_8_6  -2.2258731252318614e-02
    x[8,6]    w_ub_8_6  -3.9535535354550462e-02
    x[8,6]    hard_lower  6
    x[8,6]    hard_upper  6
    x[8,6]    old_TS1   -1.3355238751391169e-01
    x[8,6]    old_TS2   -2.3721321212730279e-01
    x[8,6]    old_TS3   -2.3721321212730279e-01
    x[8,6]    old_TS4   -1.3355238751391169e-01
    x[8,7]    OBJ       -2.4852085714285713e-02
    x[8,7]    onehot_8  1
    x[8,7]    w_lb_8_7  -2.2258731252318614e-02
    x[8,7]    w_ub_8_7  -3.9535535354550462e-02
    x[8,7]    hard_lower  7
    x[8,7]    hard_upper  7
    x[8,7]    old_TS1   -1.5581111876623030e-01
    x[8,7]    old_TS2   -2.7674874748185324e-01
    x[8,7]    old_TS3   -2.7674874748185324e-01
    x[8,7]    old_TS4   -1.5581111876623030e-01
    x[8,8]    OBJ       -1.8639064285714289e-02
    x[8,8]    onehot_8  1
    x[8,8]    w_lb_8_8  -2.2258731252318614e-02
    x[8,8]    w_ub_8_8  -3.9535535354550462e-02
    x[8,8]    hard_lower  8
    x[8,8]    hard_upper  8
    x[8,8]    old_TS1   -1.7806985001854891e-01
    x[8,8]    old_TS2   -3.1628428283640370e-01
    x[8,8]    old_TS3   -3.1628428283640370e-01
    x[8,8]    old_TS4   -1.7806985001854891e-01
    x[8,9]    OBJ       -1.2426042857142860e-02
    x[8,9]    onehot_8  1
    x[8,9]    w_lb_8_9  -2.2258731252318614e-02
    x[8,9]    w_ub_8_9  -3.9535535354550462e-02
    x[8,9]    hard_lower  9
    x[8,9]    hard_upper  9
    x[8,9]    old_TS1   -2.0032858127086753e-01
    x[8,9]    old_TS2   -3.5581981819095415e-01
    x[8,9]    old_TS3   -3.5581981819095415e-01
    x[8,9]    old_TS4   -2.0032858127086753e-01
    x[8,10]   OBJ       -6.2130214285714309e-03
    x[8,10]   onehot_8  1
    x[8,10]   w_lb_8_10  -2.2258731252318614e-02
    x[8,10]   w_ub_8_10  -3.9535535354550462e-02
    x[8,10]   hard_lower  10
    x[8,10]   hard_upper  10
    x[8,10]   old_TS1   -2.2258731252318614e-01
    x[8,10]   old_TS2   -3.9535535354550461e-01
    x[8,10]   old_TS3   -3.9535535354550461e-01
    x[8,10]   old_TS4   -2.2258731252318614e-01
    x[8,11]   OBJ       -2.4142438048713188e-18
    x[8,11]   onehot_8  1
    x[8,11]   w_lb_8_11  -2.2258731252318614e-02
    x[8,11]   w_ub_8_11  -3.9535535354550462e-02
    x[8,11]   hard_lower  11
    x[8,11]   hard_upper  11
    x[8,11]   old_TS1   -2.4484604377550476e-01
    x[8,11]   old_TS2   -4.3489088890005506e-01
    x[8,11]   old_TS3   -4.3489088890005506e-01
    x[8,11]   old_TS4   -2.4484604377550476e-01
    x[8,12]   OBJ       6.2130214285714249e-03
    x[8,12]   onehot_8  1
    x[8,12]   w_lb_8_12  -2.2258731252318614e-02
    x[8,12]   w_ub_8_12  -3.9535535354550462e-02
    x[8,12]   hard_lower  12
    x[8,12]   hard_upper  12
    x[8,12]   old_TS1   -2.6710477502782337e-01
    x[8,12]   old_TS2   -4.7442642425460557e-01
    x[8,12]   old_TS3   -4.7442642425460557e-01
    x[8,12]   old_TS4   -2.6710477502782337e-01
    x[8,13]   OBJ       1.2426042857142853e-02
    x[8,13]   onehot_8  1
    x[8,13]   w_lb_8_13  -2.2258731252318614e-02
    x[8,13]   w_ub_8_13  -3.9535535354550462e-02
    x[8,13]   hard_lower  13
    x[8,13]   hard_upper  13
    x[8,13]   old_TS1   -2.8936350628014196e-01
    x[8,13]   old_TS2   -0.513961959609156
    x[8,13]   old_TS3   -0.513961959609156
    x[8,13]   old_TS4   -2.8936350628014196e-01
    x[8,14]   OBJ       1.8639064285714279e-02
    x[8,14]   onehot_8  1
    x[8,14]   w_lb_8_14  -2.2258731252318614e-02
    x[8,14]   w_ub_8_14  -3.9535535354550462e-02
    x[8,14]   hard_lower  14
    x[8,14]   hard_upper  14
    x[8,14]   old_TS1   -3.1162223753246060e-01
    x[8,14]   old_TS2   -5.5349749496370648e-01
    x[8,14]   old_TS3   -5.5349749496370648e-01
    x[8,14]   old_TS4   -3.1162223753246060e-01
    x[8,15]   OBJ       2.4852085714285710e-02
    x[8,15]   onehot_8  1
    x[8,15]   w_lb_8_15  -2.2258731252318614e-02
    x[8,15]   w_ub_8_15  -3.9535535354550462e-02
    x[8,15]   hard_lower  15
    x[8,15]   hard_upper  15
    x[8,15]   old_TS1   -3.3388096878477924e-01
    x[8,15]   old_TS2   -5.9303303031825694e-01
    x[8,15]   old_TS3   -5.9303303031825694e-01
    x[8,15]   old_TS4   -3.3388096878477924e-01
    x[9,0]    OBJ       4.4378699999999993e-02
    x[9,0]    onehot_9  1
    x[9,0]    w_lb_9_0  -2.2258731252318614e-02
    x[9,0]    w_ub_9_0  -3.9535535354550462e-02
    x[9,1]    OBJ       3.5502959999999993e-02
    x[9,1]    onehot_9  1
    x[9,1]    w_lb_9_1  -2.2258731252318614e-02
    x[9,1]    w_ub_9_1  -3.9535535354550462e-02
    x[9,1]    hard_lower  1
    x[9,1]    hard_upper  1
    x[9,1]    old_TS1   -2.2258731252318614e-02
    x[9,1]    old_TS2   -3.9535535354550462e-02
    x[9,1]    old_TS3   -3.9535535354550462e-02
    x[9,1]    old_TS4   -2.2258731252318614e-02
    x[9,2]    OBJ       2.6627219999999997e-02
    x[9,2]    onehot_9  1
    x[9,2]    w_lb_9_2  -2.2258731252318614e-02
    x[9,2]    w_ub_9_2  -3.9535535354550462e-02
    x[9,2]    hard_lower  2
    x[9,2]    hard_upper  2
    x[9,2]    old_TS1   -4.4517462504637229e-02
    x[9,2]    old_TS2   -7.9071070709100924e-02
    x[9,2]    old_TS3   -7.9071070709100924e-02
    x[9,2]    old_TS4   -4.4517462504637229e-02
    x[9,3]    OBJ       1.7751479999999993e-02
    x[9,3]    onehot_9  1
    x[9,3]    w_lb_9_3  -2.2258731252318614e-02
    x[9,3]    w_ub_9_3  -3.9535535354550462e-02
    x[9,3]    hard_lower  3
    x[9,3]    hard_upper  3
    x[9,3]    old_TS1   -6.6776193756955843e-02
    x[9,3]    old_TS2   -1.1860660606365139e-01
    x[9,3]    old_TS3   -1.1860660606365139e-01
    x[9,3]    old_TS4   -6.6776193756955843e-02
    x[9,4]    OBJ       8.8757399999999948e-03
    x[9,4]    onehot_9  1
    x[9,4]    w_lb_9_4  -2.2258731252318614e-02
    x[9,4]    w_ub_9_4  -3.9535535354550462e-02
    x[9,4]    hard_lower  4
    x[9,4]    hard_upper  4
    x[9,4]    old_TS1   -8.9034925009274457e-02
    x[9,4]    old_TS2   -1.5814214141820185e-01
    x[9,4]    old_TS3   -1.5814214141820185e-01
    x[9,4]    old_TS4   -8.9034925009274457e-02
    x[9,5]    OBJ       -4.9270254542932435e-18
    x[9,5]    onehot_9  1
    x[9,5]    w_lb_9_5  -2.2258731252318614e-02
    x[9,5]    w_ub_9_5  -3.9535535354550462e-02
    x[9,5]    hard_lower  5
    x[9,5]    hard_upper  5
    x[9,5]    old_TS1   -1.1129365626159307e-01
    x[9,5]    old_TS2   -1.9767767677275230e-01
    x[9,5]    old_TS3   -1.9767767677275230e-01
    x[9,5]    old_TS4   -1.1129365626159307e-01
    x[9,6]    OBJ       -8.8757400000000070e-03
    x[9,6]    onehot_9  1
    x[9,6]    w_lb_9_6  -2.2258731252318614e-02
    x[9,6]    w_ub_9_6  -3.9535535354550462e-02
    x[9,6]    hard_lower  6
    x[9,6]    hard_upper  6
    x[9,6]    old_TS1   -1.3355238751391169e-01
    x[9,6]    old_TS2   -2.3721321212730279e-01
    x[9,6]    old_TS3   -2.3721321212730279e-01
    x[9,6]    old_TS4   -1.3355238751391169e-01
    x[9,7]    OBJ       -1.7751480000000007e-02
    x[9,7]    onehot_9  1
    x[9,7]    w_lb_9_7  -2.2258731252318614e-02
    x[9,7]    w_ub_9_7  -3.9535535354550462e-02
    x[9,7]    hard_lower  7
    x[9,7]    hard_upper  7
    x[9,7]    old_TS1   -1.5581111876623030e-01
    x[9,7]    old_TS2   -2.7674874748185324e-01
    x[9,7]    old_TS3   -2.7674874748185324e-01
    x[9,7]    old_TS4   -1.5581111876623030e-01
    x[9,8]    OBJ       -2.6627220000000007e-02
    x[9,8]    onehot_9  1
    x[9,8]    w_lb_9_8  -2.2258731252318614e-02
    x[9,8]    w_ub_9_8  -3.9535535354550462e-02
    x[9,8]    hard_lower  8
    x[9,8]    hard_upper  8
    x[9,8]    old_TS1   -1.7806985001854891e-01
    x[9,8]    old_TS2   -3.1628428283640370e-01
    x[9,8]    old_TS3   -3.1628428283640370e-01
    x[9,8]    old_TS4   -1.7806985001854891e-01
    x[9,9]    OBJ       -3.5502960000000007e-02
    x[9,9]    onehot_9  1
    x[9,9]    w_lb_9_9  -2.2258731252318614e-02
    x[9,9]    w_ub_9_9  -3.9535535354550462e-02
    x[9,9]    hard_lower  9
    x[9,9]    hard_upper  9
    x[9,9]    old_TS1   -2.0032858127086753e-01
    x[9,9]    old_TS2   -3.5581981819095415e-01
    x[9,9]    old_TS3   -3.5581981819095415e-01
    x[9,9]    old_TS4   -2.0032858127086753e-01
    x[9,10]   OBJ       -0.0443787
    x[9,10]   onehot_9  1
    x[9,10]   w_lb_9_10  -2.2258731252318614e-02
    x[9,10]   w_ub_9_10  -3.9535535354550462e-02
    x[9,10]   hard_lower  10
    x[9,10]   hard_upper  10
    x[9,10]   old_TS1   -2.2258731252318614e-01
    x[9,10]   old_TS2   -3.9535535354550461e-01
    x[9,10]   old_TS3   -3.9535535354550461e-01
    x[9,10]   old_TS4   -2.2258731252318614e-01
    x[9,11]   OBJ       -0.03550296
    x[9,11]   onehot_9  1
    x[9,11]   w_lb_9_11  -2.2258731252318614e-02
    x[9,11]   w_ub_9_11  -3.9535535354550462e-02
    x[9,11]   hard_lower  11
    x[9,11]   hard_upper  11
    x[9,11]   old_TS1   -2.4484604377550476e-01
    x[9,11]   old_TS2   -4.3489088890005506e-01
    x[9,11]   old_TS3   -4.3489088890005506e-01
    x[9,11]   old_TS4   -2.4484604377550476e-01
    x[9,12]   OBJ       -0.02662722
    x[9,12]   onehot_9  1
    x[9,12]   w_lb_9_12  -2.2258731252318614e-02
    x[9,12]   w_ub_9_12  -3.9535535354550462e-02
    x[9,12]   hard_lower  12
    x[9,12]   hard_upper  12
    x[9,12]   old_TS1   -2.6710477502782337e-01
    x[9,12]   old_TS2   -4.7442642425460557e-01
    x[9,12]   old_TS3   -4.7442642425460557e-01
    x[9,12]   old_TS4   -2.6710477502782337e-01
    x[9,13]   OBJ       -1.7751479999999997e-02
    x[9,13]   onehot_9  1
    x[9,13]   w_lb_9_13  -2.2258731252318614e-02
    x[9,13]   w_ub_9_13  -3.9535535354550462e-02
    x[9,13]   hard_lower  13
    x[9,13]   hard_upper  13
    x[9,13]   old_TS1   -2.8936350628014196e-01
    x[9,13]   old_TS2   -0.513961959609156
    x[9,13]   old_TS3   -0.513961959609156
    x[9,13]   old_TS4   -2.8936350628014196e-01
    x[9,14]   OBJ       -8.8757399999999965e-03
    x[9,14]   onehot_9  1
    x[9,14]   w_lb_9_14  -2.2258731252318614e-02
    x[9,14]   w_ub_9_14  -3.9535535354550462e-02
    x[9,14]   hard_lower  14
    x[9,14]   hard_upper  14
    x[9,14]   old_TS1   -3.1162223753246060e-01
    x[9,14]   old_TS2   -5.5349749496370648e-01
    x[9,14]   old_TS3   -5.5349749496370648e-01
    x[9,14]   old_TS4   -3.1162223753246060e-01
    x[10,0]   OBJ       1.5976349999999997e-02
    x[10,0]   onehot_10  1
    x[10,0]   w_lb_10_0  -2.2258731252318614e-02
    x[10,0]   w_ub_10_0  -3.9535535354550462e-02
    x[10,1]   OBJ       1.0650899999999998e-02
    x[10,1]   onehot_10  1
    x[10,1]   w_lb_10_1  -2.2258731252318614e-02
    x[10,1]   w_ub_10_1  -3.9535535354550462e-02
    x[10,1]   hard_lower  1
    x[10,1]   hard_upper  1
    x[10,1]   old_TS1   -2.2258731252318614e-02
    x[10,1]   old_TS2   -3.9535535354550462e-02
    x[10,1]   old_TS3   -3.9535535354550462e-02
    x[10,1]   old_TS4   -2.2258731252318614e-02
    x[10,2]   OBJ       5.3254499999999989e-03
    x[10,2]   onehot_10  1
    x[10,2]   w_lb_10_2  -2.2258731252318614e-02
    x[10,2]   w_ub_10_2  -3.9535535354550462e-02
    x[10,2]   hard_lower  2
    x[10,2]   hard_upper  2
    x[10,2]   old_TS1   -4.4517462504637229e-02
    x[10,2]   old_TS2   -7.9071070709100924e-02
    x[10,2]   old_TS3   -7.9071070709100924e-02
    x[10,2]   old_TS4   -4.4517462504637229e-02
    x[10,3]   onehot_10  1
    x[10,3]   w_lb_10_3  -2.2258731252318614e-02
    x[10,3]   w_ub_10_3  -3.9535535354550462e-02
    x[10,3]   hard_lower  3
    x[10,3]   hard_upper  3
    x[10,3]   old_TS1   -6.6776193756955843e-02
    x[10,3]   old_TS2   -1.1860660606365139e-01
    x[10,3]   old_TS3   -1.1860660606365139e-01
    x[10,3]   old_TS4   -6.6776193756955843e-02
    x[10,4]   OBJ       -0.00532545
    x[10,4]   onehot_10  1
    x[10,4]   w_lb_10_4  -2.2258731252318614e-02
    x[10,4]   w_ub_10_4  -3.9535535354550462e-02
    x[10,4]   hard_lower  4
    x[10,4]   hard_upper  4
    x[10,4]   old_TS1   -8.9034925009274457e-02
    x[10,4]   old_TS2   -1.5814214141820185e-01
    x[10,4]   old_TS3   -1.5814214141820185e-01
    x[10,4]   old_TS4   -8.9034925009274457e-02
    x[10,5]   OBJ       -0.0106509
    x[10,5]   onehot_10  1
    x[10,5]   w_lb_10_5  -2.2258731252318614e-02
    x[10,5]   w_ub_10_5  -3.9535535354550462e-02
    x[10,5]   hard_lower  5
    x[10,5]   hard_upper  5
    x[10,5]   old_TS1   -1.1129365626159307e-01
    x[10,5]   old_TS2   -1.9767767677275230e-01
    x[10,5]   old_TS3   -1.9767767677275230e-01
    x[10,5]   old_TS4   -1.1129365626159307e-01
    x[10,6]   OBJ       -0.01597635
    x[10,6]   onehot_10  1
    x[10,6]   w_lb_10_6  -2.2258731252318614e-02
    x[10,6]   w_ub_10_6  -3.9535535354550462e-02
    x[10,6]   hard_lower  6
    x[10,6]   hard_upper  6
    x[10,6]   old_TS1   -1.3355238751391169e-01
    x[10,6]   old_TS2   -2.3721321212730279e-01
    x[10,6]   old_TS3   -2.3721321212730279e-01
    x[10,6]   old_TS4   -1.3355238751391169e-01
    x[10,7]   OBJ       -1.0650900000000005e-02
    x[10,7]   onehot_10  1
    x[10,7]   w_lb_10_7  -2.2258731252318614e-02
    x[10,7]   w_ub_10_7  -3.9535535354550462e-02
    x[10,7]   hard_lower  7
    x[10,7]   hard_upper  7
    x[10,7]   old_TS1   -1.5581111876623030e-01
    x[10,7]   old_TS2   -2.7674874748185324e-01
    x[10,7]   old_TS3   -2.7674874748185324e-01
    x[10,7]   old_TS4   -1.5581111876623030e-01
    x[10,8]   OBJ       -5.3254500000000041e-03
    x[10,8]   onehot_10  1
    x[10,8]   w_lb_10_8  -2.2258731252318614e-02
    x[10,8]   w_ub_10_8  -3.9535535354550462e-02
    x[10,8]   hard_lower  8
    x[10,8]   hard_upper  8
    x[10,8]   old_TS1   -1.7806985001854891e-01
    x[10,8]   old_TS2   -3.1628428283640370e-01
    x[10,8]   old_TS3   -3.1628428283640370e-01
    x[10,8]   old_TS4   -1.7806985001854891e-01
    x[10,9]   OBJ       -3.5474623238940240e-18
    x[10,9]   onehot_10  1
    x[10,9]   w_lb_10_9  -2.2258731252318614e-02
    x[10,9]   w_ub_10_9  -3.9535535354550462e-02
    x[10,9]   hard_lower  9
    x[10,9]   hard_upper  9
    x[10,9]   old_TS1   -2.0032858127086753e-01
    x[10,9]   old_TS2   -3.5581981819095415e-01
    x[10,9]   old_TS3   -3.5581981819095415e-01
    x[10,9]   old_TS4   -2.0032858127086753e-01
    x[10,10]  OBJ       5.3254499999999955e-03
    x[10,10]  onehot_10  1
    x[10,10]  w_lb_10_10  -2.2258731252318614e-02
    x[10,10]  w_ub_10_10  -3.9535535354550462e-02
    x[10,10]  hard_lower  10
    x[10,10]  hard_upper  10
    x[10,10]  old_TS1   -2.2258731252318614e-01
    x[10,10]  old_TS2   -3.9535535354550461e-01
    x[10,10]  old_TS3   -3.9535535354550461e-01
    x[10,10]  old_TS4   -2.2258731252318614e-01
    x[10,11]  OBJ       1.0650899999999994e-02
    x[10,11]  onehot_10  1
    x[10,11]  w_lb_10_11  -2.2258731252318614e-02
    x[10,11]  w_ub_10_11  -3.9535535354550462e-02
    x[10,11]  hard_lower  11
    x[10,11]  hard_upper  11
    x[10,11]  old_TS1   -2.4484604377550476e-01
    x[10,11]  old_TS2   -4.3489088890005506e-01
    x[10,11]  old_TS3   -4.3489088890005506e-01
    x[10,11]  old_TS4   -2.4484604377550476e-01
    x[11,0]   OBJ       1.8639064285714286e-02
    x[11,0]   onehot_11  1
    x[11,0]   w_lb_11_0  -2.2258731252318614e-02
    x[11,0]   w_ub_11_0  -3.9535535354550462e-02
    x[11,1]   OBJ       1.2426042857142858e-02
    x[11,1]   onehot_11  1
    x[11,1]   w_lb_11_1  -2.2258731252318614e-02
    x[11,1]   w_ub_11_1  -3.9535535354550462e-02
    x[11,1]   hard_lower  1
    x[11,1]   hard_upper  1
    x[11,1]   old_TS1   -2.2258731252318614e-02
    x[11,1]   old_TS2   -3.9535535354550462e-02
    x[11,1]   old_TS3   -3.9535535354550462e-02
    x[11,1]   old_TS4   -2.2258731252318614e-02
    x[11,2]   OBJ       0.00621302142857143
    x[11,2]   onehot_11  1
    x[11,2]   w_lb_11_2  -2.2258731252318614e-02
    x[11,2]   w_ub_11_2  -3.9535535354550462e-02
    x[11,2]   hard_lower  2
    x[11,2]   hard_upper  2
    x[11,2]   old_TS1   -4.4517462504637229e-02
    x[11,2]   old_TS2   -7.9071070709100924e-02
    x[11,2]   old_TS3   -7.9071070709100924e-02
    x[11,2]   old_TS4   -4.4517462504637229e-02
    x[11,3]   OBJ       2.4142438048713188e-18
    x[11,3]   onehot_11  1
    x[11,3]   w_lb_11_3  -2.2258731252318614e-02
    x[11,3]   w_ub_11_3  -3.9535535354550462e-02
    x[11,3]   hard_lower  3
    x[11,3]   hard_upper  3
    x[11,3]   old_TS1   -6.6776193756955843e-02
    x[11,3]   old_TS2   -1.1860660606365139e-01
    x[11,3]   old_TS3   -1.1860660606365139e-01
    x[11,3]   old_TS4   -6.6776193756955843e-02
    x[11,4]   OBJ       -6.2130214285714257e-03
    x[11,4]   onehot_11  1
    x[11,4]   w_lb_11_4  -2.2258731252318614e-02
    x[11,4]   w_ub_11_4  -3.9535535354550462e-02
    x[11,4]   hard_lower  4
    x[11,4]   hard_upper  4
    x[11,4]   old_TS1   -8.9034925009274457e-02
    x[11,4]   old_TS2   -1.5814214141820185e-01
    x[11,4]   old_TS3   -1.5814214141820185e-01
    x[11,4]   old_TS4   -8.9034925009274457e-02
    x[11,5]   OBJ       -1.2426042857142855e-02
    x[11,5]   onehot_11  1
    x[11,5]   w_lb_11_5  -2.2258731252318614e-02
    x[11,5]   w_ub_11_5  -3.9535535354550462e-02
    x[11,5]   hard_lower  5
    x[11,5]   hard_upper  5
    x[11,5]   old_TS1   -1.1129365626159307e-01
    x[11,5]   old_TS2   -1.9767767677275230e-01
    x[11,5]   old_TS3   -1.9767767677275230e-01
    x[11,5]   old_TS4   -1.1129365626159307e-01
    x[11,6]   OBJ       -1.8639064285714282e-02
    x[11,6]   onehot_11  1
    x[11,6]   w_lb_11_6  -2.2258731252318614e-02
    x[11,6]   w_ub_11_6  -3.9535535354550462e-02
    x[11,6]   hard_lower  6
    x[11,6]   hard_upper  6
    x[11,6]   old_TS1   -1.3355238751391169e-01
    x[11,6]   old_TS2   -2.3721321212730279e-01
    x[11,6]   old_TS3   -2.3721321212730279e-01
    x[11,6]   old_TS4   -1.3355238751391169e-01
    x[11,7]   OBJ       -2.4852085714285713e-02
    x[11,7]   onehot_11  1
    x[11,7]   w_lb_11_7  -2.2258731252318614e-02
    x[11,7]   w_ub_11_7  -3.9535535354550462e-02
    x[11,7]   hard_lower  7
    x[11,7]   hard_upper  7
    x[11,7]   old_TS1   -1.5581111876623030e-01
    x[11,7]   old_TS2   -2.7674874748185324e-01
    x[11,7]   old_TS3   -2.7674874748185324e-01
    x[11,7]   old_TS4   -1.5581111876623030e-01
    x[11,8]   OBJ       -1.8639064285714289e-02
    x[11,8]   onehot_11  1
    x[11,8]   w_lb_11_8  -2.2258731252318614e-02
    x[11,8]   w_ub_11_8  -3.9535535354550462e-02
    x[11,8]   hard_lower  8
    x[11,8]   hard_upper  8
    x[11,8]   old_TS1   -1.7806985001854891e-01
    x[11,8]   old_TS2   -3.1628428283640370e-01
    x[11,8]   old_TS3   -3.1628428283640370e-01
    x[11,8]   old_TS4   -1.7806985001854891e-01
    x[11,9]   OBJ       -1.2426042857142860e-02
    x[11,9]   onehot_11  1
    x[11,9]   w_lb_11_9  -2.2258731252318614e-02
    x[11,9]   w_ub_11_9  -3.9535535354550462e-02
    x[11,9]   hard_lower  9
    x[11,9]   hard_upper  9
    x[11,9]   old_TS1   -2.0032858127086753e-01
    x[11,9]   old_TS2   -3.5581981819095415e-01
    x[11,9]   old_TS3   -3.5581981819095415e-01
    x[11,9]   old_TS4   -2.0032858127086753e-01
    x[11,10]  OBJ       -6.2130214285714309e-03
    x[11,10]  onehot_11  1
    x[11,10]  w_lb_11_10  -2.2258731252318614e-02
    x[11,10]  w_ub_11_10  -3.9535535354550462e-02
    x[11,10]  hard_lower  10
    x[11,10]  hard_upper  10
    x[11,10]  old_TS1   -2.2258731252318614e-01
    x[11,10]  old_TS2   -3.9535535354550461e-01
    x[11,10]  old_TS3   -3.9535535354550461e-01
    x[11,10]  old_TS4   -2.2258731252318614e-01
    x[11,11]  OBJ       -2.4142438048713188e-18
    x[11,11]  onehot_11  1
    x[11,11]  w_lb_11_11  -2.2258731252318614e-02
    x[11,11]  w_ub_11_11  -3.9535535354550462e-02
    x[11,11]  hard_lower  11
    x[11,11]  hard_upper  11
    x[11,11]  old_TS1   -2.4484604377550476e-01
    x[11,11]  old_TS2   -4.3489088890005506e-01
    x[11,11]  old_TS3   -4.3489088890005506e-01
    x[11,11]  old_TS4   -2.4484604377550476e-01
    x[11,12]  OBJ       6.2130214285714249e-03
    x[11,12]  onehot_11  1
    x[11,12]  w_lb_11_12  -2.2258731252318614e-02
    x[11,12]  w_ub_11_12  -3.9535535354550462e-02
    x[11,12]  hard_lower  12
    x[11,12]  hard_upper  12
    x[11,12]  old_TS1   -2.6710477502782337e-01
    x[11,12]  old_TS2   -4.7442642425460557e-01
    x[11,12]  old_TS3   -4.7442642425460557e-01
    x[11,12]  old_TS4   -2.6710477502782337e-01
    x[11,13]  OBJ       1.2426042857142853e-02
    x[11,13]  onehot_11  1
    x[11,13]  w_lb_11_13  -2.2258731252318614e-02
    x[11,13]  w_ub_11_13  -3.9535535354550462e-02
    x[11,13]  hard_lower  13
    x[11,13]  hard_upper  13
    x[11,13]  old_TS1   -2.8936350628014196e-01
    x[11,13]  old_TS2   -0.513961959609156
    x[11,13]  old_TS3   -0.513961959609156
    x[11,13]  old_TS4   -2.8936350628014196e-01
    x[11,14]  OBJ       1.8639064285714279e-02
    x[11,14]  onehot_11  1
    x[11,14]  w_lb_11_14  -2.2258731252318614e-02
    x[11,14]  w_ub_11_14  -3.9535535354550462e-02
    x[11,14]  hard_lower  14
    x[11,14]  hard_upper  14
    x[11,14]  old_TS1   -3.1162223753246060e-01
    x[11,14]  old_TS2   -5.5349749496370648e-01
    x[11,14]  old_TS3   -5.5349749496370648e-01
    x[11,14]  old_TS4   -3.1162223753246060e-01
    x[11,15]  OBJ       2.4852085714285710e-02
    x[11,15]  onehot_11  1
    x[11,15]  w_lb_11_15  -2.2258731252318614e-02
    x[11,15]  w_ub_11_15  -3.9535535354550462e-02
    x[11,15]  hard_lower  15
    x[11,15]  hard_upper  15
    x[11,15]  old_TS1   -3.3388096878477924e-01
    x[11,15]  old_TS2   -5.9303303031825694e-01
    x[11,15]  old_TS3   -5.9303303031825694e-01
    x[11,15]  old_TS4   -3.3388096878477924e-01
    x[12,0]   OBJ       2.8402349999999996e-02
    x[12,0]   onehot_12  1
    x[12,0]   w_lb_12_0  -2.2258731252318614e-02
    x[12,0]   w_ub_12_0  -3.9535535354550462e-02
    x[12,1]   OBJ       2.1301762499999995e-02
    x[12,1]   onehot_12  1
    x[12,1]   w_lb_12_1  -2.2258731252318614e-02
    x[12,1]   w_ub_12_1  -3.9535535354550462e-02
    x[12,1]   hard_lower  1
    x[12,1]   hard_upper  1
    x[12,1]   old_TS1   -2.2258731252318614e-02
    x[12,1]   old_TS2   -3.9535535354550462e-02
    x[12,1]   old_TS3   -3.9535535354550462e-02
    x[12,1]   old_TS4   -2.2258731252318614e-02
    x[12,2]   OBJ       1.4201174999999998e-02
    x[12,2]   onehot_12  1
    x[12,2]   w_lb_12_2  -2.2258731252318614e-02
    x[12,2]   w_ub_12_2  -3.9535535354550462e-02
    x[12,2]   hard_lower  2
    x[12,2]   hard_upper  2
    x[12,2]   old_TS1   -4.4517462504637229e-02
    x[12,2]   old_TS2   -7.9071070709100924e-02
    x[12,2]   old_TS3   -7.9071070709100924e-02
    x[12,2]   old_TS4   -4.4517462504637229e-02
    x[12,3]   OBJ       7.1005874999999991e-03
    x[12,3]   onehot_12  1
    x[12,3]   w_lb_12_3  -2.2258731252318614e-02
    x[12,3]   w_ub_12_3  -3.9535535354550462e-02
    x[12,3]   hard_lower  3
    x[12,3]   hard_upper  3
    x[12,3]   old_TS1   -6.6776193756955843e-02
    x[12,3]   old_TS2   -1.1860660606365139e-01
    x[12,3]   old_TS3   -1.1860660606365139e-01
    x[12,3]   old_TS4   -6.6776193756955843e-02
    x[12,4]   onehot_12  1
    x[12,4]   w_lb_12_4  -2.2258731252318614e-02
    x[12,4]   w_ub_12_4  -3.9535535354550462e-02
    x[12,4]   hard_lower  4
    x[12,4]   hard_upper  4
    x[12,4]   old_TS1   -8.9034925009274457e-02
    x[12,4]   old_TS2   -1.5814214141820185e-01
    x[12,4]   old_TS3   -1.5814214141820185e-01
    x[12,4]   old_TS4   -8.9034925009274457e-02
    x[12,5]   OBJ       -7.1005874999999991e-03
    x[12,5]   onehot_12  1
    x[12,5]   w_lb_12_5  -2.2258731252318614e-02
    x[12,5]   w_ub_12_5  -3.9535535354550462e-02
    x[12,5]   hard_lower  5
    x[12,5]   hard_upper  5
    x[12,5]   old_TS1   -1.1129365626159307e-01
    x[12,5]   old_TS2   -1.9767767677275230e-01
    x[12,5]   old_TS3   -1.9767767677275230e-01
    x[12,5]   old_TS4   -1.1129365626159307e-01
    x[12,6]   OBJ       -1.4201174999999998e-02
    x[12,6]   onehot_12  1
    x[12,6]   w_lb_12_6  -2.2258731252318614e-02
    x[12,6]   w_ub_12_6  -3.9535535354550462e-02
    x[12,6]   hard_lower  6
    x[12,6]   hard_upper  6
    x[12,6]   old_TS1   -1.3355238751391169e-01
    x[12,6]   old_TS2   -2.3721321212730279e-01
    x[12,6]   old_TS3   -2.3721321212730279e-01
    x[12,6]   old_TS4   -1.3355238751391169e-01
    x[12,7]   OBJ       -2.1301762499999998e-02
    x[12,7]   onehot_12  1
    x[12,7]   w_lb_12_7  -2.2258731252318614e-02
    x[12,7]   w_ub_12_7  -3.9535535354550462e-02
    x[12,7]   hard_lower  7
    x[12,7]   hard_upper  7
    x[12,7]   old_TS1   -1.5581111876623030e-01
    x[12,7]   old_TS2   -2.7674874748185324e-01
    x[12,7]   old_TS3   -2.7674874748185324e-01
    x[12,7]   old_TS4   -1.5581111876623030e-01
    x[12,8]   OBJ       -2.8402349999999996e-02
    x[12,8]   onehot_12  1
    x[12,8]   w_lb_12_8  -2.2258731252318614e-02
    x[12,8]   w_ub_12_8  -3.9535535354550462e-02
    x[12,8]   hard_lower  8
    x[12,8]   hard_upper  8
    x[12,8]   old_TS1   -1.7806985001854891e-01
    x[12,8]   old_TS2   -3.1628428283640370e-01
    x[12,8]   old_TS3   -3.1628428283640370e-01
    x[12,8]   old_TS4   -1.7806985001854891e-01
    x[12,9]   OBJ       -2.1301762499999998e-02
    x[12,9]   onehot_12  1
    x[12,9]   w_lb_12_9  -2.2258731252318614e-02
    x[12,9]   w_ub_12_9  -3.9535535354550462e-02
    x[12,9]   hard_lower  9
    x[12,9]   hard_upper  9
    x[12,9]   old_TS1   -2.0032858127086753e-01
    x[12,9]   old_TS2   -3.5581981819095415e-01
    x[12,9]   old_TS3   -3.5581981819095415e-01
    x[12,9]   old_TS4   -2.0032858127086753e-01
    x[12,10]  OBJ       -1.4201174999999998e-02
    x[12,10]  onehot_12  1
    x[12,10]  w_lb_12_10  -2.2258731252318614e-02
    x[12,10]  w_ub_12_10  -3.9535535354550462e-02
    x[12,10]  hard_lower  10
    x[12,10]  hard_upper  10
    x[12,10]  old_TS1   -2.2258731252318614e-01
    x[12,10]  old_TS2   -3.9535535354550461e-01
    x[12,10]  old_TS3   -3.9535535354550461e-01
    x[12,10]  old_TS4   -2.2258731252318614e-01
    x[12,11]  OBJ       -7.1005874999999991e-03
    x[12,11]  onehot_12  1
    x[12,11]  w_lb_12_11  -2.2258731252318614e-02
    x[12,11]  w_ub_12_11  -3.9535535354550462e-02
    x[12,11]  hard_lower  11
    x[12,11]  hard_upper  11
    x[12,11]  old_TS1   -2.4484604377550476e-01
    x[12,11]  old_TS2   -4.3489088890005506e-01
    x[12,11]  old_TS3   -4.3489088890005506e-01
    x[12,11]  old_TS4   -2.4484604377550476e-01
    x[12,12]  onehot_12  1
    x[12,12]  w_lb_12_12  -2.2258731252318614e-02
    x[12,12]  w_ub_12_12  -3.9535535354550462e-02
    x[12,12]  hard_lower  12
    x[12,12]  hard_upper  12
    x[12,12]  old_TS1   -2.6710477502782337e-01
    x[12,12]  old_TS2   -4.7442642425460557e-01
    x[12,12]  old_TS3   -4.7442642425460557e-01
    x[12,12]  old_TS4   -2.6710477502782337e-01
    x[12,13]  OBJ       7.1005874999999991e-03
    x[12,13]  onehot_12  1
    x[12,13]  w_lb_12_13  -2.2258731252318614e-02
    x[12,13]  w_ub_12_13  -3.9535535354550462e-02
    x[12,13]  hard_lower  13
    x[12,13]  hard_upper  13
    x[12,13]  old_TS1   -2.8936350628014196e-01
    x[12,13]  old_TS2   -0.513961959609156
    x[12,13]  old_TS3   -0.513961959609156
    x[12,13]  old_TS4   -2.8936350628014196e-01
    x[12,14]  OBJ       1.4201174999999998e-02
    x[12,14]  onehot_12  1
    x[12,14]  w_lb_12_14  -2.2258731252318614e-02
    x[12,14]  w_ub_12_14  -3.9535535354550462e-02
    x[12,14]  hard_lower  14
    x[12,14]  hard_upper  14
    x[12,14]  old_TS1   -3.1162223753246060e-01
    x[12,14]  old_TS2   -5.5349749496370648e-01
    x[12,14]  old_TS3   -5.5349749496370648e-01
    x[12,14]  old_TS4   -3.1162223753246060e-01
    x[12,15]  OBJ       2.1301762499999995e-02
    x[12,15]  onehot_12  1
    x[12,15]  w_lb_12_15  -2.2258731252318614e-02
    x[12,15]  w_ub_12_15  -3.9535535354550462e-02
    x[12,15]  hard_lower  15
    x[12,15]  hard_upper  15
    x[12,15]  old_TS1   -3.3388096878477924e-01
    x[12,15]  old_TS2   -5.9303303031825694e-01
    x[12,15]  old_TS3   -5.9303303031825694e-01
    x[12,15]  old_TS4   -3.3388096878477924e-01
    x[13,0]   OBJ       4.4378699999999993e-02
    x[13,0]   onehot_13  1
    x[13,0]   w_lb_13_0  -2.2258731252318614e-02
    x[13,0]   w_ub_13_0  -3.9535535354550462e-02
    x[13,1]   OBJ       3.5502959999999993e-02
    x[13,1]   onehot_13  1
    x[13,1]   w_lb_13_1  -2.2258731252318614e-02
    x[13,1]   w_ub_13_1  -3.9535535354550462e-02
    x[13,1]   hard_lower  1
    x[13,1]   hard_upper  1
    x[13,1]   old_TS1   -2.2258731252318614e-02
    x[13,1]   old_TS2   -3.9535535354550462e-02
    x[13,1]   old_TS3   -3.9535535354550462e-02
    x[13,1]   old_TS4   -2.2258731252318614e-02
    x[13,2]   OBJ       2.6627219999999997e-02
    x[13,2]   onehot_13  1
    x[13,2]   w_lb_13_2  -2.2258731252318614e-02
    x[13,2]   w_ub_13_2  -3.9535535354550462e-02
    x[13,2]   hard_lower  2
    x[13,2]   hard_upper  2
    x[13,2]   old_TS1   -4.4517462504637229e-02
    x[13,2]   old_TS2   -7.9071070709100924e-02
    x[13,2]   old_TS3   -7.9071070709100924e-02
    x[13,2]   old_TS4   -4.4517462504637229e-02
    x[13,3]   OBJ       1.7751479999999993e-02
    x[13,3]   onehot_13  1
    x[13,3]   w_lb_13_3  -2.2258731252318614e-02
    x[13,3]   w_ub_13_3  -3.9535535354550462e-02
    x[13,3]   hard_lower  3
    x[13,3]   hard_upper  3
    x[13,3]   old_TS1   -6.6776193756955843e-02
    x[13,3]   old_TS2   -1.1860660606365139e-01
    x[13,3]   old_TS3   -1.1860660606365139e-01
    x[13,3]   old_TS4   -6.6776193756955843e-02
    x[13,4]   OBJ       8.8757399999999948e-03
    x[13,4]   onehot_13  1
    x[13,4]   w_lb_13_4  -2.2258731252318614e-02
    x[13,4]   w_ub_13_4  -3.9535535354550462e-02
    x[13,4]   hard_lower  4
    x[13,4]   hard_upper  4
    x[13,4]   old_TS1   -8.9034925009274457e-02
    x[13,4]   old_TS2   -1.5814214141820185e-01
    x[13,4]   old_TS3   -1.5814214141820185e-01
    x[13,4]   old_TS4   -8.9034925009274457e-02
    x[13,5]   OBJ       -4.9270254542932435e-18
    x[13,5]   onehot_13  1
    x[13,5]   w_lb_13_5  -2.2258731252318614e-02
    x[13,5]   w_ub_13_5  -3.9535535354550462e-02
    x[13,5]   hard_lower  5
    x[13,5]   hard_upper  5
    x[13,5]   old_TS1   -1.1129365626159307e-01
    x[13,5]   old_TS2   -1.9767767677275230e-01
    x[13,5]   old_TS3   -1.9767767677275230e-01
    x[13,5]   old_TS4   -1.1129365626159307e-01
    x[13,6]   OBJ       -8.8757400000000070e-03
    x[13,6]   onehot_13  1
    x[13,6]   w_lb_13_6  -2.2258731252318614e-02
    x[13,6]   w_ub_13_6  -3.9535535354550462e-02
    x[13,6]   hard_lower  6
    x[13,6]   hard_upper  6
    x[13,6]   old_TS1   -1.3355238751391169e-01
    x[13,6]   old_TS2   -2.3721321212730279e-01
    x[13,6]   old_TS3   -2.3721321212730279e-01
    x[13,6]   old_TS4   -1.3355238751391169e-01
    x[13,7]   OBJ       -1.7751480000000007e-02
    x[13,7]   onehot_13  1
    x[13,7]   w_lb_13_7  -2.2258731252318614e-02
    x[13,7]   w_ub_13_7  -3.9535535354550462e-02
    x[13,7]   hard_lower  7
    x[13,7]   hard_upper  7
    x[13,7]   old_TS1   -1.5581111876623030e-01
    x[13,7]   old_TS2   -2.7674874748185324e-01
    x[13,7]   old_TS3   -2.7674874748185324e-01
    x[13,7]   old_TS4   -1.5581111876623030e-01
    x[13,8]   OBJ       -2.6627220000000007e-02
    x[13,8]   onehot_13  1
    x[13,8]   w_lb_13_8  -2.2258731252318614e-02
    x[13,8]   w_ub_13_8  -3.9535535354550462e-02
    x[13,8]   hard_lower  8
    x[13,8]   hard_upper  8
    x[13,8]   old_TS1   -1.7806985001854891e-01
    x[13,8]   old_TS2   -3.1628428283640370e-01
    x[13,8]   old_TS3   -3.1628428283640370e-01
    x[13,8]   old_TS4   -1.7806985001854891e-01
    x[13,9]   OBJ       -3.5502960000000007e-02
    x[13,9]   onehot_13  1
    x[13,9]   w_lb_13_9  -2.2258731252318614e-02
    x[13,9]   w_ub_13_9  -3.9535535354550462e-02
    x[13,9]   hard_lower  9
    x[13,9]   hard_upper  9
    x[13,9]   old_TS1   -2.0032858127086753e-01
    x[13,9]   old_TS2   -3.5581981819095415e-01
    x[13,9]   old_TS3   -3.5581981819095415e-01
    x[13,9]   old_TS4   -2.0032858127086753e-01
    x[13,10]  OBJ       -0.0443787
    x[13,10]  onehot_13  1
    x[13,10]  w_lb_13_10  -2.2258731252318614e-02
    x[13,10]  w_ub_13_10  -3.9535535354550462e-02
    x[13,10]  hard_lower  10
    x[13,10]  hard_upper  10
    x[13,10]  old_TS1   -2.2258731252318614e-01
    x[13,10]  old_TS2   -3.9535535354550461e-01
    x[13,10]  old_TS3   -3.9535535354550461e-01
    x[13,10]  old_TS4   -2.2258731252318614e-01
    x[13,11]  OBJ       -0.03550296
    x[13,11]  onehot_13  1
    x[13,11]  w_lb_13_11  -2.2258731252318614e-02
    x[13,11]  w_ub_13_11  -3.9535535354550462e-02
    x[13,11]  hard_lower  11
    x[13,11]  hard_upper  11
    x[13,11]  old_TS1   -2.4484604377550476e-01
    x[13,11]  old_TS2   -4.3489088890005506e-01
    x[13,11]  old_TS3   -4.3489088890005506e-01
    x[13,11]  old_TS4   -2.4484604377550476e-01
    x[13,12]  OBJ       -0.02662722
    x[13,12]  onehot_13  1
    x[13,12]  w_lb_13_12  -2.2258731252318614e-02
    x[13,12]  w_ub_13_12  -3.9535535354550462e-02
    x[13,12]  hard_lower  12
    x[13,12]  hard_upper  12
    x[13,12]  old_TS1   -2.6710477502782337e-01
    x[13,12]  old_TS2   -4.7442642425460557e-01
    x[13,12]  old_TS3   -4.7442642425460557e-01
    x[13,12]  old_TS4   -2.6710477502782337e-01
    x[13,13]  OBJ       -1.7751479999999997e-02
    x[13,13]  onehot_13  1
    x[13,13]  w_lb_13_13  -2.2258731252318614e-02
    x[13,13]  w_ub_13_13  -3.9535535354550462e-02
    x[13,13]  hard_lower  13
    x[13,13]  hard_upper  13
    x[13,13]  old_TS1   -2.8936350628014196e-01
    x[13,13]  old_TS2   -0.513961959609156
    x[13,13]  old_TS3   -0.513961959609156
    x[13,13]  old_TS4   -2.8936350628014196e-01
    x[13,14]  OBJ       -8.8757399999999965e-03
    x[13,14]  onehot_13  1
    x[13,14]  w_lb_13_14  -2.2258731252318614e-02
    x[13,14]  w_ub_13_14  -3.9535535354550462e-02
    x[13,14]  hard_lower  14
    x[13,14]  hard_upper  14
    x[13,14]  old_TS1   -3.1162223753246060e-01
    x[13,14]  old_TS2   -5.5349749496370648e-01
    x[13,14]  old_TS3   -5.5349749496370648e-01
    x[13,14]  old_TS4   -3.1162223753246060e-01
    x[13,15]  OBJ       4.9270254542932435e-18
    x[13,15]  onehot_13  1
    x[13,15]  w_lb_13_15  -2.2258731252318614e-02
    x[13,15]  w_ub_13_15  -3.9535535354550462e-02
    x[13,15]  hard_lower  15
    x[13,15]  hard_upper  15
    x[13,15]  old_TS1   -3.3388096878477924e-01
    x[13,15]  old_TS2   -5.9303303031825694e-01
    x[13,15]  old_TS3   -5.9303303031825694e-01
    x[13,15]  old_TS4   -3.3388096878477924e-01
    x[13,16]  OBJ       8.8757400000000052e-03
    x[13,16]  onehot_13  1
    x[13,16]  w_lb_13_16  -2.2258731252318614e-02
    x[13,16]  w_ub_13_16  -3.9535535354550462e-02
    x[13,16]  hard_lower  16
    x[13,16]  hard_upper  16
    x[13,16]  old_TS1   -3.5613970003709783e-01
    x[13,16]  old_TS2   -6.3256856567280739e-01
    x[13,16]  old_TS3   -6.3256856567280739e-01
    x[13,16]  old_TS4   -3.5613970003709783e-01
    x[13,17]  OBJ       1.7751480000000004e-02
    x[13,17]  onehot_13  1
    x[13,17]  w_lb_13_17  -2.2258731252318614e-02
    x[13,17]  w_ub_13_17  -3.9535535354550462e-02
    x[13,17]  hard_lower  17
    x[13,17]  hard_upper  17
    x[13,17]  old_TS1   -3.7839843128941641e-01
    x[13,17]  old_TS2   -6.7210410102735785e-01
    x[13,17]  old_TS3   -6.7210410102735785e-01
    x[13,17]  old_TS4   -3.7839843128941641e-01
    x[13,18]  OBJ       2.6627220000000004e-02
    x[13,18]  onehot_13  1
    x[13,18]  w_lb_13_18  -2.2258731252318614e-02
    x[13,18]  w_ub_13_18  -3.9535535354550462e-02
    x[13,18]  hard_lower  18
    x[13,18]  hard_upper  18
    x[13,18]  old_TS1   -4.0065716254173506e-01
    x[13,18]  old_TS2   -7.1163963638190830e-01
    x[13,18]  old_TS3   -7.1163963638190830e-01
    x[13,18]  old_TS4   -4.0065716254173506e-01
    x[13,19]  OBJ       0.03550296
    x[13,19]  onehot_13  1
    x[13,19]  w_lb_13_19  -2.2258731252318614e-02
    x[13,19]  w_ub_13_19  -3.9535535354550462e-02
    x[13,19]  hard_lower  19
    x[13,19]  hard_upper  19
    x[13,19]  old_TS1   -4.2291589379405370e-01
    x[13,19]  old_TS2   -7.5117517173645876e-01
    x[13,19]  old_TS3   -7.5117517173645876e-01
    x[13,19]  old_TS4   -4.2291589379405370e-01
    x[14,0]   OBJ       4.4378699999999993e-02
    x[14,0]   onehot_14  1
    x[14,0]   w_lb_14_0  -2.2258731252318614e-02
    x[14,0]   w_ub_14_0  -3.9535535354550462e-02
    x[14,1]   OBJ       3.5502959999999993e-02
    x[14,1]   onehot_14  1
    x[14,1]   w_lb_14_1  -2.2258731252318614e-02
    x[14,1]   w_ub_14_1  -3.9535535354550462e-02
    x[14,1]   hard_lower  1
    x[14,1]   hard_upper  1
    x[14,1]   old_TS1   -2.2258731252318614e-02
    x[14,1]   old_TS2   -3.9535535354550462e-02
    x[14,1]   old_TS3   -3.9535535354550462e-02
    x[14,1]   old_TS4   -2.2258731252318614e-02
    x[14,2]   OBJ       2.6627219999999997e-02
    x[14,2]   onehot_14  1
    x[14,2]   w_lb_14_2  -2.2258731252318614e-02
    x[14,2]   w_ub_14_2  -3.9535535354550462e-02
    x[14,2]   hard_lower  2
    x[14,2]   hard_upper  2
    x[14,2]   old_TS1   -4.4517462504637229e-02
    x[14,2]   old_TS2   -7.9071070709100924e-02
    x[14,2]   old_TS3   -7.9071070709100924e-02
    x[14,2]   old_TS4   -4.4517462504637229e-02
    x[14,3]   OBJ       1.7751479999999993e-02
    x[14,3]   onehot_14  1
    x[14,3]   w_lb_14_3  -2.2258731252318614e-02
    x[14,3]   w_ub_14_3  -3.9535535354550462e-02
    x[14,3]   hard_lower  3
    x[14,3]   hard_upper  3
    x[14,3]   old_TS1   -6.6776193756955843e-02
    x[14,3]   old_TS2   -1.1860660606365139e-01
    x[14,3]   old_TS3   -1.1860660606365139e-01
    x[14,3]   old_TS4   -6.6776193756955843e-02
    x[14,4]   OBJ       8.8757399999999948e-03
    x[14,4]   onehot_14  1
    x[14,4]   w_lb_14_4  -2.2258731252318614e-02
    x[14,4]   w_ub_14_4  -3.9535535354550462e-02
    x[14,4]   hard_lower  4
    x[14,4]   hard_upper  4
    x[14,4]   old_TS1   -8.9034925009274457e-02
    x[14,4]   old_TS2   -1.5814214141820185e-01
    x[14,4]   old_TS3   -1.5814214141820185e-01
    x[14,4]   old_TS4   -8.9034925009274457e-02
    x[14,5]   OBJ       -4.9270254542932435e-18
    x[14,5]   onehot_14  1
    x[14,5]   w_lb_14_5  -2.2258731252318614e-02
    x[14,5]   w_ub_14_5  -3.9535535354550462e-02
    x[14,5]   hard_lower  5
    x[14,5]   hard_upper  5
    x[14,5]   old_TS1   -1.1129365626159307e-01
    x[14,5]   old_TS2   -1.9767767677275230e-01
    x[14,5]   old_TS3   -1.9767767677275230e-01
    x[14,5]   old_TS4   -1.1129365626159307e-01
    x[14,6]   OBJ       -8.8757400000000070e-03
    x[14,6]   onehot_14  1
    x[14,6]   w_lb_14_6  -2.2258731252318614e-02
    x[14,6]   w_ub_14_6  -3.9535535354550462e-02
    x[14,6]   hard_lower  6
    x[14,6]   hard_upper  6
    x[14,6]   old_TS1   -1.3355238751391169e-01
    x[14,6]   old_TS2   -2.3721321212730279e-01
    x[14,6]   old_TS3   -2.3721321212730279e-01
    x[14,6]   old_TS4   -1.3355238751391169e-01
    x[14,7]   OBJ       -1.7751480000000007e-02
    x[14,7]   onehot_14  1
    x[14,7]   w_lb_14_7  -2.2258731252318614e-02
    x[14,7]   w_ub_14_7  -3.9535535354550462e-02
    x[14,7]   hard_lower  7
    x[14,7]   hard_upper  7
    x[14,7]   old_TS1   -1.5581111876623030e-01
    x[14,7]   old_TS2   -2.7674874748185324e-01
    x[14,7]   old_TS3   -2.7674874748185324e-01
    x[14,7]   old_TS4   -1.5581111876623030e-01
    x[14,8]   OBJ       -2.6627220000000007e-02
    x[14,8]   onehot_14  1
    x[14,8]   w_lb_14_8  -2.2258731252318614e-02
    x[14,8]   w_ub_14_8  -3.9535535354550462e-02
    x[14,8]   hard_lower  8
    x[14,8]   hard_upper  8
    x[14,8]   old_TS1   -1.7806985001854891e-01
    x[14,8]   old_TS2   -3.1628428283640370e-01
    x[14,8]   old_TS3   -3.1628428283640370e-01
    x[14,8]   old_TS4   -1.7806985001854891e-01
    x[14,9]   OBJ       -3.5502960000000007e-02
    x[14,9]   onehot_14  1
    x[14,9]   w_lb_14_9  -2.2258731252318614e-02
    x[14,9]   w_ub_14_9  -3.9535535354550462e-02
    x[14,9]   hard_lower  9
    x[14,9]   hard_upper  9
    x[14,9]   old_TS1   -2.0032858127086753e-01
    x[14,9]   old_TS2   -3.5581981819095415e-01
    x[14,9]   old_TS3   -3.5581981819095415e-01
    x[14,9]   old_TS4   -2.0032858127086753e-01
    x[14,10]  OBJ       -0.0443787
    x[14,10]  onehot_14  1
    x[14,10]  w_lb_14_10  -2.2258731252318614e-02
    x[14,10]  w_ub_14_10  -3.9535535354550462e-02
    x[14,10]  hard_lower  10
    x[14,10]  hard_upper  10
    x[14,10]  old_TS1   -2.2258731252318614e-01
    x[14,10]  old_TS2   -3.9535535354550461e-01
    x[14,10]  old_TS3   -3.9535535354550461e-01
    x[14,10]  old_TS4   -2.2258731252318614e-01
    x[14,11]  OBJ       -0.03550296
    x[14,11]  onehot_14  1
    x[14,11]  w_lb_14_11  -2.2258731252318614e-02
    x[14,11]  w_ub_14_11  -3.9535535354550462e-02
    x[14,11]  hard_lower  11
    x[14,11]  hard_upper  11
    x[14,11]  old_TS1   -2.4484604377550476e-01
    x[14,11]  old_TS2   -4.3489088890005506e-01
    x[14,11]  old_TS3   -4.3489088890005506e-01
    x[14,11]  old_TS4   -2.4484604377550476e-01
    x[14,12]  OBJ       -0.02662722
    x[14,12]  onehot_14  1
    x[14,12]  w_lb_14_12  -2.2258731252318614e-02
    x[14,12]  w_ub_14_12  -3.9535535354550462e-02
    x[14,12]  hard_lower  12
    x[14,12]  hard_upper  12
    x[14,12]  old_TS1   -2.6710477502782337e-01
    x[14,12]  old_TS2   -4.7442642425460557e-01
    x[14,12]  old_TS3   -4.7442642425460557e-01
    x[14,12]  old_TS4   -2.6710477502782337e-01
    x[14,13]  OBJ       -1.7751479999999997e-02
    x[14,13]  onehot_14  1
    x[14,13]  w_lb_14_13  -2.2258731252318614e-02
    x[14,13]  w_ub_14_13  -3.9535535354550462e-02
    x[14,13]  hard_lower  13
    x[14,13]  hard_upper  13
    x[14,13]  old_TS1   -2.8936350628014196e-01
    x[14,13]  old_TS2   -0.513961959609156
    x[14,13]  old_TS3   -0.513961959609156
    x[14,13]  old_TS4   -2.8936350628014196e-01
    x[14,14]  OBJ       -8.8757399999999965e-03
    x[14,14]  onehot_14  1
    x[14,14]  w_lb_14_14  -2.2258731252318614e-02
    x[14,14]  w_ub_14_14  -3.9535535354550462e-02
    x[14,14]  hard_lower  14
    x[14,14]  hard_upper  14
    x[14,14]  old_TS1   -3.1162223753246060e-01
    x[14,14]  old_TS2   -5.5349749496370648e-01
    x[14,14]  old_TS3   -5.5349749496370648e-01
    x[14,14]  old_TS4   -3.1162223753246060e-01
    x[14,15]  OBJ       4.9270254542932435e-18
    x[14,15]  onehot_14  1
    x[14,15]  w_lb_14_15  -2.2258731252318614e-02
    x[14,15]  w_ub_14_15  -3.9535535354550462e-02
    x[14,15]  hard_lower  15
    x[14,15]  hard_upper  15
    x[14,15]  old_TS1   -3.3388096878477924e-01
    x[14,15]  old_TS2   -5.9303303031825694e-01
    x[14,15]  old_TS3   -5.9303303031825694e-01
    x[14,15]  old_TS4   -3.3388096878477924e-01
    x[14,16]  OBJ       8.8757400000000052e-03
    x[14,16]  onehot_14  1
    x[14,16]  w_lb_14_16  -2.2258731252318614e-02
    x[14,16]  w_ub_14_16  -3.9535535354550462e-02
    x[14,16]  hard_lower  16
    x[14,16]  hard_upper  16
    x[14,16]  old_TS1   -3.5613970003709783e-01
    x[14,16]  old_TS2   -6.3256856567280739e-01
    x[14,16]  old_TS3   -6.3256856567280739e-01
    x[14,16]  old_TS4   -3.5613970003709783e-01
    x[14,17]  OBJ       1.7751480000000004e-02
    x[14,17]  onehot_14  1
    x[14,17]  w_lb_14_17  -2.2258731252318614e-02
    x[14,17]  w_ub_14_17  -3.9535535354550462e-02
    x[14,17]  hard_lower  17
    x[14,17]  hard_upper  17
    x[14,17]  old_TS1   -3.7839843128941641e-01
    x[14,17]  old_TS2   -6.7210410102735785e-01
    x[14,17]  old_TS3   -6.7210410102735785e-01
    x[14,17]  old_TS4   -3.7839843128941641e-01
    x[14,18]  OBJ       2.6627220000000004e-02
    x[14,18]  onehot_14  1
    x[14,18]  w_lb_14_18  -2.2258731252318614e-02
    x[14,18]  w_ub_14_18  -3.9535535354550462e-02
    x[14,18]  hard_lower  18
    x[14,18]  hard_upper  18
    x[14,18]  old_TS1   -4.0065716254173506e-01
    x[14,18]  old_TS2   -7.1163963638190830e-01
    x[14,18]  old_TS3   -7.1163963638190830e-01
    x[14,18]  old_TS4   -4.0065716254173506e-01
    x[15,0]   OBJ       4.4378699999999993e-02
    x[15,0]   onehot_15  1
    x[15,0]   w_lb_15_0  -2.2258731252318614e-02
    x[15,0]   w_ub_15_0  -3.9535535354550462e-02
    x[15,1]   OBJ       3.5502959999999993e-02
    x[15,1]   onehot_15  1
    x[15,1]   w_lb_15_1  -2.2258731252318614e-02
    x[15,1]   w_ub_15_1  -3.9535535354550462e-02
    x[15,1]   hard_lower  1
    x[15,1]   hard_upper  1
    x[15,1]   old_TS1   -2.2258731252318614e-02
    x[15,1]   old_TS2   -3.9535535354550462e-02
    x[15,1]   old_TS3   -3.9535535354550462e-02
    x[15,1]   old_TS4   -2.2258731252318614e-02
    x[15,2]   OBJ       2.6627219999999997e-02
    x[15,2]   onehot_15  1
    x[15,2]   w_lb_15_2  -2.2258731252318614e-02
    x[15,2]   w_ub_15_2  -3.9535535354550462e-02
    x[15,2]   hard_lower  2
    x[15,2]   hard_upper  2
    x[15,2]   old_TS1   -4.4517462504637229e-02
    x[15,2]   old_TS2   -7.9071070709100924e-02
    x[15,2]   old_TS3   -7.9071070709100924e-02
    x[15,2]   old_TS4   -4.4517462504637229e-02
    x[15,3]   OBJ       1.7751479999999993e-02
    x[15,3]   onehot_15  1
    x[15,3]   w_lb_15_3  -2.2258731252318614e-02
    x[15,3]   w_ub_15_3  -3.9535535354550462e-02
    x[15,3]   hard_lower  3
    x[15,3]   hard_upper  3
    x[15,3]   old_TS1   -6.6776193756955843e-02
    x[15,3]   old_TS2   -1.1860660606365139e-01
    x[15,3]   old_TS3   -1.1860660606365139e-01
    x[15,3]   old_TS4   -6.6776193756955843e-02
    x[15,4]   OBJ       8.8757399999999948e-03
    x[15,4]   onehot_15  1
    x[15,4]   w_lb_15_4  -2.2258731252318614e-02
    x[15,4]   w_ub_15_4  -3.9535535354550462e-02
    x[15,4]   hard_lower  4
    x[15,4]   hard_upper  4
    x[15,4]   old_TS1   -8.9034925009274457e-02
    x[15,4]   old_TS2   -1.5814214141820185e-01
    x[15,4]   old_TS3   -1.5814214141820185e-01
    x[15,4]   old_TS4   -8.9034925009274457e-02
    x[15,5]   OBJ       -4.9270254542932435e-18
    x[15,5]   onehot_15  1
    x[15,5]   w_lb_15_5  -2.2258731252318614e-02
    x[15,5]   w_ub_15_5  -3.9535535354550462e-02
    x[15,5]   hard_lower  5
    x[15,5]   hard_upper  5
    x[15,5]   old_TS1   -1.1129365626159307e-01
    x[15,5]   old_TS2   -1.9767767677275230e-01
    x[15,5]   old_TS3   -1.9767767677275230e-01
    x[15,5]   old_TS4   -1.1129365626159307e-01
    x[15,6]   OBJ       -8.8757400000000070e-03
    x[15,6]   onehot_15  1
    x[15,6]   w_lb_15_6  -2.2258731252318614e-02
    x[15,6]   w_ub_15_6  -3.9535535354550462e-02
    x[15,6]   hard_lower  6
    x[15,6]   hard_upper  6
    x[15,6]   old_TS1   -1.3355238751391169e-01
    x[15,6]   old_TS2   -2.3721321212730279e-01
    x[15,6]   old_TS3   -2.3721321212730279e-01
    x[15,6]   old_TS4   -1.3355238751391169e-01
    x[15,7]   OBJ       -1.7751480000000007e-02
    x[15,7]   onehot_15  1
    x[15,7]   w_lb_15_7  -2.2258731252318614e-02
    x[15,7]   w_ub_15_7  -3.9535535354550462e-02
    x[15,7]   hard_lower  7
    x[15,7]   hard_upper  7
    x[15,7]   old_TS1   -1.5581111876623030e-01
    x[15,7]   old_TS2   -2.7674874748185324e-01
    x[15,7]   old_TS3   -2.7674874748185324e-01
    x[15,7]   old_TS4   -1.5581111876623030e-01
    x[15,8]   OBJ       -2.6627220000000007e-02
    x[15,8]   onehot_15  1
    x[15,8]   w_lb_15_8  -2.2258731252318614e-02
    x[15,8]   w_ub_15_8  -3.9535535354550462e-02
    x[15,8]   hard_lower  8
    x[15,8]   hard_upper  8
    x[15,8]   old_TS1   -1.7806985001854891e-01
    x[15,8]   old_TS2   -3.1628428283640370e-01
    x[15,8]   old_TS3   -3.1628428283640370e-01
    x[15,8]   old_TS4   -1.7806985001854891e-01
    x[15,9]   OBJ       -3.5502960000000007e-02
    x[15,9]   onehot_15  1
    x[15,9]   w_lb_15_9  -2.2258731252318614e-02
    x[15,9]   w_ub_15_9  -3.9535535354550462e-02
    x[15,9]   hard_lower  9
    x[15,9]   hard_upper  9
    x[15,9]   old_TS1   -2.0032858127086753e-01
    x[15,9]   old_TS2   -3.5581981819095415e-01
    x[15,9]   old_TS3   -3.5581981819095415e-01
    x[15,9]   old_TS4   -2.0032858127086753e-01
    x[15,10]  OBJ       -0.0443787
    x[15,10]  onehot_15  1
    x[15,10]  w_lb_15_10  -2.2258731252318614e-02
    x[15,10]  w_ub_15_10  -3.9535535354550462e-02
    x[15,10]  hard_lower  10
    x[15,10]  hard_upper  10
    x[15,10]  old_TS1   -2.2258731252318614e-01
    x[15,10]  old_TS2   -3.9535535354550461e-01
    x[15,10]  old_TS3   -3.9535535354550461e-01
    x[15,10]  old_TS4   -2.2258731252318614e-01
    x[15,11]  OBJ       -0.03550296
    x[15,11]  onehot_15  1
    x[15,11]  w_lb_15_11  -2.2258731252318614e-02
    x[15,11]  w_ub_15_11  -3.9535535354550462e-02
    x[15,11]  hard_lower  11
    x[15,11]  hard_upper  11
    x[15,11]  old_TS1   -2.4484604377550476e-01
    x[15,11]  old_TS2   -4.3489088890005506e-01
    x[15,11]  old_TS3   -4.3489088890005506e-01
    x[15,11]  old_TS4   -2.4484604377550476e-01
    x[15,12]  OBJ       -0.02662722
    x[15,12]  onehot_15  1
    x[15,12]  w_lb_15_12  -2.2258731252318614e-02
    x[15,12]  w_ub_15_12  -3.9535535354550462e-02
    x[15,12]  hard_lower  12
    x[15,12]  hard_upper  12
    x[15,12]  old_TS1   -2.6710477502782337e-01
    x[15,12]  old_TS2   -4.7442642425460557e-01
    x[15,12]  old_TS3   -4.7442642425460557e-01
    x[15,12]  old_TS4   -2.6710477502782337e-01
    x[15,13]  OBJ       -1.7751479999999997e-02
    x[15,13]  onehot_15  1
    x[15,13]  w_lb_15_13  -2.2258731252318614e-02
    x[15,13]  w_ub_15_13  -3.9535535354550462e-02
    x[15,13]  hard_lower  13
    x[15,13]  hard_upper  13
    x[15,13]  old_TS1   -2.8936350628014196e-01
    x[15,13]  old_TS2   -0.513961959609156
    x[15,13]  old_TS3   -0.513961959609156
    x[15,13]  old_TS4   -2.8936350628014196e-01
    x[15,14]  OBJ       -8.8757399999999965e-03
    x[15,14]  onehot_15  1
    x[15,14]  w_lb_15_14  -2.2258731252318614e-02
    x[15,14]  w_ub_15_14  -3.9535535354550462e-02
    x[15,14]  hard_lower  14
    x[15,14]  hard_upper  14
    x[15,14]  old_TS1   -3.1162223753246060e-01
    x[15,14]  old_TS2   -5.5349749496370648e-01
    x[15,14]  old_TS3   -5.5349749496370648e-01
    x[15,14]  old_TS4   -3.1162223753246060e-01
    x[15,15]  OBJ       4.9270254542932435e-18
    x[15,15]  onehot_15  1
    x[15,15]  w_lb_15_15  -2.2258731252318614e-02
    x[15,15]  w_ub_15_15  -3.9535535354550462e-02
    x[15,15]  hard_lower  15
    x[15,15]  hard_upper  15
    x[15,15]  old_TS1   -3.3388096878477924e-01
    x[15,15]  old_TS2   -5.9303303031825694e-01
    x[15,15]  old_TS3   -5.9303303031825694e-01
    x[15,15]  old_TS4   -3.3388096878477924e-01
    x[15,16]  OBJ       8.8757400000000052e-03
    x[15,16]  onehot_15  1
    x[15,16]  w_lb_15_16  -2.2258731252318614e-02
    x[15,16]  w_ub_15_16  -3.9535535354550462e-02
    x[15,16]  hard_lower  16
    x[15,16]  hard_upper  16
    x[15,16]  old_TS1   -3.5613970003709783e-01
    x[15,16]  old_TS2   -6.3256856567280739e-01
    x[15,16]  old_TS3   -6.3256856567280739e-01
    x[15,16]  old_TS4   -3.5613970003709783e-01
    x[15,17]  OBJ       1.7751480000000004e-02
    x[15,17]  onehot_15  1
    x[15,17]  w_lb_15_17  -2.2258731252318614e-02
    x[15,17]  w_ub_15_17  -3.9535535354550462e-02
    x[15,17]  hard_lower  17
    x[15,17]  hard_upper  17
    x[15,17]  old_TS1   -3.7839843128941641e-01
    x[15,17]  old_TS2   -6.7210410102735785e-01
    x[15,17]  old_TS3   -6.7210410102735785e-01
    x[15,17]  old_TS4   -3.7839843128941641e-01
    x[15,18]  OBJ       2.6627220000000004e-02
    x[15,18]  onehot_15  1
    x[15,18]  w_lb_15_18  -2.2258731252318614e-02
    x[15,18]  w_ub_15_18  -3.9535535354550462e-02
    x[15,18]  hard_lower  18
    x[15,18]  hard_upper  18
    x[15,18]  old_TS1   -4.0065716254173506e-01
    x[15,18]  old_TS2   -7.1163963638190830e-01
    x[15,18]  old_TS3   -7.1163963638190830e-01
    x[15,18]  old_TS4   -4.0065716254173506e-01
    x[15,19]  OBJ       0.03550296
    x[15,19]  onehot_15  1
    x[15,19]  w_lb_15_19  -2.2258731252318614e-02
    x[15,19]  w_ub_15_19  -3.9535535354550462e-02
    x[15,19]  hard_lower  19
    x[15,19]  hard_upper  19
    x[15,19]  old_TS1   -4.2291589379405370e-01
    x[15,19]  old_TS2   -7.5117517173645876e-01
    x[15,19]  old_TS3   -7.5117517173645876e-01
    x[15,19]  old_TS4   -4.2291589379405370e-01
    x[16,0]   OBJ       8.8757399999999965e-03
    x[16,0]   onehot_16  1
    x[16,0]   w_lb_16_0  -2.2258731252318614e-02
    x[16,0]   w_ub_16_0  -3.9535535354550462e-02
    x[16,1]   OBJ       4.4378699999999974e-03
    x[16,1]   onehot_16  1
    x[16,1]   w_lb_16_1  -2.2258731252318614e-02
    x[16,1]   w_ub_16_1  -3.9535535354550462e-02
    x[16,1]   hard_lower  1
    x[16,1]   hard_upper  1
    x[16,1]   old_TS1   -2.2258731252318614e-02
    x[16,1]   old_TS2   -3.9535535354550462e-02
    x[16,1]   old_TS3   -3.9535535354550462e-02
    x[16,1]   old_TS4   -2.2258731252318614e-02
    x[16,2]   OBJ       -2.4635127271466217e-18
    x[16,2]   onehot_16  1
    x[16,2]   w_lb_16_2  -2.2258731252318614e-02
    x[16,2]   w_ub_16_2  -3.9535535354550462e-02
    x[16,2]   hard_lower  2
    x[16,2]   hard_upper  2
    x[16,2]   old_TS1   -4.4517462504637229e-02
    x[16,2]   old_TS2   -7.9071070709100924e-02
    x[16,2]   old_TS3   -7.9071070709100924e-02
    x[16,2]   old_TS4   -4.4517462504637229e-02
    x[16,3]   OBJ       -4.4378700000000035e-03
    x[16,3]   onehot_16  1
    x[16,3]   w_lb_16_3  -2.2258731252318614e-02
    x[16,3]   w_ub_16_3  -3.9535535354550462e-02
    x[16,3]   hard_lower  3
    x[16,3]   hard_upper  3
    x[16,3]   old_TS1   -6.6776193756955843e-02
    x[16,3]   old_TS2   -1.1860660606365139e-01
    x[16,3]   old_TS3   -1.1860660606365139e-01
    x[16,3]   old_TS4   -6.6776193756955843e-02
    x[16,4]   OBJ       -8.8757400000000035e-03
    x[16,4]   onehot_16  1
    x[16,4]   w_lb_16_4  -2.2258731252318614e-02
    x[16,4]   w_ub_16_4  -3.9535535354550462e-02
    x[16,4]   hard_lower  4
    x[16,4]   hard_upper  4
    x[16,4]   old_TS1   -8.9034925009274457e-02
    x[16,4]   old_TS2   -1.5814214141820185e-01
    x[16,4]   old_TS3   -1.5814214141820185e-01
    x[16,4]   old_TS4   -8.9034925009274457e-02
    x[16,5]   OBJ       -1.3313610000000002e-02
    x[16,5]   onehot_16  1
    x[16,5]   w_lb_16_5  -2.2258731252318614e-02
    x[16,5]   w_ub_16_5  -3.9535535354550462e-02
    x[16,5]   hard_lower  5
    x[16,5]   hard_upper  5
    x[16,5]   old_TS1   -1.1129365626159307e-01
    x[16,5]   old_TS2   -1.9767767677275230e-01
    x[16,5]   old_TS3   -1.9767767677275230e-01
    x[16,5]   old_TS4   -1.1129365626159307e-01
    x[16,6]   OBJ       -8.8757400000000018e-03
    x[16,6]   onehot_16  1
    x[16,6]   w_lb_16_6  -2.2258731252318614e-02
    x[16,6]   w_ub_16_6  -3.9535535354550462e-02
    x[16,6]   hard_lower  6
    x[16,6]   hard_upper  6
    x[16,6]   old_TS1   -1.3355238751391169e-01
    x[16,6]   old_TS2   -2.3721321212730279e-01
    x[16,6]   old_TS3   -2.3721321212730279e-01
    x[16,6]   old_TS4   -1.3355238751391169e-01
    x[16,7]   OBJ       -4.4378700000000009e-03
    x[16,7]   onehot_16  1
    x[16,7]   w_lb_16_7  -2.2258731252318614e-02
    x[16,7]   w_ub_16_7  -3.9535535354550462e-02
    x[16,7]   hard_lower  7
    x[16,7]   hard_upper  7
    x[16,7]   old_TS1   -1.5581111876623030e-01
    x[16,7]   old_TS2   -2.7674874748185324e-01
    x[16,7]   old_TS3   -2.7674874748185324e-01
    x[16,7]   old_TS4   -1.5581111876623030e-01
    x[16,8]   onehot_16  1
    x[16,8]   w_lb_16_8  -2.2258731252318614e-02
    x[16,8]   w_ub_16_8  -3.9535535354550462e-02
    x[16,8]   hard_lower  8
    x[16,8]   hard_upper  8
    x[16,8]   old_TS1   -1.7806985001854891e-01
    x[16,8]   old_TS2   -3.1628428283640370e-01
    x[16,8]   old_TS3   -3.1628428283640370e-01
    x[16,8]   old_TS4   -1.7806985001854891e-01
    x[16,9]   OBJ       0.00443787
    x[16,9]   onehot_16  1
    x[16,9]   w_lb_16_9  -2.2258731252318614e-02
    x[16,9]   w_ub_16_9  -3.9535535354550462e-02
    x[16,9]   hard_lower  9
    x[16,9]   hard_upper  9
    x[16,9]   old_TS1   -2.0032858127086753e-01
    x[16,9]   old_TS2   -3.5581981819095415e-01
    x[16,9]   old_TS3   -3.5581981819095415e-01
    x[16,9]   old_TS4   -2.0032858127086753e-01
    x[16,10]  OBJ       0.00887574
    x[16,10]  onehot_16  1
    x[16,10]  w_lb_16_10  -2.2258731252318614e-02
    x[16,10]  w_ub_16_10  -3.9535535354550462e-02
    x[16,10]  hard_lower  10
    x[16,10]  hard_upper  10
    x[16,10]  old_TS1   -2.2258731252318614e-01
    x[16,10]  old_TS2   -3.9535535354550461e-01
    x[16,10]  old_TS3   -3.9535535354550461e-01
    x[16,10]  old_TS4   -2.2258731252318614e-01
    x[16,11]  OBJ       0.01331361
    x[16,11]  onehot_16  1
    x[16,11]  w_lb_16_11  -2.2258731252318614e-02
    x[16,11]  w_ub_16_11  -3.9535535354550462e-02
    x[16,11]  hard_lower  11
    x[16,11]  hard_upper  11
    x[16,11]  old_TS1   -2.4484604377550476e-01
    x[16,11]  old_TS2   -4.3489088890005506e-01
    x[16,11]  old_TS3   -4.3489088890005506e-01
    x[16,11]  old_TS4   -2.4484604377550476e-01
    x[17,16]  onehot_17  1
    x[17,16]  w_lb_17_16  -2.2258731252318614e-02
    x[17,16]  w_ub_17_16  -3.9535535354550462e-02
    x[17,16]  hard_lower  16
    x[17,16]  hard_upper  16
    x[17,16]  old_TS1   -3.5613970003709783e-01
    x[17,16]  old_TS2   -6.3256856567280739e-01
    x[17,16]  old_TS3   -6.3256856567280739e-01
    x[17,16]  old_TS4   -3.5613970003709783e-01
    x[18,0]   OBJ       1.8639064285714286e-02
    x[18,0]   onehot_18  1
    x[18,0]   w_lb_18_0  -2.2258731252318614e-02
    x[18,0]   w_ub_18_0  -3.9535535354550462e-02
    x[18,1]   OBJ       1.2426042857142858e-02
    x[18,1]   onehot_18  1
    x[18,1]   w_lb_18_1  -2.2258731252318614e-02
    x[18,1]   w_ub_18_1  -3.9535535354550462e-02
    x[18,1]   hard_lower  1
    x[18,1]   hard_upper  1
    x[18,1]   old_TS1   -2.2258731252318614e-02
    x[18,1]   old_TS2   -3.9535535354550462e-02
    x[18,1]   old_TS3   -3.9535535354550462e-02
    x[18,1]   old_TS4   -2.2258731252318614e-02
    x[18,2]   OBJ       0.00621302142857143
    x[18,2]   onehot_18  1
    x[18,2]   w_lb_18_2  -2.2258731252318614e-02
    x[18,2]   w_ub_18_2  -3.9535535354550462e-02
    x[18,2]   hard_lower  2
    x[18,2]   hard_upper  2
    x[18,2]   old_TS1   -4.4517462504637229e-02
    x[18,2]   old_TS2   -7.9071070709100924e-02
    x[18,2]   old_TS3   -7.9071070709100924e-02
    x[18,2]   old_TS4   -4.4517462504637229e-02
    x[18,3]   OBJ       2.4142438048713188e-18
    x[18,3]   onehot_18  1
    x[18,3]   w_lb_18_3  -2.2258731252318614e-02
    x[18,3]   w_ub_18_3  -3.9535535354550462e-02
    x[18,3]   hard_lower  3
    x[18,3]   hard_upper  3
    x[18,3]   old_TS1   -6.6776193756955843e-02
    x[18,3]   old_TS2   -1.1860660606365139e-01
    x[18,3]   old_TS3   -1.1860660606365139e-01
    x[18,3]   old_TS4   -6.6776193756955843e-02
    x[18,4]   OBJ       -6.2130214285714257e-03
    x[18,4]   onehot_18  1
    x[18,4]   w_lb_18_4  -2.2258731252318614e-02
    x[18,4]   w_ub_18_4  -3.9535535354550462e-02
    x[18,4]   hard_lower  4
    x[18,4]   hard_upper  4
    x[18,4]   old_TS1   -8.9034925009274457e-02
    x[18,4]   old_TS2   -1.5814214141820185e-01
    x[18,4]   old_TS3   -1.5814214141820185e-01
    x[18,4]   old_TS4   -8.9034925009274457e-02
    x[18,5]   OBJ       -1.2426042857142855e-02
    x[18,5]   onehot_18  1
    x[18,5]   w_lb_18_5  -2.2258731252318614e-02
    x[18,5]   w_ub_18_5  -3.9535535354550462e-02
    x[18,5]   hard_lower  5
    x[18,5]   hard_upper  5
    x[18,5]   old_TS1   -1.1129365626159307e-01
    x[18,5]   old_TS2   -1.9767767677275230e-01
    x[18,5]   old_TS3   -1.9767767677275230e-01
    x[18,5]   old_TS4   -1.1129365626159307e-01
    x[18,6]   OBJ       -1.8639064285714282e-02
    x[18,6]   onehot_18  1
    x[18,6]   w_lb_18_6  -2.2258731252318614e-02
    x[18,6]   w_ub_18_6  -3.9535535354550462e-02
    x[18,6]   hard_lower  6
    x[18,6]   hard_upper  6
    x[18,6]   old_TS1   -1.3355238751391169e-01
    x[18,6]   old_TS2   -2.3721321212730279e-01
    x[18,6]   old_TS3   -2.3721321212730279e-01
    x[18,6]   old_TS4   -1.3355238751391169e-01
    x[18,7]   OBJ       -2.4852085714285713e-02
    x[18,7]   onehot_18  1
    x[18,7]   w_lb_18_7  -2.2258731252318614e-02
    x[18,7]   w_ub_18_7  -3.9535535354550462e-02
    x[18,7]   hard_lower  7
    x[18,7]   hard_upper  7
    x[18,7]   old_TS1   -1.5581111876623030e-01
    x[18,7]   old_TS2   -2.7674874748185324e-01
    x[18,7]   old_TS3   -2.7674874748185324e-01
    x[18,7]   old_TS4   -1.5581111876623030e-01
    x[18,8]   OBJ       -1.8639064285714289e-02
    x[18,8]   onehot_18  1
    x[18,8]   w_lb_18_8  -2.2258731252318614e-02
    x[18,8]   w_ub_18_8  -3.9535535354550462e-02
    x[18,8]   hard_lower  8
    x[18,8]   hard_upper  8
    x[18,8]   old_TS1   -1.7806985001854891e-01
    x[18,8]   old_TS2   -3.1628428283640370e-01
    x[18,8]   old_TS3   -3.1628428283640370e-01
    x[18,8]   old_TS4   -1.7806985001854891e-01
    x[18,9]   OBJ       -1.2426042857142860e-02
    x[18,9]   onehot_18  1
    x[18,9]   w_lb_18_9  -2.2258731252318614e-02
    x[18,9]   w_ub_18_9  -3.9535535354550462e-02
    x[18,9]   hard_lower  9
    x[18,9]   hard_upper  9
    x[18,9]   old_TS1   -2.0032858127086753e-01
    x[18,9]   old_TS2   -3.5581981819095415e-01
    x[18,9]   old_TS3   -3.5581981819095415e-01
    x[18,9]   old_TS4   -2.0032858127086753e-01
    x[18,10]  OBJ       -6.2130214285714309e-03
    x[18,10]  onehot_18  1
    x[18,10]  w_lb_18_10  -2.2258731252318614e-02
    x[18,10]  w_ub_18_10  -3.9535535354550462e-02
    x[18,10]  hard_lower  10
    x[18,10]  hard_upper  10
    x[18,10]  old_TS1   -2.2258731252318614e-01
    x[18,10]  old_TS2   -3.9535535354550461e-01
    x[18,10]  old_TS3   -3.9535535354550461e-01
    x[18,10]  old_TS4   -2.2258731252318614e-01
    x[18,11]  OBJ       -2.4142438048713188e-18
    x[18,11]  onehot_18  1
    x[18,11]  w_lb_18_11  -2.2258731252318614e-02
    x[18,11]  w_ub_18_11  -3.9535535354550462e-02
    x[18,11]  hard_lower  11
    x[18,11]  hard_upper  11
    x[18,11]  old_TS1   -2.4484604377550476e-01
    x[18,11]  old_TS2   -4.3489088890005506e-01
    x[18,11]  old_TS3   -4.3489088890005506e-01
    x[18,11]  old_TS4   -2.4484604377550476e-01
    x[18,12]  OBJ       6.2130214285714249e-03
    x[18,12]  onehot_18  1
    x[18,12]  w_lb_18_12  -2.2258731252318614e-02
    x[18,12]  w_ub_18_12  -3.9535535354550462e-02
    x[18,12]  hard_lower  12
    x[18,12]  hard_upper  12
    x[18,12]  old_TS1   -2.6710477502782337e-01
    x[18,12]  old_TS2   -4.7442642425460557e-01
    x[18,12]  old_TS3   -4.7442642425460557e-01
    x[18,12]  old_TS4   -2.6710477502782337e-01
    x[18,13]  OBJ       1.2426042857142853e-02
    x[18,13]  onehot_18  1
    x[18,13]  w_lb_18_13  -2.2258731252318614e-02
    x[18,13]  w_ub_18_13  -3.9535535354550462e-02
    x[18,13]  hard_lower  13
    x[18,13]  hard_upper  13
    x[18,13]  old_TS1   -2.8936350628014196e-01
    x[18,13]  old_TS2   -0.513961959609156
    x[18,13]  old_TS3   -0.513961959609156
    x[18,13]  old_TS4   -2.8936350628014196e-01
    x[18,14]  OBJ       1.8639064285714279e-02
    x[18,14]  onehot_18  1
    x[18,14]  w_lb_18_14  -2.2258731252318614e-02
    x[18,14]  w_ub_18_14  -3.9535535354550462e-02
    x[18,14]  hard_lower  14
    x[18,14]  hard_upper  14
    x[18,14]  old_TS1   -3.1162223753246060e-01
    x[18,14]  old_TS2   -5.5349749496370648e-01
    x[18,14]  old_TS3   -5.5349749496370648e-01
    x[18,14]  old_TS4   -3.1162223753246060e-01
    x[18,15]  OBJ       2.4852085714285710e-02
    x[18,15]  onehot_18  1
    x[18,15]  w_lb_18_15  -2.2258731252318614e-02
    x[18,15]  w_ub_18_15  -3.9535535354550462e-02
    x[18,15]  hard_lower  15
    x[18,15]  hard_upper  15
    x[18,15]  old_TS1   -3.3388096878477924e-01
    x[18,15]  old_TS2   -5.9303303031825694e-01
    x[18,15]  old_TS3   -5.9303303031825694e-01
    x[18,15]  old_TS4   -3.3388096878477924e-01
    x[19,0]   OBJ       3.1952666666666664e-02
    x[19,0]   onehot_19  1
    x[19,0]   w_lb_19_0  -2.2258731252318614e-02
    x[19,0]   w_ub_19_0  -3.9535535354550462e-02
    x[19,1]   OBJ       0.0239645
    x[19,1]   onehot_19  1
    x[19,1]   w_lb_19_1  -2.2258731252318614e-02
    x[19,1]   w_ub_19_1  -3.9535535354550462e-02
    x[19,1]   hard_lower  1
    x[19,1]   hard_upper  1
    x[19,1]   old_TS1   -2.2258731252318614e-02
    x[19,1]   old_TS2   -3.9535535354550462e-02
    x[19,1]   old_TS3   -3.9535535354550462e-02
    x[19,1]   old_TS4   -2.2258731252318614e-02
    x[19,2]   OBJ       1.5976333333333335e-02
    x[19,2]   onehot_19  1
    x[19,2]   w_lb_19_2  -2.2258731252318614e-02
    x[19,2]   w_ub_19_2  -3.9535535354550462e-02
    x[19,2]   hard_lower  2
    x[19,2]   hard_upper  2
    x[19,2]   old_TS1   -4.4517462504637229e-02
    x[19,2]   old_TS2   -7.9071070709100924e-02
    x[19,2]   old_TS3   -7.9071070709100924e-02
    x[19,2]   old_TS4   -4.4517462504637229e-02
    x[19,3]   OBJ       0.00798816666666667
    x[19,3]   onehot_19  1
    x[19,3]   w_lb_19_3  -2.2258731252318614e-02
    x[19,3]   w_ub_19_3  -3.9535535354550462e-02
    x[19,3]   hard_lower  3
    x[19,3]   hard_upper  3
    x[19,3]   old_TS1   -6.6776193756955843e-02
    x[19,3]   old_TS2   -1.1860660606365139e-01
    x[19,3]   old_TS3   -1.1860660606365139e-01
    x[19,3]   old_TS4   -6.6776193756955843e-02
    x[19,4]   OBJ       3.9908909510444345e-18
    x[19,4]   onehot_19  1
    x[19,4]   w_lb_19_4  -2.2258731252318614e-02
    x[19,4]   w_ub_19_4  -3.9535535354550462e-02
    x[19,4]   hard_lower  4
    x[19,4]   hard_upper  4
    x[19,4]   old_TS1   -8.9034925009274457e-02
    x[19,4]   old_TS2   -1.5814214141820185e-01
    x[19,4]   old_TS3   -1.5814214141820185e-01
    x[19,4]   old_TS4   -8.9034925009274457e-02
    x[19,5]   OBJ       -7.9881666666666625e-03
    x[19,5]   onehot_19  1
    x[19,5]   w_lb_19_5  -2.2258731252318614e-02
    x[19,5]   w_ub_19_5  -3.9535535354550462e-02
    x[19,5]   hard_lower  5
    x[19,5]   hard_upper  5
    x[19,5]   old_TS1   -1.1129365626159307e-01
    x[19,5]   old_TS2   -1.9767767677275230e-01
    x[19,5]   old_TS3   -1.9767767677275230e-01
    x[19,5]   old_TS4   -1.1129365626159307e-01
    x[19,6]   OBJ       -1.5976333333333329e-02
    x[19,6]   onehot_19  1
    x[19,6]   w_lb_19_6  -2.2258731252318614e-02
    x[19,6]   w_ub_19_6  -3.9535535354550462e-02
    x[19,6]   hard_lower  6
    x[19,6]   hard_upper  6
    x[19,6]   old_TS1   -1.3355238751391169e-01
    x[19,6]   old_TS2   -2.3721321212730279e-01
    x[19,6]   old_TS3   -2.3721321212730279e-01
    x[19,6]   old_TS4   -1.3355238751391169e-01
    x[19,7]   OBJ       -2.3964499999999996e-02
    x[19,7]   onehot_19  1
    x[19,7]   w_lb_19_7  -2.2258731252318614e-02
    x[19,7]   w_ub_19_7  -3.9535535354550462e-02
    x[19,7]   hard_lower  7
    x[19,7]   hard_upper  7
    x[19,7]   old_TS1   -1.5581111876623030e-01
    x[19,7]   old_TS2   -2.7674874748185324e-01
    x[19,7]   old_TS3   -2.7674874748185324e-01
    x[19,7]   old_TS4   -1.5581111876623030e-01
    x[19,8]   OBJ       -3.1952666666666664e-02
    x[19,8]   onehot_19  1
    x[19,8]   w_lb_19_8  -2.2258731252318614e-02
    x[19,8]   w_ub_19_8  -3.9535535354550462e-02
    x[19,8]   hard_lower  8
    x[19,8]   hard_upper  8
    x[19,8]   old_TS1   -1.7806985001854891e-01
    x[19,8]   old_TS2   -3.1628428283640370e-01
    x[19,8]   old_TS3   -3.1628428283640370e-01
    x[19,8]   old_TS4   -1.7806985001854891e-01
    x[19,9]   OBJ       -3.9940833333333328e-02
    x[19,9]   onehot_19  1
    x[19,9]   w_lb_19_9  -2.2258731252318614e-02
    x[19,9]   w_ub_19_9  -3.9535535354550462e-02
    x[19,9]   hard_lower  9
    x[19,9]   hard_upper  9
    x[19,9]   old_TS1   -2.0032858127086753e-01
    x[19,9]   old_TS2   -3.5581981819095415e-01
    x[19,9]   old_TS3   -3.5581981819095415e-01
    x[19,9]   old_TS4   -2.0032858127086753e-01
    x[19,10]  OBJ       -3.1952666666666671e-02
    x[19,10]  onehot_19  1
    x[19,10]  w_lb_19_10  -2.2258731252318614e-02
    x[19,10]  w_ub_19_10  -3.9535535354550462e-02
    x[19,10]  hard_lower  10
    x[19,10]  hard_upper  10
    x[19,10]  old_TS1   -2.2258731252318614e-01
    x[19,10]  old_TS2   -3.9535535354550461e-01
    x[19,10]  old_TS3   -3.9535535354550461e-01
    x[19,10]  old_TS4   -2.2258731252318614e-01
    x[19,11]  OBJ       -2.3964500000000003e-02
    x[19,11]  onehot_19  1
    x[19,11]  w_lb_19_11  -2.2258731252318614e-02
    x[19,11]  w_ub_19_11  -3.9535535354550462e-02
    x[19,11]  hard_lower  11
    x[19,11]  hard_upper  11
    x[19,11]  old_TS1   -2.4484604377550476e-01
    x[19,11]  old_TS2   -4.3489088890005506e-01
    x[19,11]  old_TS3   -4.3489088890005506e-01
    x[19,11]  old_TS4   -2.4484604377550476e-01
    x[19,12]  OBJ       -1.5976333333333339e-02
    x[19,12]  onehot_19  1
    x[19,12]  w_lb_19_12  -2.2258731252318614e-02
    x[19,12]  w_ub_19_12  -3.9535535354550462e-02
    x[19,12]  hard_lower  12
    x[19,12]  hard_upper  12
    x[19,12]  old_TS1   -2.6710477502782337e-01
    x[19,12]  old_TS2   -4.7442642425460557e-01
    x[19,12]  old_TS3   -4.7442642425460557e-01
    x[19,12]  old_TS4   -2.6710477502782337e-01
    x[19,13]  OBJ       -7.9881666666666712e-03
    x[19,13]  onehot_19  1
    x[19,13]  w_lb_19_13  -2.2258731252318614e-02
    x[19,13]  w_ub_19_13  -3.9535535354550462e-02
    x[19,13]  hard_lower  13
    x[19,13]  hard_upper  13
    x[19,13]  old_TS1   -2.8936350628014196e-01
    x[19,13]  old_TS2   -0.513961959609156
    x[19,13]  old_TS3   -0.513961959609156
    x[19,13]  old_TS4   -2.8936350628014196e-01
    x[19,14]  OBJ       -3.9908909510444345e-18
    x[19,14]  onehot_19  1
    x[19,14]  w_lb_19_14  -2.2258731252318614e-02
    x[19,14]  w_ub_19_14  -3.9535535354550462e-02
    x[19,14]  hard_lower  14
    x[19,14]  hard_upper  14
    x[19,14]  old_TS1   -3.1162223753246060e-01
    x[19,14]  old_TS2   -5.5349749496370648e-01
    x[19,14]  old_TS3   -5.5349749496370648e-01
    x[19,14]  old_TS4   -3.1162223753246060e-01
    x[19,15]  OBJ       0.00798816666666666
    x[19,15]  onehot_19  1
    x[19,15]  w_lb_19_15  -2.2258731252318614e-02
    x[19,15]  w_ub_19_15  -3.9535535354550462e-02
    x[19,15]  hard_lower  15
    x[19,15]  hard_upper  15
    x[19,15]  old_TS1   -3.3388096878477924e-01
    x[19,15]  old_TS2   -5.9303303031825694e-01
    x[19,15]  old_TS3   -5.9303303031825694e-01
    x[19,15]  old_TS4   -3.3388096878477924e-01
    x[19,16]  OBJ       1.5976333333333325e-02
    x[19,16]  onehot_19  1
    x[19,16]  w_lb_19_16  -2.2258731252318614e-02
    x[19,16]  w_ub_19_16  -3.9535535354550462e-02
    x[19,16]  hard_lower  16
    x[19,16]  hard_upper  16
    x[19,16]  old_TS1   -3.5613970003709783e-01
    x[19,16]  old_TS2   -6.3256856567280739e-01
    x[19,16]  old_TS3   -6.3256856567280739e-01
    x[19,16]  old_TS4   -3.5613970003709783e-01
    x[19,17]  OBJ       2.3964499999999993e-02
    x[19,17]  onehot_19  1
    x[19,17]  w_lb_19_17  -2.2258731252318614e-02
    x[19,17]  w_ub_19_17  -3.9535535354550462e-02
    x[19,17]  hard_lower  17
    x[19,17]  hard_upper  17
    x[19,17]  old_TS1   -3.7839843128941641e-01
    x[19,17]  old_TS2   -6.7210410102735785e-01
    x[19,17]  old_TS3   -6.7210410102735785e-01
    x[19,17]  old_TS4   -3.7839843128941641e-01
    x[19,18]  OBJ       3.1952666666666657e-02
    x[19,18]  onehot_19  1
    x[19,18]  w_lb_19_18  -2.2258731252318614e-02
    x[19,18]  w_ub_19_18  -3.9535535354550462e-02
    x[19,18]  hard_lower  18
    x[19,18]  hard_upper  18
    x[19,18]  old_TS1   -4.0065716254173506e-01
    x[19,18]  old_TS2   -7.1163963638190830e-01
    x[19,18]  old_TS3   -7.1163963638190830e-01
    x[19,18]  old_TS4   -4.0065716254173506e-01
    x[19,19]  OBJ       3.9940833333333321e-02
    x[19,19]  onehot_19  1
    x[19,19]  w_lb_19_19  -2.2258731252318614e-02
    x[19,19]  w_ub_19_19  -3.9535535354550462e-02
    x[19,19]  hard_lower  19
    x[19,19]  hard_upper  19
    x[19,19]  old_TS1   -4.2291589379405370e-01
    x[19,19]  old_TS2   -7.5117517173645876e-01
    x[19,19]  old_TS3   -7.5117517173645876e-01
    x[19,19]  old_TS4   -4.2291589379405370e-01
    x[20,0]   OBJ       1.8639064285714286e-02
    x[20,0]   onehot_20  1
    x[20,0]   w_lb_20_0  -2.2258731252318614e-02
    x[20,0]   w_ub_20_0  -3.9535535354550462e-02
    x[20,1]   OBJ       1.2426042857142858e-02
    x[20,1]   onehot_20  1
    x[20,1]   w_lb_20_1  -2.2258731252318614e-02
    x[20,1]   w_ub_20_1  -3.9535535354550462e-02
    x[20,1]   hard_lower  1
    x[20,1]   hard_upper  1
    x[20,1]   old_TS1   -2.2258731252318614e-02
    x[20,1]   old_TS2   -3.9535535354550462e-02
    x[20,1]   old_TS3   -3.9535535354550462e-02
    x[20,1]   old_TS4   -2.2258731252318614e-02
    x[20,2]   OBJ       0.00621302142857143
    x[20,2]   onehot_20  1
    x[20,2]   w_lb_20_2  -2.2258731252318614e-02
    x[20,2]   w_ub_20_2  -3.9535535354550462e-02
    x[20,2]   hard_lower  2
    x[20,2]   hard_upper  2
    x[20,2]   old_TS1   -4.4517462504637229e-02
    x[20,2]   old_TS2   -7.9071070709100924e-02
    x[20,2]   old_TS3   -7.9071070709100924e-02
    x[20,2]   old_TS4   -4.4517462504637229e-02
    x[20,3]   OBJ       2.4142438048713188e-18
    x[20,3]   onehot_20  1
    x[20,3]   w_lb_20_3  -2.2258731252318614e-02
    x[20,3]   w_ub_20_3  -3.9535535354550462e-02
    x[20,3]   hard_lower  3
    x[20,3]   hard_upper  3
    x[20,3]   old_TS1   -6.6776193756955843e-02
    x[20,3]   old_TS2   -1.1860660606365139e-01
    x[20,3]   old_TS3   -1.1860660606365139e-01
    x[20,3]   old_TS4   -6.6776193756955843e-02
    x[20,4]   OBJ       -6.2130214285714257e-03
    x[20,4]   onehot_20  1
    x[20,4]   w_lb_20_4  -2.2258731252318614e-02
    x[20,4]   w_ub_20_4  -3.9535535354550462e-02
    x[20,4]   hard_lower  4
    x[20,4]   hard_upper  4
    x[20,4]   old_TS1   -8.9034925009274457e-02
    x[20,4]   old_TS2   -1.5814214141820185e-01
    x[20,4]   old_TS3   -1.5814214141820185e-01
    x[20,4]   old_TS4   -8.9034925009274457e-02
    x[20,5]   OBJ       -1.2426042857142855e-02
    x[20,5]   onehot_20  1
    x[20,5]   w_lb_20_5  -2.2258731252318614e-02
    x[20,5]   w_ub_20_5  -3.9535535354550462e-02
    x[20,5]   hard_lower  5
    x[20,5]   hard_upper  5
    x[20,5]   old_TS1   -1.1129365626159307e-01
    x[20,5]   old_TS2   -1.9767767677275230e-01
    x[20,5]   old_TS3   -1.9767767677275230e-01
    x[20,5]   old_TS4   -1.1129365626159307e-01
    x[20,6]   OBJ       -1.8639064285714282e-02
    x[20,6]   onehot_20  1
    x[20,6]   w_lb_20_6  -2.2258731252318614e-02
    x[20,6]   w_ub_20_6  -3.9535535354550462e-02
    x[20,6]   hard_lower  6
    x[20,6]   hard_upper  6
    x[20,6]   old_TS1   -1.3355238751391169e-01
    x[20,6]   old_TS2   -2.3721321212730279e-01
    x[20,6]   old_TS3   -2.3721321212730279e-01
    x[20,6]   old_TS4   -1.3355238751391169e-01
    x[20,7]   OBJ       -2.4852085714285713e-02
    x[20,7]   onehot_20  1
    x[20,7]   w_lb_20_7  -2.2258731252318614e-02
    x[20,7]   w_ub_20_7  -3.9535535354550462e-02
    x[20,7]   hard_lower  7
    x[20,7]   hard_upper  7
    x[20,7]   old_TS1   -1.5581111876623030e-01
    x[20,7]   old_TS2   -2.7674874748185324e-01
    x[20,7]   old_TS3   -2.7674874748185324e-01
    x[20,7]   old_TS4   -1.5581111876623030e-01
    x[20,8]   OBJ       -1.8639064285714289e-02
    x[20,8]   onehot_20  1
    x[20,8]   w_lb_20_8  -2.2258731252318614e-02
    x[20,8]   w_ub_20_8  -3.9535535354550462e-02
    x[20,8]   hard_lower  8
    x[20,8]   hard_upper  8
    x[20,8]   old_TS1   -1.7806985001854891e-01
    x[20,8]   old_TS2   -3.1628428283640370e-01
    x[20,8]   old_TS3   -3.1628428283640370e-01
    x[20,8]   old_TS4   -1.7806985001854891e-01
    x[20,9]   OBJ       -1.2426042857142860e-02
    x[20,9]   onehot_20  1
    x[20,9]   w_lb_20_9  -2.2258731252318614e-02
    x[20,9]   w_ub_20_9  -3.9535535354550462e-02
    x[20,9]   hard_lower  9
    x[20,9]   hard_upper  9
    x[20,9]   old_TS1   -2.0032858127086753e-01
    x[20,9]   old_TS2   -3.5581981819095415e-01
    x[20,9]   old_TS3   -3.5581981819095415e-01
    x[20,9]   old_TS4   -2.0032858127086753e-01
    x[20,10]  OBJ       -6.2130214285714309e-03
    x[20,10]  onehot_20  1
    x[20,10]  w_lb_20_10  -2.2258731252318614e-02
    x[20,10]  w_ub_20_10  -3.9535535354550462e-02
    x[20,10]  hard_lower  10
    x[20,10]  hard_upper  10
    x[20,10]  old_TS1   -2.2258731252318614e-01
    x[20,10]  old_TS2   -3.9535535354550461e-01
    x[20,10]  old_TS3   -3.9535535354550461e-01
    x[20,10]  old_TS4   -2.2258731252318614e-01
    x[20,11]  OBJ       -2.4142438048713188e-18
    x[20,11]  onehot_20  1
    x[20,11]  w_lb_20_11  -2.2258731252318614e-02
    x[20,11]  w_ub_20_11  -3.9535535354550462e-02
    x[20,11]  hard_lower  11
    x[20,11]  hard_upper  11
    x[20,11]  old_TS1   -2.4484604377550476e-01
    x[20,11]  old_TS2   -4.3489088890005506e-01
    x[20,11]  old_TS3   -4.3489088890005506e-01
    x[20,11]  old_TS4   -2.4484604377550476e-01
    x[20,12]  OBJ       6.2130214285714249e-03
    x[20,12]  onehot_20  1
    x[20,12]  w_lb_20_12  -2.2258731252318614e-02
    x[20,12]  w_ub_20_12  -3.9535535354550462e-02
    x[20,12]  hard_lower  12
    x[20,12]  hard_upper  12
    x[20,12]  old_TS1   -2.6710477502782337e-01
    x[20,12]  old_TS2   -4.7442642425460557e-01
    x[20,12]  old_TS3   -4.7442642425460557e-01
    x[20,12]  old_TS4   -2.6710477502782337e-01
    x[20,13]  OBJ       1.2426042857142853e-02
    x[20,13]  onehot_20  1
    x[20,13]  w_lb_20_13  -2.2258731252318614e-02
    x[20,13]  w_ub_20_13  -3.9535535354550462e-02
    x[20,13]  hard_lower  13
    x[20,13]  hard_upper  13
    x[20,13]  old_TS1   -2.8936350628014196e-01
    x[20,13]  old_TS2   -0.513961959609156
    x[20,13]  old_TS3   -0.513961959609156
    x[20,13]  old_TS4   -2.8936350628014196e-01
    x[20,14]  OBJ       1.8639064285714279e-02
    x[20,14]  onehot_20  1
    x[20,14]  w_lb_20_14  -2.2258731252318614e-02
    x[20,14]  w_ub_20_14  -3.9535535354550462e-02
    x[20,14]  hard_lower  14
    x[20,14]  hard_upper  14
    x[20,14]  old_TS1   -3.1162223753246060e-01
    x[20,14]  old_TS2   -5.5349749496370648e-01
    x[20,14]  old_TS3   -5.5349749496370648e-01
    x[20,14]  old_TS4   -3.1162223753246060e-01
    x[20,15]  OBJ       2.4852085714285710e-02
    x[20,15]  onehot_20  1
    x[20,15]  w_lb_20_15  -2.2258731252318614e-02
    x[20,15]  w_ub_20_15  -3.9535535354550462e-02
    x[20,15]  hard_lower  15
    x[20,15]  hard_upper  15
    x[20,15]  old_TS1   -3.3388096878477924e-01
    x[20,15]  old_TS2   -5.9303303031825694e-01
    x[20,15]  old_TS3   -5.9303303031825694e-01
    x[20,15]  old_TS4   -3.3388096878477924e-01
    x[21,0]   OBJ       3.1952666666666664e-02
    x[21,0]   onehot_21  1
    x[21,0]   w_lb_21_0  -2.2258731252318614e-02
    x[21,0]   w_ub_21_0  -3.9535535354550462e-02
    x[21,1]   OBJ       0.0239645
    x[21,1]   onehot_21  1
    x[21,1]   w_lb_21_1  -2.2258731252318614e-02
    x[21,1]   w_ub_21_1  -3.9535535354550462e-02
    x[21,1]   hard_lower  1
    x[21,1]   hard_upper  1
    x[21,1]   old_TS1   -2.2258731252318614e-02
    x[21,1]   old_TS2   -3.9535535354550462e-02
    x[21,1]   old_TS3   -3.9535535354550462e-02
    x[21,1]   old_TS4   -2.2258731252318614e-02
    x[21,2]   OBJ       1.5976333333333335e-02
    x[21,2]   onehot_21  1
    x[21,2]   w_lb_21_2  -2.2258731252318614e-02
    x[21,2]   w_ub_21_2  -3.9535535354550462e-02
    x[21,2]   hard_lower  2
    x[21,2]   hard_upper  2
    x[21,2]   old_TS1   -4.4517462504637229e-02
    x[21,2]   old_TS2   -7.9071070709100924e-02
    x[21,2]   old_TS3   -7.9071070709100924e-02
    x[21,2]   old_TS4   -4.4517462504637229e-02
    x[21,3]   OBJ       0.00798816666666667
    x[21,3]   onehot_21  1
    x[21,3]   w_lb_21_3  -2.2258731252318614e-02
    x[21,3]   w_ub_21_3  -3.9535535354550462e-02
    x[21,3]   hard_lower  3
    x[21,3]   hard_upper  3
    x[21,3]   old_TS1   -6.6776193756955843e-02
    x[21,3]   old_TS2   -1.1860660606365139e-01
    x[21,3]   old_TS3   -1.1860660606365139e-01
    x[21,3]   old_TS4   -6.6776193756955843e-02
    x[21,4]   OBJ       3.9908909510444345e-18
    x[21,4]   onehot_21  1
    x[21,4]   w_lb_21_4  -2.2258731252318614e-02
    x[21,4]   w_ub_21_4  -3.9535535354550462e-02
    x[21,4]   hard_lower  4
    x[21,4]   hard_upper  4
    x[21,4]   old_TS1   -8.9034925009274457e-02
    x[21,4]   old_TS2   -1.5814214141820185e-01
    x[21,4]   old_TS3   -1.5814214141820185e-01
    x[21,4]   old_TS4   -8.9034925009274457e-02
    x[21,5]   OBJ       -7.9881666666666625e-03
    x[21,5]   onehot_21  1
    x[21,5]   w_lb_21_5  -2.2258731252318614e-02
    x[21,5]   w_ub_21_5  -3.9535535354550462e-02
    x[21,5]   hard_lower  5
    x[21,5]   hard_upper  5
    x[21,5]   old_TS1   -1.1129365626159307e-01
    x[21,5]   old_TS2   -1.9767767677275230e-01
    x[21,5]   old_TS3   -1.9767767677275230e-01
    x[21,5]   old_TS4   -1.1129365626159307e-01
    x[21,6]   OBJ       -1.5976333333333329e-02
    x[21,6]   onehot_21  1
    x[21,6]   w_lb_21_6  -2.2258731252318614e-02
    x[21,6]   w_ub_21_6  -3.9535535354550462e-02
    x[21,6]   hard_lower  6
    x[21,6]   hard_upper  6
    x[21,6]   old_TS1   -1.3355238751391169e-01
    x[21,6]   old_TS2   -2.3721321212730279e-01
    x[21,6]   old_TS3   -2.3721321212730279e-01
    x[21,6]   old_TS4   -1.3355238751391169e-01
    x[21,7]   OBJ       -2.3964499999999996e-02
    x[21,7]   onehot_21  1
    x[21,7]   w_lb_21_7  -2.2258731252318614e-02
    x[21,7]   w_ub_21_7  -3.9535535354550462e-02
    x[21,7]   hard_lower  7
    x[21,7]   hard_upper  7
    x[21,7]   old_TS1   -1.5581111876623030e-01
    x[21,7]   old_TS2   -2.7674874748185324e-01
    x[21,7]   old_TS3   -2.7674874748185324e-01
    x[21,7]   old_TS4   -1.5581111876623030e-01
    x[21,8]   OBJ       -3.1952666666666664e-02
    x[21,8]   onehot_21  1
    x[21,8]   w_lb_21_8  -2.2258731252318614e-02
    x[21,8]   w_ub_21_8  -3.9535535354550462e-02
    x[21,8]   hard_lower  8
    x[21,8]   hard_upper  8
    x[21,8]   old_TS1   -1.7806985001854891e-01
    x[21,8]   old_TS2   -3.1628428283640370e-01
    x[21,8]   old_TS3   -3.1628428283640370e-01
    x[21,8]   old_TS4   -1.7806985001854891e-01
    x[21,9]   OBJ       -3.9940833333333328e-02
    x[21,9]   onehot_21  1
    x[21,9]   w_lb_21_9  -2.2258731252318614e-02
    x[21,9]   w_ub_21_9  -3.9535535354550462e-02
    x[21,9]   hard_lower  9
    x[21,9]   hard_upper  9
    x[21,9]   old_TS1   -2.0032858127086753e-01
    x[21,9]   old_TS2   -3.5581981819095415e-01
    x[21,9]   old_TS3   -3.5581981819095415e-01
    x[21,9]   old_TS4   -2.0032858127086753e-01
    x[21,10]  OBJ       -3.1952666666666671e-02
    x[21,10]  onehot_21  1
    x[21,10]  w_lb_21_10  -2.2258731252318614e-02
    x[21,10]  w_ub_21_10  -3.9535535354550462e-02
    x[21,10]  hard_lower  10
    x[21,10]  hard_upper  10
    x[21,10]  old_TS1   -2.2258731252318614e-01
    x[21,10]  old_TS2   -3.9535535354550461e-01
    x[21,10]  old_TS3   -3.9535535354550461e-01
    x[21,10]  old_TS4   -2.2258731252318614e-01
    x[21,11]  OBJ       -2.3964500000000003e-02
    x[21,11]  onehot_21  1
    x[21,11]  w_lb_21_11  -2.2258731252318614e-02
    x[21,11]  w_ub_21_11  -3.9535535354550462e-02
    x[21,11]  hard_lower  11
    x[21,11]  hard_upper  11
    x[21,11]  old_TS1   -2.4484604377550476e-01
    x[21,11]  old_TS2   -4.3489088890005506e-01
    x[21,11]  old_TS3   -4.3489088890005506e-01
    x[21,11]  old_TS4   -2.4484604377550476e-01
    x[21,12]  OBJ       -1.5976333333333339e-02
    x[21,12]  onehot_21  1
    x[21,12]  w_lb_21_12  -2.2258731252318614e-02
    x[21,12]  w_ub_21_12  -3.9535535354550462e-02
    x[21,12]  hard_lower  12
    x[21,12]  hard_upper  12
    x[21,12]  old_TS1   -2.6710477502782337e-01
    x[21,12]  old_TS2   -4.7442642425460557e-01
    x[21,12]  old_TS3   -4.7442642425460557e-01
    x[21,12]  old_TS4   -2.6710477502782337e-01
    x[21,13]  OBJ       -7.9881666666666712e-03
    x[21,13]  onehot_21  1
    x[21,13]  w_lb_21_13  -2.2258731252318614e-02
    x[21,13]  w_ub_21_13  -3.9535535354550462e-02
    x[21,13]  hard_lower  13
    x[21,13]  hard_upper  13
    x[21,13]  old_TS1   -2.8936350628014196e-01
    x[21,13]  old_TS2   -0.513961959609156
    x[21,13]  old_TS3   -0.513961959609156
    x[21,13]  old_TS4   -2.8936350628014196e-01
    x[21,14]  OBJ       -3.9908909510444345e-18
    x[21,14]  onehot_21  1
    x[21,14]  w_lb_21_14  -2.2258731252318614e-02
    x[21,14]  w_ub_21_14  -3.9535535354550462e-02
    x[21,14]  hard_lower  14
    x[21,14]  hard_upper  14
    x[21,14]  old_TS1   -3.1162223753246060e-01
    x[21,14]  old_TS2   -5.5349749496370648e-01
    x[21,14]  old_TS3   -5.5349749496370648e-01
    x[21,14]  old_TS4   -3.1162223753246060e-01
    x[21,15]  OBJ       0.00798816666666666
    x[21,15]  onehot_21  1
    x[21,15]  w_lb_21_15  -2.2258731252318614e-02
    x[21,15]  w_ub_21_15  -3.9535535354550462e-02
    x[21,15]  hard_lower  15
    x[21,15]  hard_upper  15
    x[21,15]  old_TS1   -3.3388096878477924e-01
    x[21,15]  old_TS2   -5.9303303031825694e-01
    x[21,15]  old_TS3   -5.9303303031825694e-01
    x[21,15]  old_TS4   -3.3388096878477924e-01
    x[21,16]  OBJ       1.5976333333333325e-02
    x[21,16]  onehot_21  1
    x[21,16]  w_lb_21_16  -2.2258731252318614e-02
    x[21,16]  w_ub_21_16  -3.9535535354550462e-02
    x[21,16]  hard_lower  16
    x[21,16]  hard_upper  16
    x[21,16]  old_TS1   -3.5613970003709783e-01
    x[21,16]  old_TS2   -6.3256856567280739e-01
    x[21,16]  old_TS3   -6.3256856567280739e-01
    x[21,16]  old_TS4   -3.5613970003709783e-01
    x[21,17]  OBJ       2.3964499999999993e-02
    x[21,17]  onehot_21  1
    x[21,17]  w_lb_21_17  -2.2258731252318614e-02
    x[21,17]  w_ub_21_17  -3.9535535354550462e-02
    x[21,17]  hard_lower  17
    x[21,17]  hard_upper  17
    x[21,17]  old_TS1   -3.7839843128941641e-01
    x[21,17]  old_TS2   -6.7210410102735785e-01
    x[21,17]  old_TS3   -6.7210410102735785e-01
    x[21,17]  old_TS4   -3.7839843128941641e-01
    x[21,18]  OBJ       3.1952666666666657e-02
    x[21,18]  onehot_21  1
    x[21,18]  w_lb_21_18  -2.2258731252318614e-02
    x[21,18]  w_ub_21_18  -3.9535535354550462e-02
    x[21,18]  hard_lower  18
    x[21,18]  hard_upper  18
    x[21,18]  old_TS1   -4.0065716254173506e-01
    x[21,18]  old_TS2   -7.1163963638190830e-01
    x[21,18]  old_TS3   -7.1163963638190830e-01
    x[21,18]  old_TS4   -4.0065716254173506e-01
    x[21,19]  OBJ       3.9940833333333321e-02
    x[21,19]  onehot_21  1
    x[21,19]  w_lb_21_19  -2.2258731252318614e-02
    x[21,19]  w_ub_21_19  -3.9535535354550462e-02
    x[21,19]  hard_lower  19
    x[21,19]  hard_upper  19
    x[21,19]  old_TS1   -4.2291589379405370e-01
    x[21,19]  old_TS2   -7.5117517173645876e-01
    x[21,19]  old_TS3   -7.5117517173645876e-01
    x[21,19]  old_TS4   -4.2291589379405370e-01
    x[22,0]   OBJ       4.4378699999999993e-02
    x[22,0]   onehot_22  1
    x[22,0]   w_lb_22_0  -2.2258731252318614e-02
    x[22,0]   w_ub_22_0  -3.9535535354550462e-02
    x[22,1]   OBJ       3.5502959999999993e-02
    x[22,1]   onehot_22  1
    x[22,1]   w_lb_22_1  -2.2258731252318614e-02
    x[22,1]   w_ub_22_1  -3.9535535354550462e-02
    x[22,1]   hard_lower  1
    x[22,1]   hard_upper  1
    x[22,1]   old_TS1   -2.2258731252318614e-02
    x[22,1]   old_TS2   -3.9535535354550462e-02
    x[22,1]   old_TS3   -3.9535535354550462e-02
    x[22,1]   old_TS4   -2.2258731252318614e-02
    x[22,2]   OBJ       2.6627219999999997e-02
    x[22,2]   onehot_22  1
    x[22,2]   w_lb_22_2  -2.2258731252318614e-02
    x[22,2]   w_ub_22_2  -3.9535535354550462e-02
    x[22,2]   hard_lower  2
    x[22,2]   hard_upper  2
    x[22,2]   old_TS1   -4.4517462504637229e-02
    x[22,2]   old_TS2   -7.9071070709100924e-02
    x[22,2]   old_TS3   -7.9071070709100924e-02
    x[22,2]   old_TS4   -4.4517462504637229e-02
    x[22,3]   OBJ       1.7751479999999993e-02
    x[22,3]   onehot_22  1
    x[22,3]   w_lb_22_3  -2.2258731252318614e-02
    x[22,3]   w_ub_22_3  -3.9535535354550462e-02
    x[22,3]   hard_lower  3
    x[22,3]   hard_upper  3
    x[22,3]   old_TS1   -6.6776193756955843e-02
    x[22,3]   old_TS2   -1.1860660606365139e-01
    x[22,3]   old_TS3   -1.1860660606365139e-01
    x[22,3]   old_TS4   -6.6776193756955843e-02
    x[22,4]   OBJ       8.8757399999999948e-03
    x[22,4]   onehot_22  1
    x[22,4]   w_lb_22_4  -2.2258731252318614e-02
    x[22,4]   w_ub_22_4  -3.9535535354550462e-02
    x[22,4]   hard_lower  4
    x[22,4]   hard_upper  4
    x[22,4]   old_TS1   -8.9034925009274457e-02
    x[22,4]   old_TS2   -1.5814214141820185e-01
    x[22,4]   old_TS3   -1.5814214141820185e-01
    x[22,4]   old_TS4   -8.9034925009274457e-02
    x[22,5]   OBJ       -4.9270254542932435e-18
    x[22,5]   onehot_22  1
    x[22,5]   w_lb_22_5  -2.2258731252318614e-02
    x[22,5]   w_ub_22_5  -3.9535535354550462e-02
    x[22,5]   hard_lower  5
    x[22,5]   hard_upper  5
    x[22,5]   old_TS1   -1.1129365626159307e-01
    x[22,5]   old_TS2   -1.9767767677275230e-01
    x[22,5]   old_TS3   -1.9767767677275230e-01
    x[22,5]   old_TS4   -1.1129365626159307e-01
    x[22,6]   OBJ       -8.8757400000000070e-03
    x[22,6]   onehot_22  1
    x[22,6]   w_lb_22_6  -2.2258731252318614e-02
    x[22,6]   w_ub_22_6  -3.9535535354550462e-02
    x[22,6]   hard_lower  6
    x[22,6]   hard_upper  6
    x[22,6]   old_TS1   -1.3355238751391169e-01
    x[22,6]   old_TS2   -2.3721321212730279e-01
    x[22,6]   old_TS3   -2.3721321212730279e-01
    x[22,6]   old_TS4   -1.3355238751391169e-01
    x[22,7]   OBJ       -1.7751480000000007e-02
    x[22,7]   onehot_22  1
    x[22,7]   w_lb_22_7  -2.2258731252318614e-02
    x[22,7]   w_ub_22_7  -3.9535535354550462e-02
    x[22,7]   hard_lower  7
    x[22,7]   hard_upper  7
    x[22,7]   old_TS1   -1.5581111876623030e-01
    x[22,7]   old_TS2   -2.7674874748185324e-01
    x[22,7]   old_TS3   -2.7674874748185324e-01
    x[22,7]   old_TS4   -1.5581111876623030e-01
    x[22,8]   OBJ       -2.6627220000000007e-02
    x[22,8]   onehot_22  1
    x[22,8]   w_lb_22_8  -2.2258731252318614e-02
    x[22,8]   w_ub_22_8  -3.9535535354550462e-02
    x[22,8]   hard_lower  8
    x[22,8]   hard_upper  8
    x[22,8]   old_TS1   -1.7806985001854891e-01
    x[22,8]   old_TS2   -3.1628428283640370e-01
    x[22,8]   old_TS3   -3.1628428283640370e-01
    x[22,8]   old_TS4   -1.7806985001854891e-01
    x[22,9]   OBJ       -3.5502960000000007e-02
    x[22,9]   onehot_22  1
    x[22,9]   w_lb_22_9  -2.2258731252318614e-02
    x[22,9]   w_ub_22_9  -3.9535535354550462e-02
    x[22,9]   hard_lower  9
    x[22,9]   hard_upper  9
    x[22,9]   old_TS1   -2.0032858127086753e-01
    x[22,9]   old_TS2   -3.5581981819095415e-01
    x[22,9]   old_TS3   -3.5581981819095415e-01
    x[22,9]   old_TS4   -2.0032858127086753e-01
    x[22,10]  OBJ       -0.0443787
    x[22,10]  onehot_22  1
    x[22,10]  w_lb_22_10  -2.2258731252318614e-02
    x[22,10]  w_ub_22_10  -3.9535535354550462e-02
    x[22,10]  hard_lower  10
    x[22,10]  hard_upper  10
    x[22,10]  old_TS1   -2.2258731252318614e-01
    x[22,10]  old_TS2   -3.9535535354550461e-01
    x[22,10]  old_TS3   -3.9535535354550461e-01
    x[22,10]  old_TS4   -2.2258731252318614e-01
    x[22,11]  OBJ       -0.03550296
    x[22,11]  onehot_22  1
    x[22,11]  w_lb_22_11  -2.2258731252318614e-02
    x[22,11]  w_ub_22_11  -3.9535535354550462e-02
    x[22,11]  hard_lower  11
    x[22,11]  hard_upper  11
    x[22,11]  old_TS1   -2.4484604377550476e-01
    x[22,11]  old_TS2   -4.3489088890005506e-01
    x[22,11]  old_TS3   -4.3489088890005506e-01
    x[22,11]  old_TS4   -2.4484604377550476e-01
    x[22,12]  OBJ       -0.02662722
    x[22,12]  onehot_22  1
    x[22,12]  w_lb_22_12  -2.2258731252318614e-02
    x[22,12]  w_ub_22_12  -3.9535535354550462e-02
    x[22,12]  hard_lower  12
    x[22,12]  hard_upper  12
    x[22,12]  old_TS1   -2.6710477502782337e-01
    x[22,12]  old_TS2   -4.7442642425460557e-01
    x[22,12]  old_TS3   -4.7442642425460557e-01
    x[22,12]  old_TS4   -2.6710477502782337e-01
    x[22,13]  OBJ       -1.7751479999999997e-02
    x[22,13]  onehot_22  1
    x[22,13]  w_lb_22_13  -2.2258731252318614e-02
    x[22,13]  w_ub_22_13  -3.9535535354550462e-02
    x[22,13]  hard_lower  13
    x[22,13]  hard_upper  13
    x[22,13]  old_TS1   -2.8936350628014196e-01
    x[22,13]  old_TS2   -0.513961959609156
    x[22,13]  old_TS3   -0.513961959609156
    x[22,13]  old_TS4   -2.8936350628014196e-01
    x[22,14]  OBJ       -8.8757399999999965e-03
    x[22,14]  onehot_22  1
    x[22,14]  w_lb_22_14  -2.2258731252318614e-02
    x[22,14]  w_ub_22_14  -3.9535535354550462e-02
    x[22,14]  hard_lower  14
    x[22,14]  hard_upper  14
    x[22,14]  old_TS1   -3.1162223753246060e-01
    x[22,14]  old_TS2   -5.5349749496370648e-01
    x[22,14]  old_TS3   -5.5349749496370648e-01
    x[22,14]  old_TS4   -3.1162223753246060e-01
    x[22,15]  OBJ       4.9270254542932435e-18
    x[22,15]  onehot_22  1
    x[22,15]  w_lb_22_15  -2.2258731252318614e-02
    x[22,15]  w_ub_22_15  -3.9535535354550462e-02
    x[22,15]  hard_lower  15
    x[22,15]  hard_upper  15
    x[22,15]  old_TS1   -3.3388096878477924e-01
    x[22,15]  old_TS2   -5.9303303031825694e-01
    x[22,15]  old_TS3   -5.9303303031825694e-01
    x[22,15]  old_TS4   -3.3388096878477924e-01
    x[22,16]  OBJ       8.8757400000000052e-03
    x[22,16]  onehot_22  1
    x[22,16]  w_lb_22_16  -2.2258731252318614e-02
    x[22,16]  w_ub_22_16  -3.9535535354550462e-02
    x[22,16]  hard_lower  16
    x[22,16]  hard_upper  16
    x[22,16]  old_TS1   -3.5613970003709783e-01
    x[22,16]  old_TS2   -6.3256856567280739e-01
    x[22,16]  old_TS3   -6.3256856567280739e-01
    x[22,16]  old_TS4   -3.5613970003709783e-01
    x[22,17]  OBJ       1.7751480000000004e-02
    x[22,17]  onehot_22  1
    x[22,17]  w_lb_22_17  -2.2258731252318614e-02
    x[22,17]  w_ub_22_17  -3.9535535354550462e-02
    x[22,17]  hard_lower  17
    x[22,17]  hard_upper  17
    x[22,17]  old_TS1   -3.7839843128941641e-01
    x[22,17]  old_TS2   -6.7210410102735785e-01
    x[22,17]  old_TS3   -6.7210410102735785e-01
    x[22,17]  old_TS4   -3.7839843128941641e-01
    x[22,18]  OBJ       2.6627220000000004e-02
    x[22,18]  onehot_22  1
    x[22,18]  w_lb_22_18  -2.2258731252318614e-02
    x[22,18]  w_ub_22_18  -3.9535535354550462e-02
    x[22,18]  hard_lower  18
    x[22,18]  hard_upper  18
    x[22,18]  old_TS1   -4.0065716254173506e-01
    x[22,18]  old_TS2   -7.1163963638190830e-01
    x[22,18]  old_TS3   -7.1163963638190830e-01
    x[22,18]  old_TS4   -4.0065716254173506e-01
    x[22,19]  OBJ       0.03550296
    x[22,19]  onehot_22  1
    x[22,19]  w_lb_22_19  -2.2258731252318614e-02
    x[22,19]  w_ub_22_19  -3.9535535354550462e-02
    x[22,19]  hard_lower  19
    x[22,19]  hard_upper  19
    x[22,19]  old_TS1   -4.2291589379405370e-01
    x[22,19]  old_TS2   -7.5117517173645876e-01
    x[22,19]  old_TS3   -7.5117517173645876e-01
    x[22,19]  old_TS4   -4.2291589379405370e-01
    x[23,0]   OBJ       2.8402349999999996e-02
    x[23,0]   onehot_23  1
    x[23,0]   w_lb_23_0  -2.2258731252318614e-02
    x[23,0]   w_ub_23_0  -3.9535535354550462e-02
    x[23,1]   OBJ       2.1301762499999995e-02
    x[23,1]   onehot_23  1
    x[23,1]   w_lb_23_1  -2.2258731252318614e-02
    x[23,1]   w_ub_23_1  -3.9535535354550462e-02
    x[23,1]   hard_lower  1
    x[23,1]   hard_upper  1
    x[23,1]   old_TS1   -2.2258731252318614e-02
    x[23,1]   old_TS2   -3.9535535354550462e-02
    x[23,1]   old_TS3   -3.9535535354550462e-02
    x[23,1]   old_TS4   -2.2258731252318614e-02
    x[23,2]   OBJ       1.4201174999999998e-02
    x[23,2]   onehot_23  1
    x[23,2]   w_lb_23_2  -2.2258731252318614e-02
    x[23,2]   w_ub_23_2  -3.9535535354550462e-02
    x[23,2]   hard_lower  2
    x[23,2]   hard_upper  2
    x[23,2]   old_TS1   -4.4517462504637229e-02
    x[23,2]   old_TS2   -7.9071070709100924e-02
    x[23,2]   old_TS3   -7.9071070709100924e-02
    x[23,2]   old_TS4   -4.4517462504637229e-02
    x[23,3]   OBJ       7.1005874999999991e-03
    x[23,3]   onehot_23  1
    x[23,3]   w_lb_23_3  -2.2258731252318614e-02
    x[23,3]   w_ub_23_3  -3.9535535354550462e-02
    x[23,3]   hard_lower  3
    x[23,3]   hard_upper  3
    x[23,3]   old_TS1   -6.6776193756955843e-02
    x[23,3]   old_TS2   -1.1860660606365139e-01
    x[23,3]   old_TS3   -1.1860660606365139e-01
    x[23,3]   old_TS4   -6.6776193756955843e-02
    x[23,4]   onehot_23  1
    x[23,4]   w_lb_23_4  -2.2258731252318614e-02
    x[23,4]   w_ub_23_4  -3.9535535354550462e-02
    x[23,4]   hard_lower  4
    x[23,4]   hard_upper  4
    x[23,4]   old_TS1   -8.9034925009274457e-02
    x[23,4]   old_TS2   -1.5814214141820185e-01
    x[23,4]   old_TS3   -1.5814214141820185e-01
    x[23,4]   old_TS4   -8.9034925009274457e-02
    x[23,5]   OBJ       -7.1005874999999991e-03
    x[23,5]   onehot_23  1
    x[23,5]   w_lb_23_5  -2.2258731252318614e-02
    x[23,5]   w_ub_23_5  -3.9535535354550462e-02
    x[23,5]   hard_lower  5
    x[23,5]   hard_upper  5
    x[23,5]   old_TS1   -1.1129365626159307e-01
    x[23,5]   old_TS2   -1.9767767677275230e-01
    x[23,5]   old_TS3   -1.9767767677275230e-01
    x[23,5]   old_TS4   -1.1129365626159307e-01
    x[23,6]   OBJ       -1.4201174999999998e-02
    x[23,6]   onehot_23  1
    x[23,6]   w_lb_23_6  -2.2258731252318614e-02
    x[23,6]   w_ub_23_6  -3.9535535354550462e-02
    x[23,6]   hard_lower  6
    x[23,6]   hard_upper  6
    x[23,6]   old_TS1   -1.3355238751391169e-01
    x[23,6]   old_TS2   -2.3721321212730279e-01
    x[23,6]   old_TS3   -2.3721321212730279e-01
    x[23,6]   old_TS4   -1.3355238751391169e-01
    x[23,7]   OBJ       -2.1301762499999998e-02
    x[23,7]   onehot_23  1
    x[23,7]   w_lb_23_7  -2.2258731252318614e-02
    x[23,7]   w_ub_23_7  -3.9535535354550462e-02
    x[23,7]   hard_lower  7
    x[23,7]   hard_upper  7
    x[23,7]   old_TS1   -1.5581111876623030e-01
    x[23,7]   old_TS2   -2.7674874748185324e-01
    x[23,7]   old_TS3   -2.7674874748185324e-01
    x[23,7]   old_TS4   -1.5581111876623030e-01
    x[23,8]   OBJ       -2.8402349999999996e-02
    x[23,8]   onehot_23  1
    x[23,8]   w_lb_23_8  -2.2258731252318614e-02
    x[23,8]   w_ub_23_8  -3.9535535354550462e-02
    x[23,8]   hard_lower  8
    x[23,8]   hard_upper  8
    x[23,8]   old_TS1   -1.7806985001854891e-01
    x[23,8]   old_TS2   -3.1628428283640370e-01
    x[23,8]   old_TS3   -3.1628428283640370e-01
    x[23,8]   old_TS4   -1.7806985001854891e-01
    x[23,9]   OBJ       -2.1301762499999998e-02
    x[23,9]   onehot_23  1
    x[23,9]   w_lb_23_9  -2.2258731252318614e-02
    x[23,9]   w_ub_23_9  -3.9535535354550462e-02
    x[23,9]   hard_lower  9
    x[23,9]   hard_upper  9
    x[23,9]   old_TS1   -2.0032858127086753e-01
    x[23,9]   old_TS2   -3.5581981819095415e-01
    x[23,9]   old_TS3   -3.5581981819095415e-01
    x[23,9]   old_TS4   -2.0032858127086753e-01
    x[23,10]  OBJ       -1.4201174999999998e-02
    x[23,10]  onehot_23  1
    x[23,10]  w_lb_23_10  -2.2258731252318614e-02
    x[23,10]  w_ub_23_10  -3.9535535354550462e-02
    x[23,10]  hard_lower  10
    x[23,10]  hard_upper  10
    x[23,10]  old_TS1   -2.2258731252318614e-01
    x[23,10]  old_TS2   -3.9535535354550461e-01
    x[23,10]  old_TS3   -3.9535535354550461e-01
    x[23,10]  old_TS4   -2.2258731252318614e-01
    x[23,11]  OBJ       -7.1005874999999991e-03
    x[23,11]  onehot_23  1
    x[23,11]  w_lb_23_11  -2.2258731252318614e-02
    x[23,11]  w_ub_23_11  -3.9535535354550462e-02
    x[23,11]  hard_lower  11
    x[23,11]  hard_upper  11
    x[23,11]  old_TS1   -2.4484604377550476e-01
    x[23,11]  old_TS2   -4.3489088890005506e-01
    x[23,11]  old_TS3   -4.3489088890005506e-01
    x[23,11]  old_TS4   -2.4484604377550476e-01
    x[23,12]  onehot_23  1
    x[23,12]  w_lb_23_12  -2.2258731252318614e-02
    x[23,12]  w_ub_23_12  -3.9535535354550462e-02
    x[23,12]  hard_lower  12
    x[23,12]  hard_upper  12
    x[23,12]  old_TS1   -2.6710477502782337e-01
    x[23,12]  old_TS2   -4.7442642425460557e-01
    x[23,12]  old_TS3   -4.7442642425460557e-01
    x[23,12]  old_TS4   -2.6710477502782337e-01
    x[23,13]  OBJ       7.1005874999999991e-03
    x[23,13]  onehot_23  1
    x[23,13]  w_lb_23_13  -2.2258731252318614e-02
    x[23,13]  w_ub_23_13  -3.9535535354550462e-02
    x[23,13]  hard_lower  13
    x[23,13]  hard_upper  13
    x[23,13]  old_TS1   -2.8936350628014196e-01
    x[23,13]  old_TS2   -0.513961959609156
    x[23,13]  old_TS3   -0.513961959609156
    x[23,13]  old_TS4   -2.8936350628014196e-01
    x[23,14]  OBJ       1.4201174999999998e-02
    x[23,14]  onehot_23  1
    x[23,14]  w_lb_23_14  -2.2258731252318614e-02
    x[23,14]  w_ub_23_14  -3.9535535354550462e-02
    x[23,14]  hard_lower  14
    x[23,14]  hard_upper  14
    x[23,14]  old_TS1   -3.1162223753246060e-01
    x[23,14]  old_TS2   -5.5349749496370648e-01
    x[23,14]  old_TS3   -5.5349749496370648e-01
    x[23,14]  old_TS4   -3.1162223753246060e-01
    x[23,15]  OBJ       2.1301762499999995e-02
    x[23,15]  onehot_23  1
    x[23,15]  w_lb_23_15  -2.2258731252318614e-02
    x[23,15]  w_ub_23_15  -3.9535535354550462e-02
    x[23,15]  hard_lower  15
    x[23,15]  hard_upper  15
    x[23,15]  old_TS1   -3.3388096878477924e-01
    x[23,15]  old_TS2   -5.9303303031825694e-01
    x[23,15]  old_TS3   -5.9303303031825694e-01
    x[23,15]  old_TS4   -3.3388096878477924e-01
    x[24,0]   OBJ       0.0075
    x[24,0]   onehot_24  1
    x[24,0]   w_lb_24_0  -2.2258731252318614e-02
    x[24,0]   w_ub_24_0  -3.9535535354550462e-02
    x[24,1]   OBJ       0.00375
    x[24,1]   onehot_24  1
    x[24,1]   w_lb_24_1  -2.2258731252318614e-02
    x[24,1]   w_ub_24_1  -3.9535535354550462e-02
    x[24,1]   hard_lower  1
    x[24,1]   hard_upper  1
    x[24,1]   old_TS1   -2.2258731252318614e-02
    x[24,1]   old_TS2   -3.9535535354550462e-02
    x[24,1]   old_TS3   -3.9535535354550462e-02
    x[24,1]   old_TS4   -2.2258731252318614e-02
    x[24,2]   onehot_24  1
    x[24,2]   w_lb_24_2  -2.2258731252318614e-02
    x[24,2]   w_ub_24_2  -3.9535535354550462e-02
    x[24,2]   hard_lower  2
    x[24,2]   hard_upper  2
    x[24,2]   old_TS1   -4.4517462504637229e-02
    x[24,2]   old_TS2   -7.9071070709100924e-02
    x[24,2]   old_TS3   -7.9071070709100924e-02
    x[24,2]   old_TS4   -4.4517462504637229e-02
    x[24,3]   OBJ       -0.00375
    x[24,3]   onehot_24  1
    x[24,3]   w_lb_24_3  -2.2258731252318614e-02
    x[24,3]   w_ub_24_3  -3.9535535354550462e-02
    x[24,3]   hard_lower  3
    x[24,3]   hard_upper  3
    x[24,3]   old_TS1   -6.6776193756955843e-02
    x[24,3]   old_TS2   -1.1860660606365139e-01
    x[24,3]   old_TS3   -1.1860660606365139e-01
    x[24,3]   old_TS4   -6.6776193756955843e-02
    x[24,4]   OBJ       -0.0075
    x[24,4]   onehot_24  1
    x[24,4]   w_lb_24_4  -2.2258731252318614e-02
    x[24,4]   w_ub_24_4  -3.9535535354550462e-02
    x[24,4]   hard_lower  4
    x[24,4]   hard_upper  4
    x[24,4]   old_TS1   -8.9034925009274457e-02
    x[24,4]   old_TS2   -1.5814214141820185e-01
    x[24,4]   old_TS3   -1.5814214141820185e-01
    x[24,4]   old_TS4   -8.9034925009274457e-02
    x[24,5]   OBJ       -0.00375
    x[24,5]   onehot_24  1
    x[24,5]   w_lb_24_5  -2.2258731252318614e-02
    x[24,5]   w_ub_24_5  -3.9535535354550462e-02
    x[24,5]   hard_lower  5
    x[24,5]   hard_upper  5
    x[24,5]   old_TS1   -1.1129365626159307e-01
    x[24,5]   old_TS2   -1.9767767677275230e-01
    x[24,5]   old_TS3   -1.9767767677275230e-01
    x[24,5]   old_TS4   -1.1129365626159307e-01
    x[24,6]   onehot_24  1
    x[24,6]   w_lb_24_6  -2.2258731252318614e-02
    x[24,6]   w_ub_24_6  -3.9535535354550462e-02
    x[24,6]   hard_lower  6
    x[24,6]   hard_upper  6
    x[24,6]   old_TS1   -1.3355238751391169e-01
    x[24,6]   old_TS2   -2.3721321212730279e-01
    x[24,6]   old_TS3   -2.3721321212730279e-01
    x[24,6]   old_TS4   -1.3355238751391169e-01
    x[24,7]   OBJ       0.00375
    x[24,7]   onehot_24  1
    x[24,7]   w_lb_24_7  -2.2258731252318614e-02
    x[24,7]   w_ub_24_7  -3.9535535354550462e-02
    x[24,7]   hard_lower  7
    x[24,7]   hard_upper  7
    x[24,7]   old_TS1   -1.5581111876623030e-01
    x[24,7]   old_TS2   -2.7674874748185324e-01
    x[24,7]   old_TS3   -2.7674874748185324e-01
    x[24,7]   old_TS4   -1.5581111876623030e-01
    x[24,8]   OBJ       0.0075
    x[24,8]   onehot_24  1
    x[24,8]   w_lb_24_8  -2.2258731252318614e-02
    x[24,8]   w_ub_24_8  -3.9535535354550462e-02
    x[24,8]   hard_lower  8
    x[24,8]   hard_upper  8
    x[24,8]   old_TS1   -1.7806985001854891e-01
    x[24,8]   old_TS2   -3.1628428283640370e-01
    x[24,8]   old_TS3   -3.1628428283640370e-01
    x[24,8]   old_TS4   -1.7806985001854891e-01
    x[25,0]   OBJ       1.8639064285714286e-02
    x[25,0]   onehot_25  1
    x[25,0]   w_lb_25_0  -2.2258731252318614e-02
    x[25,0]   w_ub_25_0  -3.9535535354550462e-02
    x[25,1]   OBJ       1.2426042857142858e-02
    x[25,1]   onehot_25  1
    x[25,1]   w_lb_25_1  -2.2258731252318614e-02
    x[25,1]   w_ub_25_1  -3.9535535354550462e-02
    x[25,1]   hard_lower  1
    x[25,1]   hard_upper  1
    x[25,1]   old_TS1   -2.2258731252318614e-02
    x[25,1]   old_TS2   -3.9535535354550462e-02
    x[25,1]   old_TS3   -3.9535535354550462e-02
    x[25,1]   old_TS4   -2.2258731252318614e-02
    x[25,2]   OBJ       0.00621302142857143
    x[25,2]   onehot_25  1
    x[25,2]   w_lb_25_2  -2.2258731252318614e-02
    x[25,2]   w_ub_25_2  -3.9535535354550462e-02
    x[25,2]   hard_lower  2
    x[25,2]   hard_upper  2
    x[25,2]   old_TS1   -4.4517462504637229e-02
    x[25,2]   old_TS2   -7.9071070709100924e-02
    x[25,2]   old_TS3   -7.9071070709100924e-02
    x[25,2]   old_TS4   -4.4517462504637229e-02
    x[25,3]   OBJ       2.4142438048713188e-18
    x[25,3]   onehot_25  1
    x[25,3]   w_lb_25_3  -2.2258731252318614e-02
    x[25,3]   w_ub_25_3  -3.9535535354550462e-02
    x[25,3]   hard_lower  3
    x[25,3]   hard_upper  3
    x[25,3]   old_TS1   -6.6776193756955843e-02
    x[25,3]   old_TS2   -1.1860660606365139e-01
    x[25,3]   old_TS3   -1.1860660606365139e-01
    x[25,3]   old_TS4   -6.6776193756955843e-02
    x[25,4]   OBJ       -6.2130214285714257e-03
    x[25,4]   onehot_25  1
    x[25,4]   w_lb_25_4  -2.2258731252318614e-02
    x[25,4]   w_ub_25_4  -3.9535535354550462e-02
    x[25,4]   hard_lower  4
    x[25,4]   hard_upper  4
    x[25,4]   old_TS1   -8.9034925009274457e-02
    x[25,4]   old_TS2   -1.5814214141820185e-01
    x[25,4]   old_TS3   -1.5814214141820185e-01
    x[25,4]   old_TS4   -8.9034925009274457e-02
    x[25,5]   OBJ       -1.2426042857142855e-02
    x[25,5]   onehot_25  1
    x[25,5]   w_lb_25_5  -2.2258731252318614e-02
    x[25,5]   w_ub_25_5  -3.9535535354550462e-02
    x[25,5]   hard_lower  5
    x[25,5]   hard_upper  5
    x[25,5]   old_TS1   -1.1129365626159307e-01
    x[25,5]   old_TS2   -1.9767767677275230e-01
    x[25,5]   old_TS3   -1.9767767677275230e-01
    x[25,5]   old_TS4   -1.1129365626159307e-01
    x[25,6]   OBJ       -1.8639064285714282e-02
    x[25,6]   onehot_25  1
    x[25,6]   w_lb_25_6  -2.2258731252318614e-02
    x[25,6]   w_ub_25_6  -3.9535535354550462e-02
    x[25,6]   hard_lower  6
    x[25,6]   hard_upper  6
    x[25,6]   old_TS1   -1.3355238751391169e-01
    x[25,6]   old_TS2   -2.3721321212730279e-01
    x[25,6]   old_TS3   -2.3721321212730279e-01
    x[25,6]   old_TS4   -1.3355238751391169e-01
    x[25,7]   OBJ       -2.4852085714285713e-02
    x[25,7]   onehot_25  1
    x[25,7]   w_lb_25_7  -2.2258731252318614e-02
    x[25,7]   w_ub_25_7  -3.9535535354550462e-02
    x[25,7]   hard_lower  7
    x[25,7]   hard_upper  7
    x[25,7]   old_TS1   -1.5581111876623030e-01
    x[25,7]   old_TS2   -2.7674874748185324e-01
    x[25,7]   old_TS3   -2.7674874748185324e-01
    x[25,7]   old_TS4   -1.5581111876623030e-01
    x[25,8]   OBJ       -1.8639064285714289e-02
    x[25,8]   onehot_25  1
    x[25,8]   w_lb_25_8  -2.2258731252318614e-02
    x[25,8]   w_ub_25_8  -3.9535535354550462e-02
    x[25,8]   hard_lower  8
    x[25,8]   hard_upper  8
    x[25,8]   old_TS1   -1.7806985001854891e-01
    x[25,8]   old_TS2   -3.1628428283640370e-01
    x[25,8]   old_TS3   -3.1628428283640370e-01
    x[25,8]   old_TS4   -1.7806985001854891e-01
    x[25,9]   OBJ       -1.2426042857142860e-02
    x[25,9]   onehot_25  1
    x[25,9]   w_lb_25_9  -2.2258731252318614e-02
    x[25,9]   w_ub_25_9  -3.9535535354550462e-02
    x[25,9]   hard_lower  9
    x[25,9]   hard_upper  9
    x[25,9]   old_TS1   -2.0032858127086753e-01
    x[25,9]   old_TS2   -3.5581981819095415e-01
    x[25,9]   old_TS3   -3.5581981819095415e-01
    x[25,9]   old_TS4   -2.0032858127086753e-01
    x[25,10]  OBJ       -6.2130214285714309e-03
    x[25,10]  onehot_25  1
    x[25,10]  w_lb_25_10  -2.2258731252318614e-02
    x[25,10]  w_ub_25_10  -3.9535535354550462e-02
    x[25,10]  hard_lower  10
    x[25,10]  hard_upper  10
    x[25,10]  old_TS1   -2.2258731252318614e-01
    x[25,10]  old_TS2   -3.9535535354550461e-01
    x[25,10]  old_TS3   -3.9535535354550461e-01
    x[25,10]  old_TS4   -2.2258731252318614e-01
    x[25,11]  OBJ       -2.4142438048713188e-18
    x[25,11]  onehot_25  1
    x[25,11]  w_lb_25_11  -2.2258731252318614e-02
    x[25,11]  w_ub_25_11  -3.9535535354550462e-02
    x[25,11]  hard_lower  11
    x[25,11]  hard_upper  11
    x[25,11]  old_TS1   -2.4484604377550476e-01
    x[25,11]  old_TS2   -4.3489088890005506e-01
    x[25,11]  old_TS3   -4.3489088890005506e-01
    x[25,11]  old_TS4   -2.4484604377550476e-01
    x[25,12]  OBJ       6.2130214285714249e-03
    x[25,12]  onehot_25  1
    x[25,12]  w_lb_25_12  -2.2258731252318614e-02
    x[25,12]  w_ub_25_12  -3.9535535354550462e-02
    x[25,12]  hard_lower  12
    x[25,12]  hard_upper  12
    x[25,12]  old_TS1   -2.6710477502782337e-01
    x[25,12]  old_TS2   -4.7442642425460557e-01
    x[25,12]  old_TS3   -4.7442642425460557e-01
    x[25,12]  old_TS4   -2.6710477502782337e-01
    x[25,13]  OBJ       1.2426042857142853e-02
    x[25,13]  onehot_25  1
    x[25,13]  w_lb_25_13  -2.2258731252318614e-02
    x[25,13]  w_ub_25_13  -3.9535535354550462e-02
    x[25,13]  hard_lower  13
    x[25,13]  hard_upper  13
    x[25,13]  old_TS1   -2.8936350628014196e-01
    x[25,13]  old_TS2   -0.513961959609156
    x[25,13]  old_TS3   -0.513961959609156
    x[25,13]  old_TS4   -2.8936350628014196e-01
    x[25,14]  OBJ       1.8639064285714279e-02
    x[25,14]  onehot_25  1
    x[25,14]  w_lb_25_14  -2.2258731252318614e-02
    x[25,14]  w_ub_25_14  -3.9535535354550462e-02
    x[25,14]  hard_lower  14
    x[25,14]  hard_upper  14
    x[25,14]  old_TS1   -3.1162223753246060e-01
    x[25,14]  old_TS2   -5.5349749496370648e-01
    x[25,14]  old_TS3   -5.5349749496370648e-01
    x[25,14]  old_TS4   -3.1162223753246060e-01
    x[25,15]  OBJ       2.4852085714285710e-02
    x[25,15]  onehot_25  1
    x[25,15]  w_lb_25_15  -2.2258731252318614e-02
    x[25,15]  w_ub_25_15  -3.9535535354550462e-02
    x[25,15]  hard_lower  15
    x[25,15]  hard_upper  15
    x[25,15]  old_TS1   -3.3388096878477924e-01
    x[25,15]  old_TS2   -5.9303303031825694e-01
    x[25,15]  old_TS3   -5.9303303031825694e-01
    x[25,15]  old_TS4   -3.3388096878477924e-01
    x[26,0]   OBJ       2.8402349999999996e-02
    x[26,0]   onehot_26  1
    x[26,0]   w_lb_26_0  -2.2258731252318614e-02
    x[26,0]   w_ub_26_0  -3.9535535354550462e-02
    x[26,1]   OBJ       2.1301762499999995e-02
    x[26,1]   onehot_26  1
    x[26,1]   w_lb_26_1  -2.2258731252318614e-02
    x[26,1]   w_ub_26_1  -3.9535535354550462e-02
    x[26,1]   hard_lower  1
    x[26,1]   hard_upper  1
    x[26,1]   old_TS1   -2.2258731252318614e-02
    x[26,1]   old_TS2   -3.9535535354550462e-02
    x[26,1]   old_TS3   -3.9535535354550462e-02
    x[26,1]   old_TS4   -2.2258731252318614e-02
    x[26,2]   OBJ       1.4201174999999998e-02
    x[26,2]   onehot_26  1
    x[26,2]   w_lb_26_2  -2.2258731252318614e-02
    x[26,2]   w_ub_26_2  -3.9535535354550462e-02
    x[26,2]   hard_lower  2
    x[26,2]   hard_upper  2
    x[26,2]   old_TS1   -4.4517462504637229e-02
    x[26,2]   old_TS2   -7.9071070709100924e-02
    x[26,2]   old_TS3   -7.9071070709100924e-02
    x[26,2]   old_TS4   -4.4517462504637229e-02
    x[26,3]   OBJ       7.1005874999999991e-03
    x[26,3]   onehot_26  1
    x[26,3]   w_lb_26_3  -2.2258731252318614e-02
    x[26,3]   w_ub_26_3  -3.9535535354550462e-02
    x[26,3]   hard_lower  3
    x[26,3]   hard_upper  3
    x[26,3]   old_TS1   -6.6776193756955843e-02
    x[26,3]   old_TS2   -1.1860660606365139e-01
    x[26,3]   old_TS3   -1.1860660606365139e-01
    x[26,3]   old_TS4   -6.6776193756955843e-02
    x[26,4]   onehot_26  1
    x[26,4]   w_lb_26_4  -2.2258731252318614e-02
    x[26,4]   w_ub_26_4  -3.9535535354550462e-02
    x[26,4]   hard_lower  4
    x[26,4]   hard_upper  4
    x[26,4]   old_TS1   -8.9034925009274457e-02
    x[26,4]   old_TS2   -1.5814214141820185e-01
    x[26,4]   old_TS3   -1.5814214141820185e-01
    x[26,4]   old_TS4   -8.9034925009274457e-02
    x[26,5]   OBJ       -7.1005874999999991e-03
    x[26,5]   onehot_26  1
    x[26,5]   w_lb_26_5  -2.2258731252318614e-02
    x[26,5]   w_ub_26_5  -3.9535535354550462e-02
    x[26,5]   hard_lower  5
    x[26,5]   hard_upper  5
    x[26,5]   old_TS1   -1.1129365626159307e-01
    x[26,5]   old_TS2   -1.9767767677275230e-01
    x[26,5]   old_TS3   -1.9767767677275230e-01
    x[26,5]   old_TS4   -1.1129365626159307e-01
    x[26,6]   OBJ       -1.4201174999999998e-02
    x[26,6]   onehot_26  1
    x[26,6]   w_lb_26_6  -2.2258731252318614e-02
    x[26,6]   w_ub_26_6  -3.9535535354550462e-02
    x[26,6]   hard_lower  6
    x[26,6]   hard_upper  6
    x[26,6]   old_TS1   -1.3355238751391169e-01
    x[26,6]   old_TS2   -2.3721321212730279e-01
    x[26,6]   old_TS3   -2.3721321212730279e-01
    x[26,6]   old_TS4   -1.3355238751391169e-01
    x[26,7]   OBJ       -2.1301762499999998e-02
    x[26,7]   onehot_26  1
    x[26,7]   w_lb_26_7  -2.2258731252318614e-02
    x[26,7]   w_ub_26_7  -3.9535535354550462e-02
    x[26,7]   hard_lower  7
    x[26,7]   hard_upper  7
    x[26,7]   old_TS1   -1.5581111876623030e-01
    x[26,7]   old_TS2   -2.7674874748185324e-01
    x[26,7]   old_TS3   -2.7674874748185324e-01
    x[26,7]   old_TS4   -1.5581111876623030e-01
    x[26,8]   OBJ       -2.8402349999999996e-02
    x[26,8]   onehot_26  1
    x[26,8]   w_lb_26_8  -2.2258731252318614e-02
    x[26,8]   w_ub_26_8  -3.9535535354550462e-02
    x[26,8]   hard_lower  8
    x[26,8]   hard_upper  8
    x[26,8]   old_TS1   -1.7806985001854891e-01
    x[26,8]   old_TS2   -3.1628428283640370e-01
    x[26,8]   old_TS3   -3.1628428283640370e-01
    x[26,8]   old_TS4   -1.7806985001854891e-01
    x[26,9]   OBJ       -2.1301762499999998e-02
    x[26,9]   onehot_26  1
    x[26,9]   w_lb_26_9  -2.2258731252318614e-02
    x[26,9]   w_ub_26_9  -3.9535535354550462e-02
    x[26,9]   hard_lower  9
    x[26,9]   hard_upper  9
    x[26,9]   old_TS1   -2.0032858127086753e-01
    x[26,9]   old_TS2   -3.5581981819095415e-01
    x[26,9]   old_TS3   -3.5581981819095415e-01
    x[26,9]   old_TS4   -2.0032858127086753e-01
    x[26,10]  OBJ       -1.4201174999999998e-02
    x[26,10]  onehot_26  1
    x[26,10]  w_lb_26_10  -2.2258731252318614e-02
    x[26,10]  w_ub_26_10  -3.9535535354550462e-02
    x[26,10]  hard_lower  10
    x[26,10]  hard_upper  10
    x[26,10]  old_TS1   -2.2258731252318614e-01
    x[26,10]  old_TS2   -3.9535535354550461e-01
    x[26,10]  old_TS3   -3.9535535354550461e-01
    x[26,10]  old_TS4   -2.2258731252318614e-01
    x[26,11]  OBJ       -7.1005874999999991e-03
    x[26,11]  onehot_26  1
    x[26,11]  w_lb_26_11  -2.2258731252318614e-02
    x[26,11]  w_ub_26_11  -3.9535535354550462e-02
    x[26,11]  hard_lower  11
    x[26,11]  hard_upper  11
    x[26,11]  old_TS1   -2.4484604377550476e-01
    x[26,11]  old_TS2   -4.3489088890005506e-01
    x[26,11]  old_TS3   -4.3489088890005506e-01
    x[26,11]  old_TS4   -2.4484604377550476e-01
    x[26,12]  onehot_26  1
    x[26,12]  w_lb_26_12  -2.2258731252318614e-02
    x[26,12]  w_ub_26_12  -3.9535535354550462e-02
    x[26,12]  hard_lower  12
    x[26,12]  hard_upper  12
    x[26,12]  old_TS1   -2.6710477502782337e-01
    x[26,12]  old_TS2   -4.7442642425460557e-01
    x[26,12]  old_TS3   -4.7442642425460557e-01
    x[26,12]  old_TS4   -2.6710477502782337e-01
    x[26,13]  OBJ       7.1005874999999991e-03
    x[26,13]  onehot_26  1
    x[26,13]  w_lb_26_13  -2.2258731252318614e-02
    x[26,13]  w_ub_26_13  -3.9535535354550462e-02
    x[26,13]  hard_lower  13
    x[26,13]  hard_upper  13
    x[26,13]  old_TS1   -2.8936350628014196e-01
    x[26,13]  old_TS2   -0.513961959609156
    x[26,13]  old_TS3   -0.513961959609156
    x[26,13]  old_TS4   -2.8936350628014196e-01
    x[26,14]  OBJ       1.4201174999999998e-02
    x[26,14]  onehot_26  1
    x[26,14]  w_lb_26_14  -2.2258731252318614e-02
    x[26,14]  w_ub_26_14  -3.9535535354550462e-02
    x[26,14]  hard_lower  14
    x[26,14]  hard_upper  14
    x[26,14]  old_TS1   -3.1162223753246060e-01
    x[26,14]  old_TS2   -5.5349749496370648e-01
    x[26,14]  old_TS3   -5.5349749496370648e-01
    x[26,14]  old_TS4   -3.1162223753246060e-01
    x[26,15]  OBJ       2.1301762499999995e-02
    x[26,15]  onehot_26  1
    x[26,15]  w_lb_26_15  -2.2258731252318614e-02
    x[26,15]  w_ub_26_15  -3.9535535354550462e-02
    x[26,15]  hard_lower  15
    x[26,15]  hard_upper  15
    x[26,15]  old_TS1   -3.3388096878477924e-01
    x[26,15]  old_TS2   -5.9303303031825694e-01
    x[26,15]  old_TS3   -5.9303303031825694e-01
    x[26,15]  old_TS4   -3.3388096878477924e-01
    x[27,0]   OBJ       3.1952666666666664e-02
    x[27,0]   onehot_27  1
    x[27,0]   w_lb_27_0  -2.2258731252318614e-02
    x[27,0]   w_ub_27_0  -3.9535535354550462e-02
    x[27,1]   OBJ       0.0239645
    x[27,1]   onehot_27  1
    x[27,1]   w_lb_27_1  -2.2258731252318614e-02
    x[27,1]   w_ub_27_1  -3.9535535354550462e-02
    x[27,1]   hard_lower  1
    x[27,1]   hard_upper  1
    x[27,1]   old_TS1   -2.2258731252318614e-02
    x[27,1]   old_TS2   -3.9535535354550462e-02
    x[27,1]   old_TS3   -3.9535535354550462e-02
    x[27,1]   old_TS4   -2.2258731252318614e-02
    x[27,2]   OBJ       1.5976333333333335e-02
    x[27,2]   onehot_27  1
    x[27,2]   w_lb_27_2  -2.2258731252318614e-02
    x[27,2]   w_ub_27_2  -3.9535535354550462e-02
    x[27,2]   hard_lower  2
    x[27,2]   hard_upper  2
    x[27,2]   old_TS1   -4.4517462504637229e-02
    x[27,2]   old_TS2   -7.9071070709100924e-02
    x[27,2]   old_TS3   -7.9071070709100924e-02
    x[27,2]   old_TS4   -4.4517462504637229e-02
    x[27,3]   OBJ       0.00798816666666667
    x[27,3]   onehot_27  1
    x[27,3]   w_lb_27_3  -2.2258731252318614e-02
    x[27,3]   w_ub_27_3  -3.9535535354550462e-02
    x[27,3]   hard_lower  3
    x[27,3]   hard_upper  3
    x[27,3]   old_TS1   -6.6776193756955843e-02
    x[27,3]   old_TS2   -1.1860660606365139e-01
    x[27,3]   old_TS3   -1.1860660606365139e-01
    x[27,3]   old_TS4   -6.6776193756955843e-02
    x[27,4]   OBJ       3.9908909510444345e-18
    x[27,4]   onehot_27  1
    x[27,4]   w_lb_27_4  -2.2258731252318614e-02
    x[27,4]   w_ub_27_4  -3.9535535354550462e-02
    x[27,4]   hard_lower  4
    x[27,4]   hard_upper  4
    x[27,4]   old_TS1   -8.9034925009274457e-02
    x[27,4]   old_TS2   -1.5814214141820185e-01
    x[27,4]   old_TS3   -1.5814214141820185e-01
    x[27,4]   old_TS4   -8.9034925009274457e-02
    x[27,5]   OBJ       -7.9881666666666625e-03
    x[27,5]   onehot_27  1
    x[27,5]   w_lb_27_5  -2.2258731252318614e-02
    x[27,5]   w_ub_27_5  -3.9535535354550462e-02
    x[27,5]   hard_lower  5
    x[27,5]   hard_upper  5
    x[27,5]   old_TS1   -1.1129365626159307e-01
    x[27,5]   old_TS2   -1.9767767677275230e-01
    x[27,5]   old_TS3   -1.9767767677275230e-01
    x[27,5]   old_TS4   -1.1129365626159307e-01
    x[27,6]   OBJ       -1.5976333333333329e-02
    x[27,6]   onehot_27  1
    x[27,6]   w_lb_27_6  -2.2258731252318614e-02
    x[27,6]   w_ub_27_6  -3.9535535354550462e-02
    x[27,6]   hard_lower  6
    x[27,6]   hard_upper  6
    x[27,6]   old_TS1   -1.3355238751391169e-01
    x[27,6]   old_TS2   -2.3721321212730279e-01
    x[27,6]   old_TS3   -2.3721321212730279e-01
    x[27,6]   old_TS4   -1.3355238751391169e-01
    x[27,7]   OBJ       -2.3964499999999996e-02
    x[27,7]   onehot_27  1
    x[27,7]   w_lb_27_7  -2.2258731252318614e-02
    x[27,7]   w_ub_27_7  -3.9535535354550462e-02
    x[27,7]   hard_lower  7
    x[27,7]   hard_upper  7
    x[27,7]   old_TS1   -1.5581111876623030e-01
    x[27,7]   old_TS2   -2.7674874748185324e-01
    x[27,7]   old_TS3   -2.7674874748185324e-01
    x[27,7]   old_TS4   -1.5581111876623030e-01
    x[27,8]   OBJ       -3.1952666666666664e-02
    x[27,8]   onehot_27  1
    x[27,8]   w_lb_27_8  -2.2258731252318614e-02
    x[27,8]   w_ub_27_8  -3.9535535354550462e-02
    x[27,8]   hard_lower  8
    x[27,8]   hard_upper  8
    x[27,8]   old_TS1   -1.7806985001854891e-01
    x[27,8]   old_TS2   -3.1628428283640370e-01
    x[27,8]   old_TS3   -3.1628428283640370e-01
    x[27,8]   old_TS4   -1.7806985001854891e-01
    x[27,9]   OBJ       -3.9940833333333328e-02
    x[27,9]   onehot_27  1
    x[27,9]   w_lb_27_9  -2.2258731252318614e-02
    x[27,9]   w_ub_27_9  -3.9535535354550462e-02
    x[27,9]   hard_lower  9
    x[27,9]   hard_upper  9
    x[27,9]   old_TS1   -2.0032858127086753e-01
    x[27,9]   old_TS2   -3.5581981819095415e-01
    x[27,9]   old_TS3   -3.5581981819095415e-01
    x[27,9]   old_TS4   -2.0032858127086753e-01
    x[27,10]  OBJ       -3.1952666666666671e-02
    x[27,10]  onehot_27  1
    x[27,10]  w_lb_27_10  -2.2258731252318614e-02
    x[27,10]  w_ub_27_10  -3.9535535354550462e-02
    x[27,10]  hard_lower  10
    x[27,10]  hard_upper  10
    x[27,10]  old_TS1   -2.2258731252318614e-01
    x[27,10]  old_TS2   -3.9535535354550461e-01
    x[27,10]  old_TS3   -3.9535535354550461e-01
    x[27,10]  old_TS4   -2.2258731252318614e-01
    x[27,11]  OBJ       -2.3964500000000003e-02
    x[27,11]  onehot_27  1
    x[27,11]  w_lb_27_11  -2.2258731252318614e-02
    x[27,11]  w_ub_27_11  -3.9535535354550462e-02
    x[27,11]  hard_lower  11
    x[27,11]  hard_upper  11
    x[27,11]  old_TS1   -2.4484604377550476e-01
    x[27,11]  old_TS2   -4.3489088890005506e-01
    x[27,11]  old_TS3   -4.3489088890005506e-01
    x[27,11]  old_TS4   -2.4484604377550476e-01
    x[27,12]  OBJ       -1.5976333333333339e-02
    x[27,12]  onehot_27  1
    x[27,12]  w_lb_27_12  -2.2258731252318614e-02
    x[27,12]  w_ub_27_12  -3.9535535354550462e-02
    x[27,12]  hard_lower  12
    x[27,12]  hard_upper  12
    x[27,12]  old_TS1   -2.6710477502782337e-01
    x[27,12]  old_TS2   -4.7442642425460557e-01
    x[27,12]  old_TS3   -4.7442642425460557e-01
    x[27,12]  old_TS4   -2.6710477502782337e-01
    x[27,13]  OBJ       -7.9881666666666712e-03
    x[27,13]  onehot_27  1
    x[27,13]  w_lb_27_13  -2.2258731252318614e-02
    x[27,13]  w_ub_27_13  -3.9535535354550462e-02
    x[27,13]  hard_lower  13
    x[27,13]  hard_upper  13
    x[27,13]  old_TS1   -2.8936350628014196e-01
    x[27,13]  old_TS2   -0.513961959609156
    x[27,13]  old_TS3   -0.513961959609156
    x[27,13]  old_TS4   -2.8936350628014196e-01
    x[27,14]  OBJ       -3.9908909510444345e-18
    x[27,14]  onehot_27  1
    x[27,14]  w_lb_27_14  -2.2258731252318614e-02
    x[27,14]  w_ub_27_14  -3.9535535354550462e-02
    x[27,14]  hard_lower  14
    x[27,14]  hard_upper  14
    x[27,14]  old_TS1   -3.1162223753246060e-01
    x[27,14]  old_TS2   -5.5349749496370648e-01
    x[27,14]  old_TS3   -5.5349749496370648e-01
    x[27,14]  old_TS4   -3.1162223753246060e-01
    x[27,15]  OBJ       0.00798816666666666
    x[27,15]  onehot_27  1
    x[27,15]  w_lb_27_15  -2.2258731252318614e-02
    x[27,15]  w_ub_27_15  -3.9535535354550462e-02
    x[27,15]  hard_lower  15
    x[27,15]  hard_upper  15
    x[27,15]  old_TS1   -3.3388096878477924e-01
    x[27,15]  old_TS2   -5.9303303031825694e-01
    x[27,15]  old_TS3   -5.9303303031825694e-01
    x[27,15]  old_TS4   -3.3388096878477924e-01
    x[27,16]  OBJ       1.5976333333333325e-02
    x[27,16]  onehot_27  1
    x[27,16]  w_lb_27_16  -2.2258731252318614e-02
    x[27,16]  w_ub_27_16  -3.9535535354550462e-02
    x[27,16]  hard_lower  16
    x[27,16]  hard_upper  16
    x[27,16]  old_TS1   -3.5613970003709783e-01
    x[27,16]  old_TS2   -6.3256856567280739e-01
    x[27,16]  old_TS3   -6.3256856567280739e-01
    x[27,16]  old_TS4   -3.5613970003709783e-01
    x[27,17]  OBJ       2.3964499999999993e-02
    x[27,17]  onehot_27  1
    x[27,17]  w_lb_27_17  -2.2258731252318614e-02
    x[27,17]  w_ub_27_17  -3.9535535354550462e-02
    x[27,17]  hard_lower  17
    x[27,17]  hard_upper  17
    x[27,17]  old_TS1   -3.7839843128941641e-01
    x[27,17]  old_TS2   -6.7210410102735785e-01
    x[27,17]  old_TS3   -6.7210410102735785e-01
    x[27,17]  old_TS4   -3.7839843128941641e-01
    x[27,18]  OBJ       3.1952666666666657e-02
    x[27,18]  onehot_27  1
    x[27,18]  w_lb_27_18  -2.2258731252318614e-02
    x[27,18]  w_ub_27_18  -3.9535535354550462e-02
    x[27,18]  hard_lower  18
    x[27,18]  hard_upper  18
    x[27,18]  old_TS1   -4.0065716254173506e-01
    x[27,18]  old_TS2   -7.1163963638190830e-01
    x[27,18]  old_TS3   -7.1163963638190830e-01
    x[27,18]  old_TS4   -4.0065716254173506e-01
    x[27,19]  OBJ       3.9940833333333321e-02
    x[27,19]  onehot_27  1
    x[27,19]  w_lb_27_19  -2.2258731252318614e-02
    x[27,19]  w_ub_27_19  -3.9535535354550462e-02
    x[27,19]  hard_lower  19
    x[27,19]  hard_upper  19
    x[27,19]  old_TS1   -4.2291589379405370e-01
    x[27,19]  old_TS2   -7.5117517173645876e-01
    x[27,19]  old_TS3   -7.5117517173645876e-01
    x[27,19]  old_TS4   -4.2291589379405370e-01
    x[28,0]   OBJ       1.8639064285714286e-02
    x[28,0]   onehot_28  1
    x[28,0]   w_lb_28_0  -2.2258731252318614e-02
    x[28,0]   w_ub_28_0  -3.9535535354550462e-02
    x[28,1]   OBJ       1.2426042857142858e-02
    x[28,1]   onehot_28  1
    x[28,1]   w_lb_28_1  -2.2258731252318614e-02
    x[28,1]   w_ub_28_1  -3.9535535354550462e-02
    x[28,1]   hard_lower  1
    x[28,1]   hard_upper  1
    x[28,1]   old_TS1   -2.2258731252318614e-02
    x[28,1]   old_TS2   -3.9535535354550462e-02
    x[28,1]   old_TS3   -3.9535535354550462e-02
    x[28,1]   old_TS4   -2.2258731252318614e-02
    x[28,2]   OBJ       0.00621302142857143
    x[28,2]   onehot_28  1
    x[28,2]   w_lb_28_2  -2.2258731252318614e-02
    x[28,2]   w_ub_28_2  -3.9535535354550462e-02
    x[28,2]   hard_lower  2
    x[28,2]   hard_upper  2
    x[28,2]   old_TS1   -4.4517462504637229e-02
    x[28,2]   old_TS2   -7.9071070709100924e-02
    x[28,2]   old_TS3   -7.9071070709100924e-02
    x[28,2]   old_TS4   -4.4517462504637229e-02
    x[28,3]   OBJ       2.4142438048713188e-18
    x[28,3]   onehot_28  1
    x[28,3]   w_lb_28_3  -2.2258731252318614e-02
    x[28,3]   w_ub_28_3  -3.9535535354550462e-02
    x[28,3]   hard_lower  3
    x[28,3]   hard_upper  3
    x[28,3]   old_TS1   -6.6776193756955843e-02
    x[28,3]   old_TS2   -1.1860660606365139e-01
    x[28,3]   old_TS3   -1.1860660606365139e-01
    x[28,3]   old_TS4   -6.6776193756955843e-02
    x[28,4]   OBJ       -6.2130214285714257e-03
    x[28,4]   onehot_28  1
    x[28,4]   w_lb_28_4  -2.2258731252318614e-02
    x[28,4]   w_ub_28_4  -3.9535535354550462e-02
    x[28,4]   hard_lower  4
    x[28,4]   hard_upper  4
    x[28,4]   old_TS1   -8.9034925009274457e-02
    x[28,4]   old_TS2   -1.5814214141820185e-01
    x[28,4]   old_TS3   -1.5814214141820185e-01
    x[28,4]   old_TS4   -8.9034925009274457e-02
    x[28,5]   OBJ       -1.2426042857142855e-02
    x[28,5]   onehot_28  1
    x[28,5]   w_lb_28_5  -2.2258731252318614e-02
    x[28,5]   w_ub_28_5  -3.9535535354550462e-02
    x[28,5]   hard_lower  5
    x[28,5]   hard_upper  5
    x[28,5]   old_TS1   -1.1129365626159307e-01
    x[28,5]   old_TS2   -1.9767767677275230e-01
    x[28,5]   old_TS3   -1.9767767677275230e-01
    x[28,5]   old_TS4   -1.1129365626159307e-01
    x[28,6]   OBJ       -1.8639064285714282e-02
    x[28,6]   onehot_28  1
    x[28,6]   w_lb_28_6  -2.2258731252318614e-02
    x[28,6]   w_ub_28_6  -3.9535535354550462e-02
    x[28,6]   hard_lower  6
    x[28,6]   hard_upper  6
    x[28,6]   old_TS1   -1.3355238751391169e-01
    x[28,6]   old_TS2   -2.3721321212730279e-01
    x[28,6]   old_TS3   -2.3721321212730279e-01
    x[28,6]   old_TS4   -1.3355238751391169e-01
    x[28,7]   OBJ       -2.4852085714285713e-02
    x[28,7]   onehot_28  1
    x[28,7]   w_lb_28_7  -2.2258731252318614e-02
    x[28,7]   w_ub_28_7  -3.9535535354550462e-02
    x[28,7]   hard_lower  7
    x[28,7]   hard_upper  7
    x[28,7]   old_TS1   -1.5581111876623030e-01
    x[28,7]   old_TS2   -2.7674874748185324e-01
    x[28,7]   old_TS3   -2.7674874748185324e-01
    x[28,7]   old_TS4   -1.5581111876623030e-01
    x[28,8]   OBJ       -1.8639064285714289e-02
    x[28,8]   onehot_28  1
    x[28,8]   w_lb_28_8  -2.2258731252318614e-02
    x[28,8]   w_ub_28_8  -3.9535535354550462e-02
    x[28,8]   hard_lower  8
    x[28,8]   hard_upper  8
    x[28,8]   old_TS1   -1.7806985001854891e-01
    x[28,8]   old_TS2   -3.1628428283640370e-01
    x[28,8]   old_TS3   -3.1628428283640370e-01
    x[28,8]   old_TS4   -1.7806985001854891e-01
    x[28,9]   OBJ       -1.2426042857142860e-02
    x[28,9]   onehot_28  1
    x[28,9]   w_lb_28_9  -2.2258731252318614e-02
    x[28,9]   w_ub_28_9  -3.9535535354550462e-02
    x[28,9]   hard_lower  9
    x[28,9]   hard_upper  9
    x[28,9]   old_TS1   -2.0032858127086753e-01
    x[28,9]   old_TS2   -3.5581981819095415e-01
    x[28,9]   old_TS3   -3.5581981819095415e-01
    x[28,9]   old_TS4   -2.0032858127086753e-01
    x[28,10]  OBJ       -6.2130214285714309e-03
    x[28,10]  onehot_28  1
    x[28,10]  w_lb_28_10  -2.2258731252318614e-02
    x[28,10]  w_ub_28_10  -3.9535535354550462e-02
    x[28,10]  hard_lower  10
    x[28,10]  hard_upper  10
    x[28,10]  old_TS1   -2.2258731252318614e-01
    x[28,10]  old_TS2   -3.9535535354550461e-01
    x[28,10]  old_TS3   -3.9535535354550461e-01
    x[28,10]  old_TS4   -2.2258731252318614e-01
    x[28,11]  OBJ       -2.4142438048713188e-18
    x[28,11]  onehot_28  1
    x[28,11]  w_lb_28_11  -2.2258731252318614e-02
    x[28,11]  w_ub_28_11  -3.9535535354550462e-02
    x[28,11]  hard_lower  11
    x[28,11]  hard_upper  11
    x[28,11]  old_TS1   -2.4484604377550476e-01
    x[28,11]  old_TS2   -4.3489088890005506e-01
    x[28,11]  old_TS3   -4.3489088890005506e-01
    x[28,11]  old_TS4   -2.4484604377550476e-01
    x[28,12]  OBJ       6.2130214285714249e-03
    x[28,12]  onehot_28  1
    x[28,12]  w_lb_28_12  -2.2258731252318614e-02
    x[28,12]  w_ub_28_12  -3.9535535354550462e-02
    x[28,12]  hard_lower  12
    x[28,12]  hard_upper  12
    x[28,12]  old_TS1   -2.6710477502782337e-01
    x[28,12]  old_TS2   -4.7442642425460557e-01
    x[28,12]  old_TS3   -4.7442642425460557e-01
    x[28,12]  old_TS4   -2.6710477502782337e-01
    x[28,13]  OBJ       1.2426042857142853e-02
    x[28,13]  onehot_28  1
    x[28,13]  w_lb_28_13  -2.2258731252318614e-02
    x[28,13]  w_ub_28_13  -3.9535535354550462e-02
    x[28,13]  hard_lower  13
    x[28,13]  hard_upper  13
    x[28,13]  old_TS1   -2.8936350628014196e-01
    x[28,13]  old_TS2   -0.513961959609156
    x[28,13]  old_TS3   -0.513961959609156
    x[28,13]  old_TS4   -2.8936350628014196e-01
    x[28,14]  OBJ       1.8639064285714279e-02
    x[28,14]  onehot_28  1
    x[28,14]  w_lb_28_14  -2.2258731252318614e-02
    x[28,14]  w_ub_28_14  -3.9535535354550462e-02
    x[28,14]  hard_lower  14
    x[28,14]  hard_upper  14
    x[28,14]  old_TS1   -3.1162223753246060e-01
    x[28,14]  old_TS2   -5.5349749496370648e-01
    x[28,14]  old_TS3   -5.5349749496370648e-01
    x[28,14]  old_TS4   -3.1162223753246060e-01
    x[28,15]  OBJ       2.4852085714285710e-02
    x[28,15]  onehot_28  1
    x[28,15]  w_lb_28_15  -2.2258731252318614e-02
    x[28,15]  w_ub_28_15  -3.9535535354550462e-02
    x[28,15]  hard_lower  15
    x[28,15]  hard_upper  15
    x[28,15]  old_TS1   -3.3388096878477924e-01
    x[28,15]  old_TS2   -5.9303303031825694e-01
    x[28,15]  old_TS3   -5.9303303031825694e-01
    x[28,15]  old_TS4   -3.3388096878477924e-01
    x[29,0]   OBJ       1.8639064285714286e-02
    x[29,0]   onehot_29  1
    x[29,0]   w_lb_29_0  -2.2258731252318614e-02
    x[29,0]   w_ub_29_0  -3.9535535354550462e-02
    x[29,1]   OBJ       1.2426042857142858e-02
    x[29,1]   onehot_29  1
    x[29,1]   w_lb_29_1  -2.2258731252318614e-02
    x[29,1]   w_ub_29_1  -3.9535535354550462e-02
    x[29,1]   hard_lower  1
    x[29,1]   hard_upper  1
    x[29,1]   old_TS1   -2.2258731252318614e-02
    x[29,1]   old_TS2   -3.9535535354550462e-02
    x[29,1]   old_TS3   -3.9535535354550462e-02
    x[29,1]   old_TS4   -2.2258731252318614e-02
    x[29,2]   OBJ       0.00621302142857143
    x[29,2]   onehot_29  1
    x[29,2]   w_lb_29_2  -2.2258731252318614e-02
    x[29,2]   w_ub_29_2  -3.9535535354550462e-02
    x[29,2]   hard_lower  2
    x[29,2]   hard_upper  2
    x[29,2]   old_TS1   -4.4517462504637229e-02
    x[29,2]   old_TS2   -7.9071070709100924e-02
    x[29,2]   old_TS3   -7.9071070709100924e-02
    x[29,2]   old_TS4   -4.4517462504637229e-02
    x[29,3]   OBJ       2.4142438048713188e-18
    x[29,3]   onehot_29  1
    x[29,3]   w_lb_29_3  -2.2258731252318614e-02
    x[29,3]   w_ub_29_3  -3.9535535354550462e-02
    x[29,3]   hard_lower  3
    x[29,3]   hard_upper  3
    x[29,3]   old_TS1   -6.6776193756955843e-02
    x[29,3]   old_TS2   -1.1860660606365139e-01
    x[29,3]   old_TS3   -1.1860660606365139e-01
    x[29,3]   old_TS4   -6.6776193756955843e-02
    x[29,4]   OBJ       -6.2130214285714257e-03
    x[29,4]   onehot_29  1
    x[29,4]   w_lb_29_4  -2.2258731252318614e-02
    x[29,4]   w_ub_29_4  -3.9535535354550462e-02
    x[29,4]   hard_lower  4
    x[29,4]   hard_upper  4
    x[29,4]   old_TS1   -8.9034925009274457e-02
    x[29,4]   old_TS2   -1.5814214141820185e-01
    x[29,4]   old_TS3   -1.5814214141820185e-01
    x[29,4]   old_TS4   -8.9034925009274457e-02
    x[29,5]   OBJ       -1.2426042857142855e-02
    x[29,5]   onehot_29  1
    x[29,5]   w_lb_29_5  -2.2258731252318614e-02
    x[29,5]   w_ub_29_5  -3.9535535354550462e-02
    x[29,5]   hard_lower  5
    x[29,5]   hard_upper  5
    x[29,5]   old_TS1   -1.1129365626159307e-01
    x[29,5]   old_TS2   -1.9767767677275230e-01
    x[29,5]   old_TS3   -1.9767767677275230e-01
    x[29,5]   old_TS4   -1.1129365626159307e-01
    x[29,6]   OBJ       -1.8639064285714282e-02
    x[29,6]   onehot_29  1
    x[29,6]   w_lb_29_6  -2.2258731252318614e-02
    x[29,6]   w_ub_29_6  -3.9535535354550462e-02
    x[29,6]   hard_lower  6
    x[29,6]   hard_upper  6
    x[29,6]   old_TS1   -1.3355238751391169e-01
    x[29,6]   old_TS2   -2.3721321212730279e-01
    x[29,6]   old_TS3   -2.3721321212730279e-01
    x[29,6]   old_TS4   -1.3355238751391169e-01
    x[29,7]   OBJ       -2.4852085714285713e-02
    x[29,7]   onehot_29  1
    x[29,7]   w_lb_29_7  -2.2258731252318614e-02
    x[29,7]   w_ub_29_7  -3.9535535354550462e-02
    x[29,7]   hard_lower  7
    x[29,7]   hard_upper  7
    x[29,7]   old_TS1   -1.5581111876623030e-01
    x[29,7]   old_TS2   -2.7674874748185324e-01
    x[29,7]   old_TS3   -2.7674874748185324e-01
    x[29,7]   old_TS4   -1.5581111876623030e-01
    x[29,8]   OBJ       -1.8639064285714289e-02
    x[29,8]   onehot_29  1
    x[29,8]   w_lb_29_8  -2.2258731252318614e-02
    x[29,8]   w_ub_29_8  -3.9535535354550462e-02
    x[29,8]   hard_lower  8
    x[29,8]   hard_upper  8
    x[29,8]   old_TS1   -1.7806985001854891e-01
    x[29,8]   old_TS2   -3.1628428283640370e-01
    x[29,8]   old_TS3   -3.1628428283640370e-01
    x[29,8]   old_TS4   -1.7806985001854891e-01
    x[29,9]   OBJ       -1.2426042857142860e-02
    x[29,9]   onehot_29  1
    x[29,9]   w_lb_29_9  -2.2258731252318614e-02
    x[29,9]   w_ub_29_9  -3.9535535354550462e-02
    x[29,9]   hard_lower  9
    x[29,9]   hard_upper  9
    x[29,9]   old_TS1   -2.0032858127086753e-01
    x[29,9]   old_TS2   -3.5581981819095415e-01
    x[29,9]   old_TS3   -3.5581981819095415e-01
    x[29,9]   old_TS4   -2.0032858127086753e-01
    x[29,10]  OBJ       -6.2130214285714309e-03
    x[29,10]  onehot_29  1
    x[29,10]  w_lb_29_10  -2.2258731252318614e-02
    x[29,10]  w_ub_29_10  -3.9535535354550462e-02
    x[29,10]  hard_lower  10
    x[29,10]  hard_upper  10
    x[29,10]  old_TS1   -2.2258731252318614e-01
    x[29,10]  old_TS2   -3.9535535354550461e-01
    x[29,10]  old_TS3   -3.9535535354550461e-01
    x[29,10]  old_TS4   -2.2258731252318614e-01
    x[29,11]  OBJ       -2.4142438048713188e-18
    x[29,11]  onehot_29  1
    x[29,11]  w_lb_29_11  -2.2258731252318614e-02
    x[29,11]  w_ub_29_11  -3.9535535354550462e-02
    x[29,11]  hard_lower  11
    x[29,11]  hard_upper  11
    x[29,11]  old_TS1   -2.4484604377550476e-01
    x[29,11]  old_TS2   -4.3489088890005506e-01
    x[29,11]  old_TS3   -4.3489088890005506e-01
    x[29,11]  old_TS4   -2.4484604377550476e-01
    x[29,12]  OBJ       6.2130214285714249e-03
    x[29,12]  onehot_29  1
    x[29,12]  w_lb_29_12  -2.2258731252318614e-02
    x[29,12]  w_ub_29_12  -3.9535535354550462e-02
    x[29,12]  hard_lower  12
    x[29,12]  hard_upper  12
    x[29,12]  old_TS1   -2.6710477502782337e-01
    x[29,12]  old_TS2   -4.7442642425460557e-01
    x[29,12]  old_TS3   -4.7442642425460557e-01
    x[29,12]  old_TS4   -2.6710477502782337e-01
    x[29,13]  OBJ       1.2426042857142853e-02
    x[29,13]  onehot_29  1
    x[29,13]  w_lb_29_13  -2.2258731252318614e-02
    x[29,13]  w_ub_29_13  -3.9535535354550462e-02
    x[29,13]  hard_lower  13
    x[29,13]  hard_upper  13
    x[29,13]  old_TS1   -2.8936350628014196e-01
    x[29,13]  old_TS2   -0.513961959609156
    x[29,13]  old_TS3   -0.513961959609156
    x[29,13]  old_TS4   -2.8936350628014196e-01
    x[29,14]  OBJ       1.8639064285714279e-02
    x[29,14]  onehot_29  1
    x[29,14]  w_lb_29_14  -2.2258731252318614e-02
    x[29,14]  w_ub_29_14  -3.9535535354550462e-02
    x[29,14]  hard_lower  14
    x[29,14]  hard_upper  14
    x[29,14]  old_TS1   -3.1162223753246060e-01
    x[29,14]  old_TS2   -5.5349749496370648e-01
    x[29,14]  old_TS3   -5.5349749496370648e-01
    x[29,14]  old_TS4   -3.1162223753246060e-01
    x[29,15]  OBJ       2.4852085714285710e-02
    x[29,15]  onehot_29  1
    x[29,15]  w_lb_29_15  -2.2258731252318614e-02
    x[29,15]  w_ub_29_15  -3.9535535354550462e-02
    x[29,15]  hard_lower  15
    x[29,15]  hard_upper  15
    x[29,15]  old_TS1   -3.3388096878477924e-01
    x[29,15]  old_TS2   -5.9303303031825694e-01
    x[29,15]  old_TS3   -5.9303303031825694e-01
    x[29,15]  old_TS4   -3.3388096878477924e-01
    x[30,0]   OBJ       5.3698199999999988e-02
    x[30,0]   onehot_30  1
    x[30,0]   w_lb_30_0  -2.2258731252318614e-02
    x[30,0]   w_ub_30_0  -3.9535535354550462e-02
    x[30,1]   OBJ       0.0439348909090909
    x[30,1]   onehot_30  1
    x[30,1]   w_lb_30_1  -2.2258731252318614e-02
    x[30,1]   w_ub_30_1  -3.9535535354550462e-02
    x[30,1]   hard_lower  1
    x[30,1]   hard_upper  1
    x[30,1]   old_TS1   -2.2258731252318614e-02
    x[30,1]   old_TS2   -3.9535535354550462e-02
    x[30,1]   old_TS3   -3.9535535354550462e-02
    x[30,1]   old_TS4   -2.2258731252318614e-02
    x[30,2]   OBJ       3.4171581818181807e-02
    x[30,2]   onehot_30  1
    x[30,2]   w_lb_30_2  -2.2258731252318614e-02
    x[30,2]   w_ub_30_2  -3.9535535354550462e-02
    x[30,2]   hard_lower  2
    x[30,2]   hard_upper  2
    x[30,2]   old_TS1   -4.4517462504637229e-02
    x[30,2]   old_TS2   -7.9071070709100924e-02
    x[30,2]   old_TS3   -7.9071070709100924e-02
    x[30,2]   old_TS4   -4.4517462504637229e-02
    x[30,3]   OBJ       2.4408272727272719e-02
    x[30,3]   onehot_30  1
    x[30,3]   w_lb_30_3  -2.2258731252318614e-02
    x[30,3]   w_ub_30_3  -3.9535535354550462e-02
    x[30,3]   hard_lower  3
    x[30,3]   hard_upper  3
    x[30,3]   old_TS1   -6.6776193756955843e-02
    x[30,3]   old_TS2   -1.1860660606365139e-01
    x[30,3]   old_TS3   -1.1860660606365139e-01
    x[30,3]   old_TS4   -6.6776193756955843e-02
    x[30,4]   OBJ       1.4644963636363631e-02
    x[30,4]   onehot_30  1
    x[30,4]   w_lb_30_4  -2.2258731252318614e-02
    x[30,4]   w_ub_30_4  -3.9535535354550462e-02
    x[30,4]   hard_lower  4
    x[30,4]   hard_upper  4
    x[30,4]   old_TS1   -8.9034925009274457e-02
    x[30,4]   old_TS2   -1.5814214141820185e-01
    x[30,4]   old_TS3   -1.5814214141820185e-01
    x[30,4]   old_TS4   -8.9034925009274457e-02
    x[30,5]   OBJ       4.8816545454545418e-03
    x[30,5]   onehot_30  1
    x[30,5]   w_lb_30_5  -2.2258731252318614e-02
    x[30,5]   w_ub_30_5  -3.9535535354550462e-02
    x[30,5]   hard_lower  5
    x[30,5]   hard_upper  5
    x[30,5]   old_TS1   -1.1129365626159307e-01
    x[30,5]   old_TS2   -1.9767767677275230e-01
    x[30,5]   old_TS3   -1.9767767677275230e-01
    x[30,5]   old_TS4   -1.1129365626159307e-01
    x[30,6]   OBJ       -4.8816545454545487e-03
    x[30,6]   onehot_30  1
    x[30,6]   w_lb_30_6  -2.2258731252318614e-02
    x[30,6]   w_ub_30_6  -3.9535535354550462e-02
    x[30,6]   hard_lower  6
    x[30,6]   hard_upper  6
    x[30,6]   old_TS1   -1.3355238751391169e-01
    x[30,6]   old_TS2   -2.3721321212730279e-01
    x[30,6]   old_TS3   -2.3721321212730279e-01
    x[30,6]   old_TS4   -1.3355238751391169e-01
    x[30,7]   OBJ       -1.4644963636363639e-02
    x[30,7]   onehot_30  1
    x[30,7]   w_lb_30_7  -2.2258731252318614e-02
    x[30,7]   w_ub_30_7  -3.9535535354550462e-02
    x[30,7]   hard_lower  7
    x[30,7]   hard_upper  7
    x[30,7]   old_TS1   -1.5581111876623030e-01
    x[30,7]   old_TS2   -2.7674874748185324e-01
    x[30,7]   old_TS3   -2.7674874748185324e-01
    x[30,7]   old_TS4   -1.5581111876623030e-01
    x[30,8]   OBJ       -2.4408272727272730e-02
    x[30,8]   onehot_30  1
    x[30,8]   w_lb_30_8  -2.2258731252318614e-02
    x[30,8]   w_ub_30_8  -3.9535535354550462e-02
    x[30,8]   hard_lower  8
    x[30,8]   hard_upper  8
    x[30,8]   old_TS1   -1.7806985001854891e-01
    x[30,8]   old_TS2   -3.1628428283640370e-01
    x[30,8]   old_TS3   -3.1628428283640370e-01
    x[30,8]   old_TS4   -1.7806985001854891e-01
    x[30,9]   OBJ       -3.4171581818181820e-02
    x[30,9]   onehot_30  1
    x[30,9]   w_lb_30_9  -2.2258731252318614e-02
    x[30,9]   w_ub_30_9  -3.9535535354550462e-02
    x[30,9]   hard_lower  9
    x[30,9]   hard_upper  9
    x[30,9]   old_TS1   -2.0032858127086753e-01
    x[30,9]   old_TS2   -3.5581981819095415e-01
    x[30,9]   old_TS3   -3.5581981819095415e-01
    x[30,9]   old_TS4   -2.0032858127086753e-01
    x[30,10]  OBJ       -4.3934890909090911e-02
    x[30,10]  onehot_30  1
    x[30,10]  w_lb_30_10  -2.2258731252318614e-02
    x[30,10]  w_ub_30_10  -3.9535535354550462e-02
    x[30,10]  hard_lower  10
    x[30,10]  hard_upper  10
    x[30,10]  old_TS1   -2.2258731252318614e-01
    x[30,10]  old_TS2   -3.9535535354550461e-01
    x[30,10]  old_TS3   -3.9535535354550461e-01
    x[30,10]  old_TS4   -2.2258731252318614e-01
    x[30,11]  OBJ       -5.3698199999999995e-02
    x[30,11]  onehot_30  1
    x[30,11]  w_lb_30_11  -2.2258731252318614e-02
    x[30,11]  w_ub_30_11  -3.9535535354550462e-02
    x[30,11]  hard_lower  11
    x[30,11]  hard_upper  11
    x[30,11]  old_TS1   -2.4484604377550476e-01
    x[30,11]  old_TS2   -4.3489088890005506e-01
    x[30,11]  old_TS3   -4.3489088890005506e-01
    x[30,11]  old_TS4   -2.4484604377550476e-01
    x[30,12]  OBJ       -4.3934890909090904e-02
    x[30,12]  onehot_30  1
    x[30,12]  w_lb_30_12  -2.2258731252318614e-02
    x[30,12]  w_ub_30_12  -3.9535535354550462e-02
    x[30,12]  hard_lower  12
    x[30,12]  hard_upper  12
    x[30,12]  old_TS1   -2.6710477502782337e-01
    x[30,12]  old_TS2   -4.7442642425460557e-01
    x[30,12]  old_TS3   -4.7442642425460557e-01
    x[30,12]  old_TS4   -2.6710477502782337e-01
    x[30,13]  OBJ       -3.4171581818181813e-02
    x[30,13]  onehot_30  1
    x[30,13]  w_lb_30_13  -2.2258731252318614e-02
    x[30,13]  w_ub_30_13  -3.9535535354550462e-02
    x[30,13]  hard_lower  13
    x[30,13]  hard_upper  13
    x[30,13]  old_TS1   -2.8936350628014196e-01
    x[30,13]  old_TS2   -0.513961959609156
    x[30,13]  old_TS3   -0.513961959609156
    x[30,13]  old_TS4   -2.8936350628014196e-01
    x[30,14]  OBJ       -2.4408272727272723e-02
    x[30,14]  onehot_30  1
    x[30,14]  w_lb_30_14  -2.2258731252318614e-02
    x[30,14]  w_ub_30_14  -3.9535535354550462e-02
    x[30,14]  hard_lower  14
    x[30,14]  hard_upper  14
    x[30,14]  old_TS1   -3.1162223753246060e-01
    x[30,14]  old_TS2   -5.5349749496370648e-01
    x[30,14]  old_TS3   -5.5349749496370648e-01
    x[30,14]  old_TS4   -3.1162223753246060e-01
    x[30,15]  OBJ       -1.4644963636363632e-02
    x[30,15]  onehot_30  1
    x[30,15]  w_lb_30_15  -2.2258731252318614e-02
    x[30,15]  w_ub_30_15  -3.9535535354550462e-02
    x[30,15]  hard_lower  15
    x[30,15]  hard_upper  15
    x[30,15]  old_TS1   -3.3388096878477924e-01
    x[30,15]  old_TS2   -5.9303303031825694e-01
    x[30,15]  old_TS3   -5.9303303031825694e-01
    x[30,15]  old_TS4   -3.3388096878477924e-01
    x[30,16]  OBJ       -4.8816545454545427e-03
    x[30,16]  onehot_30  1
    x[30,16]  w_lb_30_16  -2.2258731252318614e-02
    x[30,16]  w_ub_30_16  -3.9535535354550462e-02
    x[30,16]  hard_lower  16
    x[30,16]  hard_upper  16
    x[30,16]  old_TS1   -3.5613970003709783e-01
    x[30,16]  old_TS2   -6.3256856567280739e-01
    x[30,16]  old_TS3   -6.3256856567280739e-01
    x[30,16]  old_TS4   -3.5613970003709783e-01
    x[30,17]  OBJ       4.8816545454545479e-03
    x[30,17]  onehot_30  1
    x[30,17]  w_lb_30_17  -2.2258731252318614e-02
    x[30,17]  w_ub_30_17  -3.9535535354550462e-02
    x[30,17]  hard_lower  17
    x[30,17]  hard_upper  17
    x[30,17]  old_TS1   -3.7839843128941641e-01
    x[30,17]  old_TS2   -6.7210410102735785e-01
    x[30,17]  old_TS3   -6.7210410102735785e-01
    x[30,17]  old_TS4   -3.7839843128941641e-01
    x[30,18]  OBJ       1.4644963636363638e-02
    x[30,18]  onehot_30  1
    x[30,18]  w_lb_30_18  -2.2258731252318614e-02
    x[30,18]  w_ub_30_18  -3.9535535354550462e-02
    x[30,18]  hard_lower  18
    x[30,18]  hard_upper  18
    x[30,18]  old_TS1   -4.0065716254173506e-01
    x[30,18]  old_TS2   -7.1163963638190830e-01
    x[30,18]  old_TS3   -7.1163963638190830e-01
    x[30,18]  old_TS4   -4.0065716254173506e-01
    x[30,19]  OBJ       2.4408272727272726e-02
    x[30,19]  onehot_30  1
    x[30,19]  w_lb_30_19  -2.2258731252318614e-02
    x[30,19]  w_ub_30_19  -3.9535535354550462e-02
    x[30,19]  hard_lower  19
    x[30,19]  hard_upper  19
    x[30,19]  old_TS1   -4.2291589379405370e-01
    x[30,19]  old_TS2   -7.5117517173645876e-01
    x[30,19]  old_TS3   -7.5117517173645876e-01
    x[30,19]  old_TS4   -4.2291589379405370e-01
    x[30,20]  OBJ       3.4171581818181813e-02
    x[30,20]  onehot_30  1
    x[30,20]  w_lb_30_20  -2.2258731252318614e-02
    x[30,20]  w_ub_30_20  -3.9535535354550462e-02
    x[30,20]  hard_lower  20
    x[30,20]  hard_upper  20
    x[30,20]  old_TS1   -4.4517462504637229e-01
    x[30,20]  old_TS2   -7.9071070709100921e-01
    x[30,20]  old_TS3   -7.9071070709100921e-01
    x[30,20]  old_TS4   -4.4517462504637229e-01
    x[31,0]   OBJ       1.8639064285714286e-02
    x[31,0]   onehot_31  1
    x[31,0]   w_lb_31_0  -2.2258731252318614e-02
    x[31,0]   w_ub_31_0  -3.9535535354550462e-02
    x[31,1]   OBJ       1.2426042857142858e-02
    x[31,1]   onehot_31  1
    x[31,1]   w_lb_31_1  -2.2258731252318614e-02
    x[31,1]   w_ub_31_1  -3.9535535354550462e-02
    x[31,1]   hard_lower  1
    x[31,1]   hard_upper  1
    x[31,1]   old_TS1   -2.2258731252318614e-02
    x[31,1]   old_TS2   -3.9535535354550462e-02
    x[31,1]   old_TS3   -3.9535535354550462e-02
    x[31,1]   old_TS4   -2.2258731252318614e-02
    x[31,2]   OBJ       0.00621302142857143
    x[31,2]   onehot_31  1
    x[31,2]   w_lb_31_2  -2.2258731252318614e-02
    x[31,2]   w_ub_31_2  -3.9535535354550462e-02
    x[31,2]   hard_lower  2
    x[31,2]   hard_upper  2
    x[31,2]   old_TS1   -4.4517462504637229e-02
    x[31,2]   old_TS2   -7.9071070709100924e-02
    x[31,2]   old_TS3   -7.9071070709100924e-02
    x[31,2]   old_TS4   -4.4517462504637229e-02
    x[31,3]   OBJ       2.4142438048713188e-18
    x[31,3]   onehot_31  1
    x[31,3]   w_lb_31_3  -2.2258731252318614e-02
    x[31,3]   w_ub_31_3  -3.9535535354550462e-02
    x[31,3]   hard_lower  3
    x[31,3]   hard_upper  3
    x[31,3]   old_TS1   -6.6776193756955843e-02
    x[31,3]   old_TS2   -1.1860660606365139e-01
    x[31,3]   old_TS3   -1.1860660606365139e-01
    x[31,3]   old_TS4   -6.6776193756955843e-02
    x[31,4]   OBJ       -6.2130214285714257e-03
    x[31,4]   onehot_31  1
    x[31,4]   w_lb_31_4  -2.2258731252318614e-02
    x[31,4]   w_ub_31_4  -3.9535535354550462e-02
    x[31,4]   hard_lower  4
    x[31,4]   hard_upper  4
    x[31,4]   old_TS1   -8.9034925009274457e-02
    x[31,4]   old_TS2   -1.5814214141820185e-01
    x[31,4]   old_TS3   -1.5814214141820185e-01
    x[31,4]   old_TS4   -8.9034925009274457e-02
    x[31,5]   OBJ       -1.2426042857142855e-02
    x[31,5]   onehot_31  1
    x[31,5]   w_lb_31_5  -2.2258731252318614e-02
    x[31,5]   w_ub_31_5  -3.9535535354550462e-02
    x[31,5]   hard_lower  5
    x[31,5]   hard_upper  5
    x[31,5]   old_TS1   -1.1129365626159307e-01
    x[31,5]   old_TS2   -1.9767767677275230e-01
    x[31,5]   old_TS3   -1.9767767677275230e-01
    x[31,5]   old_TS4   -1.1129365626159307e-01
    x[31,6]   OBJ       -1.8639064285714282e-02
    x[31,6]   onehot_31  1
    x[31,6]   w_lb_31_6  -2.2258731252318614e-02
    x[31,6]   w_ub_31_6  -3.9535535354550462e-02
    x[31,6]   hard_lower  6
    x[31,6]   hard_upper  6
    x[31,6]   old_TS1   -1.3355238751391169e-01
    x[31,6]   old_TS2   -2.3721321212730279e-01
    x[31,6]   old_TS3   -2.3721321212730279e-01
    x[31,6]   old_TS4   -1.3355238751391169e-01
    x[31,7]   OBJ       -2.4852085714285713e-02
    x[31,7]   onehot_31  1
    x[31,7]   w_lb_31_7  -2.2258731252318614e-02
    x[31,7]   w_ub_31_7  -3.9535535354550462e-02
    x[31,7]   hard_lower  7
    x[31,7]   hard_upper  7
    x[31,7]   old_TS1   -1.5581111876623030e-01
    x[31,7]   old_TS2   -2.7674874748185324e-01
    x[31,7]   old_TS3   -2.7674874748185324e-01
    x[31,7]   old_TS4   -1.5581111876623030e-01
    x[31,8]   OBJ       -1.8639064285714289e-02
    x[31,8]   onehot_31  1
    x[31,8]   w_lb_31_8  -2.2258731252318614e-02
    x[31,8]   w_ub_31_8  -3.9535535354550462e-02
    x[31,8]   hard_lower  8
    x[31,8]   hard_upper  8
    x[31,8]   old_TS1   -1.7806985001854891e-01
    x[31,8]   old_TS2   -3.1628428283640370e-01
    x[31,8]   old_TS3   -3.1628428283640370e-01
    x[31,8]   old_TS4   -1.7806985001854891e-01
    x[31,9]   OBJ       -1.2426042857142860e-02
    x[31,9]   onehot_31  1
    x[31,9]   w_lb_31_9  -2.2258731252318614e-02
    x[31,9]   w_ub_31_9  -3.9535535354550462e-02
    x[31,9]   hard_lower  9
    x[31,9]   hard_upper  9
    x[31,9]   old_TS1   -2.0032858127086753e-01
    x[31,9]   old_TS2   -3.5581981819095415e-01
    x[31,9]   old_TS3   -3.5581981819095415e-01
    x[31,9]   old_TS4   -2.0032858127086753e-01
    x[31,10]  OBJ       -6.2130214285714309e-03
    x[31,10]  onehot_31  1
    x[31,10]  w_lb_31_10  -2.2258731252318614e-02
    x[31,10]  w_ub_31_10  -3.9535535354550462e-02
    x[31,10]  hard_lower  10
    x[31,10]  hard_upper  10
    x[31,10]  old_TS1   -2.2258731252318614e-01
    x[31,10]  old_TS2   -3.9535535354550461e-01
    x[31,10]  old_TS3   -3.9535535354550461e-01
    x[31,10]  old_TS4   -2.2258731252318614e-01
    x[31,11]  OBJ       -2.4142438048713188e-18
    x[31,11]  onehot_31  1
    x[31,11]  w_lb_31_11  -2.2258731252318614e-02
    x[31,11]  w_ub_31_11  -3.9535535354550462e-02
    x[31,11]  hard_lower  11
    x[31,11]  hard_upper  11
    x[31,11]  old_TS1   -2.4484604377550476e-01
    x[31,11]  old_TS2   -4.3489088890005506e-01
    x[31,11]  old_TS3   -4.3489088890005506e-01
    x[31,11]  old_TS4   -2.4484604377550476e-01
    x[31,12]  OBJ       6.2130214285714249e-03
    x[31,12]  onehot_31  1
    x[31,12]  w_lb_31_12  -2.2258731252318614e-02
    x[31,12]  w_ub_31_12  -3.9535535354550462e-02
    x[31,12]  hard_lower  12
    x[31,12]  hard_upper  12
    x[31,12]  old_TS1   -2.6710477502782337e-01
    x[31,12]  old_TS2   -4.7442642425460557e-01
    x[31,12]  old_TS3   -4.7442642425460557e-01
    x[31,12]  old_TS4   -2.6710477502782337e-01
    x[31,13]  OBJ       1.2426042857142853e-02
    x[31,13]  onehot_31  1
    x[31,13]  w_lb_31_13  -2.2258731252318614e-02
    x[31,13]  w_ub_31_13  -3.9535535354550462e-02
    x[31,13]  hard_lower  13
    x[31,13]  hard_upper  13
    x[31,13]  old_TS1   -2.8936350628014196e-01
    x[31,13]  old_TS2   -0.513961959609156
    x[31,13]  old_TS3   -0.513961959609156
    x[31,13]  old_TS4   -2.8936350628014196e-01
    x[31,14]  OBJ       1.8639064285714279e-02
    x[31,14]  onehot_31  1
    x[31,14]  w_lb_31_14  -2.2258731252318614e-02
    x[31,14]  w_ub_31_14  -3.9535535354550462e-02
    x[31,14]  hard_lower  14
    x[31,14]  hard_upper  14
    x[31,14]  old_TS1   -3.1162223753246060e-01
    x[31,14]  old_TS2   -5.5349749496370648e-01
    x[31,14]  old_TS3   -5.5349749496370648e-01
    x[31,14]  old_TS4   -3.1162223753246060e-01
    x[31,15]  OBJ       2.4852085714285710e-02
    x[31,15]  onehot_31  1
    x[31,15]  w_lb_31_15  -2.2258731252318614e-02
    x[31,15]  w_ub_31_15  -3.9535535354550462e-02
    x[31,15]  hard_lower  15
    x[31,15]  hard_upper  15
    x[31,15]  old_TS1   -3.3388096878477924e-01
    x[31,15]  old_TS2   -5.9303303031825694e-01
    x[31,15]  old_TS3   -5.9303303031825694e-01
    x[31,15]  old_TS4   -3.3388096878477924e-01
    x[32,0]   OBJ       2.8402349999999996e-02
    x[32,0]   onehot_32  1
    x[32,0]   w_lb_32_0  -2.2258731252318614e-02
    x[32,0]   w_ub_32_0  -3.9535535354550462e-02
    x[32,1]   OBJ       2.1301762499999995e-02
    x[32,1]   onehot_32  1
    x[32,1]   w_lb_32_1  -2.2258731252318614e-02
    x[32,1]   w_ub_32_1  -3.9535535354550462e-02
    x[32,1]   hard_lower  1
    x[32,1]   hard_upper  1
    x[32,1]   old_TS1   -2.2258731252318614e-02
    x[32,1]   old_TS2   -3.9535535354550462e-02
    x[32,1]   old_TS3   -3.9535535354550462e-02
    x[32,1]   old_TS4   -2.2258731252318614e-02
    x[32,2]   OBJ       1.4201174999999998e-02
    x[32,2]   onehot_32  1
    x[32,2]   w_lb_32_2  -2.2258731252318614e-02
    x[32,2]   w_ub_32_2  -3.9535535354550462e-02
    x[32,2]   hard_lower  2
    x[32,2]   hard_upper  2
    x[32,2]   old_TS1   -4.4517462504637229e-02
    x[32,2]   old_TS2   -7.9071070709100924e-02
    x[32,2]   old_TS3   -7.9071070709100924e-02
    x[32,2]   old_TS4   -4.4517462504637229e-02
    x[32,3]   OBJ       7.1005874999999991e-03
    x[32,3]   onehot_32  1
    x[32,3]   w_lb_32_3  -2.2258731252318614e-02
    x[32,3]   w_ub_32_3  -3.9535535354550462e-02
    x[32,3]   hard_lower  3
    x[32,3]   hard_upper  3
    x[32,3]   old_TS1   -6.6776193756955843e-02
    x[32,3]   old_TS2   -1.1860660606365139e-01
    x[32,3]   old_TS3   -1.1860660606365139e-01
    x[32,3]   old_TS4   -6.6776193756955843e-02
    x[32,4]   onehot_32  1
    x[32,4]   w_lb_32_4  -2.2258731252318614e-02
    x[32,4]   w_ub_32_4  -3.9535535354550462e-02
    x[32,4]   hard_lower  4
    x[32,4]   hard_upper  4
    x[32,4]   old_TS1   -8.9034925009274457e-02
    x[32,4]   old_TS2   -1.5814214141820185e-01
    x[32,4]   old_TS3   -1.5814214141820185e-01
    x[32,4]   old_TS4   -8.9034925009274457e-02
    x[32,5]   OBJ       -7.1005874999999991e-03
    x[32,5]   onehot_32  1
    x[32,5]   w_lb_32_5  -2.2258731252318614e-02
    x[32,5]   w_ub_32_5  -3.9535535354550462e-02
    x[32,5]   hard_lower  5
    x[32,5]   hard_upper  5
    x[32,5]   old_TS1   -1.1129365626159307e-01
    x[32,5]   old_TS2   -1.9767767677275230e-01
    x[32,5]   old_TS3   -1.9767767677275230e-01
    x[32,5]   old_TS4   -1.1129365626159307e-01
    x[32,6]   OBJ       -1.4201174999999998e-02
    x[32,6]   onehot_32  1
    x[32,6]   w_lb_32_6  -2.2258731252318614e-02
    x[32,6]   w_ub_32_6  -3.9535535354550462e-02
    x[32,6]   hard_lower  6
    x[32,6]   hard_upper  6
    x[32,6]   old_TS1   -1.3355238751391169e-01
    x[32,6]   old_TS2   -2.3721321212730279e-01
    x[32,6]   old_TS3   -2.3721321212730279e-01
    x[32,6]   old_TS4   -1.3355238751391169e-01
    x[32,7]   OBJ       -2.1301762499999998e-02
    x[32,7]   onehot_32  1
    x[32,7]   w_lb_32_7  -2.2258731252318614e-02
    x[32,7]   w_ub_32_7  -3.9535535354550462e-02
    x[32,7]   hard_lower  7
    x[32,7]   hard_upper  7
    x[32,7]   old_TS1   -1.5581111876623030e-01
    x[32,7]   old_TS2   -2.7674874748185324e-01
    x[32,7]   old_TS3   -2.7674874748185324e-01
    x[32,7]   old_TS4   -1.5581111876623030e-01
    x[32,8]   OBJ       -2.8402349999999996e-02
    x[32,8]   onehot_32  1
    x[32,8]   w_lb_32_8  -2.2258731252318614e-02
    x[32,8]   w_ub_32_8  -3.9535535354550462e-02
    x[32,8]   hard_lower  8
    x[32,8]   hard_upper  8
    x[32,8]   old_TS1   -1.7806985001854891e-01
    x[32,8]   old_TS2   -3.1628428283640370e-01
    x[32,8]   old_TS3   -3.1628428283640370e-01
    x[32,8]   old_TS4   -1.7806985001854891e-01
    x[32,9]   OBJ       -2.1301762499999998e-02
    x[32,9]   onehot_32  1
    x[32,9]   w_lb_32_9  -2.2258731252318614e-02
    x[32,9]   w_ub_32_9  -3.9535535354550462e-02
    x[32,9]   hard_lower  9
    x[32,9]   hard_upper  9
    x[32,9]   old_TS1   -2.0032858127086753e-01
    x[32,9]   old_TS2   -3.5581981819095415e-01
    x[32,9]   old_TS3   -3.5581981819095415e-01
    x[32,9]   old_TS4   -2.0032858127086753e-01
    x[32,10]  OBJ       -1.4201174999999998e-02
    x[32,10]  onehot_32  1
    x[32,10]  w_lb_32_10  -2.2258731252318614e-02
    x[32,10]  w_ub_32_10  -3.9535535354550462e-02
    x[32,10]  hard_lower  10
    x[32,10]  hard_upper  10
    x[32,10]  old_TS1   -2.2258731252318614e-01
    x[32,10]  old_TS2   -3.9535535354550461e-01
    x[32,10]  old_TS3   -3.9535535354550461e-01
    x[32,10]  old_TS4   -2.2258731252318614e-01
    x[32,11]  OBJ       -7.1005874999999991e-03
    x[32,11]  onehot_32  1
    x[32,11]  w_lb_32_11  -2.2258731252318614e-02
    x[32,11]  w_ub_32_11  -3.9535535354550462e-02
    x[32,11]  hard_lower  11
    x[32,11]  hard_upper  11
    x[32,11]  old_TS1   -2.4484604377550476e-01
    x[32,11]  old_TS2   -4.3489088890005506e-01
    x[32,11]  old_TS3   -4.3489088890005506e-01
    x[32,11]  old_TS4   -2.4484604377550476e-01
    x[32,12]  onehot_32  1
    x[32,12]  w_lb_32_12  -2.2258731252318614e-02
    x[32,12]  w_ub_32_12  -3.9535535354550462e-02
    x[32,12]  hard_lower  12
    x[32,12]  hard_upper  12
    x[32,12]  old_TS1   -2.6710477502782337e-01
    x[32,12]  old_TS2   -4.7442642425460557e-01
    x[32,12]  old_TS3   -4.7442642425460557e-01
    x[32,12]  old_TS4   -2.6710477502782337e-01
    x[32,13]  OBJ       7.1005874999999991e-03
    x[32,13]  onehot_32  1
    x[32,13]  w_lb_32_13  -2.2258731252318614e-02
    x[32,13]  w_ub_32_13  -3.9535535354550462e-02
    x[32,13]  hard_lower  13
    x[32,13]  hard_upper  13
    x[32,13]  old_TS1   -2.8936350628014196e-01
    x[32,13]  old_TS2   -0.513961959609156
    x[32,13]  old_TS3   -0.513961959609156
    x[32,13]  old_TS4   -2.8936350628014196e-01
    x[32,14]  OBJ       1.4201174999999998e-02
    x[32,14]  onehot_32  1
    x[32,14]  w_lb_32_14  -2.2258731252318614e-02
    x[32,14]  w_ub_32_14  -3.9535535354550462e-02
    x[32,14]  hard_lower  14
    x[32,14]  hard_upper  14
    x[32,14]  old_TS1   -3.1162223753246060e-01
    x[32,14]  old_TS2   -5.5349749496370648e-01
    x[32,14]  old_TS3   -5.5349749496370648e-01
    x[32,14]  old_TS4   -3.1162223753246060e-01
    x[32,15]  OBJ       2.1301762499999995e-02
    x[32,15]  onehot_32  1
    x[32,15]  w_lb_32_15  -2.2258731252318614e-02
    x[32,15]  w_ub_32_15  -3.9535535354550462e-02
    x[32,15]  hard_lower  15
    x[32,15]  hard_upper  15
    x[32,15]  old_TS1   -3.3388096878477924e-01
    x[32,15]  old_TS2   -5.9303303031825694e-01
    x[32,15]  old_TS3   -5.9303303031825694e-01
    x[32,15]  old_TS4   -3.3388096878477924e-01
    x[33,0]   OBJ       7.4999999999999983e-02
    x[33,0]   onehot_33  1
    x[33,0]   w_lb_33_0  -2.2258731252318614e-02
    x[33,0]   w_ub_33_0  -3.9535535354550462e-02
    x[33,1]   OBJ       6.3461538461538444e-02
    x[33,1]   onehot_33  1
    x[33,1]   w_lb_33_1  -2.2258731252318614e-02
    x[33,1]   w_ub_33_1  -3.9535535354550462e-02
    x[33,1]   hard_lower  1
    x[33,1]   hard_upper  1
    x[33,1]   old_TS1   -2.2258731252318614e-02
    x[33,1]   old_TS2   -3.9535535354550462e-02
    x[33,1]   old_TS3   -3.9535535354550462e-02
    x[33,1]   old_TS4   -2.2258731252318614e-02
    x[33,2]   OBJ       5.1923076923076912e-02
    x[33,2]   onehot_33  1
    x[33,2]   w_lb_33_2  -2.2258731252318614e-02
    x[33,2]   w_ub_33_2  -3.9535535354550462e-02
    x[33,2]   hard_lower  2
    x[33,2]   hard_upper  2
    x[33,2]   old_TS1   -4.4517462504637229e-02
    x[33,2]   old_TS2   -7.9071070709100924e-02
    x[33,2]   old_TS3   -7.9071070709100924e-02
    x[33,2]   old_TS4   -4.4517462504637229e-02
    x[33,3]   OBJ       4.0384615384615373e-02
    x[33,3]   onehot_33  1
    x[33,3]   w_lb_33_3  -2.2258731252318614e-02
    x[33,3]   w_ub_33_3  -3.9535535354550462e-02
    x[33,3]   hard_lower  3
    x[33,3]   hard_upper  3
    x[33,3]   old_TS1   -6.6776193756955843e-02
    x[33,3]   old_TS2   -1.1860660606365139e-01
    x[33,3]   old_TS3   -1.1860660606365139e-01
    x[33,3]   old_TS4   -6.6776193756955843e-02
    x[33,4]   OBJ       2.8846153846153837e-02
    x[33,4]   onehot_33  1
    x[33,4]   w_lb_33_4  -2.2258731252318614e-02
    x[33,4]   w_ub_33_4  -3.9535535354550462e-02
    x[33,4]   hard_lower  4
    x[33,4]   hard_upper  4
    x[33,4]   old_TS1   -8.9034925009274457e-02
    x[33,4]   old_TS2   -1.5814214141820185e-01
    x[33,4]   old_TS3   -1.5814214141820185e-01
    x[33,4]   old_TS4   -8.9034925009274457e-02
    x[33,5]   OBJ       1.7307692307692298e-02
    x[33,5]   onehot_33  1
    x[33,5]   w_lb_33_5  -2.2258731252318614e-02
    x[33,5]   w_ub_33_5  -3.9535535354550462e-02
    x[33,5]   hard_lower  5
    x[33,5]   hard_upper  5
    x[33,5]   old_TS1   -1.1129365626159307e-01
    x[33,5]   old_TS2   -1.9767767677275230e-01
    x[33,5]   old_TS3   -1.9767767677275230e-01
    x[33,5]   old_TS4   -1.1129365626159307e-01
    x[33,6]   OBJ       5.7692307692307609e-03
    x[33,6]   onehot_33  1
    x[33,6]   w_lb_33_6  -2.2258731252318614e-02
    x[33,6]   w_ub_33_6  -3.9535535354550462e-02
    x[33,6]   hard_lower  6
    x[33,6]   hard_upper  6
    x[33,6]   old_TS1   -1.3355238751391169e-01
    x[33,6]   old_TS2   -2.3721321212730279e-01
    x[33,6]   old_TS3   -2.3721321212730279e-01
    x[33,6]   old_TS4   -1.3355238751391169e-01
    x[33,7]   OBJ       -5.7692307692307782e-03
    x[33,7]   onehot_33  1
    x[33,7]   w_lb_33_7  -2.2258731252318614e-02
    x[33,7]   w_ub_33_7  -3.9535535354550462e-02
    x[33,7]   hard_lower  7
    x[33,7]   hard_upper  7
    x[33,7]   old_TS1   -1.5581111876623030e-01
    x[33,7]   old_TS2   -2.7674874748185324e-01
    x[33,7]   old_TS3   -2.7674874748185324e-01
    x[33,7]   old_TS4   -1.5581111876623030e-01
    x[33,8]   OBJ       -1.7307692307692319e-02
    x[33,8]   onehot_33  1
    x[33,8]   w_lb_33_8  -2.2258731252318614e-02
    x[33,8]   w_ub_33_8  -3.9535535354550462e-02
    x[33,8]   hard_lower  8
    x[33,8]   hard_upper  8
    x[33,8]   old_TS1   -1.7806985001854891e-01
    x[33,8]   old_TS2   -3.1628428283640370e-01
    x[33,8]   old_TS3   -3.1628428283640370e-01
    x[33,8]   old_TS4   -1.7806985001854891e-01
    x[33,9]   OBJ       -2.8846153846153858e-02
    x[33,9]   onehot_33  1
    x[33,9]   w_lb_33_9  -2.2258731252318614e-02
    x[33,9]   w_ub_33_9  -3.9535535354550462e-02
    x[33,9]   hard_lower  9
    x[33,9]   hard_upper  9
    x[33,9]   old_TS1   -2.0032858127086753e-01
    x[33,9]   old_TS2   -3.5581981819095415e-01
    x[33,9]   old_TS3   -3.5581981819095415e-01
    x[33,9]   old_TS4   -2.0032858127086753e-01
    x[33,10]  OBJ       -4.0384615384615394e-02
    x[33,10]  onehot_33  1
    x[33,10]  w_lb_33_10  -2.2258731252318614e-02
    x[33,10]  w_ub_33_10  -3.9535535354550462e-02
    x[33,10]  hard_lower  10
    x[33,10]  hard_upper  10
    x[33,10]  old_TS1   -2.2258731252318614e-01
    x[33,10]  old_TS2   -3.9535535354550461e-01
    x[33,10]  old_TS3   -3.9535535354550461e-01
    x[33,10]  old_TS4   -2.2258731252318614e-01
    x[33,11]  OBJ       -5.1923076923076933e-02
    x[33,11]  onehot_33  1
    x[33,11]  w_lb_33_11  -2.2258731252318614e-02
    x[33,11]  w_ub_33_11  -3.9535535354550462e-02
    x[33,11]  hard_lower  11
    x[33,11]  hard_upper  11
    x[33,11]  old_TS1   -2.4484604377550476e-01
    x[33,11]  old_TS2   -4.3489088890005506e-01
    x[33,11]  old_TS3   -4.3489088890005506e-01
    x[33,11]  old_TS4   -2.4484604377550476e-01
    x[33,12]  OBJ       -6.3461538461538472e-02
    x[33,12]  onehot_33  1
    x[33,12]  w_lb_33_12  -2.2258731252318614e-02
    x[33,12]  w_ub_33_12  -3.9535535354550462e-02
    x[33,12]  hard_lower  12
    x[33,12]  hard_upper  12
    x[33,12]  old_TS1   -2.6710477502782337e-01
    x[33,12]  old_TS2   -4.7442642425460557e-01
    x[33,12]  old_TS3   -4.7442642425460557e-01
    x[33,12]  old_TS4   -2.6710477502782337e-01
    x[33,13]  OBJ       -0.075
    x[33,13]  onehot_33  1
    x[33,13]  w_lb_33_13  -2.2258731252318614e-02
    x[33,13]  w_ub_33_13  -3.9535535354550462e-02
    x[33,13]  hard_lower  13
    x[33,13]  hard_upper  13
    x[33,13]  old_TS1   -2.8936350628014196e-01
    x[33,13]  old_TS2   -0.513961959609156
    x[33,13]  old_TS3   -0.513961959609156
    x[33,13]  old_TS4   -2.8936350628014196e-01
    x[33,14]  OBJ       -6.3461538461538458e-02
    x[33,14]  onehot_33  1
    x[33,14]  w_lb_33_14  -2.2258731252318614e-02
    x[33,14]  w_ub_33_14  -3.9535535354550462e-02
    x[33,14]  hard_lower  14
    x[33,14]  hard_upper  14
    x[33,14]  old_TS1   -3.1162223753246060e-01
    x[33,14]  old_TS2   -5.5349749496370648e-01
    x[33,14]  old_TS3   -5.5349749496370648e-01
    x[33,14]  old_TS4   -3.1162223753246060e-01
    x[33,15]  OBJ       -5.1923076923076919e-02
    x[33,15]  onehot_33  1
    x[33,15]  w_lb_33_15  -2.2258731252318614e-02
    x[33,15]  w_ub_33_15  -3.9535535354550462e-02
    x[33,15]  hard_lower  15
    x[33,15]  hard_upper  15
    x[33,15]  old_TS1   -3.3388096878477924e-01
    x[33,15]  old_TS2   -5.9303303031825694e-01
    x[33,15]  old_TS3   -5.9303303031825694e-01
    x[33,15]  old_TS4   -3.3388096878477924e-01
    x[33,16]  OBJ       -4.0384615384615380e-02
    x[33,16]  onehot_33  1
    x[33,16]  w_lb_33_16  -2.2258731252318614e-02
    x[33,16]  w_ub_33_16  -3.9535535354550462e-02
    x[33,16]  hard_lower  16
    x[33,16]  hard_upper  16
    x[33,16]  old_TS1   -3.5613970003709783e-01
    x[33,16]  old_TS2   -6.3256856567280739e-01
    x[33,16]  old_TS3   -6.3256856567280739e-01
    x[33,16]  old_TS4   -3.5613970003709783e-01
    x[33,17]  OBJ       -2.8846153846153841e-02
    x[33,17]  onehot_33  1
    x[33,17]  w_lb_33_17  -2.2258731252318614e-02
    x[33,17]  w_ub_33_17  -3.9535535354550462e-02
    x[33,17]  hard_lower  17
    x[33,17]  hard_upper  17
    x[33,17]  old_TS1   -3.7839843128941641e-01
    x[33,17]  old_TS2   -6.7210410102735785e-01
    x[33,17]  old_TS3   -6.7210410102735785e-01
    x[33,17]  old_TS4   -3.7839843128941641e-01
    x[33,18]  OBJ       -0.0173076923076923
    x[33,18]  onehot_33  1
    x[33,18]  w_lb_33_18  -2.2258731252318614e-02
    x[33,18]  w_ub_33_18  -3.9535535354550462e-02
    x[33,18]  hard_lower  18
    x[33,18]  hard_upper  18
    x[33,18]  old_TS1   -4.0065716254173506e-01
    x[33,18]  old_TS2   -7.1163963638190830e-01
    x[33,18]  old_TS3   -7.1163963638190830e-01
    x[33,18]  old_TS4   -4.0065716254173506e-01
    x[33,19]  OBJ       -5.7692307692307617e-03
    x[33,19]  onehot_33  1
    x[33,19]  w_lb_33_19  -2.2258731252318614e-02
    x[33,19]  w_ub_33_19  -3.9535535354550462e-02
    x[33,19]  hard_lower  19
    x[33,19]  hard_upper  19
    x[33,19]  old_TS1   -4.2291589379405370e-01
    x[33,19]  old_TS2   -7.5117517173645876e-01
    x[33,19]  old_TS3   -7.5117517173645876e-01
    x[33,19]  old_TS4   -4.2291589379405370e-01
    x[33,20]  OBJ       5.7692307692307774e-03
    x[33,20]  onehot_33  1
    x[33,20]  w_lb_33_20  -2.2258731252318614e-02
    x[33,20]  w_ub_33_20  -3.9535535354550462e-02
    x[33,20]  hard_lower  20
    x[33,20]  hard_upper  20
    x[33,20]  old_TS1   -4.4517462504637229e-01
    x[33,20]  old_TS2   -7.9071070709100921e-01
    x[33,20]  old_TS3   -7.9071070709100921e-01
    x[33,20]  old_TS4   -4.4517462504637229e-01
    x[33,21]  OBJ       1.7307692307692316e-02
    x[33,21]  onehot_33  1
    x[33,21]  w_lb_33_21  -2.2258731252318614e-02
    x[33,21]  w_ub_33_21  -3.9535535354550462e-02
    x[33,21]  hard_lower  21
    x[33,21]  hard_upper  21
    x[33,21]  old_TS1   -4.6743335629869087e-01
    x[33,21]  old_TS2   -8.3024624244555967e-01
    x[33,21]  old_TS3   -8.3024624244555967e-01
    x[33,21]  old_TS4   -4.6743335629869087e-01
    x[33,22]  OBJ       2.8846153846153855e-02
    x[33,22]  onehot_33  1
    x[33,22]  w_lb_33_22  -2.2258731252318614e-02
    x[33,22]  w_ub_33_22  -3.9535535354550462e-02
    x[33,22]  hard_lower  22
    x[33,22]  hard_upper  22
    x[33,22]  old_TS1   -4.8969208755100951e-01
    x[33,22]  old_TS2   -8.6978177780011012e-01
    x[33,22]  old_TS3   -8.6978177780011012e-01
    x[33,22]  old_TS4   -4.8969208755100951e-01
    x[33,23]  OBJ       4.0384615384615387e-02
    x[33,23]  onehot_33  1
    x[33,23]  w_lb_33_23  -2.2258731252318614e-02
    x[33,23]  w_ub_33_23  -3.9535535354550462e-02
    x[33,23]  hard_lower  23
    x[33,23]  hard_upper  23
    x[33,23]  old_TS1   -5.1195081880332816e-01
    x[33,23]  old_TS2   -9.0931731315466058e-01
    x[33,23]  old_TS3   -9.0931731315466058e-01
    x[33,23]  old_TS4   -5.1195081880332816e-01
    x[33,24]  OBJ       5.1923076923076926e-02
    x[33,24]  onehot_33  1
    x[33,24]  w_lb_33_24  -2.2258731252318614e-02
    x[33,24]  w_ub_33_24  -3.9535535354550462e-02
    x[33,24]  hard_lower  24
    x[33,24]  hard_upper  24
    x[33,24]  old_TS1   -5.3420955005564674e-01
    x[33,24]  old_TS2   -9.4885284850921114e-01
    x[33,24]  old_TS3   -9.4885284850921114e-01
    x[33,24]  old_TS4   -5.3420955005564674e-01
    x[34,0]   OBJ       2.8402349999999996e-02
    x[34,0]   onehot_34  1
    x[34,0]   w_lb_34_0  -2.2258731252318614e-02
    x[34,0]   w_ub_34_0  -3.9535535354550462e-02
    x[34,1]   OBJ       2.1301762499999995e-02
    x[34,1]   onehot_34  1
    x[34,1]   w_lb_34_1  -2.2258731252318614e-02
    x[34,1]   w_ub_34_1  -3.9535535354550462e-02
    x[34,1]   hard_lower  1
    x[34,1]   hard_upper  1
    x[34,1]   old_TS1   -2.2258731252318614e-02
    x[34,1]   old_TS2   -3.9535535354550462e-02
    x[34,1]   old_TS3   -3.9535535354550462e-02
    x[34,1]   old_TS4   -2.2258731252318614e-02
    x[34,2]   OBJ       1.4201174999999998e-02
    x[34,2]   onehot_34  1
    x[34,2]   w_lb_34_2  -2.2258731252318614e-02
    x[34,2]   w_ub_34_2  -3.9535535354550462e-02
    x[34,2]   hard_lower  2
    x[34,2]   hard_upper  2
    x[34,2]   old_TS1   -4.4517462504637229e-02
    x[34,2]   old_TS2   -7.9071070709100924e-02
    x[34,2]   old_TS3   -7.9071070709100924e-02
    x[34,2]   old_TS4   -4.4517462504637229e-02
    x[34,3]   OBJ       7.1005874999999991e-03
    x[34,3]   onehot_34  1
    x[34,3]   w_lb_34_3  -2.2258731252318614e-02
    x[34,3]   w_ub_34_3  -3.9535535354550462e-02
    x[34,3]   hard_lower  3
    x[34,3]   hard_upper  3
    x[34,3]   old_TS1   -6.6776193756955843e-02
    x[34,3]   old_TS2   -1.1860660606365139e-01
    x[34,3]   old_TS3   -1.1860660606365139e-01
    x[34,3]   old_TS4   -6.6776193756955843e-02
    x[34,4]   onehot_34  1
    x[34,4]   w_lb_34_4  -2.2258731252318614e-02
    x[34,4]   w_ub_34_4  -3.9535535354550462e-02
    x[34,4]   hard_lower  4
    x[34,4]   hard_upper  4
    x[34,4]   old_TS1   -8.9034925009274457e-02
    x[34,4]   old_TS2   -1.5814214141820185e-01
    x[34,4]   old_TS3   -1.5814214141820185e-01
    x[34,4]   old_TS4   -8.9034925009274457e-02
    x[34,5]   OBJ       -7.1005874999999991e-03
    x[34,5]   onehot_34  1
    x[34,5]   w_lb_34_5  -2.2258731252318614e-02
    x[34,5]   w_ub_34_5  -3.9535535354550462e-02
    x[34,5]   hard_lower  5
    x[34,5]   hard_upper  5
    x[34,5]   old_TS1   -1.1129365626159307e-01
    x[34,5]   old_TS2   -1.9767767677275230e-01
    x[34,5]   old_TS3   -1.9767767677275230e-01
    x[34,5]   old_TS4   -1.1129365626159307e-01
    x[34,6]   OBJ       -1.4201174999999998e-02
    x[34,6]   onehot_34  1
    x[34,6]   w_lb_34_6  -2.2258731252318614e-02
    x[34,6]   w_ub_34_6  -3.9535535354550462e-02
    x[34,6]   hard_lower  6
    x[34,6]   hard_upper  6
    x[34,6]   old_TS1   -1.3355238751391169e-01
    x[34,6]   old_TS2   -2.3721321212730279e-01
    x[34,6]   old_TS3   -2.3721321212730279e-01
    x[34,6]   old_TS4   -1.3355238751391169e-01
    x[34,7]   OBJ       -2.1301762499999998e-02
    x[34,7]   onehot_34  1
    x[34,7]   w_lb_34_7  -2.2258731252318614e-02
    x[34,7]   w_ub_34_7  -3.9535535354550462e-02
    x[34,7]   hard_lower  7
    x[34,7]   hard_upper  7
    x[34,7]   old_TS1   -1.5581111876623030e-01
    x[34,7]   old_TS2   -2.7674874748185324e-01
    x[34,7]   old_TS3   -2.7674874748185324e-01
    x[34,7]   old_TS4   -1.5581111876623030e-01
    x[34,8]   OBJ       -2.8402349999999996e-02
    x[34,8]   onehot_34  1
    x[34,8]   w_lb_34_8  -2.2258731252318614e-02
    x[34,8]   w_ub_34_8  -3.9535535354550462e-02
    x[34,8]   hard_lower  8
    x[34,8]   hard_upper  8
    x[34,8]   old_TS1   -1.7806985001854891e-01
    x[34,8]   old_TS2   -3.1628428283640370e-01
    x[34,8]   old_TS3   -3.1628428283640370e-01
    x[34,8]   old_TS4   -1.7806985001854891e-01
    x[34,9]   OBJ       -2.1301762499999998e-02
    x[34,9]   onehot_34  1
    x[34,9]   w_lb_34_9  -2.2258731252318614e-02
    x[34,9]   w_ub_34_9  -3.9535535354550462e-02
    x[34,9]   hard_lower  9
    x[34,9]   hard_upper  9
    x[34,9]   old_TS1   -2.0032858127086753e-01
    x[34,9]   old_TS2   -3.5581981819095415e-01
    x[34,9]   old_TS3   -3.5581981819095415e-01
    x[34,9]   old_TS4   -2.0032858127086753e-01
    x[34,10]  OBJ       -1.4201174999999998e-02
    x[34,10]  onehot_34  1
    x[34,10]  w_lb_34_10  -2.2258731252318614e-02
    x[34,10]  w_ub_34_10  -3.9535535354550462e-02
    x[34,10]  hard_lower  10
    x[34,10]  hard_upper  10
    x[34,10]  old_TS1   -2.2258731252318614e-01
    x[34,10]  old_TS2   -3.9535535354550461e-01
    x[34,10]  old_TS3   -3.9535535354550461e-01
    x[34,10]  old_TS4   -2.2258731252318614e-01
    x[34,11]  OBJ       -7.1005874999999991e-03
    x[34,11]  onehot_34  1
    x[34,11]  w_lb_34_11  -2.2258731252318614e-02
    x[34,11]  w_ub_34_11  -3.9535535354550462e-02
    x[34,11]  hard_lower  11
    x[34,11]  hard_upper  11
    x[34,11]  old_TS1   -2.4484604377550476e-01
    x[34,11]  old_TS2   -4.3489088890005506e-01
    x[34,11]  old_TS3   -4.3489088890005506e-01
    x[34,11]  old_TS4   -2.4484604377550476e-01
    x[34,12]  onehot_34  1
    x[34,12]  w_lb_34_12  -2.2258731252318614e-02
    x[34,12]  w_ub_34_12  -3.9535535354550462e-02
    x[34,12]  hard_lower  12
    x[34,12]  hard_upper  12
    x[34,12]  old_TS1   -2.6710477502782337e-01
    x[34,12]  old_TS2   -4.7442642425460557e-01
    x[34,12]  old_TS3   -4.7442642425460557e-01
    x[34,12]  old_TS4   -2.6710477502782337e-01
    x[34,13]  OBJ       7.1005874999999991e-03
    x[34,13]  onehot_34  1
    x[34,13]  w_lb_34_13  -2.2258731252318614e-02
    x[34,13]  w_ub_34_13  -3.9535535354550462e-02
    x[34,13]  hard_lower  13
    x[34,13]  hard_upper  13
    x[34,13]  old_TS1   -2.8936350628014196e-01
    x[34,13]  old_TS2   -0.513961959609156
    x[34,13]  old_TS3   -0.513961959609156
    x[34,13]  old_TS4   -2.8936350628014196e-01
    x[34,14]  OBJ       1.4201174999999998e-02
    x[34,14]  onehot_34  1
    x[34,14]  w_lb_34_14  -2.2258731252318614e-02
    x[34,14]  w_ub_34_14  -3.9535535354550462e-02
    x[34,14]  hard_lower  14
    x[34,14]  hard_upper  14
    x[34,14]  old_TS1   -3.1162223753246060e-01
    x[34,14]  old_TS2   -5.5349749496370648e-01
    x[34,14]  old_TS3   -5.5349749496370648e-01
    x[34,14]  old_TS4   -3.1162223753246060e-01
    x[34,15]  OBJ       2.1301762499999995e-02
    x[34,15]  onehot_34  1
    x[34,15]  w_lb_34_15  -2.2258731252318614e-02
    x[34,15]  w_ub_34_15  -3.9535535354550462e-02
    x[34,15]  hard_lower  15
    x[34,15]  hard_upper  15
    x[34,15]  old_TS1   -3.3388096878477924e-01
    x[34,15]  old_TS2   -5.9303303031825694e-01
    x[34,15]  old_TS3   -5.9303303031825694e-01
    x[34,15]  old_TS4   -3.3388096878477924e-01
    x[35,0]   OBJ       3.5946749999999993e-02
    x[35,0]   onehot_35  1
    x[35,0]   w_lb_35_0  -2.2258731252318614e-02
    x[35,0]   w_ub_35_0  -3.9535535354550462e-02
    x[35,1]   OBJ       2.7958583333333328e-02
    x[35,1]   onehot_35  1
    x[35,1]   w_lb_35_1  -2.2258731252318614e-02
    x[35,1]   w_ub_35_1  -3.9535535354550462e-02
    x[35,1]   hard_lower  1
    x[35,1]   hard_upper  1
    x[35,1]   old_TS1   -2.2258731252318614e-02
    x[35,1]   old_TS2   -3.9535535354550462e-02
    x[35,1]   old_TS3   -3.9535535354550462e-02
    x[35,1]   old_TS4   -2.2258731252318614e-02
    x[35,2]   OBJ       1.9970416666666664e-02
    x[35,2]   onehot_35  1
    x[35,2]   w_lb_35_2  -2.2258731252318614e-02
    x[35,2]   w_ub_35_2  -3.9535535354550462e-02
    x[35,2]   hard_lower  2
    x[35,2]   hard_upper  2
    x[35,2]   old_TS1   -4.4517462504637229e-02
    x[35,2]   old_TS2   -7.9071070709100924e-02
    x[35,2]   old_TS3   -7.9071070709100924e-02
    x[35,2]   old_TS4   -4.4517462504637229e-02
    x[35,3]   OBJ       1.1982249999999998e-02
    x[35,3]   onehot_35  1
    x[35,3]   w_lb_35_3  -2.2258731252318614e-02
    x[35,3]   w_ub_35_3  -3.9535535354550462e-02
    x[35,3]   hard_lower  3
    x[35,3]   hard_upper  3
    x[35,3]   old_TS1   -6.6776193756955843e-02
    x[35,3]   old_TS2   -1.1860660606365139e-01
    x[35,3]   old_TS3   -1.1860660606365139e-01
    x[35,3]   old_TS4   -6.6776193756955843e-02
    x[35,4]   OBJ       3.9940833333333330e-03
    x[35,4]   onehot_35  1
    x[35,4]   w_lb_35_4  -2.2258731252318614e-02
    x[35,4]   w_ub_35_4  -3.9535535354550462e-02
    x[35,4]   hard_lower  4
    x[35,4]   hard_upper  4
    x[35,4]   old_TS1   -8.9034925009274457e-02
    x[35,4]   old_TS2   -1.5814214141820185e-01
    x[35,4]   old_TS3   -1.5814214141820185e-01
    x[35,4]   old_TS4   -8.9034925009274457e-02
    x[35,5]   OBJ       -3.9940833333333339e-03
    x[35,5]   onehot_35  1
    x[35,5]   w_lb_35_5  -2.2258731252318614e-02
    x[35,5]   w_ub_35_5  -3.9535535354550462e-02
    x[35,5]   hard_lower  5
    x[35,5]   hard_upper  5
    x[35,5]   old_TS1   -1.1129365626159307e-01
    x[35,5]   old_TS2   -1.9767767677275230e-01
    x[35,5]   old_TS3   -1.9767767677275230e-01
    x[35,5]   old_TS4   -1.1129365626159307e-01
    x[35,6]   OBJ       -0.01198225
    x[35,6]   onehot_35  1
    x[35,6]   w_lb_35_6  -2.2258731252318614e-02
    x[35,6]   w_ub_35_6  -3.9535535354550462e-02
    x[35,6]   hard_lower  6
    x[35,6]   hard_upper  6
    x[35,6]   old_TS1   -1.3355238751391169e-01
    x[35,6]   old_TS2   -2.3721321212730279e-01
    x[35,6]   old_TS3   -2.3721321212730279e-01
    x[35,6]   old_TS4   -1.3355238751391169e-01
    x[35,7]   OBJ       -1.9970416666666668e-02
    x[35,7]   onehot_35  1
    x[35,7]   w_lb_35_7  -2.2258731252318614e-02
    x[35,7]   w_ub_35_7  -3.9535535354550462e-02
    x[35,7]   hard_lower  7
    x[35,7]   hard_upper  7
    x[35,7]   old_TS1   -1.5581111876623030e-01
    x[35,7]   old_TS2   -2.7674874748185324e-01
    x[35,7]   old_TS3   -2.7674874748185324e-01
    x[35,7]   old_TS4   -1.5581111876623030e-01
    x[35,8]   OBJ       -2.7958583333333332e-02
    x[35,8]   onehot_35  1
    x[35,8]   w_lb_35_8  -2.2258731252318614e-02
    x[35,8]   w_ub_35_8  -3.9535535354550462e-02
    x[35,8]   hard_lower  8
    x[35,8]   hard_upper  8
    x[35,8]   old_TS1   -1.7806985001854891e-01
    x[35,8]   old_TS2   -3.1628428283640370e-01
    x[35,8]   old_TS3   -3.1628428283640370e-01
    x[35,8]   old_TS4   -1.7806985001854891e-01
    x[35,9]   OBJ       -0.03594675
    x[35,9]   onehot_35  1
    x[35,9]   w_lb_35_9  -2.2258731252318614e-02
    x[35,9]   w_ub_35_9  -3.9535535354550462e-02
    x[35,9]   hard_lower  9
    x[35,9]   hard_upper  9
    x[35,9]   old_TS1   -2.0032858127086753e-01
    x[35,9]   old_TS2   -3.5581981819095415e-01
    x[35,9]   old_TS3   -3.5581981819095415e-01
    x[35,9]   old_TS4   -2.0032858127086753e-01
    x[35,10]  OBJ       -2.7958583333333342e-02
    x[35,10]  onehot_35  1
    x[35,10]  w_lb_35_10  -2.2258731252318614e-02
    x[35,10]  w_ub_35_10  -3.9535535354550462e-02
    x[35,10]  hard_lower  10
    x[35,10]  hard_upper  10
    x[35,10]  old_TS1   -2.2258731252318614e-01
    x[35,10]  old_TS2   -3.9535535354550461e-01
    x[35,10]  old_TS3   -3.9535535354550461e-01
    x[35,10]  old_TS4   -2.2258731252318614e-01
    x[35,11]  OBJ       -1.9970416666666675e-02
    x[35,11]  onehot_35  1
    x[35,11]  w_lb_35_11  -2.2258731252318614e-02
    x[35,11]  w_ub_35_11  -3.9535535354550462e-02
    x[35,11]  hard_lower  11
    x[35,11]  hard_upper  11
    x[35,11]  old_TS1   -2.4484604377550476e-01
    x[35,11]  old_TS2   -4.3489088890005506e-01
    x[35,11]  old_TS3   -4.3489088890005506e-01
    x[35,11]  old_TS4   -2.4484604377550476e-01
    x[35,12]  OBJ       -1.1982250000000009e-02
    x[35,12]  onehot_35  1
    x[35,12]  w_lb_35_12  -2.2258731252318614e-02
    x[35,12]  w_ub_35_12  -3.9535535354550462e-02
    x[35,12]  hard_lower  12
    x[35,12]  hard_upper  12
    x[35,12]  old_TS1   -2.6710477502782337e-01
    x[35,12]  old_TS2   -4.7442642425460557e-01
    x[35,12]  old_TS3   -4.7442642425460557e-01
    x[35,12]  old_TS4   -2.6710477502782337e-01
    x[35,13]  OBJ       -3.9940833333333417e-03
    x[35,13]  onehot_35  1
    x[35,13]  w_lb_35_13  -2.2258731252318614e-02
    x[35,13]  w_ub_35_13  -3.9535535354550462e-02
    x[35,13]  hard_lower  13
    x[35,13]  hard_upper  13
    x[35,13]  old_TS1   -2.8936350628014196e-01
    x[35,13]  old_TS2   -0.513961959609156
    x[35,13]  old_TS3   -0.513961959609156
    x[35,13]  old_TS4   -2.8936350628014196e-01
    x[35,14]  OBJ       3.9940833333333243e-03
    x[35,14]  onehot_35  1
    x[35,14]  w_lb_35_14  -2.2258731252318614e-02
    x[35,14]  w_ub_35_14  -3.9535535354550462e-02
    x[35,14]  hard_lower  14
    x[35,14]  hard_upper  14
    x[35,14]  old_TS1   -3.1162223753246060e-01
    x[35,14]  old_TS2   -5.5349749496370648e-01
    x[35,14]  old_TS3   -5.5349749496370648e-01
    x[35,14]  old_TS4   -3.1162223753246060e-01
    x[35,15]  OBJ       1.1982249999999991e-02
    x[35,15]  onehot_35  1
    x[35,15]  w_lb_35_15  -2.2258731252318614e-02
    x[35,15]  w_ub_35_15  -3.9535535354550462e-02
    x[35,15]  hard_lower  15
    x[35,15]  hard_upper  15
    x[35,15]  old_TS1   -3.3388096878477924e-01
    x[35,15]  old_TS2   -5.9303303031825694e-01
    x[35,15]  old_TS3   -5.9303303031825694e-01
    x[35,15]  old_TS4   -3.3388096878477924e-01
    x[35,16]  OBJ       1.9970416666666657e-02
    x[35,16]  onehot_35  1
    x[35,16]  w_lb_35_16  -2.2258731252318614e-02
    x[35,16]  w_ub_35_16  -3.9535535354550462e-02
    x[35,16]  hard_lower  16
    x[35,16]  hard_upper  16
    x[35,16]  old_TS1   -3.5613970003709783e-01
    x[35,16]  old_TS2   -6.3256856567280739e-01
    x[35,16]  old_TS3   -6.3256856567280739e-01
    x[35,16]  old_TS4   -3.5613970003709783e-01
    x[35,17]  OBJ       2.7958583333333321e-02
    x[35,17]  onehot_35  1
    x[35,17]  w_lb_35_17  -2.2258731252318614e-02
    x[35,17]  w_ub_35_17  -3.9535535354550462e-02
    x[35,17]  hard_lower  17
    x[35,17]  hard_upper  17
    x[35,17]  old_TS1   -3.7839843128941641e-01
    x[35,17]  old_TS2   -6.7210410102735785e-01
    x[35,17]  old_TS3   -6.7210410102735785e-01
    x[35,17]  old_TS4   -3.7839843128941641e-01
    MARKER    'MARKER'                 'INTEND'
    w[1,4]    mass_1    1
    w[1,4]    w_lb_1_4  1
    w[1,4]    w_ub_1_4  1
    w[1,4]    normalized_inventory_1  -4
    w[1,4]    old_normalized_TC  -5.5555555555555580e-02
    w[1,4]    old_normalized_TC2  6.6210317460317460e+00
    w[2,0]    mass_2    1
    w[2,0]    w_lb_2_0  1
    w[2,0]    w_ub_2_0  1
    w[2,1]    mass_2    1
    w[2,1]    w_lb_2_1  1
    w[2,1]    w_ub_2_1  1
    w[2,1]    normalized_inventory_2  -1
    w[2,1]    old_normalized_TC2  1.25
    w[2,2]    mass_2    1
    w[2,2]    w_lb_2_2  1
    w[2,2]    w_ub_2_2  1
    w[2,2]    normalized_inventory_2  -2
    w[2,2]    old_normalized_TC2  2.4761904761904763e+00
    w[2,3]    mass_2    1
    w[2,3]    w_lb_2_3  1
    w[2,3]    w_ub_2_3  1
    w[2,3]    normalized_inventory_2  -3
    w[2,3]    old_normalized_TC2  3.6428571428571428e+00
    w[2,4]    mass_2    1
    w[2,4]    w_lb_2_4  1
    w[2,4]    w_ub_2_4  1
    w[2,4]    normalized_inventory_2  -4
    w[2,4]    old_normalized_TC2  4.7619047619047619e+00
    w[2,5]    mass_2    1
    w[2,5]    w_lb_2_5  1
    w[2,5]    w_ub_2_5  1
    w[2,5]    normalized_inventory_2  -5
    w[2,5]    old_normalized_TC2  5.8035714285714288e+00
    w[2,6]    mass_2    1
    w[2,6]    w_lb_2_6  1
    w[2,6]    w_ub_2_6  1
    w[2,6]    normalized_inventory_2  -6
    w[2,6]    old_normalized_TC  -5.5555555555555552e-02
    w[2,6]    old_normalized_TC2  6.6210317460317460e+00
    w[2,7]    mass_2    1
    w[2,7]    w_lb_2_7  1
    w[2,7]    w_ub_2_7  1
    w[2,7]    normalized_inventory_2  -7
    w[2,7]    old_normalized_TC  -2.2222222222222218e-01
    w[2,7]    old_normalized_TC2  7.1210317460317460e+00
    w[2,8]    mass_2    1
    w[2,8]    w_lb_2_8  1
    w[2,8]    w_ub_2_8  1
    w[2,8]    normalized_inventory_2  -8
    w[2,8]    old_normalized_TC  -3.8888888888888884e-01
    w[2,8]    old_normalized_TC2  7.55436507936508
    w[2,9]    mass_2    1
    w[2,9]    w_lb_2_9  1
    w[2,9]    w_ub_2_9  1
    w[2,9]    normalized_inventory_2  -9
    w[2,9]    old_normalized_TC  -5.5555555555555547e-01
    w[2,9]    old_normalized_TC2  7.8519841269841271e+00
    w[2,10]   mass_2    1
    w[2,10]   w_lb_2_10  1
    w[2,10]   w_ub_2_10  1
    w[2,10]   normalized_inventory_2  -10
    w[2,10]   old_normalized_TC  -7.2222222222222210e-01
    w[2,10]   old_normalized_TC2  8.0464285714285726e+00
    w[2,11]   mass_2    1
    w[2,11]   w_lb_2_11  1
    w[2,11]   w_ub_2_11  1
    w[2,11]   normalized_inventory_2  -11
    w[2,11]   old_normalized_TC  -8.8888888888888873e-01
    w[2,11]   old_normalized_TC2  8.1119047619047624e+00
    w[2,12]   mass_2    1
    w[2,12]   w_lb_2_12  1
    w[2,12]   w_ub_2_12  1
    w[2,12]   normalized_inventory_2  -12
    w[2,12]   old_normalized_TC  -1.0555555555555554e+00
    w[2,12]   old_normalized_TC2  8.1119047619047624e+00
    w[2,13]   mass_2    1
    w[2,13]   w_lb_2_13  1
    w[2,13]   w_ub_2_13  1
    w[2,13]   normalized_inventory_2  -13
    w[2,13]   old_normalized_TC  -1.2286324786324783e+00
    w[2,13]   old_normalized_TC2  8.1054945054945069e+00
    w[2,14]   mass_2    1
    w[2,14]   w_lb_2_14  1
    w[2,14]   w_ub_2_14  1
    w[2,14]   normalized_inventory_2  -14
    w[2,14]   old_normalized_TC  -1.5202991452991450e+00
    w[2,14]   old_normalized_TC2  7.9804945054945060e+00
    w[2,15]   mass_2    1
    w[2,15]   w_lb_2_15  1
    w[2,15]   w_ub_2_15  1
    w[2,15]   normalized_inventory_2  -15
    w[2,15]   old_normalized_TC  -1.9218142968142964e+00
    w[2,15]   old_normalized_TC2  7.7456460206460216e+00
    w[2,16]   mass_2    1
    w[2,16]   w_lb_2_16  1
    w[2,16]   w_ub_2_16  1
    w[2,16]   normalized_inventory_2  -16
    w[2,16]   old_normalized_TC  -2.4694333444333436e+00
    w[2,16]   old_normalized_TC2  7.36469363969364
    w[2,17]   mass_2    1
    w[2,17]   w_lb_2_17  1
    w[2,17]   w_ub_2_17  1
    w[2,17]   normalized_inventory_2  -17
    w[2,17]   old_normalized_TC  -3.0944333444333436e+00
    w[2,17]   old_normalized_TC2  6.9063603063603072e+00
    w[2,18]   mass_2    1
    w[2,18]   w_lb_2_18  1
    w[2,18]   w_ub_2_18  1
    w[2,18]   normalized_inventory_2  -18
    w[2,18]   old_normalized_TC  -3.8325285825285818e+00
    w[2,18]   old_normalized_TC2  6.3349317349317360e+00
    w[2,19]   mass_2    1
    w[2,19]   w_lb_2_19  1
    w[2,19]   w_ub_2_19  1
    w[2,19]   normalized_inventory_2  -19
    w[2,19]   old_normalized_TC  -4.6658619158619148e+00
    w[2,19]   old_normalized_TC2  5.6682650682650690e+00
    w[2,20]   mass_2    1
    w[2,20]   w_lb_2_20  1
    w[2,20]   w_ub_2_20  1
    w[2,20]   normalized_inventory_2  -20
    w[2,20]   old_normalized_TC  -5.5408619158619148e+00
    w[2,20]   old_normalized_TC2  4.9599317349317360e+00
    w[2,21]   mass_2    1
    w[2,21]   w_lb_2_21  1
    w[2,21]   w_ub_2_21  1
    w[2,21]   normalized_inventory_2  -21
    w[2,21]   old_normalized_TC  -6.4932428682428665e+00
    w[2,21]   old_normalized_TC2  4.17421744921745
    w[2,22]   mass_2    1
    w[2,22]   w_lb_2_22  1
    w[2,22]   w_ub_2_22  1
    w[2,22]   normalized_inventory_2  -22
    w[2,22]   old_normalized_TC  -7.5487984237984218e+00
    w[2,22]   old_normalized_TC2  3.2297730047730058e+00
    w[2,23]   mass_2    1
    w[2,23]   w_lb_2_23  1
    w[2,23]   w_ub_2_23  1
    w[2,23]   normalized_inventory_2  -23
    w[2,23]   old_normalized_TC  -8.8944333444333417e+00
    w[2,23]   old_normalized_TC2  1.9079476079476096e+00
    w[3,13]   mass_3    1
    w[3,13]   w_lb_3_13  1
    w[3,13]   w_ub_3_13  1
    w[3,13]   normalized_inventory_3  -13
    w[3,13]   old_normalized_TC  -7.8821317571317557e+00
    w[3,13]   old_normalized_TC2  2.9202491952491960e+00
    w[4,0]    mass_4    1
    w[4,0]    w_lb_4_0  1
    w[4,0]    w_ub_4_0  1
    w[4,1]    mass_4    1
    w[4,1]    w_lb_4_1  1
    w[4,1]    w_ub_4_1  1
    w[4,1]    normalized_inventory_4  -1
    w[4,1]    old_normalized_TC2  2.1428571428571428e+00
    w[4,2]    mass_4    1
    w[4,2]    w_lb_4_2  1
    w[4,2]    w_ub_4_2  1
    w[4,2]    normalized_inventory_4  -2
    w[4,2]    old_normalized_TC2  4.1428571428571432e+00
    w[4,3]    mass_4    1
    w[4,3]    w_lb_4_3  1
    w[4,3]    w_ub_4_3  1
    w[4,3]    normalized_inventory_4  -3
    w[4,3]    old_normalized_TC2  5.9464285714285712e+00
    w[4,4]    mass_4    1
    w[4,4]    w_lb_4_4  1
    w[4,4]    w_ub_4_4  1
    w[4,4]    normalized_inventory_4  -4
    w[4,4]    old_normalized_TC  -1.9841269841269837e-01
    w[4,4]    old_normalized_TC2  7.0496031746031749e+00
    w[4,5]    mass_4    1
    w[4,5]    w_lb_4_5  1
    w[4,5]    w_ub_4_5  1
    w[4,5]    normalized_inventory_4  -5
    w[4,5]    old_normalized_TC  -4.8412698412698407e-01
    w[4,5]    old_normalized_TC2  7.74484126984127
    w[4,6]    mass_4    1
    w[4,6]    w_lb_4_6  1
    w[4,6]    w_ub_4_6  1
    w[4,6]    normalized_inventory_4  -6
    w[4,6]    old_normalized_TC  -7.6984126984126977e-01
    w[4,6]    old_normalized_TC2  8.09404761904762
    w[4,7]    mass_4    1
    w[4,7]    w_lb_4_7  1
    w[4,7]    w_ub_4_7  1
    w[4,7]    normalized_inventory_4  -7
    w[4,7]    old_normalized_TC  -1.0555555555555554e+00
    w[4,7]    old_normalized_TC2  8.1119047619047624e+00
    w[4,8]    mass_4    1
    w[4,8]    w_lb_4_8  1
    w[4,8]    w_ub_4_8  1
    w[4,8]    normalized_inventory_4  -8
    w[4,8]    old_normalized_TC  -1.4250610500610497e+00
    w[4,8]    old_normalized_TC2  8.0281135531135543e+00
    w[4,9]    mass_4    1
    w[4,9]    w_lb_4_9  1
    w[4,9]    w_ub_4_9  1
    w[4,9]    normalized_inventory_4  -9
    w[4,9]    old_normalized_TC  -2.1361000111000106e+00
    w[4,9]    old_normalized_TC2  7.6027888777888784e+00
    w[4,10]   mass_4    1
    w[4,10]   w_lb_4_10  1
    w[4,10]   w_ub_4_10  1
    w[4,10]   normalized_inventory_4  -10
    w[4,10]   old_normalized_TC  -3.1896714396714390e+00
    w[4,10]   old_normalized_TC2  6.8349317349317360e+00
    w[4,11]   mass_4    1
    w[4,11]   w_lb_4_11  1
    w[4,11]   w_ub_4_11  1
    w[4,11]   normalized_inventory_4  -11
    w[4,11]   old_normalized_TC  -4.5468142968142953e+00
    w[4,11]   old_normalized_TC2  5.7635031635031648e+00
    w[4,12]   mass_4    1
    w[4,12]   w_lb_4_12  1
    w[4,12]   w_ub_4_12  1
    w[4,12]   normalized_inventory_4  -12
    w[4,12]   old_normalized_TC  -6.0646714396714385e+00
    w[4,12]   old_normalized_TC2  4.5313603063603072e+00
    w[4,13]   mass_4    1
    w[4,13]   w_lb_4_13  1
    w[4,13]   w_ub_4_13  1
    w[4,13]   normalized_inventory_4  -13
    w[4,13]   old_normalized_TC  -7.8821317571317557e+00
    w[4,13]   old_normalized_TC2  2.9202491952491960e+00
    w[4,14]   mass_4    1
    w[4,14]   w_lb_4_14  1
    w[4,14]   w_ub_4_14  1
    w[4,14]   normalized_inventory_4  -14
    w[4,14]   old_normalized_TC  -1.0644433344433342e+01
    w[4,14]   old_normalized_TC2  1.5794760794760962e-01
    w[4,15]   mass_4    1
    w[4,15]   w_lb_4_15  1
    w[4,15]   w_ub_4_15  1
    w[4,15]   normalized_inventory_4  -15
    w[4,15]   old_normalized_TC  -1.3882528582528579e+01
    w[4,15]   old_normalized_TC2  -3.0801476301476280e+00
    w[5,0]    mass_5    1
    w[5,0]    w_lb_5_0  1
    w[5,0]    w_ub_5_0  1
    w[5,1]    mass_5    1
    w[5,1]    w_lb_5_1  1
    w[5,1]    w_ub_5_1  1
    w[5,1]    normalized_inventory_5  -1
    w[5,1]    old_normalized_TC2  1.875
    w[5,2]    mass_5    1
    w[5,2]    w_lb_5_2  1
    w[5,2]    w_ub_5_2  1
    w[5,2]    normalized_inventory_5  -2
    w[5,2]    old_normalized_TC2  3.6428571428571432e+00
    w[5,3]    mass_5    1
    w[5,3]    w_lb_5_3  1
    w[5,3]    w_ub_5_3  1
    w[5,3]    normalized_inventory_5  -3
    w[5,3]    old_normalized_TC2  5.3035714285714288e+00
    w[5,4]    mass_5    1
    w[5,4]    w_lb_5_4  1
    w[5,4]    w_ub_5_4  1
    w[5,4]    normalized_inventory_5  -4
    w[5,4]    old_normalized_TC  -5.5555555555555580e-02
    w[5,4]    old_normalized_TC2  6.6210317460317460e+00
    w[5,5]    mass_5    1
    w[5,5]    w_lb_5_5  1
    w[5,5]    w_ub_5_5  1
    w[5,5]    normalized_inventory_5  -5
    w[5,5]    old_normalized_TC  -3.0555555555555558e-01
    w[5,5]    old_normalized_TC2  7.3460317460317466e+00
    w[5,6]    mass_5    1
    w[5,6]    w_lb_5_6  1
    w[5,6]    w_ub_5_6  1
    w[5,6]    normalized_inventory_5  -6
    w[5,6]    old_normalized_TC  -5.5555555555555558e-01
    w[5,6]    old_normalized_TC2  7.8519841269841271e+00
    w[5,7]    mass_5    1
    w[5,7]    w_lb_5_7  1
    w[5,7]    w_ub_5_7  1
    w[5,7]    normalized_inventory_5  -7
    w[5,7]    old_normalized_TC  -8.0555555555555558e-01
    w[5,7]    old_normalized_TC2  8.1119047619047624e+00
    w[5,8]    mass_5    1
    w[5,8]    w_lb_5_8  1
    w[5,8]    w_ub_5_8  1
    w[5,8]    normalized_inventory_5  -8
    w[5,8]    old_normalized_TC  -1.0555555555555556e+00
    w[5,8]    old_normalized_TC2  8.1119047619047624e+00
    w[5,9]    mass_5    1
    w[5,9]    w_lb_5_9  1
    w[5,9]    w_ub_5_9  1
    w[5,9]    normalized_inventory_5  -9
    w[5,9]    old_normalized_TC  -1.3536324786324785e+00
    w[5,9]    old_normalized_TC2  8.0638278388278390e+00
    w[5,10]   mass_5    1
    w[5,10]   w_lb_5_10  1
    w[5,10]   w_ub_5_10  1
    w[5,10]   normalized_inventory_5  -10
    w[5,10]   old_normalized_TC  -1.9218142968142966e+00
    w[5,10]   old_normalized_TC2  7.7456460206460207e+00
    w[5,11]   mass_5    1
    w[5,11]   w_lb_5_11  1
    w[5,11]   w_ub_5_11  1
    w[5,11]   normalized_inventory_5  -11
    w[5,11]   old_normalized_TC  -2.7611000111000110e+00
    w[5,11]   old_normalized_TC2  7.1563603063603063e+00
    w[5,12]   mass_5    1
    w[5,12]   w_lb_5_12  1
    w[5,12]   w_ub_5_12  1
    w[5,12]   normalized_inventory_5  -12
    w[5,12]   old_normalized_TC  -3.8325285825285822e+00
    w[5,12]   old_normalized_TC2  6.3349317349317351e+00
    w[5,13]   mass_5    1
    w[5,13]   w_lb_5_13  1
    w[5,13]   w_ub_5_13  1
    w[5,13]   normalized_inventory_5  -13
    w[5,13]   old_normalized_TC  -5.0825285825285818e+00
    w[5,13]   old_normalized_TC2  5.3349317349317351e+00
    w[5,14]   mass_5    1
    w[5,14]   w_lb_5_14  1
    w[5,14]   w_ub_5_14  1
    w[5,14]   normalized_inventory_5  -14
    w[5,14]   old_normalized_TC  -6.4932428682428682e+00
    w[5,14]   old_normalized_TC2  4.1742174492174495e+00
    w[5,15]   mass_5    1
    w[5,15]   w_lb_5_15  1
    w[5,15]   w_ub_5_15  1
    w[5,15]   normalized_inventory_5  -15
    w[5,15]   old_normalized_TC  -8.1499888999889
    w[5,15]   old_normalized_TC2  2.6523920523920519e+00
    w[6,4]    mass_6    1
    w[6,4]    w_lb_6_4  1
    w[6,4]    w_ub_6_4  1
    w[6,4]    normalized_inventory_6  -4
    w[6,4]    old_normalized_TC2  6.1210317460317460e+00
    w[7,0]    mass_7    1
    w[7,0]    w_lb_7_0  1
    w[7,0]    w_ub_7_0  1
    w[7,1]    mass_7    1
    w[7,1]    w_lb_7_1  1
    w[7,1]    w_ub_7_1  1
    w[7,1]    normalized_inventory_7  -1
    w[7,1]    old_normalized_TC2  1.5000000000000002e+00
    w[7,2]    mass_7    1
    w[7,2]    w_lb_7_2  1
    w[7,2]    w_ub_7_2  1
    w[7,2]    normalized_inventory_7  -2
    w[7,2]    old_normalized_TC2  2.9428571428571431e+00
    w[7,3]    mass_7    1
    w[7,3]    w_lb_7_3  1
    w[7,3]    w_ub_7_3  1
    w[7,3]    normalized_inventory_7  -3
    w[7,3]    old_normalized_TC2  4.3285714285714292e+00
    w[7,4]    mass_7    1
    w[7,4]    w_lb_7_4  1
    w[7,4]    w_ub_7_4  1
    w[7,4]    normalized_inventory_7  -4
    w[7,4]    old_normalized_TC2  5.6035714285714295e+00
    w[7,5]    mass_7    1
    w[7,5]    w_lb_7_5  1
    w[7,5]    w_ub_7_5  1
    w[7,5]    normalized_inventory_7  -5
    w[7,5]    old_normalized_TC  -5.5555555555555636e-02
    w[7,5]    old_normalized_TC2  6.6210317460317469e+00
    w[7,6]    mass_7    1
    w[7,6]    w_lb_7_6  1
    w[7,6]    w_ub_7_6  1
    w[7,6]    normalized_inventory_7  -6
    w[7,6]    old_normalized_TC  -2.5555555555555565e-01
    w[7,6]    old_normalized_TC2  7.2210317460317466e+00
    w[7,7]    mass_7    1
    w[7,7]    w_lb_7_7  1
    w[7,7]    w_ub_7_7  1
    w[7,7]    normalized_inventory_7  -7
    w[7,7]    old_normalized_TC  -4.5555555555555566e-01
    w[7,7]    old_normalized_TC2  7.6876984126984134e+00
    w[7,8]    mass_7    1
    w[7,8]    w_lb_7_8  1
    w[7,8]    w_ub_7_8  1
    w[7,8]    normalized_inventory_7  -8
    w[7,8]    old_normalized_TC  -6.5555555555555567e-01
    w[7,8]    old_normalized_TC2  7.9797619047619053e+00
    w[7,9]    mass_7    1
    w[7,9]    w_lb_7_9  1
    w[7,9]    w_ub_7_9  1
    w[7,9]    normalized_inventory_7  -9
    w[7,9]    old_normalized_TC  -8.5555555555555562e-01
    w[7,9]    old_normalized_TC2  8.1119047619047624e+00
    w[7,10]   mass_7    1
    w[7,10]   w_lb_7_10  1
    w[7,10]   w_ub_7_10  1
    w[7,10]   normalized_inventory_7  -10
    w[7,10]   old_normalized_TC  -1.0555555555555556e+00
    w[7,10]   old_normalized_TC2  8.1119047619047624e+00
    w[7,11]   mass_7    1
    w[7,11]   w_lb_7_11  1
    w[7,11]   w_ub_7_11  1
    w[7,11]   normalized_inventory_7  -11
    w[7,11]   old_normalized_TC  -1.2786324786324788e+00
    w[7,11]   old_normalized_TC2  8.08882783882784
    w[7,12]   mass_7    1
    w[7,12]   w_lb_7_12  1
    w[7,12]   w_ub_7_12  1
    w[7,12]   normalized_inventory_7  -12
    w[7,12]   old_normalized_TC  -1.6718142968142971e+00
    w[7,12]   old_normalized_TC2  7.8956460206460211e+00
    w[7,13]   mass_7    1
    w[7,13]   w_lb_7_13  1
    w[7,13]   w_ub_7_13  1
    w[7,13]   normalized_inventory_7  -13
    w[7,13]   old_normalized_TC  -2.2361000111000116e+00
    w[7,13]   old_normalized_TC2  7.5313603063603063e+00
    w[7,14]   mass_7    1
    w[7,14]   w_lb_7_14  1
    w[7,14]   w_ub_7_14  1
    w[7,14]   normalized_inventory_7  -14
    w[7,14]   old_normalized_TC  -2.9611000111000116e+00
    w[7,14]   old_normalized_TC2  7.0063603063603059e+00
    w[7,15]   mass_7    1
    w[7,15]   w_lb_7_15  1
    w[7,15]   w_ub_7_15  1
    w[7,15]   normalized_inventory_7  -15
    w[7,15]   old_normalized_TC  -3.8325285825285831e+00
    w[7,15]   old_normalized_TC2  6.3349317349317342e+00
    w[7,16]   mass_7    1
    w[7,16]   w_lb_7_16  1
    w[7,16]   w_ub_7_16  1
    w[7,16]   normalized_inventory_7  -16
    w[7,16]   old_normalized_TC  -4.8325285825285826e+00
    w[7,16]   old_normalized_TC2  5.5349317349317344e+00
    w[7,17]   mass_7    1
    w[7,17]   w_lb_7_17  1
    w[7,17]   w_ub_7_17  1
    w[7,17]   normalized_inventory_7  -17
    w[7,17]   old_normalized_TC  -5.9075285825285828e+00
    w[7,17]   old_normalized_TC2  4.6599317349317344e+00
    w[7,18]   mass_7    1
    w[7,18]   w_lb_7_18  1
    w[7,18]   w_ub_7_18  1
    w[7,18]   normalized_inventory_7  -18
    w[7,18]   old_normalized_TC  -7.1154650904650918e+00
    w[7,18]   old_normalized_TC2  3.6297730047730035e+00
    w[7,19]   mass_7    1
    w[7,19]   w_lb_7_19  1
    w[7,19]   w_ub_7_19  1
    w[7,19]   normalized_inventory_7  -19
    w[7,19]   old_normalized_TC  -8.5611000111000131e+00
    w[7,19]   old_normalized_TC2  2.2412809412809387e+00
    w[8,0]    mass_8    1
    w[8,0]    w_lb_8_0  1
    w[8,0]    w_ub_8_0  1
    w[8,1]    mass_8    1
    w[8,1]    w_lb_8_1  1
    w[8,1]    w_ub_8_1  1
    w[8,1]    normalized_inventory_8  -1
    w[8,1]    old_normalized_TC2  2.1428571428571428e+00
    w[8,2]    mass_8    1
    w[8,2]    w_lb_8_2  1
    w[8,2]    w_ub_8_2  1
    w[8,2]    normalized_inventory_8  -2
    w[8,2]    old_normalized_TC2  4.1428571428571432e+00
    w[8,3]    mass_8    1
    w[8,3]    w_lb_8_3  1
    w[8,3]    w_ub_8_3  1
    w[8,3]    normalized_inventory_8  -3
    w[8,3]    old_normalized_TC2  5.9464285714285712e+00
    w[8,4]    mass_8    1
    w[8,4]    w_lb_8_4  1
    w[8,4]    w_ub_8_4  1
    w[8,4]    normalized_inventory_8  -4
    w[8,4]    old_normalized_TC  -1.9841269841269837e-01
    w[8,4]    old_normalized_TC2  7.0496031746031749e+00
    w[8,5]    mass_8    1
    w[8,5]    w_lb_8_5  1
    w[8,5]    w_ub_8_5  1
    w[8,5]    normalized_inventory_8  -5
    w[8,5]    old_normalized_TC  -4.8412698412698407e-01
    w[8,5]    old_normalized_TC2  7.74484126984127
    w[8,6]    mass_8    1
    w[8,6]    w_lb_8_6  1
    w[8,6]    w_ub_8_6  1
    w[8,6]    normalized_inventory_8  -6
    w[8,6]    old_normalized_TC  -7.6984126984126977e-01
    w[8,6]    old_normalized_TC2  8.09404761904762
    w[8,7]    mass_8    1
    w[8,7]    w_lb_8_7  1
    w[8,7]    w_ub_8_7  1
    w[8,7]    normalized_inventory_8  -7
    w[8,7]    old_normalized_TC  -1.0555555555555554e+00
    w[8,7]    old_normalized_TC2  8.1119047619047624e+00
    w[8,8]    mass_8    1
    w[8,8]    w_lb_8_8  1
    w[8,8]    w_ub_8_8  1
    w[8,8]    normalized_inventory_8  -8
    w[8,8]    old_normalized_TC  -1.4250610500610497e+00
    w[8,8]    old_normalized_TC2  8.0281135531135543e+00
    w[8,9]    mass_8    1
    w[8,9]    w_lb_8_9  1
    w[8,9]    w_ub_8_9  1
    w[8,9]    normalized_inventory_8  -9
    w[8,9]    old_normalized_TC  -2.1361000111000106e+00
    w[8,9]    old_normalized_TC2  7.6027888777888784e+00
    w[8,10]   mass_8    1
    w[8,10]   w_lb_8_10  1
    w[8,10]   w_ub_8_10  1
    w[8,10]   normalized_inventory_8  -10
    w[8,10]   old_normalized_TC  -3.1896714396714390e+00
    w[8,10]   old_normalized_TC2  6.8349317349317360e+00
    w[8,11]   mass_8    1
    w[8,11]   w_lb_8_11  1
    w[8,11]   w_ub_8_11  1
    w[8,11]   normalized_inventory_8  -11
    w[8,11]   old_normalized_TC  -4.5468142968142953e+00
    w[8,11]   old_normalized_TC2  5.7635031635031648e+00
    w[8,12]   mass_8    1
    w[8,12]   w_lb_8_12  1
    w[8,12]   w_ub_8_12  1
    w[8,12]   normalized_inventory_8  -12
    w[8,12]   old_normalized_TC  -6.0646714396714385e+00
    w[8,12]   old_normalized_TC2  4.5313603063603072e+00
    w[8,13]   mass_8    1
    w[8,13]   w_lb_8_13  1
    w[8,13]   w_ub_8_13  1
    w[8,13]   normalized_inventory_8  -13
    w[8,13]   old_normalized_TC  -7.8821317571317557e+00
    w[8,13]   old_normalized_TC2  2.9202491952491960e+00
    w[8,14]   mass_8    1
    w[8,14]   w_lb_8_14  1
    w[8,14]   w_ub_8_14  1
    w[8,14]   normalized_inventory_8  -14
    w[8,14]   old_normalized_TC  -1.0644433344433342e+01
    w[8,14]   old_normalized_TC2  1.5794760794760962e-01
    w[8,15]   mass_8    1
    w[8,15]   w_lb_8_15  1
    w[8,15]   w_ub_8_15  1
    w[8,15]   normalized_inventory_8  -15
    w[8,15]   old_normalized_TC  -1.3882528582528579e+01
    w[8,15]   old_normalized_TC2  -3.0801476301476280e+00
    w[9,0]    mass_9    1
    w[9,0]    w_lb_9_0  1
    w[9,0]    w_ub_9_0  1
    w[9,1]    mass_9    1
    w[9,1]    w_lb_9_1  1
    w[9,1]    w_ub_9_1  1
    w[9,1]    normalized_inventory_9  -1
    w[9,1]    old_normalized_TC2  1.5000000000000002e+00
    w[9,2]    mass_9    1
    w[9,2]    w_lb_9_2  1
    w[9,2]    w_ub_9_2  1
    w[9,2]    normalized_inventory_9  -2
    w[9,2]    old_normalized_TC2  2.9428571428571431e+00
    w[9,3]    mass_9    1
    w[9,3]    w_lb_9_3  1
    w[9,3]    w_ub_9_3  1
    w[9,3]    normalized_inventory_9  -3
    w[9,3]    old_normalized_TC2  4.3285714285714292e+00
    w[9,4]    mass_9    1
    w[9,4]    w_lb_9_4  1
    w[9,4]    w_ub_9_4  1
    w[9,4]    normalized_inventory_9  -4
    w[9,4]    old_normalized_TC2  5.6035714285714295e+00
    w[9,5]    mass_9    1
    w[9,5]    w_lb_9_5  1
    w[9,5]    w_ub_9_5  1
    w[9,5]    normalized_inventory_9  -5
    w[9,5]    old_normalized_TC  -5.5555555555555636e-02
    w[9,5]    old_normalized_TC2  6.6210317460317469e+00
    w[9,6]    mass_9    1
    w[9,6]    w_lb_9_6  1
    w[9,6]    w_ub_9_6  1
    w[9,6]    normalized_inventory_9  -6
    w[9,6]    old_normalized_TC  -2.5555555555555565e-01
    w[9,6]    old_normalized_TC2  7.2210317460317466e+00
    w[9,7]    mass_9    1
    w[9,7]    w_lb_9_7  1
    w[9,7]    w_ub_9_7  1
    w[9,7]    normalized_inventory_9  -7
    w[9,7]    old_normalized_TC  -4.5555555555555566e-01
    w[9,7]    old_normalized_TC2  7.6876984126984134e+00
    w[9,8]    mass_9    1
    w[9,8]    w_lb_9_8  1
    w[9,8]    w_ub_9_8  1
    w[9,8]    normalized_inventory_9  -8
    w[9,8]    old_normalized_TC  -6.5555555555555567e-01
    w[9,8]    old_normalized_TC2  7.9797619047619053e+00
    w[9,9]    mass_9    1
    w[9,9]    w_lb_9_9  1
    w[9,9]    w_ub_9_9  1
    w[9,9]    normalized_inventory_9  -9
    w[9,9]    old_normalized_TC  -8.5555555555555562e-01
    w[9,9]    old_normalized_TC2  8.1119047619047624e+00
    w[9,10]   mass_9    1
    w[9,10]   w_lb_9_10  1
    w[9,10]   w_ub_9_10  1
    w[9,10]   normalized_inventory_9  -10
    w[9,10]   old_normalized_TC  -1.0555555555555556e+00
    w[9,10]   old_normalized_TC2  8.1119047619047624e+00
    w[9,11]   mass_9    1
    w[9,11]   w_lb_9_11  1
    w[9,11]   w_ub_9_11  1
    w[9,11]   normalized_inventory_9  -11
    w[9,11]   old_normalized_TC  -1.2786324786324788e+00
    w[9,11]   old_normalized_TC2  8.08882783882784
    w[9,12]   mass_9    1
    w[9,12]   w_lb_9_12  1
    w[9,12]   w_ub_9_12  1
    w[9,12]   normalized_inventory_9  -12
    w[9,12]   old_normalized_TC  -1.6718142968142971e+00
    w[9,12]   old_normalized_TC2  7.8956460206460211e+00
    w[9,13]   mass_9    1
    w[9,13]   w_lb_9_13  1
    w[9,13]   w_ub_9_13  1
    w[9,13]   normalized_inventory_9  -13
    w[9,13]   old_normalized_TC  -2.2361000111000116e+00
    w[9,13]   old_normalized_TC2  7.5313603063603063e+00
    w[9,14]   mass_9    1
    w[9,14]   w_lb_9_14  1
    w[9,14]   w_ub_9_14  1
    w[9,14]   normalized_inventory_9  -14
    w[9,14]   old_normalized_TC  -2.9611000111000116e+00
    w[9,14]   old_normalized_TC2  7.0063603063603059e+00
    w[10,0]   mass_10   1
    w[10,0]   w_lb_10_0  1
    w[10,0]   w_ub_10_0  1
    w[10,1]   mass_10   1
    w[10,1]   w_lb_10_1  1
    w[10,1]   w_ub_10_1  1
    w[10,1]   normalized_inventory_10  -1
    w[10,1]   old_normalized_TC2  2.4761904761904763e+00
    w[10,2]   mass_10   1
    w[10,2]   w_lb_10_2  1
    w[10,2]   w_ub_10_2  1
    w[10,2]   normalized_inventory_10  -2
    w[10,2]   old_normalized_TC2  4.7619047619047619e+00
    w[10,3]   mass_10   1
    w[10,3]   w_lb_10_3  1
    w[10,3]   w_ub_10_3  1
    w[10,3]   normalized_inventory_10  -3
    w[10,3]   old_normalized_TC  -5.5555555555555552e-02
    w[10,3]   old_normalized_TC2  6.6210317460317460e+00
    w[10,4]   mass_10   1
    w[10,4]   w_lb_10_4  1
    w[10,4]   w_ub_10_4  1
    w[10,4]   normalized_inventory_10  -4
    w[10,4]   old_normalized_TC  -3.8888888888888884e-01
    w[10,4]   old_normalized_TC2  7.55436507936508
    w[10,5]   mass_10   1
    w[10,5]   w_lb_10_5  1
    w[10,5]   w_ub_10_5  1
    w[10,5]   normalized_inventory_10  -5
    w[10,5]   old_normalized_TC  -7.2222222222222210e-01
    w[10,5]   old_normalized_TC2  8.0464285714285726e+00
    w[10,6]   mass_10   1
    w[10,6]   w_lb_10_6  1
    w[10,6]   w_ub_10_6  1
    w[10,6]   normalized_inventory_10  -6
    w[10,6]   old_normalized_TC  -1.0555555555555554e+00
    w[10,6]   old_normalized_TC2  8.1119047619047624e+00
    w[10,7]   mass_10   1
    w[10,7]   w_lb_10_7  1
    w[10,7]   w_ub_10_7  1
    w[10,7]   normalized_inventory_10  -7
    w[10,7]   old_normalized_TC  -1.5202991452991450e+00
    w[10,7]   old_normalized_TC2  7.9804945054945060e+00
    w[10,8]   mass_10   1
    w[10,8]   w_lb_10_8  1
    w[10,8]   w_ub_10_8  1
    w[10,8]   normalized_inventory_10  -8
    w[10,8]   old_normalized_TC  -2.4694333444333436e+00
    w[10,8]   old_normalized_TC2  7.36469363969364
    w[10,9]   mass_10   1
    w[10,9]   w_lb_10_9  1
    w[10,9]   w_ub_10_9  1
    w[10,9]   normalized_inventory_10  -9
    w[10,9]   old_normalized_TC  -3.8325285825285818e+00
    w[10,9]   old_normalized_TC2  6.3349317349317360e+00
    w[10,10]  mass_10   1
    w[10,10]  w_lb_10_10  1
    w[10,10]  w_ub_10_10  1
    w[10,10]  normalized_inventory_10  -10
    w[10,10]  old_normalized_TC  -5.5408619158619148e+00
    w[10,10]  old_normalized_TC2  4.9599317349317360e+00
    w[10,11]  mass_10   1
    w[10,11]  w_lb_10_11  1
    w[10,11]  w_ub_10_11  1
    w[10,11]  normalized_inventory_10  -11
    w[10,11]  old_normalized_TC  -7.5487984237984218e+00
    w[10,11]  old_normalized_TC2  3.2297730047730058e+00
    w[11,0]   mass_11   1
    w[11,0]   w_lb_11_0  1
    w[11,0]   w_ub_11_0  1
    w[11,1]   mass_11   1
    w[11,1]   w_lb_11_1  1
    w[11,1]   w_ub_11_1  1
    w[11,1]   normalized_inventory_11  -1
    w[11,1]   old_normalized_TC2  2.1428571428571428e+00
    w[11,2]   mass_11   1
    w[11,2]   w_lb_11_2  1
    w[11,2]   w_ub_11_2  1
    w[11,2]   normalized_inventory_11  -2
    w[11,2]   old_normalized_TC2  4.1428571428571432e+00
    w[11,3]   mass_11   1
    w[11,3]   w_lb_11_3  1
    w[11,3]   w_ub_11_3  1
    w[11,3]   normalized_inventory_11  -3
    w[11,3]   old_normalized_TC2  5.9464285714285712e+00
    w[11,4]   mass_11   1
    w[11,4]   w_lb_11_4  1
    w[11,4]   w_ub_11_4  1
    w[11,4]   normalized_inventory_11  -4
    w[11,4]   old_normalized_TC  -1.9841269841269837e-01
    w[11,4]   old_normalized_TC2  7.0496031746031749e+00
    w[11,5]   mass_11   1
    w[11,5]   w_lb_11_5  1
    w[11,5]   w_ub_11_5  1
    w[11,5]   normalized_inventory_11  -5
    w[11,5]   old_normalized_TC  -4.8412698412698407e-01
    w[11,5]   old_normalized_TC2  7.74484126984127
    w[11,6]   mass_11   1
    w[11,6]   w_lb_11_6  1
    w[11,6]   w_ub_11_6  1
    w[11,6]   normalized_inventory_11  -6
    w[11,6]   old_normalized_TC  -7.6984126984126977e-01
    w[11,6]   old_normalized_TC2  8.09404761904762
    w[11,7]   mass_11   1
    w[11,7]   w_lb_11_7  1
    w[11,7]   w_ub_11_7  1
    w[11,7]   normalized_inventory_11  -7
    w[11,7]   old_normalized_TC  -1.0555555555555554e+00
    w[11,7]   old_normalized_TC2  8.1119047619047624e+00
    w[11,8]   mass_11   1
    w[11,8]   w_lb_11_8  1
    w[11,8]   w_ub_11_8  1
    w[11,8]   normalized_inventory_11  -8
    w[11,8]   old_normalized_TC  -1.4250610500610497e+00
    w[11,8]   old_normalized_TC2  8.0281135531135543e+00
    w[11,9]   mass_11   1
    w[11,9]   w_lb_11_9  1
    w[11,9]   w_ub_11_9  1
    w[11,9]   normalized_inventory_11  -9
    w[11,9]   old_normalized_TC  -2.1361000111000106e+00
    w[11,9]   old_normalized_TC2  7.6027888777888784e+00
    w[11,10]  mass_11   1
    w[11,10]  w_lb_11_10  1
    w[11,10]  w_ub_11_10  1
    w[11,10]  normalized_inventory_11  -10
    w[11,10]  old_normalized_TC  -3.1896714396714390e+00
    w[11,10]  old_normalized_TC2  6.8349317349317360e+00
    w[11,11]  mass_11   1
    w[11,11]  w_lb_11_11  1
    w[11,11]  w_ub_11_11  1
    w[11,11]  normalized_inventory_11  -11
    w[11,11]  old_normalized_TC  -4.5468142968142953e+00
    w[11,11]  old_normalized_TC2  5.7635031635031648e+00
    w[11,12]  mass_11   1
    w[11,12]  w_lb_11_12  1
    w[11,12]  w_ub_11_12  1
    w[11,12]  normalized_inventory_11  -12
    w[11,12]  old_normalized_TC  -6.0646714396714385e+00
    w[11,12]  old_normalized_TC2  4.5313603063603072e+00
    w[11,13]  mass_11   1
    w[11,13]  w_lb_11_13  1
    w[11,13]  w_ub_11_13  1
    w[11,13]  normalized_inventory_11  -13
    w[11,13]  old_normalized_TC  -7.8821317571317557e+00
    w[11,13]  old_normalized_TC2  2.9202491952491960e+00
    w[11,14]  mass_11   1
    w[11,14]  w_lb_11_14  1
    w[11,14]  w_ub_11_14  1
    w[11,14]  normalized_inventory_11  -14
    w[11,14]  old_normalized_TC  -1.0644433344433342e+01
    w[11,14]  old_normalized_TC2  1.5794760794760962e-01
    w[11,15]  mass_11   1
    w[11,15]  w_lb_11_15  1
    w[11,15]  w_ub_11_15  1
    w[11,15]  normalized_inventory_11  -15
    w[11,15]  old_normalized_TC  -1.3882528582528579e+01
    w[11,15]  old_normalized_TC2  -3.0801476301476280e+00
    w[12,0]   mass_12   1
    w[12,0]   w_lb_12_0  1
    w[12,0]   w_ub_12_0  1
    w[12,1]   mass_12   1
    w[12,1]   w_lb_12_1  1
    w[12,1]   w_ub_12_1  1
    w[12,1]   normalized_inventory_12  -1
    w[12,1]   old_normalized_TC2  1.875
    w[12,2]   mass_12   1
    w[12,2]   w_lb_12_2  1
    w[12,2]   w_ub_12_2  1
    w[12,2]   normalized_inventory_12  -2
    w[12,2]   old_normalized_TC2  3.6428571428571432e+00
    w[12,3]   mass_12   1
    w[12,3]   w_lb_12_3  1
    w[12,3]   w_ub_12_3  1
    w[12,3]   normalized_inventory_12  -3
    w[12,3]   old_normalized_TC2  5.3035714285714288e+00
    w[12,4]   mass_12   1
    w[12,4]   w_lb_12_4  1
    w[12,4]   w_ub_12_4  1
    w[12,4]   normalized_inventory_12  -4
    w[12,4]   old_normalized_TC  -5.5555555555555580e-02
    w[12,4]   old_normalized_TC2  6.6210317460317460e+00
    w[12,5]   mass_12   1
    w[12,5]   w_lb_12_5  1
    w[12,5]   w_ub_12_5  1
    w[12,5]   normalized_inventory_12  -5
    w[12,5]   old_normalized_TC  -3.0555555555555558e-01
    w[12,5]   old_normalized_TC2  7.3460317460317466e+00
    w[12,6]   mass_12   1
    w[12,6]   w_lb_12_6  1
    w[12,6]   w_ub_12_6  1
    w[12,6]   normalized_inventory_12  -6
    w[12,6]   old_normalized_TC  -5.5555555555555558e-01
    w[12,6]   old_normalized_TC2  7.8519841269841271e+00
    w[12,7]   mass_12   1
    w[12,7]   w_lb_12_7  1
    w[12,7]   w_ub_12_7  1
    w[12,7]   normalized_inventory_12  -7
    w[12,7]   old_normalized_TC  -8.0555555555555558e-01
    w[12,7]   old_normalized_TC2  8.1119047619047624e+00
    w[12,8]   mass_12   1
    w[12,8]   w_lb_12_8  1
    w[12,8]   w_ub_12_8  1
    w[12,8]   normalized_inventory_12  -8
    w[12,8]   old_normalized_TC  -1.0555555555555556e+00
    w[12,8]   old_normalized_TC2  8.1119047619047624e+00
    w[12,9]   mass_12   1
    w[12,9]   w_lb_12_9  1
    w[12,9]   w_ub_12_9  1
    w[12,9]   normalized_inventory_12  -9
    w[12,9]   old_normalized_TC  -1.3536324786324785e+00
    w[12,9]   old_normalized_TC2  8.0638278388278390e+00
    w[12,10]  mass_12   1
    w[12,10]  w_lb_12_10  1
    w[12,10]  w_ub_12_10  1
    w[12,10]  normalized_inventory_12  -10
    w[12,10]  old_normalized_TC  -1.9218142968142966e+00
    w[12,10]  old_normalized_TC2  7.7456460206460207e+00
    w[12,11]  mass_12   1
    w[12,11]  w_lb_12_11  1
    w[12,11]  w_ub_12_11  1
    w[12,11]  normalized_inventory_12  -11
    w[12,11]  old_normalized_TC  -2.7611000111000110e+00
    w[12,11]  old_normalized_TC2  7.1563603063603063e+00
    w[12,12]  mass_12   1
    w[12,12]  w_lb_12_12  1
    w[12,12]  w_ub_12_12  1
    w[12,12]  normalized_inventory_12  -12
    w[12,12]  old_normalized_TC  -3.8325285825285822e+00
    w[12,12]  old_normalized_TC2  6.3349317349317351e+00
    w[12,13]  mass_12   1
    w[12,13]  w_lb_12_13  1
    w[12,13]  w_ub_12_13  1
    w[12,13]  normalized_inventory_12  -13
    w[12,13]  old_normalized_TC  -5.0825285825285818e+00
    w[12,13]  old_normalized_TC2  5.3349317349317351e+00
    w[12,14]  mass_12   1
    w[12,14]  w_lb_12_14  1
    w[12,14]  w_ub_12_14  1
    w[12,14]  normalized_inventory_12  -14
    w[12,14]  old_normalized_TC  -6.4932428682428682e+00
    w[12,14]  old_normalized_TC2  4.1742174492174495e+00
    w[12,15]  mass_12   1
    w[12,15]  w_lb_12_15  1
    w[12,15]  w_ub_12_15  1
    w[12,15]  normalized_inventory_12  -15
    w[12,15]  old_normalized_TC  -8.1499888999889
    w[12,15]  old_normalized_TC2  2.6523920523920519e+00
    w[13,0]   mass_13   1
    w[13,0]   w_lb_13_0  1
    w[13,0]   w_ub_13_0  1
    w[13,1]   mass_13   1
    w[13,1]   w_lb_13_1  1
    w[13,1]   w_ub_13_1  1
    w[13,1]   normalized_inventory_13  -1
    w[13,1]   old_normalized_TC2  1.5000000000000002e+00
    w[13,2]   mass_13   1
    w[13,2]   w_lb_13_2  1
    w[13,2]   w_ub_13_2  1
    w[13,2]   normalized_inventory_13  -2
    w[13,2]   old_normalized_TC2  2.9428571428571431e+00
    w[13,3]   mass_13   1
    w[13,3]   w_lb_13_3  1
    w[13,3]   w_ub_13_3  1
    w[13,3]   normalized_inventory_13  -3
    w[13,3]   old_normalized_TC2  4.3285714285714292e+00
    w[13,4]   mass_13   1
    w[13,4]   w_lb_13_4  1
    w[13,4]   w_ub_13_4  1
    w[13,4]   normalized_inventory_13  -4
    w[13,4]   old_normalized_TC2  5.6035714285714295e+00
    w[13,5]   mass_13   1
    w[13,5]   w_lb_13_5  1
    w[13,5]   w_ub_13_5  1
    w[13,5]   normalized_inventory_13  -5
    w[13,5]   old_normalized_TC  -5.5555555555555636e-02
    w[13,5]   old_normalized_TC2  6.6210317460317469e+00
    w[13,6]   mass_13   1
    w[13,6]   w_lb_13_6  1
    w[13,6]   w_ub_13_6  1
    w[13,6]   normalized_inventory_13  -6
    w[13,6]   old_normalized_TC  -2.5555555555555565e-01
    w[13,6]   old_normalized_TC2  7.2210317460317466e+00
    w[13,7]   mass_13   1
    w[13,7]   w_lb_13_7  1
    w[13,7]   w_ub_13_7  1
    w[13,7]   normalized_inventory_13  -7
    w[13,7]   old_normalized_TC  -4.5555555555555566e-01
    w[13,7]   old_normalized_TC2  7.6876984126984134e+00
    w[13,8]   mass_13   1
    w[13,8]   w_lb_13_8  1
    w[13,8]   w_ub_13_8  1
    w[13,8]   normalized_inventory_13  -8
    w[13,8]   old_normalized_TC  -6.5555555555555567e-01
    w[13,8]   old_normalized_TC2  7.9797619047619053e+00
    w[13,9]   mass_13   1
    w[13,9]   w_lb_13_9  1
    w[13,9]   w_ub_13_9  1
    w[13,9]   normalized_inventory_13  -9
    w[13,9]   old_normalized_TC  -8.5555555555555562e-01
    w[13,9]   old_normalized_TC2  8.1119047619047624e+00
    w[13,10]  mass_13   1
    w[13,10]  w_lb_13_10  1
    w[13,10]  w_ub_13_10  1
    w[13,10]  normalized_inventory_13  -10
    w[13,10]  old_normalized_TC  -1.0555555555555556e+00
    w[13,10]  old_normalized_TC2  8.1119047619047624e+00
    w[13,11]  mass_13   1
    w[13,11]  w_lb_13_11  1
    w[13,11]  w_ub_13_11  1
    w[13,11]  normalized_inventory_13  -11
    w[13,11]  old_normalized_TC  -1.2786324786324788e+00
    w[13,11]  old_normalized_TC2  8.08882783882784
    w[13,12]  mass_13   1
    w[13,12]  w_lb_13_12  1
    w[13,12]  w_ub_13_12  1
    w[13,12]  normalized_inventory_13  -12
    w[13,12]  old_normalized_TC  -1.6718142968142971e+00
    w[13,12]  old_normalized_TC2  7.8956460206460211e+00
    w[13,13]  mass_13   1
    w[13,13]  w_lb_13_13  1
    w[13,13]  w_ub_13_13  1
    w[13,13]  normalized_inventory_13  -13
    w[13,13]  old_normalized_TC  -2.2361000111000116e+00
    w[13,13]  old_normalized_TC2  7.5313603063603063e+00
    w[13,14]  mass_13   1
    w[13,14]  w_lb_13_14  1
    w[13,14]  w_ub_13_14  1
    w[13,14]  normalized_inventory_13  -14
    w[13,14]  old_normalized_TC  -2.9611000111000116e+00
    w[13,14]  old_normalized_TC2  7.0063603063603059e+00
    w[13,15]  mass_13   1
    w[13,15]  w_lb_13_15  1
    w[13,15]  w_ub_13_15  1
    w[13,15]  normalized_inventory_13  -15
    w[13,15]  old_normalized_TC  -3.8325285825285831e+00
    w[13,15]  old_normalized_TC2  6.3349317349317342e+00
    w[13,16]  mass_13   1
    w[13,16]  w_lb_13_16  1
    w[13,16]  w_ub_13_16  1
    w[13,16]  normalized_inventory_13  -16
    w[13,16]  old_normalized_TC  -4.8325285825285826e+00
    w[13,16]  old_normalized_TC2  5.5349317349317344e+00
    w[13,17]  mass_13   1
    w[13,17]  w_lb_13_17  1
    w[13,17]  w_ub_13_17  1
    w[13,17]  normalized_inventory_13  -17
    w[13,17]  old_normalized_TC  -5.9075285825285828e+00
    w[13,17]  old_normalized_TC2  4.6599317349317344e+00
    w[13,18]  mass_13   1
    w[13,18]  w_lb_13_18  1
    w[13,18]  w_ub_13_18  1
    w[13,18]  normalized_inventory_13  -18
    w[13,18]  old_normalized_TC  -7.1154650904650918e+00
    w[13,18]  old_normalized_TC2  3.6297730047730035e+00
    w[13,19]  mass_13   1
    w[13,19]  w_lb_13_19  1
    w[13,19]  w_ub_13_19  1
    w[13,19]  normalized_inventory_13  -19
    w[13,19]  old_normalized_TC  -8.5611000111000131e+00
    w[13,19]  old_normalized_TC2  2.2412809412809387e+00
    w[14,0]   mass_14   1
    w[14,0]   w_lb_14_0  1
    w[14,0]   w_ub_14_0  1
    w[14,1]   mass_14   1
    w[14,1]   w_lb_14_1  1
    w[14,1]   w_ub_14_1  1
    w[14,1]   normalized_inventory_14  -1
    w[14,1]   old_normalized_TC2  1.5000000000000002e+00
    w[14,2]   mass_14   1
    w[14,2]   w_lb_14_2  1
    w[14,2]   w_ub_14_2  1
    w[14,2]   normalized_inventory_14  -2
    w[14,2]   old_normalized_TC2  2.9428571428571431e+00
    w[14,3]   mass_14   1
    w[14,3]   w_lb_14_3  1
    w[14,3]   w_ub_14_3  1
    w[14,3]   normalized_inventory_14  -3
    w[14,3]   old_normalized_TC2  4.3285714285714292e+00
    w[14,4]   mass_14   1
    w[14,4]   w_lb_14_4  1
    w[14,4]   w_ub_14_4  1
    w[14,4]   normalized_inventory_14  -4
    w[14,4]   old_normalized_TC2  5.6035714285714295e+00
    w[14,5]   mass_14   1
    w[14,5]   w_lb_14_5  1
    w[14,5]   w_ub_14_5  1
    w[14,5]   normalized_inventory_14  -5
    w[14,5]   old_normalized_TC  -5.5555555555555636e-02
    w[14,5]   old_normalized_TC2  6.6210317460317469e+00
    w[14,6]   mass_14   1
    w[14,6]   w_lb_14_6  1
    w[14,6]   w_ub_14_6  1
    w[14,6]   normalized_inventory_14  -6
    w[14,6]   old_normalized_TC  -2.5555555555555565e-01
    w[14,6]   old_normalized_TC2  7.2210317460317466e+00
    w[14,7]   mass_14   1
    w[14,7]   w_lb_14_7  1
    w[14,7]   w_ub_14_7  1
    w[14,7]   normalized_inventory_14  -7
    w[14,7]   old_normalized_TC  -4.5555555555555566e-01
    w[14,7]   old_normalized_TC2  7.6876984126984134e+00
    w[14,8]   mass_14   1
    w[14,8]   w_lb_14_8  1
    w[14,8]   w_ub_14_8  1
    w[14,8]   normalized_inventory_14  -8
    w[14,8]   old_normalized_TC  -6.5555555555555567e-01
    w[14,8]   old_normalized_TC2  7.9797619047619053e+00
    w[14,9]   mass_14   1
    w[14,9]   w_lb_14_9  1
    w[14,9]   w_ub_14_9  1
    w[14,9]   normalized_inventory_14  -9
    w[14,9]   old_normalized_TC  -8.5555555555555562e-01
    w[14,9]   old_normalized_TC2  8.1119047619047624e+00
    w[14,10]  mass_14   1
    w[14,10]  w_lb_14_10  1
    w[14,10]  w_ub_14_10  1
    w[14,10]  normalized_inventory_14  -10
    w[14,10]  old_normalized_TC  -1.0555555555555556e+00
    w[14,10]  old_normalized_TC2  8.1119047619047624e+00
    w[14,11]  mass_14   1
    w[14,11]  w_lb_14_11  1
    w[14,11]  w_ub_14_11  1
    w[14,11]  normalized_inventory_14  -11
    w[14,11]  old_normalized_TC  -1.2786324786324788e+00
    w[14,11]  old_normalized_TC2  8.08882783882784
    w[14,12]  mass_14   1
    w[14,12]  w_lb_14_12  1
    w[14,12]  w_ub_14_12  1
    w[14,12]  normalized_inventory_14  -12
    w[14,12]  old_normalized_TC  -1.6718142968142971e+00
    w[14,12]  old_normalized_TC2  7.8956460206460211e+00
    w[14,13]  mass_14   1
    w[14,13]  w_lb_14_13  1
    w[14,13]  w_ub_14_13  1
    w[14,13]  normalized_inventory_14  -13
    w[14,13]  old_normalized_TC  -2.2361000111000116e+00
    w[14,13]  old_normalized_TC2  7.5313603063603063e+00
    w[14,14]  mass_14   1
    w[14,14]  w_lb_14_14  1
    w[14,14]  w_ub_14_14  1
    w[14,14]  normalized_inventory_14  -14
    w[14,14]  old_normalized_TC  -2.9611000111000116e+00
    w[14,14]  old_normalized_TC2  7.0063603063603059e+00
    w[14,15]  mass_14   1
    w[14,15]  w_lb_14_15  1
    w[14,15]  w_ub_14_15  1
    w[14,15]  normalized_inventory_14  -15
    w[14,15]  old_normalized_TC  -3.8325285825285831e+00
    w[14,15]  old_normalized_TC2  6.3349317349317342e+00
    w[14,16]  mass_14   1
    w[14,16]  w_lb_14_16  1
    w[14,16]  w_ub_14_16  1
    w[14,16]  normalized_inventory_14  -16
    w[14,16]  old_normalized_TC  -4.8325285825285826e+00
    w[14,16]  old_normalized_TC2  5.5349317349317344e+00
    w[14,17]  mass_14   1
    w[14,17]  w_lb_14_17  1
    w[14,17]  w_ub_14_17  1
    w[14,17]  normalized_inventory_14  -17
    w[14,17]  old_normalized_TC  -5.9075285825285828e+00
    w[14,17]  old_normalized_TC2  4.6599317349317344e+00
    w[14,18]  mass_14   1
    w[14,18]  w_lb_14_18  1
    w[14,18]  w_ub_14_18  1
    w[14,18]  normalized_inventory_14  -18
    w[14,18]  old_normalized_TC  -7.1154650904650918e+00
    w[14,18]  old_normalized_TC2  3.6297730047730035e+00
    w[15,0]   mass_15   1
    w[15,0]   w_lb_15_0  1
    w[15,0]   w_ub_15_0  1
    w[15,1]   mass_15   1
    w[15,1]   w_lb_15_1  1
    w[15,1]   w_ub_15_1  1
    w[15,1]   normalized_inventory_15  -1
    w[15,1]   old_normalized_TC2  1.5000000000000002e+00
    w[15,2]   mass_15   1
    w[15,2]   w_lb_15_2  1
    w[15,2]   w_ub_15_2  1
    w[15,2]   normalized_inventory_15  -2
    w[15,2]   old_normalized_TC2  2.9428571428571431e+00
    w[15,3]   mass_15   1
    w[15,3]   w_lb_15_3  1
    w[15,3]   w_ub_15_3  1
    w[15,3]   normalized_inventory_15  -3
    w[15,3]   old_normalized_TC2  4.3285714285714292e+00
    w[15,4]   mass_15   1
    w[15,4]   w_lb_15_4  1
    w[15,4]   w_ub_15_4  1
    w[15,4]   normalized_inventory_15  -4
    w[15,4]   old_normalized_TC2  5.6035714285714295e+00
    w[15,5]   mass_15   1
    w[15,5]   w_lb_15_5  1
    w[15,5]   w_ub_15_5  1
    w[15,5]   normalized_inventory_15  -5
    w[15,5]   old_normalized_TC  -5.5555555555555636e-02
    w[15,5]   old_normalized_TC2  6.6210317460317469e+00
    w[15,6]   mass_15   1
    w[15,6]   w_lb_15_6  1
    w[15,6]   w_ub_15_6  1
    w[15,6]   normalized_inventory_15  -6
    w[15,6]   old_normalized_TC  -2.5555555555555565e-01
    w[15,6]   old_normalized_TC2  7.2210317460317466e+00
    w[15,7]   mass_15   1
    w[15,7]   w_lb_15_7  1
    w[15,7]   w_ub_15_7  1
    w[15,7]   normalized_inventory_15  -7
    w[15,7]   old_normalized_TC  -4.5555555555555566e-01
    w[15,7]   old_normalized_TC2  7.6876984126984134e+00
    w[15,8]   mass_15   1
    w[15,8]   w_lb_15_8  1
    w[15,8]   w_ub_15_8  1
    w[15,8]   normalized_inventory_15  -8
    w[15,8]   old_normalized_TC  -6.5555555555555567e-01
    w[15,8]   old_normalized_TC2  7.9797619047619053e+00
    w[15,9]   mass_15   1
    w[15,9]   w_lb_15_9  1
    w[15,9]   w_ub_15_9  1
    w[15,9]   normalized_inventory_15  -9
    w[15,9]   old_normalized_TC  -8.5555555555555562e-01
    w[15,9]   old_normalized_TC2  8.1119047619047624e+00
    w[15,10]  mass_15   1
    w[15,10]  w_lb_15_10  1
    w[15,10]  w_ub_15_10  1
    w[15,10]  normalized_inventory_15  -10
    w[15,10]  old_normalized_TC  -1.0555555555555556e+00
    w[15,10]  old_normalized_TC2  8.1119047619047624e+00
    w[15,11]  mass_15   1
    w[15,11]  w_lb_15_11  1
    w[15,11]  w_ub_15_11  1
    w[15,11]  normalized_inventory_15  -11
    w[15,11]  old_normalized_TC  -1.2786324786324788e+00
    w[15,11]  old_normalized_TC2  8.08882783882784
    w[15,12]  mass_15   1
    w[15,12]  w_lb_15_12  1
    w[15,12]  w_ub_15_12  1
    w[15,12]  normalized_inventory_15  -12
    w[15,12]  old_normalized_TC  -1.6718142968142971e+00
    w[15,12]  old_normalized_TC2  7.8956460206460211e+00
    w[15,13]  mass_15   1
    w[15,13]  w_lb_15_13  1
    w[15,13]  w_ub_15_13  1
    w[15,13]  normalized_inventory_15  -13
    w[15,13]  old_normalized_TC  -2.2361000111000116e+00
    w[15,13]  old_normalized_TC2  7.5313603063603063e+00
    w[15,14]  mass_15   1
    w[15,14]  w_lb_15_14  1
    w[15,14]  w_ub_15_14  1
    w[15,14]  normalized_inventory_15  -14
    w[15,14]  old_normalized_TC  -2.9611000111000116e+00
    w[15,14]  old_normalized_TC2  7.0063603063603059e+00
    w[15,15]  mass_15   1
    w[15,15]  w_lb_15_15  1
    w[15,15]  w_ub_15_15  1
    w[15,15]  normalized_inventory_15  -15
    w[15,15]  old_normalized_TC  -3.8325285825285831e+00
    w[15,15]  old_normalized_TC2  6.3349317349317342e+00
    w[15,16]  mass_15   1
    w[15,16]  w_lb_15_16  1
    w[15,16]  w_ub_15_16  1
    w[15,16]  normalized_inventory_15  -16
    w[15,16]  old_normalized_TC  -4.8325285825285826e+00
    w[15,16]  old_normalized_TC2  5.5349317349317344e+00
    w[15,17]  mass_15   1
    w[15,17]  w_lb_15_17  1
    w[15,17]  w_ub_15_17  1
    w[15,17]  normalized_inventory_15  -17
    w[15,17]  old_normalized_TC  -5.9075285825285828e+00
    w[15,17]  old_normalized_TC2  4.6599317349317344e+00
    w[15,18]  mass_15   1
    w[15,18]  w_lb_15_18  1
    w[15,18]  w_ub_15_18  1
    w[15,18]  normalized_inventory_15  -18
    w[15,18]  old_normalized_TC  -7.1154650904650918e+00
    w[15,18]  old_normalized_TC2  3.6297730047730035e+00
    w[15,19]  mass_15   1
    w[15,19]  w_lb_15_19  1
    w[15,19]  w_ub_15_19  1
    w[15,19]  normalized_inventory_15  -19
    w[15,19]  old_normalized_TC  -8.5611000111000131e+00
    w[15,19]  old_normalized_TC2  2.2412809412809387e+00
    w[16,0]   mass_16   1
    w[16,0]   w_lb_16_0  1
    w[16,0]   w_ub_16_0  1
    w[16,1]   mass_16   1
    w[16,1]   w_lb_16_1  1
    w[16,1]   w_ub_16_1  1
    w[16,1]   normalized_inventory_16  -1
    w[16,1]   old_normalized_TC2  2.9428571428571431e+00
    w[16,2]   mass_16   1
    w[16,2]   w_lb_16_2  1
    w[16,2]   w_ub_16_2  1
    w[16,2]   normalized_inventory_16  -2
    w[16,2]   old_normalized_TC2  5.6035714285714295e+00
    w[16,3]   mass_16   1
    w[16,3]   w_lb_16_3  1
    w[16,3]   w_ub_16_3  1
    w[16,3]   normalized_inventory_16  -3
    w[16,3]   old_normalized_TC  -2.5555555555555565e-01
    w[16,3]   old_normalized_TC2  7.2210317460317466e+00
    w[16,4]   mass_16   1
    w[16,4]   w_lb_16_4  1
    w[16,4]   w_ub_16_4  1
    w[16,4]   normalized_inventory_16  -4
    w[16,4]   old_normalized_TC  -6.5555555555555567e-01
    w[16,4]   old_normalized_TC2  7.9797619047619053e+00
    w[16,5]   mass_16   1
    w[16,5]   w_lb_16_5  1
    w[16,5]   w_ub_16_5  1
    w[16,5]   normalized_inventory_16  -5
    w[16,5]   old_normalized_TC  -1.0555555555555556e+00
    w[16,5]   old_normalized_TC2  8.1119047619047624e+00
    w[16,6]   mass_16   1
    w[16,6]   w_lb_16_6  1
    w[16,6]   w_ub_16_6  1
    w[16,6]   normalized_inventory_16  -6
    w[16,6]   old_normalized_TC  -1.6718142968142971e+00
    w[16,6]   old_normalized_TC2  7.8956460206460211e+00
    w[16,7]   mass_16   1
    w[16,7]   w_lb_16_7  1
    w[16,7]   w_ub_16_7  1
    w[16,7]   normalized_inventory_16  -7
    w[16,7]   old_normalized_TC  -2.9611000111000116e+00
    w[16,7]   old_normalized_TC2  7.0063603063603059e+00
    w[16,8]   mass_16   1
    w[16,8]   w_lb_16_8  1
    w[16,8]   w_ub_16_8  1
    w[16,8]   normalized_inventory_16  -8
    w[16,8]   old_normalized_TC  -4.8325285825285826e+00
    w[16,8]   old_normalized_TC2  5.5349317349317344e+00
    w[16,9]   mass_16   1
    w[16,9]   w_lb_16_9  1
    w[16,9]   w_ub_16_9  1
    w[16,9]   normalized_inventory_16  -9
    w[16,9]   old_normalized_TC  -7.1154650904650918e+00
    w[16,9]   old_normalized_TC2  3.6297730047730035e+00
    w[16,10]  mass_16   1
    w[16,10]  w_lb_16_10  1
    w[16,10]  w_ub_16_10  1
    w[16,10]  normalized_inventory_16  -10
    w[16,10]  old_normalized_TC  -1.0644433344433347e+01
    w[16,10]  old_normalized_TC2  1.5794760794760485e-01
    w[16,11]  mass_16   1
    w[16,11]  w_lb_16_11  1
    w[16,11]  w_ub_16_11  1
    w[16,11]  normalized_inventory_16  -11
    w[16,11]  old_normalized_TC  -1.5825385725385731e+01
    w[16,11]  old_normalized_TC2  -5.0230047730047787e+00
    w[17,16]  mass_17   1
    w[17,16]  w_lb_17_16  1
    w[17,16]  w_ub_17_16  1
    w[17,16]  normalized_inventory_17  -16
    w[17,16]  old_normalized_TC  -6.8265762015762
    w[17,16]  old_normalized_TC2  3.8964396714396723e+00
    w[18,0]   mass_18   1
    w[18,0]   w_lb_18_0  1
    w[18,0]   w_ub_18_0  1
    w[18,1]   mass_18   1
    w[18,1]   w_lb_18_1  1
    w[18,1]   w_ub_18_1  1
    w[18,1]   normalized_inventory_18  -1
    w[18,1]   old_normalized_TC2  2.1428571428571428e+00
    w[18,2]   mass_18   1
    w[18,2]   w_lb_18_2  1
    w[18,2]   w_ub_18_2  1
    w[18,2]   normalized_inventory_18  -2
    w[18,2]   old_normalized_TC2  4.1428571428571432e+00
    w[18,3]   mass_18   1
    w[18,3]   w_lb_18_3  1
    w[18,3]   w_ub_18_3  1
    w[18,3]   normalized_inventory_18  -3
    w[18,3]   old_normalized_TC2  5.9464285714285712e+00
    w[18,4]   mass_18   1
    w[18,4]   w_lb_18_4  1
    w[18,4]   w_ub_18_4  1
    w[18,4]   normalized_inventory_18  -4
    w[18,4]   old_normalized_TC  -1.9841269841269837e-01
    w[18,4]   old_normalized_TC2  7.0496031746031749e+00
    w[18,5]   mass_18   1
    w[18,5]   w_lb_18_5  1
    w[18,5]   w_ub_18_5  1
    w[18,5]   normalized_inventory_18  -5
    w[18,5]   old_normalized_TC  -4.8412698412698407e-01
    w[18,5]   old_normalized_TC2  7.74484126984127
    w[18,6]   mass_18   1
    w[18,6]   w_lb_18_6  1
    w[18,6]   w_ub_18_6  1
    w[18,6]   normalized_inventory_18  -6
    w[18,6]   old_normalized_TC  -7.6984126984126977e-01
    w[18,6]   old_normalized_TC2  8.09404761904762
    w[18,7]   mass_18   1
    w[18,7]   w_lb_18_7  1
    w[18,7]   w_ub_18_7  1
    w[18,7]   normalized_inventory_18  -7
    w[18,7]   old_normalized_TC  -1.0555555555555554e+00
    w[18,7]   old_normalized_TC2  8.1119047619047624e+00
    w[18,8]   mass_18   1
    w[18,8]   w_lb_18_8  1
    w[18,8]   w_ub_18_8  1
    w[18,8]   normalized_inventory_18  -8
    w[18,8]   old_normalized_TC  -1.4250610500610497e+00
    w[18,8]   old_normalized_TC2  8.0281135531135543e+00
    w[18,9]   mass_18   1
    w[18,9]   w_lb_18_9  1
    w[18,9]   w_ub_18_9  1
    w[18,9]   normalized_inventory_18  -9
    w[18,9]   old_normalized_TC  -2.1361000111000106e+00
    w[18,9]   old_normalized_TC2  7.6027888777888784e+00
    w[18,10]  mass_18   1
    w[18,10]  w_lb_18_10  1
    w[18,10]  w_ub_18_10  1
    w[18,10]  normalized_inventory_18  -10
    w[18,10]  old_normalized_TC  -3.1896714396714390e+00
    w[18,10]  old_normalized_TC2  6.8349317349317360e+00
    w[18,11]  mass_18   1
    w[18,11]  w_lb_18_11  1
    w[18,11]  w_ub_18_11  1
    w[18,11]  normalized_inventory_18  -11
    w[18,11]  old_normalized_TC  -4.5468142968142953e+00
    w[18,11]  old_normalized_TC2  5.7635031635031648e+00
    w[18,12]  mass_18   1
    w[18,12]  w_lb_18_12  1
    w[18,12]  w_ub_18_12  1
    w[18,12]  normalized_inventory_18  -12
    w[18,12]  old_normalized_TC  -6.0646714396714385e+00
    w[18,12]  old_normalized_TC2  4.5313603063603072e+00
    w[18,13]  mass_18   1
    w[18,13]  w_lb_18_13  1
    w[18,13]  w_ub_18_13  1
    w[18,13]  normalized_inventory_18  -13
    w[18,13]  old_normalized_TC  -7.8821317571317557e+00
    w[18,13]  old_normalized_TC2  2.9202491952491960e+00
    w[18,14]  mass_18   1
    w[18,14]  w_lb_18_14  1
    w[18,14]  w_ub_18_14  1
    w[18,14]  normalized_inventory_18  -14
    w[18,14]  old_normalized_TC  -1.0644433344433342e+01
    w[18,14]  old_normalized_TC2  1.5794760794760962e-01
    w[18,15]  mass_18   1
    w[18,15]  w_lb_18_15  1
    w[18,15]  w_ub_18_15  1
    w[18,15]  normalized_inventory_18  -15
    w[18,15]  old_normalized_TC  -1.3882528582528579e+01
    w[18,15]  old_normalized_TC2  -3.0801476301476280e+00
    w[19,0]   mass_19   1
    w[19,0]   w_lb_19_0  1
    w[19,0]   w_ub_19_0  1
    w[19,1]   mass_19   1
    w[19,1]   w_lb_19_1  1
    w[19,1]   w_ub_19_1  1
    w[19,1]   normalized_inventory_19  -1
    w[19,1]   old_normalized_TC2  1.6666666666666667e+00
    w[19,2]   mass_19   1
    w[19,2]   w_lb_19_2  1
    w[19,2]   w_ub_19_2  1
    w[19,2]   normalized_inventory_19  -2
    w[19,2]   old_normalized_TC2  3.2539682539682540e+00
    w[19,3]   mass_19   1
    w[19,3]   w_lb_19_3  1
    w[19,3]   w_ub_19_3  1
    w[19,3]   normalized_inventory_19  -3
    w[19,3]   old_normalized_TC2  4.7619047619047619e+00
    w[19,4]   mass_19   1
    w[19,4]   w_lb_19_4  1
    w[19,4]   w_ub_19_4  1
    w[19,4]   normalized_inventory_19  -4
    w[19,4]   old_normalized_TC2  6.1210317460317460e+00
    w[19,5]   mass_19   1
    w[19,5]   w_lb_19_5  1
    w[19,5]   w_ub_19_5  1
    w[19,5]   normalized_inventory_19  -5
    w[19,5]   old_normalized_TC  -1.6666666666666663e-01
    w[19,5]   old_normalized_TC2  6.95436507936508
    w[19,6]   mass_19   1
    w[19,6]   w_lb_19_6  1
    w[19,6]   w_ub_19_6  1
    w[19,6]   normalized_inventory_19  -6
    w[19,6]   old_normalized_TC  -3.8888888888888884e-01
    w[19,6]   old_normalized_TC2  7.55436507936508
    w[19,7]   mass_19   1
    w[19,7]   w_lb_19_7  1
    w[19,7]   w_ub_19_7  1
    w[19,7]   normalized_inventory_19  -7
    w[19,7]   old_normalized_TC  -0.611111111111111
    w[19,7]   old_normalized_TC2  7.93531746031746
    w[19,8]   mass_19   1
    w[19,8]   w_lb_19_8  1
    w[19,8]   w_ub_19_8  1
    w[19,8]   normalized_inventory_19  -8
    w[19,8]   old_normalized_TC  -8.3333333333333326e-01
    w[19,8]   old_normalized_TC2  8.1119047619047624e+00
    w[19,9]   mass_19   1
    w[19,9]   w_lb_19_9  1
    w[19,9]   w_ub_19_9  1
    w[19,9]   normalized_inventory_19  -9
    w[19,9]   old_normalized_TC  -1.0555555555555554e+00
    w[19,9]   old_normalized_TC2  8.1119047619047624e+00
    w[19,10]  mass_19   1
    w[19,10]  w_lb_19_10  1
    w[19,10]  w_ub_19_10  1
    w[19,10]  normalized_inventory_19  -10
    w[19,10]  old_normalized_TC  -1.3119658119658117e+00
    w[19,10]  old_normalized_TC2  8.0777167277167283e+00
    w[19,11]  mass_19   1
    w[19,11]  w_lb_19_11  1
    w[19,11]  w_ub_19_11  1
    w[19,11]  normalized_inventory_19  -11
    w[19,11]  old_normalized_TC  -1.7829254079254073e+00
    w[19,11]  old_normalized_TC2  7.8289793539793546e+00
    w[19,12]  mass_19   1
    w[19,12]  w_lb_19_12  1
    w[19,12]  w_ub_19_12  1
    w[19,12]  normalized_inventory_19  -12
    w[19,12]  old_normalized_TC  -2.4694333444333436e+00
    w[19,12]  old_normalized_TC2  7.36469363969364
    w[19,13]  mass_19   1
    w[19,13]  w_lb_19_13  1
    w[19,13]  w_ub_19_13  1
    w[19,13]  normalized_inventory_19  -13
    w[19,13]  old_normalized_TC  -3.3325285825285818e+00
    w[19,13]  old_normalized_TC2  6.7238206238206244e+00
    w[19,14]  mass_19   1
    w[19,14]  w_lb_19_14  1
    w[19,14]  w_ub_19_14  1
    w[19,14]  normalized_inventory_19  -14
    w[19,14]  old_normalized_TC  -4.3880841380841371e+00
    w[19,14]  old_normalized_TC2  5.8904872904872914e+00
    w[19,15]  mass_19   1
    w[19,15]  w_lb_19_15  1
    w[19,15]  w_ub_19_15  1
    w[19,15]  normalized_inventory_19  -15
    w[19,15]  old_normalized_TC  -5.5408619158619148e+00
    w[19,15]  old_normalized_TC2  4.9599317349317360e+00
    w[19,16]  mass_19   1
    w[19,16]  w_lb_19_16  1
    w[19,16]  w_ub_19_16  1
    w[19,16]  normalized_inventory_19  -16
    w[19,16]  old_normalized_TC  -6.8265762015762
    w[19,16]  old_normalized_TC2  3.8964396714396723e+00
    w[19,17]  mass_19   1
    w[19,17]  w_lb_19_17  1
    w[19,17]  w_ub_19_17  1
    w[19,17]  normalized_inventory_19  -17
    w[19,17]  old_normalized_TC  -8.37221112221112
    w[19,17]  old_normalized_TC2  2.4301698301698313e+00
    w[19,18]  mass_19   1
    w[19,18]  w_lb_19_18  1
    w[19,18]  w_ub_19_18  1
    w[19,18]  normalized_inventory_19  -18
    w[19,18]  old_normalized_TC  -1.0644433344433342e+01
    w[19,18]  old_normalized_TC2  1.5794760794760962e-01
    w[19,19]  mass_19   1
    w[19,19]  w_lb_19_19  1
    w[19,19]  w_ub_19_19  1
    w[19,19]  normalized_inventory_19  -19
    w[19,19]  old_normalized_TC  -1.3088877788877786e+01
    w[19,19]  old_normalized_TC2  -2.2864968364968346e+00
    w[20,0]   mass_20   1
    w[20,0]   w_lb_20_0  1
    w[20,0]   w_ub_20_0  1
    w[20,1]   mass_20   1
    w[20,1]   w_lb_20_1  1
    w[20,1]   w_ub_20_1  1
    w[20,1]   normalized_inventory_20  -1
    w[20,1]   old_normalized_TC2  2.1428571428571428e+00
    w[20,2]   mass_20   1
    w[20,2]   w_lb_20_2  1
    w[20,2]   w_ub_20_2  1
    w[20,2]   normalized_inventory_20  -2
    w[20,2]   old_normalized_TC2  4.1428571428571432e+00
    w[20,3]   mass_20   1
    w[20,3]   w_lb_20_3  1
    w[20,3]   w_ub_20_3  1
    w[20,3]   normalized_inventory_20  -3
    w[20,3]   old_normalized_TC2  5.9464285714285712e+00
    w[20,4]   mass_20   1
    w[20,4]   w_lb_20_4  1
    w[20,4]   w_ub_20_4  1
    w[20,4]   normalized_inventory_20  -4
    w[20,4]   old_normalized_TC  -1.9841269841269837e-01
    w[20,4]   old_normalized_TC2  7.0496031746031749e+00
    w[20,5]   mass_20   1
    w[20,5]   w_lb_20_5  1
    w[20,5]   w_ub_20_5  1
    w[20,5]   normalized_inventory_20  -5
    w[20,5]   old_normalized_TC  -4.8412698412698407e-01
    w[20,5]   old_normalized_TC2  7.74484126984127
    w[20,6]   mass_20   1
    w[20,6]   w_lb_20_6  1
    w[20,6]   w_ub_20_6  1
    w[20,6]   normalized_inventory_20  -6
    w[20,6]   old_normalized_TC  -7.6984126984126977e-01
    w[20,6]   old_normalized_TC2  8.09404761904762
    w[20,7]   mass_20   1
    w[20,7]   w_lb_20_7  1
    w[20,7]   w_ub_20_7  1
    w[20,7]   normalized_inventory_20  -7
    w[20,7]   old_normalized_TC  -1.0555555555555554e+00
    w[20,7]   old_normalized_TC2  8.1119047619047624e+00
    w[20,8]   mass_20   1
    w[20,8]   w_lb_20_8  1
    w[20,8]   w_ub_20_8  1
    w[20,8]   normalized_inventory_20  -8
    w[20,8]   old_normalized_TC  -1.4250610500610497e+00
    w[20,8]   old_normalized_TC2  8.0281135531135543e+00
    w[20,9]   mass_20   1
    w[20,9]   w_lb_20_9  1
    w[20,9]   w_ub_20_9  1
    w[20,9]   normalized_inventory_20  -9
    w[20,9]   old_normalized_TC  -2.1361000111000106e+00
    w[20,9]   old_normalized_TC2  7.6027888777888784e+00
    w[20,10]  mass_20   1
    w[20,10]  w_lb_20_10  1
    w[20,10]  w_ub_20_10  1
    w[20,10]  normalized_inventory_20  -10
    w[20,10]  old_normalized_TC  -3.1896714396714390e+00
    w[20,10]  old_normalized_TC2  6.8349317349317360e+00
    w[20,11]  mass_20   1
    w[20,11]  w_lb_20_11  1
    w[20,11]  w_ub_20_11  1
    w[20,11]  normalized_inventory_20  -11
    w[20,11]  old_normalized_TC  -4.5468142968142953e+00
    w[20,11]  old_normalized_TC2  5.7635031635031648e+00
    w[20,12]  mass_20   1
    w[20,12]  w_lb_20_12  1
    w[20,12]  w_ub_20_12  1
    w[20,12]  normalized_inventory_20  -12
    w[20,12]  old_normalized_TC  -6.0646714396714385e+00
    w[20,12]  old_normalized_TC2  4.5313603063603072e+00
    w[20,13]  mass_20   1
    w[20,13]  w_lb_20_13  1
    w[20,13]  w_ub_20_13  1
    w[20,13]  normalized_inventory_20  -13
    w[20,13]  old_normalized_TC  -7.8821317571317557e+00
    w[20,13]  old_normalized_TC2  2.9202491952491960e+00
    w[20,14]  mass_20   1
    w[20,14]  w_lb_20_14  1
    w[20,14]  w_ub_20_14  1
    w[20,14]  normalized_inventory_20  -14
    w[20,14]  old_normalized_TC  -1.0644433344433342e+01
    w[20,14]  old_normalized_TC2  1.5794760794760962e-01
    w[20,15]  mass_20   1
    w[20,15]  w_lb_20_15  1
    w[20,15]  w_ub_20_15  1
    w[20,15]  normalized_inventory_20  -15
    w[20,15]  old_normalized_TC  -1.3882528582528579e+01
    w[20,15]  old_normalized_TC2  -3.0801476301476280e+00
    w[21,0]   mass_21   1
    w[21,0]   w_lb_21_0  1
    w[21,0]   w_ub_21_0  1
    w[21,1]   mass_21   1
    w[21,1]   w_lb_21_1  1
    w[21,1]   w_ub_21_1  1
    w[21,1]   normalized_inventory_21  -1
    w[21,1]   old_normalized_TC2  1.6666666666666667e+00
    w[21,2]   mass_21   1
    w[21,2]   w_lb_21_2  1
    w[21,2]   w_ub_21_2  1
    w[21,2]   normalized_inventory_21  -2
    w[21,2]   old_normalized_TC2  3.2539682539682540e+00
    w[21,3]   mass_21   1
    w[21,3]   w_lb_21_3  1
    w[21,3]   w_ub_21_3  1
    w[21,3]   normalized_inventory_21  -3
    w[21,3]   old_normalized_TC2  4.7619047619047619e+00
    w[21,4]   mass_21   1
    w[21,4]   w_lb_21_4  1
    w[21,4]   w_ub_21_4  1
    w[21,4]   normalized_inventory_21  -4
    w[21,4]   old_normalized_TC2  6.1210317460317460e+00
    w[21,5]   mass_21   1
    w[21,5]   w_lb_21_5  1
    w[21,5]   w_ub_21_5  1
    w[21,5]   normalized_inventory_21  -5
    w[21,5]   old_normalized_TC  -1.6666666666666663e-01
    w[21,5]   old_normalized_TC2  6.95436507936508
    w[21,6]   mass_21   1
    w[21,6]   w_lb_21_6  1
    w[21,6]   w_ub_21_6  1
    w[21,6]   normalized_inventory_21  -6
    w[21,6]   old_normalized_TC  -3.8888888888888884e-01
    w[21,6]   old_normalized_TC2  7.55436507936508
    w[21,7]   mass_21   1
    w[21,7]   w_lb_21_7  1
    w[21,7]   w_ub_21_7  1
    w[21,7]   normalized_inventory_21  -7
    w[21,7]   old_normalized_TC  -0.611111111111111
    w[21,7]   old_normalized_TC2  7.93531746031746
    w[21,8]   mass_21   1
    w[21,8]   w_lb_21_8  1
    w[21,8]   w_ub_21_8  1
    w[21,8]   normalized_inventory_21  -8
    w[21,8]   old_normalized_TC  -8.3333333333333326e-01
    w[21,8]   old_normalized_TC2  8.1119047619047624e+00
    w[21,9]   mass_21   1
    w[21,9]   w_lb_21_9  1
    w[21,9]   w_ub_21_9  1
    w[21,9]   normalized_inventory_21  -9
    w[21,9]   old_normalized_TC  -1.0555555555555554e+00
    w[21,9]   old_normalized_TC2  8.1119047619047624e+00
    w[21,10]  mass_21   1
    w[21,10]  w_lb_21_10  1
    w[21,10]  w_ub_21_10  1
    w[21,10]  normalized_inventory_21  -10
    w[21,10]  old_normalized_TC  -1.3119658119658117e+00
    w[21,10]  old_normalized_TC2  8.0777167277167283e+00
    w[21,11]  mass_21   1
    w[21,11]  w_lb_21_11  1
    w[21,11]  w_ub_21_11  1
    w[21,11]  normalized_inventory_21  -11
    w[21,11]  old_normalized_TC  -1.7829254079254073e+00
    w[21,11]  old_normalized_TC2  7.8289793539793546e+00
    w[21,12]  mass_21   1
    w[21,12]  w_lb_21_12  1
    w[21,12]  w_ub_21_12  1
    w[21,12]  normalized_inventory_21  -12
    w[21,12]  old_normalized_TC  -2.4694333444333436e+00
    w[21,12]  old_normalized_TC2  7.36469363969364
    w[21,13]  mass_21   1
    w[21,13]  w_lb_21_13  1
    w[21,13]  w_ub_21_13  1
    w[21,13]  normalized_inventory_21  -13
    w[21,13]  old_normalized_TC  -3.3325285825285818e+00
    w[21,13]  old_normalized_TC2  6.7238206238206244e+00
    w[21,14]  mass_21   1
    w[21,14]  w_lb_21_14  1
    w[21,14]  w_ub_21_14  1
    w[21,14]  normalized_inventory_21  -14
    w[21,14]  old_normalized_TC  -4.3880841380841371e+00
    w[21,14]  old_normalized_TC2  5.8904872904872914e+00
    w[21,15]  mass_21   1
    w[21,15]  w_lb_21_15  1
    w[21,15]  w_ub_21_15  1
    w[21,15]  normalized_inventory_21  -15
    w[21,15]  old_normalized_TC  -5.5408619158619148e+00
    w[21,15]  old_normalized_TC2  4.9599317349317360e+00
    w[21,16]  mass_21   1
    w[21,16]  w_lb_21_16  1
    w[21,16]  w_ub_21_16  1
    w[21,16]  normalized_inventory_21  -16
    w[21,16]  old_normalized_TC  -6.8265762015762
    w[21,16]  old_normalized_TC2  3.8964396714396723e+00
    w[21,17]  mass_21   1
    w[21,17]  w_lb_21_17  1
    w[21,17]  w_ub_21_17  1
    w[21,17]  normalized_inventory_21  -17
    w[21,17]  old_normalized_TC  -8.37221112221112
    w[21,17]  old_normalized_TC2  2.4301698301698313e+00
    w[21,18]  mass_21   1
    w[21,18]  w_lb_21_18  1
    w[21,18]  w_ub_21_18  1
    w[21,18]  normalized_inventory_21  -18
    w[21,18]  old_normalized_TC  -1.0644433344433342e+01
    w[21,18]  old_normalized_TC2  1.5794760794760962e-01
    w[21,19]  mass_21   1
    w[21,19]  w_lb_21_19  1
    w[21,19]  w_ub_21_19  1
    w[21,19]  normalized_inventory_21  -19
    w[21,19]  old_normalized_TC  -1.3088877788877786e+01
    w[21,19]  old_normalized_TC2  -2.2864968364968346e+00
    w[22,0]   mass_22   1
    w[22,0]   w_lb_22_0  1
    w[22,0]   w_ub_22_0  1
    w[22,1]   mass_22   1
    w[22,1]   w_lb_22_1  1
    w[22,1]   w_ub_22_1  1
    w[22,1]   normalized_inventory_22  -1
    w[22,1]   old_normalized_TC2  1.5000000000000002e+00
    w[22,2]   mass_22   1
    w[22,2]   w_lb_22_2  1
    w[22,2]   w_ub_22_2  1
    w[22,2]   normalized_inventory_22  -2
    w[22,2]   old_normalized_TC2  2.9428571428571431e+00
    w[22,3]   mass_22   1
    w[22,3]   w_lb_22_3  1
    w[22,3]   w_ub_22_3  1
    w[22,3]   normalized_inventory_22  -3
    w[22,3]   old_normalized_TC2  4.3285714285714292e+00
    w[22,4]   mass_22   1
    w[22,4]   w_lb_22_4  1
    w[22,4]   w_ub_22_4  1
    w[22,4]   normalized_inventory_22  -4
    w[22,4]   old_normalized_TC2  5.6035714285714295e+00
    w[22,5]   mass_22   1
    w[22,5]   w_lb_22_5  1
    w[22,5]   w_ub_22_5  1
    w[22,5]   normalized_inventory_22  -5
    w[22,5]   old_normalized_TC  -5.5555555555555636e-02
    w[22,5]   old_normalized_TC2  6.6210317460317469e+00
    w[22,6]   mass_22   1
    w[22,6]   w_lb_22_6  1
    w[22,6]   w_ub_22_6  1
    w[22,6]   normalized_inventory_22  -6
    w[22,6]   old_normalized_TC  -2.5555555555555565e-01
    w[22,6]   old_normalized_TC2  7.2210317460317466e+00
    w[22,7]   mass_22   1
    w[22,7]   w_lb_22_7  1
    w[22,7]   w_ub_22_7  1
    w[22,7]   normalized_inventory_22  -7
    w[22,7]   old_normalized_TC  -4.5555555555555566e-01
    w[22,7]   old_normalized_TC2  7.6876984126984134e+00
    w[22,8]   mass_22   1
    w[22,8]   w_lb_22_8  1
    w[22,8]   w_ub_22_8  1
    w[22,8]   normalized_inventory_22  -8
    w[22,8]   old_normalized_TC  -6.5555555555555567e-01
    w[22,8]   old_normalized_TC2  7.9797619047619053e+00
    w[22,9]   mass_22   1
    w[22,9]   w_lb_22_9  1
    w[22,9]   w_ub_22_9  1
    w[22,9]   normalized_inventory_22  -9
    w[22,9]   old_normalized_TC  -8.5555555555555562e-01
    w[22,9]   old_normalized_TC2  8.1119047619047624e+00
    w[22,10]  mass_22   1
    w[22,10]  w_lb_22_10  1
    w[22,10]  w_ub_22_10  1
    w[22,10]  normalized_inventory_22  -10
    w[22,10]  old_normalized_TC  -1.0555555555555556e+00
    w[22,10]  old_normalized_TC2  8.1119047619047624e+00
    w[22,11]  mass_22   1
    w[22,11]  w_lb_22_11  1
    w[22,11]  w_ub_22_11  1
    w[22,11]  normalized_inventory_22  -11
    w[22,11]  old_normalized_TC  -1.2786324786324788e+00
    w[22,11]  old_normalized_TC2  8.08882783882784
    w[22,12]  mass_22   1
    w[22,12]  w_lb_22_12  1
    w[22,12]  w_ub_22_12  1
    w[22,12]  normalized_inventory_22  -12
    w[22,12]  old_normalized_TC  -1.6718142968142971e+00
    w[22,12]  old_normalized_TC2  7.8956460206460211e+00
    w[22,13]  mass_22   1
    w[22,13]  w_lb_22_13  1
    w[22,13]  w_ub_22_13  1
    w[22,13]  normalized_inventory_22  -13
    w[22,13]  old_normalized_TC  -2.2361000111000116e+00
    w[22,13]  old_normalized_TC2  7.5313603063603063e+00
    w[22,14]  mass_22   1
    w[22,14]  w_lb_22_14  1
    w[22,14]  w_ub_22_14  1
    w[22,14]  normalized_inventory_22  -14
    w[22,14]  old_normalized_TC  -2.9611000111000116e+00
    w[22,14]  old_normalized_TC2  7.0063603063603059e+00
    w[22,15]  mass_22   1
    w[22,15]  w_lb_22_15  1
    w[22,15]  w_ub_22_15  1
    w[22,15]  normalized_inventory_22  -15
    w[22,15]  old_normalized_TC  -3.8325285825285831e+00
    w[22,15]  old_normalized_TC2  6.3349317349317342e+00
    w[22,16]  mass_22   1
    w[22,16]  w_lb_22_16  1
    w[22,16]  w_ub_22_16  1
    w[22,16]  normalized_inventory_22  -16
    w[22,16]  old_normalized_TC  -4.8325285825285826e+00
    w[22,16]  old_normalized_TC2  5.5349317349317344e+00
    w[22,17]  mass_22   1
    w[22,17]  w_lb_22_17  1
    w[22,17]  w_ub_22_17  1
    w[22,17]  normalized_inventory_22  -17
    w[22,17]  old_normalized_TC  -5.9075285825285828e+00
    w[22,17]  old_normalized_TC2  4.6599317349317344e+00
    w[22,18]  mass_22   1
    w[22,18]  w_lb_22_18  1
    w[22,18]  w_ub_22_18  1
    w[22,18]  normalized_inventory_22  -18
    w[22,18]  old_normalized_TC  -7.1154650904650918e+00
    w[22,18]  old_normalized_TC2  3.6297730047730035e+00
    w[22,19]  mass_22   1
    w[22,19]  w_lb_22_19  1
    w[22,19]  w_ub_22_19  1
    w[22,19]  normalized_inventory_22  -19
    w[22,19]  old_normalized_TC  -8.5611000111000131e+00
    w[22,19]  old_normalized_TC2  2.2412809412809387e+00
    w[23,0]   mass_23   1
    w[23,0]   w_lb_23_0  1
    w[23,0]   w_ub_23_0  1
    w[23,1]   mass_23   1
    w[23,1]   w_lb_23_1  1
    w[23,1]   w_ub_23_1  1
    w[23,1]   normalized_inventory_23  -1
    w[23,1]   old_normalized_TC2  1.875
    w[23,2]   mass_23   1
    w[23,2]   w_lb_23_2  1
    w[23,2]   w_ub_23_2  1
    w[23,2]   normalized_inventory_23  -2
    w[23,2]   old_normalized_TC2  3.6428571428571432e+00
    w[23,3]   mass_23   1
    w[23,3]   w_lb_23_3  1
    w[23,3]   w_ub_23_3  1
    w[23,3]   normalized_inventory_23  -3
    w[23,3]   old_normalized_TC2  5.3035714285714288e+00
    w[23,4]   mass_23   1
    w[23,4]   w_lb_23_4  1
    w[23,4]   w_ub_23_4  1
    w[23,4]   normalized_inventory_23  -4
    w[23,4]   old_normalized_TC  -5.5555555555555580e-02
    w[23,4]   old_normalized_TC2  6.6210317460317460e+00
    w[23,5]   mass_23   1
    w[23,5]   w_lb_23_5  1
    w[23,5]   w_ub_23_5  1
    w[23,5]   normalized_inventory_23  -5
    w[23,5]   old_normalized_TC  -3.0555555555555558e-01
    w[23,5]   old_normalized_TC2  7.3460317460317466e+00
    w[23,6]   mass_23   1
    w[23,6]   w_lb_23_6  1
    w[23,6]   w_ub_23_6  1
    w[23,6]   normalized_inventory_23  -6
    w[23,6]   old_normalized_TC  -5.5555555555555558e-01
    w[23,6]   old_normalized_TC2  7.8519841269841271e+00
    w[23,7]   mass_23   1
    w[23,7]   w_lb_23_7  1
    w[23,7]   w_ub_23_7  1
    w[23,7]   normalized_inventory_23  -7
    w[23,7]   old_normalized_TC  -8.0555555555555558e-01
    w[23,7]   old_normalized_TC2  8.1119047619047624e+00
    w[23,8]   mass_23   1
    w[23,8]   w_lb_23_8  1
    w[23,8]   w_ub_23_8  1
    w[23,8]   normalized_inventory_23  -8
    w[23,8]   old_normalized_TC  -1.0555555555555556e+00
    w[23,8]   old_normalized_TC2  8.1119047619047624e+00
    w[23,9]   mass_23   1
    w[23,9]   w_lb_23_9  1
    w[23,9]   w_ub_23_9  1
    w[23,9]   normalized_inventory_23  -9
    w[23,9]   old_normalized_TC  -1.3536324786324785e+00
    w[23,9]   old_normalized_TC2  8.0638278388278390e+00
    w[23,10]  mass_23   1
    w[23,10]  w_lb_23_10  1
    w[23,10]  w_ub_23_10  1
    w[23,10]  normalized_inventory_23  -10
    w[23,10]  old_normalized_TC  -1.9218142968142966e+00
    w[23,10]  old_normalized_TC2  7.7456460206460207e+00
    w[23,11]  mass_23   1
    w[23,11]  w_lb_23_11  1
    w[23,11]  w_ub_23_11  1
    w[23,11]  normalized_inventory_23  -11
    w[23,11]  old_normalized_TC  -2.7611000111000110e+00
    w[23,11]  old_normalized_TC2  7.1563603063603063e+00
    w[23,12]  mass_23   1
    w[23,12]  w_lb_23_12  1
    w[23,12]  w_ub_23_12  1
    w[23,12]  normalized_inventory_23  -12
    w[23,12]  old_normalized_TC  -3.8325285825285822e+00
    w[23,12]  old_normalized_TC2  6.3349317349317351e+00
    w[23,13]  mass_23   1
    w[23,13]  w_lb_23_13  1
    w[23,13]  w_ub_23_13  1
    w[23,13]  normalized_inventory_23  -13
    w[23,13]  old_normalized_TC  -5.0825285825285818e+00
    w[23,13]  old_normalized_TC2  5.3349317349317351e+00
    w[23,14]  mass_23   1
    w[23,14]  w_lb_23_14  1
    w[23,14]  w_ub_23_14  1
    w[23,14]  normalized_inventory_23  -14
    w[23,14]  old_normalized_TC  -6.4932428682428682e+00
    w[23,14]  old_normalized_TC2  4.1742174492174495e+00
    w[23,15]  mass_23   1
    w[23,15]  w_lb_23_15  1
    w[23,15]  w_ub_23_15  1
    w[23,15]  normalized_inventory_23  -15
    w[23,15]  old_normalized_TC  -8.1499888999889
    w[23,15]  old_normalized_TC2  2.6523920523920519e+00
    w[24,0]   mass_24   1
    w[24,0]   w_lb_24_0  1
    w[24,0]   w_ub_24_0  1
    w[24,1]   mass_24   1
    w[24,1]   w_lb_24_1  1
    w[24,1]   w_ub_24_1  1
    w[24,1]   normalized_inventory_24  -1
    w[24,1]   old_normalized_TC2  3.6428571428571432e+00
    w[24,2]   mass_24   1
    w[24,2]   w_lb_24_2  1
    w[24,2]   w_ub_24_2  1
    w[24,2]   normalized_inventory_24  -2
    w[24,2]   old_normalized_TC  -5.5555555555555580e-02
    w[24,2]   old_normalized_TC2  6.6210317460317460e+00
    w[24,3]   mass_24   1
    w[24,3]   w_lb_24_3  1
    w[24,3]   w_ub_24_3  1
    w[24,3]   normalized_inventory_24  -3
    w[24,3]   old_normalized_TC  -5.5555555555555558e-01
    w[24,3]   old_normalized_TC2  7.8519841269841271e+00
    w[24,4]   mass_24   1
    w[24,4]   w_lb_24_4  1
    w[24,4]   w_ub_24_4  1
    w[24,4]   normalized_inventory_24  -4
    w[24,4]   old_normalized_TC  -1.0555555555555556e+00
    w[24,4]   old_normalized_TC2  8.1119047619047624e+00
    w[24,5]   mass_24   1
    w[24,5]   w_lb_24_5  1
    w[24,5]   w_ub_24_5  1
    w[24,5]   normalized_inventory_24  -5
    w[24,5]   old_normalized_TC  -1.9218142968142966e+00
    w[24,5]   old_normalized_TC2  7.7456460206460207e+00
    w[24,6]   mass_24   1
    w[24,6]   w_lb_24_6  1
    w[24,6]   w_ub_24_6  1
    w[24,6]   normalized_inventory_24  -6
    w[24,6]   old_normalized_TC  -3.8325285825285822e+00
    w[24,6]   old_normalized_TC2  6.3349317349317351e+00
    w[24,7]   mass_24   1
    w[24,7]   w_lb_24_7  1
    w[24,7]   w_ub_24_7  1
    w[24,7]   normalized_inventory_24  -7
    w[24,7]   old_normalized_TC  -6.4932428682428682e+00
    w[24,7]   old_normalized_TC2  4.1742174492174495e+00
    w[24,8]   mass_24   1
    w[24,8]   w_lb_24_8  1
    w[24,8]   w_ub_24_8  1
    w[24,8]   normalized_inventory_24  -8
    w[24,8]   old_normalized_TC  -1.0644433344433343e+01
    w[24,8]   old_normalized_TC2  1.5794760794760729e-01
    w[25,0]   mass_25   1
    w[25,0]   w_lb_25_0  1
    w[25,0]   w_ub_25_0  1
    w[25,1]   mass_25   1
    w[25,1]   w_lb_25_1  1
    w[25,1]   w_ub_25_1  1
    w[25,1]   normalized_inventory_25  -1
    w[25,1]   old_normalized_TC2  2.1428571428571428e+00
    w[25,2]   mass_25   1
    w[25,2]   w_lb_25_2  1
    w[25,2]   w_ub_25_2  1
    w[25,2]   normalized_inventory_25  -2
    w[25,2]   old_normalized_TC2  4.1428571428571432e+00
    w[25,3]   mass_25   1
    w[25,3]   w_lb_25_3  1
    w[25,3]   w_ub_25_3  1
    w[25,3]   normalized_inventory_25  -3
    w[25,3]   old_normalized_TC2  5.9464285714285712e+00
    w[25,4]   mass_25   1
    w[25,4]   w_lb_25_4  1
    w[25,4]   w_ub_25_4  1
    w[25,4]   normalized_inventory_25  -4
    w[25,4]   old_normalized_TC  -1.9841269841269837e-01
    w[25,4]   old_normalized_TC2  7.0496031746031749e+00
    w[25,5]   mass_25   1
    w[25,5]   w_lb_25_5  1
    w[25,5]   w_ub_25_5  1
    w[25,5]   normalized_inventory_25  -5
    w[25,5]   old_normalized_TC  -4.8412698412698407e-01
    w[25,5]   old_normalized_TC2  7.74484126984127
    w[25,6]   mass_25   1
    w[25,6]   w_lb_25_6  1
    w[25,6]   w_ub_25_6  1
    w[25,6]   normalized_inventory_25  -6
    w[25,6]   old_normalized_TC  -7.6984126984126977e-01
    w[25,6]   old_normalized_TC2  8.09404761904762
    w[25,7]   mass_25   1
    w[25,7]   w_lb_25_7  1
    w[25,7]   w_ub_25_7  1
    w[25,7]   normalized_inventory_25  -7
    w[25,7]   old_normalized_TC  -1.0555555555555554e+00
    w[25,7]   old_normalized_TC2  8.1119047619047624e+00
    w[25,8]   mass_25   1
    w[25,8]   w_lb_25_8  1
    w[25,8]   w_ub_25_8  1
    w[25,8]   normalized_inventory_25  -8
    w[25,8]   old_normalized_TC  -1.4250610500610497e+00
    w[25,8]   old_normalized_TC2  8.0281135531135543e+00
    w[25,9]   mass_25   1
    w[25,9]   w_lb_25_9  1
    w[25,9]   w_ub_25_9  1
    w[25,9]   normalized_inventory_25  -9
    w[25,9]   old_normalized_TC  -2.1361000111000106e+00
    w[25,9]   old_normalized_TC2  7.6027888777888784e+00
    w[25,10]  mass_25   1
    w[25,10]  w_lb_25_10  1
    w[25,10]  w_ub_25_10  1
    w[25,10]  normalized_inventory_25  -10
    w[25,10]  old_normalized_TC  -3.1896714396714390e+00
    w[25,10]  old_normalized_TC2  6.8349317349317360e+00
    w[25,11]  mass_25   1
    w[25,11]  w_lb_25_11  1
    w[25,11]  w_ub_25_11  1
    w[25,11]  normalized_inventory_25  -11
    w[25,11]  old_normalized_TC  -4.5468142968142953e+00
    w[25,11]  old_normalized_TC2  5.7635031635031648e+00
    w[25,12]  mass_25   1
    w[25,12]  w_lb_25_12  1
    w[25,12]  w_ub_25_12  1
    w[25,12]  normalized_inventory_25  -12
    w[25,12]  old_normalized_TC  -6.0646714396714385e+00
    w[25,12]  old_normalized_TC2  4.5313603063603072e+00
    w[25,13]  mass_25   1
    w[25,13]  w_lb_25_13  1
    w[25,13]  w_ub_25_13  1
    w[25,13]  normalized_inventory_25  -13
    w[25,13]  old_normalized_TC  -7.8821317571317557e+00
    w[25,13]  old_normalized_TC2  2.9202491952491960e+00
    w[25,14]  mass_25   1
    w[25,14]  w_lb_25_14  1
    w[25,14]  w_ub_25_14  1
    w[25,14]  normalized_inventory_25  -14
    w[25,14]  old_normalized_TC  -1.0644433344433342e+01
    w[25,14]  old_normalized_TC2  1.5794760794760962e-01
    w[25,15]  mass_25   1
    w[25,15]  w_lb_25_15  1
    w[25,15]  w_ub_25_15  1
    w[25,15]  normalized_inventory_25  -15
    w[25,15]  old_normalized_TC  -1.3882528582528579e+01
    w[25,15]  old_normalized_TC2  -3.0801476301476280e+00
    w[26,0]   mass_26   1
    w[26,0]   w_lb_26_0  1
    w[26,0]   w_ub_26_0  1
    w[26,1]   mass_26   1
    w[26,1]   w_lb_26_1  1
    w[26,1]   w_ub_26_1  1
    w[26,1]   normalized_inventory_26  -1
    w[26,1]   old_normalized_TC2  1.875
    w[26,2]   mass_26   1
    w[26,2]   w_lb_26_2  1
    w[26,2]   w_ub_26_2  1
    w[26,2]   normalized_inventory_26  -2
    w[26,2]   old_normalized_TC2  3.6428571428571432e+00
    w[26,3]   mass_26   1
    w[26,3]   w_lb_26_3  1
    w[26,3]   w_ub_26_3  1
    w[26,3]   normalized_inventory_26  -3
    w[26,3]   old_normalized_TC2  5.3035714285714288e+00
    w[26,4]   mass_26   1
    w[26,4]   w_lb_26_4  1
    w[26,4]   w_ub_26_4  1
    w[26,4]   normalized_inventory_26  -4
    w[26,4]   old_normalized_TC  -5.5555555555555580e-02
    w[26,4]   old_normalized_TC2  6.6210317460317460e+00
    w[26,5]   mass_26   1
    w[26,5]   w_lb_26_5  1
    w[26,5]   w_ub_26_5  1
    w[26,5]   normalized_inventory_26  -5
    w[26,5]   old_normalized_TC  -3.0555555555555558e-01
    w[26,5]   old_normalized_TC2  7.3460317460317466e+00
    w[26,6]   mass_26   1
    w[26,6]   w_lb_26_6  1
    w[26,6]   w_ub_26_6  1
    w[26,6]   normalized_inventory_26  -6
    w[26,6]   old_normalized_TC  -5.5555555555555558e-01
    w[26,6]   old_normalized_TC2  7.8519841269841271e+00
    w[26,7]   mass_26   1
    w[26,7]   w_lb_26_7  1
    w[26,7]   w_ub_26_7  1
    w[26,7]   normalized_inventory_26  -7
    w[26,7]   old_normalized_TC  -8.0555555555555558e-01
    w[26,7]   old_normalized_TC2  8.1119047619047624e+00
    w[26,8]   mass_26   1
    w[26,8]   w_lb_26_8  1
    w[26,8]   w_ub_26_8  1
    w[26,8]   normalized_inventory_26  -8
    w[26,8]   old_normalized_TC  -1.0555555555555556e+00
    w[26,8]   old_normalized_TC2  8.1119047619047624e+00
    w[26,9]   mass_26   1
    w[26,9]   w_lb_26_9  1
    w[26,9]   w_ub_26_9  1
    w[26,9]   normalized_inventory_26  -9
    w[26,9]   old_normalized_TC  -1.3536324786324785e+00
    w[26,9]   old_normalized_TC2  8.0638278388278390e+00
    w[26,10]  mass_26   1
    w[26,10]  w_lb_26_10  1
    w[26,10]  w_ub_26_10  1
    w[26,10]  normalized_inventory_26  -10
    w[26,10]  old_normalized_TC  -1.9218142968142966e+00
    w[26,10]  old_normalized_TC2  7.7456460206460207e+00
    w[26,11]  mass_26   1
    w[26,11]  w_lb_26_11  1
    w[26,11]  w_ub_26_11  1
    w[26,11]  normalized_inventory_26  -11
    w[26,11]  old_normalized_TC  -2.7611000111000110e+00
    w[26,11]  old_normalized_TC2  7.1563603063603063e+00
    w[26,12]  mass_26   1
    w[26,12]  w_lb_26_12  1
    w[26,12]  w_ub_26_12  1
    w[26,12]  normalized_inventory_26  -12
    w[26,12]  old_normalized_TC  -3.8325285825285822e+00
    w[26,12]  old_normalized_TC2  6.3349317349317351e+00
    w[26,13]  mass_26   1
    w[26,13]  w_lb_26_13  1
    w[26,13]  w_ub_26_13  1
    w[26,13]  normalized_inventory_26  -13
    w[26,13]  old_normalized_TC  -5.0825285825285818e+00
    w[26,13]  old_normalized_TC2  5.3349317349317351e+00
    w[26,14]  mass_26   1
    w[26,14]  w_lb_26_14  1
    w[26,14]  w_ub_26_14  1
    w[26,14]  normalized_inventory_26  -14
    w[26,14]  old_normalized_TC  -6.4932428682428682e+00
    w[26,14]  old_normalized_TC2  4.1742174492174495e+00
    w[26,15]  mass_26   1
    w[26,15]  w_lb_26_15  1
    w[26,15]  w_ub_26_15  1
    w[26,15]  normalized_inventory_26  -15
    w[26,15]  old_normalized_TC  -8.1499888999889
    w[26,15]  old_normalized_TC2  2.6523920523920519e+00
    w[27,0]   mass_27   1
    w[27,0]   w_lb_27_0  1
    w[27,0]   w_ub_27_0  1
    w[27,1]   mass_27   1
    w[27,1]   w_lb_27_1  1
    w[27,1]   w_ub_27_1  1
    w[27,1]   normalized_inventory_27  -1
    w[27,1]   old_normalized_TC2  1.6666666666666667e+00
    w[27,2]   mass_27   1
    w[27,2]   w_lb_27_2  1
    w[27,2]   w_ub_27_2  1
    w[27,2]   normalized_inventory_27  -2
    w[27,2]   old_normalized_TC2  3.2539682539682540e+00
    w[27,3]   mass_27   1
    w[27,3]   w_lb_27_3  1
    w[27,3]   w_ub_27_3  1
    w[27,3]   normalized_inventory_27  -3
    w[27,3]   old_normalized_TC2  4.7619047619047619e+00
    w[27,4]   mass_27   1
    w[27,4]   w_lb_27_4  1
    w[27,4]   w_ub_27_4  1
    w[27,4]   normalized_inventory_27  -4
    w[27,4]   old_normalized_TC2  6.1210317460317460e+00
    w[27,5]   mass_27   1
    w[27,5]   w_lb_27_5  1
    w[27,5]   w_ub_27_5  1
    w[27,5]   normalized_inventory_27  -5
    w[27,5]   old_normalized_TC  -1.6666666666666663e-01
    w[27,5]   old_normalized_TC2  6.95436507936508
    w[27,6]   mass_27   1
    w[27,6]   w_lb_27_6  1
    w[27,6]   w_ub_27_6  1
    w[27,6]   normalized_inventory_27  -6
    w[27,6]   old_normalized_TC  -3.8888888888888884e-01
    w[27,6]   old_normalized_TC2  7.55436507936508
    w[27,7]   mass_27   1
    w[27,7]   w_lb_27_7  1
    w[27,7]   w_ub_27_7  1
    w[27,7]   normalized_inventory_27  -7
    w[27,7]   old_normalized_TC  -0.611111111111111
    w[27,7]   old_normalized_TC2  7.93531746031746
    w[27,8]   mass_27   1
    w[27,8]   w_lb_27_8  1
    w[27,8]   w_ub_27_8  1
    w[27,8]   normalized_inventory_27  -8
    w[27,8]   old_normalized_TC  -8.3333333333333326e-01
    w[27,8]   old_normalized_TC2  8.1119047619047624e+00
    w[27,9]   mass_27   1
    w[27,9]   w_lb_27_9  1
    w[27,9]   w_ub_27_9  1
    w[27,9]   normalized_inventory_27  -9
    w[27,9]   old_normalized_TC  -1.0555555555555554e+00
    w[27,9]   old_normalized_TC2  8.1119047619047624e+00
    w[27,10]  mass_27   1
    w[27,10]  w_lb_27_10  1
    w[27,10]  w_ub_27_10  1
    w[27,10]  normalized_inventory_27  -10
    w[27,10]  old_normalized_TC  -1.3119658119658117e+00
    w[27,10]  old_normalized_TC2  8.0777167277167283e+00
    w[27,11]  mass_27   1
    w[27,11]  w_lb_27_11  1
    w[27,11]  w_ub_27_11  1
    w[27,11]  normalized_inventory_27  -11
    w[27,11]  old_normalized_TC  -1.7829254079254073e+00
    w[27,11]  old_normalized_TC2  7.8289793539793546e+00
    w[27,12]  mass_27   1
    w[27,12]  w_lb_27_12  1
    w[27,12]  w_ub_27_12  1
    w[27,12]  normalized_inventory_27  -12
    w[27,12]  old_normalized_TC  -2.4694333444333436e+00
    w[27,12]  old_normalized_TC2  7.36469363969364
    w[27,13]  mass_27   1
    w[27,13]  w_lb_27_13  1
    w[27,13]  w_ub_27_13  1
    w[27,13]  normalized_inventory_27  -13
    w[27,13]  old_normalized_TC  -3.3325285825285818e+00
    w[27,13]  old_normalized_TC2  6.7238206238206244e+00
    w[27,14]  mass_27   1
    w[27,14]  w_lb_27_14  1
    w[27,14]  w_ub_27_14  1
    w[27,14]  normalized_inventory_27  -14
    w[27,14]  old_normalized_TC  -4.3880841380841371e+00
    w[27,14]  old_normalized_TC2  5.8904872904872914e+00
    w[27,15]  mass_27   1
    w[27,15]  w_lb_27_15  1
    w[27,15]  w_ub_27_15  1
    w[27,15]  normalized_inventory_27  -15
    w[27,15]  old_normalized_TC  -5.5408619158619148e+00
    w[27,15]  old_normalized_TC2  4.9599317349317360e+00
    w[27,16]  mass_27   1
    w[27,16]  w_lb_27_16  1
    w[27,16]  w_ub_27_16  1
    w[27,16]  normalized_inventory_27  -16
    w[27,16]  old_normalized_TC  -6.8265762015762
    w[27,16]  old_normalized_TC2  3.8964396714396723e+00
    w[27,17]  mass_27   1
    w[27,17]  w_lb_27_17  1
    w[27,17]  w_ub_27_17  1
    w[27,17]  normalized_inventory_27  -17
    w[27,17]  old_normalized_TC  -8.37221112221112
    w[27,17]  old_normalized_TC2  2.4301698301698313e+00
    w[27,18]  mass_27   1
    w[27,18]  w_lb_27_18  1
    w[27,18]  w_ub_27_18  1
    w[27,18]  normalized_inventory_27  -18
    w[27,18]  old_normalized_TC  -1.0644433344433342e+01
    w[27,18]  old_normalized_TC2  1.5794760794760962e-01
    w[27,19]  mass_27   1
    w[27,19]  w_lb_27_19  1
    w[27,19]  w_ub_27_19  1
    w[27,19]  normalized_inventory_27  -19
    w[27,19]  old_normalized_TC  -1.3088877788877786e+01
    w[27,19]  old_normalized_TC2  -2.2864968364968346e+00
    w[28,0]   mass_28   1
    w[28,0]   w_lb_28_0  1
    w[28,0]   w_ub_28_0  1
    w[28,1]   mass_28   1
    w[28,1]   w_lb_28_1  1
    w[28,1]   w_ub_28_1  1
    w[28,1]   normalized_inventory_28  -1
    w[28,1]   old_normalized_TC2  2.1428571428571428e+00
    w[28,2]   mass_28   1
    w[28,2]   w_lb_28_2  1
    w[28,2]   w_ub_28_2  1
    w[28,2]   normalized_inventory_28  -2
    w[28,2]   old_normalized_TC2  4.1428571428571432e+00
    w[28,3]   mass_28   1
    w[28,3]   w_lb_28_3  1
    w[28,3]   w_ub_28_3  1
    w[28,3]   normalized_inventory_28  -3
    w[28,3]   old_normalized_TC2  5.9464285714285712e+00
    w[28,4]   mass_28   1
    w[28,4]   w_lb_28_4  1
    w[28,4]   w_ub_28_4  1
    w[28,4]   normalized_inventory_28  -4
    w[28,4]   old_normalized_TC  -1.9841269841269837e-01
    w[28,4]   old_normalized_TC2  7.0496031746031749e+00
    w[28,5]   mass_28   1
    w[28,5]   w_lb_28_5  1
    w[28,5]   w_ub_28_5  1
    w[28,5]   normalized_inventory_28  -5
    w[28,5]   old_normalized_TC  -4.8412698412698407e-01
    w[28,5]   old_normalized_TC2  7.74484126984127
    w[28,6]   mass_28   1
    w[28,6]   w_lb_28_6  1
    w[28,6]   w_ub_28_6  1
    w[28,6]   normalized_inventory_28  -6
    w[28,6]   old_normalized_TC  -7.6984126984126977e-01
    w[28,6]   old_normalized_TC2  8.09404761904762
    w[28,7]   mass_28   1
    w[28,7]   w_lb_28_7  1
    w[28,7]   w_ub_28_7  1
    w[28,7]   normalized_inventory_28  -7
    w[28,7]   old_normalized_TC  -1.0555555555555554e+00
    w[28,7]   old_normalized_TC2  8.1119047619047624e+00
    w[28,8]   mass_28   1
    w[28,8]   w_lb_28_8  1
    w[28,8]   w_ub_28_8  1
    w[28,8]   normalized_inventory_28  -8
    w[28,8]   old_normalized_TC  -1.4250610500610497e+00
    w[28,8]   old_normalized_TC2  8.0281135531135543e+00
    w[28,9]   mass_28   1
    w[28,9]   w_lb_28_9  1
    w[28,9]   w_ub_28_9  1
    w[28,9]   normalized_inventory_28  -9
    w[28,9]   old_normalized_TC  -2.1361000111000106e+00
    w[28,9]   old_normalized_TC2  7.6027888777888784e+00
    w[28,10]  mass_28   1
    w[28,10]  w_lb_28_10  1
    w[28,10]  w_ub_28_10  1
    w[28,10]  normalized_inventory_28  -10
    w[28,10]  old_normalized_TC  -3.1896714396714390e+00
    w[28,10]  old_normalized_TC2  6.8349317349317360e+00
    w[28,11]  mass_28   1
    w[28,11]  w_lb_28_11  1
    w[28,11]  w_ub_28_11  1
    w[28,11]  normalized_inventory_28  -11
    w[28,11]  old_normalized_TC  -4.5468142968142953e+00
    w[28,11]  old_normalized_TC2  5.7635031635031648e+00
    w[28,12]  mass_28   1
    w[28,12]  w_lb_28_12  1
    w[28,12]  w_ub_28_12  1
    w[28,12]  normalized_inventory_28  -12
    w[28,12]  old_normalized_TC  -6.0646714396714385e+00
    w[28,12]  old_normalized_TC2  4.5313603063603072e+00
    w[28,13]  mass_28   1
    w[28,13]  w_lb_28_13  1
    w[28,13]  w_ub_28_13  1
    w[28,13]  normalized_inventory_28  -13
    w[28,13]  old_normalized_TC  -7.8821317571317557e+00
    w[28,13]  old_normalized_TC2  2.9202491952491960e+00
    w[28,14]  mass_28   1
    w[28,14]  w_lb_28_14  1
    w[28,14]  w_ub_28_14  1
    w[28,14]  normalized_inventory_28  -14
    w[28,14]  old_normalized_TC  -1.0644433344433342e+01
    w[28,14]  old_normalized_TC2  1.5794760794760962e-01
    w[28,15]  mass_28   1
    w[28,15]  w_lb_28_15  1
    w[28,15]  w_ub_28_15  1
    w[28,15]  normalized_inventory_28  -15
    w[28,15]  old_normalized_TC  -1.3882528582528579e+01
    w[28,15]  old_normalized_TC2  -3.0801476301476280e+00
    w[29,0]   mass_29   1
    w[29,0]   w_lb_29_0  1
    w[29,0]   w_ub_29_0  1
    w[29,1]   mass_29   1
    w[29,1]   w_lb_29_1  1
    w[29,1]   w_ub_29_1  1
    w[29,1]   normalized_inventory_29  -1
    w[29,1]   old_normalized_TC2  2.1428571428571428e+00
    w[29,2]   mass_29   1
    w[29,2]   w_lb_29_2  1
    w[29,2]   w_ub_29_2  1
    w[29,2]   normalized_inventory_29  -2
    w[29,2]   old_normalized_TC2  4.1428571428571432e+00
    w[29,3]   mass_29   1
    w[29,3]   w_lb_29_3  1
    w[29,3]   w_ub_29_3  1
    w[29,3]   normalized_inventory_29  -3
    w[29,3]   old_normalized_TC2  5.9464285714285712e+00
    w[29,4]   mass_29   1
    w[29,4]   w_lb_29_4  1
    w[29,4]   w_ub_29_4  1
    w[29,4]   normalized_inventory_29  -4
    w[29,4]   old_normalized_TC  -1.9841269841269837e-01
    w[29,4]   old_normalized_TC2  7.0496031746031749e+00
    w[29,5]   mass_29   1
    w[29,5]   w_lb_29_5  1
    w[29,5]   w_ub_29_5  1
    w[29,5]   normalized_inventory_29  -5
    w[29,5]   old_normalized_TC  -4.8412698412698407e-01
    w[29,5]   old_normalized_TC2  7.74484126984127
    w[29,6]   mass_29   1
    w[29,6]   w_lb_29_6  1
    w[29,6]   w_ub_29_6  1
    w[29,6]   normalized_inventory_29  -6
    w[29,6]   old_normalized_TC  -7.6984126984126977e-01
    w[29,6]   old_normalized_TC2  8.09404761904762
    w[29,7]   mass_29   1
    w[29,7]   w_lb_29_7  1
    w[29,7]   w_ub_29_7  1
    w[29,7]   normalized_inventory_29  -7
    w[29,7]   old_normalized_TC  -1.0555555555555554e+00
    w[29,7]   old_normalized_TC2  8.1119047619047624e+00
    w[29,8]   mass_29   1
    w[29,8]   w_lb_29_8  1
    w[29,8]   w_ub_29_8  1
    w[29,8]   normalized_inventory_29  -8
    w[29,8]   old_normalized_TC  -1.4250610500610497e+00
    w[29,8]   old_normalized_TC2  8.0281135531135543e+00
    w[29,9]   mass_29   1
    w[29,9]   w_lb_29_9  1
    w[29,9]   w_ub_29_9  1
    w[29,9]   normalized_inventory_29  -9
    w[29,9]   old_normalized_TC  -2.1361000111000106e+00
    w[29,9]   old_normalized_TC2  7.6027888777888784e+00
    w[29,10]  mass_29   1
    w[29,10]  w_lb_29_10  1
    w[29,10]  w_ub_29_10  1
    w[29,10]  normalized_inventory_29  -10
    w[29,10]  old_normalized_TC  -3.1896714396714390e+00
    w[29,10]  old_normalized_TC2  6.8349317349317360e+00
    w[29,11]  mass_29   1
    w[29,11]  w_lb_29_11  1
    w[29,11]  w_ub_29_11  1
    w[29,11]  normalized_inventory_29  -11
    w[29,11]  old_normalized_TC  -4.5468142968142953e+00
    w[29,11]  old_normalized_TC2  5.7635031635031648e+00
    w[29,12]  mass_29   1
    w[29,12]  w_lb_29_12  1
    w[29,12]  w_ub_29_12  1
    w[29,12]  normalized_inventory_29  -12
    w[29,12]  old_normalized_TC  -6.0646714396714385e+00
    w[29,12]  old_normalized_TC2  4.5313603063603072e+00
    w[29,13]  mass_29   1
    w[29,13]  w_lb_29_13  1
    w[29,13]  w_ub_29_13  1
    w[29,13]  normalized_inventory_29  -13
    w[29,13]  old_normalized_TC  -7.8821317571317557e+00
    w[29,13]  old_normalized_TC2  2.9202491952491960e+00
    w[29,14]  mass_29   1
    w[29,14]  w_lb_29_14  1
    w[29,14]  w_ub_29_14  1
    w[29,14]  normalized_inventory_29  -14
    w[29,14]  old_normalized_TC  -1.0644433344433342e+01
    w[29,14]  old_normalized_TC2  1.5794760794760962e-01
    w[29,15]  mass_29   1
    w[29,15]  w_lb_29_15  1
    w[29,15]  w_ub_29_15  1
    w[29,15]  normalized_inventory_29  -15
    w[29,15]  old_normalized_TC  -1.3882528582528579e+01
    w[29,15]  old_normalized_TC2  -3.0801476301476280e+00
    w[30,0]   mass_30   1
    w[30,0]   w_lb_30_0  1
    w[30,0]   w_ub_30_0  1
    w[30,1]   mass_30   1
    w[30,1]   w_lb_30_1  1
    w[30,1]   w_ub_30_1  1
    w[30,1]   normalized_inventory_30  -1
    w[30,1]   old_normalized_TC2  1.3636363636363638e+00
    w[30,2]   mass_30   1
    w[30,2]   w_lb_30_2  1
    w[30,2]   w_ub_30_2  1
    w[30,2]   normalized_inventory_30  -2
    w[30,2]   old_normalized_TC2  2.6883116883116887e+00
    w[30,3]   mass_30   1
    w[30,3]   w_lb_30_3  1
    w[30,3]   w_ub_30_3  1
    w[30,3]   normalized_inventory_30  -3
    w[30,3]   old_normalized_TC2  3.9610389610389611e+00
    w[30,4]   mass_30   1
    w[30,4]   w_lb_30_4  1
    w[30,4]   w_ub_30_4  1
    w[30,4]   normalized_inventory_30  -4
    w[30,4]   old_normalized_TC2  5.1558441558441563e+00
    w[30,5]   mass_30   1
    w[30,5]   w_lb_30_5  1
    w[30,5]   w_ub_30_5  1
    w[30,5]   normalized_inventory_30  -5
    w[30,5]   old_normalized_TC  -1.0101010101010138e-02
    w[30,5]   old_normalized_TC2  6.2119408369408378e+00
    w[30,6]   mass_30   1
    w[30,6]   w_lb_30_6  1
    w[30,6]   w_ub_30_6  1
    w[30,6]   normalized_inventory_30  -6
    w[30,6]   old_normalized_TC  -1.4646464646464652e-01
    w[30,6]   old_normalized_TC2  6.8937590187590194e+00
    w[30,7]   mass_30   1
    w[30,7]   w_lb_30_7  1
    w[30,7]   w_ub_30_7  1
    w[30,7]   normalized_inventory_30  -7
    w[30,7]   old_normalized_TC  -3.2828282828282834e-01
    w[30,7]   old_normalized_TC2  7.4028499278499282e+00
    w[30,8]   mass_30   1
    w[30,8]   w_lb_30_8  1
    w[30,8]   w_ub_30_8  1
    w[30,8]   normalized_inventory_30  -8
    w[30,8]   old_normalized_TC  -5.1010101010101017e-01
    w[30,8]   old_normalized_TC2  7.78380230880231
    w[30,9]   mass_30   1
    w[30,9]   w_lb_30_9  1
    w[30,9]   w_ub_30_9  1
    w[30,9]   normalized_inventory_30  -9
    w[30,9]   old_normalized_TC  -6.9191919191919193e-01
    w[30,9]   old_normalized_TC2  8.0161255411255414e+00
    w[30,10]  mass_30   1
    w[30,10]  w_lb_30_10  1
    w[30,10]  w_ub_30_10  1
    w[30,10]  normalized_inventory_30  -10
    w[30,10]  old_normalized_TC  -8.7373737373737381e-01
    w[30,10]  old_normalized_TC2  8.1119047619047624e+00
    w[30,11]  mass_30   1
    w[30,11]  w_lb_30_11  1
    w[30,11]  w_ub_30_11  1
    w[30,11]  normalized_inventory_30  -11
    w[30,11]  old_normalized_TC  -1.0555555555555556e+00
    w[30,11]  old_normalized_TC2  8.1119047619047624e+00
    w[30,12]  mass_30   1
    w[30,12]  w_lb_30_12  1
    w[30,12]  w_ub_30_12  1
    w[30,12]  normalized_inventory_30  -12
    w[30,12]  old_normalized_TC  -1.2513597513597514e+00
    w[30,12]  old_normalized_TC2  8.0979187479187491e+00
    w[30,13]  mass_30   1
    w[30,13]  w_lb_30_13  1
    w[30,13]  w_ub_30_13  1
    w[30,13]  normalized_inventory_30  -13
    w[30,13]  old_normalized_TC  -1.5809052059052060e+00
    w[30,13]  old_normalized_TC2  7.9501914751914757e+00
    w[30,14]  mass_30   1
    w[30,14]  w_lb_30_14  1
    w[30,14]  w_ub_30_14  1
    w[30,14]  normalized_inventory_30  -14
    w[30,14]  old_normalized_TC  -2.0581779331779333e+00
    w[30,14]  old_normalized_TC2  7.65473692973693
    w[30,15]  mass_30   1
    w[30,15]  w_lb_30_15  1
    w[30,15]  w_ub_30_15  1
    w[30,15]  normalized_inventory_30  -15
    w[30,15]  old_normalized_TC  -2.6815545565545564e+00
    w[30,15]  old_normalized_TC2  7.2131784881784879e+00
    w[30,16]  mass_30   1
    w[30,16]  w_lb_30_16  1
    w[30,16]  w_ub_30_16  1
    w[30,16]  normalized_inventory_30  -16
    w[30,16]  old_normalized_TC  -3.4234376734376735e+00
    w[30,16]  old_normalized_TC2  6.6531135531135526e+00
    w[30,17]  mass_30   1
    w[30,17]  w_lb_30_17  1
    w[30,17]  w_ub_30_17  1
    w[30,17]  normalized_inventory_30  -17
    w[30,17]  old_normalized_TC  -4.2870740370740368e+00
    w[30,17]  old_normalized_TC2  5.9712953712953709e+00
    w[30,18]  mass_30   1
    w[30,18]  w_lb_30_18  1
    w[30,18]  w_ub_30_18  1
    w[30,18]  normalized_inventory_30  -18
    w[30,18]  old_normalized_TC  -5.2075285825285826e+00
    w[30,18]  old_normalized_TC2  5.2326590076590076e+00
    w[30,19]  mass_30   1
    w[30,19]  w_lb_30_19  1
    w[30,19]  w_ub_30_19  1
    w[30,19]  normalized_inventory_30  -19
    w[30,19]  old_normalized_TC  -6.2205155955155957e+00
    w[30,19]  old_normalized_TC2  4.4014901764901762e+00
    w[30,20]  mass_30   1
    w[30,20]  w_lb_30_20  1
    w[30,20]  w_ub_30_20  1
    w[30,20]  normalized_inventory_30  -20
    w[30,20]  old_normalized_TC  -7.3518287268287272e+00
    w[30,20]  old_normalized_TC2  3.4115911865911857e+00
    w[31,0]   mass_31   1
    w[31,0]   w_lb_31_0  1
    w[31,0]   w_ub_31_0  1
    w[31,1]   mass_31   1
    w[31,1]   w_lb_31_1  1
    w[31,1]   w_ub_31_1  1
    w[31,1]   normalized_inventory_31  -1
    w[31,1]   old_normalized_TC2  2.1428571428571428e+00
    w[31,2]   mass_31   1
    w[31,2]   w_lb_31_2  1
    w[31,2]   w_ub_31_2  1
    w[31,2]   normalized_inventory_31  -2
    w[31,2]   old_normalized_TC2  4.1428571428571432e+00
    w[31,3]   mass_31   1
    w[31,3]   w_lb_31_3  1
    w[31,3]   w_ub_31_3  1
    w[31,3]   normalized_inventory_31  -3
    w[31,3]   old_normalized_TC2  5.9464285714285712e+00
    w[31,4]   mass_31   1
    w[31,4]   w_lb_31_4  1
    w[31,4]   w_ub_31_4  1
    w[31,4]   normalized_inventory_31  -4
    w[31,4]   old_normalized_TC  -1.9841269841269837e-01
    w[31,4]   old_normalized_TC2  7.0496031746031749e+00
    w[31,5]   mass_31   1
    w[31,5]   w_lb_31_5  1
    w[31,5]   w_ub_31_5  1
    w[31,5]   normalized_inventory_31  -5
    w[31,5]   old_normalized_TC  -4.8412698412698407e-01
    w[31,5]   old_normalized_TC2  7.74484126984127
    w[31,6]   mass_31   1
    w[31,6]   w_lb_31_6  1
    w[31,6]   w_ub_31_6  1
    w[31,6]   normalized_inventory_31  -6
    w[31,6]   old_normalized_TC  -7.6984126984126977e-01
    w[31,6]   old_normalized_TC2  8.09404761904762
    w[31,7]   mass_31   1
    w[31,7]   w_lb_31_7  1
    w[31,7]   w_ub_31_7  1
    w[31,7]   normalized_inventory_31  -7
    w[31,7]   old_normalized_TC  -1.0555555555555554e+00
    w[31,7]   old_normalized_TC2  8.1119047619047624e+00
    w[31,8]   mass_31   1
    w[31,8]   w_lb_31_8  1
    w[31,8]   w_ub_31_8  1
    w[31,8]   normalized_inventory_31  -8
    w[31,8]   old_normalized_TC  -1.4250610500610497e+00
    w[31,8]   old_normalized_TC2  8.0281135531135543e+00
    w[31,9]   mass_31   1
    w[31,9]   w_lb_31_9  1
    w[31,9]   w_ub_31_9  1
    w[31,9]   normalized_inventory_31  -9
    w[31,9]   old_normalized_TC  -2.1361000111000106e+00
    w[31,9]   old_normalized_TC2  7.6027888777888784e+00
    w[31,10]  mass_31   1
    w[31,10]  w_lb_31_10  1
    w[31,10]  w_ub_31_10  1
    w[31,10]  normalized_inventory_31  -10
    w[31,10]  old_normalized_TC  -3.1896714396714390e+00
    w[31,10]  old_normalized_TC2  6.8349317349317360e+00
    w[31,11]  mass_31   1
    w[31,11]  w_lb_31_11  1
    w[31,11]  w_ub_31_11  1
    w[31,11]  normalized_inventory_31  -11
    w[31,11]  old_normalized_TC  -4.5468142968142953e+00
    w[31,11]  old_normalized_TC2  5.7635031635031648e+00
    w[31,12]  mass_31   1
    w[31,12]  w_lb_31_12  1
    w[31,12]  w_ub_31_12  1
    w[31,12]  normalized_inventory_31  -12
    w[31,12]  old_normalized_TC  -6.0646714396714385e+00
    w[31,12]  old_normalized_TC2  4.5313603063603072e+00
    w[31,13]  mass_31   1
    w[31,13]  w_lb_31_13  1
    w[31,13]  w_ub_31_13  1
    w[31,13]  normalized_inventory_31  -13
    w[31,13]  old_normalized_TC  -7.8821317571317557e+00
    w[31,13]  old_normalized_TC2  2.9202491952491960e+00
    w[31,14]  mass_31   1
    w[31,14]  w_lb_31_14  1
    w[31,14]  w_ub_31_14  1
    w[31,14]  normalized_inventory_31  -14
    w[31,14]  old_normalized_TC  -1.0644433344433342e+01
    w[31,14]  old_normalized_TC2  1.5794760794760962e-01
    w[31,15]  mass_31   1
    w[31,15]  w_lb_31_15  1
    w[31,15]  w_ub_31_15  1
    w[31,15]  normalized_inventory_31  -15
    w[31,15]  old_normalized_TC  -1.3882528582528579e+01
    w[31,15]  old_normalized_TC2  -3.0801476301476280e+00
    w[32,0]   mass_32   1
    w[32,0]   w_lb_32_0  1
    w[32,0]   w_ub_32_0  1
    w[32,1]   mass_32   1
    w[32,1]   w_lb_32_1  1
    w[32,1]   w_ub_32_1  1
    w[32,1]   normalized_inventory_32  -1
    w[32,1]   old_normalized_TC2  1.875
    w[32,2]   mass_32   1
    w[32,2]   w_lb_32_2  1
    w[32,2]   w_ub_32_2  1
    w[32,2]   normalized_inventory_32  -2
    w[32,2]   old_normalized_TC2  3.6428571428571432e+00
    w[32,3]   mass_32   1
    w[32,3]   w_lb_32_3  1
    w[32,3]   w_ub_32_3  1
    w[32,3]   normalized_inventory_32  -3
    w[32,3]   old_normalized_TC2  5.3035714285714288e+00
    w[32,4]   mass_32   1
    w[32,4]   w_lb_32_4  1
    w[32,4]   w_ub_32_4  1
    w[32,4]   normalized_inventory_32  -4
    w[32,4]   old_normalized_TC  -5.5555555555555580e-02
    w[32,4]   old_normalized_TC2  6.6210317460317460e+00
    w[32,5]   mass_32   1
    w[32,5]   w_lb_32_5  1
    w[32,5]   w_ub_32_5  1
    w[32,5]   normalized_inventory_32  -5
    w[32,5]   old_normalized_TC  -3.0555555555555558e-01
    w[32,5]   old_normalized_TC2  7.3460317460317466e+00
    w[32,6]   mass_32   1
    w[32,6]   w_lb_32_6  1
    w[32,6]   w_ub_32_6  1
    w[32,6]   normalized_inventory_32  -6
    w[32,6]   old_normalized_TC  -5.5555555555555558e-01
    w[32,6]   old_normalized_TC2  7.8519841269841271e+00
    w[32,7]   mass_32   1
    w[32,7]   w_lb_32_7  1
    w[32,7]   w_ub_32_7  1
    w[32,7]   normalized_inventory_32  -7
    w[32,7]   old_normalized_TC  -8.0555555555555558e-01
    w[32,7]   old_normalized_TC2  8.1119047619047624e+00
    w[32,8]   mass_32   1
    w[32,8]   w_lb_32_8  1
    w[32,8]   w_ub_32_8  1
    w[32,8]   normalized_inventory_32  -8
    w[32,8]   old_normalized_TC  -1.0555555555555556e+00
    w[32,8]   old_normalized_TC2  8.1119047619047624e+00
    w[32,9]   mass_32   1
    w[32,9]   w_lb_32_9  1
    w[32,9]   w_ub_32_9  1
    w[32,9]   normalized_inventory_32  -9
    w[32,9]   old_normalized_TC  -1.3536324786324785e+00
    w[32,9]   old_normalized_TC2  8.0638278388278390e+00
    w[32,10]  mass_32   1
    w[32,10]  w_lb_32_10  1
    w[32,10]  w_ub_32_10  1
    w[32,10]  normalized_inventory_32  -10
    w[32,10]  old_normalized_TC  -1.9218142968142966e+00
    w[32,10]  old_normalized_TC2  7.7456460206460207e+00
    w[32,11]  mass_32   1
    w[32,11]  w_lb_32_11  1
    w[32,11]  w_ub_32_11  1
    w[32,11]  normalized_inventory_32  -11
    w[32,11]  old_normalized_TC  -2.7611000111000110e+00
    w[32,11]  old_normalized_TC2  7.1563603063603063e+00
    w[32,12]  mass_32   1
    w[32,12]  w_lb_32_12  1
    w[32,12]  w_ub_32_12  1
    w[32,12]  normalized_inventory_32  -12
    w[32,12]  old_normalized_TC  -3.8325285825285822e+00
    w[32,12]  old_normalized_TC2  6.3349317349317351e+00
    w[32,13]  mass_32   1
    w[32,13]  w_lb_32_13  1
    w[32,13]  w_ub_32_13  1
    w[32,13]  normalized_inventory_32  -13
    w[32,13]  old_normalized_TC  -5.0825285825285818e+00
    w[32,13]  old_normalized_TC2  5.3349317349317351e+00
    w[32,14]  mass_32   1
    w[32,14]  w_lb_32_14  1
    w[32,14]  w_ub_32_14  1
    w[32,14]  normalized_inventory_32  -14
    w[32,14]  old_normalized_TC  -6.4932428682428682e+00
    w[32,14]  old_normalized_TC2  4.1742174492174495e+00
    w[32,15]  mass_32   1
    w[32,15]  w_lb_32_15  1
    w[32,15]  w_ub_32_15  1
    w[32,15]  normalized_inventory_32  -15
    w[32,15]  old_normalized_TC  -8.1499888999889
    w[32,15]  old_normalized_TC2  2.6523920523920519e+00
    w[33,0]   mass_33   1
    w[33,0]   w_lb_33_0  1
    w[33,0]   w_ub_33_0  1
    w[33,1]   mass_33   1
    w[33,1]   w_lb_33_1  1
    w[33,1]   w_ub_33_1  1
    w[33,1]   normalized_inventory_33  -1
    w[33,1]   old_normalized_TC2  1.1538461538461540e+00
    w[33,2]   mass_33   1
    w[33,2]   w_lb_33_2  1
    w[33,2]   w_ub_33_2  1
    w[33,2]   normalized_inventory_33  -2
    w[33,2]   old_normalized_TC2  2.2967032967032970e+00
    w[33,3]   mass_33   1
    w[33,3]   w_lb_33_3  1
    w[33,3]   w_ub_33_3  1
    w[33,3]   normalized_inventory_33  -3
    w[33,3]   old_normalized_TC2  3.3736263736263741e+00
    w[33,4]   mass_33   1
    w[33,4]   w_lb_33_4  1
    w[33,4]   w_ub_33_4  1
    w[33,4]   normalized_inventory_33  -4
    w[33,4]   old_normalized_TC2  4.4285714285714288e+00
    w[33,5]   mass_33   1
    w[33,5]   w_lb_33_5  1
    w[33,5]   w_ub_33_5  1
    w[33,5]   normalized_inventory_33  -5
    w[33,5]   old_normalized_TC2  5.4189560439560447e+00
    w[33,6]   mass_33   1
    w[33,6]   w_lb_33_6  1
    w[33,6]   w_ub_33_6  1
    w[33,6]   normalized_inventory_33  -6
    w[33,6]   old_normalized_TC  -1.7094017094017144e-02
    w[33,6]   old_normalized_TC2  6.2748778998779
    w[33,7]   mass_33   1
    w[33,7]   w_lb_33_7  1
    w[33,7]   w_ub_33_7  1
    w[33,7]   normalized_inventory_33  -7
    w[33,7]   old_normalized_TC  -1.3247863247863256e-01
    w[33,7]   old_normalized_TC2  6.8518009768009778e+00
    w[33,8]   mass_33   1
    w[33,8]   w_lb_33_8  1
    w[33,8]   w_ub_33_8  1
    w[33,8]   normalized_inventory_33  -8
    w[33,8]   old_normalized_TC  -2.8632478632478642e-01
    w[33,8]   old_normalized_TC2  7.2979548229548232e+00
    w[33,9]   mass_33   1
    w[33,9]   w_lb_33_9  1
    w[33,9]   w_ub_33_9  1
    w[33,9]   normalized_inventory_33  -9
    w[33,9]   old_normalized_TC  -4.4017094017094027e-01
    w[33,9]   old_normalized_TC2  7.6569291819291827e+00
    w[33,10]  mass_33   1
    w[33,10]  w_lb_33_10  1
    w[33,10]  w_ub_33_10  1
    w[33,10]  normalized_inventory_33  -10
    w[33,10]  old_normalized_TC  -5.9401709401709413e-01
    w[33,10]  old_normalized_TC2  7.9096764346764354e+00
    w[33,11]  mass_33   1
    w[33,11]  w_lb_33_11  1
    w[33,11]  w_ub_33_11  1
    w[33,11]  normalized_inventory_33  -11
    w[33,11]  old_normalized_TC  -0.747863247863248
    w[33,11]  old_normalized_TC2  8.0720695970695981e+00
    w[33,12]  mass_33   1
    w[33,12]  w_lb_33_12  1
    w[33,12]  w_ub_33_12  1
    w[33,12]  normalized_inventory_33  -12
    w[33,12]  old_normalized_TC  -9.0170940170940184e-01
    w[33,12]  old_normalized_TC2  8.1119047619047624e+00
    w[33,13]  mass_33   1
    w[33,13]  w_lb_33_13  1
    w[33,13]  w_ub_33_13  1
    w[33,13]  normalized_inventory_33  -13
    w[33,13]  old_normalized_TC  -1.0555555555555556e+00
    w[33,13]  old_normalized_TC2  8.1119047619047624e+00
    w[33,14]  mass_33   1
    w[33,14]  w_lb_33_14  1
    w[33,14]  w_ub_33_14  1
    w[33,14]  normalized_inventory_33  -14
    w[33,14]  old_normalized_TC  -1.2094017094017095e+00
    w[33,14]  old_normalized_TC2  8.1119047619047624e+00
    w[33,15]  mass_33   1
    w[33,15]  w_lb_33_15  1
    w[33,15]  w_ub_33_15  1
    w[33,15]  normalized_inventory_33  -15
    w[33,15]  old_normalized_TC  -1.4690170940170941e+00
    w[33,15]  old_normalized_TC2  8.0061355311355324e+00
    w[33,16]  mass_33   1
    w[33,16]  w_lb_33_16  1
    w[33,16]  w_ub_33_16  1
    w[33,16]  normalized_inventory_33  -16
    w[33,16]  old_normalized_TC  -1.8256604506604508e+00
    w[33,16]  old_normalized_TC2  7.8033383283383282e+00
    w[33,17]  mass_33   1
    w[33,17]  w_lb_33_17  1
    w[33,17]  w_ub_33_17  1
    w[33,17]  normalized_inventory_33  -17
    w[33,17]  old_normalized_TC  -2.2899461649461652e+00
    w[33,17]  old_normalized_TC2  7.4928987678987680e+00
    w[33,18]  mass_33   1
    w[33,18]  w_lb_33_18  1
    w[33,18]  w_ub_33_18  1
    w[33,18]  normalized_inventory_33  -18
    w[33,18]  old_normalized_TC  -2.8380230880230886e+00
    w[33,18]  old_normalized_TC2  7.0986679986679988e+00
    w[33,19]  mass_33   1
    w[33,19]  w_lb_33_19  1
    w[33,19]  w_ub_33_19  1
    w[33,19]  normalized_inventory_33  -19
    w[33,19]  old_normalized_TC  -3.4863747363747368e+00
    w[33,19]  old_normalized_TC2  6.6041625041625034e+00
    w[33,20]  mass_33   1
    w[33,20]  w_lb_33_20  1
    w[33,20]  w_ub_33_20  1
    w[33,20]  normalized_inventory_33  -20
    w[33,20]  old_normalized_TC  -4.2171439671439677e+00
    w[33,20]  old_normalized_TC2  6.0272394272394267e+00
    w[33,21]  mass_33   1
    w[33,21]  w_lb_33_21  1
    w[33,21]  w_ub_33_21  1
    w[33,21]  normalized_inventory_33  -21
    w[33,21]  old_normalized_TC  -4.9863747363747368e+00
    w[33,21]  old_normalized_TC2  5.4118548118548118e+00
    w[33,22]  mass_33   1
    w[33,22]  w_lb_33_22  1
    w[33,22]  w_ub_33_22  1
    w[33,22]  normalized_inventory_33  -22
    w[33,22]  old_normalized_TC  -5.8229131979131985e+00
    w[33,22]  old_normalized_TC2  4.7291625041625034e+00
    w[33,23]  mass_33   1
    w[33,23]  w_lb_33_23  1
    w[33,23]  w_ub_33_23  1
    w[33,23]  normalized_inventory_33  -23
    w[33,23]  old_normalized_TC  -6.7240120990121
    w[33,23]  old_normalized_TC2  3.9819097569097557e+00
    w[33,24]  mass_33   1
    w[33,24]  w_lb_33_24  1
    w[33,24]  w_ub_33_24  1
    w[33,24]  normalized_inventory_33  -24
    w[33,24]  old_normalized_TC  -7.7282856032856042e+00
    w[33,24]  old_normalized_TC2  3.0631063381063366e+00
    w[34,0]   mass_34   1
    w[34,0]   w_lb_34_0  1
    w[34,0]   w_ub_34_0  1
    w[34,1]   mass_34   1
    w[34,1]   w_lb_34_1  1
    w[34,1]   w_ub_34_1  1
    w[34,1]   normalized_inventory_34  -1
    w[34,1]   old_normalized_TC2  1.875
    w[34,2]   mass_34   1
    w[34,2]   w_lb_34_2  1
    w[34,2]   w_ub_34_2  1
    w[34,2]   normalized_inventory_34  -2
    w[34,2]   old_normalized_TC2  3.6428571428571432e+00
    w[34,3]   mass_34   1
    w[34,3]   w_lb_34_3  1
    w[34,3]   w_ub_34_3  1
    w[34,3]   normalized_inventory_34  -3
    w[34,3]   old_normalized_TC2  5.3035714285714288e+00
    w[34,4]   mass_34   1
    w[34,4]   w_lb_34_4  1
    w[34,4]   w_ub_34_4  1
    w[34,4]   normalized_inventory_34  -4
    w[34,4]   old_normalized_TC  -5.5555555555555580e-02
    w[34,4]   old_normalized_TC2  6.6210317460317460e+00
    w[34,5]   mass_34   1
    w[34,5]   w_lb_34_5  1
    w[34,5]   w_ub_34_5  1
    w[34,5]   normalized_inventory_34  -5
    w[34,5]   old_normalized_TC  -3.0555555555555558e-01
    w[34,5]   old_normalized_TC2  7.3460317460317466e+00
    w[34,6]   mass_34   1
    w[34,6]   w_lb_34_6  1
    w[34,6]   w_ub_34_6  1
    w[34,6]   normalized_inventory_34  -6
    w[34,6]   old_normalized_TC  -5.5555555555555558e-01
    w[34,6]   old_normalized_TC2  7.8519841269841271e+00
    w[34,7]   mass_34   1
    w[34,7]   w_lb_34_7  1
    w[34,7]   w_ub_34_7  1
    w[34,7]   normalized_inventory_34  -7
    w[34,7]   old_normalized_TC  -8.0555555555555558e-01
    w[34,7]   old_normalized_TC2  8.1119047619047624e+00
    w[34,8]   mass_34   1
    w[34,8]   w_lb_34_8  1
    w[34,8]   w_ub_34_8  1
    w[34,8]   normalized_inventory_34  -8
    w[34,8]   old_normalized_TC  -1.0555555555555556e+00
    w[34,8]   old_normalized_TC2  8.1119047619047624e+00
    w[34,9]   mass_34   1
    w[34,9]   w_lb_34_9  1
    w[34,9]   w_ub_34_9  1
    w[34,9]   normalized_inventory_34  -9
    w[34,9]   old_normalized_TC  -1.3536324786324785e+00
    w[34,9]   old_normalized_TC2  8.0638278388278390e+00
    w[34,10]  mass_34   1
    w[34,10]  w_lb_34_10  1
    w[34,10]  w_ub_34_10  1
    w[34,10]  normalized_inventory_34  -10
    w[34,10]  old_normalized_TC  -1.9218142968142966e+00
    w[34,10]  old_normalized_TC2  7.7456460206460207e+00
    w[34,11]  mass_34   1
    w[34,11]  w_lb_34_11  1
    w[34,11]  w_ub_34_11  1
    w[34,11]  normalized_inventory_34  -11
    w[34,11]  old_normalized_TC  -2.7611000111000110e+00
    w[34,11]  old_normalized_TC2  7.1563603063603063e+00
    w[34,12]  mass_34   1
    w[34,12]  w_lb_34_12  1
    w[34,12]  w_ub_34_12  1
    w[34,12]  normalized_inventory_34  -12
    w[34,12]  old_normalized_TC  -3.8325285825285822e+00
    w[34,12]  old_normalized_TC2  6.3349317349317351e+00
    w[34,13]  mass_34   1
    w[34,13]  w_lb_34_13  1
    w[34,13]  w_ub_34_13  1
    w[34,13]  normalized_inventory_34  -13
    w[34,13]  old_normalized_TC  -5.0825285825285818e+00
    w[34,13]  old_normalized_TC2  5.3349317349317351e+00
    w[34,14]  mass_34   1
    w[34,14]  w_lb_34_14  1
    w[34,14]  w_ub_34_14  1
    w[34,14]  normalized_inventory_34  -14
    w[34,14]  old_normalized_TC  -6.4932428682428682e+00
    w[34,14]  old_normalized_TC2  4.1742174492174495e+00
    w[34,15]  mass_34   1
    w[34,15]  w_lb_34_15  1
    w[34,15]  w_ub_34_15  1
    w[34,15]  normalized_inventory_34  -15
    w[34,15]  old_normalized_TC  -8.1499888999889
    w[34,15]  old_normalized_TC2  2.6523920523920519e+00
    w[35,0]   mass_35   1
    w[35,0]   w_lb_35_0  1
    w[35,0]   w_ub_35_0  1
    w[35,1]   mass_35   1
    w[35,1]   w_lb_35_1  1
    w[35,1]   w_ub_35_1  1
    w[35,1]   normalized_inventory_35  -1
    w[35,1]   old_normalized_TC2  1.6666666666666667e+00
    w[35,2]   mass_35   1
    w[35,2]   w_lb_35_2  1
    w[35,2]   w_ub_35_2  1
    w[35,2]   normalized_inventory_35  -2
    w[35,2]   old_normalized_TC2  3.2539682539682540e+00
    w[35,3]   mass_35   1
    w[35,3]   w_lb_35_3  1
    w[35,3]   w_ub_35_3  1
    w[35,3]   normalized_inventory_35  -3
    w[35,3]   old_normalized_TC2  4.7619047619047619e+00
    w[35,4]   mass_35   1
    w[35,4]   w_lb_35_4  1
    w[35,4]   w_ub_35_4  1
    w[35,4]   normalized_inventory_35  -4
    w[35,4]   old_normalized_TC2  6.1210317460317460e+00
    w[35,5]   mass_35   1
    w[35,5]   w_lb_35_5  1
    w[35,5]   w_ub_35_5  1
    w[35,5]   normalized_inventory_35  -5
    w[35,5]   old_normalized_TC  -1.6666666666666663e-01
    w[35,5]   old_normalized_TC2  6.95436507936508
    w[35,6]   mass_35   1
    w[35,6]   w_lb_35_6  1
    w[35,6]   w_ub_35_6  1
    w[35,6]   normalized_inventory_35  -6
    w[35,6]   old_normalized_TC  -3.8888888888888884e-01
    w[35,6]   old_normalized_TC2  7.55436507936508
    w[35,7]   mass_35   1
    w[35,7]   w_lb_35_7  1
    w[35,7]   w_ub_35_7  1
    w[35,7]   normalized_inventory_35  -7
    w[35,7]   old_normalized_TC  -0.611111111111111
    w[35,7]   old_normalized_TC2  7.93531746031746
    w[35,8]   mass_35   1
    w[35,8]   w_lb_35_8  1
    w[35,8]   w_ub_35_8  1
    w[35,8]   normalized_inventory_35  -8
    w[35,8]   old_normalized_TC  -8.3333333333333326e-01
    w[35,8]   old_normalized_TC2  8.1119047619047624e+00
    w[35,9]   mass_35   1
    w[35,9]   w_lb_35_9  1
    w[35,9]   w_ub_35_9  1
    w[35,9]   normalized_inventory_35  -9
    w[35,9]   old_normalized_TC  -1.0555555555555554e+00
    w[35,9]   old_normalized_TC2  8.1119047619047624e+00
    w[35,10]  mass_35   1
    w[35,10]  w_lb_35_10  1
    w[35,10]  w_ub_35_10  1
    w[35,10]  normalized_inventory_35  -10
    w[35,10]  old_normalized_TC  -1.3119658119658117e+00
    w[35,10]  old_normalized_TC2  8.0777167277167283e+00
    w[35,11]  mass_35   1
    w[35,11]  w_lb_35_11  1
    w[35,11]  w_ub_35_11  1
    w[35,11]  normalized_inventory_35  -11
    w[35,11]  old_normalized_TC  -1.7829254079254073e+00
    w[35,11]  old_normalized_TC2  7.8289793539793546e+00
    w[35,12]  mass_35   1
    w[35,12]  w_lb_35_12  1
    w[35,12]  w_ub_35_12  1
    w[35,12]  normalized_inventory_35  -12
    w[35,12]  old_normalized_TC  -2.4694333444333436e+00
    w[35,12]  old_normalized_TC2  7.36469363969364
    w[35,13]  mass_35   1
    w[35,13]  w_lb_35_13  1
    w[35,13]  w_ub_35_13  1
    w[35,13]  normalized_inventory_35  -13
    w[35,13]  old_normalized_TC  -3.3325285825285818e+00
    w[35,13]  old_normalized_TC2  6.7238206238206244e+00
    w[35,14]  mass_35   1
    w[35,14]  w_lb_35_14  1
    w[35,14]  w_ub_35_14  1
    w[35,14]  normalized_inventory_35  -14
    w[35,14]  old_normalized_TC  -4.3880841380841371e+00
    w[35,14]  old_normalized_TC2  5.8904872904872914e+00
    w[35,15]  mass_35   1
    w[35,15]  w_lb_35_15  1
    w[35,15]  w_ub_35_15  1
    w[35,15]  normalized_inventory_35  -15
    w[35,15]  old_normalized_TC  -5.5408619158619148e+00
    w[35,15]  old_normalized_TC2  4.9599317349317360e+00
    w[35,16]  mass_35   1
    w[35,16]  w_lb_35_16  1
    w[35,16]  w_ub_35_16  1
    w[35,16]  normalized_inventory_35  -16
    w[35,16]  old_normalized_TC  -6.8265762015762
    w[35,16]  old_normalized_TC2  3.8964396714396723e+00
    w[35,17]  mass_35   1
    w[35,17]  w_lb_35_17  1
    w[35,17]  w_ub_35_17  1
    w[35,17]  normalized_inventory_35  -17
    w[35,17]  old_normalized_TC  -8.37221112221112
    w[35,17]  old_normalized_TC2  2.4301698301698313e+00
    t         mass_1    -1
    t         mass_2    -1
    t         mass_3    -1
    t         mass_4    -1
    t         mass_5    -1
    t         mass_6    -1
    t         mass_7    -1
    t         mass_8    -1
    t         mass_9    -1
    t         mass_10   -1
    t         mass_11   -1
    t         mass_12   -1
    t         mass_13   -1
    t         mass_14   -1
    t         mass_15   -1
    t         mass_16   -1
    t         mass_17   -1
    t         mass_18   -1
    t         mass_19   -1
    t         mass_20   -1
    t         mass_21   -1
    t         mass_22   -1
    t         mass_23   -1
    t         mass_24   -1
    t         mass_25   -1
    t         mass_26   -1
    t         mass_27   -1
    t         mass_28   -1
    t         mass_29   -1
    t         mass_30   -1
    t         mass_31   -1
    t         mass_32   -1
    t         mass_33   -1
    t         mass_34   -1
    t         mass_35   -1
    t         scaled_stock_lower  -251
    t         scaled_stock_upper  -326
    t         old_normalized_TC2  -3.5994843489843487e+02
    t         old_TS1   -251
    t         old_TS2   -326
    t         old_TS3   -251
    t         old_TS4   -326
    z[1]      normalized_inventory_1  1
    z[1]      normalized_ratio_1  -0.125
    z[1]      scaled_stock_lower  1
    z[1]      scaled_stock_upper  1
    z[1]      old_TS1   1
    z[1]      old_TS2   1
    z[1]      old_TS3   1
    z[1]      old_TS4   1
    z[2]      normalized_inventory_2  1
    z[2]      normalized_ratio_2  -8.3333333333333329e-02
    z[2]      scaled_stock_lower  1
    z[2]      scaled_stock_upper  1
    z[2]      old_TS1   1
    z[2]      old_TS2   1
    z[2]      old_TS3   1
    z[2]      old_TS4   1
    z[3]      normalized_inventory_3  1
    z[3]      normalized_ratio_3  -1.4285714285714285e-01
    z[3]      scaled_stock_lower  1
    z[3]      scaled_stock_upper  1
    z[3]      old_TS1   1
    z[3]      old_TS2   1
    z[3]      old_TS3   1
    z[3]      old_TS4   1
    z[4]      normalized_inventory_4  1
    z[4]      normalized_ratio_4  -1.4285714285714285e-01
    z[4]      scaled_stock_lower  1
    z[4]      scaled_stock_upper  1
    z[4]      old_TS1   1
    z[4]      old_TS2   1
    z[4]      old_TS3   1
    z[4]      old_TS4   1
    z[5]      normalized_inventory_5  1
    z[5]      normalized_ratio_5  -0.125
    z[5]      scaled_stock_lower  1
    z[5]      scaled_stock_upper  1
    z[5]      old_TS1   1
    z[5]      old_TS2   1
    z[5]      old_TS3   1
    z[5]      old_TS4   1
    z[6]      normalized_inventory_6  1
    z[6]      normalized_ratio_6  -1.1111111111111110e-01
    z[6]      scaled_stock_lower  1
    z[6]      scaled_stock_upper  1
    z[6]      old_TS1   1
    z[6]      old_TS2   1
    z[6]      old_TS3   1
    z[6]      old_TS4   1
    z[7]      normalized_inventory_7  1
    z[7]      normalized_ratio_7  -0.1
    z[7]      scaled_stock_lower  1
    z[7]      scaled_stock_upper  1
    z[7]      old_TS1   1
    z[7]      old_TS2   1
    z[7]      old_TS3   1
    z[7]      old_TS4   1
    z[8]      normalized_inventory_8  1
    z[8]      normalized_ratio_8  -1.4285714285714285e-01
    z[8]      scaled_stock_lower  1
    z[8]      scaled_stock_upper  1
    z[8]      old_TS1   1
    z[8]      old_TS2   1
    z[8]      old_TS3   1
    z[8]      old_TS4   1
    z[9]      normalized_inventory_9  1
    z[9]      normalized_ratio_9  -0.1
    z[9]      scaled_stock_lower  1
    z[9]      scaled_stock_upper  1
    z[9]      old_TS1   1
    z[9]      old_TS2   1
    z[9]      old_TS3   1
    z[9]      old_TS4   1
    z[10]     normalized_inventory_10  1
    z[10]     normalized_ratio_10  -1.6666666666666666e-01
    z[10]     scaled_stock_lower  1
    z[10]     scaled_stock_upper  1
    z[10]     old_TS1   1
    z[10]     old_TS2   1
    z[10]     old_TS3   1
    z[10]     old_TS4   1
    z[11]     normalized_inventory_11  1
    z[11]     normalized_ratio_11  -1.4285714285714285e-01
    z[11]     scaled_stock_lower  1
    z[11]     scaled_stock_upper  1
    z[11]     old_TS1   1
    z[11]     old_TS2   1
    z[11]     old_TS3   1
    z[11]     old_TS4   1
    z[12]     normalized_inventory_12  1
    z[12]     normalized_ratio_12  -0.125
    z[12]     scaled_stock_lower  1
    z[12]     scaled_stock_upper  1
    z[12]     old_TS1   1
    z[12]     old_TS2   1
    z[12]     old_TS3   1
    z[12]     old_TS4   1
    z[13]     normalized_inventory_13  1
    z[13]     normalized_ratio_13  -0.1
    z[13]     scaled_stock_lower  1
    z[13]     scaled_stock_upper  1
    z[13]     old_TS1   1
    z[13]     old_TS2   1
    z[13]     old_TS3   1
    z[13]     old_TS4   1
    z[14]     normalized_inventory_14  1
    z[14]     normalized_ratio_14  -0.1
    z[14]     scaled_stock_lower  1
    z[14]     scaled_stock_upper  1
    z[14]     old_TS1   1
    z[14]     old_TS2   1
    z[14]     old_TS3   1
    z[14]     old_TS4   1
    z[15]     normalized_inventory_15  1
    z[15]     normalized_ratio_15  -0.1
    z[15]     scaled_stock_lower  1
    z[15]     scaled_stock_upper  1
    z[15]     old_TS1   1
    z[15]     old_TS2   1
    z[15]     old_TS3   1
    z[15]     old_TS4   1
    z[16]     normalized_inventory_16  1
    z[16]     normalized_ratio_16  -0.2
    z[16]     scaled_stock_lower  1
    z[16]     scaled_stock_upper  1
    z[16]     old_TS1   1
    z[16]     old_TS2   1
    z[16]     old_TS3   1
    z[16]     old_TS4   1
    z[17]     normalized_inventory_17  1
    z[17]     normalized_ratio_17  -1.1111111111111110e-01
    z[17]     scaled_stock_lower  1
    z[17]     scaled_stock_upper  1
    z[17]     old_TS1   1
    z[17]     old_TS2   1
    z[17]     old_TS3   1
    z[17]     old_TS4   1
    z[18]     normalized_inventory_18  1
    z[18]     normalized_ratio_18  -1.4285714285714285e-01
    z[18]     scaled_stock_lower  1
    z[18]     scaled_stock_upper  1
    z[18]     old_TS1   1
    z[18]     old_TS2   1
    z[18]     old_TS3   1
    z[18]     old_TS4   1
    z[19]     normalized_inventory_19  1
    z[19]     normalized_ratio_19  -1.1111111111111110e-01
    z[19]     scaled_stock_lower  1
    z[19]     scaled_stock_upper  1
    z[19]     old_TS1   1
    z[19]     old_TS2   1
    z[19]     old_TS3   1
    z[19]     old_TS4   1
    z[20]     normalized_inventory_20  1
    z[20]     normalized_ratio_20  -1.4285714285714285e-01
    z[20]     scaled_stock_lower  1
    z[20]     scaled_stock_upper  1
    z[20]     old_TS1   1
    z[20]     old_TS2   1
    z[20]     old_TS3   1
    z[20]     old_TS4   1
    z[21]     normalized_inventory_21  1
    z[21]     normalized_ratio_21  -1.1111111111111110e-01
    z[21]     scaled_stock_lower  1
    z[21]     scaled_stock_upper  1
    z[21]     old_TS1   1
    z[21]     old_TS2   1
    z[21]     old_TS3   1
    z[21]     old_TS4   1
    z[22]     normalized_inventory_22  1
    z[22]     normalized_ratio_22  -0.1
    z[22]     scaled_stock_lower  1
    z[22]     scaled_stock_upper  1
    z[22]     old_TS1   1
    z[22]     old_TS2   1
    z[22]     old_TS3   1
    z[22]     old_TS4   1
    z[23]     normalized_inventory_23  1
    z[23]     normalized_ratio_23  -0.125
    z[23]     scaled_stock_lower  1
    z[23]     scaled_stock_upper  1
    z[23]     old_TS1   1
    z[23]     old_TS2   1
    z[23]     old_TS3   1
    z[23]     old_TS4   1
    z[24]     normalized_inventory_24  1
    z[24]     normalized_ratio_24  -0.25
    z[24]     scaled_stock_lower  1
    z[24]     scaled_stock_upper  1
    z[24]     old_TS1   1
    z[24]     old_TS2   1
    z[24]     old_TS3   1
    z[24]     old_TS4   1
    z[25]     normalized_inventory_25  1
    z[25]     normalized_ratio_25  -1.4285714285714285e-01
    z[25]     scaled_stock_lower  1
    z[25]     scaled_stock_upper  1
    z[25]     old_TS1   1
    z[25]     old_TS2   1
    z[25]     old_TS3   1
    z[25]     old_TS4   1
    z[26]     normalized_inventory_26  1
    z[26]     normalized_ratio_26  -0.125
    z[26]     scaled_stock_lower  1
    z[26]     scaled_stock_upper  1
    z[26]     old_TS1   1
    z[26]     old_TS2   1
    z[26]     old_TS3   1
    z[26]     old_TS4   1
    z[27]     normalized_inventory_27  1
    z[27]     normalized_ratio_27  -1.1111111111111110e-01
    z[27]     scaled_stock_lower  1
    z[27]     scaled_stock_upper  1
    z[27]     old_TS1   1
    z[27]     old_TS2   1
    z[27]     old_TS3   1
    z[27]     old_TS4   1
    z[28]     normalized_inventory_28  1
    z[28]     normalized_ratio_28  -1.4285714285714285e-01
    z[28]     scaled_stock_lower  1
    z[28]     scaled_stock_upper  1
    z[28]     old_TS1   1
    z[28]     old_TS2   1
    z[28]     old_TS3   1
    z[28]     old_TS4   1
    z[29]     normalized_inventory_29  1
    z[29]     normalized_ratio_29  -1.4285714285714285e-01
    z[29]     scaled_stock_lower  1
    z[29]     scaled_stock_upper  1
    z[29]     old_TS1   1
    z[29]     old_TS2   1
    z[29]     old_TS3   1
    z[29]     old_TS4   1
    z[30]     normalized_inventory_30  1
    z[30]     normalized_ratio_30  -9.0909090909090912e-02
    z[30]     scaled_stock_lower  1
    z[30]     scaled_stock_upper  1
    z[30]     old_TS1   1
    z[30]     old_TS2   1
    z[30]     old_TS3   1
    z[30]     old_TS4   1
    z[31]     normalized_inventory_31  1
    z[31]     normalized_ratio_31  -1.4285714285714285e-01
    z[31]     scaled_stock_lower  1
    z[31]     scaled_stock_upper  1
    z[31]     old_TS1   1
    z[31]     old_TS2   1
    z[31]     old_TS3   1
    z[31]     old_TS4   1
    z[32]     normalized_inventory_32  1
    z[32]     normalized_ratio_32  -0.125
    z[32]     scaled_stock_lower  1
    z[32]     scaled_stock_upper  1
    z[32]     old_TS1   1
    z[32]     old_TS2   1
    z[32]     old_TS3   1
    z[32]     old_TS4   1
    z[33]     normalized_inventory_33  1
    z[33]     normalized_ratio_33  -7.6923076923076927e-02
    z[33]     scaled_stock_lower  1
    z[33]     scaled_stock_upper  1
    z[33]     old_TS1   1
    z[33]     old_TS2   1
    z[33]     old_TS3   1
    z[33]     old_TS4   1
    z[34]     normalized_inventory_34  1
    z[34]     normalized_ratio_34  -0.125
    z[34]     scaled_stock_lower  1
    z[34]     scaled_stock_upper  1
    z[34]     old_TS1   1
    z[34]     old_TS2   1
    z[34]     old_TS3   1
    z[34]     old_TS4   1
    z[35]     normalized_inventory_35  1
    z[35]     normalized_ratio_35  -1.1111111111111110e-01
    z[35]     scaled_stock_lower  1
    z[35]     scaled_stock_upper  1
    z[35]     old_TS1   1
    z[35]     old_TS2   1
    z[35]     old_TS3   1
    z[35]     old_TS4   1
    r[1]      normalized_ratio_1  1
    r[1]      normalization  1
    r[1]      abs_p_1_2  -1
    r[1]      abs_m_1_2  1
    r[1]      abs_p_1_3  -1
    r[1]      abs_m_1_3  1
    r[1]      abs_p_1_4  -1
    r[1]      abs_m_1_4  1
    r[1]      abs_p_1_5  -1
    r[1]      abs_m_1_5  1
    r[1]      abs_p_1_6  -1
    r[1]      abs_m_1_6  1
    r[1]      abs_p_1_7  -1
    r[1]      abs_m_1_7  1
    r[1]      abs_p_1_8  -1
    r[1]      abs_m_1_8  1
    r[1]      abs_p_1_9  -1
    r[1]      abs_m_1_9  1
    r[1]      abs_p_1_10  -1
    r[1]      abs_m_1_10  1
    r[1]      abs_p_1_11  -1
    r[1]      abs_m_1_11  1
    r[1]      abs_p_1_12  -1
    r[1]      abs_m_1_12  1
    r[1]      abs_p_1_13  -1
    r[1]      abs_m_1_13  1
    r[1]      abs_p_1_14  -1
    r[1]      abs_m_1_14  1
    r[1]      abs_p_1_15  -1
    r[1]      abs_m_1_15  1
    r[1]      abs_p_1_16  -1
    r[1]      abs_m_1_16  1
    r[1]      abs_p_1_17  -1
    r[1]      abs_m_1_17  1
    r[1]      abs_p_1_18  -1
    r[1]      abs_m_1_18  1
    r[1]      abs_p_1_19  -1
    r[1]      abs_m_1_19  1
    r[1]      abs_p_1_20  -1
    r[1]      abs_m_1_20  1
    r[1]      abs_p_1_21  -1
    r[1]      abs_m_1_21  1
    r[1]      abs_p_1_22  -1
    r[1]      abs_m_1_22  1
    r[1]      abs_p_1_23  -1
    r[1]      abs_m_1_23  1
    r[1]      abs_p_1_24  -1
    r[1]      abs_m_1_24  1
    r[1]      abs_p_1_25  -1
    r[1]      abs_m_1_25  1
    r[1]      abs_p_1_26  -1
    r[1]      abs_m_1_26  1
    r[1]      abs_p_1_27  -1
    r[1]      abs_m_1_27  1
    r[1]      abs_p_1_28  -1
    r[1]      abs_m_1_28  1
    r[1]      abs_p_1_29  -1
    r[1]      abs_m_1_29  1
    r[1]      abs_p_1_30  -1
    r[1]      abs_m_1_30  1
    r[1]      abs_p_1_31  -1
    r[1]      abs_m_1_31  1
    r[1]      abs_p_1_32  -1
    r[1]      abs_m_1_32  1
    r[1]      abs_p_1_33  -1
    r[1]      abs_m_1_33  1
    r[1]      abs_p_1_34  -1
    r[1]      abs_m_1_34  1
    r[1]      abs_p_1_35  -1
    r[1]      abs_m_1_35  1
    r[2]      normalized_ratio_2  1
    r[2]      normalization  1
    r[2]      abs_p_1_2  1
    r[2]      abs_m_1_2  -1
    r[2]      abs_p_2_3  -1
    r[2]      abs_m_2_3  1
    r[2]      abs_p_2_4  -1
    r[2]      abs_m_2_4  1
    r[2]      abs_p_2_5  -1
    r[2]      abs_m_2_5  1
    r[2]      abs_p_2_6  -1
    r[2]      abs_m_2_6  1
    r[2]      abs_p_2_7  -1
    r[2]      abs_m_2_7  1
    r[2]      abs_p_2_8  -1
    r[2]      abs_m_2_8  1
    r[2]      abs_p_2_9  -1
    r[2]      abs_m_2_9  1
    r[2]      abs_p_2_10  -1
    r[2]      abs_m_2_10  1
    r[2]      abs_p_2_11  -1
    r[2]      abs_m_2_11  1
    r[2]      abs_p_2_12  -1
    r[2]      abs_m_2_12  1
    r[2]      abs_p_2_13  -1
    r[2]      abs_m_2_13  1
    r[2]      abs_p_2_14  -1
    r[2]      abs_m_2_14  1
    r[2]      abs_p_2_15  -1
    r[2]      abs_m_2_15  1
    r[2]      abs_p_2_16  -1
    r[2]      abs_m_2_16  1
    r[2]      abs_p_2_17  -1
    r[2]      abs_m_2_17  1
    r[2]      abs_p_2_18  -1
    r[2]      abs_m_2_18  1
    r[2]      abs_p_2_19  -1
    r[2]      abs_m_2_19  1
    r[2]      abs_p_2_20  -1
    r[2]      abs_m_2_20  1
    r[2]      abs_p_2_21  -1
    r[2]      abs_m_2_21  1
    r[2]      abs_p_2_22  -1
    r[2]      abs_m_2_22  1
    r[2]      abs_p_2_23  -1
    r[2]      abs_m_2_23  1
    r[2]      abs_p_2_24  -1
    r[2]      abs_m_2_24  1
    r[2]      abs_p_2_25  -1
    r[2]      abs_m_2_25  1
    r[2]      abs_p_2_26  -1
    r[2]      abs_m_2_26  1
    r[2]      abs_p_2_27  -1
    r[2]      abs_m_2_27  1
    r[2]      abs_p_2_28  -1
    r[2]      abs_m_2_28  1
    r[2]      abs_p_2_29  -1
    r[2]      abs_m_2_29  1
    r[2]      abs_p_2_30  -1
    r[2]      abs_m_2_30  1
    r[2]      abs_p_2_31  -1
    r[2]      abs_m_2_31  1
    r[2]      abs_p_2_32  -1
    r[2]      abs_m_2_32  1
    r[2]      abs_p_2_33  -1
    r[2]      abs_m_2_33  1
    r[2]      abs_p_2_34  -1
    r[2]      abs_m_2_34  1
    r[2]      abs_p_2_35  -1
    r[2]      abs_m_2_35  1
    r[3]      normalized_ratio_3  1
    r[3]      normalization  1
    r[3]      abs_p_1_3  1
    r[3]      abs_m_1_3  -1
    r[3]      abs_p_2_3  1
    r[3]      abs_m_2_3  -1
    r[3]      abs_p_3_4  -1
    r[3]      abs_m_3_4  1
    r[3]      abs_p_3_5  -1
    r[3]      abs_m_3_5  1
    r[3]      abs_p_3_6  -1
    r[3]      abs_m_3_6  1
    r[3]      abs_p_3_7  -1
    r[3]      abs_m_3_7  1
    r[3]      abs_p_3_8  -1
    r[3]      abs_m_3_8  1
    r[3]      abs_p_3_9  -1
    r[3]      abs_m_3_9  1
    r[3]      abs_p_3_10  -1
    r[3]      abs_m_3_10  1
    r[3]      abs_p_3_11  -1
    r[3]      abs_m_3_11  1
    r[3]      abs_p_3_12  -1
    r[3]      abs_m_3_12  1
    r[3]      abs_p_3_13  -1
    r[3]      abs_m_3_13  1
    r[3]      abs_p_3_14  -1
    r[3]      abs_m_3_14  1
    r[3]      abs_p_3_15  -1
    r[3]      abs_m_3_15  1
    r[3]      abs_p_3_16  -1
    r[3]      abs_m_3_16  1
    r[3]      abs_p_3_17  -1
    r[3]      abs_m_3_17  1
    r[3]      abs_p_3_18  -1
    r[3]      abs_m_3_18  1
    r[3]      abs_p_3_19  -1
    r[3]      abs_m_3_19  1
    r[3]      abs_p_3_20  -1
    r[3]      abs_m_3_20  1
    r[3]      abs_p_3_21  -1
    r[3]      abs_m_3_21  1
    r[3]      abs_p_3_22  -1
    r[3]      abs_m_3_22  1
    r[3]      abs_p_3_23  -1
    r[3]      abs_m_3_23  1
    r[3]      abs_p_3_24  -1
    r[3]      abs_m_3_24  1
    r[3]      abs_p_3_25  -1
    r[3]      abs_m_3_25  1
    r[3]      abs_p_3_26  -1
    r[3]      abs_m_3_26  1
    r[3]      abs_p_3_27  -1
    r[3]      abs_m_3_27  1
    r[3]      abs_p_3_28  -1
    r[3]      abs_m_3_28  1
    r[3]      abs_p_3_29  -1
    r[3]      abs_m_3_29  1
    r[3]      abs_p_3_30  -1
    r[3]      abs_m_3_30  1
    r[3]      abs_p_3_31  -1
    r[3]      abs_m_3_31  1
    r[3]      abs_p_3_32  -1
    r[3]      abs_m_3_32  1
    r[3]      abs_p_3_33  -1
    r[3]      abs_m_3_33  1
    r[3]      abs_p_3_34  -1
    r[3]      abs_m_3_34  1
    r[3]      abs_p_3_35  -1
    r[3]      abs_m_3_35  1
    r[4]      normalized_ratio_4  1
    r[4]      normalization  1
    r[4]      abs_p_1_4  1
    r[4]      abs_m_1_4  -1
    r[4]      abs_p_2_4  1
    r[4]      abs_m_2_4  -1
    r[4]      abs_p_3_4  1
    r[4]      abs_m_3_4  -1
    r[4]      abs_p_4_5  -1
    r[4]      abs_m_4_5  1
    r[4]      abs_p_4_6  -1
    r[4]      abs_m_4_6  1
    r[4]      abs_p_4_7  -1
    r[4]      abs_m_4_7  1
    r[4]      abs_p_4_8  -1
    r[4]      abs_m_4_8  1
    r[4]      abs_p_4_9  -1
    r[4]      abs_m_4_9  1
    r[4]      abs_p_4_10  -1
    r[4]      abs_m_4_10  1
    r[4]      abs_p_4_11  -1
    r[4]      abs_m_4_11  1
    r[4]      abs_p_4_12  -1
    r[4]      abs_m_4_12  1
    r[4]      abs_p_4_13  -1
    r[4]      abs_m_4_13  1
    r[4]      abs_p_4_14  -1
    r[4]      abs_m_4_14  1
    r[4]      abs_p_4_15  -1
    r[4]      abs_m_4_15  1
    r[4]      abs_p_4_16  -1
    r[4]      abs_m_4_16  1
    r[4]      abs_p_4_17  -1
    r[4]      abs_m_4_17  1
    r[4]      abs_p_4_18  -1
    r[4]      abs_m_4_18  1
    r[4]      abs_p_4_19  -1
    r[4]      abs_m_4_19  1
    r[4]      abs_p_4_20  -1
    r[4]      abs_m_4_20  1
    r[4]      abs_p_4_21  -1
    r[4]      abs_m_4_21  1
    r[4]      abs_p_4_22  -1
    r[4]      abs_m_4_22  1
    r[4]      abs_p_4_23  -1
    r[4]      abs_m_4_23  1
    r[4]      abs_p_4_24  -1
    r[4]      abs_m_4_24  1
    r[4]      abs_p_4_25  -1
    r[4]      abs_m_4_25  1
    r[4]      abs_p_4_26  -1
    r[4]      abs_m_4_26  1
    r[4]      abs_p_4_27  -1
    r[4]      abs_m_4_27  1
    r[4]      abs_p_4_28  -1
    r[4]      abs_m_4_28  1
    r[4]      abs_p_4_29  -1
    r[4]      abs_m_4_29  1
    r[4]      abs_p_4_30  -1
    r[4]      abs_m_4_30  1
    r[4]      abs_p_4_31  -1
    r[4]      abs_m_4_31  1
    r[4]      abs_p_4_32  -1
    r[4]      abs_m_4_32  1
    r[4]      abs_p_4_33  -1
    r[4]      abs_m_4_33  1
    r[4]      abs_p_4_34  -1
    r[4]      abs_m_4_34  1
    r[4]      abs_p_4_35  -1
    r[4]      abs_m_4_35  1
    r[5]      normalized_ratio_5  1
    r[5]      normalization  1
    r[5]      abs_p_1_5  1
    r[5]      abs_m_1_5  -1
    r[5]      abs_p_2_5  1
    r[5]      abs_m_2_5  -1
    r[5]      abs_p_3_5  1
    r[5]      abs_m_3_5  -1
    r[5]      abs_p_4_5  1
    r[5]      abs_m_4_5  -1
    r[5]      abs_p_5_6  -1
    r[5]      abs_m_5_6  1
    r[5]      abs_p_5_7  -1
    r[5]      abs_m_5_7  1
    r[5]      abs_p_5_8  -1
    r[5]      abs_m_5_8  1
    r[5]      abs_p_5_9  -1
    r[5]      abs_m_5_9  1
    r[5]      abs_p_5_10  -1
    r[5]      abs_m_5_10  1
    r[5]      abs_p_5_11  -1
    r[5]      abs_m_5_11  1
    r[5]      abs_p_5_12  -1
    r[5]      abs_m_5_12  1
    r[5]      abs_p_5_13  -1
    r[5]      abs_m_5_13  1
    r[5]      abs_p_5_14  -1
    r[5]      abs_m_5_14  1
    r[5]      abs_p_5_15  -1
    r[5]      abs_m_5_15  1
    r[5]      abs_p_5_16  -1
    r[5]      abs_m_5_16  1
    r[5]      abs_p_5_17  -1
    r[5]      abs_m_5_17  1
    r[5]      abs_p_5_18  -1
    r[5]      abs_m_5_18  1
    r[5]      abs_p_5_19  -1
    r[5]      abs_m_5_19  1
    r[5]      abs_p_5_20  -1
    r[5]      abs_m_5_20  1
    r[5]      abs_p_5_21  -1
    r[5]      abs_m_5_21  1
    r[5]      abs_p_5_22  -1
    r[5]      abs_m_5_22  1
    r[5]      abs_p_5_23  -1
    r[5]      abs_m_5_23  1
    r[5]      abs_p_5_24  -1
    r[5]      abs_m_5_24  1
    r[5]      abs_p_5_25  -1
    r[5]      abs_m_5_25  1
    r[5]      abs_p_5_26  -1
    r[5]      abs_m_5_26  1
    r[5]      abs_p_5_27  -1
    r[5]      abs_m_5_27  1
    r[5]      abs_p_5_28  -1
    r[5]      abs_m_5_28  1
    r[5]      abs_p_5_29  -1
    r[5]      abs_m_5_29  1
    r[5]      abs_p_5_30  -1
    r[5]      abs_m_5_30  1
    r[5]      abs_p_5_31  -1
    r[5]      abs_m_5_31  1
    r[5]      abs_p_5_32  -1
    r[5]      abs_m_5_32  1
    r[5]      abs_p_5_33  -1
    r[5]      abs_m_5_33  1
    r[5]      abs_p_5_34  -1
    r[5]      abs_m_5_34  1
    r[5]      abs_p_5_35  -1
    r[5]      abs_m_5_35  1
    r[6]      normalized_ratio_6  1
    r[6]      normalization  1
    r[6]      abs_p_1_6  1
    r[6]      abs_m_1_6  -1
    r[6]      abs_p_2_6  1
    r[6]      abs_m_2_6  -1
    r[6]      abs_p_3_6  1
    r[6]      abs_m_3_6  -1
    r[6]      abs_p_4_6  1
    r[6]      abs_m_4_6  -1
    r[6]      abs_p_5_6  1
    r[6]      abs_m_5_6  -1
    r[6]      abs_p_6_7  -1
    r[6]      abs_m_6_7  1
    r[6]      abs_p_6_8  -1
    r[6]      abs_m_6_8  1
    r[6]      abs_p_6_9  -1
    r[6]      abs_m_6_9  1
    r[6]      abs_p_6_10  -1
    r[6]      abs_m_6_10  1
    r[6]      abs_p_6_11  -1
    r[6]      abs_m_6_11  1
    r[6]      abs_p_6_12  -1
    r[6]      abs_m_6_12  1
    r[6]      abs_p_6_13  -1
    r[6]      abs_m_6_13  1
    r[6]      abs_p_6_14  -1
    r[6]      abs_m_6_14  1
    r[6]      abs_p_6_15  -1
    r[6]      abs_m_6_15  1
    r[6]      abs_p_6_16  -1
    r[6]      abs_m_6_16  1
    r[6]      abs_p_6_17  -1
    r[6]      abs_m_6_17  1
    r[6]      abs_p_6_18  -1
    r[6]      abs_m_6_18  1
    r[6]      abs_p_6_19  -1
    r[6]      abs_m_6_19  1
    r[6]      abs_p_6_20  -1
    r[6]      abs_m_6_20  1
    r[6]      abs_p_6_21  -1
    r[6]      abs_m_6_21  1
    r[6]      abs_p_6_22  -1
    r[6]      abs_m_6_22  1
    r[6]      abs_p_6_23  -1
    r[6]      abs_m_6_23  1
    r[6]      abs_p_6_24  -1
    r[6]      abs_m_6_24  1
    r[6]      abs_p_6_25  -1
    r[6]      abs_m_6_25  1
    r[6]      abs_p_6_26  -1
    r[6]      abs_m_6_26  1
    r[6]      abs_p_6_27  -1
    r[6]      abs_m_6_27  1
    r[6]      abs_p_6_28  -1
    r[6]      abs_m_6_28  1
    r[6]      abs_p_6_29  -1
    r[6]      abs_m_6_29  1
    r[6]      abs_p_6_30  -1
    r[6]      abs_m_6_30  1
    r[6]      abs_p_6_31  -1
    r[6]      abs_m_6_31  1
    r[6]      abs_p_6_32  -1
    r[6]      abs_m_6_32  1
    r[6]      abs_p_6_33  -1
    r[6]      abs_m_6_33  1
    r[6]      abs_p_6_34  -1
    r[6]      abs_m_6_34  1
    r[6]      abs_p_6_35  -1
    r[6]      abs_m_6_35  1
    r[7]      normalized_ratio_7  1
    r[7]      normalization  1
    r[7]      abs_p_1_7  1
    r[7]      abs_m_1_7  -1
    r[7]      abs_p_2_7  1
    r[7]      abs_m_2_7  -1
    r[7]      abs_p_3_7  1
    r[7]      abs_m_3_7  -1
    r[7]      abs_p_4_7  1
    r[7]      abs_m_4_7  -1
    r[7]      abs_p_5_7  1
    r[7]      abs_m_5_7  -1
    r[7]      abs_p_6_7  1
    r[7]      abs_m_6_7  -1
    r[7]      abs_p_7_8  -1
    r[7]      abs_m_7_8  1
    r[7]      abs_p_7_9  -1
    r[7]      abs_m_7_9  1
    r[7]      abs_p_7_10  -1
    r[7]      abs_m_7_10  1
    r[7]      abs_p_7_11  -1
    r[7]      abs_m_7_11  1
    r[7]      abs_p_7_12  -1
    r[7]      abs_m_7_12  1
    r[7]      abs_p_7_13  -1
    r[7]      abs_m_7_13  1
    r[7]      abs_p_7_14  -1
    r[7]      abs_m_7_14  1
    r[7]      abs_p_7_15  -1
    r[7]      abs_m_7_15  1
    r[7]      abs_p_7_16  -1
    r[7]      abs_m_7_16  1
    r[7]      abs_p_7_17  -1
    r[7]      abs_m_7_17  1
    r[7]      abs_p_7_18  -1
    r[7]      abs_m_7_18  1
    r[7]      abs_p_7_19  -1
    r[7]      abs_m_7_19  1
    r[7]      abs_p_7_20  -1
    r[7]      abs_m_7_20  1
    r[7]      abs_p_7_21  -1
    r[7]      abs_m_7_21  1
    r[7]      abs_p_7_22  -1
    r[7]      abs_m_7_22  1
    r[7]      abs_p_7_23  -1
    r[7]      abs_m_7_23  1
    r[7]      abs_p_7_24  -1
    r[7]      abs_m_7_24  1
    r[7]      abs_p_7_25  -1
    r[7]      abs_m_7_25  1
    r[7]      abs_p_7_26  -1
    r[7]      abs_m_7_26  1
    r[7]      abs_p_7_27  -1
    r[7]      abs_m_7_27  1
    r[7]      abs_p_7_28  -1
    r[7]      abs_m_7_28  1
    r[7]      abs_p_7_29  -1
    r[7]      abs_m_7_29  1
    r[7]      abs_p_7_30  -1
    r[7]      abs_m_7_30  1
    r[7]      abs_p_7_31  -1
    r[7]      abs_m_7_31  1
    r[7]      abs_p_7_32  -1
    r[7]      abs_m_7_32  1
    r[7]      abs_p_7_33  -1
    r[7]      abs_m_7_33  1
    r[7]      abs_p_7_34  -1
    r[7]      abs_m_7_34  1
    r[7]      abs_p_7_35  -1
    r[7]      abs_m_7_35  1
    r[8]      normalized_ratio_8  1
    r[8]      normalization  1
    r[8]      abs_p_1_8  1
    r[8]      abs_m_1_8  -1
    r[8]      abs_p_2_8  1
    r[8]      abs_m_2_8  -1
    r[8]      abs_p_3_8  1
    r[8]      abs_m_3_8  -1
    r[8]      abs_p_4_8  1
    r[8]      abs_m_4_8  -1
    r[8]      abs_p_5_8  1
    r[8]      abs_m_5_8  -1
    r[8]      abs_p_6_8  1
    r[8]      abs_m_6_8  -1
    r[8]      abs_p_7_8  1
    r[8]      abs_m_7_8  -1
    r[8]      abs_p_8_9  -1
    r[8]      abs_m_8_9  1
    r[8]      abs_p_8_10  -1
    r[8]      abs_m_8_10  1
    r[8]      abs_p_8_11  -1
    r[8]      abs_m_8_11  1
    r[8]      abs_p_8_12  -1
    r[8]      abs_m_8_12  1
    r[8]      abs_p_8_13  -1
    r[8]      abs_m_8_13  1
    r[8]      abs_p_8_14  -1
    r[8]      abs_m_8_14  1
    r[8]      abs_p_8_15  -1
    r[8]      abs_m_8_15  1
    r[8]      abs_p_8_16  -1
    r[8]      abs_m_8_16  1
    r[8]      abs_p_8_17  -1
    r[8]      abs_m_8_17  1
    r[8]      abs_p_8_18  -1
    r[8]      abs_m_8_18  1
    r[8]      abs_p_8_19  -1
    r[8]      abs_m_8_19  1
    r[8]      abs_p_8_20  -1
    r[8]      abs_m_8_20  1
    r[8]      abs_p_8_21  -1
    r[8]      abs_m_8_21  1
    r[8]      abs_p_8_22  -1
    r[8]      abs_m_8_22  1
    r[8]      abs_p_8_23  -1
    r[8]      abs_m_8_23  1
    r[8]      abs_p_8_24  -1
    r[8]      abs_m_8_24  1
    r[8]      abs_p_8_25  -1
    r[8]      abs_m_8_25  1
    r[8]      abs_p_8_26  -1
    r[8]      abs_m_8_26  1
    r[8]      abs_p_8_27  -1
    r[8]      abs_m_8_27  1
    r[8]      abs_p_8_28  -1
    r[8]      abs_m_8_28  1
    r[8]      abs_p_8_29  -1
    r[8]      abs_m_8_29  1
    r[8]      abs_p_8_30  -1
    r[8]      abs_m_8_30  1
    r[8]      abs_p_8_31  -1
    r[8]      abs_m_8_31  1
    r[8]      abs_p_8_32  -1
    r[8]      abs_m_8_32  1
    r[8]      abs_p_8_33  -1
    r[8]      abs_m_8_33  1
    r[8]      abs_p_8_34  -1
    r[8]      abs_m_8_34  1
    r[8]      abs_p_8_35  -1
    r[8]      abs_m_8_35  1
    r[9]      normalized_ratio_9  1
    r[9]      normalization  1
    r[9]      abs_p_1_9  1
    r[9]      abs_m_1_9  -1
    r[9]      abs_p_2_9  1
    r[9]      abs_m_2_9  -1
    r[9]      abs_p_3_9  1
    r[9]      abs_m_3_9  -1
    r[9]      abs_p_4_9  1
    r[9]      abs_m_4_9  -1
    r[9]      abs_p_5_9  1
    r[9]      abs_m_5_9  -1
    r[9]      abs_p_6_9  1
    r[9]      abs_m_6_9  -1
    r[9]      abs_p_7_9  1
    r[9]      abs_m_7_9  -1
    r[9]      abs_p_8_9  1
    r[9]      abs_m_8_9  -1
    r[9]      abs_p_9_10  -1
    r[9]      abs_m_9_10  1
    r[9]      abs_p_9_11  -1
    r[9]      abs_m_9_11  1
    r[9]      abs_p_9_12  -1
    r[9]      abs_m_9_12  1
    r[9]      abs_p_9_13  -1
    r[9]      abs_m_9_13  1
    r[9]      abs_p_9_14  -1
    r[9]      abs_m_9_14  1
    r[9]      abs_p_9_15  -1
    r[9]      abs_m_9_15  1
    r[9]      abs_p_9_16  -1
    r[9]      abs_m_9_16  1
    r[9]      abs_p_9_17  -1
    r[9]      abs_m_9_17  1
    r[9]      abs_p_9_18  -1
    r[9]      abs_m_9_18  1
    r[9]      abs_p_9_19  -1
    r[9]      abs_m_9_19  1
    r[9]      abs_p_9_20  -1
    r[9]      abs_m_9_20  1
    r[9]      abs_p_9_21  -1
    r[9]      abs_m_9_21  1
    r[9]      abs_p_9_22  -1
    r[9]      abs_m_9_22  1
    r[9]      abs_p_9_23  -1
    r[9]      abs_m_9_23  1
    r[9]      abs_p_9_24  -1
    r[9]      abs_m_9_24  1
    r[9]      abs_p_9_25  -1
    r[9]      abs_m_9_25  1
    r[9]      abs_p_9_26  -1
    r[9]      abs_m_9_26  1
    r[9]      abs_p_9_27  -1
    r[9]      abs_m_9_27  1
    r[9]      abs_p_9_28  -1
    r[9]      abs_m_9_28  1
    r[9]      abs_p_9_29  -1
    r[9]      abs_m_9_29  1
    r[9]      abs_p_9_30  -1
    r[9]      abs_m_9_30  1
    r[9]      abs_p_9_31  -1
    r[9]      abs_m_9_31  1
    r[9]      abs_p_9_32  -1
    r[9]      abs_m_9_32  1
    r[9]      abs_p_9_33  -1
    r[9]      abs_m_9_33  1
    r[9]      abs_p_9_34  -1
    r[9]      abs_m_9_34  1
    r[9]      abs_p_9_35  -1
    r[9]      abs_m_9_35  1
    r[10]     normalized_ratio_10  1
    r[10]     normalization  1
    r[10]     abs_p_1_10  1
    r[10]     abs_m_1_10  -1
    r[10]     abs_p_2_10  1
    r[10]     abs_m_2_10  -1
    r[10]     abs_p_3_10  1
    r[10]     abs_m_3_10  -1
    r[10]     abs_p_4_10  1
    r[10]     abs_m_4_10  -1
    r[10]     abs_p_5_10  1
    r[10]     abs_m_5_10  -1
    r[10]     abs_p_6_10  1
    r[10]     abs_m_6_10  -1
    r[10]     abs_p_7_10  1
    r[10]     abs_m_7_10  -1
    r[10]     abs_p_8_10  1
    r[10]     abs_m_8_10  -1
    r[10]     abs_p_9_10  1
    r[10]     abs_m_9_10  -1
    r[10]     abs_p_10_11  -1
    r[10]     abs_m_10_11  1
    r[10]     abs_p_10_12  -1
    r[10]     abs_m_10_12  1
    r[10]     abs_p_10_13  -1
    r[10]     abs_m_10_13  1
    r[10]     abs_p_10_14  -1
    r[10]     abs_m_10_14  1
    r[10]     abs_p_10_15  -1
    r[10]     abs_m_10_15  1
    r[10]     abs_p_10_16  -1
    r[10]     abs_m_10_16  1
    r[10]     abs_p_10_17  -1
    r[10]     abs_m_10_17  1
    r[10]     abs_p_10_18  -1
    r[10]     abs_m_10_18  1
    r[10]     abs_p_10_19  -1
    r[10]     abs_m_10_19  1
    r[10]     abs_p_10_20  -1
    r[10]     abs_m_10_20  1
    r[10]     abs_p_10_21  -1
    r[10]     abs_m_10_21  1
    r[10]     abs_p_10_22  -1
    r[10]     abs_m_10_22  1
    r[10]     abs_p_10_23  -1
    r[10]     abs_m_10_23  1
    r[10]     abs_p_10_24  -1
    r[10]     abs_m_10_24  1
    r[10]     abs_p_10_25  -1
    r[10]     abs_m_10_25  1
    r[10]     abs_p_10_26  -1
    r[10]     abs_m_10_26  1
    r[10]     abs_p_10_27  -1
    r[10]     abs_m_10_27  1
    r[10]     abs_p_10_28  -1
    r[10]     abs_m_10_28  1
    r[10]     abs_p_10_29  -1
    r[10]     abs_m_10_29  1
    r[10]     abs_p_10_30  -1
    r[10]     abs_m_10_30  1
    r[10]     abs_p_10_31  -1
    r[10]     abs_m_10_31  1
    r[10]     abs_p_10_32  -1
    r[10]     abs_m_10_32  1
    r[10]     abs_p_10_33  -1
    r[10]     abs_m_10_33  1
    r[10]     abs_p_10_34  -1
    r[10]     abs_m_10_34  1
    r[10]     abs_p_10_35  -1
    r[10]     abs_m_10_35  1
    r[11]     normalized_ratio_11  1
    r[11]     normalization  1
    r[11]     abs_p_1_11  1
    r[11]     abs_m_1_11  -1
    r[11]     abs_p_2_11  1
    r[11]     abs_m_2_11  -1
    r[11]     abs_p_3_11  1
    r[11]     abs_m_3_11  -1
    r[11]     abs_p_4_11  1
    r[11]     abs_m_4_11  -1
    r[11]     abs_p_5_11  1
    r[11]     abs_m_5_11  -1
    r[11]     abs_p_6_11  1
    r[11]     abs_m_6_11  -1
    r[11]     abs_p_7_11  1
    r[11]     abs_m_7_11  -1
    r[11]     abs_p_8_11  1
    r[11]     abs_m_8_11  -1
    r[11]     abs_p_9_11  1
    r[11]     abs_m_9_11  -1
    r[11]     abs_p_10_11  1
    r[11]     abs_m_10_11  -1
    r[11]     abs_p_11_12  -1
    r[11]     abs_m_11_12  1
    r[11]     abs_p_11_13  -1
    r[11]     abs_m_11_13  1
    r[11]     abs_p_11_14  -1
    r[11]     abs_m_11_14  1
    r[11]     abs_p_11_15  -1
    r[11]     abs_m_11_15  1
    r[11]     abs_p_11_16  -1
    r[11]     abs_m_11_16  1
    r[11]     abs_p_11_17  -1
    r[11]     abs_m_11_17  1
    r[11]     abs_p_11_18  -1
    r[11]     abs_m_11_18  1
    r[11]     abs_p_11_19  -1
    r[11]     abs_m_11_19  1
    r[11]     abs_p_11_20  -1
    r[11]     abs_m_11_20  1
    r[11]     abs_p_11_21  -1
    r[11]     abs_m_11_21  1
    r[11]     abs_p_11_22  -1
    r[11]     abs_m_11_22  1
    r[11]     abs_p_11_23  -1
    r[11]     abs_m_11_23  1
    r[11]     abs_p_11_24  -1
    r[11]     abs_m_11_24  1
    r[11]     abs_p_11_25  -1
    r[11]     abs_m_11_25  1
    r[11]     abs_p_11_26  -1
    r[11]     abs_m_11_26  1
    r[11]     abs_p_11_27  -1
    r[11]     abs_m_11_27  1
    r[11]     abs_p_11_28  -1
    r[11]     abs_m_11_28  1
    r[11]     abs_p_11_29  -1
    r[11]     abs_m_11_29  1
    r[11]     abs_p_11_30  -1
    r[11]     abs_m_11_30  1
    r[11]     abs_p_11_31  -1
    r[11]     abs_m_11_31  1
    r[11]     abs_p_11_32  -1
    r[11]     abs_m_11_32  1
    r[11]     abs_p_11_33  -1
    r[11]     abs_m_11_33  1
    r[11]     abs_p_11_34  -1
    r[11]     abs_m_11_34  1
    r[11]     abs_p_11_35  -1
    r[11]     abs_m_11_35  1
    r[12]     normalized_ratio_12  1
    r[12]     normalization  1
    r[12]     abs_p_1_12  1
    r[12]     abs_m_1_12  -1
    r[12]     abs_p_2_12  1
    r[12]     abs_m_2_12  -1
    r[12]     abs_p_3_12  1
    r[12]     abs_m_3_12  -1
    r[12]     abs_p_4_12  1
    r[12]     abs_m_4_12  -1
    r[12]     abs_p_5_12  1
    r[12]     abs_m_5_12  -1
    r[12]     abs_p_6_12  1
    r[12]     abs_m_6_12  -1
    r[12]     abs_p_7_12  1
    r[12]     abs_m_7_12  -1
    r[12]     abs_p_8_12  1
    r[12]     abs_m_8_12  -1
    r[12]     abs_p_9_12  1
    r[12]     abs_m_9_12  -1
    r[12]     abs_p_10_12  1
    r[12]     abs_m_10_12  -1
    r[12]     abs_p_11_12  1
    r[12]     abs_m_11_12  -1
    r[12]     abs_p_12_13  -1
    r[12]     abs_m_12_13  1
    r[12]     abs_p_12_14  -1
    r[12]     abs_m_12_14  1
    r[12]     abs_p_12_15  -1
    r[12]     abs_m_12_15  1
    r[12]     abs_p_12_16  -1
    r[12]     abs_m_12_16  1
    r[12]     abs_p_12_17  -1
    r[12]     abs_m_12_17  1
    r[12]     abs_p_12_18  -1
    r[12]     abs_m_12_18  1
    r[12]     abs_p_12_19  -1
    r[12]     abs_m_12_19  1
    r[12]     abs_p_12_20  -1
    r[12]     abs_m_12_20  1
    r[12]     abs_p_12_21  -1
    r[12]     abs_m_12_21  1
    r[12]     abs_p_12_22  -1
    r[12]     abs_m_12_22  1
    r[12]     abs_p_12_23  -1
    r[12]     abs_m_12_23  1
    r[12]     abs_p_12_24  -1
    r[12]     abs_m_12_24  1
    r[12]     abs_p_12_25  -1
    r[12]     abs_m_12_25  1
    r[12]     abs_p_12_26  -1
    r[12]     abs_m_12_26  1
    r[12]     abs_p_12_27  -1
    r[12]     abs_m_12_27  1
    r[12]     abs_p_12_28  -1
    r[12]     abs_m_12_28  1
    r[12]     abs_p_12_29  -1
    r[12]     abs_m_12_29  1
    r[12]     abs_p_12_30  -1
    r[12]     abs_m_12_30  1
    r[12]     abs_p_12_31  -1
    r[12]     abs_m_12_31  1
    r[12]     abs_p_12_32  -1
    r[12]     abs_m_12_32  1
    r[12]     abs_p_12_33  -1
    r[12]     abs_m_12_33  1
    r[12]     abs_p_12_34  -1
    r[12]     abs_m_12_34  1
    r[12]     abs_p_12_35  -1
    r[12]     abs_m_12_35  1
    r[13]     normalized_ratio_13  1
    r[13]     normalization  1
    r[13]     abs_p_1_13  1
    r[13]     abs_m_1_13  -1
    r[13]     abs_p_2_13  1
    r[13]     abs_m_2_13  -1
    r[13]     abs_p_3_13  1
    r[13]     abs_m_3_13  -1
    r[13]     abs_p_4_13  1
    r[13]     abs_m_4_13  -1
    r[13]     abs_p_5_13  1
    r[13]     abs_m_5_13  -1
    r[13]     abs_p_6_13  1
    r[13]     abs_m_6_13  -1
    r[13]     abs_p_7_13  1
    r[13]     abs_m_7_13  -1
    r[13]     abs_p_8_13  1
    r[13]     abs_m_8_13  -1
    r[13]     abs_p_9_13  1
    r[13]     abs_m_9_13  -1
    r[13]     abs_p_10_13  1
    r[13]     abs_m_10_13  -1
    r[13]     abs_p_11_13  1
    r[13]     abs_m_11_13  -1
    r[13]     abs_p_12_13  1
    r[13]     abs_m_12_13  -1
    r[13]     abs_p_13_14  -1
    r[13]     abs_m_13_14  1
    r[13]     abs_p_13_15  -1
    r[13]     abs_m_13_15  1
    r[13]     abs_p_13_16  -1
    r[13]     abs_m_13_16  1
    r[13]     abs_p_13_17  -1
    r[13]     abs_m_13_17  1
    r[13]     abs_p_13_18  -1
    r[13]     abs_m_13_18  1
    r[13]     abs_p_13_19  -1
    r[13]     abs_m_13_19  1
    r[13]     abs_p_13_20  -1
    r[13]     abs_m_13_20  1
    r[13]     abs_p_13_21  -1
    r[13]     abs_m_13_21  1
    r[13]     abs_p_13_22  -1
    r[13]     abs_m_13_22  1
    r[13]     abs_p_13_23  -1
    r[13]     abs_m_13_23  1
    r[13]     abs_p_13_24  -1
    r[13]     abs_m_13_24  1
    r[13]     abs_p_13_25  -1
    r[13]     abs_m_13_25  1
    r[13]     abs_p_13_26  -1
    r[13]     abs_m_13_26  1
    r[13]     abs_p_13_27  -1
    r[13]     abs_m_13_27  1
    r[13]     abs_p_13_28  -1
    r[13]     abs_m_13_28  1
    r[13]     abs_p_13_29  -1
    r[13]     abs_m_13_29  1
    r[13]     abs_p_13_30  -1
    r[13]     abs_m_13_30  1
    r[13]     abs_p_13_31  -1
    r[13]     abs_m_13_31  1
    r[13]     abs_p_13_32  -1
    r[13]     abs_m_13_32  1
    r[13]     abs_p_13_33  -1
    r[13]     abs_m_13_33  1
    r[13]     abs_p_13_34  -1
    r[13]     abs_m_13_34  1
    r[13]     abs_p_13_35  -1
    r[13]     abs_m_13_35  1
    r[14]     normalized_ratio_14  1
    r[14]     normalization  1
    r[14]     abs_p_1_14  1
    r[14]     abs_m_1_14  -1
    r[14]     abs_p_2_14  1
    r[14]     abs_m_2_14  -1
    r[14]     abs_p_3_14  1
    r[14]     abs_m_3_14  -1
    r[14]     abs_p_4_14  1
    r[14]     abs_m_4_14  -1
    r[14]     abs_p_5_14  1
    r[14]     abs_m_5_14  -1
    r[14]     abs_p_6_14  1
    r[14]     abs_m_6_14  -1
    r[14]     abs_p_7_14  1
    r[14]     abs_m_7_14  -1
    r[14]     abs_p_8_14  1
    r[14]     abs_m_8_14  -1
    r[14]     abs_p_9_14  1
    r[14]     abs_m_9_14  -1
    r[14]     abs_p_10_14  1
    r[14]     abs_m_10_14  -1
    r[14]     abs_p_11_14  1
    r[14]     abs_m_11_14  -1
    r[14]     abs_p_12_14  1
    r[14]     abs_m_12_14  -1
    r[14]     abs_p_13_14  1
    r[14]     abs_m_13_14  -1
    r[14]     abs_p_14_15  -1
    r[14]     abs_m_14_15  1
    r[14]     abs_p_14_16  -1
    r[14]     abs_m_14_16  1
    r[14]     abs_p_14_17  -1
    r[14]     abs_m_14_17  1
    r[14]     abs_p_14_18  -1
    r[14]     abs_m_14_18  1
    r[14]     abs_p_14_19  -1
    r[14]     abs_m_14_19  1
    r[14]     abs_p_14_20  -1
    r[14]     abs_m_14_20  1
    r[14]     abs_p_14_21  -1
    r[14]     abs_m_14_21  1
    r[14]     abs_p_14_22  -1
    r[14]     abs_m_14_22  1
    r[14]     abs_p_14_23  -1
    r[14]     abs_m_14_23  1
    r[14]     abs_p_14_24  -1
    r[14]     abs_m_14_24  1
    r[14]     abs_p_14_25  -1
    r[14]     abs_m_14_25  1
    r[14]     abs_p_14_26  -1
    r[14]     abs_m_14_26  1
    r[14]     abs_p_14_27  -1
    r[14]     abs_m_14_27  1
    r[14]     abs_p_14_28  -1
    r[14]     abs_m_14_28  1
    r[14]     abs_p_14_29  -1
    r[14]     abs_m_14_29  1
    r[14]     abs_p_14_30  -1
    r[14]     abs_m_14_30  1
    r[14]     abs_p_14_31  -1
    r[14]     abs_m_14_31  1
    r[14]     abs_p_14_32  -1
    r[14]     abs_m_14_32  1
    r[14]     abs_p_14_33  -1
    r[14]     abs_m_14_33  1
    r[14]     abs_p_14_34  -1
    r[14]     abs_m_14_34  1
    r[14]     abs_p_14_35  -1
    r[14]     abs_m_14_35  1
    r[15]     normalized_ratio_15  1
    r[15]     normalization  1
    r[15]     abs_p_1_15  1
    r[15]     abs_m_1_15  -1
    r[15]     abs_p_2_15  1
    r[15]     abs_m_2_15  -1
    r[15]     abs_p_3_15  1
    r[15]     abs_m_3_15  -1
    r[15]     abs_p_4_15  1
    r[15]     abs_m_4_15  -1
    r[15]     abs_p_5_15  1
    r[15]     abs_m_5_15  -1
    r[15]     abs_p_6_15  1
    r[15]     abs_m_6_15  -1
    r[15]     abs_p_7_15  1
    r[15]     abs_m_7_15  -1
    r[15]     abs_p_8_15  1
    r[15]     abs_m_8_15  -1
    r[15]     abs_p_9_15  1
    r[15]     abs_m_9_15  -1
    r[15]     abs_p_10_15  1
    r[15]     abs_m_10_15  -1
    r[15]     abs_p_11_15  1
    r[15]     abs_m_11_15  -1
    r[15]     abs_p_12_15  1
    r[15]     abs_m_12_15  -1
    r[15]     abs_p_13_15  1
    r[15]     abs_m_13_15  -1
    r[15]     abs_p_14_15  1
    r[15]     abs_m_14_15  -1
    r[15]     abs_p_15_16  -1
    r[15]     abs_m_15_16  1
    r[15]     abs_p_15_17  -1
    r[15]     abs_m_15_17  1
    r[15]     abs_p_15_18  -1
    r[15]     abs_m_15_18  1
    r[15]     abs_p_15_19  -1
    r[15]     abs_m_15_19  1
    r[15]     abs_p_15_20  -1
    r[15]     abs_m_15_20  1
    r[15]     abs_p_15_21  -1
    r[15]     abs_m_15_21  1
    r[15]     abs_p_15_22  -1
    r[15]     abs_m_15_22  1
    r[15]     abs_p_15_23  -1
    r[15]     abs_m_15_23  1
    r[15]     abs_p_15_24  -1
    r[15]     abs_m_15_24  1
    r[15]     abs_p_15_25  -1
    r[15]     abs_m_15_25  1
    r[15]     abs_p_15_26  -1
    r[15]     abs_m_15_26  1
    r[15]     abs_p_15_27  -1
    r[15]     abs_m_15_27  1
    r[15]     abs_p_15_28  -1
    r[15]     abs_m_15_28  1
    r[15]     abs_p_15_29  -1
    r[15]     abs_m_15_29  1
    r[15]     abs_p_15_30  -1
    r[15]     abs_m_15_30  1
    r[15]     abs_p_15_31  -1
    r[15]     abs_m_15_31  1
    r[15]     abs_p_15_32  -1
    r[15]     abs_m_15_32  1
    r[15]     abs_p_15_33  -1
    r[15]     abs_m_15_33  1
    r[15]     abs_p_15_34  -1
    r[15]     abs_m_15_34  1
    r[15]     abs_p_15_35  -1
    r[15]     abs_m_15_35  1
    r[16]     normalized_ratio_16  1
    r[16]     normalization  1
    r[16]     abs_p_1_16  1
    r[16]     abs_m_1_16  -1
    r[16]     abs_p_2_16  1
    r[16]     abs_m_2_16  -1
    r[16]     abs_p_3_16  1
    r[16]     abs_m_3_16  -1
    r[16]     abs_p_4_16  1
    r[16]     abs_m_4_16  -1
    r[16]     abs_p_5_16  1
    r[16]     abs_m_5_16  -1
    r[16]     abs_p_6_16  1
    r[16]     abs_m_6_16  -1
    r[16]     abs_p_7_16  1
    r[16]     abs_m_7_16  -1
    r[16]     abs_p_8_16  1
    r[16]     abs_m_8_16  -1
    r[16]     abs_p_9_16  1
    r[16]     abs_m_9_16  -1
    r[16]     abs_p_10_16  1
    r[16]     abs_m_10_16  -1
    r[16]     abs_p_11_16  1
    r[16]     abs_m_11_16  -1
    r[16]     abs_p_12_16  1
    r[16]     abs_m_12_16  -1
    r[16]     abs_p_13_16  1
    r[16]     abs_m_13_16  -1
    r[16]     abs_p_14_16  1
    r[16]     abs_m_14_16  -1
    r[16]     abs_p_15_16  1
    r[16]     abs_m_15_16  -1
    r[16]     abs_p_16_17  -1
    r[16]     abs_m_16_17  1
    r[16]     abs_p_16_18  -1
    r[16]     abs_m_16_18  1
    r[16]     abs_p_16_19  -1
    r[16]     abs_m_16_19  1
    r[16]     abs_p_16_20  -1
    r[16]     abs_m_16_20  1
    r[16]     abs_p_16_21  -1
    r[16]     abs_m_16_21  1
    r[16]     abs_p_16_22  -1
    r[16]     abs_m_16_22  1
    r[16]     abs_p_16_23  -1
    r[16]     abs_m_16_23  1
    r[16]     abs_p_16_24  -1
    r[16]     abs_m_16_24  1
    r[16]     abs_p_16_25  -1
    r[16]     abs_m_16_25  1
    r[16]     abs_p_16_26  -1
    r[16]     abs_m_16_26  1
    r[16]     abs_p_16_27  -1
    r[16]     abs_m_16_27  1
    r[16]     abs_p_16_28  -1
    r[16]     abs_m_16_28  1
    r[16]     abs_p_16_29  -1
    r[16]     abs_m_16_29  1
    r[16]     abs_p_16_30  -1
    r[16]     abs_m_16_30  1
    r[16]     abs_p_16_31  -1
    r[16]     abs_m_16_31  1
    r[16]     abs_p_16_32  -1
    r[16]     abs_m_16_32  1
    r[16]     abs_p_16_33  -1
    r[16]     abs_m_16_33  1
    r[16]     abs_p_16_34  -1
    r[16]     abs_m_16_34  1
    r[16]     abs_p_16_35  -1
    r[16]     abs_m_16_35  1
    r[17]     normalized_ratio_17  1
    r[17]     normalization  1
    r[17]     abs_p_1_17  1
    r[17]     abs_m_1_17  -1
    r[17]     abs_p_2_17  1
    r[17]     abs_m_2_17  -1
    r[17]     abs_p_3_17  1
    r[17]     abs_m_3_17  -1
    r[17]     abs_p_4_17  1
    r[17]     abs_m_4_17  -1
    r[17]     abs_p_5_17  1
    r[17]     abs_m_5_17  -1
    r[17]     abs_p_6_17  1
    r[17]     abs_m_6_17  -1
    r[17]     abs_p_7_17  1
    r[17]     abs_m_7_17  -1
    r[17]     abs_p_8_17  1
    r[17]     abs_m_8_17  -1
    r[17]     abs_p_9_17  1
    r[17]     abs_m_9_17  -1
    r[17]     abs_p_10_17  1
    r[17]     abs_m_10_17  -1
    r[17]     abs_p_11_17  1
    r[17]     abs_m_11_17  -1
    r[17]     abs_p_12_17  1
    r[17]     abs_m_12_17  -1
    r[17]     abs_p_13_17  1
    r[17]     abs_m_13_17  -1
    r[17]     abs_p_14_17  1
    r[17]     abs_m_14_17  -1
    r[17]     abs_p_15_17  1
    r[17]     abs_m_15_17  -1
    r[17]     abs_p_16_17  1
    r[17]     abs_m_16_17  -1
    r[17]     abs_p_17_18  -1
    r[17]     abs_m_17_18  1
    r[17]     abs_p_17_19  -1
    r[17]     abs_m_17_19  1
    r[17]     abs_p_17_20  -1
    r[17]     abs_m_17_20  1
    r[17]     abs_p_17_21  -1
    r[17]     abs_m_17_21  1
    r[17]     abs_p_17_22  -1
    r[17]     abs_m_17_22  1
    r[17]     abs_p_17_23  -1
    r[17]     abs_m_17_23  1
    r[17]     abs_p_17_24  -1
    r[17]     abs_m_17_24  1
    r[17]     abs_p_17_25  -1
    r[17]     abs_m_17_25  1
    r[17]     abs_p_17_26  -1
    r[17]     abs_m_17_26  1
    r[17]     abs_p_17_27  -1
    r[17]     abs_m_17_27  1
    r[17]     abs_p_17_28  -1
    r[17]     abs_m_17_28  1
    r[17]     abs_p_17_29  -1
    r[17]     abs_m_17_29  1
    r[17]     abs_p_17_30  -1
    r[17]     abs_m_17_30  1
    r[17]     abs_p_17_31  -1
    r[17]     abs_m_17_31  1
    r[17]     abs_p_17_32  -1
    r[17]     abs_m_17_32  1
    r[17]     abs_p_17_33  -1
    r[17]     abs_m_17_33  1
    r[17]     abs_p_17_34  -1
    r[17]     abs_m_17_34  1
    r[17]     abs_p_17_35  -1
    r[17]     abs_m_17_35  1
    r[18]     normalized_ratio_18  1
    r[18]     normalization  1
    r[18]     abs_p_1_18  1
    r[18]     abs_m_1_18  -1
    r[18]     abs_p_2_18  1
    r[18]     abs_m_2_18  -1
    r[18]     abs_p_3_18  1
    r[18]     abs_m_3_18  -1
    r[18]     abs_p_4_18  1
    r[18]     abs_m_4_18  -1
    r[18]     abs_p_5_18  1
    r[18]     abs_m_5_18  -1
    r[18]     abs_p_6_18  1
    r[18]     abs_m_6_18  -1
    r[18]     abs_p_7_18  1
    r[18]     abs_m_7_18  -1
    r[18]     abs_p_8_18  1
    r[18]     abs_m_8_18  -1
    r[18]     abs_p_9_18  1
    r[18]     abs_m_9_18  -1
    r[18]     abs_p_10_18  1
    r[18]     abs_m_10_18  -1
    r[18]     abs_p_11_18  1
    r[18]     abs_m_11_18  -1
    r[18]     abs_p_12_18  1
    r[18]     abs_m_12_18  -1
    r[18]     abs_p_13_18  1
    r[18]     abs_m_13_18  -1
    r[18]     abs_p_14_18  1
    r[18]     abs_m_14_18  -1
    r[18]     abs_p_15_18  1
    r[18]     abs_m_15_18  -1
    r[18]     abs_p_16_18  1
    r[18]     abs_m_16_18  -1
    r[18]     abs_p_17_18  1
    r[18]     abs_m_17_18  -1
    r[18]     abs_p_18_19  -1
    r[18]     abs_m_18_19  1
    r[18]     abs_p_18_20  -1
    r[18]     abs_m_18_20  1
    r[18]     abs_p_18_21  -1
    r[18]     abs_m_18_21  1
    r[18]     abs_p_18_22  -1
    r[18]     abs_m_18_22  1
    r[18]     abs_p_18_23  -1
    r[18]     abs_m_18_23  1
    r[18]     abs_p_18_24  -1
    r[18]     abs_m_18_24  1
    r[18]     abs_p_18_25  -1
    r[18]     abs_m_18_25  1
    r[18]     abs_p_18_26  -1
    r[18]     abs_m_18_26  1
    r[18]     abs_p_18_27  -1
    r[18]     abs_m_18_27  1
    r[18]     abs_p_18_28  -1
    r[18]     abs_m_18_28  1
    r[18]     abs_p_18_29  -1
    r[18]     abs_m_18_29  1
    r[18]     abs_p_18_30  -1
    r[18]     abs_m_18_30  1
    r[18]     abs_p_18_31  -1
    r[18]     abs_m_18_31  1
    r[18]     abs_p_18_32  -1
    r[18]     abs_m_18_32  1
    r[18]     abs_p_18_33  -1
    r[18]     abs_m_18_33  1
    r[18]     abs_p_18_34  -1
    r[18]     abs_m_18_34  1
    r[18]     abs_p_18_35  -1
    r[18]     abs_m_18_35  1
    r[19]     normalized_ratio_19  1
    r[19]     normalization  1
    r[19]     abs_p_1_19  1
    r[19]     abs_m_1_19  -1
    r[19]     abs_p_2_19  1
    r[19]     abs_m_2_19  -1
    r[19]     abs_p_3_19  1
    r[19]     abs_m_3_19  -1
    r[19]     abs_p_4_19  1
    r[19]     abs_m_4_19  -1
    r[19]     abs_p_5_19  1
    r[19]     abs_m_5_19  -1
    r[19]     abs_p_6_19  1
    r[19]     abs_m_6_19  -1
    r[19]     abs_p_7_19  1
    r[19]     abs_m_7_19  -1
    r[19]     abs_p_8_19  1
    r[19]     abs_m_8_19  -1
    r[19]     abs_p_9_19  1
    r[19]     abs_m_9_19  -1
    r[19]     abs_p_10_19  1
    r[19]     abs_m_10_19  -1
    r[19]     abs_p_11_19  1
    r[19]     abs_m_11_19  -1
    r[19]     abs_p_12_19  1
    r[19]     abs_m_12_19  -1
    r[19]     abs_p_13_19  1
    r[19]     abs_m_13_19  -1
    r[19]     abs_p_14_19  1
    r[19]     abs_m_14_19  -1
    r[19]     abs_p_15_19  1
    r[19]     abs_m_15_19  -1
    r[19]     abs_p_16_19  1
    r[19]     abs_m_16_19  -1
    r[19]     abs_p_17_19  1
    r[19]     abs_m_17_19  -1
    r[19]     abs_p_18_19  1
    r[19]     abs_m_18_19  -1
    r[19]     abs_p_19_20  -1
    r[19]     abs_m_19_20  1
    r[19]     abs_p_19_21  -1
    r[19]     abs_m_19_21  1
    r[19]     abs_p_19_22  -1
    r[19]     abs_m_19_22  1
    r[19]     abs_p_19_23  -1
    r[19]     abs_m_19_23  1
    r[19]     abs_p_19_24  -1
    r[19]     abs_m_19_24  1
    r[19]     abs_p_19_25  -1
    r[19]     abs_m_19_25  1
    r[19]     abs_p_19_26  -1
    r[19]     abs_m_19_26  1
    r[19]     abs_p_19_27  -1
    r[19]     abs_m_19_27  1
    r[19]     abs_p_19_28  -1
    r[19]     abs_m_19_28  1
    r[19]     abs_p_19_29  -1
    r[19]     abs_m_19_29  1
    r[19]     abs_p_19_30  -1
    r[19]     abs_m_19_30  1
    r[19]     abs_p_19_31  -1
    r[19]     abs_m_19_31  1
    r[19]     abs_p_19_32  -1
    r[19]     abs_m_19_32  1
    r[19]     abs_p_19_33  -1
    r[19]     abs_m_19_33  1
    r[19]     abs_p_19_34  -1
    r[19]     abs_m_19_34  1
    r[19]     abs_p_19_35  -1
    r[19]     abs_m_19_35  1
    r[20]     normalized_ratio_20  1
    r[20]     normalization  1
    r[20]     abs_p_1_20  1
    r[20]     abs_m_1_20  -1
    r[20]     abs_p_2_20  1
    r[20]     abs_m_2_20  -1
    r[20]     abs_p_3_20  1
    r[20]     abs_m_3_20  -1
    r[20]     abs_p_4_20  1
    r[20]     abs_m_4_20  -1
    r[20]     abs_p_5_20  1
    r[20]     abs_m_5_20  -1
    r[20]     abs_p_6_20  1
    r[20]     abs_m_6_20  -1
    r[20]     abs_p_7_20  1
    r[20]     abs_m_7_20  -1
    r[20]     abs_p_8_20  1
    r[20]     abs_m_8_20  -1
    r[20]     abs_p_9_20  1
    r[20]     abs_m_9_20  -1
    r[20]     abs_p_10_20  1
    r[20]     abs_m_10_20  -1
    r[20]     abs_p_11_20  1
    r[20]     abs_m_11_20  -1
    r[20]     abs_p_12_20  1
    r[20]     abs_m_12_20  -1
    r[20]     abs_p_13_20  1
    r[20]     abs_m_13_20  -1
    r[20]     abs_p_14_20  1
    r[20]     abs_m_14_20  -1
    r[20]     abs_p_15_20  1
    r[20]     abs_m_15_20  -1
    r[20]     abs_p_16_20  1
    r[20]     abs_m_16_20  -1
    r[20]     abs_p_17_20  1
    r[20]     abs_m_17_20  -1
    r[20]     abs_p_18_20  1
    r[20]     abs_m_18_20  -1
    r[20]     abs_p_19_20  1
    r[20]     abs_m_19_20  -1
    r[20]     abs_p_20_21  -1
    r[20]     abs_m_20_21  1
    r[20]     abs_p_20_22  -1
    r[20]     abs_m_20_22  1
    r[20]     abs_p_20_23  -1
    r[20]     abs_m_20_23  1
    r[20]     abs_p_20_24  -1
    r[20]     abs_m_20_24  1
    r[20]     abs_p_20_25  -1
    r[20]     abs_m_20_25  1
    r[20]     abs_p_20_26  -1
    r[20]     abs_m_20_26  1
    r[20]     abs_p_20_27  -1
    r[20]     abs_m_20_27  1
    r[20]     abs_p_20_28  -1
    r[20]     abs_m_20_28  1
    r[20]     abs_p_20_29  -1
    r[20]     abs_m_20_29  1
    r[20]     abs_p_20_30  -1
    r[20]     abs_m_20_30  1
    r[20]     abs_p_20_31  -1
    r[20]     abs_m_20_31  1
    r[20]     abs_p_20_32  -1
    r[20]     abs_m_20_32  1
    r[20]     abs_p_20_33  -1
    r[20]     abs_m_20_33  1
    r[20]     abs_p_20_34  -1
    r[20]     abs_m_20_34  1
    r[20]     abs_p_20_35  -1
    r[20]     abs_m_20_35  1
    r[21]     normalized_ratio_21  1
    r[21]     normalization  1
    r[21]     abs_p_1_21  1
    r[21]     abs_m_1_21  -1
    r[21]     abs_p_2_21  1
    r[21]     abs_m_2_21  -1
    r[21]     abs_p_3_21  1
    r[21]     abs_m_3_21  -1
    r[21]     abs_p_4_21  1
    r[21]     abs_m_4_21  -1
    r[21]     abs_p_5_21  1
    r[21]     abs_m_5_21  -1
    r[21]     abs_p_6_21  1
    r[21]     abs_m_6_21  -1
    r[21]     abs_p_7_21  1
    r[21]     abs_m_7_21  -1
    r[21]     abs_p_8_21  1
    r[21]     abs_m_8_21  -1
    r[21]     abs_p_9_21  1
    r[21]     abs_m_9_21  -1
    r[21]     abs_p_10_21  1
    r[21]     abs_m_10_21  -1
    r[21]     abs_p_11_21  1
    r[21]     abs_m_11_21  -1
    r[21]     abs_p_12_21  1
    r[21]     abs_m_12_21  -1
    r[21]     abs_p_13_21  1
    r[21]     abs_m_13_21  -1
    r[21]     abs_p_14_21  1
    r[21]     abs_m_14_21  -1
    r[21]     abs_p_15_21  1
    r[21]     abs_m_15_21  -1
    r[21]     abs_p_16_21  1
    r[21]     abs_m_16_21  -1
    r[21]     abs_p_17_21  1
    r[21]     abs_m_17_21  -1
    r[21]     abs_p_18_21  1
    r[21]     abs_m_18_21  -1
    r[21]     abs_p_19_21  1
    r[21]     abs_m_19_21  -1
    r[21]     abs_p_20_21  1
    r[21]     abs_m_20_21  -1
    r[21]     abs_p_21_22  -1
    r[21]     abs_m_21_22  1
    r[21]     abs_p_21_23  -1
    r[21]     abs_m_21_23  1
    r[21]     abs_p_21_24  -1
    r[21]     abs_m_21_24  1
    r[21]     abs_p_21_25  -1
    r[21]     abs_m_21_25  1
    r[21]     abs_p_21_26  -1
    r[21]     abs_m_21_26  1
    r[21]     abs_p_21_27  -1
    r[21]     abs_m_21_27  1
    r[21]     abs_p_21_28  -1
    r[21]     abs_m_21_28  1
    r[21]     abs_p_21_29  -1
    r[21]     abs_m_21_29  1
    r[21]     abs_p_21_30  -1
    r[21]     abs_m_21_30  1
    r[21]     abs_p_21_31  -1
    r[21]     abs_m_21_31  1
    r[21]     abs_p_21_32  -1
    r[21]     abs_m_21_32  1
    r[21]     abs_p_21_33  -1
    r[21]     abs_m_21_33  1
    r[21]     abs_p_21_34  -1
    r[21]     abs_m_21_34  1
    r[21]     abs_p_21_35  -1
    r[21]     abs_m_21_35  1
    r[22]     normalized_ratio_22  1
    r[22]     normalization  1
    r[22]     abs_p_1_22  1
    r[22]     abs_m_1_22  -1
    r[22]     abs_p_2_22  1
    r[22]     abs_m_2_22  -1
    r[22]     abs_p_3_22  1
    r[22]     abs_m_3_22  -1
    r[22]     abs_p_4_22  1
    r[22]     abs_m_4_22  -1
    r[22]     abs_p_5_22  1
    r[22]     abs_m_5_22  -1
    r[22]     abs_p_6_22  1
    r[22]     abs_m_6_22  -1
    r[22]     abs_p_7_22  1
    r[22]     abs_m_7_22  -1
    r[22]     abs_p_8_22  1
    r[22]     abs_m_8_22  -1
    r[22]     abs_p_9_22  1
    r[22]     abs_m_9_22  -1
    r[22]     abs_p_10_22  1
    r[22]     abs_m_10_22  -1
    r[22]     abs_p_11_22  1
    r[22]     abs_m_11_22  -1
    r[22]     abs_p_12_22  1
    r[22]     abs_m_12_22  -1
    r[22]     abs_p_13_22  1
    r[22]     abs_m_13_22  -1
    r[22]     abs_p_14_22  1
    r[22]     abs_m_14_22  -1
    r[22]     abs_p_15_22  1
    r[22]     abs_m_15_22  -1
    r[22]     abs_p_16_22  1
    r[22]     abs_m_16_22  -1
    r[22]     abs_p_17_22  1
    r[22]     abs_m_17_22  -1
    r[22]     abs_p_18_22  1
    r[22]     abs_m_18_22  -1
    r[22]     abs_p_19_22  1
    r[22]     abs_m_19_22  -1
    r[22]     abs_p_20_22  1
    r[22]     abs_m_20_22  -1
    r[22]     abs_p_21_22  1
    r[22]     abs_m_21_22  -1
    r[22]     abs_p_22_23  -1
    r[22]     abs_m_22_23  1
    r[22]     abs_p_22_24  -1
    r[22]     abs_m_22_24  1
    r[22]     abs_p_22_25  -1
    r[22]     abs_m_22_25  1
    r[22]     abs_p_22_26  -1
    r[22]     abs_m_22_26  1
    r[22]     abs_p_22_27  -1
    r[22]     abs_m_22_27  1
    r[22]     abs_p_22_28  -1
    r[22]     abs_m_22_28  1
    r[22]     abs_p_22_29  -1
    r[22]     abs_m_22_29  1
    r[22]     abs_p_22_30  -1
    r[22]     abs_m_22_30  1
    r[22]     abs_p_22_31  -1
    r[22]     abs_m_22_31  1
    r[22]     abs_p_22_32  -1
    r[22]     abs_m_22_32  1
    r[22]     abs_p_22_33  -1
    r[22]     abs_m_22_33  1
    r[22]     abs_p_22_34  -1
    r[22]     abs_m_22_34  1
    r[22]     abs_p_22_35  -1
    r[22]     abs_m_22_35  1
    r[23]     normalized_ratio_23  1
    r[23]     normalization  1
    r[23]     abs_p_1_23  1
    r[23]     abs_m_1_23  -1
    r[23]     abs_p_2_23  1
    r[23]     abs_m_2_23  -1
    r[23]     abs_p_3_23  1
    r[23]     abs_m_3_23  -1
    r[23]     abs_p_4_23  1
    r[23]     abs_m_4_23  -1
    r[23]     abs_p_5_23  1
    r[23]     abs_m_5_23  -1
    r[23]     abs_p_6_23  1
    r[23]     abs_m_6_23  -1
    r[23]     abs_p_7_23  1
    r[23]     abs_m_7_23  -1
    r[23]     abs_p_8_23  1
    r[23]     abs_m_8_23  -1
    r[23]     abs_p_9_23  1
    r[23]     abs_m_9_23  -1
    r[23]     abs_p_10_23  1
    r[23]     abs_m_10_23  -1
    r[23]     abs_p_11_23  1
    r[23]     abs_m_11_23  -1
    r[23]     abs_p_12_23  1
    r[23]     abs_m_12_23  -1
    r[23]     abs_p_13_23  1
    r[23]     abs_m_13_23  -1
    r[23]     abs_p_14_23  1
    r[23]     abs_m_14_23  -1
    r[23]     abs_p_15_23  1
    r[23]     abs_m_15_23  -1
    r[23]     abs_p_16_23  1
    r[23]     abs_m_16_23  -1
    r[23]     abs_p_17_23  1
    r[23]     abs_m_17_23  -1
    r[23]     abs_p_18_23  1
    r[23]     abs_m_18_23  -1
    r[23]     abs_p_19_23  1
    r[23]     abs_m_19_23  -1
    r[23]     abs_p_20_23  1
    r[23]     abs_m_20_23  -1
    r[23]     abs_p_21_23  1
    r[23]     abs_m_21_23  -1
    r[23]     abs_p_22_23  1
    r[23]     abs_m_22_23  -1
    r[23]     abs_p_23_24  -1
    r[23]     abs_m_23_24  1
    r[23]     abs_p_23_25  -1
    r[23]     abs_m_23_25  1
    r[23]     abs_p_23_26  -1
    r[23]     abs_m_23_26  1
    r[23]     abs_p_23_27  -1
    r[23]     abs_m_23_27  1
    r[23]     abs_p_23_28  -1
    r[23]     abs_m_23_28  1
    r[23]     abs_p_23_29  -1
    r[23]     abs_m_23_29  1
    r[23]     abs_p_23_30  -1
    r[23]     abs_m_23_30  1
    r[23]     abs_p_23_31  -1
    r[23]     abs_m_23_31  1
    r[23]     abs_p_23_32  -1
    r[23]     abs_m_23_32  1
    r[23]     abs_p_23_33  -1
    r[23]     abs_m_23_33  1
    r[23]     abs_p_23_34  -1
    r[23]     abs_m_23_34  1
    r[23]     abs_p_23_35  -1
    r[23]     abs_m_23_35  1
    r[24]     normalized_ratio_24  1
    r[24]     normalization  1
    r[24]     abs_p_1_24  1
    r[24]     abs_m_1_24  -1
    r[24]     abs_p_2_24  1
    r[24]     abs_m_2_24  -1
    r[24]     abs_p_3_24  1
    r[24]     abs_m_3_24  -1
    r[24]     abs_p_4_24  1
    r[24]     abs_m_4_24  -1
    r[24]     abs_p_5_24  1
    r[24]     abs_m_5_24  -1
    r[24]     abs_p_6_24  1
    r[24]     abs_m_6_24  -1
    r[24]     abs_p_7_24  1
    r[24]     abs_m_7_24  -1
    r[24]     abs_p_8_24  1
    r[24]     abs_m_8_24  -1
    r[24]     abs_p_9_24  1
    r[24]     abs_m_9_24  -1
    r[24]     abs_p_10_24  1
    r[24]     abs_m_10_24  -1
    r[24]     abs_p_11_24  1
    r[24]     abs_m_11_24  -1
    r[24]     abs_p_12_24  1
    r[24]     abs_m_12_24  -1
    r[24]     abs_p_13_24  1
    r[24]     abs_m_13_24  -1
    r[24]     abs_p_14_24  1
    r[24]     abs_m_14_24  -1
    r[24]     abs_p_15_24  1
    r[24]     abs_m_15_24  -1
    r[24]     abs_p_16_24  1
    r[24]     abs_m_16_24  -1
    r[24]     abs_p_17_24  1
    r[24]     abs_m_17_24  -1
    r[24]     abs_p_18_24  1
    r[24]     abs_m_18_24  -1
    r[24]     abs_p_19_24  1
    r[24]     abs_m_19_24  -1
    r[24]     abs_p_20_24  1
    r[24]     abs_m_20_24  -1
    r[24]     abs_p_21_24  1
    r[24]     abs_m_21_24  -1
    r[24]     abs_p_22_24  1
    r[24]     abs_m_22_24  -1
    r[24]     abs_p_23_24  1
    r[24]     abs_m_23_24  -1
    r[24]     abs_p_24_25  -1
    r[24]     abs_m_24_25  1
    r[24]     abs_p_24_26  -1
    r[24]     abs_m_24_26  1
    r[24]     abs_p_24_27  -1
    r[24]     abs_m_24_27  1
    r[24]     abs_p_24_28  -1
    r[24]     abs_m_24_28  1
    r[24]     abs_p_24_29  -1
    r[24]     abs_m_24_29  1
    r[24]     abs_p_24_30  -1
    r[24]     abs_m_24_30  1
    r[24]     abs_p_24_31  -1
    r[24]     abs_m_24_31  1
    r[24]     abs_p_24_32  -1
    r[24]     abs_m_24_32  1
    r[24]     abs_p_24_33  -1
    r[24]     abs_m_24_33  1
    r[24]     abs_p_24_34  -1
    r[24]     abs_m_24_34  1
    r[24]     abs_p_24_35  -1
    r[24]     abs_m_24_35  1
    r[25]     normalized_ratio_25  1
    r[25]     normalization  1
    r[25]     abs_p_1_25  1
    r[25]     abs_m_1_25  -1
    r[25]     abs_p_2_25  1
    r[25]     abs_m_2_25  -1
    r[25]     abs_p_3_25  1
    r[25]     abs_m_3_25  -1
    r[25]     abs_p_4_25  1
    r[25]     abs_m_4_25  -1
    r[25]     abs_p_5_25  1
    r[25]     abs_m_5_25  -1
    r[25]     abs_p_6_25  1
    r[25]     abs_m_6_25  -1
    r[25]     abs_p_7_25  1
    r[25]     abs_m_7_25  -1
    r[25]     abs_p_8_25  1
    r[25]     abs_m_8_25  -1
    r[25]     abs_p_9_25  1
    r[25]     abs_m_9_25  -1
    r[25]     abs_p_10_25  1
    r[25]     abs_m_10_25  -1
    r[25]     abs_p_11_25  1
    r[25]     abs_m_11_25  -1
    r[25]     abs_p_12_25  1
    r[25]     abs_m_12_25  -1
    r[25]     abs_p_13_25  1
    r[25]     abs_m_13_25  -1
    r[25]     abs_p_14_25  1
    r[25]     abs_m_14_25  -1
    r[25]     abs_p_15_25  1
    r[25]     abs_m_15_25  -1
    r[25]     abs_p_16_25  1
    r[25]     abs_m_16_25  -1
    r[25]     abs_p_17_25  1
    r[25]     abs_m_17_25  -1
    r[25]     abs_p_18_25  1
    r[25]     abs_m_18_25  -1
    r[25]     abs_p_19_25  1
    r[25]     abs_m_19_25  -1
    r[25]     abs_p_20_25  1
    r[25]     abs_m_20_25  -1
    r[25]     abs_p_21_25  1
    r[25]     abs_m_21_25  -1
    r[25]     abs_p_22_25  1
    r[25]     abs_m_22_25  -1
    r[25]     abs_p_23_25  1
    r[25]     abs_m_23_25  -1
    r[25]     abs_p_24_25  1
    r[25]     abs_m_24_25  -1
    r[25]     abs_p_25_26  -1
    r[25]     abs_m_25_26  1
    r[25]     abs_p_25_27  -1
    r[25]     abs_m_25_27  1
    r[25]     abs_p_25_28  -1
    r[25]     abs_m_25_28  1
    r[25]     abs_p_25_29  -1
    r[25]     abs_m_25_29  1
    r[25]     abs_p_25_30  -1
    r[25]     abs_m_25_30  1
    r[25]     abs_p_25_31  -1
    r[25]     abs_m_25_31  1
    r[25]     abs_p_25_32  -1
    r[25]     abs_m_25_32  1
    r[25]     abs_p_25_33  -1
    r[25]     abs_m_25_33  1
    r[25]     abs_p_25_34  -1
    r[25]     abs_m_25_34  1
    r[25]     abs_p_25_35  -1
    r[25]     abs_m_25_35  1
    r[26]     normalized_ratio_26  1
    r[26]     normalization  1
    r[26]     abs_p_1_26  1
    r[26]     abs_m_1_26  -1
    r[26]     abs_p_2_26  1
    r[26]     abs_m_2_26  -1
    r[26]     abs_p_3_26  1
    r[26]     abs_m_3_26  -1
    r[26]     abs_p_4_26  1
    r[26]     abs_m_4_26  -1
    r[26]     abs_p_5_26  1
    r[26]     abs_m_5_26  -1
    r[26]     abs_p_6_26  1
    r[26]     abs_m_6_26  -1
    r[26]     abs_p_7_26  1
    r[26]     abs_m_7_26  -1
    r[26]     abs_p_8_26  1
    r[26]     abs_m_8_26  -1
    r[26]     abs_p_9_26  1
    r[26]     abs_m_9_26  -1
    r[26]     abs_p_10_26  1
    r[26]     abs_m_10_26  -1
    r[26]     abs_p_11_26  1
    r[26]     abs_m_11_26  -1
    r[26]     abs_p_12_26  1
    r[26]     abs_m_12_26  -1
    r[26]     abs_p_13_26  1
    r[26]     abs_m_13_26  -1
    r[26]     abs_p_14_26  1
    r[26]     abs_m_14_26  -1
    r[26]     abs_p_15_26  1
    r[26]     abs_m_15_26  -1
    r[26]     abs_p_16_26  1
    r[26]     abs_m_16_26  -1
    r[26]     abs_p_17_26  1
    r[26]     abs_m_17_26  -1
    r[26]     abs_p_18_26  1
    r[26]     abs_m_18_26  -1
    r[26]     abs_p_19_26  1
    r[26]     abs_m_19_26  -1
    r[26]     abs_p_20_26  1
    r[26]     abs_m_20_26  -1
    r[26]     abs_p_21_26  1
    r[26]     abs_m_21_26  -1
    r[26]     abs_p_22_26  1
    r[26]     abs_m_22_26  -1
    r[26]     abs_p_23_26  1
    r[26]     abs_m_23_26  -1
    r[26]     abs_p_24_26  1
    r[26]     abs_m_24_26  -1
    r[26]     abs_p_25_26  1
    r[26]     abs_m_25_26  -1
    r[26]     abs_p_26_27  -1
    r[26]     abs_m_26_27  1
    r[26]     abs_p_26_28  -1
    r[26]     abs_m_26_28  1
    r[26]     abs_p_26_29  -1
    r[26]     abs_m_26_29  1
    r[26]     abs_p_26_30  -1
    r[26]     abs_m_26_30  1
    r[26]     abs_p_26_31  -1
    r[26]     abs_m_26_31  1
    r[26]     abs_p_26_32  -1
    r[26]     abs_m_26_32  1
    r[26]     abs_p_26_33  -1
    r[26]     abs_m_26_33  1
    r[26]     abs_p_26_34  -1
    r[26]     abs_m_26_34  1
    r[26]     abs_p_26_35  -1
    r[26]     abs_m_26_35  1
    r[27]     normalized_ratio_27  1
    r[27]     normalization  1
    r[27]     abs_p_1_27  1
    r[27]     abs_m_1_27  -1
    r[27]     abs_p_2_27  1
    r[27]     abs_m_2_27  -1
    r[27]     abs_p_3_27  1
    r[27]     abs_m_3_27  -1
    r[27]     abs_p_4_27  1
    r[27]     abs_m_4_27  -1
    r[27]     abs_p_5_27  1
    r[27]     abs_m_5_27  -1
    r[27]     abs_p_6_27  1
    r[27]     abs_m_6_27  -1
    r[27]     abs_p_7_27  1
    r[27]     abs_m_7_27  -1
    r[27]     abs_p_8_27  1
    r[27]     abs_m_8_27  -1
    r[27]     abs_p_9_27  1
    r[27]     abs_m_9_27  -1
    r[27]     abs_p_10_27  1
    r[27]     abs_m_10_27  -1
    r[27]     abs_p_11_27  1
    r[27]     abs_m_11_27  -1
    r[27]     abs_p_12_27  1
    r[27]     abs_m_12_27  -1
    r[27]     abs_p_13_27  1
    r[27]     abs_m_13_27  -1
    r[27]     abs_p_14_27  1
    r[27]     abs_m_14_27  -1
    r[27]     abs_p_15_27  1
    r[27]     abs_m_15_27  -1
    r[27]     abs_p_16_27  1
    r[27]     abs_m_16_27  -1
    r[27]     abs_p_17_27  1
    r[27]     abs_m_17_27  -1
    r[27]     abs_p_18_27  1
    r[27]     abs_m_18_27  -1
    r[27]     abs_p_19_27  1
    r[27]     abs_m_19_27  -1
    r[27]     abs_p_20_27  1
    r[27]     abs_m_20_27  -1
    r[27]     abs_p_21_27  1
    r[27]     abs_m_21_27  -1
    r[27]     abs_p_22_27  1
    r[27]     abs_m_22_27  -1
    r[27]     abs_p_23_27  1
    r[27]     abs_m_23_27  -1
    r[27]     abs_p_24_27  1
    r[27]     abs_m_24_27  -1
    r[27]     abs_p_25_27  1
    r[27]     abs_m_25_27  -1
    r[27]     abs_p_26_27  1
    r[27]     abs_m_26_27  -1
    r[27]     abs_p_27_28  -1
    r[27]     abs_m_27_28  1
    r[27]     abs_p_27_29  -1
    r[27]     abs_m_27_29  1
    r[27]     abs_p_27_30  -1
    r[27]     abs_m_27_30  1
    r[27]     abs_p_27_31  -1
    r[27]     abs_m_27_31  1
    r[27]     abs_p_27_32  -1
    r[27]     abs_m_27_32  1
    r[27]     abs_p_27_33  -1
    r[27]     abs_m_27_33  1
    r[27]     abs_p_27_34  -1
    r[27]     abs_m_27_34  1
    r[27]     abs_p_27_35  -1
    r[27]     abs_m_27_35  1
    r[28]     normalized_ratio_28  1
    r[28]     normalization  1
    r[28]     abs_p_1_28  1
    r[28]     abs_m_1_28  -1
    r[28]     abs_p_2_28  1
    r[28]     abs_m_2_28  -1
    r[28]     abs_p_3_28  1
    r[28]     abs_m_3_28  -1
    r[28]     abs_p_4_28  1
    r[28]     abs_m_4_28  -1
    r[28]     abs_p_5_28  1
    r[28]     abs_m_5_28  -1
    r[28]     abs_p_6_28  1
    r[28]     abs_m_6_28  -1
    r[28]     abs_p_7_28  1
    r[28]     abs_m_7_28  -1
    r[28]     abs_p_8_28  1
    r[28]     abs_m_8_28  -1
    r[28]     abs_p_9_28  1
    r[28]     abs_m_9_28  -1
    r[28]     abs_p_10_28  1
    r[28]     abs_m_10_28  -1
    r[28]     abs_p_11_28  1
    r[28]     abs_m_11_28  -1
    r[28]     abs_p_12_28  1
    r[28]     abs_m_12_28  -1
    r[28]     abs_p_13_28  1
    r[28]     abs_m_13_28  -1
    r[28]     abs_p_14_28  1
    r[28]     abs_m_14_28  -1
    r[28]     abs_p_15_28  1
    r[28]     abs_m_15_28  -1
    r[28]     abs_p_16_28  1
    r[28]     abs_m_16_28  -1
    r[28]     abs_p_17_28  1
    r[28]     abs_m_17_28  -1
    r[28]     abs_p_18_28  1
    r[28]     abs_m_18_28  -1
    r[28]     abs_p_19_28  1
    r[28]     abs_m_19_28  -1
    r[28]     abs_p_20_28  1
    r[28]     abs_m_20_28  -1
    r[28]     abs_p_21_28  1
    r[28]     abs_m_21_28  -1
    r[28]     abs_p_22_28  1
    r[28]     abs_m_22_28  -1
    r[28]     abs_p_23_28  1
    r[28]     abs_m_23_28  -1
    r[28]     abs_p_24_28  1
    r[28]     abs_m_24_28  -1
    r[28]     abs_p_25_28  1
    r[28]     abs_m_25_28  -1
    r[28]     abs_p_26_28  1
    r[28]     abs_m_26_28  -1
    r[28]     abs_p_27_28  1
    r[28]     abs_m_27_28  -1
    r[28]     abs_p_28_29  -1
    r[28]     abs_m_28_29  1
    r[28]     abs_p_28_30  -1
    r[28]     abs_m_28_30  1
    r[28]     abs_p_28_31  -1
    r[28]     abs_m_28_31  1
    r[28]     abs_p_28_32  -1
    r[28]     abs_m_28_32  1
    r[28]     abs_p_28_33  -1
    r[28]     abs_m_28_33  1
    r[28]     abs_p_28_34  -1
    r[28]     abs_m_28_34  1
    r[28]     abs_p_28_35  -1
    r[28]     abs_m_28_35  1
    r[29]     normalized_ratio_29  1
    r[29]     normalization  1
    r[29]     abs_p_1_29  1
    r[29]     abs_m_1_29  -1
    r[29]     abs_p_2_29  1
    r[29]     abs_m_2_29  -1
    r[29]     abs_p_3_29  1
    r[29]     abs_m_3_29  -1
    r[29]     abs_p_4_29  1
    r[29]     abs_m_4_29  -1
    r[29]     abs_p_5_29  1
    r[29]     abs_m_5_29  -1
    r[29]     abs_p_6_29  1
    r[29]     abs_m_6_29  -1
    r[29]     abs_p_7_29  1
    r[29]     abs_m_7_29  -1
    r[29]     abs_p_8_29  1
    r[29]     abs_m_8_29  -1
    r[29]     abs_p_9_29  1
    r[29]     abs_m_9_29  -1
    r[29]     abs_p_10_29  1
    r[29]     abs_m_10_29  -1
    r[29]     abs_p_11_29  1
    r[29]     abs_m_11_29  -1
    r[29]     abs_p_12_29  1
    r[29]     abs_m_12_29  -1
    r[29]     abs_p_13_29  1
    r[29]     abs_m_13_29  -1
    r[29]     abs_p_14_29  1
    r[29]     abs_m_14_29  -1
    r[29]     abs_p_15_29  1
    r[29]     abs_m_15_29  -1
    r[29]     abs_p_16_29  1
    r[29]     abs_m_16_29  -1
    r[29]     abs_p_17_29  1
    r[29]     abs_m_17_29  -1
    r[29]     abs_p_18_29  1
    r[29]     abs_m_18_29  -1
    r[29]     abs_p_19_29  1
    r[29]     abs_m_19_29  -1
    r[29]     abs_p_20_29  1
    r[29]     abs_m_20_29  -1
    r[29]     abs_p_21_29  1
    r[29]     abs_m_21_29  -1
    r[29]     abs_p_22_29  1
    r[29]     abs_m_22_29  -1
    r[29]     abs_p_23_29  1
    r[29]     abs_m_23_29  -1
    r[29]     abs_p_24_29  1
    r[29]     abs_m_24_29  -1
    r[29]     abs_p_25_29  1
    r[29]     abs_m_25_29  -1
    r[29]     abs_p_26_29  1
    r[29]     abs_m_26_29  -1
    r[29]     abs_p_27_29  1
    r[29]     abs_m_27_29  -1
    r[29]     abs_p_28_29  1
    r[29]     abs_m_28_29  -1
    r[29]     abs_p_29_30  -1
    r[29]     abs_m_29_30  1
    r[29]     abs_p_29_31  -1
    r[29]     abs_m_29_31  1
    r[29]     abs_p_29_32  -1
    r[29]     abs_m_29_32  1
    r[29]     abs_p_29_33  -1
    r[29]     abs_m_29_33  1
    r[29]     abs_p_29_34  -1
    r[29]     abs_m_29_34  1
    r[29]     abs_p_29_35  -1
    r[29]     abs_m_29_35  1
    r[30]     normalized_ratio_30  1
    r[30]     normalization  1
    r[30]     abs_p_1_30  1
    r[30]     abs_m_1_30  -1
    r[30]     abs_p_2_30  1
    r[30]     abs_m_2_30  -1
    r[30]     abs_p_3_30  1
    r[30]     abs_m_3_30  -1
    r[30]     abs_p_4_30  1
    r[30]     abs_m_4_30  -1
    r[30]     abs_p_5_30  1
    r[30]     abs_m_5_30  -1
    r[30]     abs_p_6_30  1
    r[30]     abs_m_6_30  -1
    r[30]     abs_p_7_30  1
    r[30]     abs_m_7_30  -1
    r[30]     abs_p_8_30  1
    r[30]     abs_m_8_30  -1
    r[30]     abs_p_9_30  1
    r[30]     abs_m_9_30  -1
    r[30]     abs_p_10_30  1
    r[30]     abs_m_10_30  -1
    r[30]     abs_p_11_30  1
    r[30]     abs_m_11_30  -1
    r[30]     abs_p_12_30  1
    r[30]     abs_m_12_30  -1
    r[30]     abs_p_13_30  1
    r[30]     abs_m_13_30  -1
    r[30]     abs_p_14_30  1
    r[30]     abs_m_14_30  -1
    r[30]     abs_p_15_30  1
    r[30]     abs_m_15_30  -1
    r[30]     abs_p_16_30  1
    r[30]     abs_m_16_30  -1
    r[30]     abs_p_17_30  1
    r[30]     abs_m_17_30  -1
    r[30]     abs_p_18_30  1
    r[30]     abs_m_18_30  -1
    r[30]     abs_p_19_30  1
    r[30]     abs_m_19_30  -1
    r[30]     abs_p_20_30  1
    r[30]     abs_m_20_30  -1
    r[30]     abs_p_21_30  1
    r[30]     abs_m_21_30  -1
    r[30]     abs_p_22_30  1
    r[30]     abs_m_22_30  -1
    r[30]     abs_p_23_30  1
    r[30]     abs_m_23_30  -1
    r[30]     abs_p_24_30  1
    r[30]     abs_m_24_30  -1
    r[30]     abs_p_25_30  1
    r[30]     abs_m_25_30  -1
    r[30]     abs_p_26_30  1
    r[30]     abs_m_26_30  -1
    r[30]     abs_p_27_30  1
    r[30]     abs_m_27_30  -1
    r[30]     abs_p_28_30  1
    r[30]     abs_m_28_30  -1
    r[30]     abs_p_29_30  1
    r[30]     abs_m_29_30  -1
    r[30]     abs_p_30_31  -1
    r[30]     abs_m_30_31  1
    r[30]     abs_p_30_32  -1
    r[30]     abs_m_30_32  1
    r[30]     abs_p_30_33  -1
    r[30]     abs_m_30_33  1
    r[30]     abs_p_30_34  -1
    r[30]     abs_m_30_34  1
    r[30]     abs_p_30_35  -1
    r[30]     abs_m_30_35  1
    r[31]     normalized_ratio_31  1
    r[31]     normalization  1
    r[31]     abs_p_1_31  1
    r[31]     abs_m_1_31  -1
    r[31]     abs_p_2_31  1
    r[31]     abs_m_2_31  -1
    r[31]     abs_p_3_31  1
    r[31]     abs_m_3_31  -1
    r[31]     abs_p_4_31  1
    r[31]     abs_m_4_31  -1
    r[31]     abs_p_5_31  1
    r[31]     abs_m_5_31  -1
    r[31]     abs_p_6_31  1
    r[31]     abs_m_6_31  -1
    r[31]     abs_p_7_31  1
    r[31]     abs_m_7_31  -1
    r[31]     abs_p_8_31  1
    r[31]     abs_m_8_31  -1
    r[31]     abs_p_9_31  1
    r[31]     abs_m_9_31  -1
    r[31]     abs_p_10_31  1
    r[31]     abs_m_10_31  -1
    r[31]     abs_p_11_31  1
    r[31]     abs_m_11_31  -1
    r[31]     abs_p_12_31  1
    r[31]     abs_m_12_31  -1
    r[31]     abs_p_13_31  1
    r[31]     abs_m_13_31  -1
    r[31]     abs_p_14_31  1
    r[31]     abs_m_14_31  -1
    r[31]     abs_p_15_31  1
    r[31]     abs_m_15_31  -1
    r[31]     abs_p_16_31  1
    r[31]     abs_m_16_31  -1
    r[31]     abs_p_17_31  1
    r[31]     abs_m_17_31  -1
    r[31]     abs_p_18_31  1
    r[31]     abs_m_18_31  -1
    r[31]     abs_p_19_31  1
    r[31]     abs_m_19_31  -1
    r[31]     abs_p_20_31  1
    r[31]     abs_m_20_31  -1
    r[31]     abs_p_21_31  1
    r[31]     abs_m_21_31  -1
    r[31]     abs_p_22_31  1
    r[31]     abs_m_22_31  -1
    r[31]     abs_p_23_31  1
    r[31]     abs_m_23_31  -1
    r[31]     abs_p_24_31  1
    r[31]     abs_m_24_31  -1
    r[31]     abs_p_25_31  1
    r[31]     abs_m_25_31  -1
    r[31]     abs_p_26_31  1
    r[31]     abs_m_26_31  -1
    r[31]     abs_p_27_31  1
    r[31]     abs_m_27_31  -1
    r[31]     abs_p_28_31  1
    r[31]     abs_m_28_31  -1
    r[31]     abs_p_29_31  1
    r[31]     abs_m_29_31  -1
    r[31]     abs_p_30_31  1
    r[31]     abs_m_30_31  -1
    r[31]     abs_p_31_32  -1
    r[31]     abs_m_31_32  1
    r[31]     abs_p_31_33  -1
    r[31]     abs_m_31_33  1
    r[31]     abs_p_31_34  -1
    r[31]     abs_m_31_34  1
    r[31]     abs_p_31_35  -1
    r[31]     abs_m_31_35  1
    r[32]     normalized_ratio_32  1
    r[32]     normalization  1
    r[32]     abs_p_1_32  1
    r[32]     abs_m_1_32  -1
    r[32]     abs_p_2_32  1
    r[32]     abs_m_2_32  -1
    r[32]     abs_p_3_32  1
    r[32]     abs_m_3_32  -1
    r[32]     abs_p_4_32  1
    r[32]     abs_m_4_32  -1
    r[32]     abs_p_5_32  1
    r[32]     abs_m_5_32  -1
    r[32]     abs_p_6_32  1
    r[32]     abs_m_6_32  -1
    r[32]     abs_p_7_32  1
    r[32]     abs_m_7_32  -1
    r[32]     abs_p_8_32  1
    r[32]     abs_m_8_32  -1
    r[32]     abs_p_9_32  1
    r[32]     abs_m_9_32  -1
    r[32]     abs_p_10_32  1
    r[32]     abs_m_10_32  -1
    r[32]     abs_p_11_32  1
    r[32]     abs_m_11_32  -1
    r[32]     abs_p_12_32  1
    r[32]     abs_m_12_32  -1
    r[32]     abs_p_13_32  1
    r[32]     abs_m_13_32  -1
    r[32]     abs_p_14_32  1
    r[32]     abs_m_14_32  -1
    r[32]     abs_p_15_32  1
    r[32]     abs_m_15_32  -1
    r[32]     abs_p_16_32  1
    r[32]     abs_m_16_32  -1
    r[32]     abs_p_17_32  1
    r[32]     abs_m_17_32  -1
    r[32]     abs_p_18_32  1
    r[32]     abs_m_18_32  -1
    r[32]     abs_p_19_32  1
    r[32]     abs_m_19_32  -1
    r[32]     abs_p_20_32  1
    r[32]     abs_m_20_32  -1
    r[32]     abs_p_21_32  1
    r[32]     abs_m_21_32  -1
    r[32]     abs_p_22_32  1
    r[32]     abs_m_22_32  -1
    r[32]     abs_p_23_32  1
    r[32]     abs_m_23_32  -1
    r[32]     abs_p_24_32  1
    r[32]     abs_m_24_32  -1
    r[32]     abs_p_25_32  1
    r[32]     abs_m_25_32  -1
    r[32]     abs_p_26_32  1
    r[32]     abs_m_26_32  -1
    r[32]     abs_p_27_32  1
    r[32]     abs_m_27_32  -1
    r[32]     abs_p_28_32  1
    r[32]     abs_m_28_32  -1
    r[32]     abs_p_29_32  1
    r[32]     abs_m_29_32  -1
    r[32]     abs_p_30_32  1
    r[32]     abs_m_30_32  -1
    r[32]     abs_p_31_32  1
    r[32]     abs_m_31_32  -1
    r[32]     abs_p_32_33  -1
    r[32]     abs_m_32_33  1
    r[32]     abs_p_32_34  -1
    r[32]     abs_m_32_34  1
    r[32]     abs_p_32_35  -1
    r[32]     abs_m_32_35  1
    r[33]     normalized_ratio_33  1
    r[33]     normalization  1
    r[33]     abs_p_1_33  1
    r[33]     abs_m_1_33  -1
    r[33]     abs_p_2_33  1
    r[33]     abs_m_2_33  -1
    r[33]     abs_p_3_33  1
    r[33]     abs_m_3_33  -1
    r[33]     abs_p_4_33  1
    r[33]     abs_m_4_33  -1
    r[33]     abs_p_5_33  1
    r[33]     abs_m_5_33  -1
    r[33]     abs_p_6_33  1
    r[33]     abs_m_6_33  -1
    r[33]     abs_p_7_33  1
    r[33]     abs_m_7_33  -1
    r[33]     abs_p_8_33  1
    r[33]     abs_m_8_33  -1
    r[33]     abs_p_9_33  1
    r[33]     abs_m_9_33  -1
    r[33]     abs_p_10_33  1
    r[33]     abs_m_10_33  -1
    r[33]     abs_p_11_33  1
    r[33]     abs_m_11_33  -1
    r[33]     abs_p_12_33  1
    r[33]     abs_m_12_33  -1
    r[33]     abs_p_13_33  1
    r[33]     abs_m_13_33  -1
    r[33]     abs_p_14_33  1
    r[33]     abs_m_14_33  -1
    r[33]     abs_p_15_33  1
    r[33]     abs_m_15_33  -1
    r[33]     abs_p_16_33  1
    r[33]     abs_m_16_33  -1
    r[33]     abs_p_17_33  1
    r[33]     abs_m_17_33  -1
    r[33]     abs_p_18_33  1
    r[33]     abs_m_18_33  -1
    r[33]     abs_p_19_33  1
    r[33]     abs_m_19_33  -1
    r[33]     abs_p_20_33  1
    r[33]     abs_m_20_33  -1
    r[33]     abs_p_21_33  1
    r[33]     abs_m_21_33  -1
    r[33]     abs_p_22_33  1
    r[33]     abs_m_22_33  -1
    r[33]     abs_p_23_33  1
    r[33]     abs_m_23_33  -1
    r[33]     abs_p_24_33  1
    r[33]     abs_m_24_33  -1
    r[33]     abs_p_25_33  1
    r[33]     abs_m_25_33  -1
    r[33]     abs_p_26_33  1
    r[33]     abs_m_26_33  -1
    r[33]     abs_p_27_33  1
    r[33]     abs_m_27_33  -1
    r[33]     abs_p_28_33  1
    r[33]     abs_m_28_33  -1
    r[33]     abs_p_29_33  1
    r[33]     abs_m_29_33  -1
    r[33]     abs_p_30_33  1
    r[33]     abs_m_30_33  -1
    r[33]     abs_p_31_33  1
    r[33]     abs_m_31_33  -1
    r[33]     abs_p_32_33  1
    r[33]     abs_m_32_33  -1
    r[33]     abs_p_33_34  -1
    r[33]     abs_m_33_34  1
    r[33]     abs_p_33_35  -1
    r[33]     abs_m_33_35  1
    r[34]     normalized_ratio_34  1
    r[34]     normalization  1
    r[34]     abs_p_1_34  1
    r[34]     abs_m_1_34  -1
    r[34]     abs_p_2_34  1
    r[34]     abs_m_2_34  -1
    r[34]     abs_p_3_34  1
    r[34]     abs_m_3_34  -1
    r[34]     abs_p_4_34  1
    r[34]     abs_m_4_34  -1
    r[34]     abs_p_5_34  1
    r[34]     abs_m_5_34  -1
    r[34]     abs_p_6_34  1
    r[34]     abs_m_6_34  -1
    r[34]     abs_p_7_34  1
    r[34]     abs_m_7_34  -1
    r[34]     abs_p_8_34  1
    r[34]     abs_m_8_34  -1
    r[34]     abs_p_9_34  1
    r[34]     abs_m_9_34  -1
    r[34]     abs_p_10_34  1
    r[34]     abs_m_10_34  -1
    r[34]     abs_p_11_34  1
    r[34]     abs_m_11_34  -1
    r[34]     abs_p_12_34  1
    r[34]     abs_m_12_34  -1
    r[34]     abs_p_13_34  1
    r[34]     abs_m_13_34  -1
    r[34]     abs_p_14_34  1
    r[34]     abs_m_14_34  -1
    r[34]     abs_p_15_34  1
    r[34]     abs_m_15_34  -1
    r[34]     abs_p_16_34  1
    r[34]     abs_m_16_34  -1
    r[34]     abs_p_17_34  1
    r[34]     abs_m_17_34  -1
    r[34]     abs_p_18_34  1
    r[34]     abs_m_18_34  -1
    r[34]     abs_p_19_34  1
    r[34]     abs_m_19_34  -1
    r[34]     abs_p_20_34  1
    r[34]     abs_m_20_34  -1
    r[34]     abs_p_21_34  1
    r[34]     abs_m_21_34  -1
    r[34]     abs_p_22_34  1
    r[34]     abs_m_22_34  -1
    r[34]     abs_p_23_34  1
    r[34]     abs_m_23_34  -1
    r[34]     abs_p_24_34  1
    r[34]     abs_m_24_34  -1
    r[34]     abs_p_25_34  1
    r[34]     abs_m_25_34  -1
    r[34]     abs_p_26_34  1
    r[34]     abs_m_26_34  -1
    r[34]     abs_p_27_34  1
    r[34]     abs_m_27_34  -1
    r[34]     abs_p_28_34  1
    r[34]     abs_m_28_34  -1
    r[34]     abs_p_29_34  1
    r[34]     abs_m_29_34  -1
    r[34]     abs_p_30_34  1
    r[34]     abs_m_30_34  -1
    r[34]     abs_p_31_34  1
    r[34]     abs_m_31_34  -1
    r[34]     abs_p_32_34  1
    r[34]     abs_m_32_34  -1
    r[34]     abs_p_33_34  1
    r[34]     abs_m_33_34  -1
    r[34]     abs_p_34_35  -1
    r[34]     abs_m_34_35  1
    r[35]     normalized_ratio_35  1
    r[35]     normalization  1
    r[35]     abs_p_1_35  1
    r[35]     abs_m_1_35  -1
    r[35]     abs_p_2_35  1
    r[35]     abs_m_2_35  -1
    r[35]     abs_p_3_35  1
    r[35]     abs_m_3_35  -1
    r[35]     abs_p_4_35  1
    r[35]     abs_m_4_35  -1
    r[35]     abs_p_5_35  1
    r[35]     abs_m_5_35  -1
    r[35]     abs_p_6_35  1
    r[35]     abs_m_6_35  -1
    r[35]     abs_p_7_35  1
    r[35]     abs_m_7_35  -1
    r[35]     abs_p_8_35  1
    r[35]     abs_m_8_35  -1
    r[35]     abs_p_9_35  1
    r[35]     abs_m_9_35  -1
    r[35]     abs_p_10_35  1
    r[35]     abs_m_10_35  -1
    r[35]     abs_p_11_35  1
    r[35]     abs_m_11_35  -1
    r[35]     abs_p_12_35  1
    r[35]     abs_m_12_35  -1
    r[35]     abs_p_13_35  1
    r[35]     abs_m_13_35  -1
    r[35]     abs_p_14_35  1
    r[35]     abs_m_14_35  -1
    r[35]     abs_p_15_35  1
    r[35]     abs_m_15_35  -1
    r[35]     abs_p_16_35  1
    r[35]     abs_m_16_35  -1
    r[35]     abs_p_17_35  1
    r[35]     abs_m_17_35  -1
    r[35]     abs_p_18_35  1
    r[35]     abs_m_18_35  -1
    r[35]     abs_p_19_35  1
    r[35]     abs_m_19_35  -1
    r[35]     abs_p_20_35  1
    r[35]     abs_m_20_35  -1
    r[35]     abs_p_21_35  1
    r[35]     abs_m_21_35  -1
    r[35]     abs_p_22_35  1
    r[35]     abs_m_22_35  -1
    r[35]     abs_p_23_35  1
    r[35]     abs_m_23_35  -1
    r[35]     abs_p_24_35  1
    r[35]     abs_m_24_35  -1
    r[35]     abs_p_25_35  1
    r[35]     abs_m_25_35  -1
    r[35]     abs_p_26_35  1
    r[35]     abs_m_26_35  -1
    r[35]     abs_p_27_35  1
    r[35]     abs_m_27_35  -1
    r[35]     abs_p_28_35  1
    r[35]     abs_m_28_35  -1
    r[35]     abs_p_29_35  1
    r[35]     abs_m_29_35  -1
    r[35]     abs_p_30_35  1
    r[35]     abs_m_30_35  -1
    r[35]     abs_p_31_35  1
    r[35]     abs_m_31_35  -1
    r[35]     abs_p_32_35  1
    r[35]     abs_m_32_35  -1
    r[35]     abs_p_33_35  1
    r[35]     abs_m_33_35  -1
    r[35]     abs_p_34_35  1
    r[35]     abs_m_34_35  -1
    a[1,2]    abs_p_1_2  1
    a[1,2]    abs_m_1_2  1
    a[1,2]    true_G_epigraph  1
    a[1,2]    physical_G_upper  1
    a[1,2]    old_normalized_TC  1
    a[1,2]    old_normalized_TC2  1
    a[1,3]    abs_p_1_3  1
    a[1,3]    abs_m_1_3  1
    a[1,3]    true_G_epigraph  1
    a[1,3]    physical_G_upper  1
    a[1,3]    old_normalized_TC  1
    a[1,3]    old_normalized_TC2  1
    a[1,4]    abs_p_1_4  1
    a[1,4]    abs_m_1_4  1
    a[1,4]    true_G_epigraph  1
    a[1,4]    physical_G_upper  1
    a[1,4]    old_normalized_TC  1
    a[1,4]    old_normalized_TC2  1
    a[1,5]    abs_p_1_5  1
    a[1,5]    abs_m_1_5  1
    a[1,5]    true_G_epigraph  1
    a[1,5]    physical_G_upper  1
    a[1,5]    old_normalized_TC  1
    a[1,5]    old_normalized_TC2  1
    a[1,6]    abs_p_1_6  1
    a[1,6]    abs_m_1_6  1
    a[1,6]    true_G_epigraph  1
    a[1,6]    physical_G_upper  1
    a[1,6]    old_normalized_TC  1
    a[1,6]    old_normalized_TC2  1
    a[1,7]    abs_p_1_7  1
    a[1,7]    abs_m_1_7  1
    a[1,7]    true_G_epigraph  1
    a[1,7]    physical_G_upper  1
    a[1,7]    old_normalized_TC  1
    a[1,7]    old_normalized_TC2  1
    a[1,8]    abs_p_1_8  1
    a[1,8]    abs_m_1_8  1
    a[1,8]    true_G_epigraph  1
    a[1,8]    physical_G_upper  1
    a[1,8]    old_normalized_TC  1
    a[1,8]    old_normalized_TC2  1
    a[1,9]    abs_p_1_9  1
    a[1,9]    abs_m_1_9  1
    a[1,9]    true_G_epigraph  1
    a[1,9]    physical_G_upper  1
    a[1,9]    old_normalized_TC  1
    a[1,9]    old_normalized_TC2  1
    a[1,10]   abs_p_1_10  1
    a[1,10]   abs_m_1_10  1
    a[1,10]   true_G_epigraph  1
    a[1,10]   physical_G_upper  1
    a[1,10]   old_normalized_TC  1
    a[1,10]   old_normalized_TC2  1
    a[1,11]   abs_p_1_11  1
    a[1,11]   abs_m_1_11  1
    a[1,11]   true_G_epigraph  1
    a[1,11]   physical_G_upper  1
    a[1,11]   old_normalized_TC  1
    a[1,11]   old_normalized_TC2  1
    a[1,12]   abs_p_1_12  1
    a[1,12]   abs_m_1_12  1
    a[1,12]   true_G_epigraph  1
    a[1,12]   physical_G_upper  1
    a[1,12]   old_normalized_TC  1
    a[1,12]   old_normalized_TC2  1
    a[1,13]   abs_p_1_13  1
    a[1,13]   abs_m_1_13  1
    a[1,13]   true_G_epigraph  1
    a[1,13]   physical_G_upper  1
    a[1,13]   old_normalized_TC  1
    a[1,13]   old_normalized_TC2  1
    a[1,14]   abs_p_1_14  1
    a[1,14]   abs_m_1_14  1
    a[1,14]   true_G_epigraph  1
    a[1,14]   physical_G_upper  1
    a[1,14]   old_normalized_TC  1
    a[1,14]   old_normalized_TC2  1
    a[1,15]   abs_p_1_15  1
    a[1,15]   abs_m_1_15  1
    a[1,15]   true_G_epigraph  1
    a[1,15]   physical_G_upper  1
    a[1,15]   old_normalized_TC  1
    a[1,15]   old_normalized_TC2  1
    a[1,16]   abs_p_1_16  1
    a[1,16]   abs_m_1_16  1
    a[1,16]   true_G_epigraph  1
    a[1,16]   physical_G_upper  1
    a[1,16]   old_normalized_TC  1
    a[1,16]   old_normalized_TC2  1
    a[1,17]   abs_p_1_17  1
    a[1,17]   abs_m_1_17  1
    a[1,17]   true_G_epigraph  1
    a[1,17]   physical_G_upper  1
    a[1,17]   old_normalized_TC  1
    a[1,17]   old_normalized_TC2  1
    a[1,18]   abs_p_1_18  1
    a[1,18]   abs_m_1_18  1
    a[1,18]   true_G_epigraph  1
    a[1,18]   physical_G_upper  1
    a[1,18]   old_normalized_TC  1
    a[1,18]   old_normalized_TC2  1
    a[1,19]   abs_p_1_19  1
    a[1,19]   abs_m_1_19  1
    a[1,19]   true_G_epigraph  1
    a[1,19]   physical_G_upper  1
    a[1,19]   old_normalized_TC  1
    a[1,19]   old_normalized_TC2  1
    a[1,20]   abs_p_1_20  1
    a[1,20]   abs_m_1_20  1
    a[1,20]   true_G_epigraph  1
    a[1,20]   physical_G_upper  1
    a[1,20]   old_normalized_TC  1
    a[1,20]   old_normalized_TC2  1
    a[1,21]   abs_p_1_21  1
    a[1,21]   abs_m_1_21  1
    a[1,21]   true_G_epigraph  1
    a[1,21]   physical_G_upper  1
    a[1,21]   old_normalized_TC  1
    a[1,21]   old_normalized_TC2  1
    a[1,22]   abs_p_1_22  1
    a[1,22]   abs_m_1_22  1
    a[1,22]   true_G_epigraph  1
    a[1,22]   physical_G_upper  1
    a[1,22]   old_normalized_TC  1
    a[1,22]   old_normalized_TC2  1
    a[1,23]   abs_p_1_23  1
    a[1,23]   abs_m_1_23  1
    a[1,23]   true_G_epigraph  1
    a[1,23]   physical_G_upper  1
    a[1,23]   old_normalized_TC  1
    a[1,23]   old_normalized_TC2  1
    a[1,24]   abs_p_1_24  1
    a[1,24]   abs_m_1_24  1
    a[1,24]   true_G_epigraph  1
    a[1,24]   physical_G_upper  1
    a[1,24]   old_normalized_TC  1
    a[1,24]   old_normalized_TC2  1
    a[1,25]   abs_p_1_25  1
    a[1,25]   abs_m_1_25  1
    a[1,25]   true_G_epigraph  1
    a[1,25]   physical_G_upper  1
    a[1,25]   old_normalized_TC  1
    a[1,25]   old_normalized_TC2  1
    a[1,26]   abs_p_1_26  1
    a[1,26]   abs_m_1_26  1
    a[1,26]   true_G_epigraph  1
    a[1,26]   physical_G_upper  1
    a[1,26]   old_normalized_TC  1
    a[1,26]   old_normalized_TC2  1
    a[1,27]   abs_p_1_27  1
    a[1,27]   abs_m_1_27  1
    a[1,27]   true_G_epigraph  1
    a[1,27]   physical_G_upper  1
    a[1,27]   old_normalized_TC  1
    a[1,27]   old_normalized_TC2  1
    a[1,28]   abs_p_1_28  1
    a[1,28]   abs_m_1_28  1
    a[1,28]   true_G_epigraph  1
    a[1,28]   physical_G_upper  1
    a[1,28]   old_normalized_TC  1
    a[1,28]   old_normalized_TC2  1
    a[1,29]   abs_p_1_29  1
    a[1,29]   abs_m_1_29  1
    a[1,29]   true_G_epigraph  1
    a[1,29]   physical_G_upper  1
    a[1,29]   old_normalized_TC  1
    a[1,29]   old_normalized_TC2  1
    a[1,30]   abs_p_1_30  1
    a[1,30]   abs_m_1_30  1
    a[1,30]   true_G_epigraph  1
    a[1,30]   physical_G_upper  1
    a[1,30]   old_normalized_TC  1
    a[1,30]   old_normalized_TC2  1
    a[1,31]   abs_p_1_31  1
    a[1,31]   abs_m_1_31  1
    a[1,31]   true_G_epigraph  1
    a[1,31]   physical_G_upper  1
    a[1,31]   old_normalized_TC  1
    a[1,31]   old_normalized_TC2  1
    a[1,32]   abs_p_1_32  1
    a[1,32]   abs_m_1_32  1
    a[1,32]   true_G_epigraph  1
    a[1,32]   physical_G_upper  1
    a[1,32]   old_normalized_TC  1
    a[1,32]   old_normalized_TC2  1
    a[1,33]   abs_p_1_33  1
    a[1,33]   abs_m_1_33  1
    a[1,33]   true_G_epigraph  1
    a[1,33]   physical_G_upper  1
    a[1,33]   old_normalized_TC  1
    a[1,33]   old_normalized_TC2  1
    a[1,34]   abs_p_1_34  1
    a[1,34]   abs_m_1_34  1
    a[1,34]   true_G_epigraph  1
    a[1,34]   physical_G_upper  1
    a[1,34]   old_normalized_TC  1
    a[1,34]   old_normalized_TC2  1
    a[1,35]   abs_p_1_35  1
    a[1,35]   abs_m_1_35  1
    a[1,35]   true_G_epigraph  1
    a[1,35]   physical_G_upper  1
    a[1,35]   old_normalized_TC  1
    a[1,35]   old_normalized_TC2  1
    a[2,3]    abs_p_2_3  1
    a[2,3]    abs_m_2_3  1
    a[2,3]    true_G_epigraph  1
    a[2,3]    physical_G_upper  1
    a[2,3]    old_normalized_TC  1
    a[2,3]    old_normalized_TC2  1
    a[2,4]    abs_p_2_4  1
    a[2,4]    abs_m_2_4  1
    a[2,4]    true_G_epigraph  1
    a[2,4]    physical_G_upper  1
    a[2,4]    old_normalized_TC  1
    a[2,4]    old_normalized_TC2  1
    a[2,5]    abs_p_2_5  1
    a[2,5]    abs_m_2_5  1
    a[2,5]    true_G_epigraph  1
    a[2,5]    physical_G_upper  1
    a[2,5]    old_normalized_TC  1
    a[2,5]    old_normalized_TC2  1
    a[2,6]    abs_p_2_6  1
    a[2,6]    abs_m_2_6  1
    a[2,6]    true_G_epigraph  1
    a[2,6]    physical_G_upper  1
    a[2,6]    old_normalized_TC  1
    a[2,6]    old_normalized_TC2  1
    a[2,7]    abs_p_2_7  1
    a[2,7]    abs_m_2_7  1
    a[2,7]    true_G_epigraph  1
    a[2,7]    physical_G_upper  1
    a[2,7]    old_normalized_TC  1
    a[2,7]    old_normalized_TC2  1
    a[2,8]    abs_p_2_8  1
    a[2,8]    abs_m_2_8  1
    a[2,8]    true_G_epigraph  1
    a[2,8]    physical_G_upper  1
    a[2,8]    old_normalized_TC  1
    a[2,8]    old_normalized_TC2  1
    a[2,9]    abs_p_2_9  1
    a[2,9]    abs_m_2_9  1
    a[2,9]    true_G_epigraph  1
    a[2,9]    physical_G_upper  1
    a[2,9]    old_normalized_TC  1
    a[2,9]    old_normalized_TC2  1
    a[2,10]   abs_p_2_10  1
    a[2,10]   abs_m_2_10  1
    a[2,10]   true_G_epigraph  1
    a[2,10]   physical_G_upper  1
    a[2,10]   old_normalized_TC  1
    a[2,10]   old_normalized_TC2  1
    a[2,11]   abs_p_2_11  1
    a[2,11]   abs_m_2_11  1
    a[2,11]   true_G_epigraph  1
    a[2,11]   physical_G_upper  1
    a[2,11]   old_normalized_TC  1
    a[2,11]   old_normalized_TC2  1
    a[2,12]   abs_p_2_12  1
    a[2,12]   abs_m_2_12  1
    a[2,12]   true_G_epigraph  1
    a[2,12]   physical_G_upper  1
    a[2,12]   old_normalized_TC  1
    a[2,12]   old_normalized_TC2  1
    a[2,13]   abs_p_2_13  1
    a[2,13]   abs_m_2_13  1
    a[2,13]   true_G_epigraph  1
    a[2,13]   physical_G_upper  1
    a[2,13]   old_normalized_TC  1
    a[2,13]   old_normalized_TC2  1
    a[2,14]   abs_p_2_14  1
    a[2,14]   abs_m_2_14  1
    a[2,14]   true_G_epigraph  1
    a[2,14]   physical_G_upper  1
    a[2,14]   old_normalized_TC  1
    a[2,14]   old_normalized_TC2  1
    a[2,15]   abs_p_2_15  1
    a[2,15]   abs_m_2_15  1
    a[2,15]   true_G_epigraph  1
    a[2,15]   physical_G_upper  1
    a[2,15]   old_normalized_TC  1
    a[2,15]   old_normalized_TC2  1
    a[2,16]   abs_p_2_16  1
    a[2,16]   abs_m_2_16  1
    a[2,16]   true_G_epigraph  1
    a[2,16]   physical_G_upper  1
    a[2,16]   old_normalized_TC  1
    a[2,16]   old_normalized_TC2  1
    a[2,17]   abs_p_2_17  1
    a[2,17]   abs_m_2_17  1
    a[2,17]   true_G_epigraph  1
    a[2,17]   physical_G_upper  1
    a[2,17]   old_normalized_TC  1
    a[2,17]   old_normalized_TC2  1
    a[2,18]   abs_p_2_18  1
    a[2,18]   abs_m_2_18  1
    a[2,18]   true_G_epigraph  1
    a[2,18]   physical_G_upper  1
    a[2,18]   old_normalized_TC  1
    a[2,18]   old_normalized_TC2  1
    a[2,19]   abs_p_2_19  1
    a[2,19]   abs_m_2_19  1
    a[2,19]   true_G_epigraph  1
    a[2,19]   physical_G_upper  1
    a[2,19]   old_normalized_TC  1
    a[2,19]   old_normalized_TC2  1
    a[2,20]   abs_p_2_20  1
    a[2,20]   abs_m_2_20  1
    a[2,20]   true_G_epigraph  1
    a[2,20]   physical_G_upper  1
    a[2,20]   old_normalized_TC  1
    a[2,20]   old_normalized_TC2  1
    a[2,21]   abs_p_2_21  1
    a[2,21]   abs_m_2_21  1
    a[2,21]   true_G_epigraph  1
    a[2,21]   physical_G_upper  1
    a[2,21]   old_normalized_TC  1
    a[2,21]   old_normalized_TC2  1
    a[2,22]   abs_p_2_22  1
    a[2,22]   abs_m_2_22  1
    a[2,22]   true_G_epigraph  1
    a[2,22]   physical_G_upper  1
    a[2,22]   old_normalized_TC  1
    a[2,22]   old_normalized_TC2  1
    a[2,23]   abs_p_2_23  1
    a[2,23]   abs_m_2_23  1
    a[2,23]   true_G_epigraph  1
    a[2,23]   physical_G_upper  1
    a[2,23]   old_normalized_TC  1
    a[2,23]   old_normalized_TC2  1
    a[2,24]   abs_p_2_24  1
    a[2,24]   abs_m_2_24  1
    a[2,24]   true_G_epigraph  1
    a[2,24]   physical_G_upper  1
    a[2,24]   old_normalized_TC  1
    a[2,24]   old_normalized_TC2  1
    a[2,25]   abs_p_2_25  1
    a[2,25]   abs_m_2_25  1
    a[2,25]   true_G_epigraph  1
    a[2,25]   physical_G_upper  1
    a[2,25]   old_normalized_TC  1
    a[2,25]   old_normalized_TC2  1
    a[2,26]   abs_p_2_26  1
    a[2,26]   abs_m_2_26  1
    a[2,26]   true_G_epigraph  1
    a[2,26]   physical_G_upper  1
    a[2,26]   old_normalized_TC  1
    a[2,26]   old_normalized_TC2  1
    a[2,27]   abs_p_2_27  1
    a[2,27]   abs_m_2_27  1
    a[2,27]   true_G_epigraph  1
    a[2,27]   physical_G_upper  1
    a[2,27]   old_normalized_TC  1
    a[2,27]   old_normalized_TC2  1
    a[2,28]   abs_p_2_28  1
    a[2,28]   abs_m_2_28  1
    a[2,28]   true_G_epigraph  1
    a[2,28]   physical_G_upper  1
    a[2,28]   old_normalized_TC  1
    a[2,28]   old_normalized_TC2  1
    a[2,29]   abs_p_2_29  1
    a[2,29]   abs_m_2_29  1
    a[2,29]   true_G_epigraph  1
    a[2,29]   physical_G_upper  1
    a[2,29]   old_normalized_TC  1
    a[2,29]   old_normalized_TC2  1
    a[2,30]   abs_p_2_30  1
    a[2,30]   abs_m_2_30  1
    a[2,30]   true_G_epigraph  1
    a[2,30]   physical_G_upper  1
    a[2,30]   old_normalized_TC  1
    a[2,30]   old_normalized_TC2  1
    a[2,31]   abs_p_2_31  1
    a[2,31]   abs_m_2_31  1
    a[2,31]   true_G_epigraph  1
    a[2,31]   physical_G_upper  1
    a[2,31]   old_normalized_TC  1
    a[2,31]   old_normalized_TC2  1
    a[2,32]   abs_p_2_32  1
    a[2,32]   abs_m_2_32  1
    a[2,32]   true_G_epigraph  1
    a[2,32]   physical_G_upper  1
    a[2,32]   old_normalized_TC  1
    a[2,32]   old_normalized_TC2  1
    a[2,33]   abs_p_2_33  1
    a[2,33]   abs_m_2_33  1
    a[2,33]   true_G_epigraph  1
    a[2,33]   physical_G_upper  1
    a[2,33]   old_normalized_TC  1
    a[2,33]   old_normalized_TC2  1
    a[2,34]   abs_p_2_34  1
    a[2,34]   abs_m_2_34  1
    a[2,34]   true_G_epigraph  1
    a[2,34]   physical_G_upper  1
    a[2,34]   old_normalized_TC  1
    a[2,34]   old_normalized_TC2  1
    a[2,35]   abs_p_2_35  1
    a[2,35]   abs_m_2_35  1
    a[2,35]   true_G_epigraph  1
    a[2,35]   physical_G_upper  1
    a[2,35]   old_normalized_TC  1
    a[2,35]   old_normalized_TC2  1
    a[3,4]    abs_p_3_4  1
    a[3,4]    abs_m_3_4  1
    a[3,4]    true_G_epigraph  1
    a[3,4]    physical_G_upper  1
    a[3,4]    old_normalized_TC  1
    a[3,4]    old_normalized_TC2  1
    a[3,5]    abs_p_3_5  1
    a[3,5]    abs_m_3_5  1
    a[3,5]    true_G_epigraph  1
    a[3,5]    physical_G_upper  1
    a[3,5]    old_normalized_TC  1
    a[3,5]    old_normalized_TC2  1
    a[3,6]    abs_p_3_6  1
    a[3,6]    abs_m_3_6  1
    a[3,6]    true_G_epigraph  1
    a[3,6]    physical_G_upper  1
    a[3,6]    old_normalized_TC  1
    a[3,6]    old_normalized_TC2  1
    a[3,7]    abs_p_3_7  1
    a[3,7]    abs_m_3_7  1
    a[3,7]    true_G_epigraph  1
    a[3,7]    physical_G_upper  1
    a[3,7]    old_normalized_TC  1
    a[3,7]    old_normalized_TC2  1
    a[3,8]    abs_p_3_8  1
    a[3,8]    abs_m_3_8  1
    a[3,8]    true_G_epigraph  1
    a[3,8]    physical_G_upper  1
    a[3,8]    old_normalized_TC  1
    a[3,8]    old_normalized_TC2  1
    a[3,9]    abs_p_3_9  1
    a[3,9]    abs_m_3_9  1
    a[3,9]    true_G_epigraph  1
    a[3,9]    physical_G_upper  1
    a[3,9]    old_normalized_TC  1
    a[3,9]    old_normalized_TC2  1
    a[3,10]   abs_p_3_10  1
    a[3,10]   abs_m_3_10  1
    a[3,10]   true_G_epigraph  1
    a[3,10]   physical_G_upper  1
    a[3,10]   old_normalized_TC  1
    a[3,10]   old_normalized_TC2  1
    a[3,11]   abs_p_3_11  1
    a[3,11]   abs_m_3_11  1
    a[3,11]   true_G_epigraph  1
    a[3,11]   physical_G_upper  1
    a[3,11]   old_normalized_TC  1
    a[3,11]   old_normalized_TC2  1
    a[3,12]   abs_p_3_12  1
    a[3,12]   abs_m_3_12  1
    a[3,12]   true_G_epigraph  1
    a[3,12]   physical_G_upper  1
    a[3,12]   old_normalized_TC  1
    a[3,12]   old_normalized_TC2  1
    a[3,13]   abs_p_3_13  1
    a[3,13]   abs_m_3_13  1
    a[3,13]   true_G_epigraph  1
    a[3,13]   physical_G_upper  1
    a[3,13]   old_normalized_TC  1
    a[3,13]   old_normalized_TC2  1
    a[3,14]   abs_p_3_14  1
    a[3,14]   abs_m_3_14  1
    a[3,14]   true_G_epigraph  1
    a[3,14]   physical_G_upper  1
    a[3,14]   old_normalized_TC  1
    a[3,14]   old_normalized_TC2  1
    a[3,15]   abs_p_3_15  1
    a[3,15]   abs_m_3_15  1
    a[3,15]   true_G_epigraph  1
    a[3,15]   physical_G_upper  1
    a[3,15]   old_normalized_TC  1
    a[3,15]   old_normalized_TC2  1
    a[3,16]   abs_p_3_16  1
    a[3,16]   abs_m_3_16  1
    a[3,16]   true_G_epigraph  1
    a[3,16]   physical_G_upper  1
    a[3,16]   old_normalized_TC  1
    a[3,16]   old_normalized_TC2  1
    a[3,17]   abs_p_3_17  1
    a[3,17]   abs_m_3_17  1
    a[3,17]   true_G_epigraph  1
    a[3,17]   physical_G_upper  1
    a[3,17]   old_normalized_TC  1
    a[3,17]   old_normalized_TC2  1
    a[3,18]   abs_p_3_18  1
    a[3,18]   abs_m_3_18  1
    a[3,18]   true_G_epigraph  1
    a[3,18]   physical_G_upper  1
    a[3,18]   old_normalized_TC  1
    a[3,18]   old_normalized_TC2  1
    a[3,19]   abs_p_3_19  1
    a[3,19]   abs_m_3_19  1
    a[3,19]   true_G_epigraph  1
    a[3,19]   physical_G_upper  1
    a[3,19]   old_normalized_TC  1
    a[3,19]   old_normalized_TC2  1
    a[3,20]   abs_p_3_20  1
    a[3,20]   abs_m_3_20  1
    a[3,20]   true_G_epigraph  1
    a[3,20]   physical_G_upper  1
    a[3,20]   old_normalized_TC  1
    a[3,20]   old_normalized_TC2  1
    a[3,21]   abs_p_3_21  1
    a[3,21]   abs_m_3_21  1
    a[3,21]   true_G_epigraph  1
    a[3,21]   physical_G_upper  1
    a[3,21]   old_normalized_TC  1
    a[3,21]   old_normalized_TC2  1
    a[3,22]   abs_p_3_22  1
    a[3,22]   abs_m_3_22  1
    a[3,22]   true_G_epigraph  1
    a[3,22]   physical_G_upper  1
    a[3,22]   old_normalized_TC  1
    a[3,22]   old_normalized_TC2  1
    a[3,23]   abs_p_3_23  1
    a[3,23]   abs_m_3_23  1
    a[3,23]   true_G_epigraph  1
    a[3,23]   physical_G_upper  1
    a[3,23]   old_normalized_TC  1
    a[3,23]   old_normalized_TC2  1
    a[3,24]   abs_p_3_24  1
    a[3,24]   abs_m_3_24  1
    a[3,24]   true_G_epigraph  1
    a[3,24]   physical_G_upper  1
    a[3,24]   old_normalized_TC  1
    a[3,24]   old_normalized_TC2  1
    a[3,25]   abs_p_3_25  1
    a[3,25]   abs_m_3_25  1
    a[3,25]   true_G_epigraph  1
    a[3,25]   physical_G_upper  1
    a[3,25]   old_normalized_TC  1
    a[3,25]   old_normalized_TC2  1
    a[3,26]   abs_p_3_26  1
    a[3,26]   abs_m_3_26  1
    a[3,26]   true_G_epigraph  1
    a[3,26]   physical_G_upper  1
    a[3,26]   old_normalized_TC  1
    a[3,26]   old_normalized_TC2  1
    a[3,27]   abs_p_3_27  1
    a[3,27]   abs_m_3_27  1
    a[3,27]   true_G_epigraph  1
    a[3,27]   physical_G_upper  1
    a[3,27]   old_normalized_TC  1
    a[3,27]   old_normalized_TC2  1
    a[3,28]   abs_p_3_28  1
    a[3,28]   abs_m_3_28  1
    a[3,28]   true_G_epigraph  1
    a[3,28]   physical_G_upper  1
    a[3,28]   old_normalized_TC  1
    a[3,28]   old_normalized_TC2  1
    a[3,29]   abs_p_3_29  1
    a[3,29]   abs_m_3_29  1
    a[3,29]   true_G_epigraph  1
    a[3,29]   physical_G_upper  1
    a[3,29]   old_normalized_TC  1
    a[3,29]   old_normalized_TC2  1
    a[3,30]   abs_p_3_30  1
    a[3,30]   abs_m_3_30  1
    a[3,30]   true_G_epigraph  1
    a[3,30]   physical_G_upper  1
    a[3,30]   old_normalized_TC  1
    a[3,30]   old_normalized_TC2  1
    a[3,31]   abs_p_3_31  1
    a[3,31]   abs_m_3_31  1
    a[3,31]   true_G_epigraph  1
    a[3,31]   physical_G_upper  1
    a[3,31]   old_normalized_TC  1
    a[3,31]   old_normalized_TC2  1
    a[3,32]   abs_p_3_32  1
    a[3,32]   abs_m_3_32  1
    a[3,32]   true_G_epigraph  1
    a[3,32]   physical_G_upper  1
    a[3,32]   old_normalized_TC  1
    a[3,32]   old_normalized_TC2  1
    a[3,33]   abs_p_3_33  1
    a[3,33]   abs_m_3_33  1
    a[3,33]   true_G_epigraph  1
    a[3,33]   physical_G_upper  1
    a[3,33]   old_normalized_TC  1
    a[3,33]   old_normalized_TC2  1
    a[3,34]   abs_p_3_34  1
    a[3,34]   abs_m_3_34  1
    a[3,34]   true_G_epigraph  1
    a[3,34]   physical_G_upper  1
    a[3,34]   old_normalized_TC  1
    a[3,34]   old_normalized_TC2  1
    a[3,35]   abs_p_3_35  1
    a[3,35]   abs_m_3_35  1
    a[3,35]   true_G_epigraph  1
    a[3,35]   physical_G_upper  1
    a[3,35]   old_normalized_TC  1
    a[3,35]   old_normalized_TC2  1
    a[4,5]    abs_p_4_5  1
    a[4,5]    abs_m_4_5  1
    a[4,5]    true_G_epigraph  1
    a[4,5]    physical_G_upper  1
    a[4,5]    old_normalized_TC  1
    a[4,5]    old_normalized_TC2  1
    a[4,6]    abs_p_4_6  1
    a[4,6]    abs_m_4_6  1
    a[4,6]    true_G_epigraph  1
    a[4,6]    physical_G_upper  1
    a[4,6]    old_normalized_TC  1
    a[4,6]    old_normalized_TC2  1
    a[4,7]    abs_p_4_7  1
    a[4,7]    abs_m_4_7  1
    a[4,7]    true_G_epigraph  1
    a[4,7]    physical_G_upper  1
    a[4,7]    old_normalized_TC  1
    a[4,7]    old_normalized_TC2  1
    a[4,8]    abs_p_4_8  1
    a[4,8]    abs_m_4_8  1
    a[4,8]    true_G_epigraph  1
    a[4,8]    physical_G_upper  1
    a[4,8]    old_normalized_TC  1
    a[4,8]    old_normalized_TC2  1
    a[4,9]    abs_p_4_9  1
    a[4,9]    abs_m_4_9  1
    a[4,9]    true_G_epigraph  1
    a[4,9]    physical_G_upper  1
    a[4,9]    old_normalized_TC  1
    a[4,9]    old_normalized_TC2  1
    a[4,10]   abs_p_4_10  1
    a[4,10]   abs_m_4_10  1
    a[4,10]   true_G_epigraph  1
    a[4,10]   physical_G_upper  1
    a[4,10]   old_normalized_TC  1
    a[4,10]   old_normalized_TC2  1
    a[4,11]   abs_p_4_11  1
    a[4,11]   abs_m_4_11  1
    a[4,11]   true_G_epigraph  1
    a[4,11]   physical_G_upper  1
    a[4,11]   old_normalized_TC  1
    a[4,11]   old_normalized_TC2  1
    a[4,12]   abs_p_4_12  1
    a[4,12]   abs_m_4_12  1
    a[4,12]   true_G_epigraph  1
    a[4,12]   physical_G_upper  1
    a[4,12]   old_normalized_TC  1
    a[4,12]   old_normalized_TC2  1
    a[4,13]   abs_p_4_13  1
    a[4,13]   abs_m_4_13  1
    a[4,13]   true_G_epigraph  1
    a[4,13]   physical_G_upper  1
    a[4,13]   old_normalized_TC  1
    a[4,13]   old_normalized_TC2  1
    a[4,14]   abs_p_4_14  1
    a[4,14]   abs_m_4_14  1
    a[4,14]   true_G_epigraph  1
    a[4,14]   physical_G_upper  1
    a[4,14]   old_normalized_TC  1
    a[4,14]   old_normalized_TC2  1
    a[4,15]   abs_p_4_15  1
    a[4,15]   abs_m_4_15  1
    a[4,15]   true_G_epigraph  1
    a[4,15]   physical_G_upper  1
    a[4,15]   old_normalized_TC  1
    a[4,15]   old_normalized_TC2  1
    a[4,16]   abs_p_4_16  1
    a[4,16]   abs_m_4_16  1
    a[4,16]   true_G_epigraph  1
    a[4,16]   physical_G_upper  1
    a[4,16]   old_normalized_TC  1
    a[4,16]   old_normalized_TC2  1
    a[4,17]   abs_p_4_17  1
    a[4,17]   abs_m_4_17  1
    a[4,17]   true_G_epigraph  1
    a[4,17]   physical_G_upper  1
    a[4,17]   old_normalized_TC  1
    a[4,17]   old_normalized_TC2  1
    a[4,18]   abs_p_4_18  1
    a[4,18]   abs_m_4_18  1
    a[4,18]   true_G_epigraph  1
    a[4,18]   physical_G_upper  1
    a[4,18]   old_normalized_TC  1
    a[4,18]   old_normalized_TC2  1
    a[4,19]   abs_p_4_19  1
    a[4,19]   abs_m_4_19  1
    a[4,19]   true_G_epigraph  1
    a[4,19]   physical_G_upper  1
    a[4,19]   old_normalized_TC  1
    a[4,19]   old_normalized_TC2  1
    a[4,20]   abs_p_4_20  1
    a[4,20]   abs_m_4_20  1
    a[4,20]   true_G_epigraph  1
    a[4,20]   physical_G_upper  1
    a[4,20]   old_normalized_TC  1
    a[4,20]   old_normalized_TC2  1
    a[4,21]   abs_p_4_21  1
    a[4,21]   abs_m_4_21  1
    a[4,21]   true_G_epigraph  1
    a[4,21]   physical_G_upper  1
    a[4,21]   old_normalized_TC  1
    a[4,21]   old_normalized_TC2  1
    a[4,22]   abs_p_4_22  1
    a[4,22]   abs_m_4_22  1
    a[4,22]   true_G_epigraph  1
    a[4,22]   physical_G_upper  1
    a[4,22]   old_normalized_TC  1
    a[4,22]   old_normalized_TC2  1
    a[4,23]   abs_p_4_23  1
    a[4,23]   abs_m_4_23  1
    a[4,23]   true_G_epigraph  1
    a[4,23]   physical_G_upper  1
    a[4,23]   old_normalized_TC  1
    a[4,23]   old_normalized_TC2  1
    a[4,24]   abs_p_4_24  1
    a[4,24]   abs_m_4_24  1
    a[4,24]   true_G_epigraph  1
    a[4,24]   physical_G_upper  1
    a[4,24]   old_normalized_TC  1
    a[4,24]   old_normalized_TC2  1
    a[4,25]   abs_p_4_25  1
    a[4,25]   abs_m_4_25  1
    a[4,25]   true_G_epigraph  1
    a[4,25]   physical_G_upper  1
    a[4,25]   old_normalized_TC  1
    a[4,25]   old_normalized_TC2  1
    a[4,26]   abs_p_4_26  1
    a[4,26]   abs_m_4_26  1
    a[4,26]   true_G_epigraph  1
    a[4,26]   physical_G_upper  1
    a[4,26]   old_normalized_TC  1
    a[4,26]   old_normalized_TC2  1
    a[4,27]   abs_p_4_27  1
    a[4,27]   abs_m_4_27  1
    a[4,27]   true_G_epigraph  1
    a[4,27]   physical_G_upper  1
    a[4,27]   old_normalized_TC  1
    a[4,27]   old_normalized_TC2  1
    a[4,28]   abs_p_4_28  1
    a[4,28]   abs_m_4_28  1
    a[4,28]   true_G_epigraph  1
    a[4,28]   physical_G_upper  1
    a[4,28]   old_normalized_TC  1
    a[4,28]   old_normalized_TC2  1
    a[4,29]   abs_p_4_29  1
    a[4,29]   abs_m_4_29  1
    a[4,29]   true_G_epigraph  1
    a[4,29]   physical_G_upper  1
    a[4,29]   old_normalized_TC  1
    a[4,29]   old_normalized_TC2  1
    a[4,30]   abs_p_4_30  1
    a[4,30]   abs_m_4_30  1
    a[4,30]   true_G_epigraph  1
    a[4,30]   physical_G_upper  1
    a[4,30]   old_normalized_TC  1
    a[4,30]   old_normalized_TC2  1
    a[4,31]   abs_p_4_31  1
    a[4,31]   abs_m_4_31  1
    a[4,31]   true_G_epigraph  1
    a[4,31]   physical_G_upper  1
    a[4,31]   old_normalized_TC  1
    a[4,31]   old_normalized_TC2  1
    a[4,32]   abs_p_4_32  1
    a[4,32]   abs_m_4_32  1
    a[4,32]   true_G_epigraph  1
    a[4,32]   physical_G_upper  1
    a[4,32]   old_normalized_TC  1
    a[4,32]   old_normalized_TC2  1
    a[4,33]   abs_p_4_33  1
    a[4,33]   abs_m_4_33  1
    a[4,33]   true_G_epigraph  1
    a[4,33]   physical_G_upper  1
    a[4,33]   old_normalized_TC  1
    a[4,33]   old_normalized_TC2  1
    a[4,34]   abs_p_4_34  1
    a[4,34]   abs_m_4_34  1
    a[4,34]   true_G_epigraph  1
    a[4,34]   physical_G_upper  1
    a[4,34]   old_normalized_TC  1
    a[4,34]   old_normalized_TC2  1
    a[4,35]   abs_p_4_35  1
    a[4,35]   abs_m_4_35  1
    a[4,35]   true_G_epigraph  1
    a[4,35]   physical_G_upper  1
    a[4,35]   old_normalized_TC  1
    a[4,35]   old_normalized_TC2  1
    a[5,6]    abs_p_5_6  1
    a[5,6]    abs_m_5_6  1
    a[5,6]    true_G_epigraph  1
    a[5,6]    physical_G_upper  1
    a[5,6]    old_normalized_TC  1
    a[5,6]    old_normalized_TC2  1
    a[5,7]    abs_p_5_7  1
    a[5,7]    abs_m_5_7  1
    a[5,7]    true_G_epigraph  1
    a[5,7]    physical_G_upper  1
    a[5,7]    old_normalized_TC  1
    a[5,7]    old_normalized_TC2  1
    a[5,8]    abs_p_5_8  1
    a[5,8]    abs_m_5_8  1
    a[5,8]    true_G_epigraph  1
    a[5,8]    physical_G_upper  1
    a[5,8]    old_normalized_TC  1
    a[5,8]    old_normalized_TC2  1
    a[5,9]    abs_p_5_9  1
    a[5,9]    abs_m_5_9  1
    a[5,9]    true_G_epigraph  1
    a[5,9]    physical_G_upper  1
    a[5,9]    old_normalized_TC  1
    a[5,9]    old_normalized_TC2  1
    a[5,10]   abs_p_5_10  1
    a[5,10]   abs_m_5_10  1
    a[5,10]   true_G_epigraph  1
    a[5,10]   physical_G_upper  1
    a[5,10]   old_normalized_TC  1
    a[5,10]   old_normalized_TC2  1
    a[5,11]   abs_p_5_11  1
    a[5,11]   abs_m_5_11  1
    a[5,11]   true_G_epigraph  1
    a[5,11]   physical_G_upper  1
    a[5,11]   old_normalized_TC  1
    a[5,11]   old_normalized_TC2  1
    a[5,12]   abs_p_5_12  1
    a[5,12]   abs_m_5_12  1
    a[5,12]   true_G_epigraph  1
    a[5,12]   physical_G_upper  1
    a[5,12]   old_normalized_TC  1
    a[5,12]   old_normalized_TC2  1
    a[5,13]   abs_p_5_13  1
    a[5,13]   abs_m_5_13  1
    a[5,13]   true_G_epigraph  1
    a[5,13]   physical_G_upper  1
    a[5,13]   old_normalized_TC  1
    a[5,13]   old_normalized_TC2  1
    a[5,14]   abs_p_5_14  1
    a[5,14]   abs_m_5_14  1
    a[5,14]   true_G_epigraph  1
    a[5,14]   physical_G_upper  1
    a[5,14]   old_normalized_TC  1
    a[5,14]   old_normalized_TC2  1
    a[5,15]   abs_p_5_15  1
    a[5,15]   abs_m_5_15  1
    a[5,15]   true_G_epigraph  1
    a[5,15]   physical_G_upper  1
    a[5,15]   old_normalized_TC  1
    a[5,15]   old_normalized_TC2  1
    a[5,16]   abs_p_5_16  1
    a[5,16]   abs_m_5_16  1
    a[5,16]   true_G_epigraph  1
    a[5,16]   physical_G_upper  1
    a[5,16]   old_normalized_TC  1
    a[5,16]   old_normalized_TC2  1
    a[5,17]   abs_p_5_17  1
    a[5,17]   abs_m_5_17  1
    a[5,17]   true_G_epigraph  1
    a[5,17]   physical_G_upper  1
    a[5,17]   old_normalized_TC  1
    a[5,17]   old_normalized_TC2  1
    a[5,18]   abs_p_5_18  1
    a[5,18]   abs_m_5_18  1
    a[5,18]   true_G_epigraph  1
    a[5,18]   physical_G_upper  1
    a[5,18]   old_normalized_TC  1
    a[5,18]   old_normalized_TC2  1
    a[5,19]   abs_p_5_19  1
    a[5,19]   abs_m_5_19  1
    a[5,19]   true_G_epigraph  1
    a[5,19]   physical_G_upper  1
    a[5,19]   old_normalized_TC  1
    a[5,19]   old_normalized_TC2  1
    a[5,20]   abs_p_5_20  1
    a[5,20]   abs_m_5_20  1
    a[5,20]   true_G_epigraph  1
    a[5,20]   physical_G_upper  1
    a[5,20]   old_normalized_TC  1
    a[5,20]   old_normalized_TC2  1
    a[5,21]   abs_p_5_21  1
    a[5,21]   abs_m_5_21  1
    a[5,21]   true_G_epigraph  1
    a[5,21]   physical_G_upper  1
    a[5,21]   old_normalized_TC  1
    a[5,21]   old_normalized_TC2  1
    a[5,22]   abs_p_5_22  1
    a[5,22]   abs_m_5_22  1
    a[5,22]   true_G_epigraph  1
    a[5,22]   physical_G_upper  1
    a[5,22]   old_normalized_TC  1
    a[5,22]   old_normalized_TC2  1
    a[5,23]   abs_p_5_23  1
    a[5,23]   abs_m_5_23  1
    a[5,23]   true_G_epigraph  1
    a[5,23]   physical_G_upper  1
    a[5,23]   old_normalized_TC  1
    a[5,23]   old_normalized_TC2  1
    a[5,24]   abs_p_5_24  1
    a[5,24]   abs_m_5_24  1
    a[5,24]   true_G_epigraph  1
    a[5,24]   physical_G_upper  1
    a[5,24]   old_normalized_TC  1
    a[5,24]   old_normalized_TC2  1
    a[5,25]   abs_p_5_25  1
    a[5,25]   abs_m_5_25  1
    a[5,25]   true_G_epigraph  1
    a[5,25]   physical_G_upper  1
    a[5,25]   old_normalized_TC  1
    a[5,25]   old_normalized_TC2  1
    a[5,26]   abs_p_5_26  1
    a[5,26]   abs_m_5_26  1
    a[5,26]   true_G_epigraph  1
    a[5,26]   physical_G_upper  1
    a[5,26]   old_normalized_TC  1
    a[5,26]   old_normalized_TC2  1
    a[5,27]   abs_p_5_27  1
    a[5,27]   abs_m_5_27  1
    a[5,27]   true_G_epigraph  1
    a[5,27]   physical_G_upper  1
    a[5,27]   old_normalized_TC  1
    a[5,27]   old_normalized_TC2  1
    a[5,28]   abs_p_5_28  1
    a[5,28]   abs_m_5_28  1
    a[5,28]   true_G_epigraph  1
    a[5,28]   physical_G_upper  1
    a[5,28]   old_normalized_TC  1
    a[5,28]   old_normalized_TC2  1
    a[5,29]   abs_p_5_29  1
    a[5,29]   abs_m_5_29  1
    a[5,29]   true_G_epigraph  1
    a[5,29]   physical_G_upper  1
    a[5,29]   old_normalized_TC  1
    a[5,29]   old_normalized_TC2  1
    a[5,30]   abs_p_5_30  1
    a[5,30]   abs_m_5_30  1
    a[5,30]   true_G_epigraph  1
    a[5,30]   physical_G_upper  1
    a[5,30]   old_normalized_TC  1
    a[5,30]   old_normalized_TC2  1
    a[5,31]   abs_p_5_31  1
    a[5,31]   abs_m_5_31  1
    a[5,31]   true_G_epigraph  1
    a[5,31]   physical_G_upper  1
    a[5,31]   old_normalized_TC  1
    a[5,31]   old_normalized_TC2  1
    a[5,32]   abs_p_5_32  1
    a[5,32]   abs_m_5_32  1
    a[5,32]   true_G_epigraph  1
    a[5,32]   physical_G_upper  1
    a[5,32]   old_normalized_TC  1
    a[5,32]   old_normalized_TC2  1
    a[5,33]   abs_p_5_33  1
    a[5,33]   abs_m_5_33  1
    a[5,33]   true_G_epigraph  1
    a[5,33]   physical_G_upper  1
    a[5,33]   old_normalized_TC  1
    a[5,33]   old_normalized_TC2  1
    a[5,34]   abs_p_5_34  1
    a[5,34]   abs_m_5_34  1
    a[5,34]   true_G_epigraph  1
    a[5,34]   physical_G_upper  1
    a[5,34]   old_normalized_TC  1
    a[5,34]   old_normalized_TC2  1
    a[5,35]   abs_p_5_35  1
    a[5,35]   abs_m_5_35  1
    a[5,35]   true_G_epigraph  1
    a[5,35]   physical_G_upper  1
    a[5,35]   old_normalized_TC  1
    a[5,35]   old_normalized_TC2  1
    a[6,7]    abs_p_6_7  1
    a[6,7]    abs_m_6_7  1
    a[6,7]    true_G_epigraph  1
    a[6,7]    physical_G_upper  1
    a[6,7]    old_normalized_TC  1
    a[6,7]    old_normalized_TC2  1
    a[6,8]    abs_p_6_8  1
    a[6,8]    abs_m_6_8  1
    a[6,8]    true_G_epigraph  1
    a[6,8]    physical_G_upper  1
    a[6,8]    old_normalized_TC  1
    a[6,8]    old_normalized_TC2  1
    a[6,9]    abs_p_6_9  1
    a[6,9]    abs_m_6_9  1
    a[6,9]    true_G_epigraph  1
    a[6,9]    physical_G_upper  1
    a[6,9]    old_normalized_TC  1
    a[6,9]    old_normalized_TC2  1
    a[6,10]   abs_p_6_10  1
    a[6,10]   abs_m_6_10  1
    a[6,10]   true_G_epigraph  1
    a[6,10]   physical_G_upper  1
    a[6,10]   old_normalized_TC  1
    a[6,10]   old_normalized_TC2  1
    a[6,11]   abs_p_6_11  1
    a[6,11]   abs_m_6_11  1
    a[6,11]   true_G_epigraph  1
    a[6,11]   physical_G_upper  1
    a[6,11]   old_normalized_TC  1
    a[6,11]   old_normalized_TC2  1
    a[6,12]   abs_p_6_12  1
    a[6,12]   abs_m_6_12  1
    a[6,12]   true_G_epigraph  1
    a[6,12]   physical_G_upper  1
    a[6,12]   old_normalized_TC  1
    a[6,12]   old_normalized_TC2  1
    a[6,13]   abs_p_6_13  1
    a[6,13]   abs_m_6_13  1
    a[6,13]   true_G_epigraph  1
    a[6,13]   physical_G_upper  1
    a[6,13]   old_normalized_TC  1
    a[6,13]   old_normalized_TC2  1
    a[6,14]   abs_p_6_14  1
    a[6,14]   abs_m_6_14  1
    a[6,14]   true_G_epigraph  1
    a[6,14]   physical_G_upper  1
    a[6,14]   old_normalized_TC  1
    a[6,14]   old_normalized_TC2  1
    a[6,15]   abs_p_6_15  1
    a[6,15]   abs_m_6_15  1
    a[6,15]   true_G_epigraph  1
    a[6,15]   physical_G_upper  1
    a[6,15]   old_normalized_TC  1
    a[6,15]   old_normalized_TC2  1
    a[6,16]   abs_p_6_16  1
    a[6,16]   abs_m_6_16  1
    a[6,16]   true_G_epigraph  1
    a[6,16]   physical_G_upper  1
    a[6,16]   old_normalized_TC  1
    a[6,16]   old_normalized_TC2  1
    a[6,17]   abs_p_6_17  1
    a[6,17]   abs_m_6_17  1
    a[6,17]   true_G_epigraph  1
    a[6,17]   physical_G_upper  1
    a[6,17]   old_normalized_TC  1
    a[6,17]   old_normalized_TC2  1
    a[6,18]   abs_p_6_18  1
    a[6,18]   abs_m_6_18  1
    a[6,18]   true_G_epigraph  1
    a[6,18]   physical_G_upper  1
    a[6,18]   old_normalized_TC  1
    a[6,18]   old_normalized_TC2  1
    a[6,19]   abs_p_6_19  1
    a[6,19]   abs_m_6_19  1
    a[6,19]   true_G_epigraph  1
    a[6,19]   physical_G_upper  1
    a[6,19]   old_normalized_TC  1
    a[6,19]   old_normalized_TC2  1
    a[6,20]   abs_p_6_20  1
    a[6,20]   abs_m_6_20  1
    a[6,20]   true_G_epigraph  1
    a[6,20]   physical_G_upper  1
    a[6,20]   old_normalized_TC  1
    a[6,20]   old_normalized_TC2  1
    a[6,21]   abs_p_6_21  1
    a[6,21]   abs_m_6_21  1
    a[6,21]   true_G_epigraph  1
    a[6,21]   physical_G_upper  1
    a[6,21]   old_normalized_TC  1
    a[6,21]   old_normalized_TC2  1
    a[6,22]   abs_p_6_22  1
    a[6,22]   abs_m_6_22  1
    a[6,22]   true_G_epigraph  1
    a[6,22]   physical_G_upper  1
    a[6,22]   old_normalized_TC  1
    a[6,22]   old_normalized_TC2  1
    a[6,23]   abs_p_6_23  1
    a[6,23]   abs_m_6_23  1
    a[6,23]   true_G_epigraph  1
    a[6,23]   physical_G_upper  1
    a[6,23]   old_normalized_TC  1
    a[6,23]   old_normalized_TC2  1
    a[6,24]   abs_p_6_24  1
    a[6,24]   abs_m_6_24  1
    a[6,24]   true_G_epigraph  1
    a[6,24]   physical_G_upper  1
    a[6,24]   old_normalized_TC  1
    a[6,24]   old_normalized_TC2  1
    a[6,25]   abs_p_6_25  1
    a[6,25]   abs_m_6_25  1
    a[6,25]   true_G_epigraph  1
    a[6,25]   physical_G_upper  1
    a[6,25]   old_normalized_TC  1
    a[6,25]   old_normalized_TC2  1
    a[6,26]   abs_p_6_26  1
    a[6,26]   abs_m_6_26  1
    a[6,26]   true_G_epigraph  1
    a[6,26]   physical_G_upper  1
    a[6,26]   old_normalized_TC  1
    a[6,26]   old_normalized_TC2  1
    a[6,27]   abs_p_6_27  1
    a[6,27]   abs_m_6_27  1
    a[6,27]   true_G_epigraph  1
    a[6,27]   physical_G_upper  1
    a[6,27]   old_normalized_TC  1
    a[6,27]   old_normalized_TC2  1
    a[6,28]   abs_p_6_28  1
    a[6,28]   abs_m_6_28  1
    a[6,28]   true_G_epigraph  1
    a[6,28]   physical_G_upper  1
    a[6,28]   old_normalized_TC  1
    a[6,28]   old_normalized_TC2  1
    a[6,29]   abs_p_6_29  1
    a[6,29]   abs_m_6_29  1
    a[6,29]   true_G_epigraph  1
    a[6,29]   physical_G_upper  1
    a[6,29]   old_normalized_TC  1
    a[6,29]   old_normalized_TC2  1
    a[6,30]   abs_p_6_30  1
    a[6,30]   abs_m_6_30  1
    a[6,30]   true_G_epigraph  1
    a[6,30]   physical_G_upper  1
    a[6,30]   old_normalized_TC  1
    a[6,30]   old_normalized_TC2  1
    a[6,31]   abs_p_6_31  1
    a[6,31]   abs_m_6_31  1
    a[6,31]   true_G_epigraph  1
    a[6,31]   physical_G_upper  1
    a[6,31]   old_normalized_TC  1
    a[6,31]   old_normalized_TC2  1
    a[6,32]   abs_p_6_32  1
    a[6,32]   abs_m_6_32  1
    a[6,32]   true_G_epigraph  1
    a[6,32]   physical_G_upper  1
    a[6,32]   old_normalized_TC  1
    a[6,32]   old_normalized_TC2  1
    a[6,33]   abs_p_6_33  1
    a[6,33]   abs_m_6_33  1
    a[6,33]   true_G_epigraph  1
    a[6,33]   physical_G_upper  1
    a[6,33]   old_normalized_TC  1
    a[6,33]   old_normalized_TC2  1
    a[6,34]   abs_p_6_34  1
    a[6,34]   abs_m_6_34  1
    a[6,34]   true_G_epigraph  1
    a[6,34]   physical_G_upper  1
    a[6,34]   old_normalized_TC  1
    a[6,34]   old_normalized_TC2  1
    a[6,35]   abs_p_6_35  1
    a[6,35]   abs_m_6_35  1
    a[6,35]   true_G_epigraph  1
    a[6,35]   physical_G_upper  1
    a[6,35]   old_normalized_TC  1
    a[6,35]   old_normalized_TC2  1
    a[7,8]    abs_p_7_8  1
    a[7,8]    abs_m_7_8  1
    a[7,8]    true_G_epigraph  1
    a[7,8]    physical_G_upper  1
    a[7,8]    old_normalized_TC  1
    a[7,8]    old_normalized_TC2  1
    a[7,9]    abs_p_7_9  1
    a[7,9]    abs_m_7_9  1
    a[7,9]    true_G_epigraph  1
    a[7,9]    physical_G_upper  1
    a[7,9]    old_normalized_TC  1
    a[7,9]    old_normalized_TC2  1
    a[7,10]   abs_p_7_10  1
    a[7,10]   abs_m_7_10  1
    a[7,10]   true_G_epigraph  1
    a[7,10]   physical_G_upper  1
    a[7,10]   old_normalized_TC  1
    a[7,10]   old_normalized_TC2  1
    a[7,11]   abs_p_7_11  1
    a[7,11]   abs_m_7_11  1
    a[7,11]   true_G_epigraph  1
    a[7,11]   physical_G_upper  1
    a[7,11]   old_normalized_TC  1
    a[7,11]   old_normalized_TC2  1
    a[7,12]   abs_p_7_12  1
    a[7,12]   abs_m_7_12  1
    a[7,12]   true_G_epigraph  1
    a[7,12]   physical_G_upper  1
    a[7,12]   old_normalized_TC  1
    a[7,12]   old_normalized_TC2  1
    a[7,13]   abs_p_7_13  1
    a[7,13]   abs_m_7_13  1
    a[7,13]   true_G_epigraph  1
    a[7,13]   physical_G_upper  1
    a[7,13]   old_normalized_TC  1
    a[7,13]   old_normalized_TC2  1
    a[7,14]   abs_p_7_14  1
    a[7,14]   abs_m_7_14  1
    a[7,14]   true_G_epigraph  1
    a[7,14]   physical_G_upper  1
    a[7,14]   old_normalized_TC  1
    a[7,14]   old_normalized_TC2  1
    a[7,15]   abs_p_7_15  1
    a[7,15]   abs_m_7_15  1
    a[7,15]   true_G_epigraph  1
    a[7,15]   physical_G_upper  1
    a[7,15]   old_normalized_TC  1
    a[7,15]   old_normalized_TC2  1
    a[7,16]   abs_p_7_16  1
    a[7,16]   abs_m_7_16  1
    a[7,16]   true_G_epigraph  1
    a[7,16]   physical_G_upper  1
    a[7,16]   old_normalized_TC  1
    a[7,16]   old_normalized_TC2  1
    a[7,17]   abs_p_7_17  1
    a[7,17]   abs_m_7_17  1
    a[7,17]   true_G_epigraph  1
    a[7,17]   physical_G_upper  1
    a[7,17]   old_normalized_TC  1
    a[7,17]   old_normalized_TC2  1
    a[7,18]   abs_p_7_18  1
    a[7,18]   abs_m_7_18  1
    a[7,18]   true_G_epigraph  1
    a[7,18]   physical_G_upper  1
    a[7,18]   old_normalized_TC  1
    a[7,18]   old_normalized_TC2  1
    a[7,19]   abs_p_7_19  1
    a[7,19]   abs_m_7_19  1
    a[7,19]   true_G_epigraph  1
    a[7,19]   physical_G_upper  1
    a[7,19]   old_normalized_TC  1
    a[7,19]   old_normalized_TC2  1
    a[7,20]   abs_p_7_20  1
    a[7,20]   abs_m_7_20  1
    a[7,20]   true_G_epigraph  1
    a[7,20]   physical_G_upper  1
    a[7,20]   old_normalized_TC  1
    a[7,20]   old_normalized_TC2  1
    a[7,21]   abs_p_7_21  1
    a[7,21]   abs_m_7_21  1
    a[7,21]   true_G_epigraph  1
    a[7,21]   physical_G_upper  1
    a[7,21]   old_normalized_TC  1
    a[7,21]   old_normalized_TC2  1
    a[7,22]   abs_p_7_22  1
    a[7,22]   abs_m_7_22  1
    a[7,22]   true_G_epigraph  1
    a[7,22]   physical_G_upper  1
    a[7,22]   old_normalized_TC  1
    a[7,22]   old_normalized_TC2  1
    a[7,23]   abs_p_7_23  1
    a[7,23]   abs_m_7_23  1
    a[7,23]   true_G_epigraph  1
    a[7,23]   physical_G_upper  1
    a[7,23]   old_normalized_TC  1
    a[7,23]   old_normalized_TC2  1
    a[7,24]   abs_p_7_24  1
    a[7,24]   abs_m_7_24  1
    a[7,24]   true_G_epigraph  1
    a[7,24]   physical_G_upper  1
    a[7,24]   old_normalized_TC  1
    a[7,24]   old_normalized_TC2  1
    a[7,25]   abs_p_7_25  1
    a[7,25]   abs_m_7_25  1
    a[7,25]   true_G_epigraph  1
    a[7,25]   physical_G_upper  1
    a[7,25]   old_normalized_TC  1
    a[7,25]   old_normalized_TC2  1
    a[7,26]   abs_p_7_26  1
    a[7,26]   abs_m_7_26  1
    a[7,26]   true_G_epigraph  1
    a[7,26]   physical_G_upper  1
    a[7,26]   old_normalized_TC  1
    a[7,26]   old_normalized_TC2  1
    a[7,27]   abs_p_7_27  1
    a[7,27]   abs_m_7_27  1
    a[7,27]   true_G_epigraph  1
    a[7,27]   physical_G_upper  1
    a[7,27]   old_normalized_TC  1
    a[7,27]   old_normalized_TC2  1
    a[7,28]   abs_p_7_28  1
    a[7,28]   abs_m_7_28  1
    a[7,28]   true_G_epigraph  1
    a[7,28]   physical_G_upper  1
    a[7,28]   old_normalized_TC  1
    a[7,28]   old_normalized_TC2  1
    a[7,29]   abs_p_7_29  1
    a[7,29]   abs_m_7_29  1
    a[7,29]   true_G_epigraph  1
    a[7,29]   physical_G_upper  1
    a[7,29]   old_normalized_TC  1
    a[7,29]   old_normalized_TC2  1
    a[7,30]   abs_p_7_30  1
    a[7,30]   abs_m_7_30  1
    a[7,30]   true_G_epigraph  1
    a[7,30]   physical_G_upper  1
    a[7,30]   old_normalized_TC  1
    a[7,30]   old_normalized_TC2  1
    a[7,31]   abs_p_7_31  1
    a[7,31]   abs_m_7_31  1
    a[7,31]   true_G_epigraph  1
    a[7,31]   physical_G_upper  1
    a[7,31]   old_normalized_TC  1
    a[7,31]   old_normalized_TC2  1
    a[7,32]   abs_p_7_32  1
    a[7,32]   abs_m_7_32  1
    a[7,32]   true_G_epigraph  1
    a[7,32]   physical_G_upper  1
    a[7,32]   old_normalized_TC  1
    a[7,32]   old_normalized_TC2  1
    a[7,33]   abs_p_7_33  1
    a[7,33]   abs_m_7_33  1
    a[7,33]   true_G_epigraph  1
    a[7,33]   physical_G_upper  1
    a[7,33]   old_normalized_TC  1
    a[7,33]   old_normalized_TC2  1
    a[7,34]   abs_p_7_34  1
    a[7,34]   abs_m_7_34  1
    a[7,34]   true_G_epigraph  1
    a[7,34]   physical_G_upper  1
    a[7,34]   old_normalized_TC  1
    a[7,34]   old_normalized_TC2  1
    a[7,35]   abs_p_7_35  1
    a[7,35]   abs_m_7_35  1
    a[7,35]   true_G_epigraph  1
    a[7,35]   physical_G_upper  1
    a[7,35]   old_normalized_TC  1
    a[7,35]   old_normalized_TC2  1
    a[8,9]    abs_p_8_9  1
    a[8,9]    abs_m_8_9  1
    a[8,9]    true_G_epigraph  1
    a[8,9]    physical_G_upper  1
    a[8,9]    old_normalized_TC  1
    a[8,9]    old_normalized_TC2  1
    a[8,10]   abs_p_8_10  1
    a[8,10]   abs_m_8_10  1
    a[8,10]   true_G_epigraph  1
    a[8,10]   physical_G_upper  1
    a[8,10]   old_normalized_TC  1
    a[8,10]   old_normalized_TC2  1
    a[8,11]   abs_p_8_11  1
    a[8,11]   abs_m_8_11  1
    a[8,11]   true_G_epigraph  1
    a[8,11]   physical_G_upper  1
    a[8,11]   old_normalized_TC  1
    a[8,11]   old_normalized_TC2  1
    a[8,12]   abs_p_8_12  1
    a[8,12]   abs_m_8_12  1
    a[8,12]   true_G_epigraph  1
    a[8,12]   physical_G_upper  1
    a[8,12]   old_normalized_TC  1
    a[8,12]   old_normalized_TC2  1
    a[8,13]   abs_p_8_13  1
    a[8,13]   abs_m_8_13  1
    a[8,13]   true_G_epigraph  1
    a[8,13]   physical_G_upper  1
    a[8,13]   old_normalized_TC  1
    a[8,13]   old_normalized_TC2  1
    a[8,14]   abs_p_8_14  1
    a[8,14]   abs_m_8_14  1
    a[8,14]   true_G_epigraph  1
    a[8,14]   physical_G_upper  1
    a[8,14]   old_normalized_TC  1
    a[8,14]   old_normalized_TC2  1
    a[8,15]   abs_p_8_15  1
    a[8,15]   abs_m_8_15  1
    a[8,15]   true_G_epigraph  1
    a[8,15]   physical_G_upper  1
    a[8,15]   old_normalized_TC  1
    a[8,15]   old_normalized_TC2  1
    a[8,16]   abs_p_8_16  1
    a[8,16]   abs_m_8_16  1
    a[8,16]   true_G_epigraph  1
    a[8,16]   physical_G_upper  1
    a[8,16]   old_normalized_TC  1
    a[8,16]   old_normalized_TC2  1
    a[8,17]   abs_p_8_17  1
    a[8,17]   abs_m_8_17  1
    a[8,17]   true_G_epigraph  1
    a[8,17]   physical_G_upper  1
    a[8,17]   old_normalized_TC  1
    a[8,17]   old_normalized_TC2  1
    a[8,18]   abs_p_8_18  1
    a[8,18]   abs_m_8_18  1
    a[8,18]   true_G_epigraph  1
    a[8,18]   physical_G_upper  1
    a[8,18]   old_normalized_TC  1
    a[8,18]   old_normalized_TC2  1
    a[8,19]   abs_p_8_19  1
    a[8,19]   abs_m_8_19  1
    a[8,19]   true_G_epigraph  1
    a[8,19]   physical_G_upper  1
    a[8,19]   old_normalized_TC  1
    a[8,19]   old_normalized_TC2  1
    a[8,20]   abs_p_8_20  1
    a[8,20]   abs_m_8_20  1
    a[8,20]   true_G_epigraph  1
    a[8,20]   physical_G_upper  1
    a[8,20]   old_normalized_TC  1
    a[8,20]   old_normalized_TC2  1
    a[8,21]   abs_p_8_21  1
    a[8,21]   abs_m_8_21  1
    a[8,21]   true_G_epigraph  1
    a[8,21]   physical_G_upper  1
    a[8,21]   old_normalized_TC  1
    a[8,21]   old_normalized_TC2  1
    a[8,22]   abs_p_8_22  1
    a[8,22]   abs_m_8_22  1
    a[8,22]   true_G_epigraph  1
    a[8,22]   physical_G_upper  1
    a[8,22]   old_normalized_TC  1
    a[8,22]   old_normalized_TC2  1
    a[8,23]   abs_p_8_23  1
    a[8,23]   abs_m_8_23  1
    a[8,23]   true_G_epigraph  1
    a[8,23]   physical_G_upper  1
    a[8,23]   old_normalized_TC  1
    a[8,23]   old_normalized_TC2  1
    a[8,24]   abs_p_8_24  1
    a[8,24]   abs_m_8_24  1
    a[8,24]   true_G_epigraph  1
    a[8,24]   physical_G_upper  1
    a[8,24]   old_normalized_TC  1
    a[8,24]   old_normalized_TC2  1
    a[8,25]   abs_p_8_25  1
    a[8,25]   abs_m_8_25  1
    a[8,25]   true_G_epigraph  1
    a[8,25]   physical_G_upper  1
    a[8,25]   old_normalized_TC  1
    a[8,25]   old_normalized_TC2  1
    a[8,26]   abs_p_8_26  1
    a[8,26]   abs_m_8_26  1
    a[8,26]   true_G_epigraph  1
    a[8,26]   physical_G_upper  1
    a[8,26]   old_normalized_TC  1
    a[8,26]   old_normalized_TC2  1
    a[8,27]   abs_p_8_27  1
    a[8,27]   abs_m_8_27  1
    a[8,27]   true_G_epigraph  1
    a[8,27]   physical_G_upper  1
    a[8,27]   old_normalized_TC  1
    a[8,27]   old_normalized_TC2  1
    a[8,28]   abs_p_8_28  1
    a[8,28]   abs_m_8_28  1
    a[8,28]   true_G_epigraph  1
    a[8,28]   physical_G_upper  1
    a[8,28]   old_normalized_TC  1
    a[8,28]   old_normalized_TC2  1
    a[8,29]   abs_p_8_29  1
    a[8,29]   abs_m_8_29  1
    a[8,29]   true_G_epigraph  1
    a[8,29]   physical_G_upper  1
    a[8,29]   old_normalized_TC  1
    a[8,29]   old_normalized_TC2  1
    a[8,30]   abs_p_8_30  1
    a[8,30]   abs_m_8_30  1
    a[8,30]   true_G_epigraph  1
    a[8,30]   physical_G_upper  1
    a[8,30]   old_normalized_TC  1
    a[8,30]   old_normalized_TC2  1
    a[8,31]   abs_p_8_31  1
    a[8,31]   abs_m_8_31  1
    a[8,31]   true_G_epigraph  1
    a[8,31]   physical_G_upper  1
    a[8,31]   old_normalized_TC  1
    a[8,31]   old_normalized_TC2  1
    a[8,32]   abs_p_8_32  1
    a[8,32]   abs_m_8_32  1
    a[8,32]   true_G_epigraph  1
    a[8,32]   physical_G_upper  1
    a[8,32]   old_normalized_TC  1
    a[8,32]   old_normalized_TC2  1
    a[8,33]   abs_p_8_33  1
    a[8,33]   abs_m_8_33  1
    a[8,33]   true_G_epigraph  1
    a[8,33]   physical_G_upper  1
    a[8,33]   old_normalized_TC  1
    a[8,33]   old_normalized_TC2  1
    a[8,34]   abs_p_8_34  1
    a[8,34]   abs_m_8_34  1
    a[8,34]   true_G_epigraph  1
    a[8,34]   physical_G_upper  1
    a[8,34]   old_normalized_TC  1
    a[8,34]   old_normalized_TC2  1
    a[8,35]   abs_p_8_35  1
    a[8,35]   abs_m_8_35  1
    a[8,35]   true_G_epigraph  1
    a[8,35]   physical_G_upper  1
    a[8,35]   old_normalized_TC  1
    a[8,35]   old_normalized_TC2  1
    a[9,10]   abs_p_9_10  1
    a[9,10]   abs_m_9_10  1
    a[9,10]   true_G_epigraph  1
    a[9,10]   physical_G_upper  1
    a[9,10]   old_normalized_TC  1
    a[9,10]   old_normalized_TC2  1
    a[9,11]   abs_p_9_11  1
    a[9,11]   abs_m_9_11  1
    a[9,11]   true_G_epigraph  1
    a[9,11]   physical_G_upper  1
    a[9,11]   old_normalized_TC  1
    a[9,11]   old_normalized_TC2  1
    a[9,12]   abs_p_9_12  1
    a[9,12]   abs_m_9_12  1
    a[9,12]   true_G_epigraph  1
    a[9,12]   physical_G_upper  1
    a[9,12]   old_normalized_TC  1
    a[9,12]   old_normalized_TC2  1
    a[9,13]   abs_p_9_13  1
    a[9,13]   abs_m_9_13  1
    a[9,13]   true_G_epigraph  1
    a[9,13]   physical_G_upper  1
    a[9,13]   old_normalized_TC  1
    a[9,13]   old_normalized_TC2  1
    a[9,14]   abs_p_9_14  1
    a[9,14]   abs_m_9_14  1
    a[9,14]   true_G_epigraph  1
    a[9,14]   physical_G_upper  1
    a[9,14]   old_normalized_TC  1
    a[9,14]   old_normalized_TC2  1
    a[9,15]   abs_p_9_15  1
    a[9,15]   abs_m_9_15  1
    a[9,15]   true_G_epigraph  1
    a[9,15]   physical_G_upper  1
    a[9,15]   old_normalized_TC  1
    a[9,15]   old_normalized_TC2  1
    a[9,16]   abs_p_9_16  1
    a[9,16]   abs_m_9_16  1
    a[9,16]   true_G_epigraph  1
    a[9,16]   physical_G_upper  1
    a[9,16]   old_normalized_TC  1
    a[9,16]   old_normalized_TC2  1
    a[9,17]   abs_p_9_17  1
    a[9,17]   abs_m_9_17  1
    a[9,17]   true_G_epigraph  1
    a[9,17]   physical_G_upper  1
    a[9,17]   old_normalized_TC  1
    a[9,17]   old_normalized_TC2  1
    a[9,18]   abs_p_9_18  1
    a[9,18]   abs_m_9_18  1
    a[9,18]   true_G_epigraph  1
    a[9,18]   physical_G_upper  1
    a[9,18]   old_normalized_TC  1
    a[9,18]   old_normalized_TC2  1
    a[9,19]   abs_p_9_19  1
    a[9,19]   abs_m_9_19  1
    a[9,19]   true_G_epigraph  1
    a[9,19]   physical_G_upper  1
    a[9,19]   old_normalized_TC  1
    a[9,19]   old_normalized_TC2  1
    a[9,20]   abs_p_9_20  1
    a[9,20]   abs_m_9_20  1
    a[9,20]   true_G_epigraph  1
    a[9,20]   physical_G_upper  1
    a[9,20]   old_normalized_TC  1
    a[9,20]   old_normalized_TC2  1
    a[9,21]   abs_p_9_21  1
    a[9,21]   abs_m_9_21  1
    a[9,21]   true_G_epigraph  1
    a[9,21]   physical_G_upper  1
    a[9,21]   old_normalized_TC  1
    a[9,21]   old_normalized_TC2  1
    a[9,22]   abs_p_9_22  1
    a[9,22]   abs_m_9_22  1
    a[9,22]   true_G_epigraph  1
    a[9,22]   physical_G_upper  1
    a[9,22]   old_normalized_TC  1
    a[9,22]   old_normalized_TC2  1
    a[9,23]   abs_p_9_23  1
    a[9,23]   abs_m_9_23  1
    a[9,23]   true_G_epigraph  1
    a[9,23]   physical_G_upper  1
    a[9,23]   old_normalized_TC  1
    a[9,23]   old_normalized_TC2  1
    a[9,24]   abs_p_9_24  1
    a[9,24]   abs_m_9_24  1
    a[9,24]   true_G_epigraph  1
    a[9,24]   physical_G_upper  1
    a[9,24]   old_normalized_TC  1
    a[9,24]   old_normalized_TC2  1
    a[9,25]   abs_p_9_25  1
    a[9,25]   abs_m_9_25  1
    a[9,25]   true_G_epigraph  1
    a[9,25]   physical_G_upper  1
    a[9,25]   old_normalized_TC  1
    a[9,25]   old_normalized_TC2  1
    a[9,26]   abs_p_9_26  1
    a[9,26]   abs_m_9_26  1
    a[9,26]   true_G_epigraph  1
    a[9,26]   physical_G_upper  1
    a[9,26]   old_normalized_TC  1
    a[9,26]   old_normalized_TC2  1
    a[9,27]   abs_p_9_27  1
    a[9,27]   abs_m_9_27  1
    a[9,27]   true_G_epigraph  1
    a[9,27]   physical_G_upper  1
    a[9,27]   old_normalized_TC  1
    a[9,27]   old_normalized_TC2  1
    a[9,28]   abs_p_9_28  1
    a[9,28]   abs_m_9_28  1
    a[9,28]   true_G_epigraph  1
    a[9,28]   physical_G_upper  1
    a[9,28]   old_normalized_TC  1
    a[9,28]   old_normalized_TC2  1
    a[9,29]   abs_p_9_29  1
    a[9,29]   abs_m_9_29  1
    a[9,29]   true_G_epigraph  1
    a[9,29]   physical_G_upper  1
    a[9,29]   old_normalized_TC  1
    a[9,29]   old_normalized_TC2  1
    a[9,30]   abs_p_9_30  1
    a[9,30]   abs_m_9_30  1
    a[9,30]   true_G_epigraph  1
    a[9,30]   physical_G_upper  1
    a[9,30]   old_normalized_TC  1
    a[9,30]   old_normalized_TC2  1
    a[9,31]   abs_p_9_31  1
    a[9,31]   abs_m_9_31  1
    a[9,31]   true_G_epigraph  1
    a[9,31]   physical_G_upper  1
    a[9,31]   old_normalized_TC  1
    a[9,31]   old_normalized_TC2  1
    a[9,32]   abs_p_9_32  1
    a[9,32]   abs_m_9_32  1
    a[9,32]   true_G_epigraph  1
    a[9,32]   physical_G_upper  1
    a[9,32]   old_normalized_TC  1
    a[9,32]   old_normalized_TC2  1
    a[9,33]   abs_p_9_33  1
    a[9,33]   abs_m_9_33  1
    a[9,33]   true_G_epigraph  1
    a[9,33]   physical_G_upper  1
    a[9,33]   old_normalized_TC  1
    a[9,33]   old_normalized_TC2  1
    a[9,34]   abs_p_9_34  1
    a[9,34]   abs_m_9_34  1
    a[9,34]   true_G_epigraph  1
    a[9,34]   physical_G_upper  1
    a[9,34]   old_normalized_TC  1
    a[9,34]   old_normalized_TC2  1
    a[9,35]   abs_p_9_35  1
    a[9,35]   abs_m_9_35  1
    a[9,35]   true_G_epigraph  1
    a[9,35]   physical_G_upper  1
    a[9,35]   old_normalized_TC  1
    a[9,35]   old_normalized_TC2  1
    a[10,11]  abs_p_10_11  1
    a[10,11]  abs_m_10_11  1
    a[10,11]  true_G_epigraph  1
    a[10,11]  physical_G_upper  1
    a[10,11]  old_normalized_TC  1
    a[10,11]  old_normalized_TC2  1
    a[10,12]  abs_p_10_12  1
    a[10,12]  abs_m_10_12  1
    a[10,12]  true_G_epigraph  1
    a[10,12]  physical_G_upper  1
    a[10,12]  old_normalized_TC  1
    a[10,12]  old_normalized_TC2  1
    a[10,13]  abs_p_10_13  1
    a[10,13]  abs_m_10_13  1
    a[10,13]  true_G_epigraph  1
    a[10,13]  physical_G_upper  1
    a[10,13]  old_normalized_TC  1
    a[10,13]  old_normalized_TC2  1
    a[10,14]  abs_p_10_14  1
    a[10,14]  abs_m_10_14  1
    a[10,14]  true_G_epigraph  1
    a[10,14]  physical_G_upper  1
    a[10,14]  old_normalized_TC  1
    a[10,14]  old_normalized_TC2  1
    a[10,15]  abs_p_10_15  1
    a[10,15]  abs_m_10_15  1
    a[10,15]  true_G_epigraph  1
    a[10,15]  physical_G_upper  1
    a[10,15]  old_normalized_TC  1
    a[10,15]  old_normalized_TC2  1
    a[10,16]  abs_p_10_16  1
    a[10,16]  abs_m_10_16  1
    a[10,16]  true_G_epigraph  1
    a[10,16]  physical_G_upper  1
    a[10,16]  old_normalized_TC  1
    a[10,16]  old_normalized_TC2  1
    a[10,17]  abs_p_10_17  1
    a[10,17]  abs_m_10_17  1
    a[10,17]  true_G_epigraph  1
    a[10,17]  physical_G_upper  1
    a[10,17]  old_normalized_TC  1
    a[10,17]  old_normalized_TC2  1
    a[10,18]  abs_p_10_18  1
    a[10,18]  abs_m_10_18  1
    a[10,18]  true_G_epigraph  1
    a[10,18]  physical_G_upper  1
    a[10,18]  old_normalized_TC  1
    a[10,18]  old_normalized_TC2  1
    a[10,19]  abs_p_10_19  1
    a[10,19]  abs_m_10_19  1
    a[10,19]  true_G_epigraph  1
    a[10,19]  physical_G_upper  1
    a[10,19]  old_normalized_TC  1
    a[10,19]  old_normalized_TC2  1
    a[10,20]  abs_p_10_20  1
    a[10,20]  abs_m_10_20  1
    a[10,20]  true_G_epigraph  1
    a[10,20]  physical_G_upper  1
    a[10,20]  old_normalized_TC  1
    a[10,20]  old_normalized_TC2  1
    a[10,21]  abs_p_10_21  1
    a[10,21]  abs_m_10_21  1
    a[10,21]  true_G_epigraph  1
    a[10,21]  physical_G_upper  1
    a[10,21]  old_normalized_TC  1
    a[10,21]  old_normalized_TC2  1
    a[10,22]  abs_p_10_22  1
    a[10,22]  abs_m_10_22  1
    a[10,22]  true_G_epigraph  1
    a[10,22]  physical_G_upper  1
    a[10,22]  old_normalized_TC  1
    a[10,22]  old_normalized_TC2  1
    a[10,23]  abs_p_10_23  1
    a[10,23]  abs_m_10_23  1
    a[10,23]  true_G_epigraph  1
    a[10,23]  physical_G_upper  1
    a[10,23]  old_normalized_TC  1
    a[10,23]  old_normalized_TC2  1
    a[10,24]  abs_p_10_24  1
    a[10,24]  abs_m_10_24  1
    a[10,24]  true_G_epigraph  1
    a[10,24]  physical_G_upper  1
    a[10,24]  old_normalized_TC  1
    a[10,24]  old_normalized_TC2  1
    a[10,25]  abs_p_10_25  1
    a[10,25]  abs_m_10_25  1
    a[10,25]  true_G_epigraph  1
    a[10,25]  physical_G_upper  1
    a[10,25]  old_normalized_TC  1
    a[10,25]  old_normalized_TC2  1
    a[10,26]  abs_p_10_26  1
    a[10,26]  abs_m_10_26  1
    a[10,26]  true_G_epigraph  1
    a[10,26]  physical_G_upper  1
    a[10,26]  old_normalized_TC  1
    a[10,26]  old_normalized_TC2  1
    a[10,27]  abs_p_10_27  1
    a[10,27]  abs_m_10_27  1
    a[10,27]  true_G_epigraph  1
    a[10,27]  physical_G_upper  1
    a[10,27]  old_normalized_TC  1
    a[10,27]  old_normalized_TC2  1
    a[10,28]  abs_p_10_28  1
    a[10,28]  abs_m_10_28  1
    a[10,28]  true_G_epigraph  1
    a[10,28]  physical_G_upper  1
    a[10,28]  old_normalized_TC  1
    a[10,28]  old_normalized_TC2  1
    a[10,29]  abs_p_10_29  1
    a[10,29]  abs_m_10_29  1
    a[10,29]  true_G_epigraph  1
    a[10,29]  physical_G_upper  1
    a[10,29]  old_normalized_TC  1
    a[10,29]  old_normalized_TC2  1
    a[10,30]  abs_p_10_30  1
    a[10,30]  abs_m_10_30  1
    a[10,30]  true_G_epigraph  1
    a[10,30]  physical_G_upper  1
    a[10,30]  old_normalized_TC  1
    a[10,30]  old_normalized_TC2  1
    a[10,31]  abs_p_10_31  1
    a[10,31]  abs_m_10_31  1
    a[10,31]  true_G_epigraph  1
    a[10,31]  physical_G_upper  1
    a[10,31]  old_normalized_TC  1
    a[10,31]  old_normalized_TC2  1
    a[10,32]  abs_p_10_32  1
    a[10,32]  abs_m_10_32  1
    a[10,32]  true_G_epigraph  1
    a[10,32]  physical_G_upper  1
    a[10,32]  old_normalized_TC  1
    a[10,32]  old_normalized_TC2  1
    a[10,33]  abs_p_10_33  1
    a[10,33]  abs_m_10_33  1
    a[10,33]  true_G_epigraph  1
    a[10,33]  physical_G_upper  1
    a[10,33]  old_normalized_TC  1
    a[10,33]  old_normalized_TC2  1
    a[10,34]  abs_p_10_34  1
    a[10,34]  abs_m_10_34  1
    a[10,34]  true_G_epigraph  1
    a[10,34]  physical_G_upper  1
    a[10,34]  old_normalized_TC  1
    a[10,34]  old_normalized_TC2  1
    a[10,35]  abs_p_10_35  1
    a[10,35]  abs_m_10_35  1
    a[10,35]  true_G_epigraph  1
    a[10,35]  physical_G_upper  1
    a[10,35]  old_normalized_TC  1
    a[10,35]  old_normalized_TC2  1
    a[11,12]  abs_p_11_12  1
    a[11,12]  abs_m_11_12  1
    a[11,12]  true_G_epigraph  1
    a[11,12]  physical_G_upper  1
    a[11,12]  old_normalized_TC  1
    a[11,12]  old_normalized_TC2  1
    a[11,13]  abs_p_11_13  1
    a[11,13]  abs_m_11_13  1
    a[11,13]  true_G_epigraph  1
    a[11,13]  physical_G_upper  1
    a[11,13]  old_normalized_TC  1
    a[11,13]  old_normalized_TC2  1
    a[11,14]  abs_p_11_14  1
    a[11,14]  abs_m_11_14  1
    a[11,14]  true_G_epigraph  1
    a[11,14]  physical_G_upper  1
    a[11,14]  old_normalized_TC  1
    a[11,14]  old_normalized_TC2  1
    a[11,15]  abs_p_11_15  1
    a[11,15]  abs_m_11_15  1
    a[11,15]  true_G_epigraph  1
    a[11,15]  physical_G_upper  1
    a[11,15]  old_normalized_TC  1
    a[11,15]  old_normalized_TC2  1
    a[11,16]  abs_p_11_16  1
    a[11,16]  abs_m_11_16  1
    a[11,16]  true_G_epigraph  1
    a[11,16]  physical_G_upper  1
    a[11,16]  old_normalized_TC  1
    a[11,16]  old_normalized_TC2  1
    a[11,17]  abs_p_11_17  1
    a[11,17]  abs_m_11_17  1
    a[11,17]  true_G_epigraph  1
    a[11,17]  physical_G_upper  1
    a[11,17]  old_normalized_TC  1
    a[11,17]  old_normalized_TC2  1
    a[11,18]  abs_p_11_18  1
    a[11,18]  abs_m_11_18  1
    a[11,18]  true_G_epigraph  1
    a[11,18]  physical_G_upper  1
    a[11,18]  old_normalized_TC  1
    a[11,18]  old_normalized_TC2  1
    a[11,19]  abs_p_11_19  1
    a[11,19]  abs_m_11_19  1
    a[11,19]  true_G_epigraph  1
    a[11,19]  physical_G_upper  1
    a[11,19]  old_normalized_TC  1
    a[11,19]  old_normalized_TC2  1
    a[11,20]  abs_p_11_20  1
    a[11,20]  abs_m_11_20  1
    a[11,20]  true_G_epigraph  1
    a[11,20]  physical_G_upper  1
    a[11,20]  old_normalized_TC  1
    a[11,20]  old_normalized_TC2  1
    a[11,21]  abs_p_11_21  1
    a[11,21]  abs_m_11_21  1
    a[11,21]  true_G_epigraph  1
    a[11,21]  physical_G_upper  1
    a[11,21]  old_normalized_TC  1
    a[11,21]  old_normalized_TC2  1
    a[11,22]  abs_p_11_22  1
    a[11,22]  abs_m_11_22  1
    a[11,22]  true_G_epigraph  1
    a[11,22]  physical_G_upper  1
    a[11,22]  old_normalized_TC  1
    a[11,22]  old_normalized_TC2  1
    a[11,23]  abs_p_11_23  1
    a[11,23]  abs_m_11_23  1
    a[11,23]  true_G_epigraph  1
    a[11,23]  physical_G_upper  1
    a[11,23]  old_normalized_TC  1
    a[11,23]  old_normalized_TC2  1
    a[11,24]  abs_p_11_24  1
    a[11,24]  abs_m_11_24  1
    a[11,24]  true_G_epigraph  1
    a[11,24]  physical_G_upper  1
    a[11,24]  old_normalized_TC  1
    a[11,24]  old_normalized_TC2  1
    a[11,25]  abs_p_11_25  1
    a[11,25]  abs_m_11_25  1
    a[11,25]  true_G_epigraph  1
    a[11,25]  physical_G_upper  1
    a[11,25]  old_normalized_TC  1
    a[11,25]  old_normalized_TC2  1
    a[11,26]  abs_p_11_26  1
    a[11,26]  abs_m_11_26  1
    a[11,26]  true_G_epigraph  1
    a[11,26]  physical_G_upper  1
    a[11,26]  old_normalized_TC  1
    a[11,26]  old_normalized_TC2  1
    a[11,27]  abs_p_11_27  1
    a[11,27]  abs_m_11_27  1
    a[11,27]  true_G_epigraph  1
    a[11,27]  physical_G_upper  1
    a[11,27]  old_normalized_TC  1
    a[11,27]  old_normalized_TC2  1
    a[11,28]  abs_p_11_28  1
    a[11,28]  abs_m_11_28  1
    a[11,28]  true_G_epigraph  1
    a[11,28]  physical_G_upper  1
    a[11,28]  old_normalized_TC  1
    a[11,28]  old_normalized_TC2  1
    a[11,29]  abs_p_11_29  1
    a[11,29]  abs_m_11_29  1
    a[11,29]  true_G_epigraph  1
    a[11,29]  physical_G_upper  1
    a[11,29]  old_normalized_TC  1
    a[11,29]  old_normalized_TC2  1
    a[11,30]  abs_p_11_30  1
    a[11,30]  abs_m_11_30  1
    a[11,30]  true_G_epigraph  1
    a[11,30]  physical_G_upper  1
    a[11,30]  old_normalized_TC  1
    a[11,30]  old_normalized_TC2  1
    a[11,31]  abs_p_11_31  1
    a[11,31]  abs_m_11_31  1
    a[11,31]  true_G_epigraph  1
    a[11,31]  physical_G_upper  1
    a[11,31]  old_normalized_TC  1
    a[11,31]  old_normalized_TC2  1
    a[11,32]  abs_p_11_32  1
    a[11,32]  abs_m_11_32  1
    a[11,32]  true_G_epigraph  1
    a[11,32]  physical_G_upper  1
    a[11,32]  old_normalized_TC  1
    a[11,32]  old_normalized_TC2  1
    a[11,33]  abs_p_11_33  1
    a[11,33]  abs_m_11_33  1
    a[11,33]  true_G_epigraph  1
    a[11,33]  physical_G_upper  1
    a[11,33]  old_normalized_TC  1
    a[11,33]  old_normalized_TC2  1
    a[11,34]  abs_p_11_34  1
    a[11,34]  abs_m_11_34  1
    a[11,34]  true_G_epigraph  1
    a[11,34]  physical_G_upper  1
    a[11,34]  old_normalized_TC  1
    a[11,34]  old_normalized_TC2  1
    a[11,35]  abs_p_11_35  1
    a[11,35]  abs_m_11_35  1
    a[11,35]  true_G_epigraph  1
    a[11,35]  physical_G_upper  1
    a[11,35]  old_normalized_TC  1
    a[11,35]  old_normalized_TC2  1
    a[12,13]  abs_p_12_13  1
    a[12,13]  abs_m_12_13  1
    a[12,13]  true_G_epigraph  1
    a[12,13]  physical_G_upper  1
    a[12,13]  old_normalized_TC  1
    a[12,13]  old_normalized_TC2  1
    a[12,14]  abs_p_12_14  1
    a[12,14]  abs_m_12_14  1
    a[12,14]  true_G_epigraph  1
    a[12,14]  physical_G_upper  1
    a[12,14]  old_normalized_TC  1
    a[12,14]  old_normalized_TC2  1
    a[12,15]  abs_p_12_15  1
    a[12,15]  abs_m_12_15  1
    a[12,15]  true_G_epigraph  1
    a[12,15]  physical_G_upper  1
    a[12,15]  old_normalized_TC  1
    a[12,15]  old_normalized_TC2  1
    a[12,16]  abs_p_12_16  1
    a[12,16]  abs_m_12_16  1
    a[12,16]  true_G_epigraph  1
    a[12,16]  physical_G_upper  1
    a[12,16]  old_normalized_TC  1
    a[12,16]  old_normalized_TC2  1
    a[12,17]  abs_p_12_17  1
    a[12,17]  abs_m_12_17  1
    a[12,17]  true_G_epigraph  1
    a[12,17]  physical_G_upper  1
    a[12,17]  old_normalized_TC  1
    a[12,17]  old_normalized_TC2  1
    a[12,18]  abs_p_12_18  1
    a[12,18]  abs_m_12_18  1
    a[12,18]  true_G_epigraph  1
    a[12,18]  physical_G_upper  1
    a[12,18]  old_normalized_TC  1
    a[12,18]  old_normalized_TC2  1
    a[12,19]  abs_p_12_19  1
    a[12,19]  abs_m_12_19  1
    a[12,19]  true_G_epigraph  1
    a[12,19]  physical_G_upper  1
    a[12,19]  old_normalized_TC  1
    a[12,19]  old_normalized_TC2  1
    a[12,20]  abs_p_12_20  1
    a[12,20]  abs_m_12_20  1
    a[12,20]  true_G_epigraph  1
    a[12,20]  physical_G_upper  1
    a[12,20]  old_normalized_TC  1
    a[12,20]  old_normalized_TC2  1
    a[12,21]  abs_p_12_21  1
    a[12,21]  abs_m_12_21  1
    a[12,21]  true_G_epigraph  1
    a[12,21]  physical_G_upper  1
    a[12,21]  old_normalized_TC  1
    a[12,21]  old_normalized_TC2  1
    a[12,22]  abs_p_12_22  1
    a[12,22]  abs_m_12_22  1
    a[12,22]  true_G_epigraph  1
    a[12,22]  physical_G_upper  1
    a[12,22]  old_normalized_TC  1
    a[12,22]  old_normalized_TC2  1
    a[12,23]  abs_p_12_23  1
    a[12,23]  abs_m_12_23  1
    a[12,23]  true_G_epigraph  1
    a[12,23]  physical_G_upper  1
    a[12,23]  old_normalized_TC  1
    a[12,23]  old_normalized_TC2  1
    a[12,24]  abs_p_12_24  1
    a[12,24]  abs_m_12_24  1
    a[12,24]  true_G_epigraph  1
    a[12,24]  physical_G_upper  1
    a[12,24]  old_normalized_TC  1
    a[12,24]  old_normalized_TC2  1
    a[12,25]  abs_p_12_25  1
    a[12,25]  abs_m_12_25  1
    a[12,25]  true_G_epigraph  1
    a[12,25]  physical_G_upper  1
    a[12,25]  old_normalized_TC  1
    a[12,25]  old_normalized_TC2  1
    a[12,26]  abs_p_12_26  1
    a[12,26]  abs_m_12_26  1
    a[12,26]  true_G_epigraph  1
    a[12,26]  physical_G_upper  1
    a[12,26]  old_normalized_TC  1
    a[12,26]  old_normalized_TC2  1
    a[12,27]  abs_p_12_27  1
    a[12,27]  abs_m_12_27  1
    a[12,27]  true_G_epigraph  1
    a[12,27]  physical_G_upper  1
    a[12,27]  old_normalized_TC  1
    a[12,27]  old_normalized_TC2  1
    a[12,28]  abs_p_12_28  1
    a[12,28]  abs_m_12_28  1
    a[12,28]  true_G_epigraph  1
    a[12,28]  physical_G_upper  1
    a[12,28]  old_normalized_TC  1
    a[12,28]  old_normalized_TC2  1
    a[12,29]  abs_p_12_29  1
    a[12,29]  abs_m_12_29  1
    a[12,29]  true_G_epigraph  1
    a[12,29]  physical_G_upper  1
    a[12,29]  old_normalized_TC  1
    a[12,29]  old_normalized_TC2  1
    a[12,30]  abs_p_12_30  1
    a[12,30]  abs_m_12_30  1
    a[12,30]  true_G_epigraph  1
    a[12,30]  physical_G_upper  1
    a[12,30]  old_normalized_TC  1
    a[12,30]  old_normalized_TC2  1
    a[12,31]  abs_p_12_31  1
    a[12,31]  abs_m_12_31  1
    a[12,31]  true_G_epigraph  1
    a[12,31]  physical_G_upper  1
    a[12,31]  old_normalized_TC  1
    a[12,31]  old_normalized_TC2  1
    a[12,32]  abs_p_12_32  1
    a[12,32]  abs_m_12_32  1
    a[12,32]  true_G_epigraph  1
    a[12,32]  physical_G_upper  1
    a[12,32]  old_normalized_TC  1
    a[12,32]  old_normalized_TC2  1
    a[12,33]  abs_p_12_33  1
    a[12,33]  abs_m_12_33  1
    a[12,33]  true_G_epigraph  1
    a[12,33]  physical_G_upper  1
    a[12,33]  old_normalized_TC  1
    a[12,33]  old_normalized_TC2  1
    a[12,34]  abs_p_12_34  1
    a[12,34]  abs_m_12_34  1
    a[12,34]  true_G_epigraph  1
    a[12,34]  physical_G_upper  1
    a[12,34]  old_normalized_TC  1
    a[12,34]  old_normalized_TC2  1
    a[12,35]  abs_p_12_35  1
    a[12,35]  abs_m_12_35  1
    a[12,35]  true_G_epigraph  1
    a[12,35]  physical_G_upper  1
    a[12,35]  old_normalized_TC  1
    a[12,35]  old_normalized_TC2  1
    a[13,14]  abs_p_13_14  1
    a[13,14]  abs_m_13_14  1
    a[13,14]  true_G_epigraph  1
    a[13,14]  physical_G_upper  1
    a[13,14]  old_normalized_TC  1
    a[13,14]  old_normalized_TC2  1
    a[13,15]  abs_p_13_15  1
    a[13,15]  abs_m_13_15  1
    a[13,15]  true_G_epigraph  1
    a[13,15]  physical_G_upper  1
    a[13,15]  old_normalized_TC  1
    a[13,15]  old_normalized_TC2  1
    a[13,16]  abs_p_13_16  1
    a[13,16]  abs_m_13_16  1
    a[13,16]  true_G_epigraph  1
    a[13,16]  physical_G_upper  1
    a[13,16]  old_normalized_TC  1
    a[13,16]  old_normalized_TC2  1
    a[13,17]  abs_p_13_17  1
    a[13,17]  abs_m_13_17  1
    a[13,17]  true_G_epigraph  1
    a[13,17]  physical_G_upper  1
    a[13,17]  old_normalized_TC  1
    a[13,17]  old_normalized_TC2  1
    a[13,18]  abs_p_13_18  1
    a[13,18]  abs_m_13_18  1
    a[13,18]  true_G_epigraph  1
    a[13,18]  physical_G_upper  1
    a[13,18]  old_normalized_TC  1
    a[13,18]  old_normalized_TC2  1
    a[13,19]  abs_p_13_19  1
    a[13,19]  abs_m_13_19  1
    a[13,19]  true_G_epigraph  1
    a[13,19]  physical_G_upper  1
    a[13,19]  old_normalized_TC  1
    a[13,19]  old_normalized_TC2  1
    a[13,20]  abs_p_13_20  1
    a[13,20]  abs_m_13_20  1
    a[13,20]  true_G_epigraph  1
    a[13,20]  physical_G_upper  1
    a[13,20]  old_normalized_TC  1
    a[13,20]  old_normalized_TC2  1
    a[13,21]  abs_p_13_21  1
    a[13,21]  abs_m_13_21  1
    a[13,21]  true_G_epigraph  1
    a[13,21]  physical_G_upper  1
    a[13,21]  old_normalized_TC  1
    a[13,21]  old_normalized_TC2  1
    a[13,22]  abs_p_13_22  1
    a[13,22]  abs_m_13_22  1
    a[13,22]  true_G_epigraph  1
    a[13,22]  physical_G_upper  1
    a[13,22]  old_normalized_TC  1
    a[13,22]  old_normalized_TC2  1
    a[13,23]  abs_p_13_23  1
    a[13,23]  abs_m_13_23  1
    a[13,23]  true_G_epigraph  1
    a[13,23]  physical_G_upper  1
    a[13,23]  old_normalized_TC  1
    a[13,23]  old_normalized_TC2  1
    a[13,24]  abs_p_13_24  1
    a[13,24]  abs_m_13_24  1
    a[13,24]  true_G_epigraph  1
    a[13,24]  physical_G_upper  1
    a[13,24]  old_normalized_TC  1
    a[13,24]  old_normalized_TC2  1
    a[13,25]  abs_p_13_25  1
    a[13,25]  abs_m_13_25  1
    a[13,25]  true_G_epigraph  1
    a[13,25]  physical_G_upper  1
    a[13,25]  old_normalized_TC  1
    a[13,25]  old_normalized_TC2  1
    a[13,26]  abs_p_13_26  1
    a[13,26]  abs_m_13_26  1
    a[13,26]  true_G_epigraph  1
    a[13,26]  physical_G_upper  1
    a[13,26]  old_normalized_TC  1
    a[13,26]  old_normalized_TC2  1
    a[13,27]  abs_p_13_27  1
    a[13,27]  abs_m_13_27  1
    a[13,27]  true_G_epigraph  1
    a[13,27]  physical_G_upper  1
    a[13,27]  old_normalized_TC  1
    a[13,27]  old_normalized_TC2  1
    a[13,28]  abs_p_13_28  1
    a[13,28]  abs_m_13_28  1
    a[13,28]  true_G_epigraph  1
    a[13,28]  physical_G_upper  1
    a[13,28]  old_normalized_TC  1
    a[13,28]  old_normalized_TC2  1
    a[13,29]  abs_p_13_29  1
    a[13,29]  abs_m_13_29  1
    a[13,29]  true_G_epigraph  1
    a[13,29]  physical_G_upper  1
    a[13,29]  old_normalized_TC  1
    a[13,29]  old_normalized_TC2  1
    a[13,30]  abs_p_13_30  1
    a[13,30]  abs_m_13_30  1
    a[13,30]  true_G_epigraph  1
    a[13,30]  physical_G_upper  1
    a[13,30]  old_normalized_TC  1
    a[13,30]  old_normalized_TC2  1
    a[13,31]  abs_p_13_31  1
    a[13,31]  abs_m_13_31  1
    a[13,31]  true_G_epigraph  1
    a[13,31]  physical_G_upper  1
    a[13,31]  old_normalized_TC  1
    a[13,31]  old_normalized_TC2  1
    a[13,32]  abs_p_13_32  1
    a[13,32]  abs_m_13_32  1
    a[13,32]  true_G_epigraph  1
    a[13,32]  physical_G_upper  1
    a[13,32]  old_normalized_TC  1
    a[13,32]  old_normalized_TC2  1
    a[13,33]  abs_p_13_33  1
    a[13,33]  abs_m_13_33  1
    a[13,33]  true_G_epigraph  1
    a[13,33]  physical_G_upper  1
    a[13,33]  old_normalized_TC  1
    a[13,33]  old_normalized_TC2  1
    a[13,34]  abs_p_13_34  1
    a[13,34]  abs_m_13_34  1
    a[13,34]  true_G_epigraph  1
    a[13,34]  physical_G_upper  1
    a[13,34]  old_normalized_TC  1
    a[13,34]  old_normalized_TC2  1
    a[13,35]  abs_p_13_35  1
    a[13,35]  abs_m_13_35  1
    a[13,35]  true_G_epigraph  1
    a[13,35]  physical_G_upper  1
    a[13,35]  old_normalized_TC  1
    a[13,35]  old_normalized_TC2  1
    a[14,15]  abs_p_14_15  1
    a[14,15]  abs_m_14_15  1
    a[14,15]  true_G_epigraph  1
    a[14,15]  physical_G_upper  1
    a[14,15]  old_normalized_TC  1
    a[14,15]  old_normalized_TC2  1
    a[14,16]  abs_p_14_16  1
    a[14,16]  abs_m_14_16  1
    a[14,16]  true_G_epigraph  1
    a[14,16]  physical_G_upper  1
    a[14,16]  old_normalized_TC  1
    a[14,16]  old_normalized_TC2  1
    a[14,17]  abs_p_14_17  1
    a[14,17]  abs_m_14_17  1
    a[14,17]  true_G_epigraph  1
    a[14,17]  physical_G_upper  1
    a[14,17]  old_normalized_TC  1
    a[14,17]  old_normalized_TC2  1
    a[14,18]  abs_p_14_18  1
    a[14,18]  abs_m_14_18  1
    a[14,18]  true_G_epigraph  1
    a[14,18]  physical_G_upper  1
    a[14,18]  old_normalized_TC  1
    a[14,18]  old_normalized_TC2  1
    a[14,19]  abs_p_14_19  1
    a[14,19]  abs_m_14_19  1
    a[14,19]  true_G_epigraph  1
    a[14,19]  physical_G_upper  1
    a[14,19]  old_normalized_TC  1
    a[14,19]  old_normalized_TC2  1
    a[14,20]  abs_p_14_20  1
    a[14,20]  abs_m_14_20  1
    a[14,20]  true_G_epigraph  1
    a[14,20]  physical_G_upper  1
    a[14,20]  old_normalized_TC  1
    a[14,20]  old_normalized_TC2  1
    a[14,21]  abs_p_14_21  1
    a[14,21]  abs_m_14_21  1
    a[14,21]  true_G_epigraph  1
    a[14,21]  physical_G_upper  1
    a[14,21]  old_normalized_TC  1
    a[14,21]  old_normalized_TC2  1
    a[14,22]  abs_p_14_22  1
    a[14,22]  abs_m_14_22  1
    a[14,22]  true_G_epigraph  1
    a[14,22]  physical_G_upper  1
    a[14,22]  old_normalized_TC  1
    a[14,22]  old_normalized_TC2  1
    a[14,23]  abs_p_14_23  1
    a[14,23]  abs_m_14_23  1
    a[14,23]  true_G_epigraph  1
    a[14,23]  physical_G_upper  1
    a[14,23]  old_normalized_TC  1
    a[14,23]  old_normalized_TC2  1
    a[14,24]  abs_p_14_24  1
    a[14,24]  abs_m_14_24  1
    a[14,24]  true_G_epigraph  1
    a[14,24]  physical_G_upper  1
    a[14,24]  old_normalized_TC  1
    a[14,24]  old_normalized_TC2  1
    a[14,25]  abs_p_14_25  1
    a[14,25]  abs_m_14_25  1
    a[14,25]  true_G_epigraph  1
    a[14,25]  physical_G_upper  1
    a[14,25]  old_normalized_TC  1
    a[14,25]  old_normalized_TC2  1
    a[14,26]  abs_p_14_26  1
    a[14,26]  abs_m_14_26  1
    a[14,26]  true_G_epigraph  1
    a[14,26]  physical_G_upper  1
    a[14,26]  old_normalized_TC  1
    a[14,26]  old_normalized_TC2  1
    a[14,27]  abs_p_14_27  1
    a[14,27]  abs_m_14_27  1
    a[14,27]  true_G_epigraph  1
    a[14,27]  physical_G_upper  1
    a[14,27]  old_normalized_TC  1
    a[14,27]  old_normalized_TC2  1
    a[14,28]  abs_p_14_28  1
    a[14,28]  abs_m_14_28  1
    a[14,28]  true_G_epigraph  1
    a[14,28]  physical_G_upper  1
    a[14,28]  old_normalized_TC  1
    a[14,28]  old_normalized_TC2  1
    a[14,29]  abs_p_14_29  1
    a[14,29]  abs_m_14_29  1
    a[14,29]  true_G_epigraph  1
    a[14,29]  physical_G_upper  1
    a[14,29]  old_normalized_TC  1
    a[14,29]  old_normalized_TC2  1
    a[14,30]  abs_p_14_30  1
    a[14,30]  abs_m_14_30  1
    a[14,30]  true_G_epigraph  1
    a[14,30]  physical_G_upper  1
    a[14,30]  old_normalized_TC  1
    a[14,30]  old_normalized_TC2  1
    a[14,31]  abs_p_14_31  1
    a[14,31]  abs_m_14_31  1
    a[14,31]  true_G_epigraph  1
    a[14,31]  physical_G_upper  1
    a[14,31]  old_normalized_TC  1
    a[14,31]  old_normalized_TC2  1
    a[14,32]  abs_p_14_32  1
    a[14,32]  abs_m_14_32  1
    a[14,32]  true_G_epigraph  1
    a[14,32]  physical_G_upper  1
    a[14,32]  old_normalized_TC  1
    a[14,32]  old_normalized_TC2  1
    a[14,33]  abs_p_14_33  1
    a[14,33]  abs_m_14_33  1
    a[14,33]  true_G_epigraph  1
    a[14,33]  physical_G_upper  1
    a[14,33]  old_normalized_TC  1
    a[14,33]  old_normalized_TC2  1
    a[14,34]  abs_p_14_34  1
    a[14,34]  abs_m_14_34  1
    a[14,34]  true_G_epigraph  1
    a[14,34]  physical_G_upper  1
    a[14,34]  old_normalized_TC  1
    a[14,34]  old_normalized_TC2  1
    a[14,35]  abs_p_14_35  1
    a[14,35]  abs_m_14_35  1
    a[14,35]  true_G_epigraph  1
    a[14,35]  physical_G_upper  1
    a[14,35]  old_normalized_TC  1
    a[14,35]  old_normalized_TC2  1
    a[15,16]  abs_p_15_16  1
    a[15,16]  abs_m_15_16  1
    a[15,16]  true_G_epigraph  1
    a[15,16]  physical_G_upper  1
    a[15,16]  old_normalized_TC  1
    a[15,16]  old_normalized_TC2  1
    a[15,17]  abs_p_15_17  1
    a[15,17]  abs_m_15_17  1
    a[15,17]  true_G_epigraph  1
    a[15,17]  physical_G_upper  1
    a[15,17]  old_normalized_TC  1
    a[15,17]  old_normalized_TC2  1
    a[15,18]  abs_p_15_18  1
    a[15,18]  abs_m_15_18  1
    a[15,18]  true_G_epigraph  1
    a[15,18]  physical_G_upper  1
    a[15,18]  old_normalized_TC  1
    a[15,18]  old_normalized_TC2  1
    a[15,19]  abs_p_15_19  1
    a[15,19]  abs_m_15_19  1
    a[15,19]  true_G_epigraph  1
    a[15,19]  physical_G_upper  1
    a[15,19]  old_normalized_TC  1
    a[15,19]  old_normalized_TC2  1
    a[15,20]  abs_p_15_20  1
    a[15,20]  abs_m_15_20  1
    a[15,20]  true_G_epigraph  1
    a[15,20]  physical_G_upper  1
    a[15,20]  old_normalized_TC  1
    a[15,20]  old_normalized_TC2  1
    a[15,21]  abs_p_15_21  1
    a[15,21]  abs_m_15_21  1
    a[15,21]  true_G_epigraph  1
    a[15,21]  physical_G_upper  1
    a[15,21]  old_normalized_TC  1
    a[15,21]  old_normalized_TC2  1
    a[15,22]  abs_p_15_22  1
    a[15,22]  abs_m_15_22  1
    a[15,22]  true_G_epigraph  1
    a[15,22]  physical_G_upper  1
    a[15,22]  old_normalized_TC  1
    a[15,22]  old_normalized_TC2  1
    a[15,23]  abs_p_15_23  1
    a[15,23]  abs_m_15_23  1
    a[15,23]  true_G_epigraph  1
    a[15,23]  physical_G_upper  1
    a[15,23]  old_normalized_TC  1
    a[15,23]  old_normalized_TC2  1
    a[15,24]  abs_p_15_24  1
    a[15,24]  abs_m_15_24  1
    a[15,24]  true_G_epigraph  1
    a[15,24]  physical_G_upper  1
    a[15,24]  old_normalized_TC  1
    a[15,24]  old_normalized_TC2  1
    a[15,25]  abs_p_15_25  1
    a[15,25]  abs_m_15_25  1
    a[15,25]  true_G_epigraph  1
    a[15,25]  physical_G_upper  1
    a[15,25]  old_normalized_TC  1
    a[15,25]  old_normalized_TC2  1
    a[15,26]  abs_p_15_26  1
    a[15,26]  abs_m_15_26  1
    a[15,26]  true_G_epigraph  1
    a[15,26]  physical_G_upper  1
    a[15,26]  old_normalized_TC  1
    a[15,26]  old_normalized_TC2  1
    a[15,27]  abs_p_15_27  1
    a[15,27]  abs_m_15_27  1
    a[15,27]  true_G_epigraph  1
    a[15,27]  physical_G_upper  1
    a[15,27]  old_normalized_TC  1
    a[15,27]  old_normalized_TC2  1
    a[15,28]  abs_p_15_28  1
    a[15,28]  abs_m_15_28  1
    a[15,28]  true_G_epigraph  1
    a[15,28]  physical_G_upper  1
    a[15,28]  old_normalized_TC  1
    a[15,28]  old_normalized_TC2  1
    a[15,29]  abs_p_15_29  1
    a[15,29]  abs_m_15_29  1
    a[15,29]  true_G_epigraph  1
    a[15,29]  physical_G_upper  1
    a[15,29]  old_normalized_TC  1
    a[15,29]  old_normalized_TC2  1
    a[15,30]  abs_p_15_30  1
    a[15,30]  abs_m_15_30  1
    a[15,30]  true_G_epigraph  1
    a[15,30]  physical_G_upper  1
    a[15,30]  old_normalized_TC  1
    a[15,30]  old_normalized_TC2  1
    a[15,31]  abs_p_15_31  1
    a[15,31]  abs_m_15_31  1
    a[15,31]  true_G_epigraph  1
    a[15,31]  physical_G_upper  1
    a[15,31]  old_normalized_TC  1
    a[15,31]  old_normalized_TC2  1
    a[15,32]  abs_p_15_32  1
    a[15,32]  abs_m_15_32  1
    a[15,32]  true_G_epigraph  1
    a[15,32]  physical_G_upper  1
    a[15,32]  old_normalized_TC  1
    a[15,32]  old_normalized_TC2  1
    a[15,33]  abs_p_15_33  1
    a[15,33]  abs_m_15_33  1
    a[15,33]  true_G_epigraph  1
    a[15,33]  physical_G_upper  1
    a[15,33]  old_normalized_TC  1
    a[15,33]  old_normalized_TC2  1
    a[15,34]  abs_p_15_34  1
    a[15,34]  abs_m_15_34  1
    a[15,34]  true_G_epigraph  1
    a[15,34]  physical_G_upper  1
    a[15,34]  old_normalized_TC  1
    a[15,34]  old_normalized_TC2  1
    a[15,35]  abs_p_15_35  1
    a[15,35]  abs_m_15_35  1
    a[15,35]  true_G_epigraph  1
    a[15,35]  physical_G_upper  1
    a[15,35]  old_normalized_TC  1
    a[15,35]  old_normalized_TC2  1
    a[16,17]  abs_p_16_17  1
    a[16,17]  abs_m_16_17  1
    a[16,17]  true_G_epigraph  1
    a[16,17]  physical_G_upper  1
    a[16,17]  old_normalized_TC  1
    a[16,17]  old_normalized_TC2  1
    a[16,18]  abs_p_16_18  1
    a[16,18]  abs_m_16_18  1
    a[16,18]  true_G_epigraph  1
    a[16,18]  physical_G_upper  1
    a[16,18]  old_normalized_TC  1
    a[16,18]  old_normalized_TC2  1
    a[16,19]  abs_p_16_19  1
    a[16,19]  abs_m_16_19  1
    a[16,19]  true_G_epigraph  1
    a[16,19]  physical_G_upper  1
    a[16,19]  old_normalized_TC  1
    a[16,19]  old_normalized_TC2  1
    a[16,20]  abs_p_16_20  1
    a[16,20]  abs_m_16_20  1
    a[16,20]  true_G_epigraph  1
    a[16,20]  physical_G_upper  1
    a[16,20]  old_normalized_TC  1
    a[16,20]  old_normalized_TC2  1
    a[16,21]  abs_p_16_21  1
    a[16,21]  abs_m_16_21  1
    a[16,21]  true_G_epigraph  1
    a[16,21]  physical_G_upper  1
    a[16,21]  old_normalized_TC  1
    a[16,21]  old_normalized_TC2  1
    a[16,22]  abs_p_16_22  1
    a[16,22]  abs_m_16_22  1
    a[16,22]  true_G_epigraph  1
    a[16,22]  physical_G_upper  1
    a[16,22]  old_normalized_TC  1
    a[16,22]  old_normalized_TC2  1
    a[16,23]  abs_p_16_23  1
    a[16,23]  abs_m_16_23  1
    a[16,23]  true_G_epigraph  1
    a[16,23]  physical_G_upper  1
    a[16,23]  old_normalized_TC  1
    a[16,23]  old_normalized_TC2  1
    a[16,24]  abs_p_16_24  1
    a[16,24]  abs_m_16_24  1
    a[16,24]  true_G_epigraph  1
    a[16,24]  physical_G_upper  1
    a[16,24]  old_normalized_TC  1
    a[16,24]  old_normalized_TC2  1
    a[16,25]  abs_p_16_25  1
    a[16,25]  abs_m_16_25  1
    a[16,25]  true_G_epigraph  1
    a[16,25]  physical_G_upper  1
    a[16,25]  old_normalized_TC  1
    a[16,25]  old_normalized_TC2  1
    a[16,26]  abs_p_16_26  1
    a[16,26]  abs_m_16_26  1
    a[16,26]  true_G_epigraph  1
    a[16,26]  physical_G_upper  1
    a[16,26]  old_normalized_TC  1
    a[16,26]  old_normalized_TC2  1
    a[16,27]  abs_p_16_27  1
    a[16,27]  abs_m_16_27  1
    a[16,27]  true_G_epigraph  1
    a[16,27]  physical_G_upper  1
    a[16,27]  old_normalized_TC  1
    a[16,27]  old_normalized_TC2  1
    a[16,28]  abs_p_16_28  1
    a[16,28]  abs_m_16_28  1
    a[16,28]  true_G_epigraph  1
    a[16,28]  physical_G_upper  1
    a[16,28]  old_normalized_TC  1
    a[16,28]  old_normalized_TC2  1
    a[16,29]  abs_p_16_29  1
    a[16,29]  abs_m_16_29  1
    a[16,29]  true_G_epigraph  1
    a[16,29]  physical_G_upper  1
    a[16,29]  old_normalized_TC  1
    a[16,29]  old_normalized_TC2  1
    a[16,30]  abs_p_16_30  1
    a[16,30]  abs_m_16_30  1
    a[16,30]  true_G_epigraph  1
    a[16,30]  physical_G_upper  1
    a[16,30]  old_normalized_TC  1
    a[16,30]  old_normalized_TC2  1
    a[16,31]  abs_p_16_31  1
    a[16,31]  abs_m_16_31  1
    a[16,31]  true_G_epigraph  1
    a[16,31]  physical_G_upper  1
    a[16,31]  old_normalized_TC  1
    a[16,31]  old_normalized_TC2  1
    a[16,32]  abs_p_16_32  1
    a[16,32]  abs_m_16_32  1
    a[16,32]  true_G_epigraph  1
    a[16,32]  physical_G_upper  1
    a[16,32]  old_normalized_TC  1
    a[16,32]  old_normalized_TC2  1
    a[16,33]  abs_p_16_33  1
    a[16,33]  abs_m_16_33  1
    a[16,33]  true_G_epigraph  1
    a[16,33]  physical_G_upper  1
    a[16,33]  old_normalized_TC  1
    a[16,33]  old_normalized_TC2  1
    a[16,34]  abs_p_16_34  1
    a[16,34]  abs_m_16_34  1
    a[16,34]  true_G_epigraph  1
    a[16,34]  physical_G_upper  1
    a[16,34]  old_normalized_TC  1
    a[16,34]  old_normalized_TC2  1
    a[16,35]  abs_p_16_35  1
    a[16,35]  abs_m_16_35  1
    a[16,35]  true_G_epigraph  1
    a[16,35]  physical_G_upper  1
    a[16,35]  old_normalized_TC  1
    a[16,35]  old_normalized_TC2  1
    a[17,18]  abs_p_17_18  1
    a[17,18]  abs_m_17_18  1
    a[17,18]  true_G_epigraph  1
    a[17,18]  physical_G_upper  1
    a[17,18]  old_normalized_TC  1
    a[17,18]  old_normalized_TC2  1
    a[17,19]  abs_p_17_19  1
    a[17,19]  abs_m_17_19  1
    a[17,19]  true_G_epigraph  1
    a[17,19]  physical_G_upper  1
    a[17,19]  old_normalized_TC  1
    a[17,19]  old_normalized_TC2  1
    a[17,20]  abs_p_17_20  1
    a[17,20]  abs_m_17_20  1
    a[17,20]  true_G_epigraph  1
    a[17,20]  physical_G_upper  1
    a[17,20]  old_normalized_TC  1
    a[17,20]  old_normalized_TC2  1
    a[17,21]  abs_p_17_21  1
    a[17,21]  abs_m_17_21  1
    a[17,21]  true_G_epigraph  1
    a[17,21]  physical_G_upper  1
    a[17,21]  old_normalized_TC  1
    a[17,21]  old_normalized_TC2  1
    a[17,22]  abs_p_17_22  1
    a[17,22]  abs_m_17_22  1
    a[17,22]  true_G_epigraph  1
    a[17,22]  physical_G_upper  1
    a[17,22]  old_normalized_TC  1
    a[17,22]  old_normalized_TC2  1
    a[17,23]  abs_p_17_23  1
    a[17,23]  abs_m_17_23  1
    a[17,23]  true_G_epigraph  1
    a[17,23]  physical_G_upper  1
    a[17,23]  old_normalized_TC  1
    a[17,23]  old_normalized_TC2  1
    a[17,24]  abs_p_17_24  1
    a[17,24]  abs_m_17_24  1
    a[17,24]  true_G_epigraph  1
    a[17,24]  physical_G_upper  1
    a[17,24]  old_normalized_TC  1
    a[17,24]  old_normalized_TC2  1
    a[17,25]  abs_p_17_25  1
    a[17,25]  abs_m_17_25  1
    a[17,25]  true_G_epigraph  1
    a[17,25]  physical_G_upper  1
    a[17,25]  old_normalized_TC  1
    a[17,25]  old_normalized_TC2  1
    a[17,26]  abs_p_17_26  1
    a[17,26]  abs_m_17_26  1
    a[17,26]  true_G_epigraph  1
    a[17,26]  physical_G_upper  1
    a[17,26]  old_normalized_TC  1
    a[17,26]  old_normalized_TC2  1
    a[17,27]  abs_p_17_27  1
    a[17,27]  abs_m_17_27  1
    a[17,27]  true_G_epigraph  1
    a[17,27]  physical_G_upper  1
    a[17,27]  old_normalized_TC  1
    a[17,27]  old_normalized_TC2  1
    a[17,28]  abs_p_17_28  1
    a[17,28]  abs_m_17_28  1
    a[17,28]  true_G_epigraph  1
    a[17,28]  physical_G_upper  1
    a[17,28]  old_normalized_TC  1
    a[17,28]  old_normalized_TC2  1
    a[17,29]  abs_p_17_29  1
    a[17,29]  abs_m_17_29  1
    a[17,29]  true_G_epigraph  1
    a[17,29]  physical_G_upper  1
    a[17,29]  old_normalized_TC  1
    a[17,29]  old_normalized_TC2  1
    a[17,30]  abs_p_17_30  1
    a[17,30]  abs_m_17_30  1
    a[17,30]  true_G_epigraph  1
    a[17,30]  physical_G_upper  1
    a[17,30]  old_normalized_TC  1
    a[17,30]  old_normalized_TC2  1
    a[17,31]  abs_p_17_31  1
    a[17,31]  abs_m_17_31  1
    a[17,31]  true_G_epigraph  1
    a[17,31]  physical_G_upper  1
    a[17,31]  old_normalized_TC  1
    a[17,31]  old_normalized_TC2  1
    a[17,32]  abs_p_17_32  1
    a[17,32]  abs_m_17_32  1
    a[17,32]  true_G_epigraph  1
    a[17,32]  physical_G_upper  1
    a[17,32]  old_normalized_TC  1
    a[17,32]  old_normalized_TC2  1
    a[17,33]  abs_p_17_33  1
    a[17,33]  abs_m_17_33  1
    a[17,33]  true_G_epigraph  1
    a[17,33]  physical_G_upper  1
    a[17,33]  old_normalized_TC  1
    a[17,33]  old_normalized_TC2  1
    a[17,34]  abs_p_17_34  1
    a[17,34]  abs_m_17_34  1
    a[17,34]  true_G_epigraph  1
    a[17,34]  physical_G_upper  1
    a[17,34]  old_normalized_TC  1
    a[17,34]  old_normalized_TC2  1
    a[17,35]  abs_p_17_35  1
    a[17,35]  abs_m_17_35  1
    a[17,35]  true_G_epigraph  1
    a[17,35]  physical_G_upper  1
    a[17,35]  old_normalized_TC  1
    a[17,35]  old_normalized_TC2  1
    a[18,19]  abs_p_18_19  1
    a[18,19]  abs_m_18_19  1
    a[18,19]  true_G_epigraph  1
    a[18,19]  physical_G_upper  1
    a[18,19]  old_normalized_TC  1
    a[18,19]  old_normalized_TC2  1
    a[18,20]  abs_p_18_20  1
    a[18,20]  abs_m_18_20  1
    a[18,20]  true_G_epigraph  1
    a[18,20]  physical_G_upper  1
    a[18,20]  old_normalized_TC  1
    a[18,20]  old_normalized_TC2  1
    a[18,21]  abs_p_18_21  1
    a[18,21]  abs_m_18_21  1
    a[18,21]  true_G_epigraph  1
    a[18,21]  physical_G_upper  1
    a[18,21]  old_normalized_TC  1
    a[18,21]  old_normalized_TC2  1
    a[18,22]  abs_p_18_22  1
    a[18,22]  abs_m_18_22  1
    a[18,22]  true_G_epigraph  1
    a[18,22]  physical_G_upper  1
    a[18,22]  old_normalized_TC  1
    a[18,22]  old_normalized_TC2  1
    a[18,23]  abs_p_18_23  1
    a[18,23]  abs_m_18_23  1
    a[18,23]  true_G_epigraph  1
    a[18,23]  physical_G_upper  1
    a[18,23]  old_normalized_TC  1
    a[18,23]  old_normalized_TC2  1
    a[18,24]  abs_p_18_24  1
    a[18,24]  abs_m_18_24  1
    a[18,24]  true_G_epigraph  1
    a[18,24]  physical_G_upper  1
    a[18,24]  old_normalized_TC  1
    a[18,24]  old_normalized_TC2  1
    a[18,25]  abs_p_18_25  1
    a[18,25]  abs_m_18_25  1
    a[18,25]  true_G_epigraph  1
    a[18,25]  physical_G_upper  1
    a[18,25]  old_normalized_TC  1
    a[18,25]  old_normalized_TC2  1
    a[18,26]  abs_p_18_26  1
    a[18,26]  abs_m_18_26  1
    a[18,26]  true_G_epigraph  1
    a[18,26]  physical_G_upper  1
    a[18,26]  old_normalized_TC  1
    a[18,26]  old_normalized_TC2  1
    a[18,27]  abs_p_18_27  1
    a[18,27]  abs_m_18_27  1
    a[18,27]  true_G_epigraph  1
    a[18,27]  physical_G_upper  1
    a[18,27]  old_normalized_TC  1
    a[18,27]  old_normalized_TC2  1
    a[18,28]  abs_p_18_28  1
    a[18,28]  abs_m_18_28  1
    a[18,28]  true_G_epigraph  1
    a[18,28]  physical_G_upper  1
    a[18,28]  old_normalized_TC  1
    a[18,28]  old_normalized_TC2  1
    a[18,29]  abs_p_18_29  1
    a[18,29]  abs_m_18_29  1
    a[18,29]  true_G_epigraph  1
    a[18,29]  physical_G_upper  1
    a[18,29]  old_normalized_TC  1
    a[18,29]  old_normalized_TC2  1
    a[18,30]  abs_p_18_30  1
    a[18,30]  abs_m_18_30  1
    a[18,30]  true_G_epigraph  1
    a[18,30]  physical_G_upper  1
    a[18,30]  old_normalized_TC  1
    a[18,30]  old_normalized_TC2  1
    a[18,31]  abs_p_18_31  1
    a[18,31]  abs_m_18_31  1
    a[18,31]  true_G_epigraph  1
    a[18,31]  physical_G_upper  1
    a[18,31]  old_normalized_TC  1
    a[18,31]  old_normalized_TC2  1
    a[18,32]  abs_p_18_32  1
    a[18,32]  abs_m_18_32  1
    a[18,32]  true_G_epigraph  1
    a[18,32]  physical_G_upper  1
    a[18,32]  old_normalized_TC  1
    a[18,32]  old_normalized_TC2  1
    a[18,33]  abs_p_18_33  1
    a[18,33]  abs_m_18_33  1
    a[18,33]  true_G_epigraph  1
    a[18,33]  physical_G_upper  1
    a[18,33]  old_normalized_TC  1
    a[18,33]  old_normalized_TC2  1
    a[18,34]  abs_p_18_34  1
    a[18,34]  abs_m_18_34  1
    a[18,34]  true_G_epigraph  1
    a[18,34]  physical_G_upper  1
    a[18,34]  old_normalized_TC  1
    a[18,34]  old_normalized_TC2  1
    a[18,35]  abs_p_18_35  1
    a[18,35]  abs_m_18_35  1
    a[18,35]  true_G_epigraph  1
    a[18,35]  physical_G_upper  1
    a[18,35]  old_normalized_TC  1
    a[18,35]  old_normalized_TC2  1
    a[19,20]  abs_p_19_20  1
    a[19,20]  abs_m_19_20  1
    a[19,20]  true_G_epigraph  1
    a[19,20]  physical_G_upper  1
    a[19,20]  old_normalized_TC  1
    a[19,20]  old_normalized_TC2  1
    a[19,21]  abs_p_19_21  1
    a[19,21]  abs_m_19_21  1
    a[19,21]  true_G_epigraph  1
    a[19,21]  physical_G_upper  1
    a[19,21]  old_normalized_TC  1
    a[19,21]  old_normalized_TC2  1
    a[19,22]  abs_p_19_22  1
    a[19,22]  abs_m_19_22  1
    a[19,22]  true_G_epigraph  1
    a[19,22]  physical_G_upper  1
    a[19,22]  old_normalized_TC  1
    a[19,22]  old_normalized_TC2  1
    a[19,23]  abs_p_19_23  1
    a[19,23]  abs_m_19_23  1
    a[19,23]  true_G_epigraph  1
    a[19,23]  physical_G_upper  1
    a[19,23]  old_normalized_TC  1
    a[19,23]  old_normalized_TC2  1
    a[19,24]  abs_p_19_24  1
    a[19,24]  abs_m_19_24  1
    a[19,24]  true_G_epigraph  1
    a[19,24]  physical_G_upper  1
    a[19,24]  old_normalized_TC  1
    a[19,24]  old_normalized_TC2  1
    a[19,25]  abs_p_19_25  1
    a[19,25]  abs_m_19_25  1
    a[19,25]  true_G_epigraph  1
    a[19,25]  physical_G_upper  1
    a[19,25]  old_normalized_TC  1
    a[19,25]  old_normalized_TC2  1
    a[19,26]  abs_p_19_26  1
    a[19,26]  abs_m_19_26  1
    a[19,26]  true_G_epigraph  1
    a[19,26]  physical_G_upper  1
    a[19,26]  old_normalized_TC  1
    a[19,26]  old_normalized_TC2  1
    a[19,27]  abs_p_19_27  1
    a[19,27]  abs_m_19_27  1
    a[19,27]  true_G_epigraph  1
    a[19,27]  physical_G_upper  1
    a[19,27]  old_normalized_TC  1
    a[19,27]  old_normalized_TC2  1
    a[19,28]  abs_p_19_28  1
    a[19,28]  abs_m_19_28  1
    a[19,28]  true_G_epigraph  1
    a[19,28]  physical_G_upper  1
    a[19,28]  old_normalized_TC  1
    a[19,28]  old_normalized_TC2  1
    a[19,29]  abs_p_19_29  1
    a[19,29]  abs_m_19_29  1
    a[19,29]  true_G_epigraph  1
    a[19,29]  physical_G_upper  1
    a[19,29]  old_normalized_TC  1
    a[19,29]  old_normalized_TC2  1
    a[19,30]  abs_p_19_30  1
    a[19,30]  abs_m_19_30  1
    a[19,30]  true_G_epigraph  1
    a[19,30]  physical_G_upper  1
    a[19,30]  old_normalized_TC  1
    a[19,30]  old_normalized_TC2  1
    a[19,31]  abs_p_19_31  1
    a[19,31]  abs_m_19_31  1
    a[19,31]  true_G_epigraph  1
    a[19,31]  physical_G_upper  1
    a[19,31]  old_normalized_TC  1
    a[19,31]  old_normalized_TC2  1
    a[19,32]  abs_p_19_32  1
    a[19,32]  abs_m_19_32  1
    a[19,32]  true_G_epigraph  1
    a[19,32]  physical_G_upper  1
    a[19,32]  old_normalized_TC  1
    a[19,32]  old_normalized_TC2  1
    a[19,33]  abs_p_19_33  1
    a[19,33]  abs_m_19_33  1
    a[19,33]  true_G_epigraph  1
    a[19,33]  physical_G_upper  1
    a[19,33]  old_normalized_TC  1
    a[19,33]  old_normalized_TC2  1
    a[19,34]  abs_p_19_34  1
    a[19,34]  abs_m_19_34  1
    a[19,34]  true_G_epigraph  1
    a[19,34]  physical_G_upper  1
    a[19,34]  old_normalized_TC  1
    a[19,34]  old_normalized_TC2  1
    a[19,35]  abs_p_19_35  1
    a[19,35]  abs_m_19_35  1
    a[19,35]  true_G_epigraph  1
    a[19,35]  physical_G_upper  1
    a[19,35]  old_normalized_TC  1
    a[19,35]  old_normalized_TC2  1
    a[20,21]  abs_p_20_21  1
    a[20,21]  abs_m_20_21  1
    a[20,21]  true_G_epigraph  1
    a[20,21]  physical_G_upper  1
    a[20,21]  old_normalized_TC  1
    a[20,21]  old_normalized_TC2  1
    a[20,22]  abs_p_20_22  1
    a[20,22]  abs_m_20_22  1
    a[20,22]  true_G_epigraph  1
    a[20,22]  physical_G_upper  1
    a[20,22]  old_normalized_TC  1
    a[20,22]  old_normalized_TC2  1
    a[20,23]  abs_p_20_23  1
    a[20,23]  abs_m_20_23  1
    a[20,23]  true_G_epigraph  1
    a[20,23]  physical_G_upper  1
    a[20,23]  old_normalized_TC  1
    a[20,23]  old_normalized_TC2  1
    a[20,24]  abs_p_20_24  1
    a[20,24]  abs_m_20_24  1
    a[20,24]  true_G_epigraph  1
    a[20,24]  physical_G_upper  1
    a[20,24]  old_normalized_TC  1
    a[20,24]  old_normalized_TC2  1
    a[20,25]  abs_p_20_25  1
    a[20,25]  abs_m_20_25  1
    a[20,25]  true_G_epigraph  1
    a[20,25]  physical_G_upper  1
    a[20,25]  old_normalized_TC  1
    a[20,25]  old_normalized_TC2  1
    a[20,26]  abs_p_20_26  1
    a[20,26]  abs_m_20_26  1
    a[20,26]  true_G_epigraph  1
    a[20,26]  physical_G_upper  1
    a[20,26]  old_normalized_TC  1
    a[20,26]  old_normalized_TC2  1
    a[20,27]  abs_p_20_27  1
    a[20,27]  abs_m_20_27  1
    a[20,27]  true_G_epigraph  1
    a[20,27]  physical_G_upper  1
    a[20,27]  old_normalized_TC  1
    a[20,27]  old_normalized_TC2  1
    a[20,28]  abs_p_20_28  1
    a[20,28]  abs_m_20_28  1
    a[20,28]  true_G_epigraph  1
    a[20,28]  physical_G_upper  1
    a[20,28]  old_normalized_TC  1
    a[20,28]  old_normalized_TC2  1
    a[20,29]  abs_p_20_29  1
    a[20,29]  abs_m_20_29  1
    a[20,29]  true_G_epigraph  1
    a[20,29]  physical_G_upper  1
    a[20,29]  old_normalized_TC  1
    a[20,29]  old_normalized_TC2  1
    a[20,30]  abs_p_20_30  1
    a[20,30]  abs_m_20_30  1
    a[20,30]  true_G_epigraph  1
    a[20,30]  physical_G_upper  1
    a[20,30]  old_normalized_TC  1
    a[20,30]  old_normalized_TC2  1
    a[20,31]  abs_p_20_31  1
    a[20,31]  abs_m_20_31  1
    a[20,31]  true_G_epigraph  1
    a[20,31]  physical_G_upper  1
    a[20,31]  old_normalized_TC  1
    a[20,31]  old_normalized_TC2  1
    a[20,32]  abs_p_20_32  1
    a[20,32]  abs_m_20_32  1
    a[20,32]  true_G_epigraph  1
    a[20,32]  physical_G_upper  1
    a[20,32]  old_normalized_TC  1
    a[20,32]  old_normalized_TC2  1
    a[20,33]  abs_p_20_33  1
    a[20,33]  abs_m_20_33  1
    a[20,33]  true_G_epigraph  1
    a[20,33]  physical_G_upper  1
    a[20,33]  old_normalized_TC  1
    a[20,33]  old_normalized_TC2  1
    a[20,34]  abs_p_20_34  1
    a[20,34]  abs_m_20_34  1
    a[20,34]  true_G_epigraph  1
    a[20,34]  physical_G_upper  1
    a[20,34]  old_normalized_TC  1
    a[20,34]  old_normalized_TC2  1
    a[20,35]  abs_p_20_35  1
    a[20,35]  abs_m_20_35  1
    a[20,35]  true_G_epigraph  1
    a[20,35]  physical_G_upper  1
    a[20,35]  old_normalized_TC  1
    a[20,35]  old_normalized_TC2  1
    a[21,22]  abs_p_21_22  1
    a[21,22]  abs_m_21_22  1
    a[21,22]  true_G_epigraph  1
    a[21,22]  physical_G_upper  1
    a[21,22]  old_normalized_TC  1
    a[21,22]  old_normalized_TC2  1
    a[21,23]  abs_p_21_23  1
    a[21,23]  abs_m_21_23  1
    a[21,23]  true_G_epigraph  1
    a[21,23]  physical_G_upper  1
    a[21,23]  old_normalized_TC  1
    a[21,23]  old_normalized_TC2  1
    a[21,24]  abs_p_21_24  1
    a[21,24]  abs_m_21_24  1
    a[21,24]  true_G_epigraph  1
    a[21,24]  physical_G_upper  1
    a[21,24]  old_normalized_TC  1
    a[21,24]  old_normalized_TC2  1
    a[21,25]  abs_p_21_25  1
    a[21,25]  abs_m_21_25  1
    a[21,25]  true_G_epigraph  1
    a[21,25]  physical_G_upper  1
    a[21,25]  old_normalized_TC  1
    a[21,25]  old_normalized_TC2  1
    a[21,26]  abs_p_21_26  1
    a[21,26]  abs_m_21_26  1
    a[21,26]  true_G_epigraph  1
    a[21,26]  physical_G_upper  1
    a[21,26]  old_normalized_TC  1
    a[21,26]  old_normalized_TC2  1
    a[21,27]  abs_p_21_27  1
    a[21,27]  abs_m_21_27  1
    a[21,27]  true_G_epigraph  1
    a[21,27]  physical_G_upper  1
    a[21,27]  old_normalized_TC  1
    a[21,27]  old_normalized_TC2  1
    a[21,28]  abs_p_21_28  1
    a[21,28]  abs_m_21_28  1
    a[21,28]  true_G_epigraph  1
    a[21,28]  physical_G_upper  1
    a[21,28]  old_normalized_TC  1
    a[21,28]  old_normalized_TC2  1
    a[21,29]  abs_p_21_29  1
    a[21,29]  abs_m_21_29  1
    a[21,29]  true_G_epigraph  1
    a[21,29]  physical_G_upper  1
    a[21,29]  old_normalized_TC  1
    a[21,29]  old_normalized_TC2  1
    a[21,30]  abs_p_21_30  1
    a[21,30]  abs_m_21_30  1
    a[21,30]  true_G_epigraph  1
    a[21,30]  physical_G_upper  1
    a[21,30]  old_normalized_TC  1
    a[21,30]  old_normalized_TC2  1
    a[21,31]  abs_p_21_31  1
    a[21,31]  abs_m_21_31  1
    a[21,31]  true_G_epigraph  1
    a[21,31]  physical_G_upper  1
    a[21,31]  old_normalized_TC  1
    a[21,31]  old_normalized_TC2  1
    a[21,32]  abs_p_21_32  1
    a[21,32]  abs_m_21_32  1
    a[21,32]  true_G_epigraph  1
    a[21,32]  physical_G_upper  1
    a[21,32]  old_normalized_TC  1
    a[21,32]  old_normalized_TC2  1
    a[21,33]  abs_p_21_33  1
    a[21,33]  abs_m_21_33  1
    a[21,33]  true_G_epigraph  1
    a[21,33]  physical_G_upper  1
    a[21,33]  old_normalized_TC  1
    a[21,33]  old_normalized_TC2  1
    a[21,34]  abs_p_21_34  1
    a[21,34]  abs_m_21_34  1
    a[21,34]  true_G_epigraph  1
    a[21,34]  physical_G_upper  1
    a[21,34]  old_normalized_TC  1
    a[21,34]  old_normalized_TC2  1
    a[21,35]  abs_p_21_35  1
    a[21,35]  abs_m_21_35  1
    a[21,35]  true_G_epigraph  1
    a[21,35]  physical_G_upper  1
    a[21,35]  old_normalized_TC  1
    a[21,35]  old_normalized_TC2  1
    a[22,23]  abs_p_22_23  1
    a[22,23]  abs_m_22_23  1
    a[22,23]  true_G_epigraph  1
    a[22,23]  physical_G_upper  1
    a[22,23]  old_normalized_TC  1
    a[22,23]  old_normalized_TC2  1
    a[22,24]  abs_p_22_24  1
    a[22,24]  abs_m_22_24  1
    a[22,24]  true_G_epigraph  1
    a[22,24]  physical_G_upper  1
    a[22,24]  old_normalized_TC  1
    a[22,24]  old_normalized_TC2  1
    a[22,25]  abs_p_22_25  1
    a[22,25]  abs_m_22_25  1
    a[22,25]  true_G_epigraph  1
    a[22,25]  physical_G_upper  1
    a[22,25]  old_normalized_TC  1
    a[22,25]  old_normalized_TC2  1
    a[22,26]  abs_p_22_26  1
    a[22,26]  abs_m_22_26  1
    a[22,26]  true_G_epigraph  1
    a[22,26]  physical_G_upper  1
    a[22,26]  old_normalized_TC  1
    a[22,26]  old_normalized_TC2  1
    a[22,27]  abs_p_22_27  1
    a[22,27]  abs_m_22_27  1
    a[22,27]  true_G_epigraph  1
    a[22,27]  physical_G_upper  1
    a[22,27]  old_normalized_TC  1
    a[22,27]  old_normalized_TC2  1
    a[22,28]  abs_p_22_28  1
    a[22,28]  abs_m_22_28  1
    a[22,28]  true_G_epigraph  1
    a[22,28]  physical_G_upper  1
    a[22,28]  old_normalized_TC  1
    a[22,28]  old_normalized_TC2  1
    a[22,29]  abs_p_22_29  1
    a[22,29]  abs_m_22_29  1
    a[22,29]  true_G_epigraph  1
    a[22,29]  physical_G_upper  1
    a[22,29]  old_normalized_TC  1
    a[22,29]  old_normalized_TC2  1
    a[22,30]  abs_p_22_30  1
    a[22,30]  abs_m_22_30  1
    a[22,30]  true_G_epigraph  1
    a[22,30]  physical_G_upper  1
    a[22,30]  old_normalized_TC  1
    a[22,30]  old_normalized_TC2  1
    a[22,31]  abs_p_22_31  1
    a[22,31]  abs_m_22_31  1
    a[22,31]  true_G_epigraph  1
    a[22,31]  physical_G_upper  1
    a[22,31]  old_normalized_TC  1
    a[22,31]  old_normalized_TC2  1
    a[22,32]  abs_p_22_32  1
    a[22,32]  abs_m_22_32  1
    a[22,32]  true_G_epigraph  1
    a[22,32]  physical_G_upper  1
    a[22,32]  old_normalized_TC  1
    a[22,32]  old_normalized_TC2  1
    a[22,33]  abs_p_22_33  1
    a[22,33]  abs_m_22_33  1
    a[22,33]  true_G_epigraph  1
    a[22,33]  physical_G_upper  1
    a[22,33]  old_normalized_TC  1
    a[22,33]  old_normalized_TC2  1
    a[22,34]  abs_p_22_34  1
    a[22,34]  abs_m_22_34  1
    a[22,34]  true_G_epigraph  1
    a[22,34]  physical_G_upper  1
    a[22,34]  old_normalized_TC  1
    a[22,34]  old_normalized_TC2  1
    a[22,35]  abs_p_22_35  1
    a[22,35]  abs_m_22_35  1
    a[22,35]  true_G_epigraph  1
    a[22,35]  physical_G_upper  1
    a[22,35]  old_normalized_TC  1
    a[22,35]  old_normalized_TC2  1
    a[23,24]  abs_p_23_24  1
    a[23,24]  abs_m_23_24  1
    a[23,24]  true_G_epigraph  1
    a[23,24]  physical_G_upper  1
    a[23,24]  old_normalized_TC  1
    a[23,24]  old_normalized_TC2  1
    a[23,25]  abs_p_23_25  1
    a[23,25]  abs_m_23_25  1
    a[23,25]  true_G_epigraph  1
    a[23,25]  physical_G_upper  1
    a[23,25]  old_normalized_TC  1
    a[23,25]  old_normalized_TC2  1
    a[23,26]  abs_p_23_26  1
    a[23,26]  abs_m_23_26  1
    a[23,26]  true_G_epigraph  1
    a[23,26]  physical_G_upper  1
    a[23,26]  old_normalized_TC  1
    a[23,26]  old_normalized_TC2  1
    a[23,27]  abs_p_23_27  1
    a[23,27]  abs_m_23_27  1
    a[23,27]  true_G_epigraph  1
    a[23,27]  physical_G_upper  1
    a[23,27]  old_normalized_TC  1
    a[23,27]  old_normalized_TC2  1
    a[23,28]  abs_p_23_28  1
    a[23,28]  abs_m_23_28  1
    a[23,28]  true_G_epigraph  1
    a[23,28]  physical_G_upper  1
    a[23,28]  old_normalized_TC  1
    a[23,28]  old_normalized_TC2  1
    a[23,29]  abs_p_23_29  1
    a[23,29]  abs_m_23_29  1
    a[23,29]  true_G_epigraph  1
    a[23,29]  physical_G_upper  1
    a[23,29]  old_normalized_TC  1
    a[23,29]  old_normalized_TC2  1
    a[23,30]  abs_p_23_30  1
    a[23,30]  abs_m_23_30  1
    a[23,30]  true_G_epigraph  1
    a[23,30]  physical_G_upper  1
    a[23,30]  old_normalized_TC  1
    a[23,30]  old_normalized_TC2  1
    a[23,31]  abs_p_23_31  1
    a[23,31]  abs_m_23_31  1
    a[23,31]  true_G_epigraph  1
    a[23,31]  physical_G_upper  1
    a[23,31]  old_normalized_TC  1
    a[23,31]  old_normalized_TC2  1
    a[23,32]  abs_p_23_32  1
    a[23,32]  abs_m_23_32  1
    a[23,32]  true_G_epigraph  1
    a[23,32]  physical_G_upper  1
    a[23,32]  old_normalized_TC  1
    a[23,32]  old_normalized_TC2  1
    a[23,33]  abs_p_23_33  1
    a[23,33]  abs_m_23_33  1
    a[23,33]  true_G_epigraph  1
    a[23,33]  physical_G_upper  1
    a[23,33]  old_normalized_TC  1
    a[23,33]  old_normalized_TC2  1
    a[23,34]  abs_p_23_34  1
    a[23,34]  abs_m_23_34  1
    a[23,34]  true_G_epigraph  1
    a[23,34]  physical_G_upper  1
    a[23,34]  old_normalized_TC  1
    a[23,34]  old_normalized_TC2  1
    a[23,35]  abs_p_23_35  1
    a[23,35]  abs_m_23_35  1
    a[23,35]  true_G_epigraph  1
    a[23,35]  physical_G_upper  1
    a[23,35]  old_normalized_TC  1
    a[23,35]  old_normalized_TC2  1
    a[24,25]  abs_p_24_25  1
    a[24,25]  abs_m_24_25  1
    a[24,25]  true_G_epigraph  1
    a[24,25]  physical_G_upper  1
    a[24,25]  old_normalized_TC  1
    a[24,25]  old_normalized_TC2  1
    a[24,26]  abs_p_24_26  1
    a[24,26]  abs_m_24_26  1
    a[24,26]  true_G_epigraph  1
    a[24,26]  physical_G_upper  1
    a[24,26]  old_normalized_TC  1
    a[24,26]  old_normalized_TC2  1
    a[24,27]  abs_p_24_27  1
    a[24,27]  abs_m_24_27  1
    a[24,27]  true_G_epigraph  1
    a[24,27]  physical_G_upper  1
    a[24,27]  old_normalized_TC  1
    a[24,27]  old_normalized_TC2  1
    a[24,28]  abs_p_24_28  1
    a[24,28]  abs_m_24_28  1
    a[24,28]  true_G_epigraph  1
    a[24,28]  physical_G_upper  1
    a[24,28]  old_normalized_TC  1
    a[24,28]  old_normalized_TC2  1
    a[24,29]  abs_p_24_29  1
    a[24,29]  abs_m_24_29  1
    a[24,29]  true_G_epigraph  1
    a[24,29]  physical_G_upper  1
    a[24,29]  old_normalized_TC  1
    a[24,29]  old_normalized_TC2  1
    a[24,30]  abs_p_24_30  1
    a[24,30]  abs_m_24_30  1
    a[24,30]  true_G_epigraph  1
    a[24,30]  physical_G_upper  1
    a[24,30]  old_normalized_TC  1
    a[24,30]  old_normalized_TC2  1
    a[24,31]  abs_p_24_31  1
    a[24,31]  abs_m_24_31  1
    a[24,31]  true_G_epigraph  1
    a[24,31]  physical_G_upper  1
    a[24,31]  old_normalized_TC  1
    a[24,31]  old_normalized_TC2  1
    a[24,32]  abs_p_24_32  1
    a[24,32]  abs_m_24_32  1
    a[24,32]  true_G_epigraph  1
    a[24,32]  physical_G_upper  1
    a[24,32]  old_normalized_TC  1
    a[24,32]  old_normalized_TC2  1
    a[24,33]  abs_p_24_33  1
    a[24,33]  abs_m_24_33  1
    a[24,33]  true_G_epigraph  1
    a[24,33]  physical_G_upper  1
    a[24,33]  old_normalized_TC  1
    a[24,33]  old_normalized_TC2  1
    a[24,34]  abs_p_24_34  1
    a[24,34]  abs_m_24_34  1
    a[24,34]  true_G_epigraph  1
    a[24,34]  physical_G_upper  1
    a[24,34]  old_normalized_TC  1
    a[24,34]  old_normalized_TC2  1
    a[24,35]  abs_p_24_35  1
    a[24,35]  abs_m_24_35  1
    a[24,35]  true_G_epigraph  1
    a[24,35]  physical_G_upper  1
    a[24,35]  old_normalized_TC  1
    a[24,35]  old_normalized_TC2  1
    a[25,26]  abs_p_25_26  1
    a[25,26]  abs_m_25_26  1
    a[25,26]  true_G_epigraph  1
    a[25,26]  physical_G_upper  1
    a[25,26]  old_normalized_TC  1
    a[25,26]  old_normalized_TC2  1
    a[25,27]  abs_p_25_27  1
    a[25,27]  abs_m_25_27  1
    a[25,27]  true_G_epigraph  1
    a[25,27]  physical_G_upper  1
    a[25,27]  old_normalized_TC  1
    a[25,27]  old_normalized_TC2  1
    a[25,28]  abs_p_25_28  1
    a[25,28]  abs_m_25_28  1
    a[25,28]  true_G_epigraph  1
    a[25,28]  physical_G_upper  1
    a[25,28]  old_normalized_TC  1
    a[25,28]  old_normalized_TC2  1
    a[25,29]  abs_p_25_29  1
    a[25,29]  abs_m_25_29  1
    a[25,29]  true_G_epigraph  1
    a[25,29]  physical_G_upper  1
    a[25,29]  old_normalized_TC  1
    a[25,29]  old_normalized_TC2  1
    a[25,30]  abs_p_25_30  1
    a[25,30]  abs_m_25_30  1
    a[25,30]  true_G_epigraph  1
    a[25,30]  physical_G_upper  1
    a[25,30]  old_normalized_TC  1
    a[25,30]  old_normalized_TC2  1
    a[25,31]  abs_p_25_31  1
    a[25,31]  abs_m_25_31  1
    a[25,31]  true_G_epigraph  1
    a[25,31]  physical_G_upper  1
    a[25,31]  old_normalized_TC  1
    a[25,31]  old_normalized_TC2  1
    a[25,32]  abs_p_25_32  1
    a[25,32]  abs_m_25_32  1
    a[25,32]  true_G_epigraph  1
    a[25,32]  physical_G_upper  1
    a[25,32]  old_normalized_TC  1
    a[25,32]  old_normalized_TC2  1
    a[25,33]  abs_p_25_33  1
    a[25,33]  abs_m_25_33  1
    a[25,33]  true_G_epigraph  1
    a[25,33]  physical_G_upper  1
    a[25,33]  old_normalized_TC  1
    a[25,33]  old_normalized_TC2  1
    a[25,34]  abs_p_25_34  1
    a[25,34]  abs_m_25_34  1
    a[25,34]  true_G_epigraph  1
    a[25,34]  physical_G_upper  1
    a[25,34]  old_normalized_TC  1
    a[25,34]  old_normalized_TC2  1
    a[25,35]  abs_p_25_35  1
    a[25,35]  abs_m_25_35  1
    a[25,35]  true_G_epigraph  1
    a[25,35]  physical_G_upper  1
    a[25,35]  old_normalized_TC  1
    a[25,35]  old_normalized_TC2  1
    a[26,27]  abs_p_26_27  1
    a[26,27]  abs_m_26_27  1
    a[26,27]  true_G_epigraph  1
    a[26,27]  physical_G_upper  1
    a[26,27]  old_normalized_TC  1
    a[26,27]  old_normalized_TC2  1
    a[26,28]  abs_p_26_28  1
    a[26,28]  abs_m_26_28  1
    a[26,28]  true_G_epigraph  1
    a[26,28]  physical_G_upper  1
    a[26,28]  old_normalized_TC  1
    a[26,28]  old_normalized_TC2  1
    a[26,29]  abs_p_26_29  1
    a[26,29]  abs_m_26_29  1
    a[26,29]  true_G_epigraph  1
    a[26,29]  physical_G_upper  1
    a[26,29]  old_normalized_TC  1
    a[26,29]  old_normalized_TC2  1
    a[26,30]  abs_p_26_30  1
    a[26,30]  abs_m_26_30  1
    a[26,30]  true_G_epigraph  1
    a[26,30]  physical_G_upper  1
    a[26,30]  old_normalized_TC  1
    a[26,30]  old_normalized_TC2  1
    a[26,31]  abs_p_26_31  1
    a[26,31]  abs_m_26_31  1
    a[26,31]  true_G_epigraph  1
    a[26,31]  physical_G_upper  1
    a[26,31]  old_normalized_TC  1
    a[26,31]  old_normalized_TC2  1
    a[26,32]  abs_p_26_32  1
    a[26,32]  abs_m_26_32  1
    a[26,32]  true_G_epigraph  1
    a[26,32]  physical_G_upper  1
    a[26,32]  old_normalized_TC  1
    a[26,32]  old_normalized_TC2  1
    a[26,33]  abs_p_26_33  1
    a[26,33]  abs_m_26_33  1
    a[26,33]  true_G_epigraph  1
    a[26,33]  physical_G_upper  1
    a[26,33]  old_normalized_TC  1
    a[26,33]  old_normalized_TC2  1
    a[26,34]  abs_p_26_34  1
    a[26,34]  abs_m_26_34  1
    a[26,34]  true_G_epigraph  1
    a[26,34]  physical_G_upper  1
    a[26,34]  old_normalized_TC  1
    a[26,34]  old_normalized_TC2  1
    a[26,35]  abs_p_26_35  1
    a[26,35]  abs_m_26_35  1
    a[26,35]  true_G_epigraph  1
    a[26,35]  physical_G_upper  1
    a[26,35]  old_normalized_TC  1
    a[26,35]  old_normalized_TC2  1
    a[27,28]  abs_p_27_28  1
    a[27,28]  abs_m_27_28  1
    a[27,28]  true_G_epigraph  1
    a[27,28]  physical_G_upper  1
    a[27,28]  old_normalized_TC  1
    a[27,28]  old_normalized_TC2  1
    a[27,29]  abs_p_27_29  1
    a[27,29]  abs_m_27_29  1
    a[27,29]  true_G_epigraph  1
    a[27,29]  physical_G_upper  1
    a[27,29]  old_normalized_TC  1
    a[27,29]  old_normalized_TC2  1
    a[27,30]  abs_p_27_30  1
    a[27,30]  abs_m_27_30  1
    a[27,30]  true_G_epigraph  1
    a[27,30]  physical_G_upper  1
    a[27,30]  old_normalized_TC  1
    a[27,30]  old_normalized_TC2  1
    a[27,31]  abs_p_27_31  1
    a[27,31]  abs_m_27_31  1
    a[27,31]  true_G_epigraph  1
    a[27,31]  physical_G_upper  1
    a[27,31]  old_normalized_TC  1
    a[27,31]  old_normalized_TC2  1
    a[27,32]  abs_p_27_32  1
    a[27,32]  abs_m_27_32  1
    a[27,32]  true_G_epigraph  1
    a[27,32]  physical_G_upper  1
    a[27,32]  old_normalized_TC  1
    a[27,32]  old_normalized_TC2  1
    a[27,33]  abs_p_27_33  1
    a[27,33]  abs_m_27_33  1
    a[27,33]  true_G_epigraph  1
    a[27,33]  physical_G_upper  1
    a[27,33]  old_normalized_TC  1
    a[27,33]  old_normalized_TC2  1
    a[27,34]  abs_p_27_34  1
    a[27,34]  abs_m_27_34  1
    a[27,34]  true_G_epigraph  1
    a[27,34]  physical_G_upper  1
    a[27,34]  old_normalized_TC  1
    a[27,34]  old_normalized_TC2  1
    a[27,35]  abs_p_27_35  1
    a[27,35]  abs_m_27_35  1
    a[27,35]  true_G_epigraph  1
    a[27,35]  physical_G_upper  1
    a[27,35]  old_normalized_TC  1
    a[27,35]  old_normalized_TC2  1
    a[28,29]  abs_p_28_29  1
    a[28,29]  abs_m_28_29  1
    a[28,29]  true_G_epigraph  1
    a[28,29]  physical_G_upper  1
    a[28,29]  old_normalized_TC  1
    a[28,29]  old_normalized_TC2  1
    a[28,30]  abs_p_28_30  1
    a[28,30]  abs_m_28_30  1
    a[28,30]  true_G_epigraph  1
    a[28,30]  physical_G_upper  1
    a[28,30]  old_normalized_TC  1
    a[28,30]  old_normalized_TC2  1
    a[28,31]  abs_p_28_31  1
    a[28,31]  abs_m_28_31  1
    a[28,31]  true_G_epigraph  1
    a[28,31]  physical_G_upper  1
    a[28,31]  old_normalized_TC  1
    a[28,31]  old_normalized_TC2  1
    a[28,32]  abs_p_28_32  1
    a[28,32]  abs_m_28_32  1
    a[28,32]  true_G_epigraph  1
    a[28,32]  physical_G_upper  1
    a[28,32]  old_normalized_TC  1
    a[28,32]  old_normalized_TC2  1
    a[28,33]  abs_p_28_33  1
    a[28,33]  abs_m_28_33  1
    a[28,33]  true_G_epigraph  1
    a[28,33]  physical_G_upper  1
    a[28,33]  old_normalized_TC  1
    a[28,33]  old_normalized_TC2  1
    a[28,34]  abs_p_28_34  1
    a[28,34]  abs_m_28_34  1
    a[28,34]  true_G_epigraph  1
    a[28,34]  physical_G_upper  1
    a[28,34]  old_normalized_TC  1
    a[28,34]  old_normalized_TC2  1
    a[28,35]  abs_p_28_35  1
    a[28,35]  abs_m_28_35  1
    a[28,35]  true_G_epigraph  1
    a[28,35]  physical_G_upper  1
    a[28,35]  old_normalized_TC  1
    a[28,35]  old_normalized_TC2  1
    a[29,30]  abs_p_29_30  1
    a[29,30]  abs_m_29_30  1
    a[29,30]  true_G_epigraph  1
    a[29,30]  physical_G_upper  1
    a[29,30]  old_normalized_TC  1
    a[29,30]  old_normalized_TC2  1
    a[29,31]  abs_p_29_31  1
    a[29,31]  abs_m_29_31  1
    a[29,31]  true_G_epigraph  1
    a[29,31]  physical_G_upper  1
    a[29,31]  old_normalized_TC  1
    a[29,31]  old_normalized_TC2  1
    a[29,32]  abs_p_29_32  1
    a[29,32]  abs_m_29_32  1
    a[29,32]  true_G_epigraph  1
    a[29,32]  physical_G_upper  1
    a[29,32]  old_normalized_TC  1
    a[29,32]  old_normalized_TC2  1
    a[29,33]  abs_p_29_33  1
    a[29,33]  abs_m_29_33  1
    a[29,33]  true_G_epigraph  1
    a[29,33]  physical_G_upper  1
    a[29,33]  old_normalized_TC  1
    a[29,33]  old_normalized_TC2  1
    a[29,34]  abs_p_29_34  1
    a[29,34]  abs_m_29_34  1
    a[29,34]  true_G_epigraph  1
    a[29,34]  physical_G_upper  1
    a[29,34]  old_normalized_TC  1
    a[29,34]  old_normalized_TC2  1
    a[29,35]  abs_p_29_35  1
    a[29,35]  abs_m_29_35  1
    a[29,35]  true_G_epigraph  1
    a[29,35]  physical_G_upper  1
    a[29,35]  old_normalized_TC  1
    a[29,35]  old_normalized_TC2  1
    a[30,31]  abs_p_30_31  1
    a[30,31]  abs_m_30_31  1
    a[30,31]  true_G_epigraph  1
    a[30,31]  physical_G_upper  1
    a[30,31]  old_normalized_TC  1
    a[30,31]  old_normalized_TC2  1
    a[30,32]  abs_p_30_32  1
    a[30,32]  abs_m_30_32  1
    a[30,32]  true_G_epigraph  1
    a[30,32]  physical_G_upper  1
    a[30,32]  old_normalized_TC  1
    a[30,32]  old_normalized_TC2  1
    a[30,33]  abs_p_30_33  1
    a[30,33]  abs_m_30_33  1
    a[30,33]  true_G_epigraph  1
    a[30,33]  physical_G_upper  1
    a[30,33]  old_normalized_TC  1
    a[30,33]  old_normalized_TC2  1
    a[30,34]  abs_p_30_34  1
    a[30,34]  abs_m_30_34  1
    a[30,34]  true_G_epigraph  1
    a[30,34]  physical_G_upper  1
    a[30,34]  old_normalized_TC  1
    a[30,34]  old_normalized_TC2  1
    a[30,35]  abs_p_30_35  1
    a[30,35]  abs_m_30_35  1
    a[30,35]  true_G_epigraph  1
    a[30,35]  physical_G_upper  1
    a[30,35]  old_normalized_TC  1
    a[30,35]  old_normalized_TC2  1
    a[31,32]  abs_p_31_32  1
    a[31,32]  abs_m_31_32  1
    a[31,32]  true_G_epigraph  1
    a[31,32]  physical_G_upper  1
    a[31,32]  old_normalized_TC  1
    a[31,32]  old_normalized_TC2  1
    a[31,33]  abs_p_31_33  1
    a[31,33]  abs_m_31_33  1
    a[31,33]  true_G_epigraph  1
    a[31,33]  physical_G_upper  1
    a[31,33]  old_normalized_TC  1
    a[31,33]  old_normalized_TC2  1
    a[31,34]  abs_p_31_34  1
    a[31,34]  abs_m_31_34  1
    a[31,34]  true_G_epigraph  1
    a[31,34]  physical_G_upper  1
    a[31,34]  old_normalized_TC  1
    a[31,34]  old_normalized_TC2  1
    a[31,35]  abs_p_31_35  1
    a[31,35]  abs_m_31_35  1
    a[31,35]  true_G_epigraph  1
    a[31,35]  physical_G_upper  1
    a[31,35]  old_normalized_TC  1
    a[31,35]  old_normalized_TC2  1
    a[32,33]  abs_p_32_33  1
    a[32,33]  abs_m_32_33  1
    a[32,33]  true_G_epigraph  1
    a[32,33]  physical_G_upper  1
    a[32,33]  old_normalized_TC  1
    a[32,33]  old_normalized_TC2  1
    a[32,34]  abs_p_32_34  1
    a[32,34]  abs_m_32_34  1
    a[32,34]  true_G_epigraph  1
    a[32,34]  physical_G_upper  1
    a[32,34]  old_normalized_TC  1
    a[32,34]  old_normalized_TC2  1
    a[32,35]  abs_p_32_35  1
    a[32,35]  abs_m_32_35  1
    a[32,35]  true_G_epigraph  1
    a[32,35]  physical_G_upper  1
    a[32,35]  old_normalized_TC  1
    a[32,35]  old_normalized_TC2  1
    a[33,34]  abs_p_33_34  1
    a[33,34]  abs_m_33_34  1
    a[33,34]  true_G_epigraph  1
    a[33,34]  physical_G_upper  1
    a[33,34]  old_normalized_TC  1
    a[33,34]  old_normalized_TC2  1
    a[33,35]  abs_p_33_35  1
    a[33,35]  abs_m_33_35  1
    a[33,35]  true_G_epigraph  1
    a[33,35]  physical_G_upper  1
    a[33,35]  old_normalized_TC  1
    a[33,35]  old_normalized_TC2  1
    a[34,35]  abs_p_34_35  1
    a[34,35]  abs_m_34_35  1
    a[34,35]  true_G_epigraph  1
    a[34,35]  physical_G_upper  1
    a[34,35]  old_normalized_TC  1
    a[34,35]  old_normalized_TC2  1
    q         OBJ       1
    q         true_G_epigraph  -35
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      onehot_3  1
    RHS1      onehot_4  1
    RHS1      onehot_5  1
    RHS1      onehot_6  1
    RHS1      onehot_7  1
    RHS1      onehot_8  1
    RHS1      onehot_9  1
    RHS1      onehot_10  1
    RHS1      onehot_11  1
    RHS1      onehot_12  1
    RHS1      onehot_13  1
    RHS1      onehot_14  1
    RHS1      onehot_15  1
    RHS1      onehot_16  1
    RHS1      onehot_17  1
    RHS1      onehot_18  1
    RHS1      onehot_19  1
    RHS1      onehot_20  1
    RHS1      onehot_21  1
    RHS1      onehot_22  1
    RHS1      onehot_23  1
    RHS1      onehot_24  1
    RHS1      onehot_25  1
    RHS1      onehot_26  1
    RHS1      onehot_27  1
    RHS1      onehot_28  1
    RHS1      onehot_29  1
    RHS1      onehot_30  1
    RHS1      onehot_31  1
    RHS1      onehot_32  1
    RHS1      onehot_33  1
    RHS1      onehot_34  1
    RHS1      onehot_35  1
    RHS1      hard_lower  251
    RHS1      hard_upper  326
    RHS1      normalization  1
    RHS1      physical_G_upper  2.6860981165365086e+01
    RHS1      old_TS1   -5.5869415443319737e+00
    RHS1      old_TS2   -1.2888584525583452e+01
    RHS1      old_TS3   -9.9234193739921643e+00
    RHS1      old_TS4   -7.2563463882558672e+00
BOUNDS
 BV BND1      x[1,4]  
 BV BND1      x[2,0]  
 BV BND1      x[2,1]  
 BV BND1      x[2,2]  
 BV BND1      x[2,3]  
 BV BND1      x[2,4]  
 BV BND1      x[2,5]  
 BV BND1      x[2,6]  
 BV BND1      x[2,7]  
 BV BND1      x[2,8]  
 BV BND1      x[2,9]  
 BV BND1      x[2,10] 
 BV BND1      x[2,11] 
 BV BND1      x[2,12] 
 BV BND1      x[2,13] 
 BV BND1      x[2,14] 
 BV BND1      x[2,15] 
 BV BND1      x[2,16] 
 BV BND1      x[2,17] 
 BV BND1      x[2,18] 
 BV BND1      x[2,19] 
 BV BND1      x[2,20] 
 BV BND1      x[2,21] 
 BV BND1      x[2,22] 
 BV BND1      x[2,23] 
 BV BND1      x[3,13] 
 BV BND1      x[4,0]  
 BV BND1      x[4,1]  
 BV BND1      x[4,2]  
 BV BND1      x[4,3]  
 BV BND1      x[4,4]  
 BV BND1      x[4,5]  
 BV BND1      x[4,6]  
 BV BND1      x[4,7]  
 BV BND1      x[4,8]  
 BV BND1      x[4,9]  
 BV BND1      x[4,10] 
 BV BND1      x[4,11] 
 BV BND1      x[4,12] 
 BV BND1      x[4,13] 
 BV BND1      x[4,14] 
 BV BND1      x[4,15] 
 BV BND1      x[5,0]  
 BV BND1      x[5,1]  
 BV BND1      x[5,2]  
 BV BND1      x[5,3]  
 BV BND1      x[5,4]  
 BV BND1      x[5,5]  
 BV BND1      x[5,6]  
 BV BND1      x[5,7]  
 BV BND1      x[5,8]  
 BV BND1      x[5,9]  
 BV BND1      x[5,10] 
 BV BND1      x[5,11] 
 BV BND1      x[5,12] 
 BV BND1      x[5,13] 
 BV BND1      x[5,14] 
 BV BND1      x[5,15] 
 BV BND1      x[6,4]  
 BV BND1      x[7,0]  
 BV BND1      x[7,1]  
 BV BND1      x[7,2]  
 BV BND1      x[7,3]  
 BV BND1      x[7,4]  
 BV BND1      x[7,5]  
 BV BND1      x[7,6]  
 BV BND1      x[7,7]  
 BV BND1      x[7,8]  
 BV BND1      x[7,9]  
 BV BND1      x[7,10] 
 BV BND1      x[7,11] 
 BV BND1      x[7,12] 
 BV BND1      x[7,13] 
 BV BND1      x[7,14] 
 BV BND1      x[7,15] 
 BV BND1      x[7,16] 
 BV BND1      x[7,17] 
 BV BND1      x[7,18] 
 BV BND1      x[7,19] 
 BV BND1      x[8,0]  
 BV BND1      x[8,1]  
 BV BND1      x[8,2]  
 BV BND1      x[8,3]  
 BV BND1      x[8,4]  
 BV BND1      x[8,5]  
 BV BND1      x[8,6]  
 BV BND1      x[8,7]  
 BV BND1      x[8,8]  
 BV BND1      x[8,9]  
 BV BND1      x[8,10] 
 BV BND1      x[8,11] 
 BV BND1      x[8,12] 
 BV BND1      x[8,13] 
 BV BND1      x[8,14] 
 BV BND1      x[8,15] 
 BV BND1      x[9,0]  
 BV BND1      x[9,1]  
 BV BND1      x[9,2]  
 BV BND1      x[9,3]  
 BV BND1      x[9,4]  
 BV BND1      x[9,5]  
 BV BND1      x[9,6]  
 BV BND1      x[9,7]  
 BV BND1      x[9,8]  
 BV BND1      x[9,9]  
 BV BND1      x[9,10] 
 BV BND1      x[9,11] 
 BV BND1      x[9,12] 
 BV BND1      x[9,13] 
 BV BND1      x[9,14] 
 BV BND1      x[10,0] 
 BV BND1      x[10,1] 
 BV BND1      x[10,2] 
 BV BND1      x[10,3] 
 BV BND1      x[10,4] 
 BV BND1      x[10,5] 
 BV BND1      x[10,6] 
 BV BND1      x[10,7] 
 BV BND1      x[10,8] 
 BV BND1      x[10,9] 
 BV BND1      x[10,10]
 BV BND1      x[10,11]
 BV BND1      x[11,0] 
 BV BND1      x[11,1] 
 BV BND1      x[11,2] 
 BV BND1      x[11,3] 
 BV BND1      x[11,4] 
 BV BND1      x[11,5] 
 BV BND1      x[11,6] 
 BV BND1      x[11,7] 
 BV BND1      x[11,8] 
 BV BND1      x[11,9] 
 BV BND1      x[11,10]
 BV BND1      x[11,11]
 BV BND1      x[11,12]
 BV BND1      x[11,13]
 BV BND1      x[11,14]
 BV BND1      x[11,15]
 BV BND1      x[12,0] 
 BV BND1      x[12,1] 
 BV BND1      x[12,2] 
 BV BND1      x[12,3] 
 BV BND1      x[12,4] 
 BV BND1      x[12,5] 
 BV BND1      x[12,6] 
 BV BND1      x[12,7] 
 BV BND1      x[12,8] 
 BV BND1      x[12,9] 
 BV BND1      x[12,10]
 BV BND1      x[12,11]
 BV BND1      x[12,12]
 BV BND1      x[12,13]
 BV BND1      x[12,14]
 BV BND1      x[12,15]
 BV BND1      x[13,0] 
 BV BND1      x[13,1] 
 BV BND1      x[13,2] 
 BV BND1      x[13,3] 
 BV BND1      x[13,4] 
 BV BND1      x[13,5] 
 BV BND1      x[13,6] 
 BV BND1      x[13,7] 
 BV BND1      x[13,8] 
 BV BND1      x[13,9] 
 BV BND1      x[13,10]
 BV BND1      x[13,11]
 BV BND1      x[13,12]
 BV BND1      x[13,13]
 BV BND1      x[13,14]
 BV BND1      x[13,15]
 BV BND1      x[13,16]
 BV BND1      x[13,17]
 BV BND1      x[13,18]
 BV BND1      x[13,19]
 BV BND1      x[14,0] 
 BV BND1      x[14,1] 
 BV BND1      x[14,2] 
 BV BND1      x[14,3] 
 BV BND1      x[14,4] 
 BV BND1      x[14,5] 
 BV BND1      x[14,6] 
 BV BND1      x[14,7] 
 BV BND1      x[14,8] 
 BV BND1      x[14,9] 
 BV BND1      x[14,10]
 BV BND1      x[14,11]
 BV BND1      x[14,12]
 BV BND1      x[14,13]
 BV BND1      x[14,14]
 BV BND1      x[14,15]
 BV BND1      x[14,16]
 BV BND1      x[14,17]
 BV BND1      x[14,18]
 BV BND1      x[15,0] 
 BV BND1      x[15,1] 
 BV BND1      x[15,2] 
 BV BND1      x[15,3] 
 BV BND1      x[15,4] 
 BV BND1      x[15,5] 
 BV BND1      x[15,6] 
 BV BND1      x[15,7] 
 BV BND1      x[15,8] 
 BV BND1      x[15,9] 
 BV BND1      x[15,10]
 BV BND1      x[15,11]
 BV BND1      x[15,12]
 BV BND1      x[15,13]
 BV BND1      x[15,14]
 BV BND1      x[15,15]
 BV BND1      x[15,16]
 BV BND1      x[15,17]
 BV BND1      x[15,18]
 BV BND1      x[15,19]
 BV BND1      x[16,0] 
 BV BND1      x[16,1] 
 BV BND1      x[16,2] 
 BV BND1      x[16,3] 
 BV BND1      x[16,4] 
 BV BND1      x[16,5] 
 BV BND1      x[16,6] 
 BV BND1      x[16,7] 
 BV BND1      x[16,8] 
 BV BND1      x[16,9] 
 BV BND1      x[16,10]
 BV BND1      x[16,11]
 BV BND1      x[17,16]
 BV BND1      x[18,0] 
 BV BND1      x[18,1] 
 BV BND1      x[18,2] 
 BV BND1      x[18,3] 
 BV BND1      x[18,4] 
 BV BND1      x[18,5] 
 BV BND1      x[18,6] 
 BV BND1      x[18,7] 
 BV BND1      x[18,8] 
 BV BND1      x[18,9] 
 BV BND1      x[18,10]
 BV BND1      x[18,11]
 BV BND1      x[18,12]
 BV BND1      x[18,13]
 BV BND1      x[18,14]
 BV BND1      x[18,15]
 BV BND1      x[19,0] 
 BV BND1      x[19,1] 
 BV BND1      x[19,2] 
 BV BND1      x[19,3] 
 BV BND1      x[19,4] 
 BV BND1      x[19,5] 
 BV BND1      x[19,6] 
 BV BND1      x[19,7] 
 BV BND1      x[19,8] 
 BV BND1      x[19,9] 
 BV BND1      x[19,10]
 BV BND1      x[19,11]
 BV BND1      x[19,12]
 BV BND1      x[19,13]
 BV BND1      x[19,14]
 BV BND1      x[19,15]
 BV BND1      x[19,16]
 BV BND1      x[19,17]
 BV BND1      x[19,18]
 BV BND1      x[19,19]
 BV BND1      x[20,0] 
 BV BND1      x[20,1] 
 BV BND1      x[20,2] 
 BV BND1      x[20,3] 
 BV BND1      x[20,4] 
 BV BND1      x[20,5] 
 BV BND1      x[20,6] 
 BV BND1      x[20,7] 
 BV BND1      x[20,8] 
 BV BND1      x[20,9] 
 BV BND1      x[20,10]
 BV BND1      x[20,11]
 BV BND1      x[20,12]
 BV BND1      x[20,13]
 BV BND1      x[20,14]
 BV BND1      x[20,15]
 BV BND1      x[21,0] 
 BV BND1      x[21,1] 
 BV BND1      x[21,2] 
 BV BND1      x[21,3] 
 BV BND1      x[21,4] 
 BV BND1      x[21,5] 
 BV BND1      x[21,6] 
 BV BND1      x[21,7] 
 BV BND1      x[21,8] 
 BV BND1      x[21,9] 
 BV BND1      x[21,10]
 BV BND1      x[21,11]
 BV BND1      x[21,12]
 BV BND1      x[21,13]
 BV BND1      x[21,14]
 BV BND1      x[21,15]
 BV BND1      x[21,16]
 BV BND1      x[21,17]
 BV BND1      x[21,18]
 BV BND1      x[21,19]
 BV BND1      x[22,0] 
 BV BND1      x[22,1] 
 BV BND1      x[22,2] 
 BV BND1      x[22,3] 
 BV BND1      x[22,4] 
 BV BND1      x[22,5] 
 BV BND1      x[22,6] 
 BV BND1      x[22,7] 
 BV BND1      x[22,8] 
 BV BND1      x[22,9] 
 BV BND1      x[22,10]
 BV BND1      x[22,11]
 BV BND1      x[22,12]
 BV BND1      x[22,13]
 BV BND1      x[22,14]
 BV BND1      x[22,15]
 BV BND1      x[22,16]
 BV BND1      x[22,17]
 BV BND1      x[22,18]
 BV BND1      x[22,19]
 BV BND1      x[23,0] 
 BV BND1      x[23,1] 
 BV BND1      x[23,2] 
 BV BND1      x[23,3] 
 BV BND1      x[23,4] 
 BV BND1      x[23,5] 
 BV BND1      x[23,6] 
 BV BND1      x[23,7] 
 BV BND1      x[23,8] 
 BV BND1      x[23,9] 
 BV BND1      x[23,10]
 BV BND1      x[23,11]
 BV BND1      x[23,12]
 BV BND1      x[23,13]
 BV BND1      x[23,14]
 BV BND1      x[23,15]
 BV BND1      x[24,0] 
 BV BND1      x[24,1] 
 BV BND1      x[24,2] 
 BV BND1      x[24,3] 
 BV BND1      x[24,4] 
 BV BND1      x[24,5] 
 BV BND1      x[24,6] 
 BV BND1      x[24,7] 
 BV BND1      x[24,8] 
 BV BND1      x[25,0] 
 BV BND1      x[25,1] 
 BV BND1      x[25,2] 
 BV BND1      x[25,3] 
 BV BND1      x[25,4] 
 BV BND1      x[25,5] 
 BV BND1      x[25,6] 
 BV BND1      x[25,7] 
 BV BND1      x[25,8] 
 BV BND1      x[25,9] 
 BV BND1      x[25,10]
 BV BND1      x[25,11]
 BV BND1      x[25,12]
 BV BND1      x[25,13]
 BV BND1      x[25,14]
 BV BND1      x[25,15]
 BV BND1      x[26,0] 
 BV BND1      x[26,1] 
 BV BND1      x[26,2] 
 BV BND1      x[26,3] 
 BV BND1      x[26,4] 
 BV BND1      x[26,5] 
 BV BND1      x[26,6] 
 BV BND1      x[26,7] 
 BV BND1      x[26,8] 
 BV BND1      x[26,9] 
 BV BND1      x[26,10]
 BV BND1      x[26,11]
 BV BND1      x[26,12]
 BV BND1      x[26,13]
 BV BND1      x[26,14]
 BV BND1      x[26,15]
 BV BND1      x[27,0] 
 BV BND1      x[27,1] 
 BV BND1      x[27,2] 
 BV BND1      x[27,3] 
 BV BND1      x[27,4] 
 BV BND1      x[27,5] 
 BV BND1      x[27,6] 
 BV BND1      x[27,7] 
 BV BND1      x[27,8] 
 BV BND1      x[27,9] 
 BV BND1      x[27,10]
 BV BND1      x[27,11]
 BV BND1      x[27,12]
 BV BND1      x[27,13]
 BV BND1      x[27,14]
 BV BND1      x[27,15]
 BV BND1      x[27,16]
 BV BND1      x[27,17]
 BV BND1      x[27,18]
 BV BND1      x[27,19]
 BV BND1      x[28,0] 
 BV BND1      x[28,1] 
 BV BND1      x[28,2] 
 BV BND1      x[28,3] 
 BV BND1      x[28,4] 
 BV BND1      x[28,5] 
 BV BND1      x[28,6] 
 BV BND1      x[28,7] 
 BV BND1      x[28,8] 
 BV BND1      x[28,9] 
 BV BND1      x[28,10]
 BV BND1      x[28,11]
 BV BND1      x[28,12]
 BV BND1      x[28,13]
 BV BND1      x[28,14]
 BV BND1      x[28,15]
 BV BND1      x[29,0] 
 BV BND1      x[29,1] 
 BV BND1      x[29,2] 
 BV BND1      x[29,3] 
 BV BND1      x[29,4] 
 BV BND1      x[29,5] 
 BV BND1      x[29,6] 
 BV BND1      x[29,7] 
 BV BND1      x[29,8] 
 BV BND1      x[29,9] 
 BV BND1      x[29,10]
 BV BND1      x[29,11]
 BV BND1      x[29,12]
 BV BND1      x[29,13]
 BV BND1      x[29,14]
 BV BND1      x[29,15]
 BV BND1      x[30,0] 
 BV BND1      x[30,1] 
 BV BND1      x[30,2] 
 BV BND1      x[30,3] 
 BV BND1      x[30,4] 
 BV BND1      x[30,5] 
 BV BND1      x[30,6] 
 BV BND1      x[30,7] 
 BV BND1      x[30,8] 
 BV BND1      x[30,9] 
 BV BND1      x[30,10]
 BV BND1      x[30,11]
 BV BND1      x[30,12]
 BV BND1      x[30,13]
 BV BND1      x[30,14]
 BV BND1      x[30,15]
 BV BND1      x[30,16]
 BV BND1      x[30,17]
 BV BND1      x[30,18]
 BV BND1      x[30,19]
 BV BND1      x[30,20]
 BV BND1      x[31,0] 
 BV BND1      x[31,1] 
 BV BND1      x[31,2] 
 BV BND1      x[31,3] 
 BV BND1      x[31,4] 
 BV BND1      x[31,5] 
 BV BND1      x[31,6] 
 BV BND1      x[31,7] 
 BV BND1      x[31,8] 
 BV BND1      x[31,9] 
 BV BND1      x[31,10]
 BV BND1      x[31,11]
 BV BND1      x[31,12]
 BV BND1      x[31,13]
 BV BND1      x[31,14]
 BV BND1      x[31,15]
 BV BND1      x[32,0] 
 BV BND1      x[32,1] 
 BV BND1      x[32,2] 
 BV BND1      x[32,3] 
 BV BND1      x[32,4] 
 BV BND1      x[32,5] 
 BV BND1      x[32,6] 
 BV BND1      x[32,7] 
 BV BND1      x[32,8] 
 BV BND1      x[32,9] 
 BV BND1      x[32,10]
 BV BND1      x[32,11]
 BV BND1      x[32,12]
 BV BND1      x[32,13]
 BV BND1      x[32,14]
 BV BND1      x[32,15]
 BV BND1      x[33,0] 
 BV BND1      x[33,1] 
 BV BND1      x[33,2] 
 BV BND1      x[33,3] 
 BV BND1      x[33,4] 
 BV BND1      x[33,5] 
 BV BND1      x[33,6] 
 BV BND1      x[33,7] 
 BV BND1      x[33,8] 
 BV BND1      x[33,9] 
 BV BND1      x[33,10]
 BV BND1      x[33,11]
 BV BND1      x[33,12]
 BV BND1      x[33,13]
 BV BND1      x[33,14]
 BV BND1      x[33,15]
 BV BND1      x[33,16]
 BV BND1      x[33,17]
 BV BND1      x[33,18]
 BV BND1      x[33,19]
 BV BND1      x[33,20]
 BV BND1      x[33,21]
 BV BND1      x[33,22]
 BV BND1      x[33,23]
 BV BND1      x[33,24]
 BV BND1      x[34,0] 
 BV BND1      x[34,1] 
 BV BND1      x[34,2] 
 BV BND1      x[34,3] 
 BV BND1      x[34,4] 
 BV BND1      x[34,5] 
 BV BND1      x[34,6] 
 BV BND1      x[34,7] 
 BV BND1      x[34,8] 
 BV BND1      x[34,9] 
 BV BND1      x[34,10]
 BV BND1      x[34,11]
 BV BND1      x[34,12]
 BV BND1      x[34,13]
 BV BND1      x[34,14]
 BV BND1      x[34,15]
 BV BND1      x[35,0] 
 BV BND1      x[35,1] 
 BV BND1      x[35,2] 
 BV BND1      x[35,3] 
 BV BND1      x[35,4] 
 BV BND1      x[35,5] 
 BV BND1      x[35,6] 
 BV BND1      x[35,7] 
 BV BND1      x[35,8] 
 BV BND1      x[35,9] 
 BV BND1      x[35,10]
 BV BND1      x[35,11]
 BV BND1      x[35,12]
 BV BND1      x[35,13]
 BV BND1      x[35,14]
 BV BND1      x[35,15]
 BV BND1      x[35,16]
 BV BND1      x[35,17]
 UP BND1      w[1,4]    3.9535535354550462e-02
 UP BND1      w[2,0]    3.9535535354550462e-02
 UP BND1      w[2,1]    3.9535535354550462e-02
 UP BND1      w[2,2]    3.9535535354550462e-02
 UP BND1      w[2,3]    3.9535535354550462e-02
 UP BND1      w[2,4]    3.9535535354550462e-02
 UP BND1      w[2,5]    3.9535535354550462e-02
 UP BND1      w[2,6]    3.9535535354550462e-02
 UP BND1      w[2,7]    3.9535535354550462e-02
 UP BND1      w[2,8]    3.9535535354550462e-02
 UP BND1      w[2,9]    3.9535535354550462e-02
 UP BND1      w[2,10]   3.9535535354550462e-02
 UP BND1      w[2,11]   3.9535535354550462e-02
 UP BND1      w[2,12]   3.9535535354550462e-02
 UP BND1      w[2,13]   3.9535535354550462e-02
 UP BND1      w[2,14]   3.9535535354550462e-02
 UP BND1      w[2,15]   3.9535535354550462e-02
 UP BND1      w[2,16]   3.9535535354550462e-02
 UP BND1      w[2,17]   3.9535535354550462e-02
 UP BND1      w[2,18]   3.9535535354550462e-02
 UP BND1      w[2,19]   3.9535535354550462e-02
 UP BND1      w[2,20]   3.9535535354550462e-02
 UP BND1      w[2,21]   3.9535535354550462e-02
 UP BND1      w[2,22]   3.9535535354550462e-02
 UP BND1      w[2,23]   3.9535535354550462e-02
 UP BND1      w[3,13]   3.9535535354550462e-02
 UP BND1      w[4,0]    3.9535535354550462e-02
 UP BND1      w[4,1]    3.9535535354550462e-02
 UP BND1      w[4,2]    3.9535535354550462e-02
 UP BND1      w[4,3]    3.9535535354550462e-02
 UP BND1      w[4,4]    3.9535535354550462e-02
 UP BND1      w[4,5]    3.9535535354550462e-02
 UP BND1      w[4,6]    3.9535535354550462e-02
 UP BND1      w[4,7]    3.9535535354550462e-02
 UP BND1      w[4,8]    3.9535535354550462e-02
 UP BND1      w[4,9]    3.9535535354550462e-02
 UP BND1      w[4,10]   3.9535535354550462e-02
 UP BND1      w[4,11]   3.9535535354550462e-02
 UP BND1      w[4,12]   3.9535535354550462e-02
 UP BND1      w[4,13]   3.9535535354550462e-02
 UP BND1      w[4,14]   3.9535535354550462e-02
 UP BND1      w[4,15]   3.9535535354550462e-02
 UP BND1      w[5,0]    3.9535535354550462e-02
 UP BND1      w[5,1]    3.9535535354550462e-02
 UP BND1      w[5,2]    3.9535535354550462e-02
 UP BND1      w[5,3]    3.9535535354550462e-02
 UP BND1      w[5,4]    3.9535535354550462e-02
 UP BND1      w[5,5]    3.9535535354550462e-02
 UP BND1      w[5,6]    3.9535535354550462e-02
 UP BND1      w[5,7]    3.9535535354550462e-02
 UP BND1      w[5,8]    3.9535535354550462e-02
 UP BND1      w[5,9]    3.9535535354550462e-02
 UP BND1      w[5,10]   3.9535535354550462e-02
 UP BND1      w[5,11]   3.9535535354550462e-02
 UP BND1      w[5,12]   3.9535535354550462e-02
 UP BND1      w[5,13]   3.9535535354550462e-02
 UP BND1      w[5,14]   3.9535535354550462e-02
 UP BND1      w[5,15]   3.9535535354550462e-02
 UP BND1      w[6,4]    3.9535535354550462e-02
 UP BND1      w[7,0]    3.9535535354550462e-02
 UP BND1      w[7,1]    3.9535535354550462e-02
 UP BND1      w[7,2]    3.9535535354550462e-02
 UP BND1      w[7,3]    3.9535535354550462e-02
 UP BND1      w[7,4]    3.9535535354550462e-02
 UP BND1      w[7,5]    3.9535535354550462e-02
 UP BND1      w[7,6]    3.9535535354550462e-02
 UP BND1      w[7,7]    3.9535535354550462e-02
 UP BND1      w[7,8]    3.9535535354550462e-02
 UP BND1      w[7,9]    3.9535535354550462e-02
 UP BND1      w[7,10]   3.9535535354550462e-02
 UP BND1      w[7,11]   3.9535535354550462e-02
 UP BND1      w[7,12]   3.9535535354550462e-02
 UP BND1      w[7,13]   3.9535535354550462e-02
 UP BND1      w[7,14]   3.9535535354550462e-02
 UP BND1      w[7,15]   3.9535535354550462e-02
 UP BND1      w[7,16]   3.9535535354550462e-02
 UP BND1      w[7,17]   3.9535535354550462e-02
 UP BND1      w[7,18]   3.9535535354550462e-02
 UP BND1      w[7,19]   3.9535535354550462e-02
 UP BND1      w[8,0]    3.9535535354550462e-02
 UP BND1      w[8,1]    3.9535535354550462e-02
 UP BND1      w[8,2]    3.9535535354550462e-02
 UP BND1      w[8,3]    3.9535535354550462e-02
 UP BND1      w[8,4]    3.9535535354550462e-02
 UP BND1      w[8,5]    3.9535535354550462e-02
 UP BND1      w[8,6]    3.9535535354550462e-02
 UP BND1      w[8,7]    3.9535535354550462e-02
 UP BND1      w[8,8]    3.9535535354550462e-02
 UP BND1      w[8,9]    3.9535535354550462e-02
 UP BND1      w[8,10]   3.9535535354550462e-02
 UP BND1      w[8,11]   3.9535535354550462e-02
 UP BND1      w[8,12]   3.9535535354550462e-02
 UP BND1      w[8,13]   3.9535535354550462e-02
 UP BND1      w[8,14]   3.9535535354550462e-02
 UP BND1      w[8,15]   3.9535535354550462e-02
 UP BND1      w[9,0]    3.9535535354550462e-02
 UP BND1      w[9,1]    3.9535535354550462e-02
 UP BND1      w[9,2]    3.9535535354550462e-02
 UP BND1      w[9,3]    3.9535535354550462e-02
 UP BND1      w[9,4]    3.9535535354550462e-02
 UP BND1      w[9,5]    3.9535535354550462e-02
 UP BND1      w[9,6]    3.9535535354550462e-02
 UP BND1      w[9,7]    3.9535535354550462e-02
 UP BND1      w[9,8]    3.9535535354550462e-02
 UP BND1      w[9,9]    3.9535535354550462e-02
 UP BND1      w[9,10]   3.9535535354550462e-02
 UP BND1      w[9,11]   3.9535535354550462e-02
 UP BND1      w[9,12]   3.9535535354550462e-02
 UP BND1      w[9,13]   3.9535535354550462e-02
 UP BND1      w[9,14]   3.9535535354550462e-02
 UP BND1      w[10,0]   3.9535535354550462e-02
 UP BND1      w[10,1]   3.9535535354550462e-02
 UP BND1      w[10,2]   3.9535535354550462e-02
 UP BND1      w[10,3]   3.9535535354550462e-02
 UP BND1      w[10,4]   3.9535535354550462e-02
 UP BND1      w[10,5]   3.9535535354550462e-02
 UP BND1      w[10,6]   3.9535535354550462e-02
 UP BND1      w[10,7]   3.9535535354550462e-02
 UP BND1      w[10,8]   3.9535535354550462e-02
 UP BND1      w[10,9]   3.9535535354550462e-02
 UP BND1      w[10,10]  3.9535535354550462e-02
 UP BND1      w[10,11]  3.9535535354550462e-02
 UP BND1      w[11,0]   3.9535535354550462e-02
 UP BND1      w[11,1]   3.9535535354550462e-02
 UP BND1      w[11,2]   3.9535535354550462e-02
 UP BND1      w[11,3]   3.9535535354550462e-02
 UP BND1      w[11,4]   3.9535535354550462e-02
 UP BND1      w[11,5]   3.9535535354550462e-02
 UP BND1      w[11,6]   3.9535535354550462e-02
 UP BND1      w[11,7]   3.9535535354550462e-02
 UP BND1      w[11,8]   3.9535535354550462e-02
 UP BND1      w[11,9]   3.9535535354550462e-02
 UP BND1      w[11,10]  3.9535535354550462e-02
 UP BND1      w[11,11]  3.9535535354550462e-02
 UP BND1      w[11,12]  3.9535535354550462e-02
 UP BND1      w[11,13]  3.9535535354550462e-02
 UP BND1      w[11,14]  3.9535535354550462e-02
 UP BND1      w[11,15]  3.9535535354550462e-02
 UP BND1      w[12,0]   3.9535535354550462e-02
 UP BND1      w[12,1]   3.9535535354550462e-02
 UP BND1      w[12,2]   3.9535535354550462e-02
 UP BND1      w[12,3]   3.9535535354550462e-02
 UP BND1      w[12,4]   3.9535535354550462e-02
 UP BND1      w[12,5]   3.9535535354550462e-02
 UP BND1      w[12,6]   3.9535535354550462e-02
 UP BND1      w[12,7]   3.9535535354550462e-02
 UP BND1      w[12,8]   3.9535535354550462e-02
 UP BND1      w[12,9]   3.9535535354550462e-02
 UP BND1      w[12,10]  3.9535535354550462e-02
 UP BND1      w[12,11]  3.9535535354550462e-02
 UP BND1      w[12,12]  3.9535535354550462e-02
 UP BND1      w[12,13]  3.9535535354550462e-02
 UP BND1      w[12,14]  3.9535535354550462e-02
 UP BND1      w[12,15]  3.9535535354550462e-02
 UP BND1      w[13,0]   3.9535535354550462e-02
 UP BND1      w[13,1]   3.9535535354550462e-02
 UP BND1      w[13,2]   3.9535535354550462e-02
 UP BND1      w[13,3]   3.9535535354550462e-02
 UP BND1      w[13,4]   3.9535535354550462e-02
 UP BND1      w[13,5]   3.9535535354550462e-02
 UP BND1      w[13,6]   3.9535535354550462e-02
 UP BND1      w[13,7]   3.9535535354550462e-02
 UP BND1      w[13,8]   3.9535535354550462e-02
 UP BND1      w[13,9]   3.9535535354550462e-02
 UP BND1      w[13,10]  3.9535535354550462e-02
 UP BND1      w[13,11]  3.9535535354550462e-02
 UP BND1      w[13,12]  3.9535535354550462e-02
 UP BND1      w[13,13]  3.9535535354550462e-02
 UP BND1      w[13,14]  3.9535535354550462e-02
 UP BND1      w[13,15]  3.9535535354550462e-02
 UP BND1      w[13,16]  3.9535535354550462e-02
 UP BND1      w[13,17]  3.9535535354550462e-02
 UP BND1      w[13,18]  3.9535535354550462e-02
 UP BND1      w[13,19]  3.9535535354550462e-02
 UP BND1      w[14,0]   3.9535535354550462e-02
 UP BND1      w[14,1]   3.9535535354550462e-02
 UP BND1      w[14,2]   3.9535535354550462e-02
 UP BND1      w[14,3]   3.9535535354550462e-02
 UP BND1      w[14,4]   3.9535535354550462e-02
 UP BND1      w[14,5]   3.9535535354550462e-02
 UP BND1      w[14,6]   3.9535535354550462e-02
 UP BND1      w[14,7]   3.9535535354550462e-02
 UP BND1      w[14,8]   3.9535535354550462e-02
 UP BND1      w[14,9]   3.9535535354550462e-02
 UP BND1      w[14,10]  3.9535535354550462e-02
 UP BND1      w[14,11]  3.9535535354550462e-02
 UP BND1      w[14,12]  3.9535535354550462e-02
 UP BND1      w[14,13]  3.9535535354550462e-02
 UP BND1      w[14,14]  3.9535535354550462e-02
 UP BND1      w[14,15]  3.9535535354550462e-02
 UP BND1      w[14,16]  3.9535535354550462e-02
 UP BND1      w[14,17]  3.9535535354550462e-02
 UP BND1      w[14,18]  3.9535535354550462e-02
 UP BND1      w[15,0]   3.9535535354550462e-02
 UP BND1      w[15,1]   3.9535535354550462e-02
 UP BND1      w[15,2]   3.9535535354550462e-02
 UP BND1      w[15,3]   3.9535535354550462e-02
 UP BND1      w[15,4]   3.9535535354550462e-02
 UP BND1      w[15,5]   3.9535535354550462e-02
 UP BND1      w[15,6]   3.9535535354550462e-02
 UP BND1      w[15,7]   3.9535535354550462e-02
 UP BND1      w[15,8]   3.9535535354550462e-02
 UP BND1      w[15,9]   3.9535535354550462e-02
 UP BND1      w[15,10]  3.9535535354550462e-02
 UP BND1      w[15,11]  3.9535535354550462e-02
 UP BND1      w[15,12]  3.9535535354550462e-02
 UP BND1      w[15,13]  3.9535535354550462e-02
 UP BND1      w[15,14]  3.9535535354550462e-02
 UP BND1      w[15,15]  3.9535535354550462e-02
 UP BND1      w[15,16]  3.9535535354550462e-02
 UP BND1      w[15,17]  3.9535535354550462e-02
 UP BND1      w[15,18]  3.9535535354550462e-02
 UP BND1      w[15,19]  3.9535535354550462e-02
 UP BND1      w[16,0]   3.9535535354550462e-02
 UP BND1      w[16,1]   3.9535535354550462e-02
 UP BND1      w[16,2]   3.9535535354550462e-02
 UP BND1      w[16,3]   3.9535535354550462e-02
 UP BND1      w[16,4]   3.9535535354550462e-02
 UP BND1      w[16,5]   3.9535535354550462e-02
 UP BND1      w[16,6]   3.9535535354550462e-02
 UP BND1      w[16,7]   3.9535535354550462e-02
 UP BND1      w[16,8]   3.9535535354550462e-02
 UP BND1      w[16,9]   3.9535535354550462e-02
 UP BND1      w[16,10]  3.9535535354550462e-02
 UP BND1      w[16,11]  3.9535535354550462e-02
 UP BND1      w[17,16]  3.9535535354550462e-02
 UP BND1      w[18,0]   3.9535535354550462e-02
 UP BND1      w[18,1]   3.9535535354550462e-02
 UP BND1      w[18,2]   3.9535535354550462e-02
 UP BND1      w[18,3]   3.9535535354550462e-02
 UP BND1      w[18,4]   3.9535535354550462e-02
 UP BND1      w[18,5]   3.9535535354550462e-02
 UP BND1      w[18,6]   3.9535535354550462e-02
 UP BND1      w[18,7]   3.9535535354550462e-02
 UP BND1      w[18,8]   3.9535535354550462e-02
 UP BND1      w[18,9]   3.9535535354550462e-02
 UP BND1      w[18,10]  3.9535535354550462e-02
 UP BND1      w[18,11]  3.9535535354550462e-02
 UP BND1      w[18,12]  3.9535535354550462e-02
 UP BND1      w[18,13]  3.9535535354550462e-02
 UP BND1      w[18,14]  3.9535535354550462e-02
 UP BND1      w[18,15]  3.9535535354550462e-02
 UP BND1      w[19,0]   3.9535535354550462e-02
 UP BND1      w[19,1]   3.9535535354550462e-02
 UP BND1      w[19,2]   3.9535535354550462e-02
 UP BND1      w[19,3]   3.9535535354550462e-02
 UP BND1      w[19,4]   3.9535535354550462e-02
 UP BND1      w[19,5]   3.9535535354550462e-02
 UP BND1      w[19,6]   3.9535535354550462e-02
 UP BND1      w[19,7]   3.9535535354550462e-02
 UP BND1      w[19,8]   3.9535535354550462e-02
 UP BND1      w[19,9]   3.9535535354550462e-02
 UP BND1      w[19,10]  3.9535535354550462e-02
 UP BND1      w[19,11]  3.9535535354550462e-02
 UP BND1      w[19,12]  3.9535535354550462e-02
 UP BND1      w[19,13]  3.9535535354550462e-02
 UP BND1      w[19,14]  3.9535535354550462e-02
 UP BND1      w[19,15]  3.9535535354550462e-02
 UP BND1      w[19,16]  3.9535535354550462e-02
 UP BND1      w[19,17]  3.9535535354550462e-02
 UP BND1      w[19,18]  3.9535535354550462e-02
 UP BND1      w[19,19]  3.9535535354550462e-02
 UP BND1      w[20,0]   3.9535535354550462e-02
 UP BND1      w[20,1]   3.9535535354550462e-02
 UP BND1      w[20,2]   3.9535535354550462e-02
 UP BND1      w[20,3]   3.9535535354550462e-02
 UP BND1      w[20,4]   3.9535535354550462e-02
 UP BND1      w[20,5]   3.9535535354550462e-02
 UP BND1      w[20,6]   3.9535535354550462e-02
 UP BND1      w[20,7]   3.9535535354550462e-02
 UP BND1      w[20,8]   3.9535535354550462e-02
 UP BND1      w[20,9]   3.9535535354550462e-02
 UP BND1      w[20,10]  3.9535535354550462e-02
 UP BND1      w[20,11]  3.9535535354550462e-02
 UP BND1      w[20,12]  3.9535535354550462e-02
 UP BND1      w[20,13]  3.9535535354550462e-02
 UP BND1      w[20,14]  3.9535535354550462e-02
 UP BND1      w[20,15]  3.9535535354550462e-02
 UP BND1      w[21,0]   3.9535535354550462e-02
 UP BND1      w[21,1]   3.9535535354550462e-02
 UP BND1      w[21,2]   3.9535535354550462e-02
 UP BND1      w[21,3]   3.9535535354550462e-02
 UP BND1      w[21,4]   3.9535535354550462e-02
 UP BND1      w[21,5]   3.9535535354550462e-02
 UP BND1      w[21,6]   3.9535535354550462e-02
 UP BND1      w[21,7]   3.9535535354550462e-02
 UP BND1      w[21,8]   3.9535535354550462e-02
 UP BND1      w[21,9]   3.9535535354550462e-02
 UP BND1      w[21,10]  3.9535535354550462e-02
 UP BND1      w[21,11]  3.9535535354550462e-02
 UP BND1      w[21,12]  3.9535535354550462e-02
 UP BND1      w[21,13]  3.9535535354550462e-02
 UP BND1      w[21,14]  3.9535535354550462e-02
 UP BND1      w[21,15]  3.9535535354550462e-02
 UP BND1      w[21,16]  3.9535535354550462e-02
 UP BND1      w[21,17]  3.9535535354550462e-02
 UP BND1      w[21,18]  3.9535535354550462e-02
 UP BND1      w[21,19]  3.9535535354550462e-02
 UP BND1      w[22,0]   3.9535535354550462e-02
 UP BND1      w[22,1]   3.9535535354550462e-02
 UP BND1      w[22,2]   3.9535535354550462e-02
 UP BND1      w[22,3]   3.9535535354550462e-02
 UP BND1      w[22,4]   3.9535535354550462e-02
 UP BND1      w[22,5]   3.9535535354550462e-02
 UP BND1      w[22,6]   3.9535535354550462e-02
 UP BND1      w[22,7]   3.9535535354550462e-02
 UP BND1      w[22,8]   3.9535535354550462e-02
 UP BND1      w[22,9]   3.9535535354550462e-02
 UP BND1      w[22,10]  3.9535535354550462e-02
 UP BND1      w[22,11]  3.9535535354550462e-02
 UP BND1      w[22,12]  3.9535535354550462e-02
 UP BND1      w[22,13]  3.9535535354550462e-02
 UP BND1      w[22,14]  3.9535535354550462e-02
 UP BND1      w[22,15]  3.9535535354550462e-02
 UP BND1      w[22,16]  3.9535535354550462e-02
 UP BND1      w[22,17]  3.9535535354550462e-02
 UP BND1      w[22,18]  3.9535535354550462e-02
 UP BND1      w[22,19]  3.9535535354550462e-02
 UP BND1      w[23,0]   3.9535535354550462e-02
 UP BND1      w[23,1]   3.9535535354550462e-02
 UP BND1      w[23,2]   3.9535535354550462e-02
 UP BND1      w[23,3]   3.9535535354550462e-02
 UP BND1      w[23,4]   3.9535535354550462e-02
 UP BND1      w[23,5]   3.9535535354550462e-02
 UP BND1      w[23,6]   3.9535535354550462e-02
 UP BND1      w[23,7]   3.9535535354550462e-02
 UP BND1      w[23,8]   3.9535535354550462e-02
 UP BND1      w[23,9]   3.9535535354550462e-02
 UP BND1      w[23,10]  3.9535535354550462e-02
 UP BND1      w[23,11]  3.9535535354550462e-02
 UP BND1      w[23,12]  3.9535535354550462e-02
 UP BND1      w[23,13]  3.9535535354550462e-02
 UP BND1      w[23,14]  3.9535535354550462e-02
 UP BND1      w[23,15]  3.9535535354550462e-02
 UP BND1      w[24,0]   3.9535535354550462e-02
 UP BND1      w[24,1]   3.9535535354550462e-02
 UP BND1      w[24,2]   3.9535535354550462e-02
 UP BND1      w[24,3]   3.9535535354550462e-02
 UP BND1      w[24,4]   3.9535535354550462e-02
 UP BND1      w[24,5]   3.9535535354550462e-02
 UP BND1      w[24,6]   3.9535535354550462e-02
 UP BND1      w[24,7]   3.9535535354550462e-02
 UP BND1      w[24,8]   3.9535535354550462e-02
 UP BND1      w[25,0]   3.9535535354550462e-02
 UP BND1      w[25,1]   3.9535535354550462e-02
 UP BND1      w[25,2]   3.9535535354550462e-02
 UP BND1      w[25,3]   3.9535535354550462e-02
 UP BND1      w[25,4]   3.9535535354550462e-02
 UP BND1      w[25,5]   3.9535535354550462e-02
 UP BND1      w[25,6]   3.9535535354550462e-02
 UP BND1      w[25,7]   3.9535535354550462e-02
 UP BND1      w[25,8]   3.9535535354550462e-02
 UP BND1      w[25,9]   3.9535535354550462e-02
 UP BND1      w[25,10]  3.9535535354550462e-02
 UP BND1      w[25,11]  3.9535535354550462e-02
 UP BND1      w[25,12]  3.9535535354550462e-02
 UP BND1      w[25,13]  3.9535535354550462e-02
 UP BND1      w[25,14]  3.9535535354550462e-02
 UP BND1      w[25,15]  3.9535535354550462e-02
 UP BND1      w[26,0]   3.9535535354550462e-02
 UP BND1      w[26,1]   3.9535535354550462e-02
 UP BND1      w[26,2]   3.9535535354550462e-02
 UP BND1      w[26,3]   3.9535535354550462e-02
 UP BND1      w[26,4]   3.9535535354550462e-02
 UP BND1      w[26,5]   3.9535535354550462e-02
 UP BND1      w[26,6]   3.9535535354550462e-02
 UP BND1      w[26,7]   3.9535535354550462e-02
 UP BND1      w[26,8]   3.9535535354550462e-02
 UP BND1      w[26,9]   3.9535535354550462e-02
 UP BND1      w[26,10]  3.9535535354550462e-02
 UP BND1      w[26,11]  3.9535535354550462e-02
 UP BND1      w[26,12]  3.9535535354550462e-02
 UP BND1      w[26,13]  3.9535535354550462e-02
 UP BND1      w[26,14]  3.9535535354550462e-02
 UP BND1      w[26,15]  3.9535535354550462e-02
 UP BND1      w[27,0]   3.9535535354550462e-02
 UP BND1      w[27,1]   3.9535535354550462e-02
 UP BND1      w[27,2]   3.9535535354550462e-02
 UP BND1      w[27,3]   3.9535535354550462e-02
 UP BND1      w[27,4]   3.9535535354550462e-02
 UP BND1      w[27,5]   3.9535535354550462e-02
 UP BND1      w[27,6]   3.9535535354550462e-02
 UP BND1      w[27,7]   3.9535535354550462e-02
 UP BND1      w[27,8]   3.9535535354550462e-02
 UP BND1      w[27,9]   3.9535535354550462e-02
 UP BND1      w[27,10]  3.9535535354550462e-02
 UP BND1      w[27,11]  3.9535535354550462e-02
 UP BND1      w[27,12]  3.9535535354550462e-02
 UP BND1      w[27,13]  3.9535535354550462e-02
 UP BND1      w[27,14]  3.9535535354550462e-02
 UP BND1      w[27,15]  3.9535535354550462e-02
 UP BND1      w[27,16]  3.9535535354550462e-02
 UP BND1      w[27,17]  3.9535535354550462e-02
 UP BND1      w[27,18]  3.9535535354550462e-02
 UP BND1      w[27,19]  3.9535535354550462e-02
 UP BND1      w[28,0]   3.9535535354550462e-02
 UP BND1      w[28,1]   3.9535535354550462e-02
 UP BND1      w[28,2]   3.9535535354550462e-02
 UP BND1      w[28,3]   3.9535535354550462e-02
 UP BND1      w[28,4]   3.9535535354550462e-02
 UP BND1      w[28,5]   3.9535535354550462e-02
 UP BND1      w[28,6]   3.9535535354550462e-02
 UP BND1      w[28,7]   3.9535535354550462e-02
 UP BND1      w[28,8]   3.9535535354550462e-02
 UP BND1      w[28,9]   3.9535535354550462e-02
 UP BND1      w[28,10]  3.9535535354550462e-02
 UP BND1      w[28,11]  3.9535535354550462e-02
 UP BND1      w[28,12]  3.9535535354550462e-02
 UP BND1      w[28,13]  3.9535535354550462e-02
 UP BND1      w[28,14]  3.9535535354550462e-02
 UP BND1      w[28,15]  3.9535535354550462e-02
 UP BND1      w[29,0]   3.9535535354550462e-02
 UP BND1      w[29,1]   3.9535535354550462e-02
 UP BND1      w[29,2]   3.9535535354550462e-02
 UP BND1      w[29,3]   3.9535535354550462e-02
 UP BND1      w[29,4]   3.9535535354550462e-02
 UP BND1      w[29,5]   3.9535535354550462e-02
 UP BND1      w[29,6]   3.9535535354550462e-02
 UP BND1      w[29,7]   3.9535535354550462e-02
 UP BND1      w[29,8]   3.9535535354550462e-02
 UP BND1      w[29,9]   3.9535535354550462e-02
 UP BND1      w[29,10]  3.9535535354550462e-02
 UP BND1      w[29,11]  3.9535535354550462e-02
 UP BND1      w[29,12]  3.9535535354550462e-02
 UP BND1      w[29,13]  3.9535535354550462e-02
 UP BND1      w[29,14]  3.9535535354550462e-02
 UP BND1      w[29,15]  3.9535535354550462e-02
 UP BND1      w[30,0]   3.9535535354550462e-02
 UP BND1      w[30,1]   3.9535535354550462e-02
 UP BND1      w[30,2]   3.9535535354550462e-02
 UP BND1      w[30,3]   3.9535535354550462e-02
 UP BND1      w[30,4]   3.9535535354550462e-02
 UP BND1      w[30,5]   3.9535535354550462e-02
 UP BND1      w[30,6]   3.9535535354550462e-02
 UP BND1      w[30,7]   3.9535535354550462e-02
 UP BND1      w[30,8]   3.9535535354550462e-02
 UP BND1      w[30,9]   3.9535535354550462e-02
 UP BND1      w[30,10]  3.9535535354550462e-02
 UP BND1      w[30,11]  3.9535535354550462e-02
 UP BND1      w[30,12]  3.9535535354550462e-02
 UP BND1      w[30,13]  3.9535535354550462e-02
 UP BND1      w[30,14]  3.9535535354550462e-02
 UP BND1      w[30,15]  3.9535535354550462e-02
 UP BND1      w[30,16]  3.9535535354550462e-02
 UP BND1      w[30,17]  3.9535535354550462e-02
 UP BND1      w[30,18]  3.9535535354550462e-02
 UP BND1      w[30,19]  3.9535535354550462e-02
 UP BND1      w[30,20]  3.9535535354550462e-02
 UP BND1      w[31,0]   3.9535535354550462e-02
 UP BND1      w[31,1]   3.9535535354550462e-02
 UP BND1      w[31,2]   3.9535535354550462e-02
 UP BND1      w[31,3]   3.9535535354550462e-02
 UP BND1      w[31,4]   3.9535535354550462e-02
 UP BND1      w[31,5]   3.9535535354550462e-02
 UP BND1      w[31,6]   3.9535535354550462e-02
 UP BND1      w[31,7]   3.9535535354550462e-02
 UP BND1      w[31,8]   3.9535535354550462e-02
 UP BND1      w[31,9]   3.9535535354550462e-02
 UP BND1      w[31,10]  3.9535535354550462e-02
 UP BND1      w[31,11]  3.9535535354550462e-02
 UP BND1      w[31,12]  3.9535535354550462e-02
 UP BND1      w[31,13]  3.9535535354550462e-02
 UP BND1      w[31,14]  3.9535535354550462e-02
 UP BND1      w[31,15]  3.9535535354550462e-02
 UP BND1      w[32,0]   3.9535535354550462e-02
 UP BND1      w[32,1]   3.9535535354550462e-02
 UP BND1      w[32,2]   3.9535535354550462e-02
 UP BND1      w[32,3]   3.9535535354550462e-02
 UP BND1      w[32,4]   3.9535535354550462e-02
 UP BND1      w[32,5]   3.9535535354550462e-02
 UP BND1      w[32,6]   3.9535535354550462e-02
 UP BND1      w[32,7]   3.9535535354550462e-02
 UP BND1      w[32,8]   3.9535535354550462e-02
 UP BND1      w[32,9]   3.9535535354550462e-02
 UP BND1      w[32,10]  3.9535535354550462e-02
 UP BND1      w[32,11]  3.9535535354550462e-02
 UP BND1      w[32,12]  3.9535535354550462e-02
 UP BND1      w[32,13]  3.9535535354550462e-02
 UP BND1      w[32,14]  3.9535535354550462e-02
 UP BND1      w[32,15]  3.9535535354550462e-02
 UP BND1      w[33,0]   3.9535535354550462e-02
 UP BND1      w[33,1]   3.9535535354550462e-02
 UP BND1      w[33,2]   3.9535535354550462e-02
 UP BND1      w[33,3]   3.9535535354550462e-02
 UP BND1      w[33,4]   3.9535535354550462e-02
 UP BND1      w[33,5]   3.9535535354550462e-02
 UP BND1      w[33,6]   3.9535535354550462e-02
 UP BND1      w[33,7]   3.9535535354550462e-02
 UP BND1      w[33,8]   3.9535535354550462e-02
 UP BND1      w[33,9]   3.9535535354550462e-02
 UP BND1      w[33,10]  3.9535535354550462e-02
 UP BND1      w[33,11]  3.9535535354550462e-02
 UP BND1      w[33,12]  3.9535535354550462e-02
 UP BND1      w[33,13]  3.9535535354550462e-02
 UP BND1      w[33,14]  3.9535535354550462e-02
 UP BND1      w[33,15]  3.9535535354550462e-02
 UP BND1      w[33,16]  3.9535535354550462e-02
 UP BND1      w[33,17]  3.9535535354550462e-02
 UP BND1      w[33,18]  3.9535535354550462e-02
 UP BND1      w[33,19]  3.9535535354550462e-02
 UP BND1      w[33,20]  3.9535535354550462e-02
 UP BND1      w[33,21]  3.9535535354550462e-02
 UP BND1      w[33,22]  3.9535535354550462e-02
 UP BND1      w[33,23]  3.9535535354550462e-02
 UP BND1      w[33,24]  3.9535535354550462e-02
 UP BND1      w[34,0]   3.9535535354550462e-02
 UP BND1      w[34,1]   3.9535535354550462e-02
 UP BND1      w[34,2]   3.9535535354550462e-02
 UP BND1      w[34,3]   3.9535535354550462e-02
 UP BND1      w[34,4]   3.9535535354550462e-02
 UP BND1      w[34,5]   3.9535535354550462e-02
 UP BND1      w[34,6]   3.9535535354550462e-02
 UP BND1      w[34,7]   3.9535535354550462e-02
 UP BND1      w[34,8]   3.9535535354550462e-02
 UP BND1      w[34,9]   3.9535535354550462e-02
 UP BND1      w[34,10]  3.9535535354550462e-02
 UP BND1      w[34,11]  3.9535535354550462e-02
 UP BND1      w[34,12]  3.9535535354550462e-02
 UP BND1      w[34,13]  3.9535535354550462e-02
 UP BND1      w[34,14]  3.9535535354550462e-02
 UP BND1      w[34,15]  3.9535535354550462e-02
 UP BND1      w[35,0]   3.9535535354550462e-02
 UP BND1      w[35,1]   3.9535535354550462e-02
 UP BND1      w[35,2]   3.9535535354550462e-02
 UP BND1      w[35,3]   3.9535535354550462e-02
 UP BND1      w[35,4]   3.9535535354550462e-02
 UP BND1      w[35,5]   3.9535535354550462e-02
 UP BND1      w[35,6]   3.9535535354550462e-02
 UP BND1      w[35,7]   3.9535535354550462e-02
 UP BND1      w[35,8]   3.9535535354550462e-02
 UP BND1      w[35,9]   3.9535535354550462e-02
 UP BND1      w[35,10]  3.9535535354550462e-02
 UP BND1      w[35,11]  3.9535535354550462e-02
 UP BND1      w[35,12]  3.9535535354550462e-02
 UP BND1      w[35,13]  3.9535535354550462e-02
 UP BND1      w[35,14]  3.9535535354550462e-02
 UP BND1      w[35,15]  3.9535535354550462e-02
 UP BND1      w[35,16]  3.9535535354550462e-02
 UP BND1      w[35,17]  3.9535535354550462e-02
 LO BND1      t         2.2258731252318614e-02
 UP BND1      t         3.9535535354550462e-02
 UP BND1      q         7.6745660472471666e-01
ENDATA
