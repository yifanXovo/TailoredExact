* Signature: 0xb7b85ffe014b6a9a
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 E  onehot_8_26
 E  normalized_mass_8_27
 E  normalized_ratio_8_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 E  onehot_6_47
 E  normalized_mass_6_48
 E  normalized_ratio_6_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 E  onehot_34_82
 E  normalized_mass_34_83
 E  normalized_ratio_34_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 E  onehot_9_107
 E  normalized_mass_9_108
 E  normalized_ratio_9_109
 G  product_lb_110
 L  product_ub_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 E  onehot_29_132
 E  normalized_mass_29_133
 E  normalized_ratio_29_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 G  product_lb_143
 L  product_ub_144
 G  product_lb_145
 L  product_ub_146
 G  product_lb_147
 L  product_ub_148
 E  onehot_10_149
 E  normalized_mass_10_150
 E  normalized_ratio_10_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 E  onehot_27_166
 E  normalized_mass_27_167
 E  normalized_ratio_27_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 E  onehot_11_191
 E  normalized_mass_11_192
 E  normalized_ratio_11_193
 G  stock_lb_194
 L  stock_ub_195
 L  parent_nonstrict_scope_196
 G  block_pair_pos_197
 G  block_pair_neg_198
 G  block_pair_pos_199
 G  block_pair_neg_200
 G  block_pair_pos_201
 G  block_pair_neg_202
 G  block_pair_pos_203
 G  block_pair_neg_204
 G  block_pair_pos_205
 G  block_pair_neg_206
 G  block_pair_pos_207
 G  block_pair_neg_208
 G  block_pair_pos_209
 G  block_pair_neg_210
 G  block_pair_pos_211
 G  block_pair_neg_212
 G  block_pair_pos_213
 G  block_pair_neg_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 E  normalization_253
 G  full_original_Gini_254
 E  unique_nonzero_owner_255
 E  unique_nonzero_owner_256
 E  unique_nonzero_owner_257
 E  unique_nonzero_owner_258
 E  unique_nonzero_owner_259
 E  unique_nonzero_owner_260
 E  unique_nonzero_owner_261
 E  unique_nonzero_owner_262
 E  unique_nonzero_owner_263
 E  unique_nonzero_owner_264
 E  unique_nonzero_owner_265
 E  unique_nonzero_owner_266
 E  unique_nonzero_owner_267
 E  unique_nonzero_owner_268
 E  unique_nonzero_owner_269
 E  unique_nonzero_owner_270
 E  unique_nonzero_owner_271
 E  unique_nonzero_owner_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 L  arc_capacity_332
 L  arc_capacity_333
 L  arc_capacity_334
 L  arc_capacity_335
 L  arc_capacity_336
 L  arc_capacity_337
 L  arc_capacity_338
 L  arc_capacity_339
 L  arc_capacity_340
 L  arc_capacity_341
 L  arc_capacity_342
 L  arc_capacity_343
 L  arc_capacity_344
 L  arc_capacity_345
 L  arc_capacity_346
 L  arc_capacity_347
 L  arc_capacity_348
 G  connected_order_arc_349
 L  arc_capacity_350
 G  connected_order_arc_351
 L  arc_capacity_352
 G  connected_order_arc_353
 L  arc_capacity_354
 G  connected_order_arc_355
 L  arc_capacity_356
 G  connected_order_arc_357
 L  arc_capacity_358
 G  connected_order_arc_359
 L  arc_capacity_360
 G  connected_order_arc_361
 L  arc_capacity_362
 G  connected_order_arc_363
 L  arc_capacity_364
 G  connected_order_arc_365
 L  arc_capacity_366
 G  connected_order_arc_367
 L  arc_capacity_368
 G  connected_order_arc_369
 L  arc_capacity_370
 G  connected_order_arc_371
 L  arc_capacity_372
 G  connected_order_arc_373
 L  arc_capacity_374
 L  arc_capacity_375
 G  connected_order_arc_376
 L  arc_capacity_377
 G  connected_order_arc_378
 L  arc_capacity_379
 G  connected_order_arc_380
 L  arc_capacity_381
 G  connected_order_arc_382
 L  arc_capacity_383
 G  connected_order_arc_384
 L  arc_capacity_385
 G  connected_order_arc_386
 L  arc_capacity_387
 G  connected_order_arc_388
 L  arc_capacity_389
 G  connected_order_arc_390
 L  arc_capacity_391
 G  connected_order_arc_392
 L  arc_capacity_393
 G  connected_order_arc_394
 L  arc_capacity_395
 G  connected_order_arc_396
 L  arc_capacity_397
 G  connected_order_arc_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 L  arc_capacity_402
 G  connected_order_arc_403
 L  arc_capacity_404
 G  connected_order_arc_405
 L  arc_capacity_406
 G  connected_order_arc_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 G  connected_order_arc_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 G  connected_order_arc_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 G  connected_order_arc_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 E  depot_departure_or_bypass_725
 E  depot_return_or_bypass_726
 E  out_degree_727
 E  in_degree_728
 G  order_active_lb_729
 L  order_active_ub_730
 E  segment_load_conservation_731
 G  segment_prefix_lb_732
 L  segment_prefix_ub_733
 E  out_degree_734
 E  in_degree_735
 G  order_active_lb_736
 L  order_active_ub_737
 E  segment_load_conservation_738
 G  segment_prefix_lb_739
 L  segment_prefix_ub_740
 E  out_degree_741
 E  in_degree_742
 G  order_active_lb_743
 L  order_active_ub_744
 E  segment_load_conservation_745
 G  segment_prefix_lb_746
 L  segment_prefix_ub_747
 E  out_degree_748
 E  in_degree_749
 G  order_active_lb_750
 L  order_active_ub_751
 E  segment_load_conservation_752
 G  segment_prefix_lb_753
 L  segment_prefix_ub_754
 E  out_degree_755
 E  in_degree_756
 G  order_active_lb_757
 L  order_active_ub_758
 E  segment_load_conservation_759
 G  segment_prefix_lb_760
 L  segment_prefix_ub_761
 E  out_degree_762
 E  in_degree_763
 G  order_active_lb_764
 L  order_active_ub_765
 E  segment_load_conservation_766
 G  segment_prefix_lb_767
 L  segment_prefix_ub_768
 E  out_degree_769
 E  in_degree_770
 G  order_active_lb_771
 L  order_active_ub_772
 E  service_visit_def_773
 E  free_load_conservation_774
 E  out_degree_775
 E  in_degree_776
 G  order_active_lb_777
 L  order_active_ub_778
 E  service_visit_def_779
 E  free_load_conservation_780
 E  out_degree_781
 E  in_degree_782
 G  order_active_lb_783
 L  order_active_ub_784
 E  service_visit_def_785
 E  free_load_conservation_786
 E  out_degree_787
 E  in_degree_788
 G  order_active_lb_789
 L  order_active_ub_790
 E  service_visit_def_791
 E  free_load_conservation_792
 E  out_degree_793
 E  in_degree_794
 G  order_active_lb_795
 L  order_active_ub_796
 E  service_visit_def_797
 E  free_load_conservation_798
 E  out_degree_799
 E  in_degree_800
 G  order_active_lb_801
 L  order_active_ub_802
 E  service_visit_def_803
 E  free_load_conservation_804
 E  out_degree_805
 E  in_degree_806
 G  order_active_lb_807
 L  order_active_ub_808
 E  service_visit_def_809
 E  free_load_conservation_810
 E  out_degree_811
 E  in_degree_812
 G  order_active_lb_813
 L  order_active_ub_814
 E  service_visit_def_815
 E  free_load_conservation_816
 G  fixed_segment_relative_order_817
 G  fixed_segment_relative_order_818
 G  fixed_segment_relative_order_819
 G  fixed_segment_relative_order_820
 G  fixed_segment_relative_order_821
 L  original_T_including_depot_unload_822
 L  arc_capacity_823
 L  arc_capacity_824
 L  arc_capacity_825
 L  arc_capacity_826
 L  arc_capacity_827
 L  arc_capacity_828
 L  arc_capacity_829
 L  arc_capacity_830
 L  arc_capacity_831
 L  arc_capacity_832
 L  arc_capacity_833
 L  arc_capacity_834
 L  arc_capacity_835
 L  arc_capacity_836
 L  arc_capacity_837
 G  connected_order_arc_838
 L  arc_capacity_839
 G  connected_order_arc_840
 L  arc_capacity_841
 G  connected_order_arc_842
 L  arc_capacity_843
 G  connected_order_arc_844
 L  arc_capacity_845
 G  connected_order_arc_846
 L  arc_capacity_847
 G  connected_order_arc_848
 L  arc_capacity_849
 G  connected_order_arc_850
 L  arc_capacity_851
 G  connected_order_arc_852
 L  arc_capacity_853
 G  connected_order_arc_854
 L  arc_capacity_855
 G  connected_order_arc_856
 L  arc_capacity_857
 G  connected_order_arc_858
 L  arc_capacity_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 G  connected_order_arc_863
 L  arc_capacity_864
 G  connected_order_arc_865
 L  arc_capacity_866
 G  connected_order_arc_867
 L  arc_capacity_868
 G  connected_order_arc_869
 L  arc_capacity_870
 G  connected_order_arc_871
 L  arc_capacity_872
 G  connected_order_arc_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 G  connected_order_arc_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 E  depot_departure_or_bypass_1112
 E  depot_return_or_bypass_1113
 E  out_degree_1114
 E  in_degree_1115
 G  order_active_lb_1116
 L  order_active_ub_1117
 E  segment_load_conservation_1118
 G  segment_prefix_lb_1119
 L  segment_prefix_ub_1120
 E  out_degree_1121
 E  in_degree_1122
 G  order_active_lb_1123
 L  order_active_ub_1124
 E  segment_load_conservation_1125
 G  segment_prefix_lb_1126
 L  segment_prefix_ub_1127
 E  out_degree_1128
 E  in_degree_1129
 G  order_active_lb_1130
 L  order_active_ub_1131
 E  segment_load_conservation_1132
 G  segment_prefix_lb_1133
 L  segment_prefix_ub_1134
 E  out_degree_1135
 E  in_degree_1136
 G  order_active_lb_1137
 L  order_active_ub_1138
 E  segment_load_conservation_1139
 G  segment_prefix_lb_1140
 L  segment_prefix_ub_1141
 E  out_degree_1142
 E  in_degree_1143
 G  order_active_lb_1144
 L  order_active_ub_1145
 E  service_visit_def_1146
 E  free_load_conservation_1147
 E  out_degree_1148
 E  in_degree_1149
 G  order_active_lb_1150
 L  order_active_ub_1151
 E  service_visit_def_1152
 E  free_load_conservation_1153
 E  out_degree_1154
 E  in_degree_1155
 G  order_active_lb_1156
 L  order_active_ub_1157
 E  service_visit_def_1158
 E  free_load_conservation_1159
 E  out_degree_1160
 E  in_degree_1161
 G  order_active_lb_1162
 L  order_active_ub_1163
 E  service_visit_def_1164
 E  free_load_conservation_1165
 E  out_degree_1166
 E  in_degree_1167
 G  order_active_lb_1168
 L  order_active_ub_1169
 E  service_visit_def_1170
 E  free_load_conservation_1171
 E  out_degree_1172
 E  in_degree_1173
 G  order_active_lb_1174
 L  order_active_ub_1175
 E  service_visit_def_1176
 E  free_load_conservation_1177
 E  out_degree_1178
 E  in_degree_1179
 G  order_active_lb_1180
 L  order_active_ub_1181
 E  service_visit_def_1182
 E  free_load_conservation_1183
 E  out_degree_1184
 E  in_degree_1185
 G  order_active_lb_1186
 L  order_active_ub_1187
 E  service_visit_def_1188
 E  free_load_conservation_1189
 G  fixed_segment_relative_order_1190
 G  fixed_segment_relative_order_1191
 G  fixed_segment_relative_order_1192
 L  original_T_including_depot_unload_1193
 L  arc_capacity_1194
 L  arc_capacity_1195
 L  arc_capacity_1196
 L  arc_capacity_1197
 L  arc_capacity_1198
 L  arc_capacity_1199
 L  arc_capacity_1200
 L  arc_capacity_1201
 L  arc_capacity_1202
 L  arc_capacity_1203
 L  arc_capacity_1204
 L  arc_capacity_1205
 L  arc_capacity_1206
 L  arc_capacity_1207
 G  connected_order_arc_1208
 L  arc_capacity_1209
 G  connected_order_arc_1210
 L  arc_capacity_1211
 G  connected_order_arc_1212
 L  arc_capacity_1213
 G  connected_order_arc_1214
 L  arc_capacity_1215
 G  connected_order_arc_1216
 L  arc_capacity_1217
 G  connected_order_arc_1218
 L  arc_capacity_1219
 G  connected_order_arc_1220
 L  arc_capacity_1221
 G  connected_order_arc_1222
 L  arc_capacity_1223
 G  connected_order_arc_1224
 L  arc_capacity_1225
 G  connected_order_arc_1226
 L  arc_capacity_1227
 L  arc_capacity_1228
 G  connected_order_arc_1229
 L  arc_capacity_1230
 G  connected_order_arc_1231
 L  arc_capacity_1232
 G  connected_order_arc_1233
 L  arc_capacity_1234
 G  connected_order_arc_1235
 L  arc_capacity_1236
 G  connected_order_arc_1237
 L  arc_capacity_1238
 G  connected_order_arc_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 G  connected_order_arc_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 L  arc_capacity_1249
 G  connected_order_arc_1250
 L  arc_capacity_1251
 G  connected_order_arc_1252
 L  arc_capacity_1253
 G  connected_order_arc_1254
 L  arc_capacity_1255
 G  connected_order_arc_1256
 L  arc_capacity_1257
 G  connected_order_arc_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 L  arc_capacity_1270
 G  connected_order_arc_1271
 L  arc_capacity_1272
 G  connected_order_arc_1273
 L  arc_capacity_1274
 G  connected_order_arc_1275
 L  arc_capacity_1276
 G  connected_order_arc_1277
 L  arc_capacity_1278
 G  connected_order_arc_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 G  connected_order_arc_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 L  arc_capacity_1291
 G  connected_order_arc_1292
 L  arc_capacity_1293
 G  connected_order_arc_1294
 L  arc_capacity_1295
 G  connected_order_arc_1296
 L  arc_capacity_1297
 G  connected_order_arc_1298
 L  arc_capacity_1299
 G  connected_order_arc_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 L  arc_capacity_1395
 L  arc_capacity_1396
 G  connected_order_arc_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 G  connected_order_arc_1415
 L  arc_capacity_1416
 L  arc_capacity_1417
 G  connected_order_arc_1418
 L  arc_capacity_1419
 G  connected_order_arc_1420
 L  arc_capacity_1421
 G  connected_order_arc_1422
 L  arc_capacity_1423
 G  connected_order_arc_1424
 L  arc_capacity_1425
 G  connected_order_arc_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 G  connected_order_arc_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 G  connected_order_arc_1436
 E  depot_departure_or_bypass_1437
 E  depot_return_or_bypass_1438
 E  out_degree_1439
 E  in_degree_1440
 G  order_active_lb_1441
 L  order_active_ub_1442
 E  segment_load_conservation_1443
 G  segment_prefix_lb_1444
 L  segment_prefix_ub_1445
 E  out_degree_1446
 E  in_degree_1447
 G  order_active_lb_1448
 L  order_active_ub_1449
 E  segment_load_conservation_1450
 G  segment_prefix_lb_1451
 L  segment_prefix_ub_1452
 E  out_degree_1453
 E  in_degree_1454
 G  order_active_lb_1455
 L  order_active_ub_1456
 E  segment_load_conservation_1457
 G  segment_prefix_lb_1458
 L  segment_prefix_ub_1459
 E  out_degree_1460
 E  in_degree_1461
 G  order_active_lb_1462
 L  order_active_ub_1463
 E  service_visit_def_1464
 E  free_load_conservation_1465
 E  out_degree_1466
 E  in_degree_1467
 G  order_active_lb_1468
 L  order_active_ub_1469
 E  service_visit_def_1470
 E  free_load_conservation_1471
 E  out_degree_1472
 E  in_degree_1473
 G  order_active_lb_1474
 L  order_active_ub_1475
 E  service_visit_def_1476
 E  free_load_conservation_1477
 E  out_degree_1478
 E  in_degree_1479
 G  order_active_lb_1480
 L  order_active_ub_1481
 E  service_visit_def_1482
 E  free_load_conservation_1483
 E  out_degree_1484
 E  in_degree_1485
 G  order_active_lb_1486
 L  order_active_ub_1487
 E  service_visit_def_1488
 E  free_load_conservation_1489
 E  out_degree_1490
 E  in_degree_1491
 G  order_active_lb_1492
 L  order_active_ub_1493
 E  service_visit_def_1494
 E  free_load_conservation_1495
 E  out_degree_1496
 E  in_degree_1497
 G  order_active_lb_1498
 L  order_active_ub_1499
 E  service_visit_def_1500
 E  free_load_conservation_1501
 E  out_degree_1502
 E  in_degree_1503
 G  order_active_lb_1504
 L  order_active_ub_1505
 E  service_visit_def_1506
 E  free_load_conservation_1507
 G  fixed_segment_relative_order_1508
 G  fixed_segment_relative_order_1509
 L  original_T_including_depot_unload_1510
COLUMNS
    t         normalized_mass_8_27  -1
    t         normalized_mass_6_48  -1
    t         normalized_mass_34_83  -1
    t         normalized_mass_9_108  -1
    t         normalized_mass_29_133  -1
    t         normalized_mass_10_150  -1
    t         normalized_mass_27_167  -1
    t         normalized_mass_11_192  -1
    t         normalization_253  2.2734523809523811e+01
    t         full_original_Gini_254  -8.7492857142857190e+01
    q         OBJ       1
    q         parent_nonstrict_scope_196  1
    q         full_original_Gini_254  35
    MARKER    'MARKER'                 'INTORG'
    x_8_0     OBJ       1.6756644912833352e-02
    x_8_0     product_lb_0  -2.5900345337911936e-02
    x_8_0     product_ub_1  -4.3985966382198260e-02
    x_8_0     onehot_8_26  1
    x_8_0     parent_nonstrict_scope_196  0.0335132898256667
    x_8_0     unique_nonzero_owner_255  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_0     product_lb_0  1
    w_8_0     product_ub_1  1
    w_8_0     normalized_mass_8_27  1
    w_8_0     full_original_Gini_254  -2.2734523809523811e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_1     OBJ       1.1171096608555569e-02
    x_8_1     product_lb_2  -2.5900345337911936e-02
    x_8_1     product_ub_3  -4.3985966382198260e-02
    x_8_1     onehot_8_26  1
    x_8_1     stock_lb_194  1
    x_8_1     stock_ub_195  1
    x_8_1     parent_nonstrict_scope_196  2.7927741521388921e-02
    x_8_1     unique_nonzero_owner_256  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_1     product_lb_2  1
    w_8_1     product_ub_3  1
    w_8_1     normalized_mass_8_27  1
    w_8_1     normalized_ratio_8_28  -1.6666666666666666e-01
    w_8_1     full_original_Gini_254  -1.8567857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_2     OBJ       5.5855483042777862e-03
    x_8_2     product_lb_4  -2.5900345337911936e-02
    x_8_2     product_ub_5  -4.3985966382198260e-02
    x_8_2     onehot_8_26  1
    x_8_2     stock_lb_194  2
    x_8_2     stock_ub_195  2
    x_8_2     parent_nonstrict_scope_196  2.2342193217111138e-02
    x_8_2     unique_nonzero_owner_257  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_2     product_lb_4  1
    w_8_2     product_ub_5  1
    w_8_2     normalized_mass_8_27  1
    w_8_2     normalized_ratio_8_28  -3.3333333333333331e-01
    w_8_2     full_original_Gini_254  -1.4401190476190473e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_3     product_lb_6  -2.5900345337911936e-02
    x_8_3     product_ub_7  -4.3985966382198260e-02
    x_8_3     onehot_8_26  1
    x_8_3     stock_lb_194  3
    x_8_3     stock_ub_195  3
    x_8_3     parent_nonstrict_scope_196  1.6756644912833352e-02
    x_8_3     unique_nonzero_owner_258  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_3     product_lb_6  1
    w_8_3     product_ub_7  1
    w_8_3     normalized_mass_8_27  1
    w_8_3     normalized_ratio_8_28  -0.5
    w_8_3     full_original_Gini_254  -1.0567857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_4     OBJ       -5.5855483042777827e-03
    x_8_4     product_lb_8  -2.5900345337911936e-02
    x_8_4     product_ub_9  -4.3985966382198260e-02
    x_8_4     onehot_8_26  1
    x_8_4     stock_lb_194  4
    x_8_4     stock_ub_195  4
    x_8_4     parent_nonstrict_scope_196  1.1171096608555569e-02
    x_8_4     unique_nonzero_owner_259  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_4     product_lb_8  1
    w_8_4     product_ub_9  1
    w_8_4     normalized_mass_8_27  1
    w_8_4     normalized_ratio_8_28  -6.6666666666666663e-01
    w_8_4     full_original_Gini_254  -6.7345238095238091e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_5     OBJ       -1.1171096608555565e-02
    x_8_5     product_lb_10  -2.5900345337911936e-02
    x_8_5     product_ub_11  -4.3985966382198260e-02
    x_8_5     onehot_8_26  1
    x_8_5     stock_lb_194  5
    x_8_5     stock_ub_195  5
    x_8_5     parent_nonstrict_scope_196  5.5855483042777862e-03
    x_8_5     unique_nonzero_owner_260  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_5     product_lb_10  1
    w_8_5     product_ub_11  1
    w_8_5     normalized_mass_8_27  1
    w_8_5     normalized_ratio_8_28  -8.3333333333333326e-01
    w_8_5     full_original_Gini_254  -4.3726190476190476e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_6     OBJ       -1.6756644912833352e-02
    x_8_6     product_lb_12  -2.5900345337911936e-02
    x_8_6     product_ub_13  -4.3985966382198260e-02
    x_8_6     onehot_8_26  1
    x_8_6     stock_lb_194  6
    x_8_6     stock_ub_195  6
    x_8_6     unique_nonzero_owner_261  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_6     product_lb_12  1
    w_8_6     product_ub_13  1
    w_8_6     normalized_mass_8_27  1
    w_8_6     normalized_ratio_8_28  -1
    w_8_6     full_original_Gini_254  -5.2654761904761909e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_7     OBJ       -1.1171096608555572e-02
    x_8_7     product_lb_14  -2.5900345337911936e-02
    x_8_7     product_ub_15  -4.3985966382198260e-02
    x_8_7     onehot_8_26  1
    x_8_7     stock_lb_194  7
    x_8_7     stock_ub_195  7
    x_8_7     parent_nonstrict_scope_196  5.5855483042777793e-03
    x_8_7     unique_nonzero_owner_262  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_7     product_lb_14  1
    w_8_7     product_ub_15  1
    w_8_7     normalized_mass_8_27  1
    w_8_7     normalized_ratio_8_28  -1.1666666666666665e+00
    w_8_7     full_original_Gini_254  -9.4321428571428516e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_8     OBJ       -5.5855483042777862e-03
    x_8_8     product_lb_16  -2.5900345337911936e-02
    x_8_8     product_ub_17  -4.3985966382198260e-02
    x_8_8     onehot_8_26  1
    x_8_8     stock_lb_194  8
    x_8_8     stock_ub_195  8
    x_8_8     parent_nonstrict_scope_196  1.1171096608555565e-02
    x_8_8     unique_nonzero_owner_263  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_8     product_lb_16  1
    w_8_8     product_ub_17  1
    w_8_8     normalized_mass_8_27  1
    w_8_8     normalized_ratio_8_28  -1.3333333333333333e+00
    w_8_8     full_original_Gini_254  -1.3598809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_9     product_lb_18  -2.5900345337911936e-02
    x_8_9     product_ub_19  -4.3985966382198260e-02
    x_8_9     onehot_8_26  1
    x_8_9     stock_lb_194  9
    x_8_9     stock_ub_195  9
    x_8_9     parent_nonstrict_scope_196  1.6756644912833352e-02
    MARKER    'MARKER'                 'INTEND'
    w_8_9     product_lb_18  1
    w_8_9     product_ub_19  1
    w_8_9     normalized_mass_8_27  1
    w_8_9     normalized_ratio_8_28  -1.5
    w_8_9     full_original_Gini_254  -1.7765476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_10    OBJ       5.5855483042777793e-03
    x_8_10    product_lb_20  -2.5900345337911936e-02
    x_8_10    product_ub_21  -4.3985966382198260e-02
    x_8_10    onehot_8_26  1
    x_8_10    stock_lb_194  10
    x_8_10    stock_ub_195  10
    x_8_10    parent_nonstrict_scope_196  2.2342193217111131e-02
    x_8_10    unique_nonzero_owner_264  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_10    product_lb_20  1
    w_8_10    product_ub_21  1
    w_8_10    normalized_mass_8_27  1
    w_8_10    normalized_ratio_8_28  -1.6666666666666665e+00
    w_8_10    full_original_Gini_254  -2.2265476190476186e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_11    OBJ       1.1171096608555565e-02
    x_8_11    product_lb_22  -2.5900345337911936e-02
    x_8_11    product_ub_23  -4.3985966382198260e-02
    x_8_11    onehot_8_26  1
    x_8_11    stock_lb_194  11
    x_8_11    stock_ub_195  11
    x_8_11    parent_nonstrict_scope_196  2.7927741521388917e-02
    x_8_11    unique_nonzero_owner_265  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_11    product_lb_22  1
    w_8_11    product_ub_23  1
    w_8_11    normalized_mass_8_27  1
    w_8_11    normalized_ratio_8_28  -1.8333333333333333e+00
    w_8_11    full_original_Gini_254  -2.6765476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_12    OBJ       1.6756644912833352e-02
    x_8_12    product_lb_24  -2.5900345337911936e-02
    x_8_12    product_ub_25  -4.3985966382198260e-02
    x_8_12    onehot_8_26  1
    x_8_12    stock_lb_194  12
    x_8_12    stock_ub_195  12
    x_8_12    parent_nonstrict_scope_196  0.0335132898256667
    x_8_12    unique_nonzero_owner_266  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_12    product_lb_24  1
    w_8_12    product_ub_25  1
    w_8_12    normalized_mass_8_27  1
    w_8_12    normalized_ratio_8_28  -2
    w_8_12    full_original_Gini_254  -3.1265476190476189e+01
    rho_8     normalized_ratio_8_28  1
    rho_8     block_pair_pos_209  -1
    rho_8     block_pair_neg_210  1
    rho_8     block_pair_pos_211  -1
    rho_8     block_pair_neg_212  1
    rho_8     block_pair_pos_213  -1
    rho_8     block_pair_neg_214  1
    rho_8     block_pair_pos_215  -1
    rho_8     block_pair_neg_216  1
    rho_8     block_pair_pos_217  -1
    rho_8     block_pair_neg_218  1
    rho_8     block_pair_pos_219  -1
    rho_8     block_pair_neg_220  1
    rho_8     block_pair_pos_221  -1
    rho_8     block_pair_neg_222  1
    rho_8     normalization_253  1
    MARKER    'MARKER'                 'INTORG'
    x_6_0     OBJ       7.4474103065332977e-03
    x_6_0     product_lb_29  -2.5900345337911936e-02
    x_6_0     product_ub_30  -4.3985966382198260e-02
    x_6_0     onehot_6_47  1
    x_6_0     parent_nonstrict_scope_196  1.4894820613066595e-02
    x_6_0     unique_nonzero_owner_267  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_0     product_lb_29  1
    w_6_0     product_ub_30  1
    w_6_0     normalized_mass_6_48  1
    w_6_0     full_original_Gini_254  -2.2734523809523811e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_1     OBJ       3.7237051532666493e-03
    x_6_1     product_lb_31  -2.5900345337911936e-02
    x_6_1     product_ub_32  -4.3985966382198260e-02
    x_6_1     onehot_6_47  1
    x_6_1     stock_lb_194  1
    x_6_1     stock_ub_195  1
    x_6_1     parent_nonstrict_scope_196  1.1171115459799947e-02
    x_6_1     unique_nonzero_owner_268  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_1     product_lb_31  1
    w_6_1     product_ub_32  1
    w_6_1     normalized_mass_6_48  1
    w_6_1     normalized_ratio_6_49  -0.25
    w_6_1     full_original_Gini_254  -1.6484523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_2     product_lb_33  -2.5900345337911936e-02
    x_6_2     product_ub_34  -4.3985966382198260e-02
    x_6_2     onehot_6_47  1
    x_6_2     stock_lb_194  2
    x_6_2     stock_ub_195  2
    x_6_2     parent_nonstrict_scope_196  7.4474103065332977e-03
    x_6_2     unique_nonzero_owner_269  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_2     product_lb_33  1
    w_6_2     product_ub_34  1
    w_6_2     normalized_mass_6_48  1
    w_6_2     normalized_ratio_6_49  -0.5
    w_6_2     full_original_Gini_254  -1.0567857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_3     OBJ       -3.7237051532666488e-03
    x_6_3     product_lb_35  -2.5900345337911936e-02
    x_6_3     product_ub_36  -4.3985966382198260e-02
    x_6_3     onehot_6_47  1
    x_6_3     stock_lb_194  3
    x_6_3     stock_ub_195  3
    x_6_3     parent_nonstrict_scope_196  3.7237051532666488e-03
    x_6_3     unique_nonzero_owner_270  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_3     product_lb_35  1
    w_6_3     product_ub_36  1
    w_6_3     normalized_mass_6_48  1
    w_6_3     normalized_ratio_6_49  -0.75
    w_6_3     full_original_Gini_254  -5.05595238095238
    MARKER    'MARKER'                 'INTORG'
    x_6_4     OBJ       -7.4474103065332977e-03
    x_6_4     product_lb_37  -2.5900345337911936e-02
    x_6_4     product_ub_38  -4.3985966382198260e-02
    x_6_4     onehot_6_47  1
    x_6_4     stock_lb_194  4
    x_6_4     stock_ub_195  4
    x_6_4     unique_nonzero_owner_271  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_4     product_lb_37  1
    w_6_4     product_ub_38  1
    w_6_4     normalized_mass_6_48  1
    w_6_4     normalized_ratio_6_49  -1
    w_6_4     full_original_Gini_254  -5.2654761904761909e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_5     OBJ       -3.7237051532666488e-03
    x_6_5     product_lb_39  -2.5900345337911936e-02
    x_6_5     product_ub_40  -4.3985966382198260e-02
    x_6_5     onehot_6_47  1
    x_6_5     stock_lb_194  5
    x_6_5     stock_ub_195  5
    x_6_5     parent_nonstrict_scope_196  3.7237051532666488e-03
    x_6_5     unique_nonzero_owner_272  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_5     product_lb_39  1
    w_6_5     product_ub_40  1
    w_6_5     normalized_mass_6_48  1
    w_6_5     normalized_ratio_6_49  -1.25
    w_6_5     full_original_Gini_254  -1.1515476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_6     product_lb_41  -2.5900345337911936e-02
    x_6_6     product_ub_42  -4.3985966382198260e-02
    x_6_6     onehot_6_47  1
    x_6_6     stock_lb_194  6
    x_6_6     stock_ub_195  6
    x_6_6     parent_nonstrict_scope_196  7.4474103065332977e-03
    MARKER    'MARKER'                 'INTEND'
    w_6_6     product_lb_41  1
    w_6_6     product_ub_42  1
    w_6_6     normalized_mass_6_48  1
    w_6_6     normalized_ratio_6_49  -1.5
    w_6_6     full_original_Gini_254  -1.7765476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_7     OBJ       3.7237051532666493e-03
    x_6_7     product_lb_43  -2.5900345337911936e-02
    x_6_7     product_ub_44  -4.3985966382198260e-02
    x_6_7     onehot_6_47  1
    x_6_7     stock_lb_194  7
    x_6_7     stock_ub_195  7
    x_6_7     parent_nonstrict_scope_196  1.1171115459799947e-02
    x_6_7     unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_7     product_lb_43  1
    w_6_7     product_ub_44  1
    w_6_7     normalized_mass_6_48  1
    w_6_7     normalized_ratio_6_49  -1.75
    w_6_7     full_original_Gini_254  -2.4515476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_8     OBJ       7.4474103065332977e-03
    x_6_8     product_lb_45  -2.5900345337911936e-02
    x_6_8     product_ub_46  -4.3985966382198260e-02
    x_6_8     onehot_6_47  1
    x_6_8     stock_lb_194  8
    x_6_8     stock_ub_195  8
    x_6_8     parent_nonstrict_scope_196  1.4894820613066595e-02
    x_6_8     unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_8     product_lb_45  1
    w_6_8     product_ub_46  1
    w_6_8     normalized_mass_6_48  1
    w_6_8     normalized_ratio_6_49  -2
    w_6_8     full_original_Gini_254  -3.1265476190476189e+01
    rho_6     normalized_ratio_6_49  1
    rho_6     block_pair_pos_197  -1
    rho_6     block_pair_neg_198  1
    rho_6     block_pair_pos_199  -1
    rho_6     block_pair_neg_200  1
    rho_6     block_pair_pos_201  -1
    rho_6     block_pair_neg_202  1
    rho_6     block_pair_pos_203  -1
    rho_6     block_pair_neg_204  1
    rho_6     block_pair_pos_205  -1
    rho_6     block_pair_neg_206  1
    rho_6     block_pair_pos_207  -1
    rho_6     block_pair_neg_208  1
    rho_6     block_pair_pos_209  1
    rho_6     block_pair_neg_210  -1
    rho_6     normalization_253  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_50  -2.5900345337911936e-02
    x_34_0    product_ub_51  -4.3985966382198260e-02
    x_34_0    onehot_34_82  1
    x_34_0    parent_nonstrict_scope_196  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_50  1
    w_34_0    product_ub_51  1
    w_34_0    normalized_mass_34_83  1
    w_34_0    full_original_Gini_254  -2.2734523809523811e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_52  -2.5900345337911936e-02
    x_34_1    product_ub_53  -4.3985966382198260e-02
    x_34_1    onehot_34_82  1
    x_34_1    stock_lb_194  1
    x_34_1    stock_ub_195  1
    x_34_1    parent_nonstrict_scope_196  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_52  1
    w_34_1    product_ub_53  1
    w_34_1    normalized_mass_34_83  1
    w_34_1    normalized_ratio_34_84  -0.125
    w_34_1    full_original_Gini_254  -1.9609523809523811e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_54  -2.5900345337911936e-02
    x_34_2    product_ub_55  -4.3985966382198260e-02
    x_34_2    onehot_34_82  1
    x_34_2    stock_lb_194  2
    x_34_2    stock_ub_195  2
    x_34_2    parent_nonstrict_scope_196  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_54  1
    w_34_2    product_ub_55  1
    w_34_2    normalized_mass_34_83  1
    w_34_2    normalized_ratio_34_84  -0.25
    w_34_2    full_original_Gini_254  -1.6484523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_56  -2.5900345337911936e-02
    x_34_3    product_ub_57  -4.3985966382198260e-02
    x_34_3    onehot_34_82  1
    x_34_3    stock_lb_194  3
    x_34_3    stock_ub_195  3
    x_34_3    parent_nonstrict_scope_196  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_56  1
    w_34_3    product_ub_57  1
    w_34_3    normalized_mass_34_83  1
    w_34_3    normalized_ratio_34_84  -0.375
    w_34_3    full_original_Gini_254  -1.3442857142857141e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_58  -2.5900345337911936e-02
    x_34_4    product_ub_59  -4.3985966382198260e-02
    x_34_4    onehot_34_82  1
    x_34_4    stock_lb_194  4
    x_34_4    stock_ub_195  4
    x_34_4    parent_nonstrict_scope_196  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_58  1
    w_34_4    product_ub_59  1
    w_34_4    normalized_mass_34_83  1
    w_34_4    normalized_ratio_34_84  -0.5
    w_34_4    full_original_Gini_254  -1.0567857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_60  -2.5900345337911936e-02
    x_34_5    product_ub_61  -4.3985966382198260e-02
    x_34_5    onehot_34_82  1
    x_34_5    stock_lb_194  5
    x_34_5    stock_ub_195  5
    x_34_5    parent_nonstrict_scope_196  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_60  1
    w_34_5    product_ub_61  1
    w_34_5    normalized_mass_34_83  1
    w_34_5    normalized_ratio_34_84  -0.625
    w_34_5    full_original_Gini_254  -7.6928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_62  -2.5900345337911936e-02
    x_34_6    product_ub_63  -4.3985966382198260e-02
    x_34_6    onehot_34_82  1
    x_34_6    stock_lb_194  6
    x_34_6    stock_ub_195  6
    x_34_6    parent_nonstrict_scope_196  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_62  1
    w_34_6    product_ub_63  1
    w_34_6    normalized_mass_34_83  1
    w_34_6    normalized_ratio_34_84  -0.75
    w_34_6    full_original_Gini_254  -5.05595238095238
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_64  -2.5900345337911936e-02
    x_34_7    product_ub_65  -4.3985966382198260e-02
    x_34_7    onehot_34_82  1
    x_34_7    stock_lb_194  7
    x_34_7    stock_ub_195  7
    x_34_7    parent_nonstrict_scope_196  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_64  1
    w_34_7    product_ub_65  1
    w_34_7    normalized_mass_34_83  1
    w_34_7    normalized_ratio_34_84  -0.875
    w_34_7    full_original_Gini_254  -4.3904761904761909e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_66  -2.5900345337911936e-02
    x_34_8    product_ub_67  -4.3985966382198260e-02
    x_34_8    onehot_34_82  1
    x_34_8    stock_lb_194  8
    x_34_8    stock_ub_195  8
    x_34_8    unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_66  1
    w_34_8    product_ub_67  1
    w_34_8    normalized_mass_34_83  1
    w_34_8    normalized_ratio_34_84  -1
    w_34_8    full_original_Gini_254  -5.2654761904761909e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_68  -2.5900345337911936e-02
    x_34_9    product_ub_69  -4.3985966382198260e-02
    x_34_9    onehot_34_82  1
    x_34_9    stock_lb_194  9
    x_34_9    stock_ub_195  9
    x_34_9    parent_nonstrict_scope_196  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_68  1
    w_34_9    product_ub_69  1
    w_34_9    normalized_mass_34_83  1
    w_34_9    normalized_ratio_34_84  -1.125
    w_34_9    full_original_Gini_254  -8.39047619047619
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_70  -2.5900345337911936e-02
    x_34_10   product_ub_71  -4.3985966382198260e-02
    x_34_10   onehot_34_82  1
    x_34_10   stock_lb_194  10
    x_34_10   stock_ub_195  10
    x_34_10   parent_nonstrict_scope_196  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_70  1
    w_34_10   product_ub_71  1
    w_34_10   normalized_mass_34_83  1
    w_34_10   normalized_ratio_34_84  -1.25
    w_34_10   full_original_Gini_254  -1.1515476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_72  -2.5900345337911936e-02
    x_34_11   product_ub_73  -4.3985966382198260e-02
    x_34_11   onehot_34_82  1
    x_34_11   stock_lb_194  11
    x_34_11   stock_ub_195  11
    x_34_11   parent_nonstrict_scope_196  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_72  1
    w_34_11   product_ub_73  1
    w_34_11   normalized_mass_34_83  1
    w_34_11   normalized_ratio_34_84  -1.375
    w_34_11   full_original_Gini_254  -1.4640476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_74  -2.5900345337911936e-02
    x_34_12   product_ub_75  -4.3985966382198260e-02
    x_34_12   onehot_34_82  1
    x_34_12   stock_lb_194  12
    x_34_12   stock_ub_195  12
    x_34_12   parent_nonstrict_scope_196  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_74  1
    w_34_12   product_ub_75  1
    w_34_12   normalized_mass_34_83  1
    w_34_12   normalized_ratio_34_84  -1.5
    w_34_12   full_original_Gini_254  -1.7765476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_76  -2.5900345337911936e-02
    x_34_13   product_ub_77  -4.3985966382198260e-02
    x_34_13   onehot_34_82  1
    x_34_13   stock_lb_194  13
    x_34_13   stock_ub_195  13
    x_34_13   parent_nonstrict_scope_196  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_76  1
    w_34_13   product_ub_77  1
    w_34_13   normalized_mass_34_83  1
    w_34_13   normalized_ratio_34_84  -1.625
    w_34_13   full_original_Gini_254  -2.1140476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_78  -2.5900345337911936e-02
    x_34_14   product_ub_79  -4.3985966382198260e-02
    x_34_14   onehot_34_82  1
    x_34_14   stock_lb_194  14
    x_34_14   stock_ub_195  14
    x_34_14   parent_nonstrict_scope_196  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_78  1
    w_34_14   product_ub_79  1
    w_34_14   normalized_mass_34_83  1
    w_34_14   normalized_ratio_34_84  -1.75
    w_34_14   full_original_Gini_254  -2.4515476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_80  -2.5900345337911936e-02
    x_34_15   product_ub_81  -4.3985966382198260e-02
    x_34_15   onehot_34_82  1
    x_34_15   stock_lb_194  15
    x_34_15   stock_ub_195  15
    x_34_15   parent_nonstrict_scope_196  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_80  1
    w_34_15   product_ub_81  1
    w_34_15   normalized_mass_34_83  1
    w_34_15   normalized_ratio_34_84  -1.875
    w_34_15   full_original_Gini_254  -2.7890476190476189e+01
    rho_34    normalized_ratio_34_84  1
    rho_34    block_pair_pos_207  1
    rho_34    block_pair_neg_208  -1
    rho_34    block_pair_pos_221  1
    rho_34    block_pair_neg_222  -1
    rho_34    block_pair_pos_243  -1
    rho_34    block_pair_neg_244  1
    rho_34    block_pair_pos_245  -1
    rho_34    block_pair_neg_246  1
    rho_34    block_pair_pos_247  -1
    rho_34    block_pair_neg_248  1
    rho_34    block_pair_pos_249  -1
    rho_34    block_pair_neg_250  1
    rho_34    block_pair_pos_251  -1
    rho_34    block_pair_neg_252  1
    rho_34    normalization_253  1
    MARKER    'MARKER'                 'INTORG'
    x_9_0     OBJ       1.1636571534741636e-02
    x_9_0     product_lb_85  -2.5900345337911936e-02
    x_9_0     product_ub_86  -4.3985966382198260e-02
    x_9_0     onehot_9_107  1
    x_9_0     parent_nonstrict_scope_196  2.3273143069483273e-02
    x_9_0     unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_0     product_lb_85  1
    w_9_0     product_ub_86  1
    w_9_0     normalized_mass_9_108  1
    w_9_0     full_original_Gini_254  -2.2734523809523811e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_1     OBJ       6.9819429208449833e-03
    x_9_1     product_lb_87  -2.5900345337911936e-02
    x_9_1     product_ub_88  -4.3985966382198260e-02
    x_9_1     onehot_9_107  1
    x_9_1     stock_lb_194  1
    x_9_1     stock_ub_195  1
    x_9_1     parent_nonstrict_scope_196  1.8618514455586620e-02
    x_9_1     unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_1     product_lb_87  1
    w_9_1     product_ub_88  1
    w_9_1     normalized_mass_9_108  1
    w_9_1     normalized_ratio_9_109  -0.2
    w_9_1     full_original_Gini_254  -1.7734523809523814e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_2     OBJ       2.3273143069483266e-03
    x_9_2     product_lb_89  -2.5900345337911936e-02
    x_9_2     product_ub_90  -4.3985966382198260e-02
    x_9_2     onehot_9_107  1
    x_9_2     stock_lb_194  2
    x_9_2     stock_ub_195  2
    x_9_2     parent_nonstrict_scope_196  1.3963885841689963e-02
    MARKER    'MARKER'                 'INTEND'
    w_9_2     product_lb_89  1
    w_9_2     product_ub_90  1
    w_9_2     normalized_mass_9_108  1
    w_9_2     normalized_ratio_9_109  -0.4
    w_9_2     full_original_Gini_254  -1.2867857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_3     OBJ       -0.00232731430694833
    x_9_3     product_lb_91  -2.5900345337911936e-02
    x_9_3     product_ub_92  -4.3985966382198260e-02
    x_9_3     onehot_9_107  1
    x_9_3     stock_lb_194  3
    x_9_3     stock_ub_195  3
    x_9_3     parent_nonstrict_scope_196  9.3092572277933064e-03
    x_9_3     unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_3     product_lb_91  1
    w_9_3     product_ub_92  1
    w_9_3     normalized_mass_9_108  1
    w_9_3     normalized_ratio_9_109  -6.0000000000000009e-01
    w_9_3     full_original_Gini_254  -8.2678571428571423e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_4     OBJ       -6.9819429208449833e-03
    x_9_4     product_lb_93  -2.5900345337911936e-02
    x_9_4     product_ub_94  -4.3985966382198260e-02
    x_9_4     onehot_9_107  1
    x_9_4     stock_lb_194  4
    x_9_4     stock_ub_195  4
    x_9_4     parent_nonstrict_scope_196  4.6546286138966532e-03
    x_9_4     unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_4     product_lb_93  1
    w_9_4     product_ub_94  1
    w_9_4     normalized_mass_9_108  1
    w_9_4     normalized_ratio_9_109  -0.8
    w_9_4     full_original_Gini_254  -4.60595238095238
    MARKER    'MARKER'                 'INTORG'
    x_9_5     OBJ       -1.1636571534741636e-02
    x_9_5     product_lb_95  -2.5900345337911936e-02
    x_9_5     product_ub_96  -4.3985966382198260e-02
    x_9_5     onehot_9_107  1
    x_9_5     stock_lb_194  5
    x_9_5     stock_ub_195  5
    x_9_5     unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_5     product_lb_95  1
    w_9_5     product_ub_96  1
    w_9_5     normalized_mass_9_108  1
    w_9_5     normalized_ratio_9_109  -1
    w_9_5     full_original_Gini_254  -5.2654761904761909e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_6     OBJ       -6.9819429208449781e-03
    x_9_6     product_lb_97  -2.5900345337911936e-02
    x_9_6     product_ub_98  -4.3985966382198260e-02
    x_9_6     onehot_9_107  1
    x_9_6     stock_lb_194  6
    x_9_6     stock_ub_195  6
    x_9_6     parent_nonstrict_scope_196  4.6546286138966584e-03
    x_9_6     unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_6     product_lb_97  1
    w_9_6     product_ub_98  1
    w_9_6     normalized_mass_9_108  1
    w_9_6     normalized_ratio_9_109  -1.2000000000000002e+00
    w_9_6     full_original_Gini_254  -1.0265476190476193e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_7     OBJ       -2.3273143069483249e-03
    x_9_7     product_lb_99  -2.5900345337911936e-02
    x_9_7     product_ub_100  -4.3985966382198260e-02
    x_9_7     onehot_9_107  1
    x_9_7     stock_lb_194  7
    x_9_7     stock_ub_195  7
    x_9_7     parent_nonstrict_scope_196  9.3092572277933116e-03
    x_9_7     unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_7     product_lb_99  1
    w_9_7     product_ub_100  1
    w_9_7     normalized_mass_9_108  1
    w_9_7     normalized_ratio_9_109  -1.4000000000000001e+00
    w_9_7     full_original_Gini_254  -1.5265476190476198e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_8     OBJ       0.00232731430694833
    x_9_8     product_lb_101  -2.5900345337911936e-02
    x_9_8     product_ub_102  -4.3985966382198260e-02
    x_9_8     onehot_9_107  1
    x_9_8     stock_lb_194  8
    x_9_8     stock_ub_195  8
    x_9_8     parent_nonstrict_scope_196  1.3963885841689967e-02
    x_9_8     unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_8     product_lb_101  1
    w_9_8     product_ub_102  1
    w_9_8     normalized_mass_9_108  1
    w_9_8     normalized_ratio_9_109  -1.6
    w_9_8     full_original_Gini_254  -2.0465476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_9     OBJ       6.9819429208449833e-03
    x_9_9     product_lb_103  -2.5900345337911936e-02
    x_9_9     product_ub_104  -4.3985966382198260e-02
    x_9_9     onehot_9_107  1
    x_9_9     stock_lb_194  9
    x_9_9     stock_ub_195  9
    x_9_9     parent_nonstrict_scope_196  1.8618514455586620e-02
    x_9_9     unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_9     product_lb_103  1
    w_9_9     product_ub_104  1
    w_9_9     normalized_mass_9_108  1
    w_9_9     normalized_ratio_9_109  -1.8
    w_9_9     full_original_Gini_254  -2.5865476190476198e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_10    OBJ       1.1636571534741636e-02
    x_9_10    product_lb_105  -2.5900345337911936e-02
    x_9_10    product_ub_106  -4.3985966382198260e-02
    x_9_10    onehot_9_107  1
    x_9_10    stock_lb_194  10
    x_9_10    stock_ub_195  10
    x_9_10    parent_nonstrict_scope_196  2.3273143069483273e-02
    x_9_10    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_10    product_lb_105  1
    w_9_10    product_ub_106  1
    w_9_10    normalized_mass_9_108  1
    w_9_10    normalized_ratio_9_109  -2
    w_9_10    full_original_Gini_254  -3.1265476190476189e+01
    rho_9     normalized_ratio_9_109  1
    rho_9     block_pair_pos_197  1
    rho_9     block_pair_neg_198  -1
    rho_9     block_pair_pos_211  1
    rho_9     block_pair_neg_212  -1
    rho_9     block_pair_pos_223  -1
    rho_9     block_pair_neg_224  1
    rho_9     block_pair_pos_225  -1
    rho_9     block_pair_neg_226  1
    rho_9     block_pair_pos_227  -1
    rho_9     block_pair_neg_228  1
    rho_9     block_pair_pos_229  -1
    rho_9     block_pair_neg_230  1
    rho_9     block_pair_pos_243  1
    rho_9     block_pair_neg_244  -1
    rho_9     normalization_253  1
    MARKER    'MARKER'                 'INTORG'
    x_29_0    OBJ       1.1636571534741636e-02
    x_29_0    product_lb_110  -2.5900345337911936e-02
    x_29_0    product_ub_111  -4.3985966382198260e-02
    x_29_0    onehot_29_132  1
    x_29_0    parent_nonstrict_scope_196  2.3273143069483273e-02
    x_29_0    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_0    product_lb_110  1
    w_29_0    product_ub_111  1
    w_29_0    normalized_mass_29_133  1
    w_29_0    full_original_Gini_254  -2.2734523809523811e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_1    OBJ       6.9819429208449833e-03
    x_29_1    product_lb_112  -2.5900345337911936e-02
    x_29_1    product_ub_113  -4.3985966382198260e-02
    x_29_1    onehot_29_132  1
    x_29_1    stock_lb_194  1
    x_29_1    stock_ub_195  1
    x_29_1    parent_nonstrict_scope_196  1.8618514455586620e-02
    MARKER    'MARKER'                 'INTEND'
    w_29_1    product_lb_112  1
    w_29_1    product_ub_113  1
    w_29_1    normalized_mass_29_133  1
    w_29_1    normalized_ratio_29_134  -0.2
    w_29_1    full_original_Gini_254  -1.7734523809523814e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_2    OBJ       2.3273143069483266e-03
    x_29_2    product_lb_114  -2.5900345337911936e-02
    x_29_2    product_ub_115  -4.3985966382198260e-02
    x_29_2    onehot_29_132  1
    x_29_2    stock_lb_194  2
    x_29_2    stock_ub_195  2
    x_29_2    parent_nonstrict_scope_196  1.3963885841689963e-02
    x_29_2    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_2    product_lb_114  1
    w_29_2    product_ub_115  1
    w_29_2    normalized_mass_29_133  1
    w_29_2    normalized_ratio_29_134  -0.4
    w_29_2    full_original_Gini_254  -1.2867857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_3    OBJ       -0.00232731430694833
    x_29_3    product_lb_116  -2.5900345337911936e-02
    x_29_3    product_ub_117  -4.3985966382198260e-02
    x_29_3    onehot_29_132  1
    x_29_3    stock_lb_194  3
    x_29_3    stock_ub_195  3
    x_29_3    parent_nonstrict_scope_196  9.3092572277933064e-03
    x_29_3    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_3    product_lb_116  1
    w_29_3    product_ub_117  1
    w_29_3    normalized_mass_29_133  1
    w_29_3    normalized_ratio_29_134  -6.0000000000000009e-01
    w_29_3    full_original_Gini_254  -8.2678571428571423e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_4    OBJ       -6.9819429208449833e-03
    x_29_4    product_lb_118  -2.5900345337911936e-02
    x_29_4    product_ub_119  -4.3985966382198260e-02
    x_29_4    onehot_29_132  1
    x_29_4    stock_lb_194  4
    x_29_4    stock_ub_195  4
    x_29_4    parent_nonstrict_scope_196  4.6546286138966532e-03
    x_29_4    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_4    product_lb_118  1
    w_29_4    product_ub_119  1
    w_29_4    normalized_mass_29_133  1
    w_29_4    normalized_ratio_29_134  -0.8
    w_29_4    full_original_Gini_254  -4.60595238095238
    MARKER    'MARKER'                 'INTORG'
    x_29_5    OBJ       -1.1636571534741636e-02
    x_29_5    product_lb_120  -2.5900345337911936e-02
    x_29_5    product_ub_121  -4.3985966382198260e-02
    x_29_5    onehot_29_132  1
    x_29_5    stock_lb_194  5
    x_29_5    stock_ub_195  5
    x_29_5    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_5    product_lb_120  1
    w_29_5    product_ub_121  1
    w_29_5    normalized_mass_29_133  1
    w_29_5    normalized_ratio_29_134  -1
    w_29_5    full_original_Gini_254  -5.2654761904761909e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_6    OBJ       -6.9819429208449781e-03
    x_29_6    product_lb_122  -2.5900345337911936e-02
    x_29_6    product_ub_123  -4.3985966382198260e-02
    x_29_6    onehot_29_132  1
    x_29_6    stock_lb_194  6
    x_29_6    stock_ub_195  6
    x_29_6    parent_nonstrict_scope_196  4.6546286138966584e-03
    x_29_6    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_6    product_lb_122  1
    w_29_6    product_ub_123  1
    w_29_6    normalized_mass_29_133  1
    w_29_6    normalized_ratio_29_134  -1.2000000000000002e+00
    w_29_6    full_original_Gini_254  -1.0265476190476193e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_7    OBJ       -2.3273143069483249e-03
    x_29_7    product_lb_124  -2.5900345337911936e-02
    x_29_7    product_ub_125  -4.3985966382198260e-02
    x_29_7    onehot_29_132  1
    x_29_7    stock_lb_194  7
    x_29_7    stock_ub_195  7
    x_29_7    parent_nonstrict_scope_196  9.3092572277933116e-03
    x_29_7    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_7    product_lb_124  1
    w_29_7    product_ub_125  1
    w_29_7    normalized_mass_29_133  1
    w_29_7    normalized_ratio_29_134  -1.4000000000000001e+00
    w_29_7    full_original_Gini_254  -1.5265476190476198e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_8    OBJ       0.00232731430694833
    x_29_8    product_lb_126  -2.5900345337911936e-02
    x_29_8    product_ub_127  -4.3985966382198260e-02
    x_29_8    onehot_29_132  1
    x_29_8    stock_lb_194  8
    x_29_8    stock_ub_195  8
    x_29_8    parent_nonstrict_scope_196  1.3963885841689967e-02
    x_29_8    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_8    product_lb_126  1
    w_29_8    product_ub_127  1
    w_29_8    normalized_mass_29_133  1
    w_29_8    normalized_ratio_29_134  -1.6
    w_29_8    full_original_Gini_254  -2.0465476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_9    OBJ       6.9819429208449833e-03
    x_29_9    product_lb_128  -2.5900345337911936e-02
    x_29_9    product_ub_129  -4.3985966382198260e-02
    x_29_9    onehot_29_132  1
    x_29_9    stock_lb_194  9
    x_29_9    stock_ub_195  9
    x_29_9    parent_nonstrict_scope_196  1.8618514455586620e-02
    x_29_9    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_9    product_lb_128  1
    w_29_9    product_ub_129  1
    w_29_9    normalized_mass_29_133  1
    w_29_9    normalized_ratio_29_134  -1.8
    w_29_9    full_original_Gini_254  -2.5865476190476198e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_10   OBJ       1.1636571534741636e-02
    x_29_10   product_lb_130  -2.5900345337911936e-02
    x_29_10   product_ub_131  -4.3985966382198260e-02
    x_29_10   onehot_29_132  1
    x_29_10   stock_lb_194  10
    x_29_10   stock_ub_195  10
    x_29_10   parent_nonstrict_scope_196  2.3273143069483273e-02
    x_29_10   unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_10   product_lb_130  1
    w_29_10   product_ub_131  1
    w_29_10   normalized_mass_29_133  1
    w_29_10   normalized_ratio_29_134  -2
    w_29_10   full_original_Gini_254  -3.1265476190476189e+01
    rho_29    normalized_ratio_29_134  1
    rho_29    block_pair_pos_205  1
    rho_29    block_pair_neg_206  -1
    rho_29    block_pair_pos_219  1
    rho_29    block_pair_neg_220  -1
    rho_29    block_pair_pos_229  1
    rho_29    block_pair_neg_230  -1
    rho_29    block_pair_pos_237  -1
    rho_29    block_pair_neg_238  1
    rho_29    block_pair_pos_239  -1
    rho_29    block_pair_neg_240  1
    rho_29    block_pair_pos_241  -1
    rho_29    block_pair_neg_242  1
    rho_29    block_pair_pos_251  1
    rho_29    block_pair_neg_252  -1
    rho_29    normalization_253  1
    MARKER    'MARKER'                 'INTORG'
    x_10_0    OBJ       4.1891612282083379e-03
    x_10_0    product_lb_135  -2.5900345337911936e-02
    x_10_0    product_ub_136  -4.3985966382198260e-02
    x_10_0    onehot_10_149  1
    x_10_0    parent_nonstrict_scope_196  8.3783224564166758e-03
    x_10_0    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_0    product_lb_135  1
    w_10_0    product_ub_136  1
    w_10_0    normalized_mass_10_150  1
    w_10_0    full_original_Gini_254  -2.2734523809523811e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_1    OBJ       1.3963870760694466e-03
    x_10_1    product_lb_137  -2.5900345337911936e-02
    x_10_1    product_ub_138  -4.3985966382198260e-02
    x_10_1    onehot_10_149  1
    x_10_1    stock_lb_194  1
    x_10_1    stock_ub_195  1
    x_10_1    parent_nonstrict_scope_196  5.5855483042777845e-03
    x_10_1    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_1    product_lb_137  1
    w_10_1    product_ub_138  1
    w_10_1    normalized_mass_10_150  1
    w_10_1    normalized_ratio_10_151  -3.3333333333333331e-01
    w_10_1    full_original_Gini_254  -1.4401190476190473e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_2    OBJ       -1.3963870760694457e-03
    x_10_2    product_lb_139  -2.5900345337911936e-02
    x_10_2    product_ub_140  -4.3985966382198260e-02
    x_10_2    onehot_10_149  1
    x_10_2    stock_lb_194  2
    x_10_2    stock_ub_195  2
    x_10_2    parent_nonstrict_scope_196  2.7927741521388922e-03
    x_10_2    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_2    product_lb_139  1
    w_10_2    product_ub_140  1
    w_10_2    normalized_mass_10_150  1
    w_10_2    normalized_ratio_10_151  -6.6666666666666663e-01
    w_10_2    full_original_Gini_254  -6.7345238095238091e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_3    OBJ       -4.1891612282083379e-03
    x_10_3    product_lb_141  -2.5900345337911936e-02
    x_10_3    product_ub_142  -4.3985966382198260e-02
    x_10_3    onehot_10_149  1
    x_10_3    stock_lb_194  3
    x_10_3    stock_ub_195  3
    x_10_3    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_3    product_lb_141  1
    w_10_3    product_ub_142  1
    w_10_3    normalized_mass_10_150  1
    w_10_3    normalized_ratio_10_151  -1
    w_10_3    full_original_Gini_254  -5.2654761904761909e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_4    OBJ       -1.3963870760694466e-03
    x_10_4    product_lb_143  -2.5900345337911936e-02
    x_10_4    product_ub_144  -4.3985966382198260e-02
    x_10_4    onehot_10_149  1
    x_10_4    stock_lb_194  4
    x_10_4    stock_ub_195  4
    x_10_4    parent_nonstrict_scope_196  2.7927741521388914e-03
    MARKER    'MARKER'                 'INTEND'
    w_10_4    product_lb_143  1
    w_10_4    product_ub_144  1
    w_10_4    normalized_mass_10_150  1
    w_10_4    normalized_ratio_10_151  -1.3333333333333333e+00
    w_10_4    full_original_Gini_254  -1.3598809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_5    OBJ       1.3963870760694448e-03
    x_10_5    product_lb_145  -2.5900345337911936e-02
    x_10_5    product_ub_146  -4.3985966382198260e-02
    x_10_5    onehot_10_149  1
    x_10_5    stock_lb_194  5
    x_10_5    stock_ub_195  5
    x_10_5    parent_nonstrict_scope_196  5.5855483042777827e-03
    x_10_5    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_5    product_lb_145  1
    w_10_5    product_ub_146  1
    w_10_5    normalized_mass_10_150  1
    w_10_5    normalized_ratio_10_151  -1.6666666666666665e+00
    w_10_5    full_original_Gini_254  -2.2265476190476186e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_6    OBJ       4.1891612282083379e-03
    x_10_6    product_lb_147  -2.5900345337911936e-02
    x_10_6    product_ub_148  -4.3985966382198260e-02
    x_10_6    onehot_10_149  1
    x_10_6    stock_lb_194  6
    x_10_6    stock_ub_195  6
    x_10_6    parent_nonstrict_scope_196  8.3783224564166758e-03
    x_10_6    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_6    product_lb_147  1
    w_10_6    product_ub_148  1
    w_10_6    normalized_mass_10_150  1
    w_10_6    normalized_ratio_10_151  -2
    w_10_6    full_original_Gini_254  -3.1265476190476189e+01
    rho_10    normalized_ratio_10_151  1
    rho_10    block_pair_pos_199  1
    rho_10    block_pair_neg_200  -1
    rho_10    block_pair_pos_213  1
    rho_10    block_pair_neg_214  -1
    rho_10    block_pair_pos_223  1
    rho_10    block_pair_neg_224  -1
    rho_10    block_pair_pos_231  -1
    rho_10    block_pair_neg_232  1
    rho_10    block_pair_pos_233  -1
    rho_10    block_pair_neg_234  1
    rho_10    block_pair_pos_237  1
    rho_10    block_pair_neg_238  -1
    rho_10    block_pair_pos_245  1
    rho_10    block_pair_neg_246  -1
    rho_10    normalization_253  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_152  -2.5900345337911936e-02
    x_27_0    product_ub_153  -4.3985966382198260e-02
    x_27_0    onehot_27_166  1
    x_27_0    parent_nonstrict_scope_196  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_152  1
    w_27_0    product_ub_153  1
    w_27_0    normalized_mass_27_167  1
    w_27_0    full_original_Gini_254  -2.2734523809523811e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_154  -2.5900345337911936e-02
    x_27_1    product_ub_155  -4.3985966382198260e-02
    x_27_1    onehot_27_166  1
    x_27_1    stock_lb_194  1
    x_27_1    stock_ub_195  1
    x_27_1    parent_nonstrict_scope_196  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_154  1
    w_27_1    product_ub_155  1
    w_27_1    normalized_mass_27_167  1
    w_27_1    normalized_ratio_27_168  -3.3333333333333331e-01
    w_27_1    full_original_Gini_254  -1.4401190476190473e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_156  -2.5900345337911936e-02
    x_27_2    product_ub_157  -4.3985966382198260e-02
    x_27_2    onehot_27_166  1
    x_27_2    stock_lb_194  2
    x_27_2    stock_ub_195  2
    x_27_2    parent_nonstrict_scope_196  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_156  1
    w_27_2    product_ub_157  1
    w_27_2    normalized_mass_27_167  1
    w_27_2    normalized_ratio_27_168  -6.6666666666666663e-01
    w_27_2    full_original_Gini_254  -6.7345238095238091e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_158  -2.5900345337911936e-02
    x_27_3    product_ub_159  -4.3985966382198260e-02
    x_27_3    onehot_27_166  1
    x_27_3    stock_lb_194  3
    x_27_3    stock_ub_195  3
    x_27_3    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_158  1
    w_27_3    product_ub_159  1
    w_27_3    normalized_mass_27_167  1
    w_27_3    normalized_ratio_27_168  -1
    w_27_3    full_original_Gini_254  -5.2654761904761909e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_160  -2.5900345337911936e-02
    x_27_4    product_ub_161  -4.3985966382198260e-02
    x_27_4    onehot_27_166  1
    x_27_4    stock_lb_194  4
    x_27_4    stock_ub_195  4
    x_27_4    parent_nonstrict_scope_196  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_160  1
    w_27_4    product_ub_161  1
    w_27_4    normalized_mass_27_167  1
    w_27_4    normalized_ratio_27_168  -1.3333333333333333e+00
    w_27_4    full_original_Gini_254  -1.3598809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_162  -2.5900345337911936e-02
    x_27_5    product_ub_163  -4.3985966382198260e-02
    x_27_5    onehot_27_166  1
    x_27_5    stock_lb_194  5
    x_27_5    stock_ub_195  5
    x_27_5    parent_nonstrict_scope_196  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_162  1
    w_27_5    product_ub_163  1
    w_27_5    normalized_mass_27_167  1
    w_27_5    normalized_ratio_27_168  -1.6666666666666665e+00
    w_27_5    full_original_Gini_254  -2.2265476190476186e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_164  -2.5900345337911936e-02
    x_27_6    product_ub_165  -4.3985966382198260e-02
    x_27_6    onehot_27_166  1
    x_27_6    stock_lb_194  6
    x_27_6    stock_ub_195  6
    x_27_6    parent_nonstrict_scope_196  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_164  1
    w_27_6    product_ub_165  1
    w_27_6    normalized_mass_27_167  1
    w_27_6    normalized_ratio_27_168  -2
    w_27_6    full_original_Gini_254  -3.1265476190476189e+01
    rho_27    normalized_ratio_27_168  1
    rho_27    block_pair_pos_203  1
    rho_27    block_pair_neg_204  -1
    rho_27    block_pair_pos_217  1
    rho_27    block_pair_neg_218  -1
    rho_27    block_pair_pos_227  1
    rho_27    block_pair_neg_228  -1
    rho_27    block_pair_pos_233  1
    rho_27    block_pair_neg_234  -1
    rho_27    block_pair_pos_235  -1
    rho_27    block_pair_neg_236  1
    rho_27    block_pair_pos_241  1
    rho_27    block_pair_neg_242  -1
    rho_27    block_pair_pos_249  1
    rho_27    block_pair_neg_250  -1
    rho_27    normalization_253  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       1.1636571534741636e-02
    x_11_0    product_lb_169  -2.5900345337911936e-02
    x_11_0    product_ub_170  -4.3985966382198260e-02
    x_11_0    onehot_11_191  1
    x_11_0    parent_nonstrict_scope_196  2.3273143069483273e-02
    x_11_0    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_169  1
    w_11_0    product_ub_170  1
    w_11_0    normalized_mass_11_192  1
    w_11_0    full_original_Gini_254  -2.2734523809523811e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       6.9819429208449833e-03
    x_11_1    product_lb_171  -2.5900345337911936e-02
    x_11_1    product_ub_172  -4.3985966382198260e-02
    x_11_1    onehot_11_191  1
    x_11_1    stock_lb_194  1
    x_11_1    stock_ub_195  1
    x_11_1    parent_nonstrict_scope_196  1.8618514455586620e-02
    x_11_1    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_171  1
    w_11_1    product_ub_172  1
    w_11_1    normalized_mass_11_192  1
    w_11_1    normalized_ratio_11_193  -0.2
    w_11_1    full_original_Gini_254  -1.7734523809523814e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       2.3273143069483266e-03
    x_11_2    product_lb_173  -2.5900345337911936e-02
    x_11_2    product_ub_174  -4.3985966382198260e-02
    x_11_2    onehot_11_191  1
    x_11_2    stock_lb_194  2
    x_11_2    stock_ub_195  2
    x_11_2    parent_nonstrict_scope_196  1.3963885841689963e-02
    x_11_2    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_173  1
    w_11_2    product_ub_174  1
    w_11_2    normalized_mass_11_192  1
    w_11_2    normalized_ratio_11_193  -0.4
    w_11_2    full_original_Gini_254  -1.2867857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       -0.00232731430694833
    x_11_3    product_lb_175  -2.5900345337911936e-02
    x_11_3    product_ub_176  -4.3985966382198260e-02
    x_11_3    onehot_11_191  1
    x_11_3    stock_lb_194  3
    x_11_3    stock_ub_195  3
    x_11_3    parent_nonstrict_scope_196  9.3092572277933064e-03
    x_11_3    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_175  1
    w_11_3    product_ub_176  1
    w_11_3    normalized_mass_11_192  1
    w_11_3    normalized_ratio_11_193  -6.0000000000000009e-01
    w_11_3    full_original_Gini_254  -8.2678571428571423e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    OBJ       -6.9819429208449833e-03
    x_11_4    product_lb_177  -2.5900345337911936e-02
    x_11_4    product_ub_178  -4.3985966382198260e-02
    x_11_4    onehot_11_191  1
    x_11_4    stock_lb_194  4
    x_11_4    stock_ub_195  4
    x_11_4    parent_nonstrict_scope_196  4.6546286138966532e-03
    x_11_4    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_177  1
    w_11_4    product_ub_178  1
    w_11_4    normalized_mass_11_192  1
    w_11_4    normalized_ratio_11_193  -0.8
    w_11_4    full_original_Gini_254  -4.60595238095238
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -1.1636571534741636e-02
    x_11_5    product_lb_179  -2.5900345337911936e-02
    x_11_5    product_ub_180  -4.3985966382198260e-02
    x_11_5    onehot_11_191  1
    x_11_5    stock_lb_194  5
    x_11_5    stock_ub_195  5
    x_11_5    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_179  1
    w_11_5    product_ub_180  1
    w_11_5    normalized_mass_11_192  1
    w_11_5    normalized_ratio_11_193  -1
    w_11_5    full_original_Gini_254  -5.2654761904761909e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -6.9819429208449781e-03
    x_11_6    product_lb_181  -2.5900345337911936e-02
    x_11_6    product_ub_182  -4.3985966382198260e-02
    x_11_6    onehot_11_191  1
    x_11_6    stock_lb_194  6
    x_11_6    stock_ub_195  6
    x_11_6    parent_nonstrict_scope_196  4.6546286138966584e-03
    x_11_6    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_181  1
    w_11_6    product_ub_182  1
    w_11_6    normalized_mass_11_192  1
    w_11_6    normalized_ratio_11_193  -1.2000000000000002e+00
    w_11_6    full_original_Gini_254  -1.0265476190476193e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -2.3273143069483249e-03
    x_11_7    product_lb_183  -2.5900345337911936e-02
    x_11_7    product_ub_184  -4.3985966382198260e-02
    x_11_7    onehot_11_191  1
    x_11_7    stock_lb_194  7
    x_11_7    stock_ub_195  7
    x_11_7    parent_nonstrict_scope_196  9.3092572277933116e-03
    x_11_7    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_183  1
    w_11_7    product_ub_184  1
    w_11_7    normalized_mass_11_192  1
    w_11_7    normalized_ratio_11_193  -1.4000000000000001e+00
    w_11_7    full_original_Gini_254  -1.5265476190476198e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       0.00232731430694833
    x_11_8    product_lb_185  -2.5900345337911936e-02
    x_11_8    product_ub_186  -4.3985966382198260e-02
    x_11_8    onehot_11_191  1
    x_11_8    stock_lb_194  8
    x_11_8    stock_ub_195  8
    x_11_8    parent_nonstrict_scope_196  1.3963885841689967e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_185  1
    w_11_8    product_ub_186  1
    w_11_8    normalized_mass_11_192  1
    w_11_8    normalized_ratio_11_193  -1.6
    w_11_8    full_original_Gini_254  -2.0465476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       6.9819429208449833e-03
    x_11_9    product_lb_187  -2.5900345337911936e-02
    x_11_9    product_ub_188  -4.3985966382198260e-02
    x_11_9    onehot_11_191  1
    x_11_9    stock_lb_194  9
    x_11_9    stock_ub_195  9
    x_11_9    parent_nonstrict_scope_196  1.8618514455586620e-02
    x_11_9    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_187  1
    w_11_9    product_ub_188  1
    w_11_9    normalized_mass_11_192  1
    w_11_9    normalized_ratio_11_193  -1.8
    w_11_9    full_original_Gini_254  -2.5865476190476198e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       1.1636571534741636e-02
    x_11_10   product_lb_189  -2.5900345337911936e-02
    x_11_10   product_ub_190  -4.3985966382198260e-02
    x_11_10   onehot_11_191  1
    x_11_10   stock_lb_194  10
    x_11_10   stock_ub_195  10
    x_11_10   parent_nonstrict_scope_196  2.3273143069483273e-02
    x_11_10   unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_189  1
    w_11_10   product_ub_190  1
    w_11_10   normalized_mass_11_192  1
    w_11_10   normalized_ratio_11_193  -2
    w_11_10   full_original_Gini_254  -3.1265476190476189e+01
    rho_11    normalized_ratio_11_193  1
    rho_11    block_pair_pos_201  1
    rho_11    block_pair_neg_202  -1
    rho_11    block_pair_pos_215  1
    rho_11    block_pair_neg_216  -1
    rho_11    block_pair_pos_225  1
    rho_11    block_pair_neg_226  -1
    rho_11    block_pair_pos_231  1
    rho_11    block_pair_neg_232  -1
    rho_11    block_pair_pos_235  1
    rho_11    block_pair_neg_236  -1
    rho_11    block_pair_pos_239  1
    rho_11    block_pair_neg_240  -1
    rho_11    block_pair_pos_247  1
    rho_11    block_pair_neg_248  -1
    rho_11    normalization_253  1
    a_8_6     block_pair_pos_209  1
    a_8_6     block_pair_neg_210  1
    a_8_6     full_original_Gini_254  -1
    a_8_34    block_pair_pos_221  1
    a_8_34    block_pair_neg_222  1
    a_8_34    full_original_Gini_254  -1
    a_8_9     block_pair_pos_211  1
    a_8_9     block_pair_neg_212  1
    a_8_9     full_original_Gini_254  -1
    a_8_29    block_pair_pos_219  1
    a_8_29    block_pair_neg_220  1
    a_8_29    full_original_Gini_254  -1
    a_8_10    block_pair_pos_213  1
    a_8_10    block_pair_neg_214  1
    a_8_10    full_original_Gini_254  -1
    a_8_27    block_pair_pos_217  1
    a_8_27    block_pair_neg_218  1
    a_8_27    full_original_Gini_254  -1
    a_8_11    block_pair_pos_215  1
    a_8_11    block_pair_neg_216  1
    a_8_11    full_original_Gini_254  -1
    a_6_34    block_pair_pos_207  1
    a_6_34    block_pair_neg_208  1
    a_6_34    full_original_Gini_254  -1
    a_6_9     block_pair_pos_197  1
    a_6_9     block_pair_neg_198  1
    a_6_9     full_original_Gini_254  -1
    a_6_29    block_pair_pos_205  1
    a_6_29    block_pair_neg_206  1
    a_6_29    full_original_Gini_254  -1
    a_6_10    block_pair_pos_199  1
    a_6_10    block_pair_neg_200  1
    a_6_10    full_original_Gini_254  -1
    a_6_27    block_pair_pos_203  1
    a_6_27    block_pair_neg_204  1
    a_6_27    full_original_Gini_254  -1
    a_6_11    block_pair_pos_201  1
    a_6_11    block_pair_neg_202  1
    a_6_11    full_original_Gini_254  -1
    a_34_9    block_pair_pos_243  1
    a_34_9    block_pair_neg_244  1
    a_34_9    full_original_Gini_254  -1
    a_34_29   block_pair_pos_251  1
    a_34_29   block_pair_neg_252  1
    a_34_29   full_original_Gini_254  -1
    a_34_10   block_pair_pos_245  1
    a_34_10   block_pair_neg_246  1
    a_34_10   full_original_Gini_254  -1
    a_34_27   block_pair_pos_249  1
    a_34_27   block_pair_neg_250  1
    a_34_27   full_original_Gini_254  -1
    a_34_11   block_pair_pos_247  1
    a_34_11   block_pair_neg_248  1
    a_34_11   full_original_Gini_254  -1
    a_9_29    block_pair_pos_229  1
    a_9_29    block_pair_neg_230  1
    a_9_29    full_original_Gini_254  -1
    a_9_10    block_pair_pos_223  1
    a_9_10    block_pair_neg_224  1
    a_9_10    full_original_Gini_254  -1
    a_9_27    block_pair_pos_227  1
    a_9_27    block_pair_neg_228  1
    a_9_27    full_original_Gini_254  -1
    a_9_11    block_pair_pos_225  1
    a_9_11    block_pair_neg_226  1
    a_9_11    full_original_Gini_254  -1
    a_29_10   block_pair_pos_237  1
    a_29_10   block_pair_neg_238  1
    a_29_10   full_original_Gini_254  -1
    a_29_27   block_pair_pos_241  1
    a_29_27   block_pair_neg_242  1
    a_29_27   full_original_Gini_254  -1
    a_29_11   block_pair_pos_239  1
    a_29_11   block_pair_neg_240  1
    a_29_11   full_original_Gini_254  -1
    a_10_27   block_pair_pos_233  1
    a_10_27   block_pair_neg_234  1
    a_10_27   full_original_Gini_254  -1
    a_10_11   block_pair_pos_231  1
    a_10_11   block_pair_neg_232  1
    a_10_11   full_original_Gini_254  -1
    a_27_11   block_pair_pos_235  1
    a_27_11   block_pair_neg_236  1
    a_27_11   full_original_Gini_254  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_8_0  unique_nonzero_owner_255  1
    service_0_8_0  service_visit_def_773  1
    service_0_8_0  free_load_conservation_774  -9
    service_0_8_0  original_T_including_depot_unload_822  1080
    service_0_8_1  unique_nonzero_owner_256  1
    service_0_8_1  service_visit_def_773  1
    service_0_8_1  free_load_conservation_774  -8
    service_0_8_1  original_T_including_depot_unload_822  960
    service_0_8_2  unique_nonzero_owner_257  1
    service_0_8_2  service_visit_def_773  1
    service_0_8_2  free_load_conservation_774  -7
    service_0_8_2  original_T_including_depot_unload_822  840
    service_0_8_3  unique_nonzero_owner_258  1
    service_0_8_3  service_visit_def_773  1
    service_0_8_3  free_load_conservation_774  -6
    service_0_8_3  original_T_including_depot_unload_822  720
    service_0_8_4  unique_nonzero_owner_259  1
    service_0_8_4  service_visit_def_773  1
    service_0_8_4  free_load_conservation_774  -5
    service_0_8_4  original_T_including_depot_unload_822  600
    service_0_8_5  unique_nonzero_owner_260  1
    service_0_8_5  service_visit_def_773  1
    service_0_8_5  free_load_conservation_774  -4
    service_0_8_5  original_T_including_depot_unload_822  480
    service_0_8_6  unique_nonzero_owner_261  1
    service_0_8_6  service_visit_def_773  1
    service_0_8_6  free_load_conservation_774  -3
    service_0_8_6  original_T_including_depot_unload_822  360
    service_0_8_7  unique_nonzero_owner_262  1
    service_0_8_7  service_visit_def_773  1
    service_0_8_7  free_load_conservation_774  -2
    service_0_8_7  original_T_including_depot_unload_822  240
    service_0_8_8  unique_nonzero_owner_263  1
    service_0_8_8  service_visit_def_773  1
    service_0_8_8  free_load_conservation_774  -1
    service_0_8_8  original_T_including_depot_unload_822  120
    service_0_8_10  unique_nonzero_owner_264  1
    service_0_8_10  service_visit_def_773  1
    service_0_8_10  free_load_conservation_774  1
    service_0_8_11  unique_nonzero_owner_265  1
    service_0_8_11  service_visit_def_773  1
    service_0_8_11  free_load_conservation_774  2
    service_0_8_12  unique_nonzero_owner_266  1
    service_0_8_12  service_visit_def_773  1
    service_0_8_12  free_load_conservation_774  3
    service_1_8_0  unique_nonzero_owner_255  1
    service_1_8_0  service_visit_def_1146  1
    service_1_8_0  free_load_conservation_1147  -9
    service_1_8_0  original_T_including_depot_unload_1193  1080
    service_1_8_1  unique_nonzero_owner_256  1
    service_1_8_1  service_visit_def_1146  1
    service_1_8_1  free_load_conservation_1147  -8
    service_1_8_1  original_T_including_depot_unload_1193  960
    service_1_8_2  unique_nonzero_owner_257  1
    service_1_8_2  service_visit_def_1146  1
    service_1_8_2  free_load_conservation_1147  -7
    service_1_8_2  original_T_including_depot_unload_1193  840
    service_1_8_3  unique_nonzero_owner_258  1
    service_1_8_3  service_visit_def_1146  1
    service_1_8_3  free_load_conservation_1147  -6
    service_1_8_3  original_T_including_depot_unload_1193  720
    service_1_8_4  unique_nonzero_owner_259  1
    service_1_8_4  service_visit_def_1146  1
    service_1_8_4  free_load_conservation_1147  -5
    service_1_8_4  original_T_including_depot_unload_1193  600
    service_1_8_5  unique_nonzero_owner_260  1
    service_1_8_5  service_visit_def_1146  1
    service_1_8_5  free_load_conservation_1147  -4
    service_1_8_5  original_T_including_depot_unload_1193  480
    service_1_8_6  unique_nonzero_owner_261  1
    service_1_8_6  service_visit_def_1146  1
    service_1_8_6  free_load_conservation_1147  -3
    service_1_8_6  original_T_including_depot_unload_1193  360
    service_1_8_7  unique_nonzero_owner_262  1
    service_1_8_7  service_visit_def_1146  1
    service_1_8_7  free_load_conservation_1147  -2
    service_1_8_7  original_T_including_depot_unload_1193  240
    service_1_8_8  unique_nonzero_owner_263  1
    service_1_8_8  service_visit_def_1146  1
    service_1_8_8  free_load_conservation_1147  -1
    service_1_8_8  original_T_including_depot_unload_1193  120
    service_1_8_10  unique_nonzero_owner_264  1
    service_1_8_10  service_visit_def_1146  1
    service_1_8_10  free_load_conservation_1147  1
    service_1_8_11  unique_nonzero_owner_265  1
    service_1_8_11  service_visit_def_1146  1
    service_1_8_11  free_load_conservation_1147  2
    service_1_8_12  unique_nonzero_owner_266  1
    service_1_8_12  service_visit_def_1146  1
    service_1_8_12  free_load_conservation_1147  3
    service_2_8_0  unique_nonzero_owner_255  1
    service_2_8_0  service_visit_def_1464  1
    service_2_8_0  free_load_conservation_1465  -9
    service_2_8_0  original_T_including_depot_unload_1510  1080
    service_2_8_1  unique_nonzero_owner_256  1
    service_2_8_1  service_visit_def_1464  1
    service_2_8_1  free_load_conservation_1465  -8
    service_2_8_1  original_T_including_depot_unload_1510  960
    service_2_8_2  unique_nonzero_owner_257  1
    service_2_8_2  service_visit_def_1464  1
    service_2_8_2  free_load_conservation_1465  -7
    service_2_8_2  original_T_including_depot_unload_1510  840
    service_2_8_3  unique_nonzero_owner_258  1
    service_2_8_3  service_visit_def_1464  1
    service_2_8_3  free_load_conservation_1465  -6
    service_2_8_3  original_T_including_depot_unload_1510  720
    service_2_8_4  unique_nonzero_owner_259  1
    service_2_8_4  service_visit_def_1464  1
    service_2_8_4  free_load_conservation_1465  -5
    service_2_8_4  original_T_including_depot_unload_1510  600
    service_2_8_5  unique_nonzero_owner_260  1
    service_2_8_5  service_visit_def_1464  1
    service_2_8_5  free_load_conservation_1465  -4
    service_2_8_5  original_T_including_depot_unload_1510  480
    service_2_8_6  unique_nonzero_owner_261  1
    service_2_8_6  service_visit_def_1464  1
    service_2_8_6  free_load_conservation_1465  -3
    service_2_8_6  original_T_including_depot_unload_1510  360
    service_2_8_7  unique_nonzero_owner_262  1
    service_2_8_7  service_visit_def_1464  1
    service_2_8_7  free_load_conservation_1465  -2
    service_2_8_7  original_T_including_depot_unload_1510  240
    service_2_8_8  unique_nonzero_owner_263  1
    service_2_8_8  service_visit_def_1464  1
    service_2_8_8  free_load_conservation_1465  -1
    service_2_8_8  original_T_including_depot_unload_1510  120
    service_2_8_10  unique_nonzero_owner_264  1
    service_2_8_10  service_visit_def_1464  1
    service_2_8_10  free_load_conservation_1465  1
    service_2_8_11  unique_nonzero_owner_265  1
    service_2_8_11  service_visit_def_1464  1
    service_2_8_11  free_load_conservation_1465  2
    service_2_8_12  unique_nonzero_owner_266  1
    service_2_8_12  service_visit_def_1464  1
    service_2_8_12  free_load_conservation_1465  3
    service_0_6_0  unique_nonzero_owner_267  1
    service_0_6_0  service_visit_def_779  1
    service_0_6_0  free_load_conservation_780  -6
    service_0_6_0  original_T_including_depot_unload_822  720
    service_0_6_1  unique_nonzero_owner_268  1
    service_0_6_1  service_visit_def_779  1
    service_0_6_1  free_load_conservation_780  -5
    service_0_6_1  original_T_including_depot_unload_822  600
    service_0_6_2  unique_nonzero_owner_269  1
    service_0_6_2  service_visit_def_779  1
    service_0_6_2  free_load_conservation_780  -4
    service_0_6_2  original_T_including_depot_unload_822  480
    service_0_6_3  unique_nonzero_owner_270  1
    service_0_6_3  service_visit_def_779  1
    service_0_6_3  free_load_conservation_780  -3
    service_0_6_3  original_T_including_depot_unload_822  360
    service_0_6_4  unique_nonzero_owner_271  1
    service_0_6_4  service_visit_def_779  1
    service_0_6_4  free_load_conservation_780  -2
    service_0_6_4  original_T_including_depot_unload_822  240
    service_0_6_5  unique_nonzero_owner_272  1
    service_0_6_5  service_visit_def_779  1
    service_0_6_5  free_load_conservation_780  -1
    service_0_6_5  original_T_including_depot_unload_822  120
    service_0_6_7  unique_nonzero_owner_273  1
    service_0_6_7  service_visit_def_779  1
    service_0_6_7  free_load_conservation_780  1
    service_0_6_8  unique_nonzero_owner_274  1
    service_0_6_8  service_visit_def_779  1
    service_0_6_8  free_load_conservation_780  2
    service_1_6_0  unique_nonzero_owner_267  1
    service_1_6_0  service_visit_def_1152  1
    service_1_6_0  free_load_conservation_1153  -6
    service_1_6_0  original_T_including_depot_unload_1193  720
    service_1_6_1  unique_nonzero_owner_268  1
    service_1_6_1  service_visit_def_1152  1
    service_1_6_1  free_load_conservation_1153  -5
    service_1_6_1  original_T_including_depot_unload_1193  600
    service_1_6_2  unique_nonzero_owner_269  1
    service_1_6_2  service_visit_def_1152  1
    service_1_6_2  free_load_conservation_1153  -4
    service_1_6_2  original_T_including_depot_unload_1193  480
    service_1_6_3  unique_nonzero_owner_270  1
    service_1_6_3  service_visit_def_1152  1
    service_1_6_3  free_load_conservation_1153  -3
    service_1_6_3  original_T_including_depot_unload_1193  360
    service_1_6_4  unique_nonzero_owner_271  1
    service_1_6_4  service_visit_def_1152  1
    service_1_6_4  free_load_conservation_1153  -2
    service_1_6_4  original_T_including_depot_unload_1193  240
    service_1_6_5  unique_nonzero_owner_272  1
    service_1_6_5  service_visit_def_1152  1
    service_1_6_5  free_load_conservation_1153  -1
    service_1_6_5  original_T_including_depot_unload_1193  120
    service_1_6_7  unique_nonzero_owner_273  1
    service_1_6_7  service_visit_def_1152  1
    service_1_6_7  free_load_conservation_1153  1
    service_1_6_8  unique_nonzero_owner_274  1
    service_1_6_8  service_visit_def_1152  1
    service_1_6_8  free_load_conservation_1153  2
    service_2_6_0  unique_nonzero_owner_267  1
    service_2_6_0  service_visit_def_1470  1
    service_2_6_0  free_load_conservation_1471  -6
    service_2_6_0  original_T_including_depot_unload_1510  720
    service_2_6_1  unique_nonzero_owner_268  1
    service_2_6_1  service_visit_def_1470  1
    service_2_6_1  free_load_conservation_1471  -5
    service_2_6_1  original_T_including_depot_unload_1510  600
    service_2_6_2  unique_nonzero_owner_269  1
    service_2_6_2  service_visit_def_1470  1
    service_2_6_2  free_load_conservation_1471  -4
    service_2_6_2  original_T_including_depot_unload_1510  480
    service_2_6_3  unique_nonzero_owner_270  1
    service_2_6_3  service_visit_def_1470  1
    service_2_6_3  free_load_conservation_1471  -3
    service_2_6_3  original_T_including_depot_unload_1510  360
    service_2_6_4  unique_nonzero_owner_271  1
    service_2_6_4  service_visit_def_1470  1
    service_2_6_4  free_load_conservation_1471  -2
    service_2_6_4  original_T_including_depot_unload_1510  240
    service_2_6_5  unique_nonzero_owner_272  1
    service_2_6_5  service_visit_def_1470  1
    service_2_6_5  free_load_conservation_1471  -1
    service_2_6_5  original_T_including_depot_unload_1510  120
    service_2_6_7  unique_nonzero_owner_273  1
    service_2_6_7  service_visit_def_1470  1
    service_2_6_7  free_load_conservation_1471  1
    service_2_6_8  unique_nonzero_owner_274  1
    service_2_6_8  service_visit_def_1470  1
    service_2_6_8  free_load_conservation_1471  2
    service_0_34_0  unique_nonzero_owner_275  1
    service_0_34_0  service_visit_def_785  1
    service_0_34_0  free_load_conservation_786  -2
    service_0_34_0  original_T_including_depot_unload_822  240
    service_0_34_1  unique_nonzero_owner_276  1
    service_0_34_1  service_visit_def_785  1
    service_0_34_1  free_load_conservation_786  -1
    service_0_34_1  original_T_including_depot_unload_822  120
    service_0_34_3  unique_nonzero_owner_277  1
    service_0_34_3  service_visit_def_785  1
    service_0_34_3  free_load_conservation_786  1
    service_0_34_4  unique_nonzero_owner_278  1
    service_0_34_4  service_visit_def_785  1
    service_0_34_4  free_load_conservation_786  2
    service_0_34_5  unique_nonzero_owner_279  1
    service_0_34_5  service_visit_def_785  1
    service_0_34_5  free_load_conservation_786  3
    service_0_34_6  unique_nonzero_owner_280  1
    service_0_34_6  service_visit_def_785  1
    service_0_34_6  free_load_conservation_786  4
    service_0_34_7  unique_nonzero_owner_281  1
    service_0_34_7  service_visit_def_785  1
    service_0_34_7  free_load_conservation_786  5
    service_0_34_8  unique_nonzero_owner_282  1
    service_0_34_8  service_visit_def_785  1
    service_0_34_8  free_load_conservation_786  6
    service_0_34_9  unique_nonzero_owner_283  1
    service_0_34_9  service_visit_def_785  1
    service_0_34_9  free_load_conservation_786  7
    service_0_34_10  unique_nonzero_owner_284  1
    service_0_34_10  service_visit_def_785  1
    service_0_34_10  free_load_conservation_786  8
    service_0_34_11  unique_nonzero_owner_285  1
    service_0_34_11  service_visit_def_785  1
    service_0_34_11  free_load_conservation_786  9
    service_0_34_12  unique_nonzero_owner_286  1
    service_0_34_12  service_visit_def_785  1
    service_0_34_12  free_load_conservation_786  10
    service_0_34_13  unique_nonzero_owner_287  1
    service_0_34_13  service_visit_def_785  1
    service_0_34_13  free_load_conservation_786  11
    service_0_34_14  unique_nonzero_owner_288  1
    service_0_34_14  service_visit_def_785  1
    service_0_34_14  free_load_conservation_786  12
    service_0_34_15  unique_nonzero_owner_289  1
    service_0_34_15  service_visit_def_785  1
    service_0_34_15  free_load_conservation_786  13
    service_1_34_0  unique_nonzero_owner_275  1
    service_1_34_0  service_visit_def_1158  1
    service_1_34_0  free_load_conservation_1159  -2
    service_1_34_0  original_T_including_depot_unload_1193  240
    service_1_34_1  unique_nonzero_owner_276  1
    service_1_34_1  service_visit_def_1158  1
    service_1_34_1  free_load_conservation_1159  -1
    service_1_34_1  original_T_including_depot_unload_1193  120
    service_1_34_3  unique_nonzero_owner_277  1
    service_1_34_3  service_visit_def_1158  1
    service_1_34_3  free_load_conservation_1159  1
    service_1_34_4  unique_nonzero_owner_278  1
    service_1_34_4  service_visit_def_1158  1
    service_1_34_4  free_load_conservation_1159  2
    service_1_34_5  unique_nonzero_owner_279  1
    service_1_34_5  service_visit_def_1158  1
    service_1_34_5  free_load_conservation_1159  3
    service_1_34_6  unique_nonzero_owner_280  1
    service_1_34_6  service_visit_def_1158  1
    service_1_34_6  free_load_conservation_1159  4
    service_1_34_7  unique_nonzero_owner_281  1
    service_1_34_7  service_visit_def_1158  1
    service_1_34_7  free_load_conservation_1159  5
    service_1_34_8  unique_nonzero_owner_282  1
    service_1_34_8  service_visit_def_1158  1
    service_1_34_8  free_load_conservation_1159  6
    service_1_34_9  unique_nonzero_owner_283  1
    service_1_34_9  service_visit_def_1158  1
    service_1_34_9  free_load_conservation_1159  7
    service_1_34_10  unique_nonzero_owner_284  1
    service_1_34_10  service_visit_def_1158  1
    service_1_34_10  free_load_conservation_1159  8
    service_1_34_11  unique_nonzero_owner_285  1
    service_1_34_11  service_visit_def_1158  1
    service_1_34_11  free_load_conservation_1159  9
    service_1_34_12  unique_nonzero_owner_286  1
    service_1_34_12  service_visit_def_1158  1
    service_1_34_12  free_load_conservation_1159  10
    service_1_34_13  unique_nonzero_owner_287  1
    service_1_34_13  service_visit_def_1158  1
    service_1_34_13  free_load_conservation_1159  11
    service_1_34_14  unique_nonzero_owner_288  1
    service_1_34_14  service_visit_def_1158  1
    service_1_34_14  free_load_conservation_1159  12
    service_1_34_15  unique_nonzero_owner_289  1
    service_1_34_15  service_visit_def_1158  1
    service_1_34_15  free_load_conservation_1159  13
    service_2_34_0  unique_nonzero_owner_275  1
    service_2_34_0  service_visit_def_1476  1
    service_2_34_0  free_load_conservation_1477  -2
    service_2_34_0  original_T_including_depot_unload_1510  240
    service_2_34_1  unique_nonzero_owner_276  1
    service_2_34_1  service_visit_def_1476  1
    service_2_34_1  free_load_conservation_1477  -1
    service_2_34_1  original_T_including_depot_unload_1510  120
    service_2_34_3  unique_nonzero_owner_277  1
    service_2_34_3  service_visit_def_1476  1
    service_2_34_3  free_load_conservation_1477  1
    service_2_34_4  unique_nonzero_owner_278  1
    service_2_34_4  service_visit_def_1476  1
    service_2_34_4  free_load_conservation_1477  2
    service_2_34_5  unique_nonzero_owner_279  1
    service_2_34_5  service_visit_def_1476  1
    service_2_34_5  free_load_conservation_1477  3
    service_2_34_6  unique_nonzero_owner_280  1
    service_2_34_6  service_visit_def_1476  1
    service_2_34_6  free_load_conservation_1477  4
    service_2_34_7  unique_nonzero_owner_281  1
    service_2_34_7  service_visit_def_1476  1
    service_2_34_7  free_load_conservation_1477  5
    service_2_34_8  unique_nonzero_owner_282  1
    service_2_34_8  service_visit_def_1476  1
    service_2_34_8  free_load_conservation_1477  6
    service_2_34_9  unique_nonzero_owner_283  1
    service_2_34_9  service_visit_def_1476  1
    service_2_34_9  free_load_conservation_1477  7
    service_2_34_10  unique_nonzero_owner_284  1
    service_2_34_10  service_visit_def_1476  1
    service_2_34_10  free_load_conservation_1477  8
    service_2_34_11  unique_nonzero_owner_285  1
    service_2_34_11  service_visit_def_1476  1
    service_2_34_11  free_load_conservation_1477  9
    service_2_34_12  unique_nonzero_owner_286  1
    service_2_34_12  service_visit_def_1476  1
    service_2_34_12  free_load_conservation_1477  10
    service_2_34_13  unique_nonzero_owner_287  1
    service_2_34_13  service_visit_def_1476  1
    service_2_34_13  free_load_conservation_1477  11
    service_2_34_14  unique_nonzero_owner_288  1
    service_2_34_14  service_visit_def_1476  1
    service_2_34_14  free_load_conservation_1477  12
    service_2_34_15  unique_nonzero_owner_289  1
    service_2_34_15  service_visit_def_1476  1
    service_2_34_15  free_load_conservation_1477  13
    service_0_9_0  unique_nonzero_owner_290  1
    service_0_9_0  service_visit_def_791  1
    service_0_9_0  free_load_conservation_792  -2
    service_0_9_0  original_T_including_depot_unload_822  240
    service_0_9_1  unique_nonzero_owner_291  1
    service_0_9_1  service_visit_def_791  1
    service_0_9_1  free_load_conservation_792  -1
    service_0_9_1  original_T_including_depot_unload_822  120
    service_0_9_3  unique_nonzero_owner_292  1
    service_0_9_3  service_visit_def_791  1
    service_0_9_3  free_load_conservation_792  1
    service_0_9_4  unique_nonzero_owner_293  1
    service_0_9_4  service_visit_def_791  1
    service_0_9_4  free_load_conservation_792  2
    service_0_9_5  unique_nonzero_owner_294  1
    service_0_9_5  service_visit_def_791  1
    service_0_9_5  free_load_conservation_792  3
    service_0_9_6  unique_nonzero_owner_295  1
    service_0_9_6  service_visit_def_791  1
    service_0_9_6  free_load_conservation_792  4
    service_0_9_7  unique_nonzero_owner_296  1
    service_0_9_7  service_visit_def_791  1
    service_0_9_7  free_load_conservation_792  5
    service_0_9_8  unique_nonzero_owner_297  1
    service_0_9_8  service_visit_def_791  1
    service_0_9_8  free_load_conservation_792  6
    service_0_9_9  unique_nonzero_owner_298  1
    service_0_9_9  service_visit_def_791  1
    service_0_9_9  free_load_conservation_792  7
    service_0_9_10  unique_nonzero_owner_299  1
    service_0_9_10  service_visit_def_791  1
    service_0_9_10  free_load_conservation_792  8
    service_1_9_0  unique_nonzero_owner_290  1
    service_1_9_0  service_visit_def_1164  1
    service_1_9_0  free_load_conservation_1165  -2
    service_1_9_0  original_T_including_depot_unload_1193  240
    service_1_9_1  unique_nonzero_owner_291  1
    service_1_9_1  service_visit_def_1164  1
    service_1_9_1  free_load_conservation_1165  -1
    service_1_9_1  original_T_including_depot_unload_1193  120
    service_1_9_3  unique_nonzero_owner_292  1
    service_1_9_3  service_visit_def_1164  1
    service_1_9_3  free_load_conservation_1165  1
    service_1_9_4  unique_nonzero_owner_293  1
    service_1_9_4  service_visit_def_1164  1
    service_1_9_4  free_load_conservation_1165  2
    service_1_9_5  unique_nonzero_owner_294  1
    service_1_9_5  service_visit_def_1164  1
    service_1_9_5  free_load_conservation_1165  3
    service_1_9_6  unique_nonzero_owner_295  1
    service_1_9_6  service_visit_def_1164  1
    service_1_9_6  free_load_conservation_1165  4
    service_1_9_7  unique_nonzero_owner_296  1
    service_1_9_7  service_visit_def_1164  1
    service_1_9_7  free_load_conservation_1165  5
    service_1_9_8  unique_nonzero_owner_297  1
    service_1_9_8  service_visit_def_1164  1
    service_1_9_8  free_load_conservation_1165  6
    service_1_9_9  unique_nonzero_owner_298  1
    service_1_9_9  service_visit_def_1164  1
    service_1_9_9  free_load_conservation_1165  7
    service_1_9_10  unique_nonzero_owner_299  1
    service_1_9_10  service_visit_def_1164  1
    service_1_9_10  free_load_conservation_1165  8
    service_2_9_0  unique_nonzero_owner_290  1
    service_2_9_0  service_visit_def_1482  1
    service_2_9_0  free_load_conservation_1483  -2
    service_2_9_0  original_T_including_depot_unload_1510  240
    service_2_9_1  unique_nonzero_owner_291  1
    service_2_9_1  service_visit_def_1482  1
    service_2_9_1  free_load_conservation_1483  -1
    service_2_9_1  original_T_including_depot_unload_1510  120
    service_2_9_3  unique_nonzero_owner_292  1
    service_2_9_3  service_visit_def_1482  1
    service_2_9_3  free_load_conservation_1483  1
    service_2_9_4  unique_nonzero_owner_293  1
    service_2_9_4  service_visit_def_1482  1
    service_2_9_4  free_load_conservation_1483  2
    service_2_9_5  unique_nonzero_owner_294  1
    service_2_9_5  service_visit_def_1482  1
    service_2_9_5  free_load_conservation_1483  3
    service_2_9_6  unique_nonzero_owner_295  1
    service_2_9_6  service_visit_def_1482  1
    service_2_9_6  free_load_conservation_1483  4
    service_2_9_7  unique_nonzero_owner_296  1
    service_2_9_7  service_visit_def_1482  1
    service_2_9_7  free_load_conservation_1483  5
    service_2_9_8  unique_nonzero_owner_297  1
    service_2_9_8  service_visit_def_1482  1
    service_2_9_8  free_load_conservation_1483  6
    service_2_9_9  unique_nonzero_owner_298  1
    service_2_9_9  service_visit_def_1482  1
    service_2_9_9  free_load_conservation_1483  7
    service_2_9_10  unique_nonzero_owner_299  1
    service_2_9_10  service_visit_def_1482  1
    service_2_9_10  free_load_conservation_1483  8
    service_0_29_0  unique_nonzero_owner_300  1
    service_0_29_0  service_visit_def_797  1
    service_0_29_0  free_load_conservation_798  -1
    service_0_29_0  original_T_including_depot_unload_822  120
    service_0_29_2  unique_nonzero_owner_301  1
    service_0_29_2  service_visit_def_797  1
    service_0_29_2  free_load_conservation_798  1
    service_0_29_3  unique_nonzero_owner_302  1
    service_0_29_3  service_visit_def_797  1
    service_0_29_3  free_load_conservation_798  2
    service_0_29_4  unique_nonzero_owner_303  1
    service_0_29_4  service_visit_def_797  1
    service_0_29_4  free_load_conservation_798  3
    service_0_29_5  unique_nonzero_owner_304  1
    service_0_29_5  service_visit_def_797  1
    service_0_29_5  free_load_conservation_798  4
    service_0_29_6  unique_nonzero_owner_305  1
    service_0_29_6  service_visit_def_797  1
    service_0_29_6  free_load_conservation_798  5
    service_0_29_7  unique_nonzero_owner_306  1
    service_0_29_7  service_visit_def_797  1
    service_0_29_7  free_load_conservation_798  6
    service_0_29_8  unique_nonzero_owner_307  1
    service_0_29_8  service_visit_def_797  1
    service_0_29_8  free_load_conservation_798  7
    service_0_29_9  unique_nonzero_owner_308  1
    service_0_29_9  service_visit_def_797  1
    service_0_29_9  free_load_conservation_798  8
    service_0_29_10  unique_nonzero_owner_309  1
    service_0_29_10  service_visit_def_797  1
    service_0_29_10  free_load_conservation_798  9
    service_1_29_0  unique_nonzero_owner_300  1
    service_1_29_0  service_visit_def_1170  1
    service_1_29_0  free_load_conservation_1171  -1
    service_1_29_0  original_T_including_depot_unload_1193  120
    service_1_29_2  unique_nonzero_owner_301  1
    service_1_29_2  service_visit_def_1170  1
    service_1_29_2  free_load_conservation_1171  1
    service_1_29_3  unique_nonzero_owner_302  1
    service_1_29_3  service_visit_def_1170  1
    service_1_29_3  free_load_conservation_1171  2
    service_1_29_4  unique_nonzero_owner_303  1
    service_1_29_4  service_visit_def_1170  1
    service_1_29_4  free_load_conservation_1171  3
    service_1_29_5  unique_nonzero_owner_304  1
    service_1_29_5  service_visit_def_1170  1
    service_1_29_5  free_load_conservation_1171  4
    service_1_29_6  unique_nonzero_owner_305  1
    service_1_29_6  service_visit_def_1170  1
    service_1_29_6  free_load_conservation_1171  5
    service_1_29_7  unique_nonzero_owner_306  1
    service_1_29_7  service_visit_def_1170  1
    service_1_29_7  free_load_conservation_1171  6
    service_1_29_8  unique_nonzero_owner_307  1
    service_1_29_8  service_visit_def_1170  1
    service_1_29_8  free_load_conservation_1171  7
    service_1_29_9  unique_nonzero_owner_308  1
    service_1_29_9  service_visit_def_1170  1
    service_1_29_9  free_load_conservation_1171  8
    service_1_29_10  unique_nonzero_owner_309  1
    service_1_29_10  service_visit_def_1170  1
    service_1_29_10  free_load_conservation_1171  9
    service_2_29_0  unique_nonzero_owner_300  1
    service_2_29_0  service_visit_def_1488  1
    service_2_29_0  free_load_conservation_1489  -1
    service_2_29_0  original_T_including_depot_unload_1510  120
    service_2_29_2  unique_nonzero_owner_301  1
    service_2_29_2  service_visit_def_1488  1
    service_2_29_2  free_load_conservation_1489  1
    service_2_29_3  unique_nonzero_owner_302  1
    service_2_29_3  service_visit_def_1488  1
    service_2_29_3  free_load_conservation_1489  2
    service_2_29_4  unique_nonzero_owner_303  1
    service_2_29_4  service_visit_def_1488  1
    service_2_29_4  free_load_conservation_1489  3
    service_2_29_5  unique_nonzero_owner_304  1
    service_2_29_5  service_visit_def_1488  1
    service_2_29_5  free_load_conservation_1489  4
    service_2_29_6  unique_nonzero_owner_305  1
    service_2_29_6  service_visit_def_1488  1
    service_2_29_6  free_load_conservation_1489  5
    service_2_29_7  unique_nonzero_owner_306  1
    service_2_29_7  service_visit_def_1488  1
    service_2_29_7  free_load_conservation_1489  6
    service_2_29_8  unique_nonzero_owner_307  1
    service_2_29_8  service_visit_def_1488  1
    service_2_29_8  free_load_conservation_1489  7
    service_2_29_9  unique_nonzero_owner_308  1
    service_2_29_9  service_visit_def_1488  1
    service_2_29_9  free_load_conservation_1489  8
    service_2_29_10  unique_nonzero_owner_309  1
    service_2_29_10  service_visit_def_1488  1
    service_2_29_10  free_load_conservation_1489  9
    service_0_10_0  unique_nonzero_owner_310  1
    service_0_10_0  service_visit_def_803  1
    service_0_10_0  free_load_conservation_804  -4
    service_0_10_0  original_T_including_depot_unload_822  480
    service_0_10_1  unique_nonzero_owner_311  1
    service_0_10_1  service_visit_def_803  1
    service_0_10_1  free_load_conservation_804  -3
    service_0_10_1  original_T_including_depot_unload_822  360
    service_0_10_2  unique_nonzero_owner_312  1
    service_0_10_2  service_visit_def_803  1
    service_0_10_2  free_load_conservation_804  -2
    service_0_10_2  original_T_including_depot_unload_822  240
    service_0_10_3  unique_nonzero_owner_313  1
    service_0_10_3  service_visit_def_803  1
    service_0_10_3  free_load_conservation_804  -1
    service_0_10_3  original_T_including_depot_unload_822  120
    service_0_10_5  unique_nonzero_owner_314  1
    service_0_10_5  service_visit_def_803  1
    service_0_10_5  free_load_conservation_804  1
    service_0_10_6  unique_nonzero_owner_315  1
    service_0_10_6  service_visit_def_803  1
    service_0_10_6  free_load_conservation_804  2
    service_1_10_0  unique_nonzero_owner_310  1
    service_1_10_0  service_visit_def_1176  1
    service_1_10_0  free_load_conservation_1177  -4
    service_1_10_0  original_T_including_depot_unload_1193  480
    service_1_10_1  unique_nonzero_owner_311  1
    service_1_10_1  service_visit_def_1176  1
    service_1_10_1  free_load_conservation_1177  -3
    service_1_10_1  original_T_including_depot_unload_1193  360
    service_1_10_2  unique_nonzero_owner_312  1
    service_1_10_2  service_visit_def_1176  1
    service_1_10_2  free_load_conservation_1177  -2
    service_1_10_2  original_T_including_depot_unload_1193  240
    service_1_10_3  unique_nonzero_owner_313  1
    service_1_10_3  service_visit_def_1176  1
    service_1_10_3  free_load_conservation_1177  -1
    service_1_10_3  original_T_including_depot_unload_1193  120
    service_1_10_5  unique_nonzero_owner_314  1
    service_1_10_5  service_visit_def_1176  1
    service_1_10_5  free_load_conservation_1177  1
    service_1_10_6  unique_nonzero_owner_315  1
    service_1_10_6  service_visit_def_1176  1
    service_1_10_6  free_load_conservation_1177  2
    service_2_10_0  unique_nonzero_owner_310  1
    service_2_10_0  service_visit_def_1494  1
    service_2_10_0  free_load_conservation_1495  -4
    service_2_10_0  original_T_including_depot_unload_1510  480
    service_2_10_1  unique_nonzero_owner_311  1
    service_2_10_1  service_visit_def_1494  1
    service_2_10_1  free_load_conservation_1495  -3
    service_2_10_1  original_T_including_depot_unload_1510  360
    service_2_10_2  unique_nonzero_owner_312  1
    service_2_10_2  service_visit_def_1494  1
    service_2_10_2  free_load_conservation_1495  -2
    service_2_10_2  original_T_including_depot_unload_1510  240
    service_2_10_3  unique_nonzero_owner_313  1
    service_2_10_3  service_visit_def_1494  1
    service_2_10_3  free_load_conservation_1495  -1
    service_2_10_3  original_T_including_depot_unload_1510  120
    service_2_10_5  unique_nonzero_owner_314  1
    service_2_10_5  service_visit_def_1494  1
    service_2_10_5  free_load_conservation_1495  1
    service_2_10_6  unique_nonzero_owner_315  1
    service_2_10_6  service_visit_def_1494  1
    service_2_10_6  free_load_conservation_1495  2
    service_0_27_1  unique_nonzero_owner_316  1
    service_0_27_1  service_visit_def_809  1
    service_0_27_1  free_load_conservation_810  1
    service_0_27_2  unique_nonzero_owner_317  1
    service_0_27_2  service_visit_def_809  1
    service_0_27_2  free_load_conservation_810  2
    service_0_27_3  unique_nonzero_owner_318  1
    service_0_27_3  service_visit_def_809  1
    service_0_27_3  free_load_conservation_810  3
    service_0_27_4  unique_nonzero_owner_319  1
    service_0_27_4  service_visit_def_809  1
    service_0_27_4  free_load_conservation_810  4
    service_0_27_5  unique_nonzero_owner_320  1
    service_0_27_5  service_visit_def_809  1
    service_0_27_5  free_load_conservation_810  5
    service_0_27_6  unique_nonzero_owner_321  1
    service_0_27_6  service_visit_def_809  1
    service_0_27_6  free_load_conservation_810  6
    service_1_27_1  unique_nonzero_owner_316  1
    service_1_27_1  service_visit_def_1182  1
    service_1_27_1  free_load_conservation_1183  1
    service_1_27_2  unique_nonzero_owner_317  1
    service_1_27_2  service_visit_def_1182  1
    service_1_27_2  free_load_conservation_1183  2
    service_1_27_3  unique_nonzero_owner_318  1
    service_1_27_3  service_visit_def_1182  1
    service_1_27_3  free_load_conservation_1183  3
    service_1_27_4  unique_nonzero_owner_319  1
    service_1_27_4  service_visit_def_1182  1
    service_1_27_4  free_load_conservation_1183  4
    service_1_27_5  unique_nonzero_owner_320  1
    service_1_27_5  service_visit_def_1182  1
    service_1_27_5  free_load_conservation_1183  5
    service_1_27_6  unique_nonzero_owner_321  1
    service_1_27_6  service_visit_def_1182  1
    service_1_27_6  free_load_conservation_1183  6
    service_2_27_1  unique_nonzero_owner_316  1
    service_2_27_1  service_visit_def_1500  1
    service_2_27_1  free_load_conservation_1501  1
    service_2_27_2  unique_nonzero_owner_317  1
    service_2_27_2  service_visit_def_1500  1
    service_2_27_2  free_load_conservation_1501  2
    service_2_27_3  unique_nonzero_owner_318  1
    service_2_27_3  service_visit_def_1500  1
    service_2_27_3  free_load_conservation_1501  3
    service_2_27_4  unique_nonzero_owner_319  1
    service_2_27_4  service_visit_def_1500  1
    service_2_27_4  free_load_conservation_1501  4
    service_2_27_5  unique_nonzero_owner_320  1
    service_2_27_5  service_visit_def_1500  1
    service_2_27_5  free_load_conservation_1501  5
    service_2_27_6  unique_nonzero_owner_321  1
    service_2_27_6  service_visit_def_1500  1
    service_2_27_6  free_load_conservation_1501  6
    service_0_11_0  unique_nonzero_owner_322  1
    service_0_11_0  service_visit_def_815  1
    service_0_11_0  free_load_conservation_816  -8
    service_0_11_0  original_T_including_depot_unload_822  960
    service_0_11_1  unique_nonzero_owner_323  1
    service_0_11_1  service_visit_def_815  1
    service_0_11_1  free_load_conservation_816  -7
    service_0_11_1  original_T_including_depot_unload_822  840
    service_0_11_2  unique_nonzero_owner_324  1
    service_0_11_2  service_visit_def_815  1
    service_0_11_2  free_load_conservation_816  -6
    service_0_11_2  original_T_including_depot_unload_822  720
    service_0_11_3  unique_nonzero_owner_325  1
    service_0_11_3  service_visit_def_815  1
    service_0_11_3  free_load_conservation_816  -5
    service_0_11_3  original_T_including_depot_unload_822  600
    service_0_11_4  unique_nonzero_owner_326  1
    service_0_11_4  service_visit_def_815  1
    service_0_11_4  free_load_conservation_816  -4
    service_0_11_4  original_T_including_depot_unload_822  480
    service_0_11_5  unique_nonzero_owner_327  1
    service_0_11_5  service_visit_def_815  1
    service_0_11_5  free_load_conservation_816  -3
    service_0_11_5  original_T_including_depot_unload_822  360
    service_0_11_6  unique_nonzero_owner_328  1
    service_0_11_6  service_visit_def_815  1
    service_0_11_6  free_load_conservation_816  -2
    service_0_11_6  original_T_including_depot_unload_822  240
    service_0_11_7  unique_nonzero_owner_329  1
    service_0_11_7  service_visit_def_815  1
    service_0_11_7  free_load_conservation_816  -1
    service_0_11_7  original_T_including_depot_unload_822  120
    service_0_11_9  unique_nonzero_owner_330  1
    service_0_11_9  service_visit_def_815  1
    service_0_11_9  free_load_conservation_816  1
    service_0_11_10  unique_nonzero_owner_331  1
    service_0_11_10  service_visit_def_815  1
    service_0_11_10  free_load_conservation_816  2
    service_1_11_0  unique_nonzero_owner_322  1
    service_1_11_0  service_visit_def_1188  1
    service_1_11_0  free_load_conservation_1189  -8
    service_1_11_0  original_T_including_depot_unload_1193  960
    service_1_11_1  unique_nonzero_owner_323  1
    service_1_11_1  service_visit_def_1188  1
    service_1_11_1  free_load_conservation_1189  -7
    service_1_11_1  original_T_including_depot_unload_1193  840
    service_1_11_2  unique_nonzero_owner_324  1
    service_1_11_2  service_visit_def_1188  1
    service_1_11_2  free_load_conservation_1189  -6
    service_1_11_2  original_T_including_depot_unload_1193  720
    service_1_11_3  unique_nonzero_owner_325  1
    service_1_11_3  service_visit_def_1188  1
    service_1_11_3  free_load_conservation_1189  -5
    service_1_11_3  original_T_including_depot_unload_1193  600
    service_1_11_4  unique_nonzero_owner_326  1
    service_1_11_4  service_visit_def_1188  1
    service_1_11_4  free_load_conservation_1189  -4
    service_1_11_4  original_T_including_depot_unload_1193  480
    service_1_11_5  unique_nonzero_owner_327  1
    service_1_11_5  service_visit_def_1188  1
    service_1_11_5  free_load_conservation_1189  -3
    service_1_11_5  original_T_including_depot_unload_1193  360
    service_1_11_6  unique_nonzero_owner_328  1
    service_1_11_6  service_visit_def_1188  1
    service_1_11_6  free_load_conservation_1189  -2
    service_1_11_6  original_T_including_depot_unload_1193  240
    service_1_11_7  unique_nonzero_owner_329  1
    service_1_11_7  service_visit_def_1188  1
    service_1_11_7  free_load_conservation_1189  -1
    service_1_11_7  original_T_including_depot_unload_1193  120
    service_1_11_9  unique_nonzero_owner_330  1
    service_1_11_9  service_visit_def_1188  1
    service_1_11_9  free_load_conservation_1189  1
    service_1_11_10  unique_nonzero_owner_331  1
    service_1_11_10  service_visit_def_1188  1
    service_1_11_10  free_load_conservation_1189  2
    service_2_11_0  unique_nonzero_owner_322  1
    service_2_11_0  service_visit_def_1506  1
    service_2_11_0  free_load_conservation_1507  -8
    service_2_11_0  original_T_including_depot_unload_1510  960
    service_2_11_1  unique_nonzero_owner_323  1
    service_2_11_1  service_visit_def_1506  1
    service_2_11_1  free_load_conservation_1507  -7
    service_2_11_1  original_T_including_depot_unload_1510  840
    service_2_11_2  unique_nonzero_owner_324  1
    service_2_11_2  service_visit_def_1506  1
    service_2_11_2  free_load_conservation_1507  -6
    service_2_11_2  original_T_including_depot_unload_1510  720
    service_2_11_3  unique_nonzero_owner_325  1
    service_2_11_3  service_visit_def_1506  1
    service_2_11_3  free_load_conservation_1507  -5
    service_2_11_3  original_T_including_depot_unload_1510  600
    service_2_11_4  unique_nonzero_owner_326  1
    service_2_11_4  service_visit_def_1506  1
    service_2_11_4  free_load_conservation_1507  -4
    service_2_11_4  original_T_including_depot_unload_1510  480
    service_2_11_5  unique_nonzero_owner_327  1
    service_2_11_5  service_visit_def_1506  1
    service_2_11_5  free_load_conservation_1507  -3
    service_2_11_5  original_T_including_depot_unload_1510  360
    service_2_11_6  unique_nonzero_owner_328  1
    service_2_11_6  service_visit_def_1506  1
    service_2_11_6  free_load_conservation_1507  -2
    service_2_11_6  original_T_including_depot_unload_1510  240
    service_2_11_7  unique_nonzero_owner_329  1
    service_2_11_7  service_visit_def_1506  1
    service_2_11_7  free_load_conservation_1507  -1
    service_2_11_7  original_T_including_depot_unload_1510  120
    service_2_11_9  unique_nonzero_owner_330  1
    service_2_11_9  service_visit_def_1506  1
    service_2_11_9  free_load_conservation_1507  1
    service_2_11_10  unique_nonzero_owner_331  1
    service_2_11_10  service_visit_def_1506  1
    service_2_11_10  free_load_conservation_1507  2
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_727  -1
    visit_0_1  in_degree_728  -1
    visit_0_1  order_active_lb_729  -1
    visit_0_1  order_active_ub_730  -14
    order_0_1  connected_order_arc_349  -1
    order_0_1  connected_order_arc_351  -1
    order_0_1  connected_order_arc_353  -1
    order_0_1  connected_order_arc_355  -1
    order_0_1  connected_order_arc_357  -1
    order_0_1  connected_order_arc_359  -1
    order_0_1  connected_order_arc_361  -1
    order_0_1  connected_order_arc_363  -1
    order_0_1  connected_order_arc_365  -1
    order_0_1  connected_order_arc_367  -1
    order_0_1  connected_order_arc_369  -1
    order_0_1  connected_order_arc_371  -1
    order_0_1  connected_order_arc_373  -1
    order_0_1  connected_order_arc_376  1
    order_0_1  connected_order_arc_403  1
    order_0_1  connected_order_arc_430  1
    order_0_1  connected_order_arc_457  1
    order_0_1  connected_order_arc_484  1
    order_0_1  connected_order_arc_511  1
    order_0_1  connected_order_arc_538  1
    order_0_1  connected_order_arc_565  1
    order_0_1  connected_order_arc_592  1
    order_0_1  connected_order_arc_619  1
    order_0_1  connected_order_arc_646  1
    order_0_1  connected_order_arc_673  1
    order_0_1  connected_order_arc_700  1
    order_0_1  order_active_lb_729  1
    order_0_1  order_active_ub_730  1
    order_0_1  fixed_segment_relative_order_817  -1
    visit_0_2  out_degree_734  -1
    visit_0_2  in_degree_735  -1
    visit_0_2  order_active_lb_736  -1
    visit_0_2  order_active_ub_737  -14
    order_0_2  connected_order_arc_349  1
    order_0_2  connected_order_arc_376  -1
    order_0_2  connected_order_arc_378  -1
    order_0_2  connected_order_arc_380  -1
    order_0_2  connected_order_arc_382  -1
    order_0_2  connected_order_arc_384  -1
    order_0_2  connected_order_arc_386  -1
    order_0_2  connected_order_arc_388  -1
    order_0_2  connected_order_arc_390  -1
    order_0_2  connected_order_arc_392  -1
    order_0_2  connected_order_arc_394  -1
    order_0_2  connected_order_arc_396  -1
    order_0_2  connected_order_arc_398  -1
    order_0_2  connected_order_arc_400  -1
    order_0_2  connected_order_arc_405  1
    order_0_2  connected_order_arc_432  1
    order_0_2  connected_order_arc_459  1
    order_0_2  connected_order_arc_486  1
    order_0_2  connected_order_arc_513  1
    order_0_2  connected_order_arc_540  1
    order_0_2  connected_order_arc_567  1
    order_0_2  connected_order_arc_594  1
    order_0_2  connected_order_arc_621  1
    order_0_2  connected_order_arc_648  1
    order_0_2  connected_order_arc_675  1
    order_0_2  connected_order_arc_702  1
    order_0_2  order_active_lb_736  1
    order_0_2  order_active_ub_737  1
    order_0_2  fixed_segment_relative_order_817  1
    order_0_2  fixed_segment_relative_order_818  -1
    visit_0_3  out_degree_741  -1
    visit_0_3  in_degree_742  -1
    visit_0_3  order_active_lb_743  -1
    visit_0_3  order_active_ub_744  -14
    order_0_3  connected_order_arc_351  1
    order_0_3  connected_order_arc_378  1
    order_0_3  connected_order_arc_403  -1
    order_0_3  connected_order_arc_405  -1
    order_0_3  connected_order_arc_407  -1
    order_0_3  connected_order_arc_409  -1
    order_0_3  connected_order_arc_411  -1
    order_0_3  connected_order_arc_413  -1
    order_0_3  connected_order_arc_415  -1
    order_0_3  connected_order_arc_417  -1
    order_0_3  connected_order_arc_419  -1
    order_0_3  connected_order_arc_421  -1
    order_0_3  connected_order_arc_423  -1
    order_0_3  connected_order_arc_425  -1
    order_0_3  connected_order_arc_427  -1
    order_0_3  connected_order_arc_434  1
    order_0_3  connected_order_arc_461  1
    order_0_3  connected_order_arc_488  1
    order_0_3  connected_order_arc_515  1
    order_0_3  connected_order_arc_542  1
    order_0_3  connected_order_arc_569  1
    order_0_3  connected_order_arc_596  1
    order_0_3  connected_order_arc_623  1
    order_0_3  connected_order_arc_650  1
    order_0_3  connected_order_arc_677  1
    order_0_3  connected_order_arc_704  1
    order_0_3  order_active_lb_743  1
    order_0_3  order_active_ub_744  1
    order_0_3  fixed_segment_relative_order_818  1
    order_0_3  fixed_segment_relative_order_819  -1
    visit_0_4  out_degree_748  -1
    visit_0_4  in_degree_749  -1
    visit_0_4  order_active_lb_750  -1
    visit_0_4  order_active_ub_751  -14
    order_0_4  connected_order_arc_353  1
    order_0_4  connected_order_arc_380  1
    order_0_4  connected_order_arc_407  1
    order_0_4  connected_order_arc_430  -1
    order_0_4  connected_order_arc_432  -1
    order_0_4  connected_order_arc_434  -1
    order_0_4  connected_order_arc_436  -1
    order_0_4  connected_order_arc_438  -1
    order_0_4  connected_order_arc_440  -1
    order_0_4  connected_order_arc_442  -1
    order_0_4  connected_order_arc_444  -1
    order_0_4  connected_order_arc_446  -1
    order_0_4  connected_order_arc_448  -1
    order_0_4  connected_order_arc_450  -1
    order_0_4  connected_order_arc_452  -1
    order_0_4  connected_order_arc_454  -1
    order_0_4  connected_order_arc_463  1
    order_0_4  connected_order_arc_490  1
    order_0_4  connected_order_arc_517  1
    order_0_4  connected_order_arc_544  1
    order_0_4  connected_order_arc_571  1
    order_0_4  connected_order_arc_598  1
    order_0_4  connected_order_arc_625  1
    order_0_4  connected_order_arc_652  1
    order_0_4  connected_order_arc_679  1
    order_0_4  connected_order_arc_706  1
    order_0_4  order_active_lb_750  1
    order_0_4  order_active_ub_751  1
    order_0_4  fixed_segment_relative_order_819  1
    order_0_4  fixed_segment_relative_order_820  -1
    visit_0_5  out_degree_755  -1
    visit_0_5  in_degree_756  -1
    visit_0_5  order_active_lb_757  -1
    visit_0_5  order_active_ub_758  -14
    order_0_5  connected_order_arc_355  1
    order_0_5  connected_order_arc_382  1
    order_0_5  connected_order_arc_409  1
    order_0_5  connected_order_arc_436  1
    order_0_5  connected_order_arc_457  -1
    order_0_5  connected_order_arc_459  -1
    order_0_5  connected_order_arc_461  -1
    order_0_5  connected_order_arc_463  -1
    order_0_5  connected_order_arc_465  -1
    order_0_5  connected_order_arc_467  -1
    order_0_5  connected_order_arc_469  -1
    order_0_5  connected_order_arc_471  -1
    order_0_5  connected_order_arc_473  -1
    order_0_5  connected_order_arc_475  -1
    order_0_5  connected_order_arc_477  -1
    order_0_5  connected_order_arc_479  -1
    order_0_5  connected_order_arc_481  -1
    order_0_5  connected_order_arc_492  1
    order_0_5  connected_order_arc_519  1
    order_0_5  connected_order_arc_546  1
    order_0_5  connected_order_arc_573  1
    order_0_5  connected_order_arc_600  1
    order_0_5  connected_order_arc_627  1
    order_0_5  connected_order_arc_654  1
    order_0_5  connected_order_arc_681  1
    order_0_5  connected_order_arc_708  1
    order_0_5  order_active_lb_757  1
    order_0_5  order_active_ub_758  1
    order_0_5  fixed_segment_relative_order_820  1
    order_0_5  fixed_segment_relative_order_821  -1
    visit_0_6  out_degree_762  -1
    visit_0_6  in_degree_763  -1
    visit_0_6  order_active_lb_764  -1
    visit_0_6  order_active_ub_765  -14
    order_0_6  connected_order_arc_357  1
    order_0_6  connected_order_arc_384  1
    order_0_6  connected_order_arc_411  1
    order_0_6  connected_order_arc_438  1
    order_0_6  connected_order_arc_465  1
    order_0_6  connected_order_arc_484  -1
    order_0_6  connected_order_arc_486  -1
    order_0_6  connected_order_arc_488  -1
    order_0_6  connected_order_arc_490  -1
    order_0_6  connected_order_arc_492  -1
    order_0_6  connected_order_arc_494  -1
    order_0_6  connected_order_arc_496  -1
    order_0_6  connected_order_arc_498  -1
    order_0_6  connected_order_arc_500  -1
    order_0_6  connected_order_arc_502  -1
    order_0_6  connected_order_arc_504  -1
    order_0_6  connected_order_arc_506  -1
    order_0_6  connected_order_arc_508  -1
    order_0_6  connected_order_arc_521  1
    order_0_6  connected_order_arc_548  1
    order_0_6  connected_order_arc_575  1
    order_0_6  connected_order_arc_602  1
    order_0_6  connected_order_arc_629  1
    order_0_6  connected_order_arc_656  1
    order_0_6  connected_order_arc_683  1
    order_0_6  connected_order_arc_710  1
    order_0_6  order_active_lb_764  1
    order_0_6  order_active_ub_765  1
    order_0_6  fixed_segment_relative_order_821  1
    visit_0_14  out_degree_769  -1
    visit_0_14  in_degree_770  -1
    visit_0_14  order_active_lb_771  -1
    visit_0_14  order_active_ub_772  -14
    visit_0_14  service_visit_def_773  -1
    order_0_14  connected_order_arc_359  1
    order_0_14  connected_order_arc_386  1
    order_0_14  connected_order_arc_413  1
    order_0_14  connected_order_arc_440  1
    order_0_14  connected_order_arc_467  1
    order_0_14  connected_order_arc_494  1
    order_0_14  connected_order_arc_511  -1
    order_0_14  connected_order_arc_513  -1
    order_0_14  connected_order_arc_515  -1
    order_0_14  connected_order_arc_517  -1
    order_0_14  connected_order_arc_519  -1
    order_0_14  connected_order_arc_521  -1
    order_0_14  connected_order_arc_523  -1
    order_0_14  connected_order_arc_525  -1
    order_0_14  connected_order_arc_527  -1
    order_0_14  connected_order_arc_529  -1
    order_0_14  connected_order_arc_531  -1
    order_0_14  connected_order_arc_533  -1
    order_0_14  connected_order_arc_535  -1
    order_0_14  connected_order_arc_550  1
    order_0_14  connected_order_arc_577  1
    order_0_14  connected_order_arc_604  1
    order_0_14  connected_order_arc_631  1
    order_0_14  connected_order_arc_658  1
    order_0_14  connected_order_arc_685  1
    order_0_14  connected_order_arc_712  1
    order_0_14  order_active_lb_771  1
    order_0_14  order_active_ub_772  1
    visit_0_15  out_degree_775  -1
    visit_0_15  in_degree_776  -1
    visit_0_15  order_active_lb_777  -1
    visit_0_15  order_active_ub_778  -14
    visit_0_15  service_visit_def_779  -1
    order_0_15  connected_order_arc_361  1
    order_0_15  connected_order_arc_388  1
    order_0_15  connected_order_arc_415  1
    order_0_15  connected_order_arc_442  1
    order_0_15  connected_order_arc_469  1
    order_0_15  connected_order_arc_496  1
    order_0_15  connected_order_arc_523  1
    order_0_15  connected_order_arc_538  -1
    order_0_15  connected_order_arc_540  -1
    order_0_15  connected_order_arc_542  -1
    order_0_15  connected_order_arc_544  -1
    order_0_15  connected_order_arc_546  -1
    order_0_15  connected_order_arc_548  -1
    order_0_15  connected_order_arc_550  -1
    order_0_15  connected_order_arc_552  -1
    order_0_15  connected_order_arc_554  -1
    order_0_15  connected_order_arc_556  -1
    order_0_15  connected_order_arc_558  -1
    order_0_15  connected_order_arc_560  -1
    order_0_15  connected_order_arc_562  -1
    order_0_15  connected_order_arc_579  1
    order_0_15  connected_order_arc_606  1
    order_0_15  connected_order_arc_633  1
    order_0_15  connected_order_arc_660  1
    order_0_15  connected_order_arc_687  1
    order_0_15  connected_order_arc_714  1
    order_0_15  order_active_lb_777  1
    order_0_15  order_active_ub_778  1
    visit_0_16  out_degree_781  -1
    visit_0_16  in_degree_782  -1
    visit_0_16  order_active_lb_783  -1
    visit_0_16  order_active_ub_784  -14
    visit_0_16  service_visit_def_785  -1
    order_0_16  connected_order_arc_363  1
    order_0_16  connected_order_arc_390  1
    order_0_16  connected_order_arc_417  1
    order_0_16  connected_order_arc_444  1
    order_0_16  connected_order_arc_471  1
    order_0_16  connected_order_arc_498  1
    order_0_16  connected_order_arc_525  1
    order_0_16  connected_order_arc_552  1
    order_0_16  connected_order_arc_565  -1
    order_0_16  connected_order_arc_567  -1
    order_0_16  connected_order_arc_569  -1
    order_0_16  connected_order_arc_571  -1
    order_0_16  connected_order_arc_573  -1
    order_0_16  connected_order_arc_575  -1
    order_0_16  connected_order_arc_577  -1
    order_0_16  connected_order_arc_579  -1
    order_0_16  connected_order_arc_581  -1
    order_0_16  connected_order_arc_583  -1
    order_0_16  connected_order_arc_585  -1
    order_0_16  connected_order_arc_587  -1
    order_0_16  connected_order_arc_589  -1
    order_0_16  connected_order_arc_608  1
    order_0_16  connected_order_arc_635  1
    order_0_16  connected_order_arc_662  1
    order_0_16  connected_order_arc_689  1
    order_0_16  connected_order_arc_716  1
    order_0_16  order_active_lb_783  1
    order_0_16  order_active_ub_784  1
    visit_0_17  out_degree_787  -1
    visit_0_17  in_degree_788  -1
    visit_0_17  order_active_lb_789  -1
    visit_0_17  order_active_ub_790  -14
    visit_0_17  service_visit_def_791  -1
    order_0_17  connected_order_arc_365  1
    order_0_17  connected_order_arc_392  1
    order_0_17  connected_order_arc_419  1
    order_0_17  connected_order_arc_446  1
    order_0_17  connected_order_arc_473  1
    order_0_17  connected_order_arc_500  1
    order_0_17  connected_order_arc_527  1
    order_0_17  connected_order_arc_554  1
    order_0_17  connected_order_arc_581  1
    order_0_17  connected_order_arc_592  -1
    order_0_17  connected_order_arc_594  -1
    order_0_17  connected_order_arc_596  -1
    order_0_17  connected_order_arc_598  -1
    order_0_17  connected_order_arc_600  -1
    order_0_17  connected_order_arc_602  -1
    order_0_17  connected_order_arc_604  -1
    order_0_17  connected_order_arc_606  -1
    order_0_17  connected_order_arc_608  -1
    order_0_17  connected_order_arc_610  -1
    order_0_17  connected_order_arc_612  -1
    order_0_17  connected_order_arc_614  -1
    order_0_17  connected_order_arc_616  -1
    order_0_17  connected_order_arc_637  1
    order_0_17  connected_order_arc_664  1
    order_0_17  connected_order_arc_691  1
    order_0_17  connected_order_arc_718  1
    order_0_17  order_active_lb_789  1
    order_0_17  order_active_ub_790  1
    visit_0_18  out_degree_793  -1
    visit_0_18  in_degree_794  -1
    visit_0_18  order_active_lb_795  -1
    visit_0_18  order_active_ub_796  -14
    visit_0_18  service_visit_def_797  -1
    order_0_18  connected_order_arc_367  1
    order_0_18  connected_order_arc_394  1
    order_0_18  connected_order_arc_421  1
    order_0_18  connected_order_arc_448  1
    order_0_18  connected_order_arc_475  1
    order_0_18  connected_order_arc_502  1
    order_0_18  connected_order_arc_529  1
    order_0_18  connected_order_arc_556  1
    order_0_18  connected_order_arc_583  1
    order_0_18  connected_order_arc_610  1
    order_0_18  connected_order_arc_619  -1
    order_0_18  connected_order_arc_621  -1
    order_0_18  connected_order_arc_623  -1
    order_0_18  connected_order_arc_625  -1
    order_0_18  connected_order_arc_627  -1
    order_0_18  connected_order_arc_629  -1
    order_0_18  connected_order_arc_631  -1
    order_0_18  connected_order_arc_633  -1
    order_0_18  connected_order_arc_635  -1
    order_0_18  connected_order_arc_637  -1
    order_0_18  connected_order_arc_639  -1
    order_0_18  connected_order_arc_641  -1
    order_0_18  connected_order_arc_643  -1
    order_0_18  connected_order_arc_666  1
    order_0_18  connected_order_arc_693  1
    order_0_18  connected_order_arc_720  1
    order_0_18  order_active_lb_795  1
    order_0_18  order_active_ub_796  1
    visit_0_19  out_degree_799  -1
    visit_0_19  in_degree_800  -1
    visit_0_19  order_active_lb_801  -1
    visit_0_19  order_active_ub_802  -14
    visit_0_19  service_visit_def_803  -1
    order_0_19  connected_order_arc_369  1
    order_0_19  connected_order_arc_396  1
    order_0_19  connected_order_arc_423  1
    order_0_19  connected_order_arc_450  1
    order_0_19  connected_order_arc_477  1
    order_0_19  connected_order_arc_504  1
    order_0_19  connected_order_arc_531  1
    order_0_19  connected_order_arc_558  1
    order_0_19  connected_order_arc_585  1
    order_0_19  connected_order_arc_612  1
    order_0_19  connected_order_arc_639  1
    order_0_19  connected_order_arc_646  -1
    order_0_19  connected_order_arc_648  -1
    order_0_19  connected_order_arc_650  -1
    order_0_19  connected_order_arc_652  -1
    order_0_19  connected_order_arc_654  -1
    order_0_19  connected_order_arc_656  -1
    order_0_19  connected_order_arc_658  -1
    order_0_19  connected_order_arc_660  -1
    order_0_19  connected_order_arc_662  -1
    order_0_19  connected_order_arc_664  -1
    order_0_19  connected_order_arc_666  -1
    order_0_19  connected_order_arc_668  -1
    order_0_19  connected_order_arc_670  -1
    order_0_19  connected_order_arc_695  1
    order_0_19  connected_order_arc_722  1
    order_0_19  order_active_lb_801  1
    order_0_19  order_active_ub_802  1
    visit_0_20  out_degree_805  -1
    visit_0_20  in_degree_806  -1
    visit_0_20  order_active_lb_807  -1
    visit_0_20  order_active_ub_808  -14
    visit_0_20  service_visit_def_809  -1
    order_0_20  connected_order_arc_371  1
    order_0_20  connected_order_arc_398  1
    order_0_20  connected_order_arc_425  1
    order_0_20  connected_order_arc_452  1
    order_0_20  connected_order_arc_479  1
    order_0_20  connected_order_arc_506  1
    order_0_20  connected_order_arc_533  1
    order_0_20  connected_order_arc_560  1
    order_0_20  connected_order_arc_587  1
    order_0_20  connected_order_arc_614  1
    order_0_20  connected_order_arc_641  1
    order_0_20  connected_order_arc_668  1
    order_0_20  connected_order_arc_673  -1
    order_0_20  connected_order_arc_675  -1
    order_0_20  connected_order_arc_677  -1
    order_0_20  connected_order_arc_679  -1
    order_0_20  connected_order_arc_681  -1
    order_0_20  connected_order_arc_683  -1
    order_0_20  connected_order_arc_685  -1
    order_0_20  connected_order_arc_687  -1
    order_0_20  connected_order_arc_689  -1
    order_0_20  connected_order_arc_691  -1
    order_0_20  connected_order_arc_693  -1
    order_0_20  connected_order_arc_695  -1
    order_0_20  connected_order_arc_697  -1
    order_0_20  connected_order_arc_724  1
    order_0_20  order_active_lb_807  1
    order_0_20  order_active_ub_808  1
    visit_0_21  out_degree_811  -1
    visit_0_21  in_degree_812  -1
    visit_0_21  order_active_lb_813  -1
    visit_0_21  order_active_ub_814  -14
    visit_0_21  service_visit_def_815  -1
    order_0_21  connected_order_arc_373  1
    order_0_21  connected_order_arc_400  1
    order_0_21  connected_order_arc_427  1
    order_0_21  connected_order_arc_454  1
    order_0_21  connected_order_arc_481  1
    order_0_21  connected_order_arc_508  1
    order_0_21  connected_order_arc_535  1
    order_0_21  connected_order_arc_562  1
    order_0_21  connected_order_arc_589  1
    order_0_21  connected_order_arc_616  1
    order_0_21  connected_order_arc_643  1
    order_0_21  connected_order_arc_670  1
    order_0_21  connected_order_arc_697  1
    order_0_21  connected_order_arc_700  -1
    order_0_21  connected_order_arc_702  -1
    order_0_21  connected_order_arc_704  -1
    order_0_21  connected_order_arc_706  -1
    order_0_21  connected_order_arc_708  -1
    order_0_21  connected_order_arc_710  -1
    order_0_21  connected_order_arc_712  -1
    order_0_21  connected_order_arc_714  -1
    order_0_21  connected_order_arc_716  -1
    order_0_21  connected_order_arc_718  -1
    order_0_21  connected_order_arc_720  -1
    order_0_21  connected_order_arc_722  -1
    order_0_21  connected_order_arc_724  -1
    order_0_21  order_active_lb_813  1
    order_0_21  order_active_ub_814  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_332  -20
    arc_0_0_0  depot_departure_or_bypass_725  1
    arc_0_0_0  depot_return_or_bypass_726  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_332  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_333  -20
    arc_0_0_1  depot_departure_or_bypass_725  1
    arc_0_0_1  in_degree_728  1
    arc_0_0_1  original_T_including_depot_unload_822  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_333  1
    load_0_0_1  segment_load_conservation_731  -1
    load_0_0_1  segment_prefix_lb_732  1
    load_0_0_1  segment_prefix_ub_733  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_334  -20
    arc_0_0_2  depot_departure_or_bypass_725  1
    arc_0_0_2  in_degree_735  1
    arc_0_0_2  original_T_including_depot_unload_822  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_334  1
    load_0_0_2  segment_load_conservation_738  -1
    load_0_0_2  segment_prefix_lb_739  1
    load_0_0_2  segment_prefix_ub_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_335  -20
    arc_0_0_3  depot_departure_or_bypass_725  1
    arc_0_0_3  in_degree_742  1
    arc_0_0_3  original_T_including_depot_unload_822  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_335  1
    load_0_0_3  segment_load_conservation_745  -1
    load_0_0_3  segment_prefix_lb_746  1
    load_0_0_3  segment_prefix_ub_747  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_336  -20
    arc_0_0_4  depot_departure_or_bypass_725  1
    arc_0_0_4  in_degree_749  1
    arc_0_0_4  original_T_including_depot_unload_822  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_336  1
    load_0_0_4  segment_load_conservation_752  -1
    load_0_0_4  segment_prefix_lb_753  1
    load_0_0_4  segment_prefix_ub_754  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_337  -20
    arc_0_0_5  depot_departure_or_bypass_725  1
    arc_0_0_5  in_degree_756  1
    arc_0_0_5  original_T_including_depot_unload_822  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_337  1
    load_0_0_5  segment_load_conservation_759  -1
    load_0_0_5  segment_prefix_lb_760  1
    load_0_0_5  segment_prefix_ub_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_338  -20
    arc_0_0_6  depot_departure_or_bypass_725  1
    arc_0_0_6  in_degree_763  1
    arc_0_0_6  original_T_including_depot_unload_822  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_338  1
    load_0_0_6  segment_load_conservation_766  -1
    load_0_0_6  segment_prefix_lb_767  1
    load_0_0_6  segment_prefix_ub_768  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_339  -20
    arc_0_0_14  depot_departure_or_bypass_725  1
    arc_0_0_14  in_degree_770  1
    arc_0_0_14  original_T_including_depot_unload_822  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_339  1
    load_0_0_14  free_load_conservation_774  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_340  -20
    arc_0_0_15  depot_departure_or_bypass_725  1
    arc_0_0_15  in_degree_776  1
    arc_0_0_15  original_T_including_depot_unload_822  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_340  1
    load_0_0_15  free_load_conservation_780  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_341  -20
    arc_0_0_16  depot_departure_or_bypass_725  1
    arc_0_0_16  in_degree_782  1
    arc_0_0_16  original_T_including_depot_unload_822  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_341  1
    load_0_0_16  free_load_conservation_786  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_342  -20
    arc_0_0_17  depot_departure_or_bypass_725  1
    arc_0_0_17  in_degree_788  1
    arc_0_0_17  original_T_including_depot_unload_822  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_342  1
    load_0_0_17  free_load_conservation_792  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_343  -20
    arc_0_0_18  depot_departure_or_bypass_725  1
    arc_0_0_18  in_degree_794  1
    arc_0_0_18  original_T_including_depot_unload_822  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_343  1
    load_0_0_18  free_load_conservation_798  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_344  -20
    arc_0_0_19  depot_departure_or_bypass_725  1
    arc_0_0_19  in_degree_800  1
    arc_0_0_19  original_T_including_depot_unload_822  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_344  1
    load_0_0_19  free_load_conservation_804  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_345  -20
    arc_0_0_20  depot_departure_or_bypass_725  1
    arc_0_0_20  in_degree_806  1
    arc_0_0_20  original_T_including_depot_unload_822  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_345  1
    load_0_0_20  free_load_conservation_810  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_346  -20
    arc_0_0_21  depot_departure_or_bypass_725  1
    arc_0_0_21  in_degree_812  1
    arc_0_0_21  original_T_including_depot_unload_822  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_346  1
    load_0_0_21  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_347  -20
    arc_0_1_0  depot_return_or_bypass_726  1
    arc_0_1_0  out_degree_727  1
    arc_0_1_0  original_T_including_depot_unload_822  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_347  1
    load_0_1_0  segment_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_348  -20
    arc_0_1_2  connected_order_arc_349  -15
    arc_0_1_2  out_degree_727  1
    arc_0_1_2  in_degree_735  1
    arc_0_1_2  original_T_including_depot_unload_822  6.0726027477261266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_348  1
    load_0_1_2  segment_load_conservation_731  1
    load_0_1_2  segment_load_conservation_738  -1
    load_0_1_2  segment_prefix_lb_739  1
    load_0_1_2  segment_prefix_ub_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_350  -20
    arc_0_1_3  connected_order_arc_351  -15
    arc_0_1_3  out_degree_727  1
    arc_0_1_3  in_degree_742  1
    arc_0_1_3  original_T_including_depot_unload_822  7.2368344003319692e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_350  1
    load_0_1_3  segment_load_conservation_731  1
    load_0_1_3  segment_load_conservation_745  -1
    load_0_1_3  segment_prefix_lb_746  1
    load_0_1_3  segment_prefix_ub_747  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_352  -20
    arc_0_1_4  connected_order_arc_353  -15
    arc_0_1_4  out_degree_727  1
    arc_0_1_4  in_degree_749  1
    arc_0_1_4  original_T_including_depot_unload_822  4.9828630663707764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_352  1
    load_0_1_4  segment_load_conservation_731  1
    load_0_1_4  segment_load_conservation_752  -1
    load_0_1_4  segment_prefix_lb_753  1
    load_0_1_4  segment_prefix_ub_754  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_354  -20
    arc_0_1_5  connected_order_arc_355  -15
    arc_0_1_5  out_degree_727  1
    arc_0_1_5  in_degree_756  1
    arc_0_1_5  original_T_including_depot_unload_822  5.4635723875297333e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_354  1
    load_0_1_5  segment_load_conservation_731  1
    load_0_1_5  segment_load_conservation_759  -1
    load_0_1_5  segment_prefix_lb_760  1
    load_0_1_5  segment_prefix_ub_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_356  -20
    arc_0_1_6  connected_order_arc_357  -15
    arc_0_1_6  out_degree_727  1
    arc_0_1_6  in_degree_763  1
    arc_0_1_6  original_T_including_depot_unload_822  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_356  1
    load_0_1_6  segment_load_conservation_731  1
    load_0_1_6  segment_load_conservation_766  -1
    load_0_1_6  segment_prefix_lb_767  1
    load_0_1_6  segment_prefix_ub_768  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_358  -20
    arc_0_1_14  connected_order_arc_359  -15
    arc_0_1_14  out_degree_727  1
    arc_0_1_14  in_degree_770  1
    arc_0_1_14  original_T_including_depot_unload_822  2.8083660458664087e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_358  1
    load_0_1_14  segment_load_conservation_731  1
    load_0_1_14  free_load_conservation_774  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_360  -20
    arc_0_1_15  connected_order_arc_361  -15
    arc_0_1_15  out_degree_727  1
    arc_0_1_15  in_degree_776  1
    arc_0_1_15  original_T_including_depot_unload_822  3.9263280945415767e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_360  1
    load_0_1_15  segment_load_conservation_731  1
    load_0_1_15  free_load_conservation_780  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_362  -20
    arc_0_1_16  connected_order_arc_363  -15
    arc_0_1_16  out_degree_727  1
    arc_0_1_16  in_degree_782  1
    arc_0_1_16  original_T_including_depot_unload_822  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_362  1
    load_0_1_16  segment_load_conservation_731  1
    load_0_1_16  free_load_conservation_786  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_364  -20
    arc_0_1_17  connected_order_arc_365  -15
    arc_0_1_17  out_degree_727  1
    arc_0_1_17  in_degree_788  1
    arc_0_1_17  original_T_including_depot_unload_822  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_364  1
    load_0_1_17  segment_load_conservation_731  1
    load_0_1_17  free_load_conservation_792  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_366  -20
    arc_0_1_18  connected_order_arc_367  -15
    arc_0_1_18  out_degree_727  1
    arc_0_1_18  in_degree_794  1
    arc_0_1_18  original_T_including_depot_unload_822  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_366  1
    load_0_1_18  segment_load_conservation_731  1
    load_0_1_18  free_load_conservation_798  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_368  -20
    arc_0_1_19  connected_order_arc_369  -15
    arc_0_1_19  out_degree_727  1
    arc_0_1_19  in_degree_800  1
    arc_0_1_19  original_T_including_depot_unload_822  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_368  1
    load_0_1_19  segment_load_conservation_731  1
    load_0_1_19  free_load_conservation_804  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_370  -20
    arc_0_1_20  connected_order_arc_371  -15
    arc_0_1_20  out_degree_727  1
    arc_0_1_20  in_degree_806  1
    arc_0_1_20  original_T_including_depot_unload_822  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_370  1
    load_0_1_20  segment_load_conservation_731  1
    load_0_1_20  free_load_conservation_810  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_372  -20
    arc_0_1_21  connected_order_arc_373  -15
    arc_0_1_21  out_degree_727  1
    arc_0_1_21  in_degree_812  1
    arc_0_1_21  original_T_including_depot_unload_822  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_372  1
    load_0_1_21  segment_load_conservation_731  1
    load_0_1_21  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_374  -20
    arc_0_2_0  depot_return_or_bypass_726  1
    arc_0_2_0  out_degree_734  1
    arc_0_2_0  original_T_including_depot_unload_822  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_374  1
    load_0_2_0  segment_load_conservation_738  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_375  -20
    arc_0_2_1  connected_order_arc_376  -15
    arc_0_2_1  in_degree_728  1
    arc_0_2_1  out_degree_734  1
    arc_0_2_1  original_T_including_depot_unload_822  6.0726027477261266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_375  1
    load_0_2_1  segment_load_conservation_731  -1
    load_0_2_1  segment_prefix_lb_732  1
    load_0_2_1  segment_prefix_ub_733  1
    load_0_2_1  segment_load_conservation_738  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_377  -20
    arc_0_2_3  connected_order_arc_378  -15
    arc_0_2_3  out_degree_734  1
    arc_0_2_3  in_degree_742  1
    arc_0_2_3  original_T_including_depot_unload_822  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_377  1
    load_0_2_3  segment_load_conservation_738  1
    load_0_2_3  segment_load_conservation_745  -1
    load_0_2_3  segment_prefix_lb_746  1
    load_0_2_3  segment_prefix_ub_747  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_379  -20
    arc_0_2_4  connected_order_arc_380  -15
    arc_0_2_4  out_degree_734  1
    arc_0_2_4  in_degree_749  1
    arc_0_2_4  original_T_including_depot_unload_822  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_379  1
    load_0_2_4  segment_load_conservation_738  1
    load_0_2_4  segment_load_conservation_752  -1
    load_0_2_4  segment_prefix_lb_753  1
    load_0_2_4  segment_prefix_ub_754  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_381  -20
    arc_0_2_5  connected_order_arc_382  -15
    arc_0_2_5  out_degree_734  1
    arc_0_2_5  in_degree_756  1
    arc_0_2_5  original_T_including_depot_unload_822  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_381  1
    load_0_2_5  segment_load_conservation_738  1
    load_0_2_5  segment_load_conservation_759  -1
    load_0_2_5  segment_prefix_lb_760  1
    load_0_2_5  segment_prefix_ub_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_383  -20
    arc_0_2_6  connected_order_arc_384  -15
    arc_0_2_6  out_degree_734  1
    arc_0_2_6  in_degree_763  1
    arc_0_2_6  original_T_including_depot_unload_822  7.6007185336497685e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_383  1
    load_0_2_6  segment_load_conservation_738  1
    load_0_2_6  segment_load_conservation_766  -1
    load_0_2_6  segment_prefix_lb_767  1
    load_0_2_6  segment_prefix_ub_768  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_385  -20
    arc_0_2_14  connected_order_arc_386  -15
    arc_0_2_14  out_degree_734  1
    arc_0_2_14  in_degree_770  1
    arc_0_2_14  original_T_including_depot_unload_822  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_385  1
    load_0_2_14  segment_load_conservation_738  1
    load_0_2_14  free_load_conservation_774  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_387  -20
    arc_0_2_15  connected_order_arc_388  -15
    arc_0_2_15  out_degree_734  1
    arc_0_2_15  in_degree_776  1
    arc_0_2_15  original_T_including_depot_unload_822  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_387  1
    load_0_2_15  segment_load_conservation_738  1
    load_0_2_15  free_load_conservation_780  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_389  -20
    arc_0_2_16  connected_order_arc_390  -15
    arc_0_2_16  out_degree_734  1
    arc_0_2_16  in_degree_782  1
    arc_0_2_16  original_T_including_depot_unload_822  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_389  1
    load_0_2_16  segment_load_conservation_738  1
    load_0_2_16  free_load_conservation_786  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_391  -20
    arc_0_2_17  connected_order_arc_392  -15
    arc_0_2_17  out_degree_734  1
    arc_0_2_17  in_degree_788  1
    arc_0_2_17  original_T_including_depot_unload_822  477.665399637945
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_391  1
    load_0_2_17  segment_load_conservation_738  1
    load_0_2_17  free_load_conservation_792  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_393  -20
    arc_0_2_18  connected_order_arc_394  -15
    arc_0_2_18  out_degree_734  1
    arc_0_2_18  in_degree_794  1
    arc_0_2_18  original_T_including_depot_unload_822  2.0959764716808540e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_393  1
    load_0_2_18  segment_load_conservation_738  1
    load_0_2_18  free_load_conservation_798  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_395  -20
    arc_0_2_19  connected_order_arc_396  -15
    arc_0_2_19  out_degree_734  1
    arc_0_2_19  in_degree_800  1
    arc_0_2_19  original_T_including_depot_unload_822  4.8210275478508015e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_395  1
    load_0_2_19  segment_load_conservation_738  1
    load_0_2_19  free_load_conservation_804  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_397  -20
    arc_0_2_20  connected_order_arc_398  -15
    arc_0_2_20  out_degree_734  1
    arc_0_2_20  in_degree_806  1
    arc_0_2_20  original_T_including_depot_unload_822  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_397  1
    load_0_2_20  segment_load_conservation_738  1
    load_0_2_20  free_load_conservation_810  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_399  -20
    arc_0_2_21  connected_order_arc_400  -15
    arc_0_2_21  out_degree_734  1
    arc_0_2_21  in_degree_812  1
    arc_0_2_21  original_T_including_depot_unload_822  4.8268503899521744e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_399  1
    load_0_2_21  segment_load_conservation_738  1
    load_0_2_21  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_401  -20
    arc_0_3_0  depot_return_or_bypass_726  1
    arc_0_3_0  out_degree_741  1
    arc_0_3_0  original_T_including_depot_unload_822  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_401  1
    load_0_3_0  segment_load_conservation_745  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_402  -20
    arc_0_3_1  connected_order_arc_403  -15
    arc_0_3_1  in_degree_728  1
    arc_0_3_1  out_degree_741  1
    arc_0_3_1  original_T_including_depot_unload_822  7.2368344003319692e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_402  1
    load_0_3_1  segment_load_conservation_731  -1
    load_0_3_1  segment_prefix_lb_732  1
    load_0_3_1  segment_prefix_ub_733  1
    load_0_3_1  segment_load_conservation_745  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_404  -20
    arc_0_3_2  connected_order_arc_405  -15
    arc_0_3_2  in_degree_735  1
    arc_0_3_2  out_degree_741  1
    arc_0_3_2  original_T_including_depot_unload_822  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_404  1
    load_0_3_2  segment_load_conservation_738  -1
    load_0_3_2  segment_prefix_lb_739  1
    load_0_3_2  segment_prefix_ub_740  1
    load_0_3_2  segment_load_conservation_745  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_406  -20
    arc_0_3_4  connected_order_arc_407  -15
    arc_0_3_4  out_degree_741  1
    arc_0_3_4  in_degree_749  1
    arc_0_3_4  original_T_including_depot_unload_822  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_406  1
    load_0_3_4  segment_load_conservation_745  1
    load_0_3_4  segment_load_conservation_752  -1
    load_0_3_4  segment_prefix_lb_753  1
    load_0_3_4  segment_prefix_ub_754  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_408  -20
    arc_0_3_5  connected_order_arc_409  -15
    arc_0_3_5  out_degree_741  1
    arc_0_3_5  in_degree_756  1
    arc_0_3_5  original_T_including_depot_unload_822  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_408  1
    load_0_3_5  segment_load_conservation_745  1
    load_0_3_5  segment_load_conservation_759  -1
    load_0_3_5  segment_prefix_lb_760  1
    load_0_3_5  segment_prefix_ub_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_410  -20
    arc_0_3_6  connected_order_arc_411  -15
    arc_0_3_6  out_degree_741  1
    arc_0_3_6  in_degree_763  1
    arc_0_3_6  original_T_including_depot_unload_822  8.8827217910440470e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_410  1
    load_0_3_6  segment_load_conservation_745  1
    load_0_3_6  segment_load_conservation_766  -1
    load_0_3_6  segment_prefix_lb_767  1
    load_0_3_6  segment_prefix_ub_768  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_412  -20
    arc_0_3_14  connected_order_arc_413  -15
    arc_0_3_14  out_degree_741  1
    arc_0_3_14  in_degree_770  1
    arc_0_3_14  original_T_including_depot_unload_822  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_412  1
    load_0_3_14  segment_load_conservation_745  1
    load_0_3_14  free_load_conservation_774  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_414  -20
    arc_0_3_15  connected_order_arc_415  -15
    arc_0_3_15  out_degree_741  1
    arc_0_3_15  in_degree_776  1
    arc_0_3_15  original_T_including_depot_unload_822  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_414  1
    load_0_3_15  segment_load_conservation_745  1
    load_0_3_15  free_load_conservation_780  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_416  -20
    arc_0_3_16  connected_order_arc_417  -15
    arc_0_3_16  out_degree_741  1
    arc_0_3_16  in_degree_782  1
    arc_0_3_16  original_T_including_depot_unload_822  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_416  1
    load_0_3_16  segment_load_conservation_745  1
    load_0_3_16  free_load_conservation_786  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_418  -20
    arc_0_3_17  connected_order_arc_419  -15
    arc_0_3_17  out_degree_741  1
    arc_0_3_17  in_degree_788  1
    arc_0_3_17  original_T_including_depot_unload_822  6.0146431446211739e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_418  1
    load_0_3_17  segment_load_conservation_745  1
    load_0_3_17  free_load_conservation_792  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_420  -20
    arc_0_3_18  connected_order_arc_421  -15
    arc_0_3_18  out_degree_741  1
    arc_0_3_18  in_degree_794  1
    arc_0_3_18  original_T_including_depot_unload_822  2.1132075050355038e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_420  1
    load_0_3_18  segment_load_conservation_745  1
    load_0_3_18  free_load_conservation_798  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_422  -20
    arc_0_3_19  connected_order_arc_423  -15
    arc_0_3_19  out_degree_741  1
    arc_0_3_19  in_degree_800  1
    arc_0_3_19  original_T_including_depot_unload_822  5.9170757102467792e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_422  1
    load_0_3_19  segment_load_conservation_745  1
    load_0_3_19  free_load_conservation_804  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_424  -20
    arc_0_3_20  connected_order_arc_425  -15
    arc_0_3_20  out_degree_741  1
    arc_0_3_20  in_degree_806  1
    arc_0_3_20  original_T_including_depot_unload_822  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_424  1
    load_0_3_20  segment_load_conservation_745  1
    load_0_3_20  free_load_conservation_810  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_426  -20
    arc_0_3_21  connected_order_arc_427  -15
    arc_0_3_21  out_degree_741  1
    arc_0_3_21  in_degree_812  1
    arc_0_3_21  original_T_including_depot_unload_822  5.9232553492869590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_426  1
    load_0_3_21  segment_load_conservation_745  1
    load_0_3_21  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_428  -20
    arc_0_4_0  depot_return_or_bypass_726  1
    arc_0_4_0  out_degree_748  1
    arc_0_4_0  original_T_including_depot_unload_822  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_428  1
    load_0_4_0  segment_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_429  -20
    arc_0_4_1  connected_order_arc_430  -15
    arc_0_4_1  in_degree_728  1
    arc_0_4_1  out_degree_748  1
    arc_0_4_1  original_T_including_depot_unload_822  4.9828630663707764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_429  1
    load_0_4_1  segment_load_conservation_731  -1
    load_0_4_1  segment_prefix_lb_732  1
    load_0_4_1  segment_prefix_ub_733  1
    load_0_4_1  segment_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_431  -20
    arc_0_4_2  connected_order_arc_432  -15
    arc_0_4_2  in_degree_735  1
    arc_0_4_2  out_degree_748  1
    arc_0_4_2  original_T_including_depot_unload_822  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_431  1
    load_0_4_2  segment_load_conservation_738  -1
    load_0_4_2  segment_prefix_lb_739  1
    load_0_4_2  segment_prefix_ub_740  1
    load_0_4_2  segment_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_433  -20
    arc_0_4_3  connected_order_arc_434  -15
    arc_0_4_3  in_degree_742  1
    arc_0_4_3  out_degree_748  1
    arc_0_4_3  original_T_including_depot_unload_822  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_433  1
    load_0_4_3  segment_load_conservation_745  -1
    load_0_4_3  segment_prefix_lb_746  1
    load_0_4_3  segment_prefix_ub_747  1
    load_0_4_3  segment_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_435  -20
    arc_0_4_5  connected_order_arc_436  -15
    arc_0_4_5  out_degree_748  1
    arc_0_4_5  in_degree_756  1
    arc_0_4_5  original_T_including_depot_unload_822  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_435  1
    load_0_4_5  segment_load_conservation_752  1
    load_0_4_5  segment_load_conservation_759  -1
    load_0_4_5  segment_prefix_lb_760  1
    load_0_4_5  segment_prefix_ub_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_437  -20
    arc_0_4_6  connected_order_arc_438  -15
    arc_0_4_6  out_degree_748  1
    arc_0_4_6  in_degree_763  1
    arc_0_4_6  original_T_including_depot_unload_822  6.6347574074434863e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_437  1
    load_0_4_6  segment_load_conservation_752  1
    load_0_4_6  segment_load_conservation_766  -1
    load_0_4_6  segment_prefix_lb_767  1
    load_0_4_6  segment_prefix_ub_768  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_439  -20
    arc_0_4_14  connected_order_arc_440  -15
    arc_0_4_14  out_degree_748  1
    arc_0_4_14  in_degree_770  1
    arc_0_4_14  original_T_including_depot_unload_822  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_439  1
    load_0_4_14  segment_load_conservation_752  1
    load_0_4_14  free_load_conservation_774  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_441  -20
    arc_0_4_15  connected_order_arc_442  -15
    arc_0_4_15  out_degree_748  1
    arc_0_4_15  in_degree_776  1
    arc_0_4_15  original_T_including_depot_unload_822  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_441  1
    load_0_4_15  segment_load_conservation_752  1
    load_0_4_15  free_load_conservation_780  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_443  -20
    arc_0_4_16  connected_order_arc_444  -15
    arc_0_4_16  out_degree_748  1
    arc_0_4_16  in_degree_782  1
    arc_0_4_16  original_T_including_depot_unload_822  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_443  1
    load_0_4_16  segment_load_conservation_752  1
    load_0_4_16  free_load_conservation_786  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_445  -20
    arc_0_4_17  connected_order_arc_446  -15
    arc_0_4_17  out_degree_748  1
    arc_0_4_17  in_degree_788  1
    arc_0_4_17  original_T_including_depot_unload_822  3.8949255894881873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_445  1
    load_0_4_17  segment_load_conservation_752  1
    load_0_4_17  free_load_conservation_792  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_447  -20
    arc_0_4_18  connected_order_arc_448  -15
    arc_0_4_18  out_degree_748  1
    arc_0_4_18  in_degree_794  1
    arc_0_4_18  original_T_including_depot_unload_822  1.8631004883789885e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_447  1
    load_0_4_18  segment_load_conservation_752  1
    load_0_4_18  free_load_conservation_798  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_449  -20
    arc_0_4_19  connected_order_arc_450  -15
    arc_0_4_19  out_degree_748  1
    arc_0_4_19  in_degree_800  1
    arc_0_4_19  original_T_including_depot_unload_822  3.7084803914885475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_449  1
    load_0_4_19  segment_load_conservation_752  1
    load_0_4_19  free_load_conservation_804  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_451  -20
    arc_0_4_20  connected_order_arc_452  -15
    arc_0_4_20  out_degree_748  1
    arc_0_4_20  in_degree_806  1
    arc_0_4_20  original_T_including_depot_unload_822  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_451  1
    load_0_4_20  segment_load_conservation_752  1
    load_0_4_20  free_load_conservation_810  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_453  -20
    arc_0_4_21  connected_order_arc_454  -15
    arc_0_4_21  out_degree_748  1
    arc_0_4_21  in_degree_812  1
    arc_0_4_21  original_T_including_depot_unload_822  3.7143421209022068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_453  1
    load_0_4_21  segment_load_conservation_752  1
    load_0_4_21  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_455  -20
    arc_0_5_0  depot_return_or_bypass_726  1
    arc_0_5_0  out_degree_755  1
    arc_0_5_0  original_T_including_depot_unload_822  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_455  1
    load_0_5_0  segment_load_conservation_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_456  -20
    arc_0_5_1  connected_order_arc_457  -15
    arc_0_5_1  in_degree_728  1
    arc_0_5_1  out_degree_755  1
    arc_0_5_1  original_T_including_depot_unload_822  5.4635723875297333e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_456  1
    load_0_5_1  segment_load_conservation_731  -1
    load_0_5_1  segment_prefix_lb_732  1
    load_0_5_1  segment_prefix_ub_733  1
    load_0_5_1  segment_load_conservation_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_458  -20
    arc_0_5_2  connected_order_arc_459  -15
    arc_0_5_2  in_degree_735  1
    arc_0_5_2  out_degree_755  1
    arc_0_5_2  original_T_including_depot_unload_822  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_458  1
    load_0_5_2  segment_load_conservation_738  -1
    load_0_5_2  segment_prefix_lb_739  1
    load_0_5_2  segment_prefix_ub_740  1
    load_0_5_2  segment_load_conservation_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_460  -20
    arc_0_5_3  connected_order_arc_461  -15
    arc_0_5_3  in_degree_742  1
    arc_0_5_3  out_degree_755  1
    arc_0_5_3  original_T_including_depot_unload_822  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_460  1
    load_0_5_3  segment_load_conservation_745  -1
    load_0_5_3  segment_prefix_lb_746  1
    load_0_5_3  segment_prefix_ub_747  1
    load_0_5_3  segment_load_conservation_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_462  -20
    arc_0_5_4  connected_order_arc_463  -15
    arc_0_5_4  in_degree_749  1
    arc_0_5_4  out_degree_755  1
    arc_0_5_4  original_T_including_depot_unload_822  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_462  1
    load_0_5_4  segment_load_conservation_752  -1
    load_0_5_4  segment_prefix_lb_753  1
    load_0_5_4  segment_prefix_ub_754  1
    load_0_5_4  segment_load_conservation_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_464  -20
    arc_0_5_6  connected_order_arc_465  -15
    arc_0_5_6  out_degree_755  1
    arc_0_5_6  in_degree_763  1
    arc_0_5_6  original_T_including_depot_unload_822  7.0663858580683063e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_464  1
    load_0_5_6  segment_load_conservation_759  1
    load_0_5_6  segment_load_conservation_766  -1
    load_0_5_6  segment_prefix_lb_767  1
    load_0_5_6  segment_prefix_ub_768  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_466  -20
    arc_0_5_14  connected_order_arc_467  -15
    arc_0_5_14  out_degree_755  1
    arc_0_5_14  in_degree_770  1
    arc_0_5_14  original_T_including_depot_unload_822  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_466  1
    load_0_5_14  segment_load_conservation_759  1
    load_0_5_14  free_load_conservation_774  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_468  -20
    arc_0_5_15  connected_order_arc_469  -15
    arc_0_5_15  out_degree_755  1
    arc_0_5_15  in_degree_776  1
    arc_0_5_15  original_T_including_depot_unload_822  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_468  1
    load_0_5_15  segment_load_conservation_759  1
    load_0_5_15  free_load_conservation_780  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_470  -20
    arc_0_5_16  connected_order_arc_471  -15
    arc_0_5_16  out_degree_755  1
    arc_0_5_16  in_degree_782  1
    arc_0_5_16  original_T_including_depot_unload_822  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_470  1
    load_0_5_16  segment_load_conservation_759  1
    load_0_5_16  free_load_conservation_786  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_472  -20
    arc_0_5_17  connected_order_arc_473  -15
    arc_0_5_17  out_degree_755  1
    arc_0_5_17  in_degree_788  1
    arc_0_5_17  original_T_including_depot_unload_822  4.5635886855303721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_472  1
    load_0_5_17  segment_load_conservation_759  1
    load_0_5_17  free_load_conservation_792  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_474  -20
    arc_0_5_18  connected_order_arc_475  -15
    arc_0_5_18  out_degree_755  1
    arc_0_5_18  in_degree_794  1
    arc_0_5_18  original_T_including_depot_unload_822  1.8150519376858174e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_474  1
    load_0_5_18  segment_load_conservation_759  1
    load_0_5_18  free_load_conservation_798  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_476  -20
    arc_0_5_19  connected_order_arc_477  -15
    arc_0_5_19  out_degree_755  1
    arc_0_5_19  in_degree_800  1
    arc_0_5_19  original_T_including_depot_unload_822  4.3076139952356033e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_476  1
    load_0_5_19  segment_load_conservation_759  1
    load_0_5_19  free_load_conservation_804  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_478  -20
    arc_0_5_20  connected_order_arc_479  -15
    arc_0_5_20  out_degree_755  1
    arc_0_5_20  in_degree_806  1
    arc_0_5_20  original_T_including_depot_unload_822  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_478  1
    load_0_5_20  segment_load_conservation_759  1
    load_0_5_20  free_load_conservation_810  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_480  -20
    arc_0_5_21  connected_order_arc_481  -15
    arc_0_5_21  out_degree_755  1
    arc_0_5_21  in_degree_812  1
    arc_0_5_21  original_T_including_depot_unload_822  4.3127471875854752e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_480  1
    load_0_5_21  segment_load_conservation_759  1
    load_0_5_21  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_482  -20
    arc_0_6_0  depot_return_or_bypass_726  1
    arc_0_6_0  out_degree_762  1
    arc_0_6_0  original_T_including_depot_unload_822  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_482  1
    load_0_6_0  segment_load_conservation_766  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_483  -20
    arc_0_6_1  connected_order_arc_484  -15
    arc_0_6_1  in_degree_728  1
    arc_0_6_1  out_degree_762  1
    arc_0_6_1  original_T_including_depot_unload_822  6.4485258452666415e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_483  1
    load_0_6_1  segment_load_conservation_731  -1
    load_0_6_1  segment_prefix_lb_732  1
    load_0_6_1  segment_prefix_ub_733  1
    load_0_6_1  segment_load_conservation_766  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_485  -20
    arc_0_6_2  connected_order_arc_486  -15
    arc_0_6_2  in_degree_735  1
    arc_0_6_2  out_degree_762  1
    arc_0_6_2  original_T_including_depot_unload_822  1.2450286067313011e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_485  1
    load_0_6_2  segment_load_conservation_738  -1
    load_0_6_2  segment_prefix_lb_739  1
    load_0_6_2  segment_prefix_ub_740  1
    load_0_6_2  segment_load_conservation_766  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_487  -20
    arc_0_6_3  connected_order_arc_488  -15
    arc_0_6_3  in_degree_742  1
    arc_0_6_3  out_degree_762  1
    arc_0_6_3  original_T_including_depot_unload_822  1.3663551195332984e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_487  1
    load_0_6_3  segment_load_conservation_745  -1
    load_0_6_3  segment_prefix_lb_746  1
    load_0_6_3  segment_prefix_ub_747  1
    load_0_6_3  segment_load_conservation_766  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_489  -20
    arc_0_6_4  connected_order_arc_490  -15
    arc_0_6_4  in_degree_749  1
    arc_0_6_4  out_degree_762  1
    arc_0_6_4  original_T_including_depot_unload_822  1.1301442107738828e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_489  1
    load_0_6_4  segment_load_conservation_752  -1
    load_0_6_4  segment_prefix_lb_753  1
    load_0_6_4  segment_prefix_ub_754  1
    load_0_6_4  segment_load_conservation_766  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_491  -20
    arc_0_6_5  connected_order_arc_492  -15
    arc_0_6_5  in_degree_756  1
    arc_0_6_5  out_degree_762  1
    arc_0_6_5  original_T_including_depot_unload_822  1.1516424799836650e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_491  1
    load_0_6_5  segment_load_conservation_759  -1
    load_0_6_5  segment_prefix_lb_760  1
    load_0_6_5  segment_prefix_ub_761  1
    load_0_6_5  segment_load_conservation_766  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_14  arc_capacity_493  -20
    arc_0_6_14  connected_order_arc_494  -15
    arc_0_6_14  out_degree_762  1
    arc_0_6_14  in_degree_770  1
    arc_0_6_14  original_T_including_depot_unload_822  9.2367088355230590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_14  arc_capacity_493  1
    load_0_6_14  segment_load_conservation_766  1
    load_0_6_14  free_load_conservation_774  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_495  -20
    arc_0_6_15  connected_order_arc_496  -15
    arc_0_6_15  out_degree_762  1
    arc_0_6_15  in_degree_776  1
    arc_0_6_15  original_T_including_depot_unload_822  1035.83277530205
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_495  1
    load_0_6_15  segment_load_conservation_766  1
    load_0_6_15  free_load_conservation_780  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_497  -20
    arc_0_6_16  connected_order_arc_498  -15
    arc_0_6_16  out_degree_762  1
    arc_0_6_16  in_degree_782  1
    arc_0_6_16  original_T_including_depot_unload_822  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_497  1
    load_0_6_16  segment_load_conservation_766  1
    load_0_6_16  free_load_conservation_786  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_17  arc_capacity_499  -20
    arc_0_6_17  connected_order_arc_500  -15
    arc_0_6_17  out_degree_762  1
    arc_0_6_17  in_degree_788  1
    arc_0_6_17  original_T_including_depot_unload_822  7.7242003812192672e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_17  arc_capacity_499  1
    load_0_6_17  segment_load_conservation_766  1
    load_0_6_17  free_load_conservation_792  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_18  arc_capacity_501  -20
    arc_0_6_18  connected_order_arc_502  -15
    arc_0_6_18  out_degree_762  1
    arc_0_6_18  in_degree_794  1
    arc_0_6_18  original_T_including_depot_unload_822  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_18  arc_capacity_501  1
    load_0_6_18  segment_load_conservation_766  1
    load_0_6_18  free_load_conservation_798  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_19  arc_capacity_503  -20
    arc_0_6_19  connected_order_arc_504  -15
    arc_0_6_19  out_degree_762  1
    arc_0_6_19  in_degree_800  1
    arc_0_6_19  original_T_including_depot_unload_822  7.7662791174533720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_19  arc_capacity_503  1
    load_0_6_19  segment_load_conservation_766  1
    load_0_6_19  free_load_conservation_804  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_20  arc_capacity_505  -20
    arc_0_6_20  connected_order_arc_506  -15
    arc_0_6_20  out_degree_762  1
    arc_0_6_20  in_degree_806  1
    arc_0_6_20  original_T_including_depot_unload_822  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_20  arc_capacity_505  1
    load_0_6_20  segment_load_conservation_766  1
    load_0_6_20  free_load_conservation_810  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_21  arc_capacity_507  -20
    arc_0_6_21  connected_order_arc_508  -15
    arc_0_6_21  out_degree_762  1
    arc_0_6_21  in_degree_812  1
    arc_0_6_21  original_T_including_depot_unload_822  7.7600923635341769e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_21  arc_capacity_507  1
    load_0_6_21  segment_load_conservation_766  1
    load_0_6_21  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_509  -20
    arc_0_14_0  depot_return_or_bypass_726  1
    arc_0_14_0  out_degree_769  1
    arc_0_14_0  original_T_including_depot_unload_822  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_509  1
    load_0_14_0  free_load_conservation_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_510  -20
    arc_0_14_1  connected_order_arc_511  -15
    arc_0_14_1  in_degree_728  1
    arc_0_14_1  out_degree_769  1
    arc_0_14_1  original_T_including_depot_unload_822  2.8083660458664087e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_510  1
    load_0_14_1  segment_load_conservation_731  -1
    load_0_14_1  segment_prefix_lb_732  1
    load_0_14_1  segment_prefix_ub_733  1
    load_0_14_1  free_load_conservation_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_512  -20
    arc_0_14_2  connected_order_arc_513  -15
    arc_0_14_2  in_degree_735  1
    arc_0_14_2  out_degree_769  1
    arc_0_14_2  original_T_including_depot_unload_822  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_512  1
    load_0_14_2  segment_load_conservation_738  -1
    load_0_14_2  segment_prefix_lb_739  1
    load_0_14_2  segment_prefix_ub_740  1
    load_0_14_2  free_load_conservation_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_514  -20
    arc_0_14_3  connected_order_arc_515  -15
    arc_0_14_3  in_degree_742  1
    arc_0_14_3  out_degree_769  1
    arc_0_14_3  original_T_including_depot_unload_822  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_514  1
    load_0_14_3  segment_load_conservation_745  -1
    load_0_14_3  segment_prefix_lb_746  1
    load_0_14_3  segment_prefix_ub_747  1
    load_0_14_3  free_load_conservation_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_516  -20
    arc_0_14_4  connected_order_arc_517  -15
    arc_0_14_4  in_degree_749  1
    arc_0_14_4  out_degree_769  1
    arc_0_14_4  original_T_including_depot_unload_822  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_516  1
    load_0_14_4  segment_load_conservation_752  -1
    load_0_14_4  segment_prefix_lb_753  1
    load_0_14_4  segment_prefix_ub_754  1
    load_0_14_4  free_load_conservation_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_518  -20
    arc_0_14_5  connected_order_arc_519  -15
    arc_0_14_5  in_degree_756  1
    arc_0_14_5  out_degree_769  1
    arc_0_14_5  original_T_including_depot_unload_822  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_518  1
    load_0_14_5  segment_load_conservation_759  -1
    load_0_14_5  segment_prefix_lb_760  1
    load_0_14_5  segment_prefix_ub_761  1
    load_0_14_5  free_load_conservation_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_6  arc_capacity_520  -20
    arc_0_14_6  connected_order_arc_521  -15
    arc_0_14_6  in_degree_763  1
    arc_0_14_6  out_degree_769  1
    arc_0_14_6  original_T_including_depot_unload_822  4.3907641772187384e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_6  arc_capacity_520  1
    load_0_14_6  segment_load_conservation_766  -1
    load_0_14_6  segment_prefix_lb_767  1
    load_0_14_6  segment_prefix_ub_768  1
    load_0_14_6  free_load_conservation_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_522  -20
    arc_0_14_15  connected_order_arc_523  -15
    arc_0_14_15  out_degree_769  1
    arc_0_14_15  in_degree_776  1
    arc_0_14_15  original_T_including_depot_unload_822  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_522  1
    load_0_14_15  free_load_conservation_774  1
    load_0_14_15  free_load_conservation_780  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_524  -20
    arc_0_14_16  connected_order_arc_525  -15
    arc_0_14_16  out_degree_769  1
    arc_0_14_16  in_degree_782  1
    arc_0_14_16  original_T_including_depot_unload_822  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_524  1
    load_0_14_16  free_load_conservation_774  1
    load_0_14_16  free_load_conservation_786  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_526  -20
    arc_0_14_17  connected_order_arc_527  -15
    arc_0_14_17  out_degree_769  1
    arc_0_14_17  in_degree_788  1
    arc_0_14_17  original_T_including_depot_unload_822  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_526  1
    load_0_14_17  free_load_conservation_774  1
    load_0_14_17  free_load_conservation_792  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_528  -20
    arc_0_14_18  connected_order_arc_529  -15
    arc_0_14_18  out_degree_769  1
    arc_0_14_18  in_degree_794  1
    arc_0_14_18  original_T_including_depot_unload_822  1.7807233899807140e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_528  1
    load_0_14_18  free_load_conservation_774  1
    load_0_14_18  free_load_conservation_798  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_530  -20
    arc_0_14_19  connected_order_arc_531  -15
    arc_0_14_19  out_degree_769  1
    arc_0_14_19  in_degree_800  1
    arc_0_14_19  original_T_including_depot_unload_822  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_530  1
    load_0_14_19  free_load_conservation_774  1
    load_0_14_19  free_load_conservation_804  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_532  -20
    arc_0_14_20  connected_order_arc_533  -15
    arc_0_14_20  out_degree_769  1
    arc_0_14_20  in_degree_806  1
    arc_0_14_20  original_T_including_depot_unload_822  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_532  1
    load_0_14_20  free_load_conservation_774  1
    load_0_14_20  free_load_conservation_810  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_21  arc_capacity_534  -20
    arc_0_14_21  connected_order_arc_535  -15
    arc_0_14_21  out_degree_769  1
    arc_0_14_21  in_degree_812  1
    arc_0_14_21  original_T_including_depot_unload_822  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_21  arc_capacity_534  1
    load_0_14_21  free_load_conservation_774  1
    load_0_14_21  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_536  -20
    arc_0_15_0  depot_return_or_bypass_726  1
    arc_0_15_0  out_degree_775  1
    arc_0_15_0  original_T_including_depot_unload_822  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_536  1
    load_0_15_0  free_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_537  -20
    arc_0_15_1  connected_order_arc_538  -15
    arc_0_15_1  in_degree_728  1
    arc_0_15_1  out_degree_775  1
    arc_0_15_1  original_T_including_depot_unload_822  3.9263280945415767e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_537  1
    load_0_15_1  segment_load_conservation_731  -1
    load_0_15_1  segment_prefix_lb_732  1
    load_0_15_1  segment_prefix_ub_733  1
    load_0_15_1  free_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_539  -20
    arc_0_15_2  connected_order_arc_540  -15
    arc_0_15_2  in_degree_735  1
    arc_0_15_2  out_degree_775  1
    arc_0_15_2  original_T_including_depot_unload_822  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_539  1
    load_0_15_2  segment_load_conservation_738  -1
    load_0_15_2  segment_prefix_lb_739  1
    load_0_15_2  segment_prefix_ub_740  1
    load_0_15_2  free_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_541  -20
    arc_0_15_3  connected_order_arc_542  -15
    arc_0_15_3  in_degree_742  1
    arc_0_15_3  out_degree_775  1
    arc_0_15_3  original_T_including_depot_unload_822  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_541  1
    load_0_15_3  segment_load_conservation_745  -1
    load_0_15_3  segment_prefix_lb_746  1
    load_0_15_3  segment_prefix_ub_747  1
    load_0_15_3  free_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_543  -20
    arc_0_15_4  connected_order_arc_544  -15
    arc_0_15_4  in_degree_749  1
    arc_0_15_4  out_degree_775  1
    arc_0_15_4  original_T_including_depot_unload_822  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_543  1
    load_0_15_4  segment_load_conservation_752  -1
    load_0_15_4  segment_prefix_lb_753  1
    load_0_15_4  segment_prefix_ub_754  1
    load_0_15_4  free_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_545  -20
    arc_0_15_5  connected_order_arc_546  -15
    arc_0_15_5  in_degree_756  1
    arc_0_15_5  out_degree_775  1
    arc_0_15_5  original_T_including_depot_unload_822  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_545  1
    load_0_15_5  segment_load_conservation_759  -1
    load_0_15_5  segment_prefix_lb_760  1
    load_0_15_5  segment_prefix_ub_761  1
    load_0_15_5  free_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_547  -20
    arc_0_15_6  connected_order_arc_548  -15
    arc_0_15_6  in_degree_763  1
    arc_0_15_6  out_degree_775  1
    arc_0_15_6  original_T_including_depot_unload_822  5.5115772567966917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_547  1
    load_0_15_6  segment_load_conservation_766  -1
    load_0_15_6  segment_prefix_lb_767  1
    load_0_15_6  segment_prefix_ub_768  1
    load_0_15_6  free_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_549  -20
    arc_0_15_14  connected_order_arc_550  -15
    arc_0_15_14  in_degree_770  1
    arc_0_15_14  out_degree_775  1
    arc_0_15_14  original_T_including_depot_unload_822  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_549  1
    load_0_15_14  free_load_conservation_774  -1
    load_0_15_14  free_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_551  -20
    arc_0_15_16  connected_order_arc_552  -15
    arc_0_15_16  out_degree_775  1
    arc_0_15_16  in_degree_782  1
    arc_0_15_16  original_T_including_depot_unload_822  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_551  1
    load_0_15_16  free_load_conservation_780  1
    load_0_15_16  free_load_conservation_786  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_553  -20
    arc_0_15_17  connected_order_arc_554  -15
    arc_0_15_17  out_degree_775  1
    arc_0_15_17  in_degree_788  1
    arc_0_15_17  original_T_including_depot_unload_822  2.6361257108552718e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_553  1
    load_0_15_17  free_load_conservation_780  1
    load_0_15_17  free_load_conservation_792  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_555  -20
    arc_0_15_18  connected_order_arc_556  -15
    arc_0_15_18  out_degree_775  1
    arc_0_15_18  in_degree_794  1
    arc_0_15_18  original_T_including_depot_unload_822  1.8786452499301340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_555  1
    load_0_15_18  free_load_conservation_780  1
    load_0_15_18  free_load_conservation_798  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_557  -20
    arc_0_15_19  connected_order_arc_558  -15
    arc_0_15_19  out_degree_775  1
    arc_0_15_19  in_degree_800  1
    arc_0_15_19  original_T_including_depot_unload_822  2.6417860079316790e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_557  1
    load_0_15_19  free_load_conservation_780  1
    load_0_15_19  free_load_conservation_804  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_559  -20
    arc_0_15_20  connected_order_arc_560  -15
    arc_0_15_20  out_degree_775  1
    arc_0_15_20  in_degree_806  1
    arc_0_15_20  original_T_including_depot_unload_822  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_559  1
    load_0_15_20  free_load_conservation_780  1
    load_0_15_20  free_load_conservation_810  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_561  -20
    arc_0_15_21  connected_order_arc_562  -15
    arc_0_15_21  out_degree_775  1
    arc_0_15_21  in_degree_812  1
    arc_0_15_21  original_T_including_depot_unload_822  2.6477572380586179e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_561  1
    load_0_15_21  free_load_conservation_780  1
    load_0_15_21  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_563  -20
    arc_0_16_0  depot_return_or_bypass_726  1
    arc_0_16_0  out_degree_781  1
    arc_0_16_0  original_T_including_depot_unload_822  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_563  1
    load_0_16_0  free_load_conservation_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_564  -20
    arc_0_16_1  connected_order_arc_565  -15
    arc_0_16_1  in_degree_728  1
    arc_0_16_1  out_degree_781  1
    arc_0_16_1  original_T_including_depot_unload_822  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_564  1
    load_0_16_1  segment_load_conservation_731  -1
    load_0_16_1  segment_prefix_lb_732  1
    load_0_16_1  segment_prefix_ub_733  1
    load_0_16_1  free_load_conservation_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_566  -20
    arc_0_16_2  connected_order_arc_567  -15
    arc_0_16_2  in_degree_735  1
    arc_0_16_2  out_degree_781  1
    arc_0_16_2  original_T_including_depot_unload_822  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_566  1
    load_0_16_2  segment_load_conservation_738  -1
    load_0_16_2  segment_prefix_lb_739  1
    load_0_16_2  segment_prefix_ub_740  1
    load_0_16_2  free_load_conservation_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_568  -20
    arc_0_16_3  connected_order_arc_569  -15
    arc_0_16_3  in_degree_742  1
    arc_0_16_3  out_degree_781  1
    arc_0_16_3  original_T_including_depot_unload_822  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_568  1
    load_0_16_3  segment_load_conservation_745  -1
    load_0_16_3  segment_prefix_lb_746  1
    load_0_16_3  segment_prefix_ub_747  1
    load_0_16_3  free_load_conservation_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_570  -20
    arc_0_16_4  connected_order_arc_571  -15
    arc_0_16_4  in_degree_749  1
    arc_0_16_4  out_degree_781  1
    arc_0_16_4  original_T_including_depot_unload_822  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_570  1
    load_0_16_4  segment_load_conservation_752  -1
    load_0_16_4  segment_prefix_lb_753  1
    load_0_16_4  segment_prefix_ub_754  1
    load_0_16_4  free_load_conservation_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_572  -20
    arc_0_16_5  connected_order_arc_573  -15
    arc_0_16_5  in_degree_756  1
    arc_0_16_5  out_degree_781  1
    arc_0_16_5  original_T_including_depot_unload_822  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_572  1
    load_0_16_5  segment_load_conservation_759  -1
    load_0_16_5  segment_prefix_lb_760  1
    load_0_16_5  segment_prefix_ub_761  1
    load_0_16_5  free_load_conservation_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_574  -20
    arc_0_16_6  connected_order_arc_575  -15
    arc_0_16_6  in_degree_763  1
    arc_0_16_6  out_degree_781  1
    arc_0_16_6  original_T_including_depot_unload_822  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_574  1
    load_0_16_6  segment_load_conservation_766  -1
    load_0_16_6  segment_prefix_lb_767  1
    load_0_16_6  segment_prefix_ub_768  1
    load_0_16_6  free_load_conservation_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_576  -20
    arc_0_16_14  connected_order_arc_577  -15
    arc_0_16_14  in_degree_770  1
    arc_0_16_14  out_degree_781  1
    arc_0_16_14  original_T_including_depot_unload_822  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_576  1
    load_0_16_14  free_load_conservation_774  -1
    load_0_16_14  free_load_conservation_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_578  -20
    arc_0_16_15  connected_order_arc_579  -15
    arc_0_16_15  in_degree_776  1
    arc_0_16_15  out_degree_781  1
    arc_0_16_15  original_T_including_depot_unload_822  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_578  1
    load_0_16_15  free_load_conservation_780  -1
    load_0_16_15  free_load_conservation_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_580  -20
    arc_0_16_17  connected_order_arc_581  -15
    arc_0_16_17  out_degree_781  1
    arc_0_16_17  in_degree_788  1
    arc_0_16_17  original_T_including_depot_unload_822  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_580  1
    load_0_16_17  free_load_conservation_786  1
    load_0_16_17  free_load_conservation_792  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_582  -20
    arc_0_16_18  connected_order_arc_583  -15
    arc_0_16_18  out_degree_781  1
    arc_0_16_18  in_degree_794  1
    arc_0_16_18  original_T_including_depot_unload_822  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_582  1
    load_0_16_18  free_load_conservation_786  1
    load_0_16_18  free_load_conservation_798  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_584  -20
    arc_0_16_19  connected_order_arc_585  -15
    arc_0_16_19  out_degree_781  1
    arc_0_16_19  in_degree_800  1
    arc_0_16_19  original_T_including_depot_unload_822  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_584  1
    load_0_16_19  free_load_conservation_786  1
    load_0_16_19  free_load_conservation_804  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_586  -20
    arc_0_16_20  connected_order_arc_587  -15
    arc_0_16_20  out_degree_781  1
    arc_0_16_20  in_degree_806  1
    arc_0_16_20  original_T_including_depot_unload_822  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_586  1
    load_0_16_20  free_load_conservation_786  1
    load_0_16_20  free_load_conservation_810  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_588  -20
    arc_0_16_21  connected_order_arc_589  -15
    arc_0_16_21  out_degree_781  1
    arc_0_16_21  in_degree_812  1
    arc_0_16_21  original_T_including_depot_unload_822  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_588  1
    load_0_16_21  free_load_conservation_786  1
    load_0_16_21  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_590  -20
    arc_0_17_0  depot_return_or_bypass_726  1
    arc_0_17_0  out_degree_787  1
    arc_0_17_0  original_T_including_depot_unload_822  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_590  1
    load_0_17_0  free_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_591  -20
    arc_0_17_1  connected_order_arc_592  -15
    arc_0_17_1  in_degree_728  1
    arc_0_17_1  out_degree_787  1
    arc_0_17_1  original_T_including_depot_unload_822  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_591  1
    load_0_17_1  segment_load_conservation_731  -1
    load_0_17_1  segment_prefix_lb_732  1
    load_0_17_1  segment_prefix_ub_733  1
    load_0_17_1  free_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_593  -20
    arc_0_17_2  connected_order_arc_594  -15
    arc_0_17_2  in_degree_735  1
    arc_0_17_2  out_degree_787  1
    arc_0_17_2  original_T_including_depot_unload_822  477.665399637945
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_593  1
    load_0_17_2  segment_load_conservation_738  -1
    load_0_17_2  segment_prefix_lb_739  1
    load_0_17_2  segment_prefix_ub_740  1
    load_0_17_2  free_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_595  -20
    arc_0_17_3  connected_order_arc_596  -15
    arc_0_17_3  in_degree_742  1
    arc_0_17_3  out_degree_787  1
    arc_0_17_3  original_T_including_depot_unload_822  6.0146431446211739e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_595  1
    load_0_17_3  segment_load_conservation_745  -1
    load_0_17_3  segment_prefix_lb_746  1
    load_0_17_3  segment_prefix_ub_747  1
    load_0_17_3  free_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_597  -20
    arc_0_17_4  connected_order_arc_598  -15
    arc_0_17_4  in_degree_749  1
    arc_0_17_4  out_degree_787  1
    arc_0_17_4  original_T_including_depot_unload_822  3.8949255894881873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_597  1
    load_0_17_4  segment_load_conservation_752  -1
    load_0_17_4  segment_prefix_lb_753  1
    load_0_17_4  segment_prefix_ub_754  1
    load_0_17_4  free_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_599  -20
    arc_0_17_5  connected_order_arc_600  -15
    arc_0_17_5  in_degree_756  1
    arc_0_17_5  out_degree_787  1
    arc_0_17_5  original_T_including_depot_unload_822  4.5635886855303721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_599  1
    load_0_17_5  segment_load_conservation_759  -1
    load_0_17_5  segment_prefix_lb_760  1
    load_0_17_5  segment_prefix_ub_761  1
    load_0_17_5  free_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_6  arc_capacity_601  -20
    arc_0_17_6  connected_order_arc_602  -15
    arc_0_17_6  in_degree_763  1
    arc_0_17_6  out_degree_787  1
    arc_0_17_6  original_T_including_depot_unload_822  2.8856753867620006e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_6  arc_capacity_601  1
    load_0_17_6  segment_load_conservation_766  -1
    load_0_17_6  segment_prefix_lb_767  1
    load_0_17_6  segment_prefix_ub_768  1
    load_0_17_6  free_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_603  -20
    arc_0_17_14  connected_order_arc_604  -15
    arc_0_17_14  in_degree_770  1
    arc_0_17_14  out_degree_787  1
    arc_0_17_14  original_T_including_depot_unload_822  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_603  1
    load_0_17_14  free_load_conservation_774  -1
    load_0_17_14  free_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_605  -20
    arc_0_17_15  connected_order_arc_606  -15
    arc_0_17_15  in_degree_776  1
    arc_0_17_15  out_degree_787  1
    arc_0_17_15  original_T_including_depot_unload_822  2.6361257108552718e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_605  1
    load_0_17_15  free_load_conservation_780  -1
    load_0_17_15  free_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_607  -20
    arc_0_17_16  connected_order_arc_608  -15
    arc_0_17_16  in_degree_782  1
    arc_0_17_16  out_degree_787  1
    arc_0_17_16  original_T_including_depot_unload_822  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_607  1
    load_0_17_16  free_load_conservation_786  -1
    load_0_17_16  free_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_609  -20
    arc_0_17_18  connected_order_arc_610  -15
    arc_0_17_18  out_degree_787  1
    arc_0_17_18  in_degree_794  1
    arc_0_17_18  original_T_including_depot_unload_822  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_609  1
    load_0_17_18  free_load_conservation_792  1
    load_0_17_18  free_load_conservation_798  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_611  -20
    arc_0_17_19  connected_order_arc_612  -15
    arc_0_17_19  out_degree_787  1
    arc_0_17_19  in_degree_800  1
    arc_0_17_19  original_T_including_depot_unload_822  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_611  1
    load_0_17_19  free_load_conservation_792  1
    load_0_17_19  free_load_conservation_804  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_613  -20
    arc_0_17_20  connected_order_arc_614  -15
    arc_0_17_20  out_degree_787  1
    arc_0_17_20  in_degree_806  1
    arc_0_17_20  original_T_including_depot_unload_822  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_613  1
    load_0_17_20  free_load_conservation_792  1
    load_0_17_20  free_load_conservation_810  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_615  -20
    arc_0_17_21  connected_order_arc_616  -15
    arc_0_17_21  out_degree_787  1
    arc_0_17_21  in_degree_812  1
    arc_0_17_21  original_T_including_depot_unload_822  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_615  1
    load_0_17_21  free_load_conservation_792  1
    load_0_17_21  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_617  -20
    arc_0_18_0  depot_return_or_bypass_726  1
    arc_0_18_0  out_degree_793  1
    arc_0_18_0  original_T_including_depot_unload_822  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_617  1
    load_0_18_0  free_load_conservation_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_618  -20
    arc_0_18_1  connected_order_arc_619  -15
    arc_0_18_1  in_degree_728  1
    arc_0_18_1  out_degree_793  1
    arc_0_18_1  original_T_including_depot_unload_822  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_618  1
    load_0_18_1  segment_load_conservation_731  -1
    load_0_18_1  segment_prefix_lb_732  1
    load_0_18_1  segment_prefix_ub_733  1
    load_0_18_1  free_load_conservation_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_620  -20
    arc_0_18_2  connected_order_arc_621  -15
    arc_0_18_2  in_degree_735  1
    arc_0_18_2  out_degree_793  1
    arc_0_18_2  original_T_including_depot_unload_822  2.0959764716808540e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_620  1
    load_0_18_2  segment_load_conservation_738  -1
    load_0_18_2  segment_prefix_lb_739  1
    load_0_18_2  segment_prefix_ub_740  1
    load_0_18_2  free_load_conservation_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_622  -20
    arc_0_18_3  connected_order_arc_623  -15
    arc_0_18_3  in_degree_742  1
    arc_0_18_3  out_degree_793  1
    arc_0_18_3  original_T_including_depot_unload_822  2.1132075050355038e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_622  1
    load_0_18_3  segment_load_conservation_745  -1
    load_0_18_3  segment_prefix_lb_746  1
    load_0_18_3  segment_prefix_ub_747  1
    load_0_18_3  free_load_conservation_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_624  -20
    arc_0_18_4  connected_order_arc_625  -15
    arc_0_18_4  in_degree_749  1
    arc_0_18_4  out_degree_793  1
    arc_0_18_4  original_T_including_depot_unload_822  1.8631004883789885e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_624  1
    load_0_18_4  segment_load_conservation_752  -1
    load_0_18_4  segment_prefix_lb_753  1
    load_0_18_4  segment_prefix_ub_754  1
    load_0_18_4  free_load_conservation_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_626  -20
    arc_0_18_5  connected_order_arc_627  -15
    arc_0_18_5  in_degree_756  1
    arc_0_18_5  out_degree_793  1
    arc_0_18_5  original_T_including_depot_unload_822  1.8150519376858174e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_626  1
    load_0_18_5  segment_load_conservation_759  -1
    load_0_18_5  segment_prefix_lb_760  1
    load_0_18_5  segment_prefix_ub_761  1
    load_0_18_5  free_load_conservation_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_6  arc_capacity_628  -20
    arc_0_18_6  connected_order_arc_629  -15
    arc_0_18_6  in_degree_763  1
    arc_0_18_6  out_degree_793  1
    arc_0_18_6  original_T_including_depot_unload_822  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_6  arc_capacity_628  1
    load_0_18_6  segment_load_conservation_766  -1
    load_0_18_6  segment_prefix_lb_767  1
    load_0_18_6  segment_prefix_ub_768  1
    load_0_18_6  free_load_conservation_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_630  -20
    arc_0_18_14  connected_order_arc_631  -15
    arc_0_18_14  in_degree_770  1
    arc_0_18_14  out_degree_793  1
    arc_0_18_14  original_T_including_depot_unload_822  1.7807233899807140e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_630  1
    load_0_18_14  free_load_conservation_774  -1
    load_0_18_14  free_load_conservation_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_632  -20
    arc_0_18_15  connected_order_arc_633  -15
    arc_0_18_15  in_degree_776  1
    arc_0_18_15  out_degree_793  1
    arc_0_18_15  original_T_including_depot_unload_822  1.8786452499301340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_632  1
    load_0_18_15  free_load_conservation_780  -1
    load_0_18_15  free_load_conservation_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_634  -20
    arc_0_18_16  connected_order_arc_635  -15
    arc_0_18_16  in_degree_782  1
    arc_0_18_16  out_degree_793  1
    arc_0_18_16  original_T_including_depot_unload_822  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_634  1
    load_0_18_16  free_load_conservation_786  -1
    load_0_18_16  free_load_conservation_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_636  -20
    arc_0_18_17  connected_order_arc_637  -15
    arc_0_18_17  in_degree_788  1
    arc_0_18_17  out_degree_793  1
    arc_0_18_17  original_T_including_depot_unload_822  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_636  1
    load_0_18_17  free_load_conservation_792  -1
    load_0_18_17  free_load_conservation_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_638  -20
    arc_0_18_19  connected_order_arc_639  -15
    arc_0_18_19  out_degree_793  1
    arc_0_18_19  in_degree_800  1
    arc_0_18_19  original_T_including_depot_unload_822  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_638  1
    load_0_18_19  free_load_conservation_798  1
    load_0_18_19  free_load_conservation_804  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_640  -20
    arc_0_18_20  connected_order_arc_641  -15
    arc_0_18_20  out_degree_793  1
    arc_0_18_20  in_degree_806  1
    arc_0_18_20  original_T_including_depot_unload_822  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_640  1
    load_0_18_20  free_load_conservation_798  1
    load_0_18_20  free_load_conservation_810  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_642  -20
    arc_0_18_21  connected_order_arc_643  -15
    arc_0_18_21  out_degree_793  1
    arc_0_18_21  in_degree_812  1
    arc_0_18_21  original_T_including_depot_unload_822  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_642  1
    load_0_18_21  free_load_conservation_798  1
    load_0_18_21  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_644  -20
    arc_0_19_0  depot_return_or_bypass_726  1
    arc_0_19_0  out_degree_799  1
    arc_0_19_0  original_T_including_depot_unload_822  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_644  1
    load_0_19_0  free_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_645  -20
    arc_0_19_1  connected_order_arc_646  -15
    arc_0_19_1  in_degree_728  1
    arc_0_19_1  out_degree_799  1
    arc_0_19_1  original_T_including_depot_unload_822  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_645  1
    load_0_19_1  segment_load_conservation_731  -1
    load_0_19_1  segment_prefix_lb_732  1
    load_0_19_1  segment_prefix_ub_733  1
    load_0_19_1  free_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_647  -20
    arc_0_19_2  connected_order_arc_648  -15
    arc_0_19_2  in_degree_735  1
    arc_0_19_2  out_degree_799  1
    arc_0_19_2  original_T_including_depot_unload_822  4.8210275478508015e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_647  1
    load_0_19_2  segment_load_conservation_738  -1
    load_0_19_2  segment_prefix_lb_739  1
    load_0_19_2  segment_prefix_ub_740  1
    load_0_19_2  free_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_649  -20
    arc_0_19_3  connected_order_arc_650  -15
    arc_0_19_3  in_degree_742  1
    arc_0_19_3  out_degree_799  1
    arc_0_19_3  original_T_including_depot_unload_822  5.9170757102467792e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_649  1
    load_0_19_3  segment_load_conservation_745  -1
    load_0_19_3  segment_prefix_lb_746  1
    load_0_19_3  segment_prefix_ub_747  1
    load_0_19_3  free_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_651  -20
    arc_0_19_4  connected_order_arc_652  -15
    arc_0_19_4  in_degree_749  1
    arc_0_19_4  out_degree_799  1
    arc_0_19_4  original_T_including_depot_unload_822  3.7084803914885475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_651  1
    load_0_19_4  segment_load_conservation_752  -1
    load_0_19_4  segment_prefix_lb_753  1
    load_0_19_4  segment_prefix_ub_754  1
    load_0_19_4  free_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_653  -20
    arc_0_19_5  connected_order_arc_654  -15
    arc_0_19_5  in_degree_756  1
    arc_0_19_5  out_degree_799  1
    arc_0_19_5  original_T_including_depot_unload_822  4.3076139952356033e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_653  1
    load_0_19_5  segment_load_conservation_759  -1
    load_0_19_5  segment_prefix_lb_760  1
    load_0_19_5  segment_prefix_ub_761  1
    load_0_19_5  free_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_6  arc_capacity_655  -20
    arc_0_19_6  connected_order_arc_656  -15
    arc_0_19_6  in_degree_763  1
    arc_0_19_6  out_degree_799  1
    arc_0_19_6  original_T_including_depot_unload_822  2.9672747884555446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_6  arc_capacity_655  1
    load_0_19_6  segment_load_conservation_766  -1
    load_0_19_6  segment_prefix_lb_767  1
    load_0_19_6  segment_prefix_ub_768  1
    load_0_19_6  free_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_657  -20
    arc_0_19_14  connected_order_arc_658  -15
    arc_0_19_14  in_degree_770  1
    arc_0_19_14  out_degree_799  1
    arc_0_19_14  original_T_including_depot_unload_822  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_657  1
    load_0_19_14  free_load_conservation_774  -1
    load_0_19_14  free_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_659  -20
    arc_0_19_15  connected_order_arc_660  -15
    arc_0_19_15  in_degree_776  1
    arc_0_19_15  out_degree_799  1
    arc_0_19_15  original_T_including_depot_unload_822  2.6417860079316790e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_659  1
    load_0_19_15  free_load_conservation_780  -1
    load_0_19_15  free_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_661  -20
    arc_0_19_16  connected_order_arc_662  -15
    arc_0_19_16  in_degree_782  1
    arc_0_19_16  out_degree_799  1
    arc_0_19_16  original_T_including_depot_unload_822  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_661  1
    load_0_19_16  free_load_conservation_786  -1
    load_0_19_16  free_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_663  -20
    arc_0_19_17  connected_order_arc_664  -15
    arc_0_19_17  in_degree_788  1
    arc_0_19_17  out_degree_799  1
    arc_0_19_17  original_T_including_depot_unload_822  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_663  1
    load_0_19_17  free_load_conservation_792  -1
    load_0_19_17  free_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_665  -20
    arc_0_19_18  connected_order_arc_666  -15
    arc_0_19_18  in_degree_794  1
    arc_0_19_18  out_degree_799  1
    arc_0_19_18  original_T_including_depot_unload_822  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_665  1
    load_0_19_18  free_load_conservation_798  -1
    load_0_19_18  free_load_conservation_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_667  -20
    arc_0_19_20  connected_order_arc_668  -15
    arc_0_19_20  out_degree_799  1
    arc_0_19_20  in_degree_806  1
    arc_0_19_20  original_T_including_depot_unload_822  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_667  1
    load_0_19_20  free_load_conservation_804  1
    load_0_19_20  free_load_conservation_810  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_669  -20
    arc_0_19_21  connected_order_arc_670  -15
    arc_0_19_21  out_degree_799  1
    arc_0_19_21  in_degree_812  1
    arc_0_19_21  original_T_including_depot_unload_822  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_669  1
    load_0_19_21  free_load_conservation_804  1
    load_0_19_21  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_671  -20
    arc_0_20_0  depot_return_or_bypass_726  1
    arc_0_20_0  out_degree_805  1
    arc_0_20_0  original_T_including_depot_unload_822  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_671  1
    load_0_20_0  free_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_672  -20
    arc_0_20_1  connected_order_arc_673  -15
    arc_0_20_1  in_degree_728  1
    arc_0_20_1  out_degree_805  1
    arc_0_20_1  original_T_including_depot_unload_822  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_672  1
    load_0_20_1  segment_load_conservation_731  -1
    load_0_20_1  segment_prefix_lb_732  1
    load_0_20_1  segment_prefix_ub_733  1
    load_0_20_1  free_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_674  -20
    arc_0_20_2  connected_order_arc_675  -15
    arc_0_20_2  in_degree_735  1
    arc_0_20_2  out_degree_805  1
    arc_0_20_2  original_T_including_depot_unload_822  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_674  1
    load_0_20_2  segment_load_conservation_738  -1
    load_0_20_2  segment_prefix_lb_739  1
    load_0_20_2  segment_prefix_ub_740  1
    load_0_20_2  free_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_676  -20
    arc_0_20_3  connected_order_arc_677  -15
    arc_0_20_3  in_degree_742  1
    arc_0_20_3  out_degree_805  1
    arc_0_20_3  original_T_including_depot_unload_822  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_676  1
    load_0_20_3  segment_load_conservation_745  -1
    load_0_20_3  segment_prefix_lb_746  1
    load_0_20_3  segment_prefix_ub_747  1
    load_0_20_3  free_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_678  -20
    arc_0_20_4  connected_order_arc_679  -15
    arc_0_20_4  in_degree_749  1
    arc_0_20_4  out_degree_805  1
    arc_0_20_4  original_T_including_depot_unload_822  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_678  1
    load_0_20_4  segment_load_conservation_752  -1
    load_0_20_4  segment_prefix_lb_753  1
    load_0_20_4  segment_prefix_ub_754  1
    load_0_20_4  free_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_680  -20
    arc_0_20_5  connected_order_arc_681  -15
    arc_0_20_5  in_degree_756  1
    arc_0_20_5  out_degree_805  1
    arc_0_20_5  original_T_including_depot_unload_822  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_680  1
    load_0_20_5  segment_load_conservation_759  -1
    load_0_20_5  segment_prefix_lb_760  1
    load_0_20_5  segment_prefix_ub_761  1
    load_0_20_5  free_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_6  arc_capacity_682  -20
    arc_0_20_6  connected_order_arc_683  -15
    arc_0_20_6  in_degree_763  1
    arc_0_20_6  out_degree_805  1
    arc_0_20_6  original_T_including_depot_unload_822  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_6  arc_capacity_682  1
    load_0_20_6  segment_load_conservation_766  -1
    load_0_20_6  segment_prefix_lb_767  1
    load_0_20_6  segment_prefix_ub_768  1
    load_0_20_6  free_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_684  -20
    arc_0_20_14  connected_order_arc_685  -15
    arc_0_20_14  in_degree_770  1
    arc_0_20_14  out_degree_805  1
    arc_0_20_14  original_T_including_depot_unload_822  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_684  1
    load_0_20_14  free_load_conservation_774  -1
    load_0_20_14  free_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_686  -20
    arc_0_20_15  connected_order_arc_687  -15
    arc_0_20_15  in_degree_776  1
    arc_0_20_15  out_degree_805  1
    arc_0_20_15  original_T_including_depot_unload_822  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_686  1
    load_0_20_15  free_load_conservation_780  -1
    load_0_20_15  free_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_688  -20
    arc_0_20_16  connected_order_arc_689  -15
    arc_0_20_16  in_degree_782  1
    arc_0_20_16  out_degree_805  1
    arc_0_20_16  original_T_including_depot_unload_822  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_688  1
    load_0_20_16  free_load_conservation_786  -1
    load_0_20_16  free_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_690  -20
    arc_0_20_17  connected_order_arc_691  -15
    arc_0_20_17  in_degree_788  1
    arc_0_20_17  out_degree_805  1
    arc_0_20_17  original_T_including_depot_unload_822  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_690  1
    load_0_20_17  free_load_conservation_792  -1
    load_0_20_17  free_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_692  -20
    arc_0_20_18  connected_order_arc_693  -15
    arc_0_20_18  in_degree_794  1
    arc_0_20_18  out_degree_805  1
    arc_0_20_18  original_T_including_depot_unload_822  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_692  1
    load_0_20_18  free_load_conservation_798  -1
    load_0_20_18  free_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_694  -20
    arc_0_20_19  connected_order_arc_695  -15
    arc_0_20_19  in_degree_800  1
    arc_0_20_19  out_degree_805  1
    arc_0_20_19  original_T_including_depot_unload_822  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_694  1
    load_0_20_19  free_load_conservation_804  -1
    load_0_20_19  free_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_696  -20
    arc_0_20_21  connected_order_arc_697  -15
    arc_0_20_21  out_degree_805  1
    arc_0_20_21  in_degree_812  1
    arc_0_20_21  original_T_including_depot_unload_822  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_696  1
    load_0_20_21  free_load_conservation_810  1
    load_0_20_21  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_698  -20
    arc_0_21_0  depot_return_or_bypass_726  1
    arc_0_21_0  out_degree_811  1
    arc_0_21_0  original_T_including_depot_unload_822  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_698  1
    load_0_21_0  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_699  -20
    arc_0_21_1  connected_order_arc_700  -15
    arc_0_21_1  in_degree_728  1
    arc_0_21_1  out_degree_811  1
    arc_0_21_1  original_T_including_depot_unload_822  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_699  1
    load_0_21_1  segment_load_conservation_731  -1
    load_0_21_1  segment_prefix_lb_732  1
    load_0_21_1  segment_prefix_ub_733  1
    load_0_21_1  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_701  -20
    arc_0_21_2  connected_order_arc_702  -15
    arc_0_21_2  in_degree_735  1
    arc_0_21_2  out_degree_811  1
    arc_0_21_2  original_T_including_depot_unload_822  4.8268503899521744e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_701  1
    load_0_21_2  segment_load_conservation_738  -1
    load_0_21_2  segment_prefix_lb_739  1
    load_0_21_2  segment_prefix_ub_740  1
    load_0_21_2  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_703  -20
    arc_0_21_3  connected_order_arc_704  -15
    arc_0_21_3  in_degree_742  1
    arc_0_21_3  out_degree_811  1
    arc_0_21_3  original_T_including_depot_unload_822  5.9232553492869590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_703  1
    load_0_21_3  segment_load_conservation_745  -1
    load_0_21_3  segment_prefix_lb_746  1
    load_0_21_3  segment_prefix_ub_747  1
    load_0_21_3  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_705  -20
    arc_0_21_4  connected_order_arc_706  -15
    arc_0_21_4  in_degree_749  1
    arc_0_21_4  out_degree_811  1
    arc_0_21_4  original_T_including_depot_unload_822  3.7143421209022068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_705  1
    load_0_21_4  segment_load_conservation_752  -1
    load_0_21_4  segment_prefix_lb_753  1
    load_0_21_4  segment_prefix_ub_754  1
    load_0_21_4  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_707  -20
    arc_0_21_5  connected_order_arc_708  -15
    arc_0_21_5  in_degree_756  1
    arc_0_21_5  out_degree_811  1
    arc_0_21_5  original_T_including_depot_unload_822  4.3127471875854752e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_707  1
    load_0_21_5  segment_load_conservation_759  -1
    load_0_21_5  segment_prefix_lb_760  1
    load_0_21_5  segment_prefix_ub_761  1
    load_0_21_5  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_6  arc_capacity_709  -20
    arc_0_21_6  connected_order_arc_710  -15
    arc_0_21_6  in_degree_763  1
    arc_0_21_6  out_degree_811  1
    arc_0_21_6  original_T_including_depot_unload_822  2.9611166330127878e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_6  arc_capacity_709  1
    load_0_21_6  segment_load_conservation_766  -1
    load_0_21_6  segment_prefix_lb_767  1
    load_0_21_6  segment_prefix_ub_768  1
    load_0_21_6  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_14  arc_capacity_711  -20
    arc_0_21_14  connected_order_arc_712  -15
    arc_0_21_14  in_degree_770  1
    arc_0_21_14  out_degree_811  1
    arc_0_21_14  original_T_including_depot_unload_822  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_14  arc_capacity_711  1
    load_0_21_14  free_load_conservation_774  -1
    load_0_21_14  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_713  -20
    arc_0_21_15  connected_order_arc_714  -15
    arc_0_21_15  in_degree_776  1
    arc_0_21_15  out_degree_811  1
    arc_0_21_15  original_T_including_depot_unload_822  2.6477572380586179e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_713  1
    load_0_21_15  free_load_conservation_780  -1
    load_0_21_15  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_715  -20
    arc_0_21_16  connected_order_arc_716  -15
    arc_0_21_16  in_degree_782  1
    arc_0_21_16  out_degree_811  1
    arc_0_21_16  original_T_including_depot_unload_822  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_715  1
    load_0_21_16  free_load_conservation_786  -1
    load_0_21_16  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_717  -20
    arc_0_21_17  connected_order_arc_718  -15
    arc_0_21_17  in_degree_788  1
    arc_0_21_17  out_degree_811  1
    arc_0_21_17  original_T_including_depot_unload_822  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_717  1
    load_0_21_17  free_load_conservation_792  -1
    load_0_21_17  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_719  -20
    arc_0_21_18  connected_order_arc_720  -15
    arc_0_21_18  in_degree_794  1
    arc_0_21_18  out_degree_811  1
    arc_0_21_18  original_T_including_depot_unload_822  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_719  1
    load_0_21_18  free_load_conservation_798  -1
    load_0_21_18  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_721  -20
    arc_0_21_19  connected_order_arc_722  -15
    arc_0_21_19  in_degree_800  1
    arc_0_21_19  out_degree_811  1
    arc_0_21_19  original_T_including_depot_unload_822  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_721  1
    load_0_21_19  free_load_conservation_804  -1
    load_0_21_19  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_723  -20
    arc_0_21_20  connected_order_arc_724  -15
    arc_0_21_20  in_degree_806  1
    arc_0_21_20  out_degree_811  1
    arc_0_21_20  original_T_including_depot_unload_822  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_723  1
    load_0_21_20  free_load_conservation_810  -1
    load_0_21_20  free_load_conservation_816  1
    visit_1_7  out_degree_1114  -1
    visit_1_7  in_degree_1115  -1
    visit_1_7  order_active_lb_1116  -1
    visit_1_7  order_active_ub_1117  -12
    order_1_7  connected_order_arc_838  -1
    order_1_7  connected_order_arc_840  -1
    order_1_7  connected_order_arc_842  -1
    order_1_7  connected_order_arc_844  -1
    order_1_7  connected_order_arc_846  -1
    order_1_7  connected_order_arc_848  -1
    order_1_7  connected_order_arc_850  -1
    order_1_7  connected_order_arc_852  -1
    order_1_7  connected_order_arc_854  -1
    order_1_7  connected_order_arc_856  -1
    order_1_7  connected_order_arc_858  -1
    order_1_7  connected_order_arc_861  1
    order_1_7  connected_order_arc_884  1
    order_1_7  connected_order_arc_907  1
    order_1_7  connected_order_arc_930  1
    order_1_7  connected_order_arc_953  1
    order_1_7  connected_order_arc_976  1
    order_1_7  connected_order_arc_999  1
    order_1_7  connected_order_arc_1022  1
    order_1_7  connected_order_arc_1045  1
    order_1_7  connected_order_arc_1068  1
    order_1_7  connected_order_arc_1091  1
    order_1_7  order_active_lb_1116  1
    order_1_7  order_active_ub_1117  1
    order_1_7  fixed_segment_relative_order_1190  -1
    visit_1_8  out_degree_1121  -1
    visit_1_8  in_degree_1122  -1
    visit_1_8  order_active_lb_1123  -1
    visit_1_8  order_active_ub_1124  -12
    order_1_8  connected_order_arc_838  1
    order_1_8  connected_order_arc_861  -1
    order_1_8  connected_order_arc_863  -1
    order_1_8  connected_order_arc_865  -1
    order_1_8  connected_order_arc_867  -1
    order_1_8  connected_order_arc_869  -1
    order_1_8  connected_order_arc_871  -1
    order_1_8  connected_order_arc_873  -1
    order_1_8  connected_order_arc_875  -1
    order_1_8  connected_order_arc_877  -1
    order_1_8  connected_order_arc_879  -1
    order_1_8  connected_order_arc_881  -1
    order_1_8  connected_order_arc_886  1
    order_1_8  connected_order_arc_909  1
    order_1_8  connected_order_arc_932  1
    order_1_8  connected_order_arc_955  1
    order_1_8  connected_order_arc_978  1
    order_1_8  connected_order_arc_1001  1
    order_1_8  connected_order_arc_1024  1
    order_1_8  connected_order_arc_1047  1
    order_1_8  connected_order_arc_1070  1
    order_1_8  connected_order_arc_1093  1
    order_1_8  order_active_lb_1123  1
    order_1_8  order_active_ub_1124  1
    order_1_8  fixed_segment_relative_order_1190  1
    order_1_8  fixed_segment_relative_order_1191  -1
    visit_1_9  out_degree_1128  -1
    visit_1_9  in_degree_1129  -1
    visit_1_9  order_active_lb_1130  -1
    visit_1_9  order_active_ub_1131  -12
    order_1_9  connected_order_arc_840  1
    order_1_9  connected_order_arc_863  1
    order_1_9  connected_order_arc_884  -1
    order_1_9  connected_order_arc_886  -1
    order_1_9  connected_order_arc_888  -1
    order_1_9  connected_order_arc_890  -1
    order_1_9  connected_order_arc_892  -1
    order_1_9  connected_order_arc_894  -1
    order_1_9  connected_order_arc_896  -1
    order_1_9  connected_order_arc_898  -1
    order_1_9  connected_order_arc_900  -1
    order_1_9  connected_order_arc_902  -1
    order_1_9  connected_order_arc_904  -1
    order_1_9  connected_order_arc_911  1
    order_1_9  connected_order_arc_934  1
    order_1_9  connected_order_arc_957  1
    order_1_9  connected_order_arc_980  1
    order_1_9  connected_order_arc_1003  1
    order_1_9  connected_order_arc_1026  1
    order_1_9  connected_order_arc_1049  1
    order_1_9  connected_order_arc_1072  1
    order_1_9  connected_order_arc_1095  1
    order_1_9  order_active_lb_1130  1
    order_1_9  order_active_ub_1131  1
    order_1_9  fixed_segment_relative_order_1191  1
    order_1_9  fixed_segment_relative_order_1192  -1
    visit_1_10  out_degree_1135  -1
    visit_1_10  in_degree_1136  -1
    visit_1_10  order_active_lb_1137  -1
    visit_1_10  order_active_ub_1138  -12
    order_1_10  connected_order_arc_842  1
    order_1_10  connected_order_arc_865  1
    order_1_10  connected_order_arc_888  1
    order_1_10  connected_order_arc_907  -1
    order_1_10  connected_order_arc_909  -1
    order_1_10  connected_order_arc_911  -1
    order_1_10  connected_order_arc_913  -1
    order_1_10  connected_order_arc_915  -1
    order_1_10  connected_order_arc_917  -1
    order_1_10  connected_order_arc_919  -1
    order_1_10  connected_order_arc_921  -1
    order_1_10  connected_order_arc_923  -1
    order_1_10  connected_order_arc_925  -1
    order_1_10  connected_order_arc_927  -1
    order_1_10  connected_order_arc_936  1
    order_1_10  connected_order_arc_959  1
    order_1_10  connected_order_arc_982  1
    order_1_10  connected_order_arc_1005  1
    order_1_10  connected_order_arc_1028  1
    order_1_10  connected_order_arc_1051  1
    order_1_10  connected_order_arc_1074  1
    order_1_10  connected_order_arc_1097  1
    order_1_10  order_active_lb_1137  1
    order_1_10  order_active_ub_1138  1
    order_1_10  fixed_segment_relative_order_1192  1
    visit_1_14  out_degree_1142  -1
    visit_1_14  in_degree_1143  -1
    visit_1_14  order_active_lb_1144  -1
    visit_1_14  order_active_ub_1145  -12
    visit_1_14  service_visit_def_1146  -1
    order_1_14  connected_order_arc_844  1
    order_1_14  connected_order_arc_867  1
    order_1_14  connected_order_arc_890  1
    order_1_14  connected_order_arc_913  1
    order_1_14  connected_order_arc_930  -1
    order_1_14  connected_order_arc_932  -1
    order_1_14  connected_order_arc_934  -1
    order_1_14  connected_order_arc_936  -1
    order_1_14  connected_order_arc_938  -1
    order_1_14  connected_order_arc_940  -1
    order_1_14  connected_order_arc_942  -1
    order_1_14  connected_order_arc_944  -1
    order_1_14  connected_order_arc_946  -1
    order_1_14  connected_order_arc_948  -1
    order_1_14  connected_order_arc_950  -1
    order_1_14  connected_order_arc_961  1
    order_1_14  connected_order_arc_984  1
    order_1_14  connected_order_arc_1007  1
    order_1_14  connected_order_arc_1030  1
    order_1_14  connected_order_arc_1053  1
    order_1_14  connected_order_arc_1076  1
    order_1_14  connected_order_arc_1099  1
    order_1_14  order_active_lb_1144  1
    order_1_14  order_active_ub_1145  1
    visit_1_15  out_degree_1148  -1
    visit_1_15  in_degree_1149  -1
    visit_1_15  order_active_lb_1150  -1
    visit_1_15  order_active_ub_1151  -12
    visit_1_15  service_visit_def_1152  -1
    order_1_15  connected_order_arc_846  1
    order_1_15  connected_order_arc_869  1
    order_1_15  connected_order_arc_892  1
    order_1_15  connected_order_arc_915  1
    order_1_15  connected_order_arc_938  1
    order_1_15  connected_order_arc_953  -1
    order_1_15  connected_order_arc_955  -1
    order_1_15  connected_order_arc_957  -1
    order_1_15  connected_order_arc_959  -1
    order_1_15  connected_order_arc_961  -1
    order_1_15  connected_order_arc_963  -1
    order_1_15  connected_order_arc_965  -1
    order_1_15  connected_order_arc_967  -1
    order_1_15  connected_order_arc_969  -1
    order_1_15  connected_order_arc_971  -1
    order_1_15  connected_order_arc_973  -1
    order_1_15  connected_order_arc_986  1
    order_1_15  connected_order_arc_1009  1
    order_1_15  connected_order_arc_1032  1
    order_1_15  connected_order_arc_1055  1
    order_1_15  connected_order_arc_1078  1
    order_1_15  connected_order_arc_1101  1
    order_1_15  order_active_lb_1150  1
    order_1_15  order_active_ub_1151  1
    visit_1_16  out_degree_1154  -1
    visit_1_16  in_degree_1155  -1
    visit_1_16  order_active_lb_1156  -1
    visit_1_16  order_active_ub_1157  -12
    visit_1_16  service_visit_def_1158  -1
    order_1_16  connected_order_arc_848  1
    order_1_16  connected_order_arc_871  1
    order_1_16  connected_order_arc_894  1
    order_1_16  connected_order_arc_917  1
    order_1_16  connected_order_arc_940  1
    order_1_16  connected_order_arc_963  1
    order_1_16  connected_order_arc_976  -1
    order_1_16  connected_order_arc_978  -1
    order_1_16  connected_order_arc_980  -1
    order_1_16  connected_order_arc_982  -1
    order_1_16  connected_order_arc_984  -1
    order_1_16  connected_order_arc_986  -1
    order_1_16  connected_order_arc_988  -1
    order_1_16  connected_order_arc_990  -1
    order_1_16  connected_order_arc_992  -1
    order_1_16  connected_order_arc_994  -1
    order_1_16  connected_order_arc_996  -1
    order_1_16  connected_order_arc_1011  1
    order_1_16  connected_order_arc_1034  1
    order_1_16  connected_order_arc_1057  1
    order_1_16  connected_order_arc_1080  1
    order_1_16  connected_order_arc_1103  1
    order_1_16  order_active_lb_1156  1
    order_1_16  order_active_ub_1157  1
    visit_1_17  out_degree_1160  -1
    visit_1_17  in_degree_1161  -1
    visit_1_17  order_active_lb_1162  -1
    visit_1_17  order_active_ub_1163  -12
    visit_1_17  service_visit_def_1164  -1
    order_1_17  connected_order_arc_850  1
    order_1_17  connected_order_arc_873  1
    order_1_17  connected_order_arc_896  1
    order_1_17  connected_order_arc_919  1
    order_1_17  connected_order_arc_942  1
    order_1_17  connected_order_arc_965  1
    order_1_17  connected_order_arc_988  1
    order_1_17  connected_order_arc_999  -1
    order_1_17  connected_order_arc_1001  -1
    order_1_17  connected_order_arc_1003  -1
    order_1_17  connected_order_arc_1005  -1
    order_1_17  connected_order_arc_1007  -1
    order_1_17  connected_order_arc_1009  -1
    order_1_17  connected_order_arc_1011  -1
    order_1_17  connected_order_arc_1013  -1
    order_1_17  connected_order_arc_1015  -1
    order_1_17  connected_order_arc_1017  -1
    order_1_17  connected_order_arc_1019  -1
    order_1_17  connected_order_arc_1036  1
    order_1_17  connected_order_arc_1059  1
    order_1_17  connected_order_arc_1082  1
    order_1_17  connected_order_arc_1105  1
    order_1_17  order_active_lb_1162  1
    order_1_17  order_active_ub_1163  1
    visit_1_18  out_degree_1166  -1
    visit_1_18  in_degree_1167  -1
    visit_1_18  order_active_lb_1168  -1
    visit_1_18  order_active_ub_1169  -12
    visit_1_18  service_visit_def_1170  -1
    order_1_18  connected_order_arc_852  1
    order_1_18  connected_order_arc_875  1
    order_1_18  connected_order_arc_898  1
    order_1_18  connected_order_arc_921  1
    order_1_18  connected_order_arc_944  1
    order_1_18  connected_order_arc_967  1
    order_1_18  connected_order_arc_990  1
    order_1_18  connected_order_arc_1013  1
    order_1_18  connected_order_arc_1022  -1
    order_1_18  connected_order_arc_1024  -1
    order_1_18  connected_order_arc_1026  -1
    order_1_18  connected_order_arc_1028  -1
    order_1_18  connected_order_arc_1030  -1
    order_1_18  connected_order_arc_1032  -1
    order_1_18  connected_order_arc_1034  -1
    order_1_18  connected_order_arc_1036  -1
    order_1_18  connected_order_arc_1038  -1
    order_1_18  connected_order_arc_1040  -1
    order_1_18  connected_order_arc_1042  -1
    order_1_18  connected_order_arc_1061  1
    order_1_18  connected_order_arc_1084  1
    order_1_18  connected_order_arc_1107  1
    order_1_18  order_active_lb_1168  1
    order_1_18  order_active_ub_1169  1
    visit_1_19  out_degree_1172  -1
    visit_1_19  in_degree_1173  -1
    visit_1_19  order_active_lb_1174  -1
    visit_1_19  order_active_ub_1175  -12
    visit_1_19  service_visit_def_1176  -1
    order_1_19  connected_order_arc_854  1
    order_1_19  connected_order_arc_877  1
    order_1_19  connected_order_arc_900  1
    order_1_19  connected_order_arc_923  1
    order_1_19  connected_order_arc_946  1
    order_1_19  connected_order_arc_969  1
    order_1_19  connected_order_arc_992  1
    order_1_19  connected_order_arc_1015  1
    order_1_19  connected_order_arc_1038  1
    order_1_19  connected_order_arc_1045  -1
    order_1_19  connected_order_arc_1047  -1
    order_1_19  connected_order_arc_1049  -1
    order_1_19  connected_order_arc_1051  -1
    order_1_19  connected_order_arc_1053  -1
    order_1_19  connected_order_arc_1055  -1
    order_1_19  connected_order_arc_1057  -1
    order_1_19  connected_order_arc_1059  -1
    order_1_19  connected_order_arc_1061  -1
    order_1_19  connected_order_arc_1063  -1
    order_1_19  connected_order_arc_1065  -1
    order_1_19  connected_order_arc_1086  1
    order_1_19  connected_order_arc_1109  1
    order_1_19  order_active_lb_1174  1
    order_1_19  order_active_ub_1175  1
    visit_1_20  out_degree_1178  -1
    visit_1_20  in_degree_1179  -1
    visit_1_20  order_active_lb_1180  -1
    visit_1_20  order_active_ub_1181  -12
    visit_1_20  service_visit_def_1182  -1
    order_1_20  connected_order_arc_856  1
    order_1_20  connected_order_arc_879  1
    order_1_20  connected_order_arc_902  1
    order_1_20  connected_order_arc_925  1
    order_1_20  connected_order_arc_948  1
    order_1_20  connected_order_arc_971  1
    order_1_20  connected_order_arc_994  1
    order_1_20  connected_order_arc_1017  1
    order_1_20  connected_order_arc_1040  1
    order_1_20  connected_order_arc_1063  1
    order_1_20  connected_order_arc_1068  -1
    order_1_20  connected_order_arc_1070  -1
    order_1_20  connected_order_arc_1072  -1
    order_1_20  connected_order_arc_1074  -1
    order_1_20  connected_order_arc_1076  -1
    order_1_20  connected_order_arc_1078  -1
    order_1_20  connected_order_arc_1080  -1
    order_1_20  connected_order_arc_1082  -1
    order_1_20  connected_order_arc_1084  -1
    order_1_20  connected_order_arc_1086  -1
    order_1_20  connected_order_arc_1088  -1
    order_1_20  connected_order_arc_1111  1
    order_1_20  order_active_lb_1180  1
    order_1_20  order_active_ub_1181  1
    visit_1_21  out_degree_1184  -1
    visit_1_21  in_degree_1185  -1
    visit_1_21  order_active_lb_1186  -1
    visit_1_21  order_active_ub_1187  -12
    visit_1_21  service_visit_def_1188  -1
    order_1_21  connected_order_arc_858  1
    order_1_21  connected_order_arc_881  1
    order_1_21  connected_order_arc_904  1
    order_1_21  connected_order_arc_927  1
    order_1_21  connected_order_arc_950  1
    order_1_21  connected_order_arc_973  1
    order_1_21  connected_order_arc_996  1
    order_1_21  connected_order_arc_1019  1
    order_1_21  connected_order_arc_1042  1
    order_1_21  connected_order_arc_1065  1
    order_1_21  connected_order_arc_1088  1
    order_1_21  connected_order_arc_1091  -1
    order_1_21  connected_order_arc_1093  -1
    order_1_21  connected_order_arc_1095  -1
    order_1_21  connected_order_arc_1097  -1
    order_1_21  connected_order_arc_1099  -1
    order_1_21  connected_order_arc_1101  -1
    order_1_21  connected_order_arc_1103  -1
    order_1_21  connected_order_arc_1105  -1
    order_1_21  connected_order_arc_1107  -1
    order_1_21  connected_order_arc_1109  -1
    order_1_21  connected_order_arc_1111  -1
    order_1_21  order_active_lb_1186  1
    order_1_21  order_active_ub_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_823  -25
    arc_1_0_0  depot_departure_or_bypass_1112  1
    arc_1_0_0  depot_return_or_bypass_1113  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_823  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_824  -25
    arc_1_0_7  depot_departure_or_bypass_1112  1
    arc_1_0_7  in_degree_1115  1
    arc_1_0_7  original_T_including_depot_unload_1193  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_824  1
    load_1_0_7  segment_load_conservation_1118  -1
    load_1_0_7  segment_prefix_lb_1119  1
    load_1_0_7  segment_prefix_ub_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_825  -25
    arc_1_0_8  depot_departure_or_bypass_1112  1
    arc_1_0_8  in_degree_1122  1
    arc_1_0_8  original_T_including_depot_unload_1193  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_825  1
    load_1_0_8  segment_load_conservation_1125  -1
    load_1_0_8  segment_prefix_lb_1126  1
    load_1_0_8  segment_prefix_ub_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_826  -25
    arc_1_0_9  depot_departure_or_bypass_1112  1
    arc_1_0_9  in_degree_1129  1
    arc_1_0_9  original_T_including_depot_unload_1193  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_826  1
    load_1_0_9  segment_load_conservation_1132  -1
    load_1_0_9  segment_prefix_lb_1133  1
    load_1_0_9  segment_prefix_ub_1134  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_827  -25
    arc_1_0_10  depot_departure_or_bypass_1112  1
    arc_1_0_10  in_degree_1136  1
    arc_1_0_10  original_T_including_depot_unload_1193  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_827  1
    load_1_0_10  segment_load_conservation_1139  -1
    load_1_0_10  segment_prefix_lb_1140  1
    load_1_0_10  segment_prefix_ub_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_828  -25
    arc_1_0_14  depot_departure_or_bypass_1112  1
    arc_1_0_14  in_degree_1143  1
    arc_1_0_14  original_T_including_depot_unload_1193  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_828  1
    load_1_0_14  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_829  -25
    arc_1_0_15  depot_departure_or_bypass_1112  1
    arc_1_0_15  in_degree_1149  1
    arc_1_0_15  original_T_including_depot_unload_1193  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_829  1
    load_1_0_15  free_load_conservation_1153  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_830  -25
    arc_1_0_16  depot_departure_or_bypass_1112  1
    arc_1_0_16  in_degree_1155  1
    arc_1_0_16  original_T_including_depot_unload_1193  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_830  1
    load_1_0_16  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_831  -25
    arc_1_0_17  depot_departure_or_bypass_1112  1
    arc_1_0_17  in_degree_1161  1
    arc_1_0_17  original_T_including_depot_unload_1193  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_831  1
    load_1_0_17  free_load_conservation_1165  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_832  -25
    arc_1_0_18  depot_departure_or_bypass_1112  1
    arc_1_0_18  in_degree_1167  1
    arc_1_0_18  original_T_including_depot_unload_1193  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_832  1
    load_1_0_18  free_load_conservation_1171  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_833  -25
    arc_1_0_19  depot_departure_or_bypass_1112  1
    arc_1_0_19  in_degree_1173  1
    arc_1_0_19  original_T_including_depot_unload_1193  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_833  1
    load_1_0_19  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_834  -25
    arc_1_0_20  depot_departure_or_bypass_1112  1
    arc_1_0_20  in_degree_1179  1
    arc_1_0_20  original_T_including_depot_unload_1193  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_834  1
    load_1_0_20  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_835  -25
    arc_1_0_21  depot_departure_or_bypass_1112  1
    arc_1_0_21  in_degree_1185  1
    arc_1_0_21  original_T_including_depot_unload_1193  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_835  1
    load_1_0_21  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_836  -25
    arc_1_7_0  depot_return_or_bypass_1113  1
    arc_1_7_0  out_degree_1114  1
    arc_1_7_0  original_T_including_depot_unload_1193  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_836  1
    load_1_7_0  segment_load_conservation_1118  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_837  -25
    arc_1_7_8  connected_order_arc_838  -13
    arc_1_7_8  out_degree_1114  1
    arc_1_7_8  in_degree_1122  1
    arc_1_7_8  original_T_including_depot_unload_1193  1.0359917537364215e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_837  1
    load_1_7_8  segment_load_conservation_1118  1
    load_1_7_8  segment_load_conservation_1125  -1
    load_1_7_8  segment_prefix_lb_1126  1
    load_1_7_8  segment_prefix_ub_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_839  -25
    arc_1_7_9  connected_order_arc_840  -13
    arc_1_7_9  out_degree_1114  1
    arc_1_7_9  in_degree_1129  1
    arc_1_7_9  original_T_including_depot_unload_1193  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_839  1
    load_1_7_9  segment_load_conservation_1118  1
    load_1_7_9  segment_load_conservation_1132  -1
    load_1_7_9  segment_prefix_lb_1133  1
    load_1_7_9  segment_prefix_ub_1134  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_841  -25
    arc_1_7_10  connected_order_arc_842  -13
    arc_1_7_10  out_degree_1114  1
    arc_1_7_10  in_degree_1136  1
    arc_1_7_10  original_T_including_depot_unload_1193  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_841  1
    load_1_7_10  segment_load_conservation_1118  1
    load_1_7_10  segment_load_conservation_1139  -1
    load_1_7_10  segment_prefix_lb_1140  1
    load_1_7_10  segment_prefix_ub_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_843  -25
    arc_1_7_14  connected_order_arc_844  -13
    arc_1_7_14  out_degree_1114  1
    arc_1_7_14  in_degree_1143  1
    arc_1_7_14  original_T_including_depot_unload_1193  6.8151832047278333e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_843  1
    load_1_7_14  segment_load_conservation_1118  1
    load_1_7_14  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_845  -25
    arc_1_7_15  connected_order_arc_846  -13
    arc_1_7_15  out_degree_1114  1
    arc_1_7_15  in_degree_1149  1
    arc_1_7_15  original_T_including_depot_unload_1193  7.0547985627601940e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_845  1
    load_1_7_15  segment_load_conservation_1118  1
    load_1_7_15  free_load_conservation_1153  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_847  -25
    arc_1_7_16  connected_order_arc_848  -13
    arc_1_7_16  out_degree_1114  1
    arc_1_7_16  in_degree_1155  1
    arc_1_7_16  original_T_including_depot_unload_1193  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_847  1
    load_1_7_16  segment_load_conservation_1118  1
    load_1_7_16  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_849  -25
    arc_1_7_17  connected_order_arc_850  -13
    arc_1_7_17  out_degree_1114  1
    arc_1_7_17  in_degree_1161  1
    arc_1_7_17  original_T_including_depot_unload_1193  6.7008394119213415e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_849  1
    load_1_7_17  segment_load_conservation_1118  1
    load_1_7_17  free_load_conservation_1165  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_851  -25
    arc_1_7_18  connected_order_arc_852  -13
    arc_1_7_18  out_degree_1114  1
    arc_1_7_18  in_degree_1167  1
    arc_1_7_18  original_T_including_depot_unload_1193  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_851  1
    load_1_7_18  segment_load_conservation_1118  1
    load_1_7_18  free_load_conservation_1171  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_853  -25
    arc_1_7_19  connected_order_arc_854  -13
    arc_1_7_19  out_degree_1114  1
    arc_1_7_19  in_degree_1173  1
    arc_1_7_19  original_T_including_depot_unload_1193  634.658635437287
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_853  1
    load_1_7_19  segment_load_conservation_1118  1
    load_1_7_19  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_855  -25
    arc_1_7_20  connected_order_arc_856  -13
    arc_1_7_20  out_degree_1114  1
    arc_1_7_20  in_degree_1179  1
    arc_1_7_20  original_T_including_depot_unload_1193  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_855  1
    load_1_7_20  segment_load_conservation_1118  1
    load_1_7_20  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_857  -25
    arc_1_7_21  connected_order_arc_858  -13
    arc_1_7_21  out_degree_1114  1
    arc_1_7_21  in_degree_1185  1
    arc_1_7_21  original_T_including_depot_unload_1193  634.778043158074
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_857  1
    load_1_7_21  segment_load_conservation_1118  1
    load_1_7_21  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_859  -25
    arc_1_8_0  depot_return_or_bypass_1113  1
    arc_1_8_0  out_degree_1121  1
    arc_1_8_0  original_T_including_depot_unload_1193  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_859  1
    load_1_8_0  segment_load_conservation_1125  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_860  -25
    arc_1_8_7  connected_order_arc_861  -13
    arc_1_8_7  in_degree_1115  1
    arc_1_8_7  out_degree_1121  1
    arc_1_8_7  original_T_including_depot_unload_1193  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_860  1
    load_1_8_7  segment_load_conservation_1118  -1
    load_1_8_7  segment_prefix_lb_1119  1
    load_1_8_7  segment_prefix_ub_1120  1
    load_1_8_7  segment_load_conservation_1125  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_862  -25
    arc_1_8_9  connected_order_arc_863  -13
    arc_1_8_9  out_degree_1121  1
    arc_1_8_9  in_degree_1129  1
    arc_1_8_9  original_T_including_depot_unload_1193  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_862  1
    load_1_8_9  segment_load_conservation_1125  1
    load_1_8_9  segment_load_conservation_1132  -1
    load_1_8_9  segment_prefix_lb_1133  1
    load_1_8_9  segment_prefix_ub_1134  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_864  -25
    arc_1_8_10  connected_order_arc_865  -13
    arc_1_8_10  out_degree_1121  1
    arc_1_8_10  in_degree_1136  1
    arc_1_8_10  original_T_including_depot_unload_1193  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_864  1
    load_1_8_10  segment_load_conservation_1125  1
    load_1_8_10  segment_load_conservation_1139  -1
    load_1_8_10  segment_prefix_lb_1140  1
    load_1_8_10  segment_prefix_ub_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_866  -25
    arc_1_8_14  connected_order_arc_867  -13
    arc_1_8_14  out_degree_1121  1
    arc_1_8_14  in_degree_1143  1
    arc_1_8_14  original_T_including_depot_unload_1193  7.4980220943945562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_866  1
    load_1_8_14  segment_load_conservation_1125  1
    load_1_8_14  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_868  -25
    arc_1_8_15  connected_order_arc_869  -13
    arc_1_8_15  out_degree_1121  1
    arc_1_8_15  in_degree_1149  1
    arc_1_8_15  original_T_including_depot_unload_1193  6.3817162287710391e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_868  1
    load_1_8_15  segment_load_conservation_1125  1
    load_1_8_15  free_load_conservation_1153  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_870  -25
    arc_1_8_16  connected_order_arc_871  -13
    arc_1_8_16  out_degree_1121  1
    arc_1_8_16  in_degree_1155  1
    arc_1_8_16  original_T_including_depot_unload_1193  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_870  1
    load_1_8_16  segment_load_conservation_1125  1
    load_1_8_16  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_872  -25
    arc_1_8_17  connected_order_arc_873  -13
    arc_1_8_17  out_degree_1121  1
    arc_1_8_17  in_degree_1161  1
    arc_1_8_17  original_T_including_depot_unload_1193  9.0007741891713113e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_872  1
    load_1_8_17  segment_load_conservation_1125  1
    load_1_8_17  free_load_conservation_1165  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_874  -25
    arc_1_8_18  connected_order_arc_875  -13
    arc_1_8_18  out_degree_1121  1
    arc_1_8_18  in_degree_1167  1
    arc_1_8_18  original_T_including_depot_unload_1193  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_874  1
    load_1_8_18  segment_load_conservation_1125  1
    load_1_8_18  free_load_conservation_1171  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_876  -25
    arc_1_8_19  connected_order_arc_877  -13
    arc_1_8_19  out_degree_1121  1
    arc_1_8_19  in_degree_1173  1
    arc_1_8_19  original_T_including_depot_unload_1193  8.9557394138123709e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_876  1
    load_1_8_19  segment_load_conservation_1125  1
    load_1_8_19  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_878  -25
    arc_1_8_20  connected_order_arc_879  -13
    arc_1_8_20  out_degree_1121  1
    arc_1_8_20  in_degree_1179  1
    arc_1_8_20  original_T_including_depot_unload_1193  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_878  1
    load_1_8_20  segment_load_conservation_1125  1
    load_1_8_20  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_880  -25
    arc_1_8_21  connected_order_arc_881  -13
    arc_1_8_21  out_degree_1121  1
    arc_1_8_21  in_degree_1185  1
    arc_1_8_21  original_T_including_depot_unload_1193  8.9619134786808888e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_880  1
    load_1_8_21  segment_load_conservation_1125  1
    load_1_8_21  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_882  -25
    arc_1_9_0  depot_return_or_bypass_1113  1
    arc_1_9_0  out_degree_1128  1
    arc_1_9_0  original_T_including_depot_unload_1193  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_882  1
    load_1_9_0  segment_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_883  -25
    arc_1_9_7  connected_order_arc_884  -13
    arc_1_9_7  in_degree_1115  1
    arc_1_9_7  out_degree_1128  1
    arc_1_9_7  original_T_including_depot_unload_1193  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_883  1
    load_1_9_7  segment_load_conservation_1118  -1
    load_1_9_7  segment_prefix_lb_1119  1
    load_1_9_7  segment_prefix_ub_1120  1
    load_1_9_7  segment_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_885  -25
    arc_1_9_8  connected_order_arc_886  -13
    arc_1_9_8  in_degree_1122  1
    arc_1_9_8  out_degree_1128  1
    arc_1_9_8  original_T_including_depot_unload_1193  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_885  1
    load_1_9_8  segment_load_conservation_1125  -1
    load_1_9_8  segment_prefix_lb_1126  1
    load_1_9_8  segment_prefix_ub_1127  1
    load_1_9_8  segment_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_887  -25
    arc_1_9_10  connected_order_arc_888  -13
    arc_1_9_10  out_degree_1128  1
    arc_1_9_10  in_degree_1136  1
    arc_1_9_10  original_T_including_depot_unload_1193  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_887  1
    load_1_9_10  segment_load_conservation_1132  1
    load_1_9_10  segment_load_conservation_1139  -1
    load_1_9_10  segment_prefix_lb_1140  1
    load_1_9_10  segment_prefix_ub_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_889  -25
    arc_1_9_14  connected_order_arc_890  -13
    arc_1_9_14  out_degree_1128  1
    arc_1_9_14  in_degree_1143  1
    arc_1_9_14  original_T_including_depot_unload_1193  4.2580398435897172e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_889  1
    load_1_9_14  segment_load_conservation_1132  1
    load_1_9_14  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_891  -25
    arc_1_9_15  connected_order_arc_892  -13
    arc_1_9_15  out_degree_1128  1
    arc_1_9_15  in_degree_1149  1
    arc_1_9_15  original_T_including_depot_unload_1193  4.8212282798659248e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_891  1
    load_1_9_15  segment_load_conservation_1132  1
    load_1_9_15  free_load_conservation_1153  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_893  -25
    arc_1_9_16  connected_order_arc_894  -13
    arc_1_9_16  out_degree_1128  1
    arc_1_9_16  in_degree_1155  1
    arc_1_9_16  original_T_including_depot_unload_1193  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_893  1
    load_1_9_16  segment_load_conservation_1132  1
    load_1_9_16  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_895  -25
    arc_1_9_17  connected_order_arc_896  -13
    arc_1_9_17  out_degree_1128  1
    arc_1_9_17  in_degree_1161  1
    arc_1_9_17  original_T_including_depot_unload_1193  3.8231967210987659e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_895  1
    load_1_9_17  segment_load_conservation_1132  1
    load_1_9_17  free_load_conservation_1165  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_897  -25
    arc_1_9_18  connected_order_arc_898  -13
    arc_1_9_18  out_degree_1128  1
    arc_1_9_18  in_degree_1167  1
    arc_1_9_18  original_T_including_depot_unload_1193  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_897  1
    load_1_9_18  segment_load_conservation_1132  1
    load_1_9_18  free_load_conservation_1171  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_899  -25
    arc_1_9_19  connected_order_arc_900  -13
    arc_1_9_19  out_degree_1128  1
    arc_1_9_19  in_degree_1173  1
    arc_1_9_19  original_T_including_depot_unload_1193  3.4724611547105854e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_899  1
    load_1_9_19  segment_load_conservation_1132  1
    load_1_9_19  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_901  -25
    arc_1_9_20  connected_order_arc_902  -13
    arc_1_9_20  out_degree_1128  1
    arc_1_9_20  in_degree_1179  1
    arc_1_9_20  original_T_including_depot_unload_1193  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_901  1
    load_1_9_20  segment_load_conservation_1132  1
    load_1_9_20  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_903  -25
    arc_1_9_21  connected_order_arc_904  -13
    arc_1_9_21  out_degree_1128  1
    arc_1_9_21  in_degree_1185  1
    arc_1_9_21  original_T_including_depot_unload_1193  3.4726967782722494e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_903  1
    load_1_9_21  segment_load_conservation_1132  1
    load_1_9_21  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_905  -25
    arc_1_10_0  depot_return_or_bypass_1113  1
    arc_1_10_0  out_degree_1135  1
    arc_1_10_0  original_T_including_depot_unload_1193  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_905  1
    load_1_10_0  segment_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_906  -25
    arc_1_10_7  connected_order_arc_907  -13
    arc_1_10_7  in_degree_1115  1
    arc_1_10_7  out_degree_1135  1
    arc_1_10_7  original_T_including_depot_unload_1193  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_906  1
    load_1_10_7  segment_load_conservation_1118  -1
    load_1_10_7  segment_prefix_lb_1119  1
    load_1_10_7  segment_prefix_ub_1120  1
    load_1_10_7  segment_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_908  -25
    arc_1_10_8  connected_order_arc_909  -13
    arc_1_10_8  in_degree_1122  1
    arc_1_10_8  out_degree_1135  1
    arc_1_10_8  original_T_including_depot_unload_1193  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_908  1
    load_1_10_8  segment_load_conservation_1125  -1
    load_1_10_8  segment_prefix_lb_1126  1
    load_1_10_8  segment_prefix_ub_1127  1
    load_1_10_8  segment_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_910  -25
    arc_1_10_9  connected_order_arc_911  -13
    arc_1_10_9  in_degree_1129  1
    arc_1_10_9  out_degree_1135  1
    arc_1_10_9  original_T_including_depot_unload_1193  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_910  1
    load_1_10_9  segment_load_conservation_1132  -1
    load_1_10_9  segment_prefix_lb_1133  1
    load_1_10_9  segment_prefix_ub_1134  1
    load_1_10_9  segment_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_912  -25
    arc_1_10_14  connected_order_arc_913  -13
    arc_1_10_14  out_degree_1135  1
    arc_1_10_14  in_degree_1143  1
    arc_1_10_14  original_T_including_depot_unload_1193  6.9292160543761986e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_912  1
    load_1_10_14  segment_load_conservation_1139  1
    load_1_10_14  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_914  -25
    arc_1_10_15  connected_order_arc_915  -13
    arc_1_10_15  out_degree_1135  1
    arc_1_10_15  in_degree_1149  1
    arc_1_10_15  original_T_including_depot_unload_1193  7.6932985985964615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_914  1
    load_1_10_15  segment_load_conservation_1139  1
    load_1_10_15  free_load_conservation_1153  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_916  -25
    arc_1_10_16  connected_order_arc_917  -13
    arc_1_10_16  out_degree_1135  1
    arc_1_10_16  in_degree_1155  1
    arc_1_10_16  original_T_including_depot_unload_1193  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_916  1
    load_1_10_16  segment_load_conservation_1139  1
    load_1_10_16  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_918  -25
    arc_1_10_17  connected_order_arc_919  -13
    arc_1_10_17  out_degree_1135  1
    arc_1_10_17  in_degree_1161  1
    arc_1_10_17  original_T_including_depot_unload_1193  6.0082621405522366e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_918  1
    load_1_10_17  segment_load_conservation_1139  1
    load_1_10_17  free_load_conservation_1165  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_920  -25
    arc_1_10_18  connected_order_arc_921  -13
    arc_1_10_18  out_degree_1135  1
    arc_1_10_18  in_degree_1167  1
    arc_1_10_18  original_T_including_depot_unload_1193  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_920  1
    load_1_10_18  segment_load_conservation_1139  1
    load_1_10_18  free_load_conservation_1171  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_19  arc_capacity_922  -25
    arc_1_10_19  connected_order_arc_923  -13
    arc_1_10_19  out_degree_1135  1
    arc_1_10_19  in_degree_1173  1
    arc_1_10_19  original_T_including_depot_unload_1193  5.7164184935040350e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_19  arc_capacity_922  1
    load_1_10_19  segment_load_conservation_1139  1
    load_1_10_19  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_20  arc_capacity_924  -25
    arc_1_10_20  connected_order_arc_925  -13
    arc_1_10_20  out_degree_1135  1
    arc_1_10_20  in_degree_1179  1
    arc_1_10_20  original_T_including_depot_unload_1193  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_20  arc_capacity_924  1
    load_1_10_20  segment_load_conservation_1139  1
    load_1_10_20  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_21  arc_capacity_926  -25
    arc_1_10_21  connected_order_arc_927  -13
    arc_1_10_21  out_degree_1135  1
    arc_1_10_21  in_degree_1185  1
    arc_1_10_21  original_T_including_depot_unload_1193  5.7138137092491206e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_21  arc_capacity_926  1
    load_1_10_21  segment_load_conservation_1139  1
    load_1_10_21  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_928  -25
    arc_1_14_0  depot_return_or_bypass_1113  1
    arc_1_14_0  out_degree_1142  1
    arc_1_14_0  original_T_including_depot_unload_1193  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_928  1
    load_1_14_0  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_929  -25
    arc_1_14_7  connected_order_arc_930  -13
    arc_1_14_7  in_degree_1115  1
    arc_1_14_7  out_degree_1142  1
    arc_1_14_7  original_T_including_depot_unload_1193  1.6985664713248598e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_929  1
    load_1_14_7  segment_load_conservation_1118  -1
    load_1_14_7  segment_prefix_lb_1119  1
    load_1_14_7  segment_prefix_ub_1120  1
    load_1_14_7  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_931  -25
    arc_1_14_8  connected_order_arc_932  -13
    arc_1_14_8  in_degree_1122  1
    arc_1_14_8  out_degree_1142  1
    arc_1_14_8  original_T_including_depot_unload_1193  7.4980220943945562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_931  1
    load_1_14_8  segment_load_conservation_1125  -1
    load_1_14_8  segment_prefix_lb_1126  1
    load_1_14_8  segment_prefix_ub_1127  1
    load_1_14_8  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_933  -25
    arc_1_14_9  connected_order_arc_934  -13
    arc_1_14_9  in_degree_1129  1
    arc_1_14_9  out_degree_1142  1
    arc_1_14_9  original_T_including_depot_unload_1193  4.2580398435897172e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_933  1
    load_1_14_9  segment_load_conservation_1132  -1
    load_1_14_9  segment_prefix_lb_1133  1
    load_1_14_9  segment_prefix_ub_1134  1
    load_1_14_9  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_935  -25
    arc_1_14_10  connected_order_arc_936  -13
    arc_1_14_10  in_degree_1136  1
    arc_1_14_10  out_degree_1142  1
    arc_1_14_10  original_T_including_depot_unload_1193  6.9292160543761986e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_935  1
    load_1_14_10  segment_load_conservation_1139  -1
    load_1_14_10  segment_prefix_lb_1140  1
    load_1_14_10  segment_prefix_ub_1141  1
    load_1_14_10  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_937  -25
    arc_1_14_15  connected_order_arc_938  -13
    arc_1_14_15  out_degree_1142  1
    arc_1_14_15  in_degree_1149  1
    arc_1_14_15  original_T_including_depot_unload_1193  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_937  1
    load_1_14_15  free_load_conservation_1147  1
    load_1_14_15  free_load_conservation_1153  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_939  -25
    arc_1_14_16  connected_order_arc_940  -13
    arc_1_14_16  out_degree_1142  1
    arc_1_14_16  in_degree_1155  1
    arc_1_14_16  original_T_including_depot_unload_1193  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_939  1
    load_1_14_16  free_load_conservation_1147  1
    load_1_14_16  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_941  -25
    arc_1_14_17  connected_order_arc_942  -13
    arc_1_14_17  out_degree_1142  1
    arc_1_14_17  in_degree_1161  1
    arc_1_14_17  original_T_including_depot_unload_1193  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_941  1
    load_1_14_17  free_load_conservation_1147  1
    load_1_14_17  free_load_conservation_1165  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_943  -25
    arc_1_14_18  connected_order_arc_944  -13
    arc_1_14_18  out_degree_1142  1
    arc_1_14_18  in_degree_1167  1
    arc_1_14_18  original_T_including_depot_unload_1193  1.7807233899807140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_943  1
    load_1_14_18  free_load_conservation_1147  1
    load_1_14_18  free_load_conservation_1171  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_945  -25
    arc_1_14_19  connected_order_arc_946  -13
    arc_1_14_19  out_degree_1142  1
    arc_1_14_19  in_degree_1173  1
    arc_1_14_19  original_T_including_depot_unload_1193  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_945  1
    load_1_14_19  free_load_conservation_1147  1
    load_1_14_19  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_947  -25
    arc_1_14_20  connected_order_arc_948  -13
    arc_1_14_20  out_degree_1142  1
    arc_1_14_20  in_degree_1179  1
    arc_1_14_20  original_T_including_depot_unload_1193  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_947  1
    load_1_14_20  free_load_conservation_1147  1
    load_1_14_20  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_21  arc_capacity_949  -25
    arc_1_14_21  connected_order_arc_950  -13
    arc_1_14_21  out_degree_1142  1
    arc_1_14_21  in_degree_1185  1
    arc_1_14_21  original_T_including_depot_unload_1193  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_21  arc_capacity_949  1
    load_1_14_21  free_load_conservation_1147  1
    load_1_14_21  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_951  -25
    arc_1_15_0  depot_return_or_bypass_1113  1
    arc_1_15_0  out_degree_1148  1
    arc_1_15_0  original_T_including_depot_unload_1193  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_951  1
    load_1_15_0  free_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_952  -25
    arc_1_15_7  connected_order_arc_953  -13
    arc_1_15_7  in_degree_1115  1
    arc_1_15_7  out_degree_1148  1
    arc_1_15_7  original_T_including_depot_unload_1193  1.7532207666032109e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_952  1
    load_1_15_7  segment_load_conservation_1118  -1
    load_1_15_7  segment_prefix_lb_1119  1
    load_1_15_7  segment_prefix_ub_1120  1
    load_1_15_7  free_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_954  -25
    arc_1_15_8  connected_order_arc_955  -13
    arc_1_15_8  in_degree_1122  1
    arc_1_15_8  out_degree_1148  1
    arc_1_15_8  original_T_including_depot_unload_1193  6.3817162287710391e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_954  1
    load_1_15_8  segment_load_conservation_1125  -1
    load_1_15_8  segment_prefix_lb_1126  1
    load_1_15_8  segment_prefix_ub_1127  1
    load_1_15_8  free_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_956  -25
    arc_1_15_9  connected_order_arc_957  -13
    arc_1_15_9  in_degree_1129  1
    arc_1_15_9  out_degree_1148  1
    arc_1_15_9  original_T_including_depot_unload_1193  4.8212282798659248e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_956  1
    load_1_15_9  segment_load_conservation_1132  -1
    load_1_15_9  segment_prefix_lb_1133  1
    load_1_15_9  segment_prefix_ub_1134  1
    load_1_15_9  free_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_958  -25
    arc_1_15_10  connected_order_arc_959  -13
    arc_1_15_10  in_degree_1136  1
    arc_1_15_10  out_degree_1148  1
    arc_1_15_10  original_T_including_depot_unload_1193  7.6932985985964615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_958  1
    load_1_15_10  segment_load_conservation_1139  -1
    load_1_15_10  segment_prefix_lb_1140  1
    load_1_15_10  segment_prefix_ub_1141  1
    load_1_15_10  free_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_960  -25
    arc_1_15_14  connected_order_arc_961  -13
    arc_1_15_14  in_degree_1143  1
    arc_1_15_14  out_degree_1148  1
    arc_1_15_14  original_T_including_depot_unload_1193  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_960  1
    load_1_15_14  free_load_conservation_1147  -1
    load_1_15_14  free_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_962  -25
    arc_1_15_16  connected_order_arc_963  -13
    arc_1_15_16  out_degree_1148  1
    arc_1_15_16  in_degree_1155  1
    arc_1_15_16  original_T_including_depot_unload_1193  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_962  1
    load_1_15_16  free_load_conservation_1153  1
    load_1_15_16  free_load_conservation_1159  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_964  -25
    arc_1_15_17  connected_order_arc_965  -13
    arc_1_15_17  out_degree_1148  1
    arc_1_15_17  in_degree_1161  1
    arc_1_15_17  original_T_including_depot_unload_1193  2.6361257108552718e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_964  1
    load_1_15_17  free_load_conservation_1153  1
    load_1_15_17  free_load_conservation_1165  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_966  -25
    arc_1_15_18  connected_order_arc_967  -13
    arc_1_15_18  out_degree_1148  1
    arc_1_15_18  in_degree_1167  1
    arc_1_15_18  original_T_including_depot_unload_1193  1.8786452499301340e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_966  1
    load_1_15_18  free_load_conservation_1153  1
    load_1_15_18  free_load_conservation_1171  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_968  -25
    arc_1_15_19  connected_order_arc_969  -13
    arc_1_15_19  out_degree_1148  1
    arc_1_15_19  in_degree_1173  1
    arc_1_15_19  original_T_including_depot_unload_1193  2.6417860079316790e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_968  1
    load_1_15_19  free_load_conservation_1153  1
    load_1_15_19  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_970  -25
    arc_1_15_20  connected_order_arc_971  -13
    arc_1_15_20  out_degree_1148  1
    arc_1_15_20  in_degree_1179  1
    arc_1_15_20  original_T_including_depot_unload_1193  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_970  1
    load_1_15_20  free_load_conservation_1153  1
    load_1_15_20  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_972  -25
    arc_1_15_21  connected_order_arc_973  -13
    arc_1_15_21  out_degree_1148  1
    arc_1_15_21  in_degree_1185  1
    arc_1_15_21  original_T_including_depot_unload_1193  2.6477572380586179e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_972  1
    load_1_15_21  free_load_conservation_1153  1
    load_1_15_21  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_974  -25
    arc_1_16_0  depot_return_or_bypass_1113  1
    arc_1_16_0  out_degree_1154  1
    arc_1_16_0  original_T_including_depot_unload_1193  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_974  1
    load_1_16_0  free_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_975  -25
    arc_1_16_7  connected_order_arc_976  -13
    arc_1_16_7  in_degree_1115  1
    arc_1_16_7  out_degree_1154  1
    arc_1_16_7  original_T_including_depot_unload_1193  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_975  1
    load_1_16_7  segment_load_conservation_1118  -1
    load_1_16_7  segment_prefix_lb_1119  1
    load_1_16_7  segment_prefix_ub_1120  1
    load_1_16_7  free_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_977  -25
    arc_1_16_8  connected_order_arc_978  -13
    arc_1_16_8  in_degree_1122  1
    arc_1_16_8  out_degree_1154  1
    arc_1_16_8  original_T_including_depot_unload_1193  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_977  1
    load_1_16_8  segment_load_conservation_1125  -1
    load_1_16_8  segment_prefix_lb_1126  1
    load_1_16_8  segment_prefix_ub_1127  1
    load_1_16_8  free_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_979  -25
    arc_1_16_9  connected_order_arc_980  -13
    arc_1_16_9  in_degree_1129  1
    arc_1_16_9  out_degree_1154  1
    arc_1_16_9  original_T_including_depot_unload_1193  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_979  1
    load_1_16_9  segment_load_conservation_1132  -1
    load_1_16_9  segment_prefix_lb_1133  1
    load_1_16_9  segment_prefix_ub_1134  1
    load_1_16_9  free_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_981  -25
    arc_1_16_10  connected_order_arc_982  -13
    arc_1_16_10  in_degree_1136  1
    arc_1_16_10  out_degree_1154  1
    arc_1_16_10  original_T_including_depot_unload_1193  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_981  1
    load_1_16_10  segment_load_conservation_1139  -1
    load_1_16_10  segment_prefix_lb_1140  1
    load_1_16_10  segment_prefix_ub_1141  1
    load_1_16_10  free_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_983  -25
    arc_1_16_14  connected_order_arc_984  -13
    arc_1_16_14  in_degree_1143  1
    arc_1_16_14  out_degree_1154  1
    arc_1_16_14  original_T_including_depot_unload_1193  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_983  1
    load_1_16_14  free_load_conservation_1147  -1
    load_1_16_14  free_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_985  -25
    arc_1_16_15  connected_order_arc_986  -13
    arc_1_16_15  in_degree_1149  1
    arc_1_16_15  out_degree_1154  1
    arc_1_16_15  original_T_including_depot_unload_1193  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_985  1
    load_1_16_15  free_load_conservation_1153  -1
    load_1_16_15  free_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_987  -25
    arc_1_16_17  connected_order_arc_988  -13
    arc_1_16_17  out_degree_1154  1
    arc_1_16_17  in_degree_1161  1
    arc_1_16_17  original_T_including_depot_unload_1193  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_987  1
    load_1_16_17  free_load_conservation_1159  1
    load_1_16_17  free_load_conservation_1165  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_989  -25
    arc_1_16_18  connected_order_arc_990  -13
    arc_1_16_18  out_degree_1154  1
    arc_1_16_18  in_degree_1167  1
    arc_1_16_18  original_T_including_depot_unload_1193  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_989  1
    load_1_16_18  free_load_conservation_1159  1
    load_1_16_18  free_load_conservation_1171  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_991  -25
    arc_1_16_19  connected_order_arc_992  -13
    arc_1_16_19  out_degree_1154  1
    arc_1_16_19  in_degree_1173  1
    arc_1_16_19  original_T_including_depot_unload_1193  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_991  1
    load_1_16_19  free_load_conservation_1159  1
    load_1_16_19  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_993  -25
    arc_1_16_20  connected_order_arc_994  -13
    arc_1_16_20  out_degree_1154  1
    arc_1_16_20  in_degree_1179  1
    arc_1_16_20  original_T_including_depot_unload_1193  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_993  1
    load_1_16_20  free_load_conservation_1159  1
    load_1_16_20  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_995  -25
    arc_1_16_21  connected_order_arc_996  -13
    arc_1_16_21  out_degree_1154  1
    arc_1_16_21  in_degree_1185  1
    arc_1_16_21  original_T_including_depot_unload_1193  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_995  1
    load_1_16_21  free_load_conservation_1159  1
    load_1_16_21  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_997  -25
    arc_1_17_0  depot_return_or_bypass_1113  1
    arc_1_17_0  out_degree_1160  1
    arc_1_17_0  original_T_including_depot_unload_1193  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_997  1
    load_1_17_0  free_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_998  -25
    arc_1_17_7  connected_order_arc_999  -13
    arc_1_17_7  in_degree_1115  1
    arc_1_17_7  out_degree_1160  1
    arc_1_17_7  original_T_including_depot_unload_1193  1.6269573599812545e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_998  1
    load_1_17_7  segment_load_conservation_1118  -1
    load_1_17_7  segment_prefix_lb_1119  1
    load_1_17_7  segment_prefix_ub_1120  1
    load_1_17_7  free_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1000  -25
    arc_1_17_8  connected_order_arc_1001  -13
    arc_1_17_8  in_degree_1122  1
    arc_1_17_8  out_degree_1160  1
    arc_1_17_8  original_T_including_depot_unload_1193  9.0007741891713113e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1000  1
    load_1_17_8  segment_load_conservation_1125  -1
    load_1_17_8  segment_prefix_lb_1126  1
    load_1_17_8  segment_prefix_ub_1127  1
    load_1_17_8  free_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1002  -25
    arc_1_17_9  connected_order_arc_1003  -13
    arc_1_17_9  in_degree_1129  1
    arc_1_17_9  out_degree_1160  1
    arc_1_17_9  original_T_including_depot_unload_1193  3.8231967210987659e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1002  1
    load_1_17_9  segment_load_conservation_1132  -1
    load_1_17_9  segment_prefix_lb_1133  1
    load_1_17_9  segment_prefix_ub_1134  1
    load_1_17_9  free_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1004  -25
    arc_1_17_10  connected_order_arc_1005  -13
    arc_1_17_10  in_degree_1136  1
    arc_1_17_10  out_degree_1160  1
    arc_1_17_10  original_T_including_depot_unload_1193  6.0082621405522366e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1004  1
    load_1_17_10  segment_load_conservation_1139  -1
    load_1_17_10  segment_prefix_lb_1140  1
    load_1_17_10  segment_prefix_ub_1141  1
    load_1_17_10  free_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1006  -25
    arc_1_17_14  connected_order_arc_1007  -13
    arc_1_17_14  in_degree_1143  1
    arc_1_17_14  out_degree_1160  1
    arc_1_17_14  original_T_including_depot_unload_1193  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1006  1
    load_1_17_14  free_load_conservation_1147  -1
    load_1_17_14  free_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1008  -25
    arc_1_17_15  connected_order_arc_1009  -13
    arc_1_17_15  in_degree_1149  1
    arc_1_17_15  out_degree_1160  1
    arc_1_17_15  original_T_including_depot_unload_1193  2.6361257108552718e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1008  1
    load_1_17_15  free_load_conservation_1153  -1
    load_1_17_15  free_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1010  -25
    arc_1_17_16  connected_order_arc_1011  -13
    arc_1_17_16  in_degree_1155  1
    arc_1_17_16  out_degree_1160  1
    arc_1_17_16  original_T_including_depot_unload_1193  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1010  1
    load_1_17_16  free_load_conservation_1159  -1
    load_1_17_16  free_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1012  -25
    arc_1_17_18  connected_order_arc_1013  -13
    arc_1_17_18  out_degree_1160  1
    arc_1_17_18  in_degree_1167  1
    arc_1_17_18  original_T_including_depot_unload_1193  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1012  1
    load_1_17_18  free_load_conservation_1165  1
    load_1_17_18  free_load_conservation_1171  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1014  -25
    arc_1_17_19  connected_order_arc_1015  -13
    arc_1_17_19  out_degree_1160  1
    arc_1_17_19  in_degree_1173  1
    arc_1_17_19  original_T_including_depot_unload_1193  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1014  1
    load_1_17_19  free_load_conservation_1165  1
    load_1_17_19  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1016  -25
    arc_1_17_20  connected_order_arc_1017  -13
    arc_1_17_20  out_degree_1160  1
    arc_1_17_20  in_degree_1179  1
    arc_1_17_20  original_T_including_depot_unload_1193  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1016  1
    load_1_17_20  free_load_conservation_1165  1
    load_1_17_20  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1018  -25
    arc_1_17_21  connected_order_arc_1019  -13
    arc_1_17_21  out_degree_1160  1
    arc_1_17_21  in_degree_1185  1
    arc_1_17_21  original_T_including_depot_unload_1193  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1018  1
    load_1_17_21  free_load_conservation_1165  1
    load_1_17_21  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1020  -25
    arc_1_18_0  depot_return_or_bypass_1113  1
    arc_1_18_0  out_degree_1166  1
    arc_1_18_0  original_T_including_depot_unload_1193  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1020  1
    load_1_18_0  free_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1021  -25
    arc_1_18_7  connected_order_arc_1022  -13
    arc_1_18_7  in_degree_1115  1
    arc_1_18_7  out_degree_1166  1
    arc_1_18_7  original_T_including_depot_unload_1193  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1021  1
    load_1_18_7  segment_load_conservation_1118  -1
    load_1_18_7  segment_prefix_lb_1119  1
    load_1_18_7  segment_prefix_ub_1120  1
    load_1_18_7  free_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1023  -25
    arc_1_18_8  connected_order_arc_1024  -13
    arc_1_18_8  in_degree_1122  1
    arc_1_18_8  out_degree_1166  1
    arc_1_18_8  original_T_including_depot_unload_1193  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1023  1
    load_1_18_8  segment_load_conservation_1125  -1
    load_1_18_8  segment_prefix_lb_1126  1
    load_1_18_8  segment_prefix_ub_1127  1
    load_1_18_8  free_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1025  -25
    arc_1_18_9  connected_order_arc_1026  -13
    arc_1_18_9  in_degree_1129  1
    arc_1_18_9  out_degree_1166  1
    arc_1_18_9  original_T_including_depot_unload_1193  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1025  1
    load_1_18_9  segment_load_conservation_1132  -1
    load_1_18_9  segment_prefix_lb_1133  1
    load_1_18_9  segment_prefix_ub_1134  1
    load_1_18_9  free_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1027  -25
    arc_1_18_10  connected_order_arc_1028  -13
    arc_1_18_10  in_degree_1136  1
    arc_1_18_10  out_degree_1166  1
    arc_1_18_10  original_T_including_depot_unload_1193  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1027  1
    load_1_18_10  segment_load_conservation_1139  -1
    load_1_18_10  segment_prefix_lb_1140  1
    load_1_18_10  segment_prefix_ub_1141  1
    load_1_18_10  free_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1029  -25
    arc_1_18_14  connected_order_arc_1030  -13
    arc_1_18_14  in_degree_1143  1
    arc_1_18_14  out_degree_1166  1
    arc_1_18_14  original_T_including_depot_unload_1193  1.7807233899807140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1029  1
    load_1_18_14  free_load_conservation_1147  -1
    load_1_18_14  free_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1031  -25
    arc_1_18_15  connected_order_arc_1032  -13
    arc_1_18_15  in_degree_1149  1
    arc_1_18_15  out_degree_1166  1
    arc_1_18_15  original_T_including_depot_unload_1193  1.8786452499301340e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1031  1
    load_1_18_15  free_load_conservation_1153  -1
    load_1_18_15  free_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1033  -25
    arc_1_18_16  connected_order_arc_1034  -13
    arc_1_18_16  in_degree_1155  1
    arc_1_18_16  out_degree_1166  1
    arc_1_18_16  original_T_including_depot_unload_1193  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1033  1
    load_1_18_16  free_load_conservation_1159  -1
    load_1_18_16  free_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1035  -25
    arc_1_18_17  connected_order_arc_1036  -13
    arc_1_18_17  in_degree_1161  1
    arc_1_18_17  out_degree_1166  1
    arc_1_18_17  original_T_including_depot_unload_1193  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1035  1
    load_1_18_17  free_load_conservation_1165  -1
    load_1_18_17  free_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1037  -25
    arc_1_18_19  connected_order_arc_1038  -13
    arc_1_18_19  out_degree_1166  1
    arc_1_18_19  in_degree_1173  1
    arc_1_18_19  original_T_including_depot_unload_1193  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1037  1
    load_1_18_19  free_load_conservation_1171  1
    load_1_18_19  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1039  -25
    arc_1_18_20  connected_order_arc_1040  -13
    arc_1_18_20  out_degree_1166  1
    arc_1_18_20  in_degree_1179  1
    arc_1_18_20  original_T_including_depot_unload_1193  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1039  1
    load_1_18_20  free_load_conservation_1171  1
    load_1_18_20  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1041  -25
    arc_1_18_21  connected_order_arc_1042  -13
    arc_1_18_21  out_degree_1166  1
    arc_1_18_21  in_degree_1185  1
    arc_1_18_21  original_T_including_depot_unload_1193  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1041  1
    load_1_18_21  free_load_conservation_1171  1
    load_1_18_21  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1043  -25
    arc_1_19_0  depot_return_or_bypass_1113  1
    arc_1_19_0  out_degree_1172  1
    arc_1_19_0  original_T_including_depot_unload_1193  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1043  1
    load_1_19_0  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1044  -25
    arc_1_19_7  connected_order_arc_1045  -13
    arc_1_19_7  in_degree_1115  1
    arc_1_19_7  out_degree_1172  1
    arc_1_19_7  original_T_including_depot_unload_1193  1.5956325928039730e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1044  1
    load_1_19_7  segment_load_conservation_1118  -1
    load_1_19_7  segment_prefix_lb_1119  1
    load_1_19_7  segment_prefix_ub_1120  1
    load_1_19_7  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1046  -25
    arc_1_19_8  connected_order_arc_1047  -13
    arc_1_19_8  in_degree_1122  1
    arc_1_19_8  out_degree_1172  1
    arc_1_19_8  original_T_including_depot_unload_1193  8.9557394138123709e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1046  1
    load_1_19_8  segment_load_conservation_1125  -1
    load_1_19_8  segment_prefix_lb_1126  1
    load_1_19_8  segment_prefix_ub_1127  1
    load_1_19_8  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1048  -25
    arc_1_19_9  connected_order_arc_1049  -13
    arc_1_19_9  in_degree_1129  1
    arc_1_19_9  out_degree_1172  1
    arc_1_19_9  original_T_including_depot_unload_1193  3.4724611547105854e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1048  1
    load_1_19_9  segment_load_conservation_1132  -1
    load_1_19_9  segment_prefix_lb_1133  1
    load_1_19_9  segment_prefix_ub_1134  1
    load_1_19_9  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_10  arc_capacity_1050  -25
    arc_1_19_10  connected_order_arc_1051  -13
    arc_1_19_10  in_degree_1136  1
    arc_1_19_10  out_degree_1172  1
    arc_1_19_10  original_T_including_depot_unload_1193  5.7164184935040350e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_10  arc_capacity_1050  1
    load_1_19_10  segment_load_conservation_1139  -1
    load_1_19_10  segment_prefix_lb_1140  1
    load_1_19_10  segment_prefix_ub_1141  1
    load_1_19_10  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1052  -25
    arc_1_19_14  connected_order_arc_1053  -13
    arc_1_19_14  in_degree_1143  1
    arc_1_19_14  out_degree_1172  1
    arc_1_19_14  original_T_including_depot_unload_1193  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1052  1
    load_1_19_14  free_load_conservation_1147  -1
    load_1_19_14  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1054  -25
    arc_1_19_15  connected_order_arc_1055  -13
    arc_1_19_15  in_degree_1149  1
    arc_1_19_15  out_degree_1172  1
    arc_1_19_15  original_T_including_depot_unload_1193  2.6417860079316790e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1054  1
    load_1_19_15  free_load_conservation_1153  -1
    load_1_19_15  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1056  -25
    arc_1_19_16  connected_order_arc_1057  -13
    arc_1_19_16  in_degree_1155  1
    arc_1_19_16  out_degree_1172  1
    arc_1_19_16  original_T_including_depot_unload_1193  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1056  1
    load_1_19_16  free_load_conservation_1159  -1
    load_1_19_16  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1058  -25
    arc_1_19_17  connected_order_arc_1059  -13
    arc_1_19_17  in_degree_1161  1
    arc_1_19_17  out_degree_1172  1
    arc_1_19_17  original_T_including_depot_unload_1193  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1058  1
    load_1_19_17  free_load_conservation_1165  -1
    load_1_19_17  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1060  -25
    arc_1_19_18  connected_order_arc_1061  -13
    arc_1_19_18  in_degree_1167  1
    arc_1_19_18  out_degree_1172  1
    arc_1_19_18  original_T_including_depot_unload_1193  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1060  1
    load_1_19_18  free_load_conservation_1171  -1
    load_1_19_18  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1062  -25
    arc_1_19_20  connected_order_arc_1063  -13
    arc_1_19_20  out_degree_1172  1
    arc_1_19_20  in_degree_1179  1
    arc_1_19_20  original_T_including_depot_unload_1193  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1062  1
    load_1_19_20  free_load_conservation_1177  1
    load_1_19_20  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1064  -25
    arc_1_19_21  connected_order_arc_1065  -13
    arc_1_19_21  out_degree_1172  1
    arc_1_19_21  in_degree_1185  1
    arc_1_19_21  original_T_including_depot_unload_1193  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1064  1
    load_1_19_21  free_load_conservation_1177  1
    load_1_19_21  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1066  -25
    arc_1_20_0  depot_return_or_bypass_1113  1
    arc_1_20_0  out_degree_1178  1
    arc_1_20_0  original_T_including_depot_unload_1193  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1066  1
    load_1_20_0  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1067  -25
    arc_1_20_7  connected_order_arc_1068  -13
    arc_1_20_7  in_degree_1115  1
    arc_1_20_7  out_degree_1178  1
    arc_1_20_7  original_T_including_depot_unload_1193  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1067  1
    load_1_20_7  segment_load_conservation_1118  -1
    load_1_20_7  segment_prefix_lb_1119  1
    load_1_20_7  segment_prefix_ub_1120  1
    load_1_20_7  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1069  -25
    arc_1_20_8  connected_order_arc_1070  -13
    arc_1_20_8  in_degree_1122  1
    arc_1_20_8  out_degree_1178  1
    arc_1_20_8  original_T_including_depot_unload_1193  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1069  1
    load_1_20_8  segment_load_conservation_1125  -1
    load_1_20_8  segment_prefix_lb_1126  1
    load_1_20_8  segment_prefix_ub_1127  1
    load_1_20_8  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1071  -25
    arc_1_20_9  connected_order_arc_1072  -13
    arc_1_20_9  in_degree_1129  1
    arc_1_20_9  out_degree_1178  1
    arc_1_20_9  original_T_including_depot_unload_1193  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1071  1
    load_1_20_9  segment_load_conservation_1132  -1
    load_1_20_9  segment_prefix_lb_1133  1
    load_1_20_9  segment_prefix_ub_1134  1
    load_1_20_9  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_10  arc_capacity_1073  -25
    arc_1_20_10  connected_order_arc_1074  -13
    arc_1_20_10  in_degree_1136  1
    arc_1_20_10  out_degree_1178  1
    arc_1_20_10  original_T_including_depot_unload_1193  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_10  arc_capacity_1073  1
    load_1_20_10  segment_load_conservation_1139  -1
    load_1_20_10  segment_prefix_lb_1140  1
    load_1_20_10  segment_prefix_ub_1141  1
    load_1_20_10  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1075  -25
    arc_1_20_14  connected_order_arc_1076  -13
    arc_1_20_14  in_degree_1143  1
    arc_1_20_14  out_degree_1178  1
    arc_1_20_14  original_T_including_depot_unload_1193  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1075  1
    load_1_20_14  free_load_conservation_1147  -1
    load_1_20_14  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1077  -25
    arc_1_20_15  connected_order_arc_1078  -13
    arc_1_20_15  in_degree_1149  1
    arc_1_20_15  out_degree_1178  1
    arc_1_20_15  original_T_including_depot_unload_1193  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1077  1
    load_1_20_15  free_load_conservation_1153  -1
    load_1_20_15  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1079  -25
    arc_1_20_16  connected_order_arc_1080  -13
    arc_1_20_16  in_degree_1155  1
    arc_1_20_16  out_degree_1178  1
    arc_1_20_16  original_T_including_depot_unload_1193  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1079  1
    load_1_20_16  free_load_conservation_1159  -1
    load_1_20_16  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1081  -25
    arc_1_20_17  connected_order_arc_1082  -13
    arc_1_20_17  in_degree_1161  1
    arc_1_20_17  out_degree_1178  1
    arc_1_20_17  original_T_including_depot_unload_1193  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1081  1
    load_1_20_17  free_load_conservation_1165  -1
    load_1_20_17  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1083  -25
    arc_1_20_18  connected_order_arc_1084  -13
    arc_1_20_18  in_degree_1167  1
    arc_1_20_18  out_degree_1178  1
    arc_1_20_18  original_T_including_depot_unload_1193  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1083  1
    load_1_20_18  free_load_conservation_1171  -1
    load_1_20_18  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1085  -25
    arc_1_20_19  connected_order_arc_1086  -13
    arc_1_20_19  in_degree_1173  1
    arc_1_20_19  out_degree_1178  1
    arc_1_20_19  original_T_including_depot_unload_1193  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1085  1
    load_1_20_19  free_load_conservation_1177  -1
    load_1_20_19  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1087  -25
    arc_1_20_21  connected_order_arc_1088  -13
    arc_1_20_21  out_degree_1178  1
    arc_1_20_21  in_degree_1185  1
    arc_1_20_21  original_T_including_depot_unload_1193  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1087  1
    load_1_20_21  free_load_conservation_1183  1
    load_1_20_21  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1089  -25
    arc_1_21_0  depot_return_or_bypass_1113  1
    arc_1_21_0  out_degree_1184  1
    arc_1_21_0  original_T_including_depot_unload_1193  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1089  1
    load_1_21_0  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1090  -25
    arc_1_21_7  connected_order_arc_1091  -13
    arc_1_21_7  in_degree_1115  1
    arc_1_21_7  out_degree_1184  1
    arc_1_21_7  original_T_including_depot_unload_1193  1.5954463271473815e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1090  1
    load_1_21_7  segment_load_conservation_1118  -1
    load_1_21_7  segment_prefix_lb_1119  1
    load_1_21_7  segment_prefix_ub_1120  1
    load_1_21_7  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1092  -25
    arc_1_21_8  connected_order_arc_1093  -13
    arc_1_21_8  in_degree_1122  1
    arc_1_21_8  out_degree_1184  1
    arc_1_21_8  original_T_including_depot_unload_1193  8.9619134786808888e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1092  1
    load_1_21_8  segment_load_conservation_1125  -1
    load_1_21_8  segment_prefix_lb_1126  1
    load_1_21_8  segment_prefix_ub_1127  1
    load_1_21_8  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1094  -25
    arc_1_21_9  connected_order_arc_1095  -13
    arc_1_21_9  in_degree_1129  1
    arc_1_21_9  out_degree_1184  1
    arc_1_21_9  original_T_including_depot_unload_1193  3.4726967782722494e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1094  1
    load_1_21_9  segment_load_conservation_1132  -1
    load_1_21_9  segment_prefix_lb_1133  1
    load_1_21_9  segment_prefix_ub_1134  1
    load_1_21_9  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_10  arc_capacity_1096  -25
    arc_1_21_10  connected_order_arc_1097  -13
    arc_1_21_10  in_degree_1136  1
    arc_1_21_10  out_degree_1184  1
    arc_1_21_10  original_T_including_depot_unload_1193  5.7138137092491206e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_10  arc_capacity_1096  1
    load_1_21_10  segment_load_conservation_1139  -1
    load_1_21_10  segment_prefix_lb_1140  1
    load_1_21_10  segment_prefix_ub_1141  1
    load_1_21_10  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_14  arc_capacity_1098  -25
    arc_1_21_14  connected_order_arc_1099  -13
    arc_1_21_14  in_degree_1143  1
    arc_1_21_14  out_degree_1184  1
    arc_1_21_14  original_T_including_depot_unload_1193  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_14  arc_capacity_1098  1
    load_1_21_14  free_load_conservation_1147  -1
    load_1_21_14  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1100  -25
    arc_1_21_15  connected_order_arc_1101  -13
    arc_1_21_15  in_degree_1149  1
    arc_1_21_15  out_degree_1184  1
    arc_1_21_15  original_T_including_depot_unload_1193  2.6477572380586179e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1100  1
    load_1_21_15  free_load_conservation_1153  -1
    load_1_21_15  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1102  -25
    arc_1_21_16  connected_order_arc_1103  -13
    arc_1_21_16  in_degree_1155  1
    arc_1_21_16  out_degree_1184  1
    arc_1_21_16  original_T_including_depot_unload_1193  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1102  1
    load_1_21_16  free_load_conservation_1159  -1
    load_1_21_16  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1104  -25
    arc_1_21_17  connected_order_arc_1105  -13
    arc_1_21_17  in_degree_1161  1
    arc_1_21_17  out_degree_1184  1
    arc_1_21_17  original_T_including_depot_unload_1193  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1104  1
    load_1_21_17  free_load_conservation_1165  -1
    load_1_21_17  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1106  -25
    arc_1_21_18  connected_order_arc_1107  -13
    arc_1_21_18  in_degree_1167  1
    arc_1_21_18  out_degree_1184  1
    arc_1_21_18  original_T_including_depot_unload_1193  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1106  1
    load_1_21_18  free_load_conservation_1171  -1
    load_1_21_18  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1108  -25
    arc_1_21_19  connected_order_arc_1109  -13
    arc_1_21_19  in_degree_1173  1
    arc_1_21_19  out_degree_1184  1
    arc_1_21_19  original_T_including_depot_unload_1193  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1108  1
    load_1_21_19  free_load_conservation_1177  -1
    load_1_21_19  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1110  -25
    arc_1_21_20  connected_order_arc_1111  -13
    arc_1_21_20  in_degree_1179  1
    arc_1_21_20  out_degree_1184  1
    arc_1_21_20  original_T_including_depot_unload_1193  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1110  1
    load_1_21_20  free_load_conservation_1183  -1
    load_1_21_20  free_load_conservation_1189  1
    visit_2_11  out_degree_1439  -1
    visit_2_11  in_degree_1440  -1
    visit_2_11  order_active_lb_1441  -1
    visit_2_11  order_active_ub_1442  -11
    order_2_11  connected_order_arc_1208  -1
    order_2_11  connected_order_arc_1210  -1
    order_2_11  connected_order_arc_1212  -1
    order_2_11  connected_order_arc_1214  -1
    order_2_11  connected_order_arc_1216  -1
    order_2_11  connected_order_arc_1218  -1
    order_2_11  connected_order_arc_1220  -1
    order_2_11  connected_order_arc_1222  -1
    order_2_11  connected_order_arc_1224  -1
    order_2_11  connected_order_arc_1226  -1
    order_2_11  connected_order_arc_1229  1
    order_2_11  connected_order_arc_1250  1
    order_2_11  connected_order_arc_1271  1
    order_2_11  connected_order_arc_1292  1
    order_2_11  connected_order_arc_1313  1
    order_2_11  connected_order_arc_1334  1
    order_2_11  connected_order_arc_1355  1
    order_2_11  connected_order_arc_1376  1
    order_2_11  connected_order_arc_1397  1
    order_2_11  connected_order_arc_1418  1
    order_2_11  order_active_lb_1441  1
    order_2_11  order_active_ub_1442  1
    order_2_11  fixed_segment_relative_order_1508  -1
    visit_2_12  out_degree_1446  -1
    visit_2_12  in_degree_1447  -1
    visit_2_12  order_active_lb_1448  -1
    visit_2_12  order_active_ub_1449  -11
    order_2_12  connected_order_arc_1208  1
    order_2_12  connected_order_arc_1229  -1
    order_2_12  connected_order_arc_1231  -1
    order_2_12  connected_order_arc_1233  -1
    order_2_12  connected_order_arc_1235  -1
    order_2_12  connected_order_arc_1237  -1
    order_2_12  connected_order_arc_1239  -1
    order_2_12  connected_order_arc_1241  -1
    order_2_12  connected_order_arc_1243  -1
    order_2_12  connected_order_arc_1245  -1
    order_2_12  connected_order_arc_1247  -1
    order_2_12  connected_order_arc_1252  1
    order_2_12  connected_order_arc_1273  1
    order_2_12  connected_order_arc_1294  1
    order_2_12  connected_order_arc_1315  1
    order_2_12  connected_order_arc_1336  1
    order_2_12  connected_order_arc_1357  1
    order_2_12  connected_order_arc_1378  1
    order_2_12  connected_order_arc_1399  1
    order_2_12  connected_order_arc_1420  1
    order_2_12  order_active_lb_1448  1
    order_2_12  order_active_ub_1449  1
    order_2_12  fixed_segment_relative_order_1508  1
    order_2_12  fixed_segment_relative_order_1509  -1
    visit_2_13  out_degree_1453  -1
    visit_2_13  in_degree_1454  -1
    visit_2_13  order_active_lb_1455  -1
    visit_2_13  order_active_ub_1456  -11
    order_2_13  connected_order_arc_1210  1
    order_2_13  connected_order_arc_1231  1
    order_2_13  connected_order_arc_1250  -1
    order_2_13  connected_order_arc_1252  -1
    order_2_13  connected_order_arc_1254  -1
    order_2_13  connected_order_arc_1256  -1
    order_2_13  connected_order_arc_1258  -1
    order_2_13  connected_order_arc_1260  -1
    order_2_13  connected_order_arc_1262  -1
    order_2_13  connected_order_arc_1264  -1
    order_2_13  connected_order_arc_1266  -1
    order_2_13  connected_order_arc_1268  -1
    order_2_13  connected_order_arc_1275  1
    order_2_13  connected_order_arc_1296  1
    order_2_13  connected_order_arc_1317  1
    order_2_13  connected_order_arc_1338  1
    order_2_13  connected_order_arc_1359  1
    order_2_13  connected_order_arc_1380  1
    order_2_13  connected_order_arc_1401  1
    order_2_13  connected_order_arc_1422  1
    order_2_13  order_active_lb_1455  1
    order_2_13  order_active_ub_1456  1
    order_2_13  fixed_segment_relative_order_1509  1
    visit_2_14  out_degree_1460  -1
    visit_2_14  in_degree_1461  -1
    visit_2_14  order_active_lb_1462  -1
    visit_2_14  order_active_ub_1463  -11
    visit_2_14  service_visit_def_1464  -1
    order_2_14  connected_order_arc_1212  1
    order_2_14  connected_order_arc_1233  1
    order_2_14  connected_order_arc_1254  1
    order_2_14  connected_order_arc_1271  -1
    order_2_14  connected_order_arc_1273  -1
    order_2_14  connected_order_arc_1275  -1
    order_2_14  connected_order_arc_1277  -1
    order_2_14  connected_order_arc_1279  -1
    order_2_14  connected_order_arc_1281  -1
    order_2_14  connected_order_arc_1283  -1
    order_2_14  connected_order_arc_1285  -1
    order_2_14  connected_order_arc_1287  -1
    order_2_14  connected_order_arc_1289  -1
    order_2_14  connected_order_arc_1298  1
    order_2_14  connected_order_arc_1319  1
    order_2_14  connected_order_arc_1340  1
    order_2_14  connected_order_arc_1361  1
    order_2_14  connected_order_arc_1382  1
    order_2_14  connected_order_arc_1403  1
    order_2_14  connected_order_arc_1424  1
    order_2_14  order_active_lb_1462  1
    order_2_14  order_active_ub_1463  1
    visit_2_15  out_degree_1466  -1
    visit_2_15  in_degree_1467  -1
    visit_2_15  order_active_lb_1468  -1
    visit_2_15  order_active_ub_1469  -11
    visit_2_15  service_visit_def_1470  -1
    order_2_15  connected_order_arc_1214  1
    order_2_15  connected_order_arc_1235  1
    order_2_15  connected_order_arc_1256  1
    order_2_15  connected_order_arc_1277  1
    order_2_15  connected_order_arc_1292  -1
    order_2_15  connected_order_arc_1294  -1
    order_2_15  connected_order_arc_1296  -1
    order_2_15  connected_order_arc_1298  -1
    order_2_15  connected_order_arc_1300  -1
    order_2_15  connected_order_arc_1302  -1
    order_2_15  connected_order_arc_1304  -1
    order_2_15  connected_order_arc_1306  -1
    order_2_15  connected_order_arc_1308  -1
    order_2_15  connected_order_arc_1310  -1
    order_2_15  connected_order_arc_1321  1
    order_2_15  connected_order_arc_1342  1
    order_2_15  connected_order_arc_1363  1
    order_2_15  connected_order_arc_1384  1
    order_2_15  connected_order_arc_1405  1
    order_2_15  connected_order_arc_1426  1
    order_2_15  order_active_lb_1468  1
    order_2_15  order_active_ub_1469  1
    visit_2_16  out_degree_1472  -1
    visit_2_16  in_degree_1473  -1
    visit_2_16  order_active_lb_1474  -1
    visit_2_16  order_active_ub_1475  -11
    visit_2_16  service_visit_def_1476  -1
    order_2_16  connected_order_arc_1216  1
    order_2_16  connected_order_arc_1237  1
    order_2_16  connected_order_arc_1258  1
    order_2_16  connected_order_arc_1279  1
    order_2_16  connected_order_arc_1300  1
    order_2_16  connected_order_arc_1313  -1
    order_2_16  connected_order_arc_1315  -1
    order_2_16  connected_order_arc_1317  -1
    order_2_16  connected_order_arc_1319  -1
    order_2_16  connected_order_arc_1321  -1
    order_2_16  connected_order_arc_1323  -1
    order_2_16  connected_order_arc_1325  -1
    order_2_16  connected_order_arc_1327  -1
    order_2_16  connected_order_arc_1329  -1
    order_2_16  connected_order_arc_1331  -1
    order_2_16  connected_order_arc_1344  1
    order_2_16  connected_order_arc_1365  1
    order_2_16  connected_order_arc_1386  1
    order_2_16  connected_order_arc_1407  1
    order_2_16  connected_order_arc_1428  1
    order_2_16  order_active_lb_1474  1
    order_2_16  order_active_ub_1475  1
    visit_2_17  out_degree_1478  -1
    visit_2_17  in_degree_1479  -1
    visit_2_17  order_active_lb_1480  -1
    visit_2_17  order_active_ub_1481  -11
    visit_2_17  service_visit_def_1482  -1
    order_2_17  connected_order_arc_1218  1
    order_2_17  connected_order_arc_1239  1
    order_2_17  connected_order_arc_1260  1
    order_2_17  connected_order_arc_1281  1
    order_2_17  connected_order_arc_1302  1
    order_2_17  connected_order_arc_1323  1
    order_2_17  connected_order_arc_1334  -1
    order_2_17  connected_order_arc_1336  -1
    order_2_17  connected_order_arc_1338  -1
    order_2_17  connected_order_arc_1340  -1
    order_2_17  connected_order_arc_1342  -1
    order_2_17  connected_order_arc_1344  -1
    order_2_17  connected_order_arc_1346  -1
    order_2_17  connected_order_arc_1348  -1
    order_2_17  connected_order_arc_1350  -1
    order_2_17  connected_order_arc_1352  -1
    order_2_17  connected_order_arc_1367  1
    order_2_17  connected_order_arc_1388  1
    order_2_17  connected_order_arc_1409  1
    order_2_17  connected_order_arc_1430  1
    order_2_17  order_active_lb_1480  1
    order_2_17  order_active_ub_1481  1
    visit_2_18  out_degree_1484  -1
    visit_2_18  in_degree_1485  -1
    visit_2_18  order_active_lb_1486  -1
    visit_2_18  order_active_ub_1487  -11
    visit_2_18  service_visit_def_1488  -1
    order_2_18  connected_order_arc_1220  1
    order_2_18  connected_order_arc_1241  1
    order_2_18  connected_order_arc_1262  1
    order_2_18  connected_order_arc_1283  1
    order_2_18  connected_order_arc_1304  1
    order_2_18  connected_order_arc_1325  1
    order_2_18  connected_order_arc_1346  1
    order_2_18  connected_order_arc_1355  -1
    order_2_18  connected_order_arc_1357  -1
    order_2_18  connected_order_arc_1359  -1
    order_2_18  connected_order_arc_1361  -1
    order_2_18  connected_order_arc_1363  -1
    order_2_18  connected_order_arc_1365  -1
    order_2_18  connected_order_arc_1367  -1
    order_2_18  connected_order_arc_1369  -1
    order_2_18  connected_order_arc_1371  -1
    order_2_18  connected_order_arc_1373  -1
    order_2_18  connected_order_arc_1390  1
    order_2_18  connected_order_arc_1411  1
    order_2_18  connected_order_arc_1432  1
    order_2_18  order_active_lb_1486  1
    order_2_18  order_active_ub_1487  1
    visit_2_19  out_degree_1490  -1
    visit_2_19  in_degree_1491  -1
    visit_2_19  order_active_lb_1492  -1
    visit_2_19  order_active_ub_1493  -11
    visit_2_19  service_visit_def_1494  -1
    order_2_19  connected_order_arc_1222  1
    order_2_19  connected_order_arc_1243  1
    order_2_19  connected_order_arc_1264  1
    order_2_19  connected_order_arc_1285  1
    order_2_19  connected_order_arc_1306  1
    order_2_19  connected_order_arc_1327  1
    order_2_19  connected_order_arc_1348  1
    order_2_19  connected_order_arc_1369  1
    order_2_19  connected_order_arc_1376  -1
    order_2_19  connected_order_arc_1378  -1
    order_2_19  connected_order_arc_1380  -1
    order_2_19  connected_order_arc_1382  -1
    order_2_19  connected_order_arc_1384  -1
    order_2_19  connected_order_arc_1386  -1
    order_2_19  connected_order_arc_1388  -1
    order_2_19  connected_order_arc_1390  -1
    order_2_19  connected_order_arc_1392  -1
    order_2_19  connected_order_arc_1394  -1
    order_2_19  connected_order_arc_1413  1
    order_2_19  connected_order_arc_1434  1
    order_2_19  order_active_lb_1492  1
    order_2_19  order_active_ub_1493  1
    visit_2_20  out_degree_1496  -1
    visit_2_20  in_degree_1497  -1
    visit_2_20  order_active_lb_1498  -1
    visit_2_20  order_active_ub_1499  -11
    visit_2_20  service_visit_def_1500  -1
    order_2_20  connected_order_arc_1224  1
    order_2_20  connected_order_arc_1245  1
    order_2_20  connected_order_arc_1266  1
    order_2_20  connected_order_arc_1287  1
    order_2_20  connected_order_arc_1308  1
    order_2_20  connected_order_arc_1329  1
    order_2_20  connected_order_arc_1350  1
    order_2_20  connected_order_arc_1371  1
    order_2_20  connected_order_arc_1392  1
    order_2_20  connected_order_arc_1397  -1
    order_2_20  connected_order_arc_1399  -1
    order_2_20  connected_order_arc_1401  -1
    order_2_20  connected_order_arc_1403  -1
    order_2_20  connected_order_arc_1405  -1
    order_2_20  connected_order_arc_1407  -1
    order_2_20  connected_order_arc_1409  -1
    order_2_20  connected_order_arc_1411  -1
    order_2_20  connected_order_arc_1413  -1
    order_2_20  connected_order_arc_1415  -1
    order_2_20  connected_order_arc_1436  1
    order_2_20  order_active_lb_1498  1
    order_2_20  order_active_ub_1499  1
    visit_2_21  out_degree_1502  -1
    visit_2_21  in_degree_1503  -1
    visit_2_21  order_active_lb_1504  -1
    visit_2_21  order_active_ub_1505  -11
    visit_2_21  service_visit_def_1506  -1
    order_2_21  connected_order_arc_1226  1
    order_2_21  connected_order_arc_1247  1
    order_2_21  connected_order_arc_1268  1
    order_2_21  connected_order_arc_1289  1
    order_2_21  connected_order_arc_1310  1
    order_2_21  connected_order_arc_1331  1
    order_2_21  connected_order_arc_1352  1
    order_2_21  connected_order_arc_1373  1
    order_2_21  connected_order_arc_1394  1
    order_2_21  connected_order_arc_1415  1
    order_2_21  connected_order_arc_1418  -1
    order_2_21  connected_order_arc_1420  -1
    order_2_21  connected_order_arc_1422  -1
    order_2_21  connected_order_arc_1424  -1
    order_2_21  connected_order_arc_1426  -1
    order_2_21  connected_order_arc_1428  -1
    order_2_21  connected_order_arc_1430  -1
    order_2_21  connected_order_arc_1432  -1
    order_2_21  connected_order_arc_1434  -1
    order_2_21  connected_order_arc_1436  -1
    order_2_21  order_active_lb_1504  1
    order_2_21  order_active_ub_1505  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1194  -30
    arc_2_0_0  depot_departure_or_bypass_1437  1
    arc_2_0_0  depot_return_or_bypass_1438  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1194  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1195  -30
    arc_2_0_11  depot_departure_or_bypass_1437  1
    arc_2_0_11  in_degree_1440  1
    arc_2_0_11  original_T_including_depot_unload_1510  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1195  1
    load_2_0_11  segment_load_conservation_1443  -1
    load_2_0_11  segment_prefix_lb_1444  1
    load_2_0_11  segment_prefix_ub_1445  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1196  -30
    arc_2_0_12  depot_departure_or_bypass_1437  1
    arc_2_0_12  in_degree_1447  1
    arc_2_0_12  original_T_including_depot_unload_1510  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1196  1
    load_2_0_12  segment_load_conservation_1450  -1
    load_2_0_12  segment_prefix_lb_1451  1
    load_2_0_12  segment_prefix_ub_1452  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1197  -30
    arc_2_0_13  depot_departure_or_bypass_1437  1
    arc_2_0_13  in_degree_1454  1
    arc_2_0_13  original_T_including_depot_unload_1510  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1197  1
    load_2_0_13  segment_load_conservation_1457  -1
    load_2_0_13  segment_prefix_lb_1458  1
    load_2_0_13  segment_prefix_ub_1459  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1198  -30
    arc_2_0_14  depot_departure_or_bypass_1437  1
    arc_2_0_14  in_degree_1461  1
    arc_2_0_14  original_T_including_depot_unload_1510  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1198  1
    load_2_0_14  free_load_conservation_1465  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1199  -30
    arc_2_0_15  depot_departure_or_bypass_1437  1
    arc_2_0_15  in_degree_1467  1
    arc_2_0_15  original_T_including_depot_unload_1510  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1199  1
    load_2_0_15  free_load_conservation_1471  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1200  -30
    arc_2_0_16  depot_departure_or_bypass_1437  1
    arc_2_0_16  in_degree_1473  1
    arc_2_0_16  original_T_including_depot_unload_1510  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1200  1
    load_2_0_16  free_load_conservation_1477  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1201  -30
    arc_2_0_17  depot_departure_or_bypass_1437  1
    arc_2_0_17  in_degree_1479  1
    arc_2_0_17  original_T_including_depot_unload_1510  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1201  1
    load_2_0_17  free_load_conservation_1483  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1202  -30
    arc_2_0_18  depot_departure_or_bypass_1437  1
    arc_2_0_18  in_degree_1485  1
    arc_2_0_18  original_T_including_depot_unload_1510  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1202  1
    load_2_0_18  free_load_conservation_1489  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1203  -30
    arc_2_0_19  depot_departure_or_bypass_1437  1
    arc_2_0_19  in_degree_1491  1
    arc_2_0_19  original_T_including_depot_unload_1510  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1203  1
    load_2_0_19  free_load_conservation_1495  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1204  -30
    arc_2_0_20  depot_departure_or_bypass_1437  1
    arc_2_0_20  in_degree_1497  1
    arc_2_0_20  original_T_including_depot_unload_1510  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1204  1
    load_2_0_20  free_load_conservation_1501  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1205  -30
    arc_2_0_21  depot_departure_or_bypass_1437  1
    arc_2_0_21  in_degree_1503  1
    arc_2_0_21  original_T_including_depot_unload_1510  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1205  1
    load_2_0_21  free_load_conservation_1507  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1206  -30
    arc_2_11_0  depot_return_or_bypass_1438  1
    arc_2_11_0  out_degree_1439  1
    arc_2_11_0  original_T_including_depot_unload_1510  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1206  1
    load_2_11_0  segment_load_conservation_1443  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1207  -30
    arc_2_11_12  connected_order_arc_1208  -12
    arc_2_11_12  out_degree_1439  1
    arc_2_11_12  in_degree_1447  1
    arc_2_11_12  original_T_including_depot_unload_1510  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1207  1
    load_2_11_12  segment_load_conservation_1443  1
    load_2_11_12  segment_load_conservation_1450  -1
    load_2_11_12  segment_prefix_lb_1451  1
    load_2_11_12  segment_prefix_ub_1452  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1209  -30
    arc_2_11_13  connected_order_arc_1210  -12
    arc_2_11_13  out_degree_1439  1
    arc_2_11_13  in_degree_1454  1
    arc_2_11_13  original_T_including_depot_unload_1510  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1209  1
    load_2_11_13  segment_load_conservation_1443  1
    load_2_11_13  segment_load_conservation_1457  -1
    load_2_11_13  segment_prefix_lb_1458  1
    load_2_11_13  segment_prefix_ub_1459  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1211  -30
    arc_2_11_14  connected_order_arc_1212  -12
    arc_2_11_14  out_degree_1439  1
    arc_2_11_14  in_degree_1461  1
    arc_2_11_14  original_T_including_depot_unload_1510  1.5756194178147177e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1211  1
    load_2_11_14  segment_load_conservation_1443  1
    load_2_11_14  free_load_conservation_1465  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1213  -30
    arc_2_11_15  connected_order_arc_1214  -12
    arc_2_11_15  out_degree_1439  1
    arc_2_11_15  in_degree_1467  1
    arc_2_11_15  original_T_including_depot_unload_1510  1.6813024470003036e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1213  1
    load_2_11_15  segment_load_conservation_1443  1
    load_2_11_15  free_load_conservation_1471  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1215  -30
    arc_2_11_16  connected_order_arc_1216  -12
    arc_2_11_16  out_degree_1439  1
    arc_2_11_16  in_degree_1473  1
    arc_2_11_16  original_T_including_depot_unload_1510  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1215  1
    load_2_11_16  segment_load_conservation_1443  1
    load_2_11_16  free_load_conservation_1477  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1217  -30
    arc_2_11_17  connected_order_arc_1218  -12
    arc_2_11_17  out_degree_1439  1
    arc_2_11_17  in_degree_1479  1
    arc_2_11_17  original_T_including_depot_unload_1510  1.4316381888253884e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1217  1
    load_2_11_17  segment_load_conservation_1443  1
    load_2_11_17  free_load_conservation_1483  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1219  -30
    arc_2_11_18  connected_order_arc_1220  -12
    arc_2_11_18  out_degree_1439  1
    arc_2_11_18  in_degree_1485  1
    arc_2_11_18  original_T_including_depot_unload_1510  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1219  1
    load_2_11_18  segment_load_conservation_1443  1
    load_2_11_18  free_load_conservation_1489  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1221  -30
    arc_2_11_19  connected_order_arc_1222  -12
    arc_2_11_19  out_degree_1439  1
    arc_2_11_19  in_degree_1491  1
    arc_2_11_19  original_T_including_depot_unload_1510  1.4214388997747180e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1221  1
    load_2_11_19  segment_load_conservation_1443  1
    load_2_11_19  free_load_conservation_1495  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1223  -30
    arc_2_11_20  connected_order_arc_1224  -12
    arc_2_11_20  out_degree_1439  1
    arc_2_11_20  in_degree_1497  1
    arc_2_11_20  original_T_including_depot_unload_1510  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1223  1
    load_2_11_20  segment_load_conservation_1443  1
    load_2_11_20  free_load_conservation_1501  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1225  -30
    arc_2_11_21  connected_order_arc_1226  -12
    arc_2_11_21  out_degree_1439  1
    arc_2_11_21  in_degree_1503  1
    arc_2_11_21  original_T_including_depot_unload_1510  1.4208855669296320e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1225  1
    load_2_11_21  segment_load_conservation_1443  1
    load_2_11_21  free_load_conservation_1507  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1227  -30
    arc_2_12_0  depot_return_or_bypass_1438  1
    arc_2_12_0  out_degree_1446  1
    arc_2_12_0  original_T_including_depot_unload_1510  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1227  1
    load_2_12_0  segment_load_conservation_1450  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1228  -30
    arc_2_12_11  connected_order_arc_1229  -12
    arc_2_12_11  in_degree_1440  1
    arc_2_12_11  out_degree_1446  1
    arc_2_12_11  original_T_including_depot_unload_1510  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1228  1
    load_2_12_11  segment_load_conservation_1443  -1
    load_2_12_11  segment_prefix_lb_1444  1
    load_2_12_11  segment_prefix_ub_1445  1
    load_2_12_11  segment_load_conservation_1450  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1230  -30
    arc_2_12_13  connected_order_arc_1231  -12
    arc_2_12_13  out_degree_1446  1
    arc_2_12_13  in_degree_1454  1
    arc_2_12_13  original_T_including_depot_unload_1510  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1230  1
    load_2_12_13  segment_load_conservation_1450  1
    load_2_12_13  segment_load_conservation_1457  -1
    load_2_12_13  segment_prefix_lb_1458  1
    load_2_12_13  segment_prefix_ub_1459  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1232  -30
    arc_2_12_14  connected_order_arc_1233  -12
    arc_2_12_14  out_degree_1446  1
    arc_2_12_14  in_degree_1461  1
    arc_2_12_14  original_T_including_depot_unload_1510  2.3332921717499753e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1232  1
    load_2_12_14  segment_load_conservation_1450  1
    load_2_12_14  free_load_conservation_1465  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1234  -30
    arc_2_12_15  connected_order_arc_1235  -12
    arc_2_12_15  out_degree_1446  1
    arc_2_12_15  in_degree_1467  1
    arc_2_12_15  original_T_including_depot_unload_1510  2.4083174684193741e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1234  1
    load_2_12_15  segment_load_conservation_1450  1
    load_2_12_15  free_load_conservation_1471  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1236  -30
    arc_2_12_16  connected_order_arc_1237  -12
    arc_2_12_16  out_degree_1446  1
    arc_2_12_16  in_degree_1473  1
    arc_2_12_16  original_T_including_depot_unload_1510  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1236  1
    load_2_12_16  segment_load_conservation_1450  1
    load_2_12_16  free_load_conservation_1477  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1238  -30
    arc_2_12_17  connected_order_arc_1239  -12
    arc_2_12_17  out_degree_1446  1
    arc_2_12_17  in_degree_1479  1
    arc_2_12_17  original_T_including_depot_unload_1510  2.2308484254926752e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1238  1
    load_2_12_17  segment_load_conservation_1450  1
    load_2_12_17  free_load_conservation_1483  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1240  -30
    arc_2_12_18  connected_order_arc_1241  -12
    arc_2_12_18  out_degree_1446  1
    arc_2_12_18  in_degree_1485  1
    arc_2_12_18  original_T_including_depot_unload_1510  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1240  1
    load_2_12_18  segment_load_conservation_1450  1
    load_2_12_18  free_load_conservation_1489  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1242  -30
    arc_2_12_19  connected_order_arc_1243  -12
    arc_2_12_19  out_degree_1446  1
    arc_2_12_19  in_degree_1491  1
    arc_2_12_19  original_T_including_depot_unload_1510  2204.98417103458
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1242  1
    load_2_12_19  segment_load_conservation_1450  1
    load_2_12_19  free_load_conservation_1495  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1244  -30
    arc_2_12_20  connected_order_arc_1245  -12
    arc_2_12_20  out_degree_1446  1
    arc_2_12_20  in_degree_1497  1
    arc_2_12_20  original_T_including_depot_unload_1510  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1244  1
    load_2_12_20  segment_load_conservation_1450  1
    load_2_12_20  free_load_conservation_1501  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1246  -30
    arc_2_12_21  connected_order_arc_1247  -12
    arc_2_12_21  out_degree_1446  1
    arc_2_12_21  in_degree_1503  1
    arc_2_12_21  original_T_including_depot_unload_1510  2.2046488102052867e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1246  1
    load_2_12_21  segment_load_conservation_1450  1
    load_2_12_21  free_load_conservation_1507  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1248  -30
    arc_2_13_0  depot_return_or_bypass_1438  1
    arc_2_13_0  out_degree_1453  1
    arc_2_13_0  original_T_including_depot_unload_1510  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1248  1
    load_2_13_0  segment_load_conservation_1457  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1249  -30
    arc_2_13_11  connected_order_arc_1250  -12
    arc_2_13_11  in_degree_1440  1
    arc_2_13_11  out_degree_1453  1
    arc_2_13_11  original_T_including_depot_unload_1510  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1249  1
    load_2_13_11  segment_load_conservation_1443  -1
    load_2_13_11  segment_prefix_lb_1444  1
    load_2_13_11  segment_prefix_ub_1445  1
    load_2_13_11  segment_load_conservation_1457  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1251  -30
    arc_2_13_12  connected_order_arc_1252  -12
    arc_2_13_12  in_degree_1447  1
    arc_2_13_12  out_degree_1453  1
    arc_2_13_12  original_T_including_depot_unload_1510  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1251  1
    load_2_13_12  segment_load_conservation_1450  -1
    load_2_13_12  segment_prefix_lb_1451  1
    load_2_13_12  segment_prefix_ub_1452  1
    load_2_13_12  segment_load_conservation_1457  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1253  -30
    arc_2_13_14  connected_order_arc_1254  -12
    arc_2_13_14  out_degree_1453  1
    arc_2_13_14  in_degree_1461  1
    arc_2_13_14  original_T_including_depot_unload_1510  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1253  1
    load_2_13_14  segment_load_conservation_1457  1
    load_2_13_14  free_load_conservation_1465  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1255  -30
    arc_2_13_15  connected_order_arc_1256  -12
    arc_2_13_15  out_degree_1453  1
    arc_2_13_15  in_degree_1467  1
    arc_2_13_15  original_T_including_depot_unload_1510  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1255  1
    load_2_13_15  segment_load_conservation_1457  1
    load_2_13_15  free_load_conservation_1471  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1257  -30
    arc_2_13_16  connected_order_arc_1258  -12
    arc_2_13_16  out_degree_1453  1
    arc_2_13_16  in_degree_1473  1
    arc_2_13_16  original_T_including_depot_unload_1510  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1257  1
    load_2_13_16  segment_load_conservation_1457  1
    load_2_13_16  free_load_conservation_1477  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1259  -30
    arc_2_13_17  connected_order_arc_1260  -12
    arc_2_13_17  out_degree_1453  1
    arc_2_13_17  in_degree_1479  1
    arc_2_13_17  original_T_including_depot_unload_1510  1.0803844170008674e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1259  1
    load_2_13_17  segment_load_conservation_1457  1
    load_2_13_17  free_load_conservation_1483  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1261  -30
    arc_2_13_18  connected_order_arc_1262  -12
    arc_2_13_18  out_degree_1453  1
    arc_2_13_18  in_degree_1485  1
    arc_2_13_18  original_T_including_depot_unload_1510  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1261  1
    load_2_13_18  segment_load_conservation_1457  1
    load_2_13_18  free_load_conservation_1489  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1263  -30
    arc_2_13_19  connected_order_arc_1264  -12
    arc_2_13_19  out_degree_1453  1
    arc_2_13_19  in_degree_1491  1
    arc_2_13_19  original_T_including_depot_unload_1510  1.0665299943292241e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1263  1
    load_2_13_19  segment_load_conservation_1457  1
    load_2_13_19  free_load_conservation_1495  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1265  -30
    arc_2_13_20  connected_order_arc_1266  -12
    arc_2_13_20  out_degree_1453  1
    arc_2_13_20  in_degree_1497  1
    arc_2_13_20  original_T_including_depot_unload_1510  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1265  1
    load_2_13_20  segment_load_conservation_1457  1
    load_2_13_20  free_load_conservation_1501  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1267  -30
    arc_2_13_21  connected_order_arc_1268  -12
    arc_2_13_21  out_degree_1453  1
    arc_2_13_21  in_degree_1503  1
    arc_2_13_21  original_T_including_depot_unload_1510  1.0660093540264595e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1267  1
    load_2_13_21  segment_load_conservation_1457  1
    load_2_13_21  free_load_conservation_1507  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1269  -30
    arc_2_14_0  depot_return_or_bypass_1438  1
    arc_2_14_0  out_degree_1460  1
    arc_2_14_0  original_T_including_depot_unload_1510  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1269  1
    load_2_14_0  free_load_conservation_1465  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1270  -30
    arc_2_14_11  connected_order_arc_1271  -12
    arc_2_14_11  in_degree_1440  1
    arc_2_14_11  out_degree_1460  1
    arc_2_14_11  original_T_including_depot_unload_1510  1.5756194178147177e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1270  1
    load_2_14_11  segment_load_conservation_1443  -1
    load_2_14_11  segment_prefix_lb_1444  1
    load_2_14_11  segment_prefix_ub_1445  1
    load_2_14_11  free_load_conservation_1465  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1272  -30
    arc_2_14_12  connected_order_arc_1273  -12
    arc_2_14_12  in_degree_1447  1
    arc_2_14_12  out_degree_1460  1
    arc_2_14_12  original_T_including_depot_unload_1510  2.1566797920965496e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1272  1
    load_2_14_12  segment_load_conservation_1450  -1
    load_2_14_12  segment_prefix_lb_1451  1
    load_2_14_12  segment_prefix_ub_1452  1
    load_2_14_12  free_load_conservation_1465  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1274  -30
    arc_2_14_13  connected_order_arc_1275  -12
    arc_2_14_13  in_degree_1454  1
    arc_2_14_13  out_degree_1460  1
    arc_2_14_13  original_T_including_depot_unload_1510  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1274  1
    load_2_14_13  segment_load_conservation_1457  -1
    load_2_14_13  segment_prefix_lb_1458  1
    load_2_14_13  segment_prefix_ub_1459  1
    load_2_14_13  free_load_conservation_1465  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1276  -30
    arc_2_14_15  connected_order_arc_1277  -12
    arc_2_14_15  out_degree_1460  1
    arc_2_14_15  in_degree_1467  1
    arc_2_14_15  original_T_including_depot_unload_1510  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1276  1
    load_2_14_15  free_load_conservation_1465  1
    load_2_14_15  free_load_conservation_1471  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1278  -30
    arc_2_14_16  connected_order_arc_1279  -12
    arc_2_14_16  out_degree_1460  1
    arc_2_14_16  in_degree_1473  1
    arc_2_14_16  original_T_including_depot_unload_1510  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1278  1
    load_2_14_16  free_load_conservation_1465  1
    load_2_14_16  free_load_conservation_1477  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1280  -30
    arc_2_14_17  connected_order_arc_1281  -12
    arc_2_14_17  out_degree_1460  1
    arc_2_14_17  in_degree_1479  1
    arc_2_14_17  original_T_including_depot_unload_1510  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1280  1
    load_2_14_17  free_load_conservation_1465  1
    load_2_14_17  free_load_conservation_1483  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1282  -30
    arc_2_14_18  connected_order_arc_1283  -12
    arc_2_14_18  out_degree_1460  1
    arc_2_14_18  in_degree_1485  1
    arc_2_14_18  original_T_including_depot_unload_1510  1.7807233899807140e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1282  1
    load_2_14_18  free_load_conservation_1465  1
    load_2_14_18  free_load_conservation_1489  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1284  -30
    arc_2_14_19  connected_order_arc_1285  -12
    arc_2_14_19  out_degree_1460  1
    arc_2_14_19  in_degree_1491  1
    arc_2_14_19  original_T_including_depot_unload_1510  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1284  1
    load_2_14_19  free_load_conservation_1465  1
    load_2_14_19  free_load_conservation_1495  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1286  -30
    arc_2_14_20  connected_order_arc_1287  -12
    arc_2_14_20  out_degree_1460  1
    arc_2_14_20  in_degree_1497  1
    arc_2_14_20  original_T_including_depot_unload_1510  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1286  1
    load_2_14_20  free_load_conservation_1465  1
    load_2_14_20  free_load_conservation_1501  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1288  -30
    arc_2_14_21  connected_order_arc_1289  -12
    arc_2_14_21  out_degree_1460  1
    arc_2_14_21  in_degree_1503  1
    arc_2_14_21  original_T_including_depot_unload_1510  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1288  1
    load_2_14_21  free_load_conservation_1465  1
    load_2_14_21  free_load_conservation_1507  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1290  -30
    arc_2_15_0  depot_return_or_bypass_1438  1
    arc_2_15_0  out_degree_1466  1
    arc_2_15_0  original_T_including_depot_unload_1510  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1290  1
    load_2_15_0  free_load_conservation_1471  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1291  -30
    arc_2_15_11  connected_order_arc_1292  -12
    arc_2_15_11  in_degree_1440  1
    arc_2_15_11  out_degree_1466  1
    arc_2_15_11  original_T_including_depot_unload_1510  1.6813024470003036e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1291  1
    load_2_15_11  segment_load_conservation_1443  -1
    load_2_15_11  segment_prefix_lb_1444  1
    load_2_15_11  segment_prefix_ub_1445  1
    load_2_15_11  free_load_conservation_1471  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1293  -30
    arc_2_15_12  connected_order_arc_1294  -12
    arc_2_15_12  in_degree_1447  1
    arc_2_15_12  out_degree_1466  1
    arc_2_15_12  original_T_including_depot_unload_1510  2.2684160167710820e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1293  1
    load_2_15_12  segment_load_conservation_1450  -1
    load_2_15_12  segment_prefix_lb_1451  1
    load_2_15_12  segment_prefix_ub_1452  1
    load_2_15_12  free_load_conservation_1471  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1295  -30
    arc_2_15_13  connected_order_arc_1296  -12
    arc_2_15_13  in_degree_1454  1
    arc_2_15_13  out_degree_1466  1
    arc_2_15_13  original_T_including_depot_unload_1510  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1295  1
    load_2_15_13  segment_load_conservation_1457  -1
    load_2_15_13  segment_prefix_lb_1458  1
    load_2_15_13  segment_prefix_ub_1459  1
    load_2_15_13  free_load_conservation_1471  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1297  -30
    arc_2_15_14  connected_order_arc_1298  -12
    arc_2_15_14  in_degree_1461  1
    arc_2_15_14  out_degree_1466  1
    arc_2_15_14  original_T_including_depot_unload_1510  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1297  1
    load_2_15_14  free_load_conservation_1465  -1
    load_2_15_14  free_load_conservation_1471  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1299  -30
    arc_2_15_16  connected_order_arc_1300  -12
    arc_2_15_16  out_degree_1466  1
    arc_2_15_16  in_degree_1473  1
    arc_2_15_16  original_T_including_depot_unload_1510  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1299  1
    load_2_15_16  free_load_conservation_1471  1
    load_2_15_16  free_load_conservation_1477  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1301  -30
    arc_2_15_17  connected_order_arc_1302  -12
    arc_2_15_17  out_degree_1466  1
    arc_2_15_17  in_degree_1479  1
    arc_2_15_17  original_T_including_depot_unload_1510  2.6361257108552718e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1301  1
    load_2_15_17  free_load_conservation_1471  1
    load_2_15_17  free_load_conservation_1483  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1303  -30
    arc_2_15_18  connected_order_arc_1304  -12
    arc_2_15_18  out_degree_1466  1
    arc_2_15_18  in_degree_1485  1
    arc_2_15_18  original_T_including_depot_unload_1510  1.8786452499301340e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1303  1
    load_2_15_18  free_load_conservation_1471  1
    load_2_15_18  free_load_conservation_1489  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1305  -30
    arc_2_15_19  connected_order_arc_1306  -12
    arc_2_15_19  out_degree_1466  1
    arc_2_15_19  in_degree_1491  1
    arc_2_15_19  original_T_including_depot_unload_1510  2.6417860079316790e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1305  1
    load_2_15_19  free_load_conservation_1471  1
    load_2_15_19  free_load_conservation_1495  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1307  -30
    arc_2_15_20  connected_order_arc_1308  -12
    arc_2_15_20  out_degree_1466  1
    arc_2_15_20  in_degree_1497  1
    arc_2_15_20  original_T_including_depot_unload_1510  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1307  1
    load_2_15_20  free_load_conservation_1471  1
    load_2_15_20  free_load_conservation_1501  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1309  -30
    arc_2_15_21  connected_order_arc_1310  -12
    arc_2_15_21  out_degree_1466  1
    arc_2_15_21  in_degree_1503  1
    arc_2_15_21  original_T_including_depot_unload_1510  2.6477572380586179e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1309  1
    load_2_15_21  free_load_conservation_1471  1
    load_2_15_21  free_load_conservation_1507  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1311  -30
    arc_2_16_0  depot_return_or_bypass_1438  1
    arc_2_16_0  out_degree_1472  1
    arc_2_16_0  original_T_including_depot_unload_1510  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1311  1
    load_2_16_0  free_load_conservation_1477  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1312  -30
    arc_2_16_11  connected_order_arc_1313  -12
    arc_2_16_11  in_degree_1440  1
    arc_2_16_11  out_degree_1472  1
    arc_2_16_11  original_T_including_depot_unload_1510  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1312  1
    load_2_16_11  segment_load_conservation_1443  -1
    load_2_16_11  segment_prefix_lb_1444  1
    load_2_16_11  segment_prefix_ub_1445  1
    load_2_16_11  free_load_conservation_1477  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1314  -30
    arc_2_16_12  connected_order_arc_1315  -12
    arc_2_16_12  in_degree_1447  1
    arc_2_16_12  out_degree_1472  1
    arc_2_16_12  original_T_including_depot_unload_1510  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1314  1
    load_2_16_12  segment_load_conservation_1450  -1
    load_2_16_12  segment_prefix_lb_1451  1
    load_2_16_12  segment_prefix_ub_1452  1
    load_2_16_12  free_load_conservation_1477  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1316  -30
    arc_2_16_13  connected_order_arc_1317  -12
    arc_2_16_13  in_degree_1454  1
    arc_2_16_13  out_degree_1472  1
    arc_2_16_13  original_T_including_depot_unload_1510  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1316  1
    load_2_16_13  segment_load_conservation_1457  -1
    load_2_16_13  segment_prefix_lb_1458  1
    load_2_16_13  segment_prefix_ub_1459  1
    load_2_16_13  free_load_conservation_1477  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1318  -30
    arc_2_16_14  connected_order_arc_1319  -12
    arc_2_16_14  in_degree_1461  1
    arc_2_16_14  out_degree_1472  1
    arc_2_16_14  original_T_including_depot_unload_1510  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1318  1
    load_2_16_14  free_load_conservation_1465  -1
    load_2_16_14  free_load_conservation_1477  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1320  -30
    arc_2_16_15  connected_order_arc_1321  -12
    arc_2_16_15  in_degree_1467  1
    arc_2_16_15  out_degree_1472  1
    arc_2_16_15  original_T_including_depot_unload_1510  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1320  1
    load_2_16_15  free_load_conservation_1471  -1
    load_2_16_15  free_load_conservation_1477  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1322  -30
    arc_2_16_17  connected_order_arc_1323  -12
    arc_2_16_17  out_degree_1472  1
    arc_2_16_17  in_degree_1479  1
    arc_2_16_17  original_T_including_depot_unload_1510  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1322  1
    load_2_16_17  free_load_conservation_1477  1
    load_2_16_17  free_load_conservation_1483  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1324  -30
    arc_2_16_18  connected_order_arc_1325  -12
    arc_2_16_18  out_degree_1472  1
    arc_2_16_18  in_degree_1485  1
    arc_2_16_18  original_T_including_depot_unload_1510  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1324  1
    load_2_16_18  free_load_conservation_1477  1
    load_2_16_18  free_load_conservation_1489  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1326  -30
    arc_2_16_19  connected_order_arc_1327  -12
    arc_2_16_19  out_degree_1472  1
    arc_2_16_19  in_degree_1491  1
    arc_2_16_19  original_T_including_depot_unload_1510  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1326  1
    load_2_16_19  free_load_conservation_1477  1
    load_2_16_19  free_load_conservation_1495  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1328  -30
    arc_2_16_20  connected_order_arc_1329  -12
    arc_2_16_20  out_degree_1472  1
    arc_2_16_20  in_degree_1497  1
    arc_2_16_20  original_T_including_depot_unload_1510  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1328  1
    load_2_16_20  free_load_conservation_1477  1
    load_2_16_20  free_load_conservation_1501  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1330  -30
    arc_2_16_21  connected_order_arc_1331  -12
    arc_2_16_21  out_degree_1472  1
    arc_2_16_21  in_degree_1503  1
    arc_2_16_21  original_T_including_depot_unload_1510  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1330  1
    load_2_16_21  free_load_conservation_1477  1
    load_2_16_21  free_load_conservation_1507  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1332  -30
    arc_2_17_0  depot_return_or_bypass_1438  1
    arc_2_17_0  out_degree_1478  1
    arc_2_17_0  original_T_including_depot_unload_1510  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1332  1
    load_2_17_0  free_load_conservation_1483  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1333  -30
    arc_2_17_11  connected_order_arc_1334  -12
    arc_2_17_11  in_degree_1440  1
    arc_2_17_11  out_degree_1478  1
    arc_2_17_11  original_T_including_depot_unload_1510  1.4316381888253884e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1333  1
    load_2_17_11  segment_load_conservation_1443  -1
    load_2_17_11  segment_prefix_lb_1444  1
    load_2_17_11  segment_prefix_ub_1445  1
    load_2_17_11  free_load_conservation_1483  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1335  -30
    arc_2_17_12  connected_order_arc_1336  -12
    arc_2_17_12  in_degree_1447  1
    arc_2_17_12  out_degree_1478  1
    arc_2_17_12  original_T_including_depot_unload_1510  2.0052615109144283e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1335  1
    load_2_17_12  segment_load_conservation_1450  -1
    load_2_17_12  segment_prefix_lb_1451  1
    load_2_17_12  segment_prefix_ub_1452  1
    load_2_17_12  free_load_conservation_1483  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1337  -30
    arc_2_17_13  connected_order_arc_1338  -12
    arc_2_17_13  in_degree_1454  1
    arc_2_17_13  out_degree_1478  1
    arc_2_17_13  original_T_including_depot_unload_1510  1.0803844170008674e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1337  1
    load_2_17_13  segment_load_conservation_1457  -1
    load_2_17_13  segment_prefix_lb_1458  1
    load_2_17_13  segment_prefix_ub_1459  1
    load_2_17_13  free_load_conservation_1483  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1339  -30
    arc_2_17_14  connected_order_arc_1340  -12
    arc_2_17_14  in_degree_1461  1
    arc_2_17_14  out_degree_1478  1
    arc_2_17_14  original_T_including_depot_unload_1510  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1339  1
    load_2_17_14  free_load_conservation_1465  -1
    load_2_17_14  free_load_conservation_1483  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1341  -30
    arc_2_17_15  connected_order_arc_1342  -12
    arc_2_17_15  in_degree_1467  1
    arc_2_17_15  out_degree_1478  1
    arc_2_17_15  original_T_including_depot_unload_1510  2.6361257108552718e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1341  1
    load_2_17_15  free_load_conservation_1471  -1
    load_2_17_15  free_load_conservation_1483  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1343  -30
    arc_2_17_16  connected_order_arc_1344  -12
    arc_2_17_16  in_degree_1473  1
    arc_2_17_16  out_degree_1478  1
    arc_2_17_16  original_T_including_depot_unload_1510  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1343  1
    load_2_17_16  free_load_conservation_1477  -1
    load_2_17_16  free_load_conservation_1483  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1345  -30
    arc_2_17_18  connected_order_arc_1346  -12
    arc_2_17_18  out_degree_1478  1
    arc_2_17_18  in_degree_1485  1
    arc_2_17_18  original_T_including_depot_unload_1510  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1345  1
    load_2_17_18  free_load_conservation_1483  1
    load_2_17_18  free_load_conservation_1489  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1347  -30
    arc_2_17_19  connected_order_arc_1348  -12
    arc_2_17_19  out_degree_1478  1
    arc_2_17_19  in_degree_1491  1
    arc_2_17_19  original_T_including_depot_unload_1510  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1347  1
    load_2_17_19  free_load_conservation_1483  1
    load_2_17_19  free_load_conservation_1495  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1349  -30
    arc_2_17_20  connected_order_arc_1350  -12
    arc_2_17_20  out_degree_1478  1
    arc_2_17_20  in_degree_1497  1
    arc_2_17_20  original_T_including_depot_unload_1510  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1349  1
    load_2_17_20  free_load_conservation_1483  1
    load_2_17_20  free_load_conservation_1501  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1351  -30
    arc_2_17_21  connected_order_arc_1352  -12
    arc_2_17_21  out_degree_1478  1
    arc_2_17_21  in_degree_1503  1
    arc_2_17_21  original_T_including_depot_unload_1510  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1351  1
    load_2_17_21  free_load_conservation_1483  1
    load_2_17_21  free_load_conservation_1507  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1353  -30
    arc_2_18_0  depot_return_or_bypass_1438  1
    arc_2_18_0  out_degree_1484  1
    arc_2_18_0  original_T_including_depot_unload_1510  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1353  1
    load_2_18_0  free_load_conservation_1489  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1354  -30
    arc_2_18_11  connected_order_arc_1355  -12
    arc_2_18_11  in_degree_1440  1
    arc_2_18_11  out_degree_1484  1
    arc_2_18_11  original_T_including_depot_unload_1510  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1354  1
    load_2_18_11  segment_load_conservation_1443  -1
    load_2_18_11  segment_prefix_lb_1444  1
    load_2_18_11  segment_prefix_ub_1445  1
    load_2_18_11  free_load_conservation_1489  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1356  -30
    arc_2_18_12  connected_order_arc_1357  -12
    arc_2_18_12  in_degree_1447  1
    arc_2_18_12  out_degree_1484  1
    arc_2_18_12  original_T_including_depot_unload_1510  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1356  1
    load_2_18_12  segment_load_conservation_1450  -1
    load_2_18_12  segment_prefix_lb_1451  1
    load_2_18_12  segment_prefix_ub_1452  1
    load_2_18_12  free_load_conservation_1489  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1358  -30
    arc_2_18_13  connected_order_arc_1359  -12
    arc_2_18_13  in_degree_1454  1
    arc_2_18_13  out_degree_1484  1
    arc_2_18_13  original_T_including_depot_unload_1510  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1358  1
    load_2_18_13  segment_load_conservation_1457  -1
    load_2_18_13  segment_prefix_lb_1458  1
    load_2_18_13  segment_prefix_ub_1459  1
    load_2_18_13  free_load_conservation_1489  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1360  -30
    arc_2_18_14  connected_order_arc_1361  -12
    arc_2_18_14  in_degree_1461  1
    arc_2_18_14  out_degree_1484  1
    arc_2_18_14  original_T_including_depot_unload_1510  1.7807233899807140e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1360  1
    load_2_18_14  free_load_conservation_1465  -1
    load_2_18_14  free_load_conservation_1489  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1362  -30
    arc_2_18_15  connected_order_arc_1363  -12
    arc_2_18_15  in_degree_1467  1
    arc_2_18_15  out_degree_1484  1
    arc_2_18_15  original_T_including_depot_unload_1510  1.8786452499301340e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1362  1
    load_2_18_15  free_load_conservation_1471  -1
    load_2_18_15  free_load_conservation_1489  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1364  -30
    arc_2_18_16  connected_order_arc_1365  -12
    arc_2_18_16  in_degree_1473  1
    arc_2_18_16  out_degree_1484  1
    arc_2_18_16  original_T_including_depot_unload_1510  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1364  1
    load_2_18_16  free_load_conservation_1477  -1
    load_2_18_16  free_load_conservation_1489  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1366  -30
    arc_2_18_17  connected_order_arc_1367  -12
    arc_2_18_17  in_degree_1479  1
    arc_2_18_17  out_degree_1484  1
    arc_2_18_17  original_T_including_depot_unload_1510  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1366  1
    load_2_18_17  free_load_conservation_1483  -1
    load_2_18_17  free_load_conservation_1489  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1368  -30
    arc_2_18_19  connected_order_arc_1369  -12
    arc_2_18_19  out_degree_1484  1
    arc_2_18_19  in_degree_1491  1
    arc_2_18_19  original_T_including_depot_unload_1510  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1368  1
    load_2_18_19  free_load_conservation_1489  1
    load_2_18_19  free_load_conservation_1495  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1370  -30
    arc_2_18_20  connected_order_arc_1371  -12
    arc_2_18_20  out_degree_1484  1
    arc_2_18_20  in_degree_1497  1
    arc_2_18_20  original_T_including_depot_unload_1510  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1370  1
    load_2_18_20  free_load_conservation_1489  1
    load_2_18_20  free_load_conservation_1501  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1372  -30
    arc_2_18_21  connected_order_arc_1373  -12
    arc_2_18_21  out_degree_1484  1
    arc_2_18_21  in_degree_1503  1
    arc_2_18_21  original_T_including_depot_unload_1510  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1372  1
    load_2_18_21  free_load_conservation_1489  1
    load_2_18_21  free_load_conservation_1507  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1374  -30
    arc_2_19_0  depot_return_or_bypass_1438  1
    arc_2_19_0  out_degree_1490  1
    arc_2_19_0  original_T_including_depot_unload_1510  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1374  1
    load_2_19_0  free_load_conservation_1495  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1375  -30
    arc_2_19_11  connected_order_arc_1376  -12
    arc_2_19_11  in_degree_1440  1
    arc_2_19_11  out_degree_1490  1
    arc_2_19_11  original_T_including_depot_unload_1510  1.4214388997747180e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1375  1
    load_2_19_11  segment_load_conservation_1443  -1
    load_2_19_11  segment_prefix_lb_1444  1
    load_2_19_11  segment_prefix_ub_1445  1
    load_2_19_11  free_load_conservation_1495  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1377  -30
    arc_2_19_12  connected_order_arc_1378  -12
    arc_2_19_12  in_degree_1447  1
    arc_2_19_12  out_degree_1490  1
    arc_2_19_12  original_T_including_depot_unload_1510  2.0051673213472504e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1377  1
    load_2_19_12  segment_load_conservation_1450  -1
    load_2_19_12  segment_prefix_lb_1451  1
    load_2_19_12  segment_prefix_ub_1452  1
    load_2_19_12  free_load_conservation_1495  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1379  -30
    arc_2_19_13  connected_order_arc_1380  -12
    arc_2_19_13  in_degree_1454  1
    arc_2_19_13  out_degree_1490  1
    arc_2_19_13  original_T_including_depot_unload_1510  1.0665299943292241e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1379  1
    load_2_19_13  segment_load_conservation_1457  -1
    load_2_19_13  segment_prefix_lb_1458  1
    load_2_19_13  segment_prefix_ub_1459  1
    load_2_19_13  free_load_conservation_1495  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1381  -30
    arc_2_19_14  connected_order_arc_1382  -12
    arc_2_19_14  in_degree_1461  1
    arc_2_19_14  out_degree_1490  1
    arc_2_19_14  original_T_including_depot_unload_1510  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1381  1
    load_2_19_14  free_load_conservation_1465  -1
    load_2_19_14  free_load_conservation_1495  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1383  -30
    arc_2_19_15  connected_order_arc_1384  -12
    arc_2_19_15  in_degree_1467  1
    arc_2_19_15  out_degree_1490  1
    arc_2_19_15  original_T_including_depot_unload_1510  2.6417860079316790e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1383  1
    load_2_19_15  free_load_conservation_1471  -1
    load_2_19_15  free_load_conservation_1495  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1385  -30
    arc_2_19_16  connected_order_arc_1386  -12
    arc_2_19_16  in_degree_1473  1
    arc_2_19_16  out_degree_1490  1
    arc_2_19_16  original_T_including_depot_unload_1510  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1385  1
    load_2_19_16  free_load_conservation_1477  -1
    load_2_19_16  free_load_conservation_1495  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1387  -30
    arc_2_19_17  connected_order_arc_1388  -12
    arc_2_19_17  in_degree_1479  1
    arc_2_19_17  out_degree_1490  1
    arc_2_19_17  original_T_including_depot_unload_1510  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1387  1
    load_2_19_17  free_load_conservation_1483  -1
    load_2_19_17  free_load_conservation_1495  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1389  -30
    arc_2_19_18  connected_order_arc_1390  -12
    arc_2_19_18  in_degree_1485  1
    arc_2_19_18  out_degree_1490  1
    arc_2_19_18  original_T_including_depot_unload_1510  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1389  1
    load_2_19_18  free_load_conservation_1489  -1
    load_2_19_18  free_load_conservation_1495  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1391  -30
    arc_2_19_20  connected_order_arc_1392  -12
    arc_2_19_20  out_degree_1490  1
    arc_2_19_20  in_degree_1497  1
    arc_2_19_20  original_T_including_depot_unload_1510  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1391  1
    load_2_19_20  free_load_conservation_1495  1
    load_2_19_20  free_load_conservation_1501  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1393  -30
    arc_2_19_21  connected_order_arc_1394  -12
    arc_2_19_21  out_degree_1490  1
    arc_2_19_21  in_degree_1503  1
    arc_2_19_21  original_T_including_depot_unload_1510  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1393  1
    load_2_19_21  free_load_conservation_1495  1
    load_2_19_21  free_load_conservation_1507  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1395  -30
    arc_2_20_0  depot_return_or_bypass_1438  1
    arc_2_20_0  out_degree_1496  1
    arc_2_20_0  original_T_including_depot_unload_1510  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1395  1
    load_2_20_0  free_load_conservation_1501  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1396  -30
    arc_2_20_11  connected_order_arc_1397  -12
    arc_2_20_11  in_degree_1440  1
    arc_2_20_11  out_degree_1496  1
    arc_2_20_11  original_T_including_depot_unload_1510  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1396  1
    load_2_20_11  segment_load_conservation_1443  -1
    load_2_20_11  segment_prefix_lb_1444  1
    load_2_20_11  segment_prefix_ub_1445  1
    load_2_20_11  free_load_conservation_1501  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1398  -30
    arc_2_20_12  connected_order_arc_1399  -12
    arc_2_20_12  in_degree_1447  1
    arc_2_20_12  out_degree_1496  1
    arc_2_20_12  original_T_including_depot_unload_1510  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1398  1
    load_2_20_12  segment_load_conservation_1450  -1
    load_2_20_12  segment_prefix_lb_1451  1
    load_2_20_12  segment_prefix_ub_1452  1
    load_2_20_12  free_load_conservation_1501  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1400  -30
    arc_2_20_13  connected_order_arc_1401  -12
    arc_2_20_13  in_degree_1454  1
    arc_2_20_13  out_degree_1496  1
    arc_2_20_13  original_T_including_depot_unload_1510  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1400  1
    load_2_20_13  segment_load_conservation_1457  -1
    load_2_20_13  segment_prefix_lb_1458  1
    load_2_20_13  segment_prefix_ub_1459  1
    load_2_20_13  free_load_conservation_1501  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1402  -30
    arc_2_20_14  connected_order_arc_1403  -12
    arc_2_20_14  in_degree_1461  1
    arc_2_20_14  out_degree_1496  1
    arc_2_20_14  original_T_including_depot_unload_1510  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1402  1
    load_2_20_14  free_load_conservation_1465  -1
    load_2_20_14  free_load_conservation_1501  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1404  -30
    arc_2_20_15  connected_order_arc_1405  -12
    arc_2_20_15  in_degree_1467  1
    arc_2_20_15  out_degree_1496  1
    arc_2_20_15  original_T_including_depot_unload_1510  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1404  1
    load_2_20_15  free_load_conservation_1471  -1
    load_2_20_15  free_load_conservation_1501  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1406  -30
    arc_2_20_16  connected_order_arc_1407  -12
    arc_2_20_16  in_degree_1473  1
    arc_2_20_16  out_degree_1496  1
    arc_2_20_16  original_T_including_depot_unload_1510  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1406  1
    load_2_20_16  free_load_conservation_1477  -1
    load_2_20_16  free_load_conservation_1501  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1408  -30
    arc_2_20_17  connected_order_arc_1409  -12
    arc_2_20_17  in_degree_1479  1
    arc_2_20_17  out_degree_1496  1
    arc_2_20_17  original_T_including_depot_unload_1510  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1408  1
    load_2_20_17  free_load_conservation_1483  -1
    load_2_20_17  free_load_conservation_1501  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1410  -30
    arc_2_20_18  connected_order_arc_1411  -12
    arc_2_20_18  in_degree_1485  1
    arc_2_20_18  out_degree_1496  1
    arc_2_20_18  original_T_including_depot_unload_1510  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1410  1
    load_2_20_18  free_load_conservation_1489  -1
    load_2_20_18  free_load_conservation_1501  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1412  -30
    arc_2_20_19  connected_order_arc_1413  -12
    arc_2_20_19  in_degree_1491  1
    arc_2_20_19  out_degree_1496  1
    arc_2_20_19  original_T_including_depot_unload_1510  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1412  1
    load_2_20_19  free_load_conservation_1495  -1
    load_2_20_19  free_load_conservation_1501  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1414  -30
    arc_2_20_21  connected_order_arc_1415  -12
    arc_2_20_21  out_degree_1496  1
    arc_2_20_21  in_degree_1503  1
    arc_2_20_21  original_T_including_depot_unload_1510  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1414  1
    load_2_20_21  free_load_conservation_1501  1
    load_2_20_21  free_load_conservation_1507  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1416  -30
    arc_2_21_0  depot_return_or_bypass_1438  1
    arc_2_21_0  out_degree_1502  1
    arc_2_21_0  original_T_including_depot_unload_1510  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1416  1
    load_2_21_0  free_load_conservation_1507  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1417  -30
    arc_2_21_11  connected_order_arc_1418  -12
    arc_2_21_11  in_degree_1440  1
    arc_2_21_11  out_degree_1502  1
    arc_2_21_11  original_T_including_depot_unload_1510  1.4208855669296320e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1417  1
    load_2_21_11  segment_load_conservation_1443  -1
    load_2_21_11  segment_prefix_lb_1444  1
    load_2_21_11  segment_prefix_ub_1445  1
    load_2_21_11  free_load_conservation_1507  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1419  -30
    arc_2_21_12  connected_order_arc_1420  -12
    arc_2_21_12  in_degree_1447  1
    arc_2_21_12  out_degree_1502  1
    arc_2_21_12  original_T_including_depot_unload_1510  2.0045579804597039e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1419  1
    load_2_21_12  segment_load_conservation_1450  -1
    load_2_21_12  segment_prefix_lb_1451  1
    load_2_21_12  segment_prefix_ub_1452  1
    load_2_21_12  free_load_conservation_1507  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1421  -30
    arc_2_21_13  connected_order_arc_1422  -12
    arc_2_21_13  in_degree_1454  1
    arc_2_21_13  out_degree_1502  1
    arc_2_21_13  original_T_including_depot_unload_1510  1.0660093540264595e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1421  1
    load_2_21_13  segment_load_conservation_1457  -1
    load_2_21_13  segment_prefix_lb_1458  1
    load_2_21_13  segment_prefix_ub_1459  1
    load_2_21_13  free_load_conservation_1507  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1423  -30
    arc_2_21_14  connected_order_arc_1424  -12
    arc_2_21_14  in_degree_1461  1
    arc_2_21_14  out_degree_1502  1
    arc_2_21_14  original_T_including_depot_unload_1510  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1423  1
    load_2_21_14  free_load_conservation_1465  -1
    load_2_21_14  free_load_conservation_1507  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1425  -30
    arc_2_21_15  connected_order_arc_1426  -12
    arc_2_21_15  in_degree_1467  1
    arc_2_21_15  out_degree_1502  1
    arc_2_21_15  original_T_including_depot_unload_1510  2.6477572380586179e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1425  1
    load_2_21_15  free_load_conservation_1471  -1
    load_2_21_15  free_load_conservation_1507  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1427  -30
    arc_2_21_16  connected_order_arc_1428  -12
    arc_2_21_16  in_degree_1473  1
    arc_2_21_16  out_degree_1502  1
    arc_2_21_16  original_T_including_depot_unload_1510  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1427  1
    load_2_21_16  free_load_conservation_1477  -1
    load_2_21_16  free_load_conservation_1507  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1429  -30
    arc_2_21_17  connected_order_arc_1430  -12
    arc_2_21_17  in_degree_1479  1
    arc_2_21_17  out_degree_1502  1
    arc_2_21_17  original_T_including_depot_unload_1510  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1429  1
    load_2_21_17  free_load_conservation_1483  -1
    load_2_21_17  free_load_conservation_1507  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1431  -30
    arc_2_21_18  connected_order_arc_1432  -12
    arc_2_21_18  in_degree_1485  1
    arc_2_21_18  out_degree_1502  1
    arc_2_21_18  original_T_including_depot_unload_1510  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1431  1
    load_2_21_18  free_load_conservation_1489  -1
    load_2_21_18  free_load_conservation_1507  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1433  -30
    arc_2_21_19  connected_order_arc_1434  -12
    arc_2_21_19  in_degree_1491  1
    arc_2_21_19  out_degree_1502  1
    arc_2_21_19  original_T_including_depot_unload_1510  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1433  1
    load_2_21_19  free_load_conservation_1495  -1
    load_2_21_19  free_load_conservation_1507  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1435  -30
    arc_2_21_20  connected_order_arc_1436  -12
    arc_2_21_20  in_degree_1497  1
    arc_2_21_20  out_degree_1502  1
    arc_2_21_20  original_T_including_depot_unload_1510  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1435  1
    load_2_21_20  free_load_conservation_1501  -1
    load_2_21_20  free_load_conservation_1507  1
RHS
    RHS1      OBJ       -2.3515175282245490e-01
    RHS1      onehot_8_26  1
    RHS1      onehot_6_47  1
    RHS1      onehot_34_82  1
    RHS1      onehot_9_107  1
    RHS1      onehot_29_132  1
    RHS1      onehot_10_149  1
    RHS1      onehot_27_166  1
    RHS1      onehot_11_191  1
    RHS1      stock_ub_195  25
    RHS1      parent_nonstrict_scope_196  2.6879265398688018e-01
    RHS1      normalization_253  1
    RHS1      connected_order_arc_349  -14
    RHS1      connected_order_arc_351  -14
    RHS1      connected_order_arc_353  -14
    RHS1      connected_order_arc_355  -14
    RHS1      connected_order_arc_357  -14
    RHS1      connected_order_arc_359  -14
    RHS1      connected_order_arc_361  -14
    RHS1      connected_order_arc_363  -14
    RHS1      connected_order_arc_365  -14
    RHS1      connected_order_arc_367  -14
    RHS1      connected_order_arc_369  -14
    RHS1      connected_order_arc_371  -14
    RHS1      connected_order_arc_373  -14
    RHS1      connected_order_arc_376  -14
    RHS1      connected_order_arc_378  -14
    RHS1      connected_order_arc_380  -14
    RHS1      connected_order_arc_382  -14
    RHS1      connected_order_arc_384  -14
    RHS1      connected_order_arc_386  -14
    RHS1      connected_order_arc_388  -14
    RHS1      connected_order_arc_390  -14
    RHS1      connected_order_arc_392  -14
    RHS1      connected_order_arc_394  -14
    RHS1      connected_order_arc_396  -14
    RHS1      connected_order_arc_398  -14
    RHS1      connected_order_arc_400  -14
    RHS1      connected_order_arc_403  -14
    RHS1      connected_order_arc_405  -14
    RHS1      connected_order_arc_407  -14
    RHS1      connected_order_arc_409  -14
    RHS1      connected_order_arc_411  -14
    RHS1      connected_order_arc_413  -14
    RHS1      connected_order_arc_415  -14
    RHS1      connected_order_arc_417  -14
    RHS1      connected_order_arc_419  -14
    RHS1      connected_order_arc_421  -14
    RHS1      connected_order_arc_423  -14
    RHS1      connected_order_arc_425  -14
    RHS1      connected_order_arc_427  -14
    RHS1      connected_order_arc_430  -14
    RHS1      connected_order_arc_432  -14
    RHS1      connected_order_arc_434  -14
    RHS1      connected_order_arc_436  -14
    RHS1      connected_order_arc_438  -14
    RHS1      connected_order_arc_440  -14
    RHS1      connected_order_arc_442  -14
    RHS1      connected_order_arc_444  -14
    RHS1      connected_order_arc_446  -14
    RHS1      connected_order_arc_448  -14
    RHS1      connected_order_arc_450  -14
    RHS1      connected_order_arc_452  -14
    RHS1      connected_order_arc_454  -14
    RHS1      connected_order_arc_457  -14
    RHS1      connected_order_arc_459  -14
    RHS1      connected_order_arc_461  -14
    RHS1      connected_order_arc_463  -14
    RHS1      connected_order_arc_465  -14
    RHS1      connected_order_arc_467  -14
    RHS1      connected_order_arc_469  -14
    RHS1      connected_order_arc_471  -14
    RHS1      connected_order_arc_473  -14
    RHS1      connected_order_arc_475  -14
    RHS1      connected_order_arc_477  -14
    RHS1      connected_order_arc_479  -14
    RHS1      connected_order_arc_481  -14
    RHS1      connected_order_arc_484  -14
    RHS1      connected_order_arc_486  -14
    RHS1      connected_order_arc_488  -14
    RHS1      connected_order_arc_490  -14
    RHS1      connected_order_arc_492  -14
    RHS1      connected_order_arc_494  -14
    RHS1      connected_order_arc_496  -14
    RHS1      connected_order_arc_498  -14
    RHS1      connected_order_arc_500  -14
    RHS1      connected_order_arc_502  -14
    RHS1      connected_order_arc_504  -14
    RHS1      connected_order_arc_506  -14
    RHS1      connected_order_arc_508  -14
    RHS1      connected_order_arc_511  -14
    RHS1      connected_order_arc_513  -14
    RHS1      connected_order_arc_515  -14
    RHS1      connected_order_arc_517  -14
    RHS1      connected_order_arc_519  -14
    RHS1      connected_order_arc_521  -14
    RHS1      connected_order_arc_523  -14
    RHS1      connected_order_arc_525  -14
    RHS1      connected_order_arc_527  -14
    RHS1      connected_order_arc_529  -14
    RHS1      connected_order_arc_531  -14
    RHS1      connected_order_arc_533  -14
    RHS1      connected_order_arc_535  -14
    RHS1      connected_order_arc_538  -14
    RHS1      connected_order_arc_540  -14
    RHS1      connected_order_arc_542  -14
    RHS1      connected_order_arc_544  -14
    RHS1      connected_order_arc_546  -14
    RHS1      connected_order_arc_548  -14
    RHS1      connected_order_arc_550  -14
    RHS1      connected_order_arc_552  -14
    RHS1      connected_order_arc_554  -14
    RHS1      connected_order_arc_556  -14
    RHS1      connected_order_arc_558  -14
    RHS1      connected_order_arc_560  -14
    RHS1      connected_order_arc_562  -14
    RHS1      connected_order_arc_565  -14
    RHS1      connected_order_arc_567  -14
    RHS1      connected_order_arc_569  -14
    RHS1      connected_order_arc_571  -14
    RHS1      connected_order_arc_573  -14
    RHS1      connected_order_arc_575  -14
    RHS1      connected_order_arc_577  -14
    RHS1      connected_order_arc_579  -14
    RHS1      connected_order_arc_581  -14
    RHS1      connected_order_arc_583  -14
    RHS1      connected_order_arc_585  -14
    RHS1      connected_order_arc_587  -14
    RHS1      connected_order_arc_589  -14
    RHS1      connected_order_arc_592  -14
    RHS1      connected_order_arc_594  -14
    RHS1      connected_order_arc_596  -14
    RHS1      connected_order_arc_598  -14
    RHS1      connected_order_arc_600  -14
    RHS1      connected_order_arc_602  -14
    RHS1      connected_order_arc_604  -14
    RHS1      connected_order_arc_606  -14
    RHS1      connected_order_arc_608  -14
    RHS1      connected_order_arc_610  -14
    RHS1      connected_order_arc_612  -14
    RHS1      connected_order_arc_614  -14
    RHS1      connected_order_arc_616  -14
    RHS1      connected_order_arc_619  -14
    RHS1      connected_order_arc_621  -14
    RHS1      connected_order_arc_623  -14
    RHS1      connected_order_arc_625  -14
    RHS1      connected_order_arc_627  -14
    RHS1      connected_order_arc_629  -14
    RHS1      connected_order_arc_631  -14
    RHS1      connected_order_arc_633  -14
    RHS1      connected_order_arc_635  -14
    RHS1      connected_order_arc_637  -14
    RHS1      connected_order_arc_639  -14
    RHS1      connected_order_arc_641  -14
    RHS1      connected_order_arc_643  -14
    RHS1      connected_order_arc_646  -14
    RHS1      connected_order_arc_648  -14
    RHS1      connected_order_arc_650  -14
    RHS1      connected_order_arc_652  -14
    RHS1      connected_order_arc_654  -14
    RHS1      connected_order_arc_656  -14
    RHS1      connected_order_arc_658  -14
    RHS1      connected_order_arc_660  -14
    RHS1      connected_order_arc_662  -14
    RHS1      connected_order_arc_664  -14
    RHS1      connected_order_arc_666  -14
    RHS1      connected_order_arc_668  -14
    RHS1      connected_order_arc_670  -14
    RHS1      connected_order_arc_673  -14
    RHS1      connected_order_arc_675  -14
    RHS1      connected_order_arc_677  -14
    RHS1      connected_order_arc_679  -14
    RHS1      connected_order_arc_681  -14
    RHS1      connected_order_arc_683  -14
    RHS1      connected_order_arc_685  -14
    RHS1      connected_order_arc_687  -14
    RHS1      connected_order_arc_689  -14
    RHS1      connected_order_arc_691  -14
    RHS1      connected_order_arc_693  -14
    RHS1      connected_order_arc_695  -14
    RHS1      connected_order_arc_697  -14
    RHS1      connected_order_arc_700  -14
    RHS1      connected_order_arc_702  -14
    RHS1      connected_order_arc_704  -14
    RHS1      connected_order_arc_706  -14
    RHS1      connected_order_arc_708  -14
    RHS1      connected_order_arc_710  -14
    RHS1      connected_order_arc_712  -14
    RHS1      connected_order_arc_714  -14
    RHS1      connected_order_arc_716  -14
    RHS1      connected_order_arc_718  -14
    RHS1      connected_order_arc_720  -14
    RHS1      connected_order_arc_722  -14
    RHS1      connected_order_arc_724  -14
    RHS1      depot_departure_or_bypass_725  1
    RHS1      depot_return_or_bypass_726  1
    RHS1      segment_load_conservation_731  2
    RHS1      segment_prefix_ub_733  18
    RHS1      segment_load_conservation_738  -4
    RHS1      segment_prefix_lb_739  4
    RHS1      segment_prefix_ub_740  20
    RHS1      segment_load_conservation_745  4
    RHS1      segment_prefix_ub_747  16
    RHS1      segment_load_conservation_752  -5
    RHS1      segment_prefix_lb_753  5
    RHS1      segment_prefix_ub_754  20
    RHS1      segment_load_conservation_759  -5
    RHS1      segment_prefix_lb_760  5
    RHS1      segment_prefix_ub_761  20
    RHS1      segment_load_conservation_766  1
    RHS1      segment_prefix_ub_768  14
    RHS1      fixed_segment_relative_order_817  1
    RHS1      fixed_segment_relative_order_818  1
    RHS1      fixed_segment_relative_order_819  1
    RHS1      fixed_segment_relative_order_820  1
    RHS1      fixed_segment_relative_order_821  1
    RHS1      original_T_including_depot_unload_822  4.1205718147700072e+03
    RHS1      connected_order_arc_838  -12
    RHS1      connected_order_arc_840  -12
    RHS1      connected_order_arc_842  -12
    RHS1      connected_order_arc_844  -12
    RHS1      connected_order_arc_846  -12
    RHS1      connected_order_arc_848  -12
    RHS1      connected_order_arc_850  -12
    RHS1      connected_order_arc_852  -12
    RHS1      connected_order_arc_854  -12
    RHS1      connected_order_arc_856  -12
    RHS1      connected_order_arc_858  -12
    RHS1      connected_order_arc_861  -12
    RHS1      connected_order_arc_863  -12
    RHS1      connected_order_arc_865  -12
    RHS1      connected_order_arc_867  -12
    RHS1      connected_order_arc_869  -12
    RHS1      connected_order_arc_871  -12
    RHS1      connected_order_arc_873  -12
    RHS1      connected_order_arc_875  -12
    RHS1      connected_order_arc_877  -12
    RHS1      connected_order_arc_879  -12
    RHS1      connected_order_arc_881  -12
    RHS1      connected_order_arc_884  -12
    RHS1      connected_order_arc_886  -12
    RHS1      connected_order_arc_888  -12
    RHS1      connected_order_arc_890  -12
    RHS1      connected_order_arc_892  -12
    RHS1      connected_order_arc_894  -12
    RHS1      connected_order_arc_896  -12
    RHS1      connected_order_arc_898  -12
    RHS1      connected_order_arc_900  -12
    RHS1      connected_order_arc_902  -12
    RHS1      connected_order_arc_904  -12
    RHS1      connected_order_arc_907  -12
    RHS1      connected_order_arc_909  -12
    RHS1      connected_order_arc_911  -12
    RHS1      connected_order_arc_913  -12
    RHS1      connected_order_arc_915  -12
    RHS1      connected_order_arc_917  -12
    RHS1      connected_order_arc_919  -12
    RHS1      connected_order_arc_921  -12
    RHS1      connected_order_arc_923  -12
    RHS1      connected_order_arc_925  -12
    RHS1      connected_order_arc_927  -12
    RHS1      connected_order_arc_930  -12
    RHS1      connected_order_arc_932  -12
    RHS1      connected_order_arc_934  -12
    RHS1      connected_order_arc_936  -12
    RHS1      connected_order_arc_938  -12
    RHS1      connected_order_arc_940  -12
    RHS1      connected_order_arc_942  -12
    RHS1      connected_order_arc_944  -12
    RHS1      connected_order_arc_946  -12
    RHS1      connected_order_arc_948  -12
    RHS1      connected_order_arc_950  -12
    RHS1      connected_order_arc_953  -12
    RHS1      connected_order_arc_955  -12
    RHS1      connected_order_arc_957  -12
    RHS1      connected_order_arc_959  -12
    RHS1      connected_order_arc_961  -12
    RHS1      connected_order_arc_963  -12
    RHS1      connected_order_arc_965  -12
    RHS1      connected_order_arc_967  -12
    RHS1      connected_order_arc_969  -12
    RHS1      connected_order_arc_971  -12
    RHS1      connected_order_arc_973  -12
    RHS1      connected_order_arc_976  -12
    RHS1      connected_order_arc_978  -12
    RHS1      connected_order_arc_980  -12
    RHS1      connected_order_arc_982  -12
    RHS1      connected_order_arc_984  -12
    RHS1      connected_order_arc_986  -12
    RHS1      connected_order_arc_988  -12
    RHS1      connected_order_arc_990  -12
    RHS1      connected_order_arc_992  -12
    RHS1      connected_order_arc_994  -12
    RHS1      connected_order_arc_996  -12
    RHS1      connected_order_arc_999  -12
    RHS1      connected_order_arc_1001  -12
    RHS1      connected_order_arc_1003  -12
    RHS1      connected_order_arc_1005  -12
    RHS1      connected_order_arc_1007  -12
    RHS1      connected_order_arc_1009  -12
    RHS1      connected_order_arc_1011  -12
    RHS1      connected_order_arc_1013  -12
    RHS1      connected_order_arc_1015  -12
    RHS1      connected_order_arc_1017  -12
    RHS1      connected_order_arc_1019  -12
    RHS1      connected_order_arc_1022  -12
    RHS1      connected_order_arc_1024  -12
    RHS1      connected_order_arc_1026  -12
    RHS1      connected_order_arc_1028  -12
    RHS1      connected_order_arc_1030  -12
    RHS1      connected_order_arc_1032  -12
    RHS1      connected_order_arc_1034  -12
    RHS1      connected_order_arc_1036  -12
    RHS1      connected_order_arc_1038  -12
    RHS1      connected_order_arc_1040  -12
    RHS1      connected_order_arc_1042  -12
    RHS1      connected_order_arc_1045  -12
    RHS1      connected_order_arc_1047  -12
    RHS1      connected_order_arc_1049  -12
    RHS1      connected_order_arc_1051  -12
    RHS1      connected_order_arc_1053  -12
    RHS1      connected_order_arc_1055  -12
    RHS1      connected_order_arc_1057  -12
    RHS1      connected_order_arc_1059  -12
    RHS1      connected_order_arc_1061  -12
    RHS1      connected_order_arc_1063  -12
    RHS1      connected_order_arc_1065  -12
    RHS1      connected_order_arc_1068  -12
    RHS1      connected_order_arc_1070  -12
    RHS1      connected_order_arc_1072  -12
    RHS1      connected_order_arc_1074  -12
    RHS1      connected_order_arc_1076  -12
    RHS1      connected_order_arc_1078  -12
    RHS1      connected_order_arc_1080  -12
    RHS1      connected_order_arc_1082  -12
    RHS1      connected_order_arc_1084  -12
    RHS1      connected_order_arc_1086  -12
    RHS1      connected_order_arc_1088  -12
    RHS1      connected_order_arc_1091  -12
    RHS1      connected_order_arc_1093  -12
    RHS1      connected_order_arc_1095  -12
    RHS1      connected_order_arc_1097  -12
    RHS1      connected_order_arc_1099  -12
    RHS1      connected_order_arc_1101  -12
    RHS1      connected_order_arc_1103  -12
    RHS1      connected_order_arc_1105  -12
    RHS1      connected_order_arc_1107  -12
    RHS1      connected_order_arc_1109  -12
    RHS1      connected_order_arc_1111  -12
    RHS1      depot_departure_or_bypass_1112  1
    RHS1      depot_return_or_bypass_1113  1
    RHS1      segment_load_conservation_1118  4
    RHS1      segment_prefix_ub_1120  20
    RHS1      segment_load_conservation_1125  5
    RHS1      segment_prefix_ub_1127  20
    RHS1      segment_load_conservation_1132  -4
    RHS1      segment_prefix_lb_1133  4
    RHS1      segment_prefix_ub_1134  25
    RHS1      segment_load_conservation_1139  -5
    RHS1      segment_prefix_lb_1140  5
    RHS1      segment_prefix_ub_1141  25
    RHS1      fixed_segment_relative_order_1190  1
    RHS1      fixed_segment_relative_order_1191  1
    RHS1      fixed_segment_relative_order_1192  1
    RHS1      original_T_including_depot_unload_1193  4.0180155701548429e+03
    RHS1      connected_order_arc_1208  -11
    RHS1      connected_order_arc_1210  -11
    RHS1      connected_order_arc_1212  -11
    RHS1      connected_order_arc_1214  -11
    RHS1      connected_order_arc_1216  -11
    RHS1      connected_order_arc_1218  -11
    RHS1      connected_order_arc_1220  -11
    RHS1      connected_order_arc_1222  -11
    RHS1      connected_order_arc_1224  -11
    RHS1      connected_order_arc_1226  -11
    RHS1      connected_order_arc_1229  -11
    RHS1      connected_order_arc_1231  -11
    RHS1      connected_order_arc_1233  -11
    RHS1      connected_order_arc_1235  -11
    RHS1      connected_order_arc_1237  -11
    RHS1      connected_order_arc_1239  -11
    RHS1      connected_order_arc_1241  -11
    RHS1      connected_order_arc_1243  -11
    RHS1      connected_order_arc_1245  -11
    RHS1      connected_order_arc_1247  -11
    RHS1      connected_order_arc_1250  -11
    RHS1      connected_order_arc_1252  -11
    RHS1      connected_order_arc_1254  -11
    RHS1      connected_order_arc_1256  -11
    RHS1      connected_order_arc_1258  -11
    RHS1      connected_order_arc_1260  -11
    RHS1      connected_order_arc_1262  -11
    RHS1      connected_order_arc_1264  -11
    RHS1      connected_order_arc_1266  -11
    RHS1      connected_order_arc_1268  -11
    RHS1      connected_order_arc_1271  -11
    RHS1      connected_order_arc_1273  -11
    RHS1      connected_order_arc_1275  -11
    RHS1      connected_order_arc_1277  -11
    RHS1      connected_order_arc_1279  -11
    RHS1      connected_order_arc_1281  -11
    RHS1      connected_order_arc_1283  -11
    RHS1      connected_order_arc_1285  -11
    RHS1      connected_order_arc_1287  -11
    RHS1      connected_order_arc_1289  -11
    RHS1      connected_order_arc_1292  -11
    RHS1      connected_order_arc_1294  -11
    RHS1      connected_order_arc_1296  -11
    RHS1      connected_order_arc_1298  -11
    RHS1      connected_order_arc_1300  -11
    RHS1      connected_order_arc_1302  -11
    RHS1      connected_order_arc_1304  -11
    RHS1      connected_order_arc_1306  -11
    RHS1      connected_order_arc_1308  -11
    RHS1      connected_order_arc_1310  -11
    RHS1      connected_order_arc_1313  -11
    RHS1      connected_order_arc_1315  -11
    RHS1      connected_order_arc_1317  -11
    RHS1      connected_order_arc_1319  -11
    RHS1      connected_order_arc_1321  -11
    RHS1      connected_order_arc_1323  -11
    RHS1      connected_order_arc_1325  -11
    RHS1      connected_order_arc_1327  -11
    RHS1      connected_order_arc_1329  -11
    RHS1      connected_order_arc_1331  -11
    RHS1      connected_order_arc_1334  -11
    RHS1      connected_order_arc_1336  -11
    RHS1      connected_order_arc_1338  -11
    RHS1      connected_order_arc_1340  -11
    RHS1      connected_order_arc_1342  -11
    RHS1      connected_order_arc_1344  -11
    RHS1      connected_order_arc_1346  -11
    RHS1      connected_order_arc_1348  -11
    RHS1      connected_order_arc_1350  -11
    RHS1      connected_order_arc_1352  -11
    RHS1      connected_order_arc_1355  -11
    RHS1      connected_order_arc_1357  -11
    RHS1      connected_order_arc_1359  -11
    RHS1      connected_order_arc_1361  -11
    RHS1      connected_order_arc_1363  -11
    RHS1      connected_order_arc_1365  -11
    RHS1      connected_order_arc_1367  -11
    RHS1      connected_order_arc_1369  -11
    RHS1      connected_order_arc_1371  -11
    RHS1      connected_order_arc_1373  -11
    RHS1      connected_order_arc_1376  -11
    RHS1      connected_order_arc_1378  -11
    RHS1      connected_order_arc_1380  -11
    RHS1      connected_order_arc_1382  -11
    RHS1      connected_order_arc_1384  -11
    RHS1      connected_order_arc_1386  -11
    RHS1      connected_order_arc_1388  -11
    RHS1      connected_order_arc_1390  -11
    RHS1      connected_order_arc_1392  -11
    RHS1      connected_order_arc_1394  -11
    RHS1      connected_order_arc_1397  -11
    RHS1      connected_order_arc_1399  -11
    RHS1      connected_order_arc_1401  -11
    RHS1      connected_order_arc_1403  -11
    RHS1      connected_order_arc_1405  -11
    RHS1      connected_order_arc_1407  -11
    RHS1      connected_order_arc_1409  -11
    RHS1      connected_order_arc_1411  -11
    RHS1      connected_order_arc_1413  -11
    RHS1      connected_order_arc_1415  -11
    RHS1      connected_order_arc_1418  -11
    RHS1      connected_order_arc_1420  -11
    RHS1      connected_order_arc_1422  -11
    RHS1      connected_order_arc_1424  -11
    RHS1      connected_order_arc_1426  -11
    RHS1      connected_order_arc_1428  -11
    RHS1      connected_order_arc_1430  -11
    RHS1      connected_order_arc_1432  -11
    RHS1      connected_order_arc_1434  -11
    RHS1      connected_order_arc_1436  -11
    RHS1      depot_departure_or_bypass_1437  1
    RHS1      depot_return_or_bypass_1438  1
    RHS1      segment_load_conservation_1443  2
    RHS1      segment_prefix_ub_1445  28
    RHS1      segment_load_conservation_1450  1
    RHS1      segment_prefix_lb_1451  2
    RHS1      segment_prefix_ub_1452  28
    RHS1      segment_load_conservation_1457  -3
    RHS1      segment_prefix_lb_1458  3
    RHS1      segment_prefix_ub_1459  30
    RHS1      fixed_segment_relative_order_1508  1
    RHS1      fixed_segment_relative_order_1509  1
    RHS1      original_T_including_depot_unload_1510  3.3317427925191068e+03
BOUNDS
 LO BND1      t         2.5900345337911936e-02
 UP BND1      t         4.3985966382198260e-02
 UP BND1      q         4.0666271100568246e-01
 BV BND1      x_8_0   
 UP BND1      w_8_0     4.3985966382198260e-02
 BV BND1      x_8_1   
 UP BND1      w_8_1     4.3985966382198260e-02
 BV BND1      x_8_2   
 UP BND1      w_8_2     4.3985966382198260e-02
 BV BND1      x_8_3   
 UP BND1      w_8_3     4.3985966382198260e-02
 BV BND1      x_8_4   
 UP BND1      w_8_4     4.3985966382198260e-02
 BV BND1      x_8_5   
 UP BND1      w_8_5     4.3985966382198260e-02
 BV BND1      x_8_6   
 UP BND1      w_8_6     4.3985966382198260e-02
 BV BND1      x_8_7   
 UP BND1      w_8_7     4.3985966382198260e-02
 BV BND1      x_8_8   
 UP BND1      w_8_8     4.3985966382198260e-02
 BV BND1      x_8_9   
 UP BND1      w_8_9     4.3985966382198260e-02
 BV BND1      x_8_10  
 UP BND1      w_8_10    4.3985966382198260e-02
 BV BND1      x_8_11  
 UP BND1      w_8_11    4.3985966382198260e-02
 BV BND1      x_8_12  
 UP BND1      w_8_12    4.3985966382198260e-02
 UP BND1      rho_8     1
 BV BND1      x_6_0   
 UP BND1      w_6_0     4.3985966382198260e-02
 BV BND1      x_6_1   
 UP BND1      w_6_1     4.3985966382198260e-02
 BV BND1      x_6_2   
 UP BND1      w_6_2     4.3985966382198260e-02
 BV BND1      x_6_3   
 UP BND1      w_6_3     4.3985966382198260e-02
 BV BND1      x_6_4   
 UP BND1      w_6_4     4.3985966382198260e-02
 BV BND1      x_6_5   
 UP BND1      w_6_5     4.3985966382198260e-02
 BV BND1      x_6_6   
 UP BND1      w_6_6     4.3985966382198260e-02
 BV BND1      x_6_7   
 UP BND1      w_6_7     4.3985966382198260e-02
 BV BND1      x_6_8   
 UP BND1      w_6_8     4.3985966382198260e-02
 UP BND1      rho_6     1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.3985966382198260e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.3985966382198260e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.3985966382198260e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.3985966382198260e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.3985966382198260e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.3985966382198260e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.3985966382198260e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.3985966382198260e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.3985966382198260e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.3985966382198260e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.3985966382198260e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.3985966382198260e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.3985966382198260e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.3985966382198260e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.3985966382198260e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.3985966382198260e-02
 UP BND1      rho_34    1
 BV BND1      x_9_0   
 UP BND1      w_9_0     4.3985966382198260e-02
 BV BND1      x_9_1   
 UP BND1      w_9_1     4.3985966382198260e-02
 BV BND1      x_9_2   
 UP BND1      w_9_2     4.3985966382198260e-02
 BV BND1      x_9_3   
 UP BND1      w_9_3     4.3985966382198260e-02
 BV BND1      x_9_4   
 UP BND1      w_9_4     4.3985966382198260e-02
 BV BND1      x_9_5   
 UP BND1      w_9_5     4.3985966382198260e-02
 BV BND1      x_9_6   
 UP BND1      w_9_6     4.3985966382198260e-02
 BV BND1      x_9_7   
 UP BND1      w_9_7     4.3985966382198260e-02
 BV BND1      x_9_8   
 UP BND1      w_9_8     4.3985966382198260e-02
 BV BND1      x_9_9   
 UP BND1      w_9_9     4.3985966382198260e-02
 BV BND1      x_9_10  
 UP BND1      w_9_10    4.3985966382198260e-02
 UP BND1      rho_9     1
 BV BND1      x_29_0  
 UP BND1      w_29_0    4.3985966382198260e-02
 BV BND1      x_29_1  
 UP BND1      w_29_1    4.3985966382198260e-02
 BV BND1      x_29_2  
 UP BND1      w_29_2    4.3985966382198260e-02
 BV BND1      x_29_3  
 UP BND1      w_29_3    4.3985966382198260e-02
 BV BND1      x_29_4  
 UP BND1      w_29_4    4.3985966382198260e-02
 BV BND1      x_29_5  
 UP BND1      w_29_5    4.3985966382198260e-02
 BV BND1      x_29_6  
 UP BND1      w_29_6    4.3985966382198260e-02
 BV BND1      x_29_7  
 UP BND1      w_29_7    4.3985966382198260e-02
 BV BND1      x_29_8  
 UP BND1      w_29_8    4.3985966382198260e-02
 BV BND1      x_29_9  
 UP BND1      w_29_9    4.3985966382198260e-02
 BV BND1      x_29_10 
 UP BND1      w_29_10   4.3985966382198260e-02
 UP BND1      rho_29    1
 BV BND1      x_10_0  
 UP BND1      w_10_0    4.3985966382198260e-02
 BV BND1      x_10_1  
 UP BND1      w_10_1    4.3985966382198260e-02
 BV BND1      x_10_2  
 UP BND1      w_10_2    4.3985966382198260e-02
 BV BND1      x_10_3  
 UP BND1      w_10_3    4.3985966382198260e-02
 BV BND1      x_10_4  
 UP BND1      w_10_4    4.3985966382198260e-02
 BV BND1      x_10_5  
 UP BND1      w_10_5    4.3985966382198260e-02
 BV BND1      x_10_6  
 UP BND1      w_10_6    4.3985966382198260e-02
 UP BND1      rho_10    1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.3985966382198260e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.3985966382198260e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.3985966382198260e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.3985966382198260e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.3985966382198260e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.3985966382198260e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.3985966382198260e-02
 UP BND1      rho_27    1
 BV BND1      x_11_0  
 UP BND1      w_11_0    4.3985966382198260e-02
 BV BND1      x_11_1  
 UP BND1      w_11_1    4.3985966382198260e-02
 BV BND1      x_11_2  
 UP BND1      w_11_2    4.3985966382198260e-02
 BV BND1      x_11_3  
 UP BND1      w_11_3    4.3985966382198260e-02
 BV BND1      x_11_4  
 UP BND1      w_11_4    4.3985966382198260e-02
 BV BND1      x_11_5  
 UP BND1      w_11_5    4.3985966382198260e-02
 BV BND1      x_11_6  
 UP BND1      w_11_6    4.3985966382198260e-02
 BV BND1      x_11_7  
 UP BND1      w_11_7    4.3985966382198260e-02
 BV BND1      x_11_8  
 UP BND1      w_11_8    4.3985966382198260e-02
 BV BND1      x_11_9  
 UP BND1      w_11_9    4.3985966382198260e-02
 BV BND1      x_11_10 
 UP BND1      w_11_10   4.3985966382198260e-02
 UP BND1      rho_11    1
 UP BND1      a_8_6     1
 UP BND1      a_8_34    1
 UP BND1      a_8_9     1
 UP BND1      a_8_29    1
 UP BND1      a_8_10    1
 UP BND1      a_8_27    1
 UP BND1      a_8_11    1
 UP BND1      a_6_34    1
 UP BND1      a_6_9     1
 UP BND1      a_6_29    1
 UP BND1      a_6_10    1
 UP BND1      a_6_27    1
 UP BND1      a_6_11    1
 UP BND1      a_34_9    1
 UP BND1      a_34_29   1
 UP BND1      a_34_10   1
 UP BND1      a_34_27   1
 UP BND1      a_34_11   1
 UP BND1      a_9_29    1
 UP BND1      a_9_10    1
 UP BND1      a_9_27    1
 UP BND1      a_9_11    1
 UP BND1      a_29_10   1
 UP BND1      a_29_27   1
 UP BND1      a_29_11   1
 UP BND1      a_10_27   1
 UP BND1      a_10_11   1
 UP BND1      a_27_11   1
 BV BND1      service_0_8_0
 BV BND1      service_0_8_1
 BV BND1      service_0_8_2
 BV BND1      service_0_8_3
 BV BND1      service_0_8_4
 BV BND1      service_0_8_5
 BV BND1      service_0_8_6
 BV BND1      service_0_8_7
 BV BND1      service_0_8_8
 BV BND1      service_0_8_10
 BV BND1      service_0_8_11
 BV BND1      service_0_8_12
 BV BND1      service_1_8_0
 BV BND1      service_1_8_1
 BV BND1      service_1_8_2
 BV BND1      service_1_8_3
 BV BND1      service_1_8_4
 BV BND1      service_1_8_5
 BV BND1      service_1_8_6
 BV BND1      service_1_8_7
 BV BND1      service_1_8_8
 BV BND1      service_1_8_10
 BV BND1      service_1_8_11
 BV BND1      service_1_8_12
 BV BND1      service_2_8_0
 BV BND1      service_2_8_1
 BV BND1      service_2_8_2
 BV BND1      service_2_8_3
 BV BND1      service_2_8_4
 BV BND1      service_2_8_5
 BV BND1      service_2_8_6
 BV BND1      service_2_8_7
 BV BND1      service_2_8_8
 BV BND1      service_2_8_10
 BV BND1      service_2_8_11
 BV BND1      service_2_8_12
 BV BND1      service_0_6_0
 BV BND1      service_0_6_1
 BV BND1      service_0_6_2
 BV BND1      service_0_6_3
 BV BND1      service_0_6_4
 BV BND1      service_0_6_5
 BV BND1      service_0_6_7
 BV BND1      service_0_6_8
 BV BND1      service_1_6_0
 BV BND1      service_1_6_1
 BV BND1      service_1_6_2
 BV BND1      service_1_6_3
 BV BND1      service_1_6_4
 BV BND1      service_1_6_5
 BV BND1      service_1_6_7
 BV BND1      service_1_6_8
 BV BND1      service_2_6_0
 BV BND1      service_2_6_1
 BV BND1      service_2_6_2
 BV BND1      service_2_6_3
 BV BND1      service_2_6_4
 BV BND1      service_2_6_5
 BV BND1      service_2_6_7
 BV BND1      service_2_6_8
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_9_0
 BV BND1      service_0_9_1
 BV BND1      service_0_9_3
 BV BND1      service_0_9_4
 BV BND1      service_0_9_5
 BV BND1      service_0_9_6
 BV BND1      service_0_9_7
 BV BND1      service_0_9_8
 BV BND1      service_0_9_9
 BV BND1      service_0_9_10
 BV BND1      service_1_9_0
 BV BND1      service_1_9_1
 BV BND1      service_1_9_3
 BV BND1      service_1_9_4
 BV BND1      service_1_9_5
 BV BND1      service_1_9_6
 BV BND1      service_1_9_7
 BV BND1      service_1_9_8
 BV BND1      service_1_9_9
 BV BND1      service_1_9_10
 BV BND1      service_2_9_0
 BV BND1      service_2_9_1
 BV BND1      service_2_9_3
 BV BND1      service_2_9_4
 BV BND1      service_2_9_5
 BV BND1      service_2_9_6
 BV BND1      service_2_9_7
 BV BND1      service_2_9_8
 BV BND1      service_2_9_9
 BV BND1      service_2_9_10
 BV BND1      service_0_29_0
 BV BND1      service_0_29_2
 BV BND1      service_0_29_3
 BV BND1      service_0_29_4
 BV BND1      service_0_29_5
 BV BND1      service_0_29_6
 BV BND1      service_0_29_7
 BV BND1      service_0_29_8
 BV BND1      service_0_29_9
 BV BND1      service_0_29_10
 BV BND1      service_1_29_0
 BV BND1      service_1_29_2
 BV BND1      service_1_29_3
 BV BND1      service_1_29_4
 BV BND1      service_1_29_5
 BV BND1      service_1_29_6
 BV BND1      service_1_29_7
 BV BND1      service_1_29_8
 BV BND1      service_1_29_9
 BV BND1      service_1_29_10
 BV BND1      service_2_29_0
 BV BND1      service_2_29_2
 BV BND1      service_2_29_3
 BV BND1      service_2_29_4
 BV BND1      service_2_29_5
 BV BND1      service_2_29_6
 BV BND1      service_2_29_7
 BV BND1      service_2_29_8
 BV BND1      service_2_29_9
 BV BND1      service_2_29_10
 BV BND1      service_0_10_0
 BV BND1      service_0_10_1
 BV BND1      service_0_10_2
 BV BND1      service_0_10_3
 BV BND1      service_0_10_5
 BV BND1      service_0_10_6
 BV BND1      service_1_10_0
 BV BND1      service_1_10_1
 BV BND1      service_1_10_2
 BV BND1      service_1_10_3
 BV BND1      service_1_10_5
 BV BND1      service_1_10_6
 BV BND1      service_2_10_0
 BV BND1      service_2_10_1
 BV BND1      service_2_10_2
 BV BND1      service_2_10_3
 BV BND1      service_2_10_5
 BV BND1      service_2_10_6
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_11_0
 BV BND1      service_0_11_1
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_7
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_1_11_0
 BV BND1      service_1_11_1
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_7
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_2_11_0
 BV BND1      service_2_11_1
 BV BND1      service_2_11_2
 BV BND1      service_2_11_3
 BV BND1      service_2_11_4
 BV BND1      service_2_11_5
 BV BND1      service_2_11_6
 BV BND1      service_2_11_7
 BV BND1      service_2_11_9
 BV BND1      service_2_11_10
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  14
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  14
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  14
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  14
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  14
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  14
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  14
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  20
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  20
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  20
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  20
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  20
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  20
 BV BND1      arc_0_6_14
 UP BND1      load_0_6_14  20
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  20
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  20
 BV BND1      arc_0_6_17
 UP BND1      load_0_6_17  20
 BV BND1      arc_0_6_18
 UP BND1      load_0_6_18  20
 BV BND1      arc_0_6_19
 UP BND1      load_0_6_19  20
 BV BND1      arc_0_6_20
 UP BND1      load_0_6_20  20
 BV BND1      arc_0_6_21
 UP BND1      load_0_6_21  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_6
 UP BND1      load_0_14_6  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_14_21
 UP BND1      load_0_14_21  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_6
 UP BND1      load_0_17_6  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_6
 UP BND1      load_0_18_6  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_6
 UP BND1      load_0_19_6  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_6
 UP BND1      load_0_20_6  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_6
 UP BND1      load_0_21_6  20
 BV BND1      arc_0_21_14
 UP BND1      load_0_21_14  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  25
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  25
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  25
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  25
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  25
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  25
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  25
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  25
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  25
 BV BND1      arc_1_10_19
 UP BND1      load_1_10_19  25
 BV BND1      arc_1_10_20
 UP BND1      load_1_10_20  25
 BV BND1      arc_1_10_21
 UP BND1      load_1_10_21  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_14_21
 UP BND1      load_1_14_21  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_10
 UP BND1      load_1_19_10  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_10
 UP BND1      load_1_20_10  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_10
 UP BND1      load_1_21_10  25
 BV BND1      arc_1_21_14
 UP BND1      load_1_21_14  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
ENDATA
