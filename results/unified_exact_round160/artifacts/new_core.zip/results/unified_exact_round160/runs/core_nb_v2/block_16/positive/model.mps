* Signature: 0xc297a4b3a536c204
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 E  onehot_30_18
 E  normalized_mass_30_19
 E  normalized_ratio_30_20
 G  product_lb_21
 L  product_ub_22
 G  product_lb_23
 L  product_ub_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 E  onehot_35_53
 E  normalized_mass_35_54
 E  normalized_ratio_35_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 E  onehot_31_82
 E  normalized_mass_31_83
 E  normalized_ratio_31_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 E  onehot_32_111
 E  normalized_mass_32_112
 E  normalized_ratio_32_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 E  onehot_19_132
 E  normalized_mass_19_133
 E  normalized_ratio_19_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 G  product_lb_143
 L  product_ub_144
 G  product_lb_145
 L  product_ub_146
 G  product_lb_147
 L  product_ub_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 E  onehot_26_153
 E  normalized_mass_26_154
 E  normalized_ratio_26_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 G  product_lb_178
 L  product_ub_179
 G  product_lb_180
 L  product_ub_181
 G  product_lb_182
 L  product_ub_183
 G  product_lb_184
 L  product_ub_185
 G  product_lb_186
 L  product_ub_187
 E  onehot_2_188
 E  normalized_mass_2_189
 E  normalized_ratio_2_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 G  product_lb_211
 L  product_ub_212
 G  product_lb_213
 L  product_ub_214
 G  product_lb_215
 L  product_ub_216
 G  product_lb_217
 L  product_ub_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 E  onehot_17_225
 E  normalized_mass_17_226
 E  normalized_ratio_17_227
 G  stock_lb_228
 L  stock_ub_229
 L  parent_nonstrict_scope_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 E  normalization_287
 G  full_original_Gini_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 L  arc_capacity_383
 L  arc_capacity_384
 L  arc_capacity_385
 L  arc_capacity_386
 L  arc_capacity_387
 L  arc_capacity_388
 L  arc_capacity_389
 L  arc_capacity_390
 L  arc_capacity_391
 L  arc_capacity_392
 L  arc_capacity_393
 L  arc_capacity_394
 L  arc_capacity_395
 L  arc_capacity_396
 L  arc_capacity_397
 L  arc_capacity_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 G  connected_order_arc_402
 L  arc_capacity_403
 G  connected_order_arc_404
 L  arc_capacity_405
 G  connected_order_arc_406
 L  arc_capacity_407
 G  connected_order_arc_408
 L  arc_capacity_409
 G  connected_order_arc_410
 L  arc_capacity_411
 G  connected_order_arc_412
 L  arc_capacity_413
 G  connected_order_arc_414
 L  arc_capacity_415
 G  connected_order_arc_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 G  connected_order_arc_435
 L  arc_capacity_436
 G  connected_order_arc_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 G  connected_order_arc_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 G  connected_order_arc_732
 L  arc_capacity_733
 G  connected_order_arc_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 G  connected_order_arc_748
 L  arc_capacity_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 G  connected_order_arc_755
 L  arc_capacity_756
 G  connected_order_arc_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 L  arc_capacity_768
 G  connected_order_arc_769
 L  arc_capacity_770
 G  connected_order_arc_771
 L  arc_capacity_772
 G  connected_order_arc_773
 L  arc_capacity_774
 G  connected_order_arc_775
 E  depot_departure_or_bypass_776
 E  depot_return_or_bypass_777
 E  out_degree_778
 E  in_degree_779
 G  order_active_lb_780
 L  order_active_ub_781
 E  segment_load_conservation_782
 G  segment_prefix_lb_783
 L  segment_prefix_ub_784
 E  out_degree_785
 E  in_degree_786
 G  order_active_lb_787
 L  order_active_ub_788
 E  segment_load_conservation_789
 G  segment_prefix_lb_790
 L  segment_prefix_ub_791
 E  out_degree_792
 E  in_degree_793
 G  order_active_lb_794
 L  order_active_ub_795
 E  segment_load_conservation_796
 G  segment_prefix_lb_797
 L  segment_prefix_ub_798
 E  out_degree_799
 E  in_degree_800
 G  order_active_lb_801
 L  order_active_ub_802
 E  segment_load_conservation_803
 G  segment_prefix_lb_804
 L  segment_prefix_ub_805
 E  out_degree_806
 E  in_degree_807
 G  order_active_lb_808
 L  order_active_ub_809
 E  segment_load_conservation_810
 G  segment_prefix_lb_811
 L  segment_prefix_ub_812
 E  out_degree_813
 E  in_degree_814
 G  order_active_lb_815
 L  order_active_ub_816
 E  segment_load_conservation_817
 G  segment_prefix_lb_818
 L  segment_prefix_ub_819
 E  out_degree_820
 E  in_degree_821
 G  order_active_lb_822
 L  order_active_ub_823
 E  service_visit_def_824
 E  free_load_conservation_825
 E  out_degree_826
 E  in_degree_827
 G  order_active_lb_828
 L  order_active_ub_829
 E  service_visit_def_830
 E  free_load_conservation_831
 E  out_degree_832
 E  in_degree_833
 G  order_active_lb_834
 L  order_active_ub_835
 E  service_visit_def_836
 E  free_load_conservation_837
 E  out_degree_838
 E  in_degree_839
 G  order_active_lb_840
 L  order_active_ub_841
 E  service_visit_def_842
 E  free_load_conservation_843
 E  out_degree_844
 E  in_degree_845
 G  order_active_lb_846
 L  order_active_ub_847
 E  service_visit_def_848
 E  free_load_conservation_849
 E  out_degree_850
 E  in_degree_851
 G  order_active_lb_852
 L  order_active_ub_853
 E  service_visit_def_854
 E  free_load_conservation_855
 E  out_degree_856
 E  in_degree_857
 G  order_active_lb_858
 L  order_active_ub_859
 E  service_visit_def_860
 E  free_load_conservation_861
 E  out_degree_862
 E  in_degree_863
 G  order_active_lb_864
 L  order_active_ub_865
 E  service_visit_def_866
 E  free_load_conservation_867
 G  fixed_segment_relative_order_868
 G  fixed_segment_relative_order_869
 G  fixed_segment_relative_order_870
 G  fixed_segment_relative_order_871
 G  fixed_segment_relative_order_872
 L  original_T_including_depot_unload_873
 L  arc_capacity_874
 L  arc_capacity_875
 L  arc_capacity_876
 L  arc_capacity_877
 L  arc_capacity_878
 L  arc_capacity_879
 L  arc_capacity_880
 L  arc_capacity_881
 L  arc_capacity_882
 L  arc_capacity_883
 L  arc_capacity_884
 L  arc_capacity_885
 L  arc_capacity_886
 L  arc_capacity_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 G  connected_order_arc_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 L  arc_capacity_1128
 G  connected_order_arc_1129
 L  arc_capacity_1130
 G  connected_order_arc_1131
 L  arc_capacity_1132
 G  connected_order_arc_1133
 L  arc_capacity_1134
 G  connected_order_arc_1135
 L  arc_capacity_1136
 G  connected_order_arc_1137
 L  arc_capacity_1138
 G  connected_order_arc_1139
 L  arc_capacity_1140
 L  arc_capacity_1141
 G  connected_order_arc_1142
 L  arc_capacity_1143
 G  connected_order_arc_1144
 L  arc_capacity_1145
 G  connected_order_arc_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 L  arc_capacity_1149
 G  connected_order_arc_1150
 L  arc_capacity_1151
 G  connected_order_arc_1152
 L  arc_capacity_1153
 G  connected_order_arc_1154
 L  arc_capacity_1155
 G  connected_order_arc_1156
 L  arc_capacity_1157
 G  connected_order_arc_1158
 L  arc_capacity_1159
 G  connected_order_arc_1160
 L  arc_capacity_1161
 G  connected_order_arc_1162
 E  depot_departure_or_bypass_1163
 E  depot_return_or_bypass_1164
 E  out_degree_1165
 E  in_degree_1166
 G  order_active_lb_1167
 L  order_active_ub_1168
 E  segment_load_conservation_1169
 G  segment_prefix_lb_1170
 L  segment_prefix_ub_1171
 E  out_degree_1172
 E  in_degree_1173
 G  order_active_lb_1174
 L  order_active_ub_1175
 E  segment_load_conservation_1176
 G  segment_prefix_lb_1177
 L  segment_prefix_ub_1178
 E  out_degree_1179
 E  in_degree_1180
 G  order_active_lb_1181
 L  order_active_ub_1182
 E  segment_load_conservation_1183
 G  segment_prefix_lb_1184
 L  segment_prefix_ub_1185
 E  out_degree_1186
 E  in_degree_1187
 G  order_active_lb_1188
 L  order_active_ub_1189
 E  segment_load_conservation_1190
 G  segment_prefix_lb_1191
 L  segment_prefix_ub_1192
 E  out_degree_1193
 E  in_degree_1194
 G  order_active_lb_1195
 L  order_active_ub_1196
 E  service_visit_def_1197
 E  free_load_conservation_1198
 E  out_degree_1199
 E  in_degree_1200
 G  order_active_lb_1201
 L  order_active_ub_1202
 E  service_visit_def_1203
 E  free_load_conservation_1204
 E  out_degree_1205
 E  in_degree_1206
 G  order_active_lb_1207
 L  order_active_ub_1208
 E  service_visit_def_1209
 E  free_load_conservation_1210
 E  out_degree_1211
 E  in_degree_1212
 G  order_active_lb_1213
 L  order_active_ub_1214
 E  service_visit_def_1215
 E  free_load_conservation_1216
 E  out_degree_1217
 E  in_degree_1218
 G  order_active_lb_1219
 L  order_active_ub_1220
 E  service_visit_def_1221
 E  free_load_conservation_1222
 E  out_degree_1223
 E  in_degree_1224
 G  order_active_lb_1225
 L  order_active_ub_1226
 E  service_visit_def_1227
 E  free_load_conservation_1228
 E  out_degree_1229
 E  in_degree_1230
 G  order_active_lb_1231
 L  order_active_ub_1232
 E  service_visit_def_1233
 E  free_load_conservation_1234
 E  out_degree_1235
 E  in_degree_1236
 G  order_active_lb_1237
 L  order_active_ub_1238
 E  service_visit_def_1239
 E  free_load_conservation_1240
 G  fixed_segment_relative_order_1241
 G  fixed_segment_relative_order_1242
 G  fixed_segment_relative_order_1243
 L  original_T_including_depot_unload_1244
 L  arc_capacity_1245
 L  arc_capacity_1246
 L  arc_capacity_1247
 L  arc_capacity_1248
 L  arc_capacity_1249
 L  arc_capacity_1250
 L  arc_capacity_1251
 L  arc_capacity_1252
 L  arc_capacity_1253
 L  arc_capacity_1254
 L  arc_capacity_1255
 L  arc_capacity_1256
 L  arc_capacity_1257
 L  arc_capacity_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 G  connected_order_arc_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 L  arc_capacity_1275
 G  connected_order_arc_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 G  connected_order_arc_1280
 L  arc_capacity_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 G  connected_order_arc_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 G  connected_order_arc_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 G  connected_order_arc_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 G  connected_order_arc_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 G  connected_order_arc_1364
 L  arc_capacity_1365
 G  connected_order_arc_1366
 L  arc_capacity_1367
 G  connected_order_arc_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 G  connected_order_arc_1385
 L  arc_capacity_1386
 G  connected_order_arc_1387
 L  arc_capacity_1388
 G  connected_order_arc_1389
 L  arc_capacity_1390
 G  connected_order_arc_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 G  connected_order_arc_1402
 L  arc_capacity_1403
 G  connected_order_arc_1404
 L  arc_capacity_1405
 G  connected_order_arc_1406
 L  arc_capacity_1407
 G  connected_order_arc_1408
 L  arc_capacity_1409
 G  connected_order_arc_1410
 L  arc_capacity_1411
 G  connected_order_arc_1412
 L  arc_capacity_1413
 G  connected_order_arc_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 G  connected_order_arc_1418
 L  arc_capacity_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 G  connected_order_arc_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 L  arc_capacity_1426
 G  connected_order_arc_1427
 L  arc_capacity_1428
 G  connected_order_arc_1429
 L  arc_capacity_1430
 G  connected_order_arc_1431
 L  arc_capacity_1432
 G  connected_order_arc_1433
 L  arc_capacity_1434
 G  connected_order_arc_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 L  arc_capacity_1438
 G  connected_order_arc_1439
 L  arc_capacity_1440
 G  connected_order_arc_1441
 L  arc_capacity_1442
 L  arc_capacity_1443
 G  connected_order_arc_1444
 L  arc_capacity_1445
 G  connected_order_arc_1446
 L  arc_capacity_1447
 G  connected_order_arc_1448
 L  arc_capacity_1449
 G  connected_order_arc_1450
 L  arc_capacity_1451
 G  connected_order_arc_1452
 L  arc_capacity_1453
 G  connected_order_arc_1454
 L  arc_capacity_1455
 G  connected_order_arc_1456
 L  arc_capacity_1457
 G  connected_order_arc_1458
 L  arc_capacity_1459
 G  connected_order_arc_1460
 L  arc_capacity_1461
 G  connected_order_arc_1462
 L  arc_capacity_1463
 G  connected_order_arc_1464
 L  arc_capacity_1465
 L  arc_capacity_1466
 G  connected_order_arc_1467
 L  arc_capacity_1468
 G  connected_order_arc_1469
 L  arc_capacity_1470
 G  connected_order_arc_1471
 L  arc_capacity_1472
 G  connected_order_arc_1473
 L  arc_capacity_1474
 G  connected_order_arc_1475
 L  arc_capacity_1476
 G  connected_order_arc_1477
 L  arc_capacity_1478
 G  connected_order_arc_1479
 L  arc_capacity_1480
 G  connected_order_arc_1481
 L  arc_capacity_1482
 G  connected_order_arc_1483
 L  arc_capacity_1484
 G  connected_order_arc_1485
 L  arc_capacity_1486
 G  connected_order_arc_1487
 L  arc_capacity_1488
 L  arc_capacity_1489
 G  connected_order_arc_1490
 L  arc_capacity_1491
 G  connected_order_arc_1492
 L  arc_capacity_1493
 G  connected_order_arc_1494
 L  arc_capacity_1495
 G  connected_order_arc_1496
 L  arc_capacity_1497
 G  connected_order_arc_1498
 L  arc_capacity_1499
 G  connected_order_arc_1500
 L  arc_capacity_1501
 G  connected_order_arc_1502
 L  arc_capacity_1503
 G  connected_order_arc_1504
 L  arc_capacity_1505
 G  connected_order_arc_1506
 L  arc_capacity_1507
 G  connected_order_arc_1508
 L  arc_capacity_1509
 G  connected_order_arc_1510
 L  arc_capacity_1511
 L  arc_capacity_1512
 G  connected_order_arc_1513
 L  arc_capacity_1514
 G  connected_order_arc_1515
 L  arc_capacity_1516
 G  connected_order_arc_1517
 L  arc_capacity_1518
 G  connected_order_arc_1519
 L  arc_capacity_1520
 G  connected_order_arc_1521
 L  arc_capacity_1522
 G  connected_order_arc_1523
 L  arc_capacity_1524
 G  connected_order_arc_1525
 L  arc_capacity_1526
 G  connected_order_arc_1527
 L  arc_capacity_1528
 G  connected_order_arc_1529
 L  arc_capacity_1530
 G  connected_order_arc_1531
 L  arc_capacity_1532
 G  connected_order_arc_1533
 E  depot_departure_or_bypass_1534
 E  depot_return_or_bypass_1535
 E  out_degree_1536
 E  in_degree_1537
 G  order_active_lb_1538
 L  order_active_ub_1539
 E  segment_load_conservation_1540
 G  segment_prefix_lb_1541
 L  segment_prefix_ub_1542
 E  out_degree_1543
 E  in_degree_1544
 G  order_active_lb_1545
 L  order_active_ub_1546
 E  segment_load_conservation_1547
 G  segment_prefix_lb_1548
 L  segment_prefix_ub_1549
 E  out_degree_1550
 E  in_degree_1551
 G  order_active_lb_1552
 L  order_active_ub_1553
 E  segment_load_conservation_1554
 G  segment_prefix_lb_1555
 L  segment_prefix_ub_1556
 E  out_degree_1557
 E  in_degree_1558
 G  order_active_lb_1559
 L  order_active_ub_1560
 E  segment_load_conservation_1561
 G  segment_prefix_lb_1562
 L  segment_prefix_ub_1563
 E  out_degree_1564
 E  in_degree_1565
 G  order_active_lb_1566
 L  order_active_ub_1567
 E  service_visit_def_1568
 E  free_load_conservation_1569
 E  out_degree_1570
 E  in_degree_1571
 G  order_active_lb_1572
 L  order_active_ub_1573
 E  service_visit_def_1574
 E  free_load_conservation_1575
 E  out_degree_1576
 E  in_degree_1577
 G  order_active_lb_1578
 L  order_active_ub_1579
 E  service_visit_def_1580
 E  free_load_conservation_1581
 E  out_degree_1582
 E  in_degree_1583
 G  order_active_lb_1584
 L  order_active_ub_1585
 E  service_visit_def_1586
 E  free_load_conservation_1587
 E  out_degree_1588
 E  in_degree_1589
 G  order_active_lb_1590
 L  order_active_ub_1591
 E  service_visit_def_1592
 E  free_load_conservation_1593
 E  out_degree_1594
 E  in_degree_1595
 G  order_active_lb_1596
 L  order_active_ub_1597
 E  service_visit_def_1598
 E  free_load_conservation_1599
 E  out_degree_1600
 E  in_degree_1601
 G  order_active_lb_1602
 L  order_active_ub_1603
 E  service_visit_def_1604
 E  free_load_conservation_1605
 E  out_degree_1606
 E  in_degree_1607
 G  order_active_lb_1608
 L  order_active_ub_1609
 E  service_visit_def_1610
 E  free_load_conservation_1611
 G  fixed_segment_relative_order_1612
 G  fixed_segment_relative_order_1613
 G  fixed_segment_relative_order_1614
 L  original_T_including_depot_unload_1615
COLUMNS
    t         normalized_mass_30_19  -1
    t         normalized_mass_35_54  -1
    t         normalized_mass_31_83  -1
    t         normalized_mass_32_112  -1
    t         normalized_mass_19_133  -1
    t         normalized_mass_26_154  -1
    t         normalized_mass_2_189  -1
    t         normalized_mass_17_226  -1
    t         normalization_287  2.4561904761904763e+01
    t         full_original_Gini_288  -5.7271428571428665e+01
    q         OBJ       1
    q         parent_nonstrict_scope_230  1
    q         full_original_Gini_288  35
    MARKER    'MARKER'                 'INTORG'
    x_30_0    OBJ       0.012
    x_30_0    product_lb_0  -2.4708547000141974e-02
    x_30_0    product_ub_1  -4.0713454827493223e-02
    x_30_0    onehot_30_18  1
    x_30_0    parent_nonstrict_scope_230  0.024
    x_30_0    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_0    product_lb_0  1
    w_30_0    product_ub_1  1
    w_30_0    normalized_mass_30_19  1
    w_30_0    full_original_Gini_288  -2.4561904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_1    OBJ       6.0000000000000019e-03
    x_30_1    product_lb_2  -2.4708547000141974e-02
    x_30_1    product_ub_3  -4.0713454827493223e-02
    x_30_1    onehot_30_18  1
    x_30_1    stock_lb_228  1
    x_30_1    stock_ub_229  1
    x_30_1    parent_nonstrict_scope_230  1.8000000000000002e-02
    x_30_1    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_1    product_lb_2  1
    w_30_1    product_ub_3  1
    w_30_1    normalized_mass_30_19  1
    w_30_1    normalized_ratio_30_20  -0.25
    w_30_1    full_original_Gini_288  -1.7811904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_2    product_lb_4  -2.4708547000141974e-02
    x_30_2    product_ub_5  -4.0713454827493223e-02
    x_30_2    onehot_30_18  1
    x_30_2    stock_lb_228  2
    x_30_2    stock_ub_229  2
    x_30_2    parent_nonstrict_scope_230  0.012
    x_30_2    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_2    product_lb_4  1
    w_30_2    product_ub_5  1
    w_30_2    normalized_mass_30_19  1
    w_30_2    normalized_ratio_30_20  -0.5
    w_30_2    full_original_Gini_288  -1.1461904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_3    OBJ       -0.006
    x_30_3    product_lb_6  -2.4708547000141974e-02
    x_30_3    product_ub_7  -4.0713454827493223e-02
    x_30_3    onehot_30_18  1
    x_30_3    stock_lb_228  3
    x_30_3    stock_ub_229  3
    x_30_3    parent_nonstrict_scope_230  0.006
    x_30_3    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_3    product_lb_6  1
    w_30_3    product_ub_7  1
    w_30_3    normalized_mass_30_19  1
    w_30_3    normalized_ratio_30_20  -0.75
    w_30_3    full_original_Gini_288  -5.7833333333333323e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_4    OBJ       -0.012
    x_30_4    product_lb_8  -2.4708547000141974e-02
    x_30_4    product_ub_9  -4.0713454827493223e-02
    x_30_4    onehot_30_18  1
    x_30_4    stock_lb_228  4
    x_30_4    stock_ub_229  4
    x_30_4    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_4    product_lb_8  1
    w_30_4    product_ub_9  1
    w_30_4    normalized_mass_30_19  1
    w_30_4    normalized_ratio_30_20  -1
    w_30_4    full_original_Gini_288  -2.8380952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_5    OBJ       -0.006
    x_30_5    product_lb_10  -2.4708547000141974e-02
    x_30_5    product_ub_11  -4.0713454827493223e-02
    x_30_5    onehot_30_18  1
    x_30_5    stock_lb_228  5
    x_30_5    stock_ub_229  5
    x_30_5    parent_nonstrict_scope_230  0.006
    MARKER    'MARKER'                 'INTEND'
    w_30_5    product_lb_10  1
    w_30_5    product_ub_11  1
    w_30_5    normalized_mass_30_19  1
    w_30_5    normalized_ratio_30_20  -1.25
    w_30_5    full_original_Gini_288  -9.1880952380952383e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_6    product_lb_12  -2.4708547000141974e-02
    x_30_6    product_ub_13  -4.0713454827493223e-02
    x_30_6    onehot_30_18  1
    x_30_6    stock_lb_228  6
    x_30_6    stock_ub_229  6
    x_30_6    parent_nonstrict_scope_230  0.012
    x_30_6    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_6    product_lb_12  1
    w_30_6    product_ub_13  1
    w_30_6    normalized_mass_30_19  1
    w_30_6    normalized_ratio_30_20  -1.5
    w_30_6    full_original_Gini_288  -1.5938095238095235e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_7    OBJ       6.0000000000000019e-03
    x_30_7    product_lb_14  -2.4708547000141974e-02
    x_30_7    product_ub_15  -4.0713454827493223e-02
    x_30_7    onehot_30_18  1
    x_30_7    stock_lb_228  7
    x_30_7    stock_ub_229  7
    x_30_7    parent_nonstrict_scope_230  1.8000000000000002e-02
    x_30_7    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_7    product_lb_14  1
    w_30_7    product_ub_15  1
    w_30_7    normalized_mass_30_19  1
    w_30_7    normalized_ratio_30_20  -1.75
    w_30_7    full_original_Gini_288  -2.2688095238095237e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_8    OBJ       0.012
    x_30_8    product_lb_16  -2.4708547000141974e-02
    x_30_8    product_ub_17  -4.0713454827493223e-02
    x_30_8    onehot_30_18  1
    x_30_8    stock_lb_228  8
    x_30_8    stock_ub_229  8
    x_30_8    parent_nonstrict_scope_230  0.024
    x_30_8    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_8    product_lb_16  1
    w_30_8    product_ub_17  1
    w_30_8    normalized_mass_30_19  1
    w_30_8    normalized_ratio_30_20  -2
    w_30_8    full_original_Gini_288  -2.9438095238095237e+01
    rho_30    normalized_ratio_30_20  1
    rho_30    block_pair_pos_243  -1
    rho_30    block_pair_neg_244  1
    rho_30    block_pair_pos_245  -1
    rho_30    block_pair_neg_246  1
    rho_30    block_pair_pos_247  -1
    rho_30    block_pair_neg_248  1
    rho_30    block_pair_pos_249  -1
    rho_30    block_pair_neg_250  1
    rho_30    block_pair_pos_251  -1
    rho_30    block_pair_neg_252  1
    rho_30    block_pair_pos_253  -1
    rho_30    block_pair_neg_254  1
    rho_30    block_pair_pos_255  -1
    rho_30    block_pair_neg_256  1
    rho_30    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_35_0    OBJ       0.048
    x_35_0    product_lb_21  -2.4708547000141974e-02
    x_35_0    product_ub_22  -4.0713454827493223e-02
    x_35_0    onehot_35_53  1
    x_35_0    parent_nonstrict_scope_230  0.096
    x_35_0    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_0    product_lb_21  1
    w_35_0    product_ub_22  1
    w_35_0    normalized_mass_35_54  1
    w_35_0    full_original_Gini_288  -2.4561904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_1    OBJ       3.6000000000000004e-02
    x_35_1    product_lb_23  -2.4708547000141974e-02
    x_35_1    product_ub_24  -4.0713454827493223e-02
    x_35_1    onehot_35_53  1
    x_35_1    stock_lb_228  1
    x_35_1    stock_ub_229  1
    x_35_1    parent_nonstrict_scope_230  0.084
    x_35_1    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_1    product_lb_23  1
    w_35_1    product_ub_24  1
    w_35_1    normalized_mass_35_54  1
    w_35_1    normalized_ratio_35_55  -0.125
    w_35_1    full_original_Gini_288  -2.1186904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_2    OBJ       2.4000000000000007e-02
    x_35_2    product_lb_25  -2.4708547000141974e-02
    x_35_2    product_ub_26  -4.0713454827493223e-02
    x_35_2    onehot_35_53  1
    x_35_2    stock_lb_228  2
    x_35_2    stock_ub_229  2
    x_35_2    parent_nonstrict_scope_230  7.2000000000000008e-02
    x_35_2    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_2    product_lb_25  1
    w_35_2    product_ub_26  1
    w_35_2    normalized_mass_35_54  1
    w_35_2    normalized_ratio_35_55  -0.25
    w_35_2    full_original_Gini_288  -1.7811904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_3    OBJ       1.1999999999999997e-02
    x_35_3    product_lb_27  -2.4708547000141974e-02
    x_35_3    product_ub_28  -4.0713454827493223e-02
    x_35_3    onehot_35_53  1
    x_35_3    stock_lb_228  3
    x_35_3    stock_ub_229  3
    x_35_3    parent_nonstrict_scope_230  0.06
    x_35_3    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_3    product_lb_27  1
    w_35_3    product_ub_28  1
    w_35_3    normalized_mass_35_54  1
    w_35_3    normalized_ratio_35_55  -0.375
    w_35_3    full_original_Gini_288  -1.4436904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_4    product_lb_29  -2.4708547000141974e-02
    x_35_4    product_ub_30  -4.0713454827493223e-02
    x_35_4    onehot_35_53  1
    x_35_4    stock_lb_228  4
    x_35_4    stock_ub_229  4
    x_35_4    parent_nonstrict_scope_230  0.048
    x_35_4    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_4    product_lb_29  1
    w_35_4    product_ub_30  1
    w_35_4    normalized_mass_35_54  1
    w_35_4    normalized_ratio_35_55  -0.5
    w_35_4    full_original_Gini_288  -1.1461904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_5    OBJ       -1.1999999999999997e-02
    x_35_5    product_lb_31  -2.4708547000141974e-02
    x_35_5    product_ub_32  -4.0713454827493223e-02
    x_35_5    onehot_35_53  1
    x_35_5    stock_lb_228  5
    x_35_5    stock_ub_229  5
    x_35_5    parent_nonstrict_scope_230  3.6000000000000004e-02
    x_35_5    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_5    product_lb_31  1
    w_35_5    product_ub_32  1
    w_35_5    normalized_mass_35_54  1
    w_35_5    normalized_ratio_35_55  -0.625
    w_35_5    full_original_Gini_288  -8.58690476190476
    MARKER    'MARKER'                 'INTORG'
    x_35_6    OBJ       -0.024
    x_35_6    product_lb_33  -2.4708547000141974e-02
    x_35_6    product_ub_34  -4.0713454827493223e-02
    x_35_6    onehot_35_53  1
    x_35_6    stock_lb_228  6
    x_35_6    stock_ub_229  6
    x_35_6    parent_nonstrict_scope_230  0.024
    x_35_6    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_6    product_lb_33  1
    w_35_6    product_ub_34  1
    w_35_6    normalized_mass_35_54  1
    w_35_6    normalized_ratio_35_55  -0.75
    w_35_6    full_original_Gini_288  -5.7833333333333323e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_7    OBJ       -3.6000000000000004e-02
    x_35_7    product_lb_35  -2.4708547000141974e-02
    x_35_7    product_ub_36  -4.0713454827493223e-02
    x_35_7    onehot_35_53  1
    x_35_7    stock_lb_228  7
    x_35_7    stock_ub_229  7
    x_35_7    parent_nonstrict_scope_230  0.012
    x_35_7    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_7    product_lb_35  1
    w_35_7    product_ub_36  1
    w_35_7    normalized_mass_35_54  1
    w_35_7    normalized_ratio_35_55  -0.875
    w_35_7    full_original_Gini_288  -3.4630952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_8    OBJ       -0.048
    x_35_8    product_lb_37  -2.4708547000141974e-02
    x_35_8    product_ub_38  -4.0713454827493223e-02
    x_35_8    onehot_35_53  1
    x_35_8    stock_lb_228  8
    x_35_8    stock_ub_229  8
    x_35_8    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_8    product_lb_37  1
    w_35_8    product_ub_38  1
    w_35_8    normalized_mass_35_54  1
    w_35_8    normalized_ratio_35_55  -1
    w_35_8    full_original_Gini_288  -2.8380952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_9    OBJ       -3.6000000000000004e-02
    x_35_9    product_lb_39  -2.4708547000141974e-02
    x_35_9    product_ub_40  -4.0713454827493223e-02
    x_35_9    onehot_35_53  1
    x_35_9    stock_lb_228  9
    x_35_9    stock_ub_229  9
    x_35_9    parent_nonstrict_scope_230  0.012
    x_35_9    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_9    product_lb_39  1
    w_35_9    product_ub_40  1
    w_35_9    normalized_mass_35_54  1
    w_35_9    normalized_ratio_35_55  -1.125
    w_35_9    full_original_Gini_288  -5.96309523809524
    MARKER    'MARKER'                 'INTORG'
    x_35_10   OBJ       -0.024
    x_35_10   product_lb_41  -2.4708547000141974e-02
    x_35_10   product_ub_42  -4.0713454827493223e-02
    x_35_10   onehot_35_53  1
    x_35_10   stock_lb_228  10
    x_35_10   stock_ub_229  10
    x_35_10   parent_nonstrict_scope_230  0.024
    x_35_10   unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_10   product_lb_41  1
    w_35_10   product_ub_42  1
    w_35_10   normalized_mass_35_54  1
    w_35_10   normalized_ratio_35_55  -1.25
    w_35_10   full_original_Gini_288  -9.1880952380952383e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_11   OBJ       -1.1999999999999997e-02
    x_35_11   product_lb_43  -2.4708547000141974e-02
    x_35_11   product_ub_44  -4.0713454827493223e-02
    x_35_11   onehot_35_53  1
    x_35_11   stock_lb_228  11
    x_35_11   stock_ub_229  11
    x_35_11   parent_nonstrict_scope_230  3.6000000000000004e-02
    MARKER    'MARKER'                 'INTEND'
    w_35_11   product_lb_43  1
    w_35_11   product_ub_44  1
    w_35_11   normalized_mass_35_54  1
    w_35_11   normalized_ratio_35_55  -1.375
    w_35_11   full_original_Gini_288  -1.2563095238095237e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_12   product_lb_45  -2.4708547000141974e-02
    x_35_12   product_ub_46  -4.0713454827493223e-02
    x_35_12   onehot_35_53  1
    x_35_12   stock_lb_228  12
    x_35_12   stock_ub_229  12
    x_35_12   parent_nonstrict_scope_230  0.048
    x_35_12   unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_12   product_lb_45  1
    w_35_12   product_ub_46  1
    w_35_12   normalized_mass_35_54  1
    w_35_12   normalized_ratio_35_55  -1.5
    w_35_12   full_original_Gini_288  -1.5938095238095235e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_13   OBJ       1.1999999999999997e-02
    x_35_13   product_lb_47  -2.4708547000141974e-02
    x_35_13   product_ub_48  -4.0713454827493223e-02
    x_35_13   onehot_35_53  1
    x_35_13   stock_lb_228  13
    x_35_13   stock_ub_229  13
    x_35_13   parent_nonstrict_scope_230  0.06
    x_35_13   unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_13   product_lb_47  1
    w_35_13   product_ub_48  1
    w_35_13   normalized_mass_35_54  1
    w_35_13   normalized_ratio_35_55  -1.625
    w_35_13   full_original_Gini_288  -1.9313095238095237e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_14   OBJ       2.4000000000000007e-02
    x_35_14   product_lb_49  -2.4708547000141974e-02
    x_35_14   product_ub_50  -4.0713454827493223e-02
    x_35_14   onehot_35_53  1
    x_35_14   stock_lb_228  14
    x_35_14   stock_ub_229  14
    x_35_14   parent_nonstrict_scope_230  7.2000000000000008e-02
    x_35_14   unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_14   product_lb_49  1
    w_35_14   product_ub_50  1
    w_35_14   normalized_mass_35_54  1
    w_35_14   normalized_ratio_35_55  -1.75
    w_35_14   full_original_Gini_288  -2.2688095238095237e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_15   OBJ       3.6000000000000004e-02
    x_35_15   product_lb_51  -2.4708547000141974e-02
    x_35_15   product_ub_52  -4.0713454827493223e-02
    x_35_15   onehot_35_53  1
    x_35_15   stock_lb_228  15
    x_35_15   stock_ub_229  15
    x_35_15   parent_nonstrict_scope_230  0.084
    x_35_15   unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_15   product_lb_51  1
    w_35_15   product_ub_52  1
    w_35_15   normalized_mass_35_54  1
    w_35_15   normalized_ratio_35_55  -1.875
    w_35_15   full_original_Gini_288  -2.6063095238095237e+01
    rho_35    normalized_ratio_35_55  1
    rho_35    block_pair_pos_255  1
    rho_35    block_pair_neg_256  -1
    rho_35    block_pair_pos_275  -1
    rho_35    block_pair_neg_276  1
    rho_35    block_pair_pos_277  -1
    rho_35    block_pair_neg_278  1
    rho_35    block_pair_pos_279  -1
    rho_35    block_pair_neg_280  1
    rho_35    block_pair_pos_281  -1
    rho_35    block_pair_neg_282  1
    rho_35    block_pair_pos_283  -1
    rho_35    block_pair_neg_284  1
    rho_35    block_pair_pos_285  -1
    rho_35    block_pair_neg_286  1
    rho_35    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_56  -2.4708547000141974e-02
    x_31_0    product_ub_57  -4.0713454827493223e-02
    x_31_0    onehot_31_82  1
    x_31_0    parent_nonstrict_scope_230  0.0735
    x_31_0    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_56  1
    w_31_0    product_ub_57  1
    w_31_0    normalized_mass_31_83  1
    w_31_0    full_original_Gini_288  -2.4561904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_58  -2.4708547000141974e-02
    x_31_1    product_ub_59  -4.0713454827493223e-02
    x_31_1    onehot_31_82  1
    x_31_1    stock_lb_228  1
    x_31_1    stock_ub_229  1
    x_31_1    parent_nonstrict_scope_230  0.063
    x_31_1    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_58  1
    w_31_1    product_ub_59  1
    w_31_1    normalized_mass_31_83  1
    w_31_1    normalized_ratio_31_84  -1.4285714285714285e-01
    w_31_1    full_original_Gini_288  -2.0704761904761909e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_60  -2.4708547000141974e-02
    x_31_2    product_ub_61  -4.0713454827493223e-02
    x_31_2    onehot_31_82  1
    x_31_2    stock_lb_228  2
    x_31_2    stock_ub_229  2
    x_31_2    parent_nonstrict_scope_230  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_60  1
    w_31_2    product_ub_61  1
    w_31_2    normalized_mass_31_83  1
    w_31_2    normalized_ratio_31_84  -2.8571428571428570e-01
    w_31_2    full_original_Gini_288  -1.6847619047619045e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_62  -2.4708547000141974e-02
    x_31_3    product_ub_63  -4.0713454827493223e-02
    x_31_3    onehot_31_82  1
    x_31_3    stock_lb_228  3
    x_31_3    stock_ub_229  3
    x_31_3    parent_nonstrict_scope_230  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_62  1
    w_31_3    product_ub_63  1
    w_31_3    normalized_mass_31_83  1
    w_31_3    normalized_ratio_31_84  -4.2857142857142855e-01
    w_31_3    full_original_Gini_288  -1.3104761904761903e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_64  -2.4708547000141974e-02
    x_31_4    product_ub_65  -4.0713454827493223e-02
    x_31_4    onehot_31_82  1
    x_31_4    stock_lb_228  4
    x_31_4    stock_ub_229  4
    x_31_4    parent_nonstrict_scope_230  0.0315
    x_31_4    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_64  1
    w_31_4    product_ub_65  1
    w_31_4    normalized_mass_31_83  1
    w_31_4    normalized_ratio_31_84  -5.7142857142857140e-01
    w_31_4    full_original_Gini_288  -9.8190476190476232e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_66  -2.4708547000141974e-02
    x_31_5    product_ub_67  -4.0713454827493223e-02
    x_31_5    onehot_31_82  1
    x_31_5    stock_lb_228  5
    x_31_5    stock_ub_229  5
    x_31_5    parent_nonstrict_scope_230  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_66  1
    w_31_5    product_ub_67  1
    w_31_5    normalized_mass_31_83  1
    w_31_5    normalized_ratio_31_84  -7.1428571428571419e-01
    w_31_5    full_original_Gini_288  -6.5333333333333341e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_68  -2.4708547000141974e-02
    x_31_6    product_ub_69  -4.0713454827493223e-02
    x_31_6    onehot_31_82  1
    x_31_6    stock_lb_228  6
    x_31_6    stock_ub_229  6
    x_31_6    parent_nonstrict_scope_230  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_68  1
    w_31_6    product_ub_69  1
    w_31_6    normalized_mass_31_83  1
    w_31_6    normalized_ratio_31_84  -8.5714285714285710e-01
    w_31_6    full_original_Gini_288  -3.6952380952380945e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_70  -2.4708547000141974e-02
    x_31_7    product_ub_71  -4.0713454827493223e-02
    x_31_7    onehot_31_82  1
    x_31_7    stock_lb_228  7
    x_31_7    stock_ub_229  7
    x_31_7    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_70  1
    w_31_7    product_ub_71  1
    w_31_7    normalized_mass_31_83  1
    w_31_7    normalized_ratio_31_84  -1
    w_31_7    full_original_Gini_288  -2.8380952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_72  -2.4708547000141974e-02
    x_31_8    product_ub_73  -4.0713454827493223e-02
    x_31_8    onehot_31_82  1
    x_31_8    stock_lb_228  8
    x_31_8    stock_ub_229  8
    x_31_8    parent_nonstrict_scope_230  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_72  1
    w_31_8    product_ub_73  1
    w_31_8    normalized_mass_31_83  1
    w_31_8    normalized_ratio_31_84  -1.1428571428571428e+00
    w_31_8    full_original_Gini_288  -6.4095238095238081e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_74  -2.4708547000141974e-02
    x_31_9    product_ub_75  -4.0713454827493223e-02
    x_31_9    onehot_31_82  1
    x_31_9    stock_lb_228  9
    x_31_9    stock_ub_229  9
    x_31_9    parent_nonstrict_scope_230  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_74  1
    w_31_9    product_ub_75  1
    w_31_9    normalized_mass_31_83  1
    w_31_9    normalized_ratio_31_84  -1.2857142857142856e+00
    w_31_9    full_original_Gini_288  -1.0152380952380950e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_76  -2.4708547000141974e-02
    x_31_10   product_ub_77  -4.0713454827493223e-02
    x_31_10   onehot_31_82  1
    x_31_10   stock_lb_228  10
    x_31_10   stock_ub_229  10
    x_31_10   parent_nonstrict_scope_230  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_76  1
    w_31_10   product_ub_77  1
    w_31_10   normalized_mass_31_83  1
    w_31_10   normalized_ratio_31_84  -1.4285714285714284e+00
    w_31_10   full_original_Gini_288  -1.4009523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_78  -2.4708547000141974e-02
    x_31_11   product_ub_79  -4.0713454827493223e-02
    x_31_11   onehot_31_82  1
    x_31_11   stock_lb_228  11
    x_31_11   stock_ub_229  11
    x_31_11   parent_nonstrict_scope_230  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_78  1
    w_31_11   product_ub_79  1
    w_31_11   normalized_mass_31_83  1
    w_31_11   normalized_ratio_31_84  -1.5714285714285714e+00
    w_31_11   full_original_Gini_288  -1.7866666666666660e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_80  -2.4708547000141974e-02
    x_31_12   product_ub_81  -4.0713454827493223e-02
    x_31_12   onehot_31_82  1
    x_31_12   stock_lb_228  12
    x_31_12   stock_ub_229  12
    x_31_12   parent_nonstrict_scope_230  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_80  1
    w_31_12   product_ub_81  1
    w_31_12   normalized_mass_31_83  1
    w_31_12   normalized_ratio_31_84  -1.7142857142857142e+00
    w_31_12   full_original_Gini_288  -2.1723809523809521e+01
    rho_31    normalized_ratio_31_84  1
    rho_31    block_pair_pos_251  1
    rho_31    block_pair_neg_252  -1
    rho_31    block_pair_pos_257  -1
    rho_31    block_pair_neg_258  1
    rho_31    block_pair_pos_259  -1
    rho_31    block_pair_neg_260  1
    rho_31    block_pair_pos_261  -1
    rho_31    block_pair_neg_262  1
    rho_31    block_pair_pos_263  -1
    rho_31    block_pair_neg_264  1
    rho_31    block_pair_pos_265  -1
    rho_31    block_pair_neg_266  1
    rho_31    block_pair_pos_283  1
    rho_31    block_pair_neg_284  -1
    rho_31    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_85  -2.4708547000141974e-02
    x_32_0    product_ub_86  -4.0713454827493223e-02
    x_32_0    onehot_32_111  1
    x_32_0    parent_nonstrict_scope_230  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_85  1
    w_32_0    product_ub_86  1
    w_32_0    normalized_mass_32_112  1
    w_32_0    full_original_Gini_288  -2.4561904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_87  -2.4708547000141974e-02
    x_32_1    product_ub_88  -4.0713454827493223e-02
    x_32_1    onehot_32_111  1
    x_32_1    stock_lb_228  1
    x_32_1    stock_ub_229  1
    x_32_1    parent_nonstrict_scope_230  0.03
    x_32_1    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_87  1
    w_32_1    product_ub_88  1
    w_32_1    normalized_mass_32_112  1
    w_32_1    normalized_ratio_32_113  -0.2
    w_32_1    full_original_Gini_288  -1.9161904761904768e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_89  -2.4708547000141974e-02
    x_32_2    product_ub_90  -4.0713454827493223e-02
    x_32_2    onehot_32_111  1
    x_32_2    stock_lb_228  2
    x_32_2    stock_ub_229  2
    x_32_2    parent_nonstrict_scope_230  0.0225
    x_32_2    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_89  1
    w_32_2    product_ub_90  1
    w_32_2    normalized_mass_32_112  1
    w_32_2    normalized_ratio_32_113  -0.4
    w_32_2    full_original_Gini_288  -1.3761904761904759e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_91  -2.4708547000141974e-02
    x_32_3    product_ub_92  -4.0713454827493223e-02
    x_32_3    onehot_32_111  1
    x_32_3    stock_lb_228  3
    x_32_3    stock_ub_229  3
    x_32_3    parent_nonstrict_scope_230  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_91  1
    w_32_3    product_ub_92  1
    w_32_3    normalized_mass_32_112  1
    w_32_3    normalized_ratio_32_113  -6.0000000000000009e-01
    w_32_3    full_original_Gini_288  -9.1619047619047613e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_93  -2.4708547000141974e-02
    x_32_4    product_ub_94  -4.0713454827493223e-02
    x_32_4    onehot_32_111  1
    x_32_4    stock_lb_228  4
    x_32_4    stock_ub_229  4
    x_32_4    parent_nonstrict_scope_230  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_93  1
    w_32_4    product_ub_94  1
    w_32_4    normalized_mass_32_112  1
    w_32_4    normalized_ratio_32_113  -0.8
    w_32_4    full_original_Gini_288  -4.7333333333333343e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_95  -2.4708547000141974e-02
    x_32_5    product_ub_96  -4.0713454827493223e-02
    x_32_5    onehot_32_111  1
    x_32_5    stock_lb_228  5
    x_32_5    stock_ub_229  5
    x_32_5    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_95  1
    w_32_5    product_ub_96  1
    w_32_5    normalized_mass_32_112  1
    w_32_5    normalized_ratio_32_113  -1
    w_32_5    full_original_Gini_288  -2.8380952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_97  -2.4708547000141974e-02
    x_32_6    product_ub_98  -4.0713454827493223e-02
    x_32_6    onehot_32_111  1
    x_32_6    stock_lb_228  6
    x_32_6    stock_ub_229  6
    x_32_6    parent_nonstrict_scope_230  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_97  1
    w_32_6    product_ub_98  1
    w_32_6    normalized_mass_32_112  1
    w_32_6    normalized_ratio_32_113  -1.2000000000000002e+00
    w_32_6    full_original_Gini_288  -7.8380952380952440e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_99  -2.4708547000141974e-02
    x_32_7    product_ub_100  -4.0713454827493223e-02
    x_32_7    onehot_32_111  1
    x_32_7    stock_lb_228  7
    x_32_7    stock_ub_229  7
    x_32_7    parent_nonstrict_scope_230  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_99  1
    w_32_7    product_ub_100  1
    w_32_7    normalized_mass_32_112  1
    w_32_7    normalized_ratio_32_113  -1.4000000000000001e+00
    w_32_7    full_original_Gini_288  -1.3238095238095244e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_101  -2.4708547000141974e-02
    x_32_8    product_ub_102  -4.0713454827493223e-02
    x_32_8    onehot_32_111  1
    x_32_8    stock_lb_228  8
    x_32_8    stock_ub_229  8
    x_32_8    parent_nonstrict_scope_230  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_101  1
    w_32_8    product_ub_102  1
    w_32_8    normalized_mass_32_112  1
    w_32_8    normalized_ratio_32_113  -1.6
    w_32_8    full_original_Gini_288  -1.8638095238095239e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_103  -2.4708547000141974e-02
    x_32_9    product_ub_104  -4.0713454827493223e-02
    x_32_9    onehot_32_111  1
    x_32_9    stock_lb_228  9
    x_32_9    stock_ub_229  9
    x_32_9    parent_nonstrict_scope_230  0.03
    x_32_9    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_103  1
    w_32_9    product_ub_104  1
    w_32_9    normalized_mass_32_112  1
    w_32_9    normalized_ratio_32_113  -1.8
    w_32_9    full_original_Gini_288  -2.4038095238095242e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_105  -2.4708547000141974e-02
    x_32_10   product_ub_106  -4.0713454827493223e-02
    x_32_10   onehot_32_111  1
    x_32_10   stock_lb_228  10
    x_32_10   stock_ub_229  10
    x_32_10   parent_nonstrict_scope_230  0.0375
    x_32_10   unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_105  1
    w_32_10   product_ub_106  1
    w_32_10   normalized_mass_32_112  1
    w_32_10   normalized_ratio_32_113  -2
    w_32_10   full_original_Gini_288  -2.9438095238095237e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_107  -2.4708547000141974e-02
    x_32_11   product_ub_108  -4.0713454827493223e-02
    x_32_11   onehot_32_111  1
    x_32_11   stock_lb_228  11
    x_32_11   stock_ub_229  11
    x_32_11   parent_nonstrict_scope_230  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_107  1
    w_32_11   product_ub_108  1
    w_32_11   normalized_mass_32_112  1
    w_32_11   normalized_ratio_32_113  -2.2
    w_32_11   full_original_Gini_288  -3.4838095238095228e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_109  -2.4708547000141974e-02
    x_32_12   product_ub_110  -4.0713454827493223e-02
    x_32_12   onehot_32_111  1
    x_32_12   stock_lb_228  12
    x_32_12   stock_ub_229  12
    x_32_12   parent_nonstrict_scope_230  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_109  1
    w_32_12   product_ub_110  1
    w_32_12   normalized_mass_32_112  1
    w_32_12   normalized_ratio_32_113  -2.4000000000000004e+00
    w_32_12   full_original_Gini_288  -4.0238095238095234e+01
    rho_32    normalized_ratio_32_113  1
    rho_32    block_pair_pos_253  1
    rho_32    block_pair_neg_254  -1
    rho_32    block_pair_pos_265  1
    rho_32    block_pair_neg_266  -1
    rho_32    block_pair_pos_267  -1
    rho_32    block_pair_neg_268  1
    rho_32    block_pair_pos_269  -1
    rho_32    block_pair_neg_270  1
    rho_32    block_pair_pos_271  -1
    rho_32    block_pair_neg_272  1
    rho_32    block_pair_pos_273  -1
    rho_32    block_pair_neg_274  1
    rho_32    block_pair_pos_285  1
    rho_32    block_pair_neg_286  -1
    rho_32    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       0.012
    x_19_0    product_lb_114  -2.4708547000141974e-02
    x_19_0    product_ub_115  -4.0713454827493223e-02
    x_19_0    onehot_19_132  1
    x_19_0    parent_nonstrict_scope_230  0.024
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_114  1
    w_19_0    product_ub_115  1
    w_19_0    normalized_mass_19_133  1
    w_19_0    full_original_Gini_288  -2.4561904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.0000000000000019e-03
    x_19_1    product_lb_116  -2.4708547000141974e-02
    x_19_1    product_ub_117  -4.0713454827493223e-02
    x_19_1    onehot_19_132  1
    x_19_1    stock_lb_228  1
    x_19_1    stock_ub_229  1
    x_19_1    parent_nonstrict_scope_230  1.8000000000000002e-02
    x_19_1    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_116  1
    w_19_1    product_ub_117  1
    w_19_1    normalized_mass_19_133  1
    w_19_1    normalized_ratio_19_134  -0.25
    w_19_1    full_original_Gini_288  -1.7811904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    product_lb_118  -2.4708547000141974e-02
    x_19_2    product_ub_119  -4.0713454827493223e-02
    x_19_2    onehot_19_132  1
    x_19_2    stock_lb_228  2
    x_19_2    stock_ub_229  2
    x_19_2    parent_nonstrict_scope_230  0.012
    x_19_2    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_118  1
    w_19_2    product_ub_119  1
    w_19_2    normalized_mass_19_133  1
    w_19_2    normalized_ratio_19_134  -0.5
    w_19_2    full_original_Gini_288  -1.1461904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.006
    x_19_3    product_lb_120  -2.4708547000141974e-02
    x_19_3    product_ub_121  -4.0713454827493223e-02
    x_19_3    onehot_19_132  1
    x_19_3    stock_lb_228  3
    x_19_3    stock_ub_229  3
    x_19_3    parent_nonstrict_scope_230  0.006
    x_19_3    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_120  1
    w_19_3    product_ub_121  1
    w_19_3    normalized_mass_19_133  1
    w_19_3    normalized_ratio_19_134  -0.75
    w_19_3    full_original_Gini_288  -5.7833333333333323e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -0.012
    x_19_4    product_lb_122  -2.4708547000141974e-02
    x_19_4    product_ub_123  -4.0713454827493223e-02
    x_19_4    onehot_19_132  1
    x_19_4    stock_lb_228  4
    x_19_4    stock_ub_229  4
    x_19_4    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_122  1
    w_19_4    product_ub_123  1
    w_19_4    normalized_mass_19_133  1
    w_19_4    normalized_ratio_19_134  -1
    w_19_4    full_original_Gini_288  -2.8380952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -0.006
    x_19_5    product_lb_124  -2.4708547000141974e-02
    x_19_5    product_ub_125  -4.0713454827493223e-02
    x_19_5    onehot_19_132  1
    x_19_5    stock_lb_228  5
    x_19_5    stock_ub_229  5
    x_19_5    parent_nonstrict_scope_230  0.006
    x_19_5    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_124  1
    w_19_5    product_ub_125  1
    w_19_5    normalized_mass_19_133  1
    w_19_5    normalized_ratio_19_134  -1.25
    w_19_5    full_original_Gini_288  -9.1880952380952383e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_6    product_lb_126  -2.4708547000141974e-02
    x_19_6    product_ub_127  -4.0713454827493223e-02
    x_19_6    onehot_19_132  1
    x_19_6    stock_lb_228  6
    x_19_6    stock_ub_229  6
    x_19_6    parent_nonstrict_scope_230  0.012
    x_19_6    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_126  1
    w_19_6    product_ub_127  1
    w_19_6    normalized_mass_19_133  1
    w_19_6    normalized_ratio_19_134  -1.5
    w_19_6    full_original_Gini_288  -1.5938095238095235e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       6.0000000000000019e-03
    x_19_7    product_lb_128  -2.4708547000141974e-02
    x_19_7    product_ub_129  -4.0713454827493223e-02
    x_19_7    onehot_19_132  1
    x_19_7    stock_lb_228  7
    x_19_7    stock_ub_229  7
    x_19_7    parent_nonstrict_scope_230  1.8000000000000002e-02
    x_19_7    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_128  1
    w_19_7    product_ub_129  1
    w_19_7    normalized_mass_19_133  1
    w_19_7    normalized_ratio_19_134  -1.75
    w_19_7    full_original_Gini_288  -2.2688095238095237e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.012
    x_19_8    product_lb_130  -2.4708547000141974e-02
    x_19_8    product_ub_131  -4.0713454827493223e-02
    x_19_8    onehot_19_132  1
    x_19_8    stock_lb_228  8
    x_19_8    stock_ub_229  8
    x_19_8    parent_nonstrict_scope_230  0.024
    x_19_8    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_130  1
    w_19_8    product_ub_131  1
    w_19_8    normalized_mass_19_133  1
    w_19_8    normalized_ratio_19_134  -2
    w_19_8    full_original_Gini_288  -2.9438095238095237e+01
    rho_19    normalized_ratio_19_134  1
    rho_19    block_pair_pos_233  -1
    rho_19    block_pair_neg_234  1
    rho_19    block_pair_pos_235  -1
    rho_19    block_pair_neg_236  1
    rho_19    block_pair_pos_237  -1
    rho_19    block_pair_neg_238  1
    rho_19    block_pair_pos_247  1
    rho_19    block_pair_neg_248  -1
    rho_19    block_pair_pos_261  1
    rho_19    block_pair_neg_262  -1
    rho_19    block_pair_pos_271  1
    rho_19    block_pair_neg_272  -1
    rho_19    block_pair_pos_279  1
    rho_19    block_pair_neg_280  -1
    rho_19    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_26_0    OBJ       0.012
    x_26_0    product_lb_135  -2.4708547000141974e-02
    x_26_0    product_ub_136  -4.0713454827493223e-02
    x_26_0    onehot_26_153  1
    x_26_0    parent_nonstrict_scope_230  0.024
    MARKER    'MARKER'                 'INTEND'
    w_26_0    product_lb_135  1
    w_26_0    product_ub_136  1
    w_26_0    normalized_mass_26_154  1
    w_26_0    full_original_Gini_288  -2.4561904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_1    OBJ       6.0000000000000019e-03
    x_26_1    product_lb_137  -2.4708547000141974e-02
    x_26_1    product_ub_138  -4.0713454827493223e-02
    x_26_1    onehot_26_153  1
    x_26_1    stock_lb_228  1
    x_26_1    stock_ub_229  1
    x_26_1    parent_nonstrict_scope_230  1.8000000000000002e-02
    x_26_1    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_1    product_lb_137  1
    w_26_1    product_ub_138  1
    w_26_1    normalized_mass_26_154  1
    w_26_1    normalized_ratio_26_155  -0.25
    w_26_1    full_original_Gini_288  -1.7811904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_2    product_lb_139  -2.4708547000141974e-02
    x_26_2    product_ub_140  -4.0713454827493223e-02
    x_26_2    onehot_26_153  1
    x_26_2    stock_lb_228  2
    x_26_2    stock_ub_229  2
    x_26_2    parent_nonstrict_scope_230  0.012
    x_26_2    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_2    product_lb_139  1
    w_26_2    product_ub_140  1
    w_26_2    normalized_mass_26_154  1
    w_26_2    normalized_ratio_26_155  -0.5
    w_26_2    full_original_Gini_288  -1.1461904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_3    OBJ       -0.006
    x_26_3    product_lb_141  -2.4708547000141974e-02
    x_26_3    product_ub_142  -4.0713454827493223e-02
    x_26_3    onehot_26_153  1
    x_26_3    stock_lb_228  3
    x_26_3    stock_ub_229  3
    x_26_3    parent_nonstrict_scope_230  0.006
    x_26_3    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_3    product_lb_141  1
    w_26_3    product_ub_142  1
    w_26_3    normalized_mass_26_154  1
    w_26_3    normalized_ratio_26_155  -0.75
    w_26_3    full_original_Gini_288  -5.7833333333333323e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_4    OBJ       -0.012
    x_26_4    product_lb_143  -2.4708547000141974e-02
    x_26_4    product_ub_144  -4.0713454827493223e-02
    x_26_4    onehot_26_153  1
    x_26_4    stock_lb_228  4
    x_26_4    stock_ub_229  4
    x_26_4    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_4    product_lb_143  1
    w_26_4    product_ub_144  1
    w_26_4    normalized_mass_26_154  1
    w_26_4    normalized_ratio_26_155  -1
    w_26_4    full_original_Gini_288  -2.8380952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_5    OBJ       -0.006
    x_26_5    product_lb_145  -2.4708547000141974e-02
    x_26_5    product_ub_146  -4.0713454827493223e-02
    x_26_5    onehot_26_153  1
    x_26_5    stock_lb_228  5
    x_26_5    stock_ub_229  5
    x_26_5    parent_nonstrict_scope_230  0.006
    x_26_5    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_5    product_lb_145  1
    w_26_5    product_ub_146  1
    w_26_5    normalized_mass_26_154  1
    w_26_5    normalized_ratio_26_155  -1.25
    w_26_5    full_original_Gini_288  -9.1880952380952383e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_6    product_lb_147  -2.4708547000141974e-02
    x_26_6    product_ub_148  -4.0713454827493223e-02
    x_26_6    onehot_26_153  1
    x_26_6    stock_lb_228  6
    x_26_6    stock_ub_229  6
    x_26_6    parent_nonstrict_scope_230  0.012
    x_26_6    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_6    product_lb_147  1
    w_26_6    product_ub_148  1
    w_26_6    normalized_mass_26_154  1
    w_26_6    normalized_ratio_26_155  -1.5
    w_26_6    full_original_Gini_288  -1.5938095238095235e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_7    OBJ       6.0000000000000019e-03
    x_26_7    product_lb_149  -2.4708547000141974e-02
    x_26_7    product_ub_150  -4.0713454827493223e-02
    x_26_7    onehot_26_153  1
    x_26_7    stock_lb_228  7
    x_26_7    stock_ub_229  7
    x_26_7    parent_nonstrict_scope_230  1.8000000000000002e-02
    x_26_7    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_7    product_lb_149  1
    w_26_7    product_ub_150  1
    w_26_7    normalized_mass_26_154  1
    w_26_7    normalized_ratio_26_155  -1.75
    w_26_7    full_original_Gini_288  -2.2688095238095237e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_8    OBJ       0.012
    x_26_8    product_lb_151  -2.4708547000141974e-02
    x_26_8    product_ub_152  -4.0713454827493223e-02
    x_26_8    onehot_26_153  1
    x_26_8    stock_lb_228  8
    x_26_8    stock_ub_229  8
    x_26_8    parent_nonstrict_scope_230  0.024
    x_26_8    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_8    product_lb_151  1
    w_26_8    product_ub_152  1
    w_26_8    normalized_mass_26_154  1
    w_26_8    normalized_ratio_26_155  -2
    w_26_8    full_original_Gini_288  -2.9438095238095237e+01
    rho_26    normalized_ratio_26_155  1
    rho_26    block_pair_pos_237  1
    rho_26    block_pair_neg_238  -1
    rho_26    block_pair_pos_239  -1
    rho_26    block_pair_neg_240  1
    rho_26    block_pair_pos_241  -1
    rho_26    block_pair_neg_242  1
    rho_26    block_pair_pos_249  1
    rho_26    block_pair_neg_250  -1
    rho_26    block_pair_pos_263  1
    rho_26    block_pair_neg_264  -1
    rho_26    block_pair_pos_273  1
    rho_26    block_pair_neg_274  -1
    rho_26    block_pair_pos_281  1
    rho_26    block_pair_neg_282  -1
    rho_26    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_156  -2.4708547000141974e-02
    x_2_0     product_ub_157  -4.0713454827493223e-02
    x_2_0     onehot_2_188  1
    x_2_0     parent_nonstrict_scope_230  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_156  1
    w_2_0     product_ub_157  1
    w_2_0     normalized_mass_2_189  1
    w_2_0     full_original_Gini_288  -2.4561904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_158  -2.4708547000141974e-02
    x_2_1     product_ub_159  -4.0713454827493223e-02
    x_2_1     onehot_2_188  1
    x_2_1     stock_lb_228  1
    x_2_1     stock_ub_229  1
    x_2_1     parent_nonstrict_scope_230  0.063
    x_2_1     unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_158  1
    w_2_1     product_ub_159  1
    w_2_1     normalized_mass_2_189  1
    w_2_1     normalized_ratio_2_190  -1.4285714285714285e-01
    w_2_1     full_original_Gini_288  -2.0704761904761909e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_160  -2.4708547000141974e-02
    x_2_2     product_ub_161  -4.0713454827493223e-02
    x_2_2     onehot_2_188  1
    x_2_2     stock_lb_228  2
    x_2_2     stock_ub_229  2
    x_2_2     parent_nonstrict_scope_230  0.0525
    x_2_2     unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_160  1
    w_2_2     product_ub_161  1
    w_2_2     normalized_mass_2_189  1
    w_2_2     normalized_ratio_2_190  -2.8571428571428570e-01
    w_2_2     full_original_Gini_288  -1.6847619047619045e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_162  -2.4708547000141974e-02
    x_2_3     product_ub_163  -4.0713454827493223e-02
    x_2_3     onehot_2_188  1
    x_2_3     stock_lb_228  3
    x_2_3     stock_ub_229  3
    x_2_3     parent_nonstrict_scope_230  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_162  1
    w_2_3     product_ub_163  1
    w_2_3     normalized_mass_2_189  1
    w_2_3     normalized_ratio_2_190  -4.2857142857142855e-01
    w_2_3     full_original_Gini_288  -1.3104761904761903e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_164  -2.4708547000141974e-02
    x_2_4     product_ub_165  -4.0713454827493223e-02
    x_2_4     onehot_2_188  1
    x_2_4     stock_lb_228  4
    x_2_4     stock_ub_229  4
    x_2_4     parent_nonstrict_scope_230  0.0315
    x_2_4     unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_164  1
    w_2_4     product_ub_165  1
    w_2_4     normalized_mass_2_189  1
    w_2_4     normalized_ratio_2_190  -5.7142857142857140e-01
    w_2_4     full_original_Gini_288  -9.8190476190476232e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_166  -2.4708547000141974e-02
    x_2_5     product_ub_167  -4.0713454827493223e-02
    x_2_5     onehot_2_188  1
    x_2_5     stock_lb_228  5
    x_2_5     stock_ub_229  5
    x_2_5     parent_nonstrict_scope_230  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_166  1
    w_2_5     product_ub_167  1
    w_2_5     normalized_mass_2_189  1
    w_2_5     normalized_ratio_2_190  -7.1428571428571419e-01
    w_2_5     full_original_Gini_288  -6.5333333333333341e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_168  -2.4708547000141974e-02
    x_2_6     product_ub_169  -4.0713454827493223e-02
    x_2_6     onehot_2_188  1
    x_2_6     stock_lb_228  6
    x_2_6     stock_ub_229  6
    x_2_6     parent_nonstrict_scope_230  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_168  1
    w_2_6     product_ub_169  1
    w_2_6     normalized_mass_2_189  1
    w_2_6     normalized_ratio_2_190  -8.5714285714285710e-01
    w_2_6     full_original_Gini_288  -3.6952380952380945e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_170  -2.4708547000141974e-02
    x_2_7     product_ub_171  -4.0713454827493223e-02
    x_2_7     onehot_2_188  1
    x_2_7     stock_lb_228  7
    x_2_7     stock_ub_229  7
    x_2_7     unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_170  1
    w_2_7     product_ub_171  1
    w_2_7     normalized_mass_2_189  1
    w_2_7     normalized_ratio_2_190  -1
    w_2_7     full_original_Gini_288  -2.8380952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_172  -2.4708547000141974e-02
    x_2_8     product_ub_173  -4.0713454827493223e-02
    x_2_8     onehot_2_188  1
    x_2_8     stock_lb_228  8
    x_2_8     stock_ub_229  8
    x_2_8     parent_nonstrict_scope_230  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_172  1
    w_2_8     product_ub_173  1
    w_2_8     normalized_mass_2_189  1
    w_2_8     normalized_ratio_2_190  -1.1428571428571428e+00
    w_2_8     full_original_Gini_288  -6.4095238095238081e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_174  -2.4708547000141974e-02
    x_2_9     product_ub_175  -4.0713454827493223e-02
    x_2_9     onehot_2_188  1
    x_2_9     stock_lb_228  9
    x_2_9     stock_ub_229  9
    x_2_9     parent_nonstrict_scope_230  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_174  1
    w_2_9     product_ub_175  1
    w_2_9     normalized_mass_2_189  1
    w_2_9     normalized_ratio_2_190  -1.2857142857142856e+00
    w_2_9     full_original_Gini_288  -1.0152380952380950e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_176  -2.4708547000141974e-02
    x_2_10    product_ub_177  -4.0713454827493223e-02
    x_2_10    onehot_2_188  1
    x_2_10    stock_lb_228  10
    x_2_10    stock_ub_229  10
    x_2_10    parent_nonstrict_scope_230  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_176  1
    w_2_10    product_ub_177  1
    w_2_10    normalized_mass_2_189  1
    w_2_10    normalized_ratio_2_190  -1.4285714285714284e+00
    w_2_10    full_original_Gini_288  -1.4009523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_178  -2.4708547000141974e-02
    x_2_11    product_ub_179  -4.0713454827493223e-02
    x_2_11    onehot_2_188  1
    x_2_11    stock_lb_228  11
    x_2_11    stock_ub_229  11
    x_2_11    parent_nonstrict_scope_230  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_178  1
    w_2_11    product_ub_179  1
    w_2_11    normalized_mass_2_189  1
    w_2_11    normalized_ratio_2_190  -1.5714285714285714e+00
    w_2_11    full_original_Gini_288  -1.7866666666666660e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_180  -2.4708547000141974e-02
    x_2_12    product_ub_181  -4.0713454827493223e-02
    x_2_12    onehot_2_188  1
    x_2_12    stock_lb_228  12
    x_2_12    stock_ub_229  12
    x_2_12    parent_nonstrict_scope_230  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_180  1
    w_2_12    product_ub_181  1
    w_2_12    normalized_mass_2_189  1
    w_2_12    normalized_ratio_2_190  -1.7142857142857142e+00
    w_2_12    full_original_Gini_288  -2.1723809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_182  -2.4708547000141974e-02
    x_2_13    product_ub_183  -4.0713454827493223e-02
    x_2_13    onehot_2_188  1
    x_2_13    stock_lb_228  13
    x_2_13    stock_ub_229  13
    x_2_13    parent_nonstrict_scope_230  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_182  1
    w_2_13    product_ub_183  1
    w_2_13    normalized_mass_2_189  1
    w_2_13    normalized_ratio_2_190  -1.8571428571428570e+00
    w_2_13    full_original_Gini_288  -2.5580952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_184  -2.4708547000141974e-02
    x_2_14    product_ub_185  -4.0713454827493223e-02
    x_2_14    onehot_2_188  1
    x_2_14    stock_lb_228  14
    x_2_14    stock_ub_229  14
    x_2_14    parent_nonstrict_scope_230  0.0735
    x_2_14    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_184  1
    w_2_14    product_ub_185  1
    w_2_14    normalized_mass_2_189  1
    w_2_14    normalized_ratio_2_190  -2
    w_2_14    full_original_Gini_288  -2.9438095238095237e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_186  -2.4708547000141974e-02
    x_2_15    product_ub_187  -4.0713454827493223e-02
    x_2_15    onehot_2_188  1
    x_2_15    stock_lb_228  15
    x_2_15    stock_ub_229  15
    x_2_15    parent_nonstrict_scope_230  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_186  1
    w_2_15    product_ub_187  1
    w_2_15    normalized_mass_2_189  1
    w_2_15    normalized_ratio_2_190  -2.1428571428571428e+00
    w_2_15    full_original_Gini_288  -3.3295238095238084e+01
    rho_2     normalized_ratio_2_190  1
    rho_2     block_pair_pos_231  -1
    rho_2     block_pair_neg_232  1
    rho_2     block_pair_pos_233  1
    rho_2     block_pair_neg_234  -1
    rho_2     block_pair_pos_239  1
    rho_2     block_pair_neg_240  -1
    rho_2     block_pair_pos_243  1
    rho_2     block_pair_neg_244  -1
    rho_2     block_pair_pos_257  1
    rho_2     block_pair_neg_258  -1
    rho_2     block_pair_pos_267  1
    rho_2     block_pair_neg_268  -1
    rho_2     block_pair_pos_275  1
    rho_2     block_pair_neg_276  -1
    rho_2     normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       0.06075
    x_17_0    product_lb_191  -2.4708547000141974e-02
    x_17_0    product_ub_192  -4.0713454827493223e-02
    x_17_0    onehot_17_225  1
    x_17_0    parent_nonstrict_scope_230  0.1215
    x_17_0    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_191  1
    w_17_0    product_ub_192  1
    w_17_0    normalized_mass_17_226  1
    w_17_0    full_original_Gini_288  -2.4561904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.7249999999999986e-02
    x_17_1    product_lb_193  -2.4708547000141974e-02
    x_17_1    product_ub_194  -4.0713454827493223e-02
    x_17_1    onehot_17_225  1
    x_17_1    stock_lb_228  1
    x_17_1    stock_ub_229  1
    x_17_1    parent_nonstrict_scope_230  1.0799999999999998e-01
    x_17_1    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_193  1
    w_17_1    product_ub_194  1
    w_17_1    normalized_mass_17_226  1
    w_17_1    normalized_ratio_17_227  -1.1111111111111110e-01
    w_17_1    full_original_Gini_288  -2.1561904761904767e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       0.03375
    x_17_2    product_lb_195  -2.4708547000141974e-02
    x_17_2    product_ub_196  -4.0713454827493223e-02
    x_17_2    onehot_17_225  1
    x_17_2    stock_lb_228  2
    x_17_2    stock_ub_229  2
    x_17_2    parent_nonstrict_scope_230  0.0945
    x_17_2    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_195  1
    w_17_2    product_ub_196  1
    w_17_2    normalized_mass_17_226  1
    w_17_2    normalized_ratio_17_227  -2.2222222222222221e-01
    w_17_2    full_original_Gini_288  -1.8561904761904767e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.0250000000000004e-02
    x_17_3    product_lb_197  -2.4708547000141974e-02
    x_17_3    product_ub_198  -4.0713454827493223e-02
    x_17_3    onehot_17_225  1
    x_17_3    stock_lb_228  3
    x_17_3    stock_ub_229  3
    x_17_3    parent_nonstrict_scope_230  0.081
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_197  1
    w_17_3    product_ub_198  1
    w_17_3    normalized_mass_17_226  1
    w_17_3    normalized_ratio_17_227  -3.3333333333333331e-01
    w_17_3    full_original_Gini_288  -1.5561904761904758e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       6.7500000000000060e-03
    x_17_4    product_lb_199  -2.4708547000141974e-02
    x_17_4    product_ub_200  -4.0713454827493223e-02
    x_17_4    onehot_17_225  1
    x_17_4    stock_lb_228  4
    x_17_4    stock_ub_229  4
    x_17_4    parent_nonstrict_scope_230  0.0675
    x_17_4    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_199  1
    w_17_4    product_ub_200  1
    w_17_4    normalized_mass_17_226  1
    w_17_4    normalized_ratio_17_227  -4.4444444444444442e-01
    w_17_4    full_original_Gini_288  -1.2739682539682537e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -6.7500000000000060e-03
    x_17_5    product_lb_201  -2.4708547000141974e-02
    x_17_5    product_ub_202  -4.0713454827493223e-02
    x_17_5    onehot_17_225  1
    x_17_5    stock_lb_228  5
    x_17_5    stock_ub_229  5
    x_17_5    parent_nonstrict_scope_230  5.3999999999999992e-02
    x_17_5    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_201  1
    w_17_5    product_ub_202  1
    w_17_5    normalized_mass_17_226  1
    w_17_5    normalized_ratio_17_227  -5.5555555555555558e-01
    w_17_5    full_original_Gini_288  -1.0184126984126987e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.0249999999999997e-02
    x_17_6    product_lb_203  -2.4708547000141974e-02
    x_17_6    product_ub_204  -4.0713454827493223e-02
    x_17_6    onehot_17_225  1
    x_17_6    stock_lb_228  6
    x_17_6    stock_ub_229  6
    x_17_6    parent_nonstrict_scope_230  0.0405
    x_17_6    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_203  1
    w_17_6    product_ub_204  1
    w_17_6    normalized_mass_17_226  1
    w_17_6    normalized_ratio_17_227  -6.6666666666666663e-01
    w_17_6    full_original_Gini_288  -7.6285714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.3749999999999988e-02
    x_17_7    product_lb_205  -2.4708547000141974e-02
    x_17_7    product_ub_206  -4.0713454827493223e-02
    x_17_7    onehot_17_225  1
    x_17_7    stock_lb_228  7
    x_17_7    stock_ub_229  7
    x_17_7    parent_nonstrict_scope_230  2.7000000000000010e-02
    x_17_7    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_205  1
    w_17_7    product_ub_206  1
    w_17_7    normalized_mass_17_226  1
    w_17_7    normalized_ratio_17_227  -7.7777777777777768e-01
    w_17_7    full_original_Gini_288  -5.2000000000000011e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.7249999999999993e-02
    x_17_8    product_lb_207  -2.4708547000141974e-02
    x_17_8    product_ub_208  -4.0713454827493223e-02
    x_17_8    onehot_17_225  1
    x_17_8    stock_lb_228  8
    x_17_8    stock_ub_229  8
    x_17_8    parent_nonstrict_scope_230  1.3500000000000005e-02
    x_17_8    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_207  1
    w_17_8    product_ub_208  1
    w_17_8    normalized_mass_17_226  1
    w_17_8    normalized_ratio_17_227  -8.8888888888888884e-01
    w_17_8    full_original_Gini_288  -3.3936507936507940e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -0.06075
    x_17_9    product_lb_209  -2.4708547000141974e-02
    x_17_9    product_ub_210  -4.0713454827493223e-02
    x_17_9    onehot_17_225  1
    x_17_9    stock_lb_228  9
    x_17_9    stock_ub_229  9
    x_17_9    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_209  1
    w_17_9    product_ub_210  1
    w_17_9    normalized_mass_17_226  1
    w_17_9    normalized_ratio_17_227  -1
    w_17_9    full_original_Gini_288  -2.8380952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.7249999999999993e-02
    x_17_10   product_lb_211  -2.4708547000141974e-02
    x_17_10   product_ub_212  -4.0713454827493223e-02
    x_17_10   onehot_17_225  1
    x_17_10   stock_lb_228  10
    x_17_10   stock_ub_229  10
    x_17_10   parent_nonstrict_scope_230  1.3500000000000005e-02
    x_17_10   unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_211  1
    w_17_10   product_ub_212  1
    w_17_10   normalized_mass_17_226  1
    w_17_10   normalized_ratio_17_227  -1.1111111111111112e+00
    w_17_10   full_original_Gini_288  -5.6158730158730172e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.3750000000000016e-02
    x_17_11   product_lb_213  -2.4708547000141974e-02
    x_17_11   product_ub_214  -4.0713454827493223e-02
    x_17_11   onehot_17_225  1
    x_17_11   stock_lb_228  11
    x_17_11   stock_ub_229  11
    x_17_11   parent_nonstrict_scope_230  2.6999999999999986e-02
    x_17_11   unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_213  1
    w_17_11   product_ub_214  1
    w_17_11   normalized_mass_17_226  1
    w_17_11   normalized_ratio_17_227  -1.2222222222222221e+00
    w_17_11   full_original_Gini_288  -8.4380952380952383e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.0250000000000011e-02
    x_17_12   product_lb_215  -2.4708547000141974e-02
    x_17_12   product_ub_216  -4.0713454827493223e-02
    x_17_12   onehot_17_225  1
    x_17_12   stock_lb_228  12
    x_17_12   stock_ub_229  12
    x_17_12   parent_nonstrict_scope_230  4.0499999999999987e-02
    x_17_12   unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_215  1
    w_17_12   product_ub_216  1
    w_17_12   normalized_mass_17_226  1
    w_17_12   normalized_ratio_17_227  -1.3333333333333333e+00
    w_17_12   full_original_Gini_288  -1.1438095238095237e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -6.7500000000000060e-03
    x_17_13   product_lb_217  -2.4708547000141974e-02
    x_17_13   product_ub_218  -4.0713454827493223e-02
    x_17_13   onehot_17_225  1
    x_17_13   stock_lb_228  13
    x_17_13   stock_ub_229  13
    x_17_13   parent_nonstrict_scope_230  5.3999999999999992e-02
    x_17_13   unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_217  1
    w_17_13   product_ub_218  1
    w_17_13   normalized_mass_17_226  1
    w_17_13   normalized_ratio_17_227  -1.4444444444444444e+00
    w_17_13   full_original_Gini_288  -1.4438095238095240e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       6.7499999999999782e-03
    x_17_14   product_lb_219  -2.4708547000141974e-02
    x_17_14   product_ub_220  -4.0713454827493223e-02
    x_17_14   onehot_17_225  1
    x_17_14   stock_lb_228  14
    x_17_14   stock_ub_229  14
    x_17_14   parent_nonstrict_scope_230  6.7499999999999977e-02
    x_17_14   unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_219  1
    w_17_14   product_ub_220  1
    w_17_14   normalized_mass_17_226  1
    w_17_14   normalized_ratio_17_227  -1.5555555555555554e+00
    w_17_14   full_original_Gini_288  -1.7438095238095229e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.0249999999999976e-02
    x_17_15   product_lb_221  -2.4708547000141974e-02
    x_17_15   product_ub_222  -4.0713454827493223e-02
    x_17_15   onehot_17_225  1
    x_17_15   stock_lb_228  15
    x_17_15   stock_ub_229  15
    x_17_15   parent_nonstrict_scope_230  8.0999999999999975e-02
    x_17_15   unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_221  1
    w_17_15   product_ub_222  1
    w_17_15   normalized_mass_17_226  1
    w_17_15   normalized_ratio_17_227  -1.6666666666666665e+00
    w_17_15   full_original_Gini_288  -2.0438095238095237e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.3749999999999988e-02
    x_17_16   product_lb_223  -2.4708547000141974e-02
    x_17_16   product_ub_224  -4.0713454827493223e-02
    x_17_16   onehot_17_225  1
    x_17_16   stock_lb_228  16
    x_17_16   stock_ub_229  16
    x_17_16   parent_nonstrict_scope_230  9.4499999999999987e-02
    x_17_16   unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_223  1
    w_17_16   product_ub_224  1
    w_17_16   normalized_mass_17_226  1
    w_17_16   normalized_ratio_17_227  -1.7777777777777777e+00
    w_17_16   full_original_Gini_288  -2.3438095238095244e+01
    rho_17    normalized_ratio_17_227  1
    rho_17    block_pair_pos_231  1
    rho_17    block_pair_neg_232  -1
    rho_17    block_pair_pos_235  1
    rho_17    block_pair_neg_236  -1
    rho_17    block_pair_pos_241  1
    rho_17    block_pair_neg_242  -1
    rho_17    block_pair_pos_245  1
    rho_17    block_pair_neg_246  -1
    rho_17    block_pair_pos_259  1
    rho_17    block_pair_neg_260  -1
    rho_17    block_pair_pos_269  1
    rho_17    block_pair_neg_270  -1
    rho_17    block_pair_pos_277  1
    rho_17    block_pair_neg_278  -1
    rho_17    normalization_287  1
    a_30_35   block_pair_pos_255  1
    a_30_35   block_pair_neg_256  1
    a_30_35   full_original_Gini_288  -1
    a_30_31   block_pair_pos_251  1
    a_30_31   block_pair_neg_252  1
    a_30_31   full_original_Gini_288  -1
    a_30_32   block_pair_pos_253  1
    a_30_32   block_pair_neg_254  1
    a_30_32   full_original_Gini_288  -1
    a_30_19   block_pair_pos_247  1
    a_30_19   block_pair_neg_248  1
    a_30_19   full_original_Gini_288  -1
    a_30_26   block_pair_pos_249  1
    a_30_26   block_pair_neg_250  1
    a_30_26   full_original_Gini_288  -1
    a_30_2    block_pair_pos_243  1
    a_30_2    block_pair_neg_244  1
    a_30_2    full_original_Gini_288  -1
    a_30_17   block_pair_pos_245  1
    a_30_17   block_pair_neg_246  1
    a_30_17   full_original_Gini_288  -1
    a_35_31   block_pair_pos_283  1
    a_35_31   block_pair_neg_284  1
    a_35_31   full_original_Gini_288  -1
    a_35_32   block_pair_pos_285  1
    a_35_32   block_pair_neg_286  1
    a_35_32   full_original_Gini_288  -1
    a_35_19   block_pair_pos_279  1
    a_35_19   block_pair_neg_280  1
    a_35_19   full_original_Gini_288  -1
    a_35_26   block_pair_pos_281  1
    a_35_26   block_pair_neg_282  1
    a_35_26   full_original_Gini_288  -1
    a_35_2    block_pair_pos_275  1
    a_35_2    block_pair_neg_276  1
    a_35_2    full_original_Gini_288  -1
    a_35_17   block_pair_pos_277  1
    a_35_17   block_pair_neg_278  1
    a_35_17   full_original_Gini_288  -1
    a_31_32   block_pair_pos_265  1
    a_31_32   block_pair_neg_266  1
    a_31_32   full_original_Gini_288  -1
    a_31_19   block_pair_pos_261  1
    a_31_19   block_pair_neg_262  1
    a_31_19   full_original_Gini_288  -1
    a_31_26   block_pair_pos_263  1
    a_31_26   block_pair_neg_264  1
    a_31_26   full_original_Gini_288  -1
    a_31_2    block_pair_pos_257  1
    a_31_2    block_pair_neg_258  1
    a_31_2    full_original_Gini_288  -1
    a_31_17   block_pair_pos_259  1
    a_31_17   block_pair_neg_260  1
    a_31_17   full_original_Gini_288  -1
    a_32_19   block_pair_pos_271  1
    a_32_19   block_pair_neg_272  1
    a_32_19   full_original_Gini_288  -1
    a_32_26   block_pair_pos_273  1
    a_32_26   block_pair_neg_274  1
    a_32_26   full_original_Gini_288  -1
    a_32_2    block_pair_pos_267  1
    a_32_2    block_pair_neg_268  1
    a_32_2    full_original_Gini_288  -1
    a_32_17   block_pair_pos_269  1
    a_32_17   block_pair_neg_270  1
    a_32_17   full_original_Gini_288  -1
    a_19_26   block_pair_pos_237  1
    a_19_26   block_pair_neg_238  1
    a_19_26   full_original_Gini_288  -1
    a_19_2    block_pair_pos_233  1
    a_19_2    block_pair_neg_234  1
    a_19_2    full_original_Gini_288  -1
    a_19_17   block_pair_pos_235  1
    a_19_17   block_pair_neg_236  1
    a_19_17   full_original_Gini_288  -1
    a_26_2    block_pair_pos_239  1
    a_26_2    block_pair_neg_240  1
    a_26_2    full_original_Gini_288  -1
    a_26_17   block_pair_pos_241  1
    a_26_17   block_pair_neg_242  1
    a_26_17   full_original_Gini_288  -1
    a_2_17    block_pair_pos_231  1
    a_2_17    block_pair_neg_232  1
    a_2_17    full_original_Gini_288  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_30_0  unique_nonzero_owner_289  1
    service_0_30_0  service_visit_def_824  1
    service_0_30_0  free_load_conservation_825  -5
    service_0_30_0  original_T_including_depot_unload_873  600
    service_0_30_1  unique_nonzero_owner_290  1
    service_0_30_1  service_visit_def_824  1
    service_0_30_1  free_load_conservation_825  -4
    service_0_30_1  original_T_including_depot_unload_873  480
    service_0_30_2  unique_nonzero_owner_291  1
    service_0_30_2  service_visit_def_824  1
    service_0_30_2  free_load_conservation_825  -3
    service_0_30_2  original_T_including_depot_unload_873  360
    service_0_30_3  unique_nonzero_owner_292  1
    service_0_30_3  service_visit_def_824  1
    service_0_30_3  free_load_conservation_825  -2
    service_0_30_3  original_T_including_depot_unload_873  240
    service_0_30_4  unique_nonzero_owner_293  1
    service_0_30_4  service_visit_def_824  1
    service_0_30_4  free_load_conservation_825  -1
    service_0_30_4  original_T_including_depot_unload_873  120
    service_0_30_6  unique_nonzero_owner_294  1
    service_0_30_6  service_visit_def_824  1
    service_0_30_6  free_load_conservation_825  1
    service_0_30_7  unique_nonzero_owner_295  1
    service_0_30_7  service_visit_def_824  1
    service_0_30_7  free_load_conservation_825  2
    service_0_30_8  unique_nonzero_owner_296  1
    service_0_30_8  service_visit_def_824  1
    service_0_30_8  free_load_conservation_825  3
    service_1_30_0  unique_nonzero_owner_289  1
    service_1_30_0  service_visit_def_1197  1
    service_1_30_0  free_load_conservation_1198  -5
    service_1_30_0  original_T_including_depot_unload_1244  600
    service_1_30_1  unique_nonzero_owner_290  1
    service_1_30_1  service_visit_def_1197  1
    service_1_30_1  free_load_conservation_1198  -4
    service_1_30_1  original_T_including_depot_unload_1244  480
    service_1_30_2  unique_nonzero_owner_291  1
    service_1_30_2  service_visit_def_1197  1
    service_1_30_2  free_load_conservation_1198  -3
    service_1_30_2  original_T_including_depot_unload_1244  360
    service_1_30_3  unique_nonzero_owner_292  1
    service_1_30_3  service_visit_def_1197  1
    service_1_30_3  free_load_conservation_1198  -2
    service_1_30_3  original_T_including_depot_unload_1244  240
    service_1_30_4  unique_nonzero_owner_293  1
    service_1_30_4  service_visit_def_1197  1
    service_1_30_4  free_load_conservation_1198  -1
    service_1_30_4  original_T_including_depot_unload_1244  120
    service_1_30_6  unique_nonzero_owner_294  1
    service_1_30_6  service_visit_def_1197  1
    service_1_30_6  free_load_conservation_1198  1
    service_1_30_7  unique_nonzero_owner_295  1
    service_1_30_7  service_visit_def_1197  1
    service_1_30_7  free_load_conservation_1198  2
    service_1_30_8  unique_nonzero_owner_296  1
    service_1_30_8  service_visit_def_1197  1
    service_1_30_8  free_load_conservation_1198  3
    service_2_30_0  unique_nonzero_owner_289  1
    service_2_30_0  service_visit_def_1568  1
    service_2_30_0  free_load_conservation_1569  -5
    service_2_30_0  original_T_including_depot_unload_1615  600
    service_2_30_1  unique_nonzero_owner_290  1
    service_2_30_1  service_visit_def_1568  1
    service_2_30_1  free_load_conservation_1569  -4
    service_2_30_1  original_T_including_depot_unload_1615  480
    service_2_30_2  unique_nonzero_owner_291  1
    service_2_30_2  service_visit_def_1568  1
    service_2_30_2  free_load_conservation_1569  -3
    service_2_30_2  original_T_including_depot_unload_1615  360
    service_2_30_3  unique_nonzero_owner_292  1
    service_2_30_3  service_visit_def_1568  1
    service_2_30_3  free_load_conservation_1569  -2
    service_2_30_3  original_T_including_depot_unload_1615  240
    service_2_30_4  unique_nonzero_owner_293  1
    service_2_30_4  service_visit_def_1568  1
    service_2_30_4  free_load_conservation_1569  -1
    service_2_30_4  original_T_including_depot_unload_1615  120
    service_2_30_6  unique_nonzero_owner_294  1
    service_2_30_6  service_visit_def_1568  1
    service_2_30_6  free_load_conservation_1569  1
    service_2_30_7  unique_nonzero_owner_295  1
    service_2_30_7  service_visit_def_1568  1
    service_2_30_7  free_load_conservation_1569  2
    service_2_30_8  unique_nonzero_owner_296  1
    service_2_30_8  service_visit_def_1568  1
    service_2_30_8  free_load_conservation_1569  3
    service_0_35_0  unique_nonzero_owner_297  1
    service_0_35_0  service_visit_def_830  1
    service_0_35_0  free_load_conservation_831  -11
    service_0_35_0  original_T_including_depot_unload_873  1320
    service_0_35_1  unique_nonzero_owner_298  1
    service_0_35_1  service_visit_def_830  1
    service_0_35_1  free_load_conservation_831  -10
    service_0_35_1  original_T_including_depot_unload_873  1200
    service_0_35_2  unique_nonzero_owner_299  1
    service_0_35_2  service_visit_def_830  1
    service_0_35_2  free_load_conservation_831  -9
    service_0_35_2  original_T_including_depot_unload_873  1080
    service_0_35_3  unique_nonzero_owner_300  1
    service_0_35_3  service_visit_def_830  1
    service_0_35_3  free_load_conservation_831  -8
    service_0_35_3  original_T_including_depot_unload_873  960
    service_0_35_4  unique_nonzero_owner_301  1
    service_0_35_4  service_visit_def_830  1
    service_0_35_4  free_load_conservation_831  -7
    service_0_35_4  original_T_including_depot_unload_873  840
    service_0_35_5  unique_nonzero_owner_302  1
    service_0_35_5  service_visit_def_830  1
    service_0_35_5  free_load_conservation_831  -6
    service_0_35_5  original_T_including_depot_unload_873  720
    service_0_35_6  unique_nonzero_owner_303  1
    service_0_35_6  service_visit_def_830  1
    service_0_35_6  free_load_conservation_831  -5
    service_0_35_6  original_T_including_depot_unload_873  600
    service_0_35_7  unique_nonzero_owner_304  1
    service_0_35_7  service_visit_def_830  1
    service_0_35_7  free_load_conservation_831  -4
    service_0_35_7  original_T_including_depot_unload_873  480
    service_0_35_8  unique_nonzero_owner_305  1
    service_0_35_8  service_visit_def_830  1
    service_0_35_8  free_load_conservation_831  -3
    service_0_35_8  original_T_including_depot_unload_873  360
    service_0_35_9  unique_nonzero_owner_306  1
    service_0_35_9  service_visit_def_830  1
    service_0_35_9  free_load_conservation_831  -2
    service_0_35_9  original_T_including_depot_unload_873  240
    service_0_35_10  unique_nonzero_owner_307  1
    service_0_35_10  service_visit_def_830  1
    service_0_35_10  free_load_conservation_831  -1
    service_0_35_10  original_T_including_depot_unload_873  120
    service_0_35_12  unique_nonzero_owner_308  1
    service_0_35_12  service_visit_def_830  1
    service_0_35_12  free_load_conservation_831  1
    service_0_35_13  unique_nonzero_owner_309  1
    service_0_35_13  service_visit_def_830  1
    service_0_35_13  free_load_conservation_831  2
    service_0_35_14  unique_nonzero_owner_310  1
    service_0_35_14  service_visit_def_830  1
    service_0_35_14  free_load_conservation_831  3
    service_0_35_15  unique_nonzero_owner_311  1
    service_0_35_15  service_visit_def_830  1
    service_0_35_15  free_load_conservation_831  4
    service_1_35_0  unique_nonzero_owner_297  1
    service_1_35_0  service_visit_def_1203  1
    service_1_35_0  free_load_conservation_1204  -11
    service_1_35_0  original_T_including_depot_unload_1244  1320
    service_1_35_1  unique_nonzero_owner_298  1
    service_1_35_1  service_visit_def_1203  1
    service_1_35_1  free_load_conservation_1204  -10
    service_1_35_1  original_T_including_depot_unload_1244  1200
    service_1_35_2  unique_nonzero_owner_299  1
    service_1_35_2  service_visit_def_1203  1
    service_1_35_2  free_load_conservation_1204  -9
    service_1_35_2  original_T_including_depot_unload_1244  1080
    service_1_35_3  unique_nonzero_owner_300  1
    service_1_35_3  service_visit_def_1203  1
    service_1_35_3  free_load_conservation_1204  -8
    service_1_35_3  original_T_including_depot_unload_1244  960
    service_1_35_4  unique_nonzero_owner_301  1
    service_1_35_4  service_visit_def_1203  1
    service_1_35_4  free_load_conservation_1204  -7
    service_1_35_4  original_T_including_depot_unload_1244  840
    service_1_35_5  unique_nonzero_owner_302  1
    service_1_35_5  service_visit_def_1203  1
    service_1_35_5  free_load_conservation_1204  -6
    service_1_35_5  original_T_including_depot_unload_1244  720
    service_1_35_6  unique_nonzero_owner_303  1
    service_1_35_6  service_visit_def_1203  1
    service_1_35_6  free_load_conservation_1204  -5
    service_1_35_6  original_T_including_depot_unload_1244  600
    service_1_35_7  unique_nonzero_owner_304  1
    service_1_35_7  service_visit_def_1203  1
    service_1_35_7  free_load_conservation_1204  -4
    service_1_35_7  original_T_including_depot_unload_1244  480
    service_1_35_8  unique_nonzero_owner_305  1
    service_1_35_8  service_visit_def_1203  1
    service_1_35_8  free_load_conservation_1204  -3
    service_1_35_8  original_T_including_depot_unload_1244  360
    service_1_35_9  unique_nonzero_owner_306  1
    service_1_35_9  service_visit_def_1203  1
    service_1_35_9  free_load_conservation_1204  -2
    service_1_35_9  original_T_including_depot_unload_1244  240
    service_1_35_10  unique_nonzero_owner_307  1
    service_1_35_10  service_visit_def_1203  1
    service_1_35_10  free_load_conservation_1204  -1
    service_1_35_10  original_T_including_depot_unload_1244  120
    service_1_35_12  unique_nonzero_owner_308  1
    service_1_35_12  service_visit_def_1203  1
    service_1_35_12  free_load_conservation_1204  1
    service_1_35_13  unique_nonzero_owner_309  1
    service_1_35_13  service_visit_def_1203  1
    service_1_35_13  free_load_conservation_1204  2
    service_1_35_14  unique_nonzero_owner_310  1
    service_1_35_14  service_visit_def_1203  1
    service_1_35_14  free_load_conservation_1204  3
    service_1_35_15  unique_nonzero_owner_311  1
    service_1_35_15  service_visit_def_1203  1
    service_1_35_15  free_load_conservation_1204  4
    service_2_35_0  unique_nonzero_owner_297  1
    service_2_35_0  service_visit_def_1574  1
    service_2_35_0  free_load_conservation_1575  -11
    service_2_35_0  original_T_including_depot_unload_1615  1320
    service_2_35_1  unique_nonzero_owner_298  1
    service_2_35_1  service_visit_def_1574  1
    service_2_35_1  free_load_conservation_1575  -10
    service_2_35_1  original_T_including_depot_unload_1615  1200
    service_2_35_2  unique_nonzero_owner_299  1
    service_2_35_2  service_visit_def_1574  1
    service_2_35_2  free_load_conservation_1575  -9
    service_2_35_2  original_T_including_depot_unload_1615  1080
    service_2_35_3  unique_nonzero_owner_300  1
    service_2_35_3  service_visit_def_1574  1
    service_2_35_3  free_load_conservation_1575  -8
    service_2_35_3  original_T_including_depot_unload_1615  960
    service_2_35_4  unique_nonzero_owner_301  1
    service_2_35_4  service_visit_def_1574  1
    service_2_35_4  free_load_conservation_1575  -7
    service_2_35_4  original_T_including_depot_unload_1615  840
    service_2_35_5  unique_nonzero_owner_302  1
    service_2_35_5  service_visit_def_1574  1
    service_2_35_5  free_load_conservation_1575  -6
    service_2_35_5  original_T_including_depot_unload_1615  720
    service_2_35_6  unique_nonzero_owner_303  1
    service_2_35_6  service_visit_def_1574  1
    service_2_35_6  free_load_conservation_1575  -5
    service_2_35_6  original_T_including_depot_unload_1615  600
    service_2_35_7  unique_nonzero_owner_304  1
    service_2_35_7  service_visit_def_1574  1
    service_2_35_7  free_load_conservation_1575  -4
    service_2_35_7  original_T_including_depot_unload_1615  480
    service_2_35_8  unique_nonzero_owner_305  1
    service_2_35_8  service_visit_def_1574  1
    service_2_35_8  free_load_conservation_1575  -3
    service_2_35_8  original_T_including_depot_unload_1615  360
    service_2_35_9  unique_nonzero_owner_306  1
    service_2_35_9  service_visit_def_1574  1
    service_2_35_9  free_load_conservation_1575  -2
    service_2_35_9  original_T_including_depot_unload_1615  240
    service_2_35_10  unique_nonzero_owner_307  1
    service_2_35_10  service_visit_def_1574  1
    service_2_35_10  free_load_conservation_1575  -1
    service_2_35_10  original_T_including_depot_unload_1615  120
    service_2_35_12  unique_nonzero_owner_308  1
    service_2_35_12  service_visit_def_1574  1
    service_2_35_12  free_load_conservation_1575  1
    service_2_35_13  unique_nonzero_owner_309  1
    service_2_35_13  service_visit_def_1574  1
    service_2_35_13  free_load_conservation_1575  2
    service_2_35_14  unique_nonzero_owner_310  1
    service_2_35_14  service_visit_def_1574  1
    service_2_35_14  free_load_conservation_1575  3
    service_2_35_15  unique_nonzero_owner_311  1
    service_2_35_15  service_visit_def_1574  1
    service_2_35_15  free_load_conservation_1575  4
    service_0_31_0  unique_nonzero_owner_312  1
    service_0_31_0  service_visit_def_836  1
    service_0_31_0  free_load_conservation_837  -2
    service_0_31_0  original_T_including_depot_unload_873  240
    service_0_31_1  unique_nonzero_owner_313  1
    service_0_31_1  service_visit_def_836  1
    service_0_31_1  free_load_conservation_837  -1
    service_0_31_1  original_T_including_depot_unload_873  120
    service_0_31_3  unique_nonzero_owner_314  1
    service_0_31_3  service_visit_def_836  1
    service_0_31_3  free_load_conservation_837  1
    service_0_31_4  unique_nonzero_owner_315  1
    service_0_31_4  service_visit_def_836  1
    service_0_31_4  free_load_conservation_837  2
    service_0_31_5  unique_nonzero_owner_316  1
    service_0_31_5  service_visit_def_836  1
    service_0_31_5  free_load_conservation_837  3
    service_0_31_6  unique_nonzero_owner_317  1
    service_0_31_6  service_visit_def_836  1
    service_0_31_6  free_load_conservation_837  4
    service_0_31_7  unique_nonzero_owner_318  1
    service_0_31_7  service_visit_def_836  1
    service_0_31_7  free_load_conservation_837  5
    service_0_31_8  unique_nonzero_owner_319  1
    service_0_31_8  service_visit_def_836  1
    service_0_31_8  free_load_conservation_837  6
    service_0_31_9  unique_nonzero_owner_320  1
    service_0_31_9  service_visit_def_836  1
    service_0_31_9  free_load_conservation_837  7
    service_0_31_10  unique_nonzero_owner_321  1
    service_0_31_10  service_visit_def_836  1
    service_0_31_10  free_load_conservation_837  8
    service_0_31_11  unique_nonzero_owner_322  1
    service_0_31_11  service_visit_def_836  1
    service_0_31_11  free_load_conservation_837  9
    service_0_31_12  unique_nonzero_owner_323  1
    service_0_31_12  service_visit_def_836  1
    service_0_31_12  free_load_conservation_837  10
    service_1_31_0  unique_nonzero_owner_312  1
    service_1_31_0  service_visit_def_1209  1
    service_1_31_0  free_load_conservation_1210  -2
    service_1_31_0  original_T_including_depot_unload_1244  240
    service_1_31_1  unique_nonzero_owner_313  1
    service_1_31_1  service_visit_def_1209  1
    service_1_31_1  free_load_conservation_1210  -1
    service_1_31_1  original_T_including_depot_unload_1244  120
    service_1_31_3  unique_nonzero_owner_314  1
    service_1_31_3  service_visit_def_1209  1
    service_1_31_3  free_load_conservation_1210  1
    service_1_31_4  unique_nonzero_owner_315  1
    service_1_31_4  service_visit_def_1209  1
    service_1_31_4  free_load_conservation_1210  2
    service_1_31_5  unique_nonzero_owner_316  1
    service_1_31_5  service_visit_def_1209  1
    service_1_31_5  free_load_conservation_1210  3
    service_1_31_6  unique_nonzero_owner_317  1
    service_1_31_6  service_visit_def_1209  1
    service_1_31_6  free_load_conservation_1210  4
    service_1_31_7  unique_nonzero_owner_318  1
    service_1_31_7  service_visit_def_1209  1
    service_1_31_7  free_load_conservation_1210  5
    service_1_31_8  unique_nonzero_owner_319  1
    service_1_31_8  service_visit_def_1209  1
    service_1_31_8  free_load_conservation_1210  6
    service_1_31_9  unique_nonzero_owner_320  1
    service_1_31_9  service_visit_def_1209  1
    service_1_31_9  free_load_conservation_1210  7
    service_1_31_10  unique_nonzero_owner_321  1
    service_1_31_10  service_visit_def_1209  1
    service_1_31_10  free_load_conservation_1210  8
    service_1_31_11  unique_nonzero_owner_322  1
    service_1_31_11  service_visit_def_1209  1
    service_1_31_11  free_load_conservation_1210  9
    service_1_31_12  unique_nonzero_owner_323  1
    service_1_31_12  service_visit_def_1209  1
    service_1_31_12  free_load_conservation_1210  10
    service_2_31_0  unique_nonzero_owner_312  1
    service_2_31_0  service_visit_def_1580  1
    service_2_31_0  free_load_conservation_1581  -2
    service_2_31_0  original_T_including_depot_unload_1615  240
    service_2_31_1  unique_nonzero_owner_313  1
    service_2_31_1  service_visit_def_1580  1
    service_2_31_1  free_load_conservation_1581  -1
    service_2_31_1  original_T_including_depot_unload_1615  120
    service_2_31_3  unique_nonzero_owner_314  1
    service_2_31_3  service_visit_def_1580  1
    service_2_31_3  free_load_conservation_1581  1
    service_2_31_4  unique_nonzero_owner_315  1
    service_2_31_4  service_visit_def_1580  1
    service_2_31_4  free_load_conservation_1581  2
    service_2_31_5  unique_nonzero_owner_316  1
    service_2_31_5  service_visit_def_1580  1
    service_2_31_5  free_load_conservation_1581  3
    service_2_31_6  unique_nonzero_owner_317  1
    service_2_31_6  service_visit_def_1580  1
    service_2_31_6  free_load_conservation_1581  4
    service_2_31_7  unique_nonzero_owner_318  1
    service_2_31_7  service_visit_def_1580  1
    service_2_31_7  free_load_conservation_1581  5
    service_2_31_8  unique_nonzero_owner_319  1
    service_2_31_8  service_visit_def_1580  1
    service_2_31_8  free_load_conservation_1581  6
    service_2_31_9  unique_nonzero_owner_320  1
    service_2_31_9  service_visit_def_1580  1
    service_2_31_9  free_load_conservation_1581  7
    service_2_31_10  unique_nonzero_owner_321  1
    service_2_31_10  service_visit_def_1580  1
    service_2_31_10  free_load_conservation_1581  8
    service_2_31_11  unique_nonzero_owner_322  1
    service_2_31_11  service_visit_def_1580  1
    service_2_31_11  free_load_conservation_1581  9
    service_2_31_12  unique_nonzero_owner_323  1
    service_2_31_12  service_visit_def_1580  1
    service_2_31_12  free_load_conservation_1581  10
    service_0_32_1  unique_nonzero_owner_324  1
    service_0_32_1  service_visit_def_842  1
    service_0_32_1  free_load_conservation_843  1
    service_0_32_2  unique_nonzero_owner_325  1
    service_0_32_2  service_visit_def_842  1
    service_0_32_2  free_load_conservation_843  2
    service_0_32_3  unique_nonzero_owner_326  1
    service_0_32_3  service_visit_def_842  1
    service_0_32_3  free_load_conservation_843  3
    service_0_32_4  unique_nonzero_owner_327  1
    service_0_32_4  service_visit_def_842  1
    service_0_32_4  free_load_conservation_843  4
    service_0_32_5  unique_nonzero_owner_328  1
    service_0_32_5  service_visit_def_842  1
    service_0_32_5  free_load_conservation_843  5
    service_0_32_6  unique_nonzero_owner_329  1
    service_0_32_6  service_visit_def_842  1
    service_0_32_6  free_load_conservation_843  6
    service_0_32_7  unique_nonzero_owner_330  1
    service_0_32_7  service_visit_def_842  1
    service_0_32_7  free_load_conservation_843  7
    service_0_32_8  unique_nonzero_owner_331  1
    service_0_32_8  service_visit_def_842  1
    service_0_32_8  free_load_conservation_843  8
    service_0_32_9  unique_nonzero_owner_332  1
    service_0_32_9  service_visit_def_842  1
    service_0_32_9  free_load_conservation_843  9
    service_0_32_10  unique_nonzero_owner_333  1
    service_0_32_10  service_visit_def_842  1
    service_0_32_10  free_load_conservation_843  10
    service_0_32_11  unique_nonzero_owner_334  1
    service_0_32_11  service_visit_def_842  1
    service_0_32_11  free_load_conservation_843  11
    service_0_32_12  unique_nonzero_owner_335  1
    service_0_32_12  service_visit_def_842  1
    service_0_32_12  free_load_conservation_843  12
    service_1_32_1  unique_nonzero_owner_324  1
    service_1_32_1  service_visit_def_1215  1
    service_1_32_1  free_load_conservation_1216  1
    service_1_32_2  unique_nonzero_owner_325  1
    service_1_32_2  service_visit_def_1215  1
    service_1_32_2  free_load_conservation_1216  2
    service_1_32_3  unique_nonzero_owner_326  1
    service_1_32_3  service_visit_def_1215  1
    service_1_32_3  free_load_conservation_1216  3
    service_1_32_4  unique_nonzero_owner_327  1
    service_1_32_4  service_visit_def_1215  1
    service_1_32_4  free_load_conservation_1216  4
    service_1_32_5  unique_nonzero_owner_328  1
    service_1_32_5  service_visit_def_1215  1
    service_1_32_5  free_load_conservation_1216  5
    service_1_32_6  unique_nonzero_owner_329  1
    service_1_32_6  service_visit_def_1215  1
    service_1_32_6  free_load_conservation_1216  6
    service_1_32_7  unique_nonzero_owner_330  1
    service_1_32_7  service_visit_def_1215  1
    service_1_32_7  free_load_conservation_1216  7
    service_1_32_8  unique_nonzero_owner_331  1
    service_1_32_8  service_visit_def_1215  1
    service_1_32_8  free_load_conservation_1216  8
    service_1_32_9  unique_nonzero_owner_332  1
    service_1_32_9  service_visit_def_1215  1
    service_1_32_9  free_load_conservation_1216  9
    service_1_32_10  unique_nonzero_owner_333  1
    service_1_32_10  service_visit_def_1215  1
    service_1_32_10  free_load_conservation_1216  10
    service_1_32_11  unique_nonzero_owner_334  1
    service_1_32_11  service_visit_def_1215  1
    service_1_32_11  free_load_conservation_1216  11
    service_1_32_12  unique_nonzero_owner_335  1
    service_1_32_12  service_visit_def_1215  1
    service_1_32_12  free_load_conservation_1216  12
    service_2_32_1  unique_nonzero_owner_324  1
    service_2_32_1  service_visit_def_1586  1
    service_2_32_1  free_load_conservation_1587  1
    service_2_32_2  unique_nonzero_owner_325  1
    service_2_32_2  service_visit_def_1586  1
    service_2_32_2  free_load_conservation_1587  2
    service_2_32_3  unique_nonzero_owner_326  1
    service_2_32_3  service_visit_def_1586  1
    service_2_32_3  free_load_conservation_1587  3
    service_2_32_4  unique_nonzero_owner_327  1
    service_2_32_4  service_visit_def_1586  1
    service_2_32_4  free_load_conservation_1587  4
    service_2_32_5  unique_nonzero_owner_328  1
    service_2_32_5  service_visit_def_1586  1
    service_2_32_5  free_load_conservation_1587  5
    service_2_32_6  unique_nonzero_owner_329  1
    service_2_32_6  service_visit_def_1586  1
    service_2_32_6  free_load_conservation_1587  6
    service_2_32_7  unique_nonzero_owner_330  1
    service_2_32_7  service_visit_def_1586  1
    service_2_32_7  free_load_conservation_1587  7
    service_2_32_8  unique_nonzero_owner_331  1
    service_2_32_8  service_visit_def_1586  1
    service_2_32_8  free_load_conservation_1587  8
    service_2_32_9  unique_nonzero_owner_332  1
    service_2_32_9  service_visit_def_1586  1
    service_2_32_9  free_load_conservation_1587  9
    service_2_32_10  unique_nonzero_owner_333  1
    service_2_32_10  service_visit_def_1586  1
    service_2_32_10  free_load_conservation_1587  10
    service_2_32_11  unique_nonzero_owner_334  1
    service_2_32_11  service_visit_def_1586  1
    service_2_32_11  free_load_conservation_1587  11
    service_2_32_12  unique_nonzero_owner_335  1
    service_2_32_12  service_visit_def_1586  1
    service_2_32_12  free_load_conservation_1587  12
    service_0_19_1  unique_nonzero_owner_336  1
    service_0_19_1  service_visit_def_848  1
    service_0_19_1  free_load_conservation_849  1
    service_0_19_2  unique_nonzero_owner_337  1
    service_0_19_2  service_visit_def_848  1
    service_0_19_2  free_load_conservation_849  2
    service_0_19_3  unique_nonzero_owner_338  1
    service_0_19_3  service_visit_def_848  1
    service_0_19_3  free_load_conservation_849  3
    service_0_19_4  unique_nonzero_owner_339  1
    service_0_19_4  service_visit_def_848  1
    service_0_19_4  free_load_conservation_849  4
    service_0_19_5  unique_nonzero_owner_340  1
    service_0_19_5  service_visit_def_848  1
    service_0_19_5  free_load_conservation_849  5
    service_0_19_6  unique_nonzero_owner_341  1
    service_0_19_6  service_visit_def_848  1
    service_0_19_6  free_load_conservation_849  6
    service_0_19_7  unique_nonzero_owner_342  1
    service_0_19_7  service_visit_def_848  1
    service_0_19_7  free_load_conservation_849  7
    service_0_19_8  unique_nonzero_owner_343  1
    service_0_19_8  service_visit_def_848  1
    service_0_19_8  free_load_conservation_849  8
    service_1_19_1  unique_nonzero_owner_336  1
    service_1_19_1  service_visit_def_1221  1
    service_1_19_1  free_load_conservation_1222  1
    service_1_19_2  unique_nonzero_owner_337  1
    service_1_19_2  service_visit_def_1221  1
    service_1_19_2  free_load_conservation_1222  2
    service_1_19_3  unique_nonzero_owner_338  1
    service_1_19_3  service_visit_def_1221  1
    service_1_19_3  free_load_conservation_1222  3
    service_1_19_4  unique_nonzero_owner_339  1
    service_1_19_4  service_visit_def_1221  1
    service_1_19_4  free_load_conservation_1222  4
    service_1_19_5  unique_nonzero_owner_340  1
    service_1_19_5  service_visit_def_1221  1
    service_1_19_5  free_load_conservation_1222  5
    service_1_19_6  unique_nonzero_owner_341  1
    service_1_19_6  service_visit_def_1221  1
    service_1_19_6  free_load_conservation_1222  6
    service_1_19_7  unique_nonzero_owner_342  1
    service_1_19_7  service_visit_def_1221  1
    service_1_19_7  free_load_conservation_1222  7
    service_1_19_8  unique_nonzero_owner_343  1
    service_1_19_8  service_visit_def_1221  1
    service_1_19_8  free_load_conservation_1222  8
    service_2_19_1  unique_nonzero_owner_336  1
    service_2_19_1  service_visit_def_1592  1
    service_2_19_1  free_load_conservation_1593  1
    service_2_19_2  unique_nonzero_owner_337  1
    service_2_19_2  service_visit_def_1592  1
    service_2_19_2  free_load_conservation_1593  2
    service_2_19_3  unique_nonzero_owner_338  1
    service_2_19_3  service_visit_def_1592  1
    service_2_19_3  free_load_conservation_1593  3
    service_2_19_4  unique_nonzero_owner_339  1
    service_2_19_4  service_visit_def_1592  1
    service_2_19_4  free_load_conservation_1593  4
    service_2_19_5  unique_nonzero_owner_340  1
    service_2_19_5  service_visit_def_1592  1
    service_2_19_5  free_load_conservation_1593  5
    service_2_19_6  unique_nonzero_owner_341  1
    service_2_19_6  service_visit_def_1592  1
    service_2_19_6  free_load_conservation_1593  6
    service_2_19_7  unique_nonzero_owner_342  1
    service_2_19_7  service_visit_def_1592  1
    service_2_19_7  free_load_conservation_1593  7
    service_2_19_8  unique_nonzero_owner_343  1
    service_2_19_8  service_visit_def_1592  1
    service_2_19_8  free_load_conservation_1593  8
    service_0_26_1  unique_nonzero_owner_344  1
    service_0_26_1  service_visit_def_854  1
    service_0_26_1  free_load_conservation_855  1
    service_0_26_2  unique_nonzero_owner_345  1
    service_0_26_2  service_visit_def_854  1
    service_0_26_2  free_load_conservation_855  2
    service_0_26_3  unique_nonzero_owner_346  1
    service_0_26_3  service_visit_def_854  1
    service_0_26_3  free_load_conservation_855  3
    service_0_26_4  unique_nonzero_owner_347  1
    service_0_26_4  service_visit_def_854  1
    service_0_26_4  free_load_conservation_855  4
    service_0_26_5  unique_nonzero_owner_348  1
    service_0_26_5  service_visit_def_854  1
    service_0_26_5  free_load_conservation_855  5
    service_0_26_6  unique_nonzero_owner_349  1
    service_0_26_6  service_visit_def_854  1
    service_0_26_6  free_load_conservation_855  6
    service_0_26_7  unique_nonzero_owner_350  1
    service_0_26_7  service_visit_def_854  1
    service_0_26_7  free_load_conservation_855  7
    service_0_26_8  unique_nonzero_owner_351  1
    service_0_26_8  service_visit_def_854  1
    service_0_26_8  free_load_conservation_855  8
    service_1_26_1  unique_nonzero_owner_344  1
    service_1_26_1  service_visit_def_1227  1
    service_1_26_1  free_load_conservation_1228  1
    service_1_26_2  unique_nonzero_owner_345  1
    service_1_26_2  service_visit_def_1227  1
    service_1_26_2  free_load_conservation_1228  2
    service_1_26_3  unique_nonzero_owner_346  1
    service_1_26_3  service_visit_def_1227  1
    service_1_26_3  free_load_conservation_1228  3
    service_1_26_4  unique_nonzero_owner_347  1
    service_1_26_4  service_visit_def_1227  1
    service_1_26_4  free_load_conservation_1228  4
    service_1_26_5  unique_nonzero_owner_348  1
    service_1_26_5  service_visit_def_1227  1
    service_1_26_5  free_load_conservation_1228  5
    service_1_26_6  unique_nonzero_owner_349  1
    service_1_26_6  service_visit_def_1227  1
    service_1_26_6  free_load_conservation_1228  6
    service_1_26_7  unique_nonzero_owner_350  1
    service_1_26_7  service_visit_def_1227  1
    service_1_26_7  free_load_conservation_1228  7
    service_1_26_8  unique_nonzero_owner_351  1
    service_1_26_8  service_visit_def_1227  1
    service_1_26_8  free_load_conservation_1228  8
    service_2_26_1  unique_nonzero_owner_344  1
    service_2_26_1  service_visit_def_1598  1
    service_2_26_1  free_load_conservation_1599  1
    service_2_26_2  unique_nonzero_owner_345  1
    service_2_26_2  service_visit_def_1598  1
    service_2_26_2  free_load_conservation_1599  2
    service_2_26_3  unique_nonzero_owner_346  1
    service_2_26_3  service_visit_def_1598  1
    service_2_26_3  free_load_conservation_1599  3
    service_2_26_4  unique_nonzero_owner_347  1
    service_2_26_4  service_visit_def_1598  1
    service_2_26_4  free_load_conservation_1599  4
    service_2_26_5  unique_nonzero_owner_348  1
    service_2_26_5  service_visit_def_1598  1
    service_2_26_5  free_load_conservation_1599  5
    service_2_26_6  unique_nonzero_owner_349  1
    service_2_26_6  service_visit_def_1598  1
    service_2_26_6  free_load_conservation_1599  6
    service_2_26_7  unique_nonzero_owner_350  1
    service_2_26_7  service_visit_def_1598  1
    service_2_26_7  free_load_conservation_1599  7
    service_2_26_8  unique_nonzero_owner_351  1
    service_2_26_8  service_visit_def_1598  1
    service_2_26_8  free_load_conservation_1599  8
    service_0_2_1  unique_nonzero_owner_352  1
    service_0_2_1  service_visit_def_860  1
    service_0_2_1  free_load_conservation_861  1
    service_0_2_2  unique_nonzero_owner_353  1
    service_0_2_2  service_visit_def_860  1
    service_0_2_2  free_load_conservation_861  2
    service_0_2_3  unique_nonzero_owner_354  1
    service_0_2_3  service_visit_def_860  1
    service_0_2_3  free_load_conservation_861  3
    service_0_2_4  unique_nonzero_owner_355  1
    service_0_2_4  service_visit_def_860  1
    service_0_2_4  free_load_conservation_861  4
    service_0_2_5  unique_nonzero_owner_356  1
    service_0_2_5  service_visit_def_860  1
    service_0_2_5  free_load_conservation_861  5
    service_0_2_6  unique_nonzero_owner_357  1
    service_0_2_6  service_visit_def_860  1
    service_0_2_6  free_load_conservation_861  6
    service_0_2_7  unique_nonzero_owner_358  1
    service_0_2_7  service_visit_def_860  1
    service_0_2_7  free_load_conservation_861  7
    service_0_2_8  unique_nonzero_owner_359  1
    service_0_2_8  service_visit_def_860  1
    service_0_2_8  free_load_conservation_861  8
    service_0_2_9  unique_nonzero_owner_360  1
    service_0_2_9  service_visit_def_860  1
    service_0_2_9  free_load_conservation_861  9
    service_0_2_10  unique_nonzero_owner_361  1
    service_0_2_10  service_visit_def_860  1
    service_0_2_10  free_load_conservation_861  10
    service_0_2_11  unique_nonzero_owner_362  1
    service_0_2_11  service_visit_def_860  1
    service_0_2_11  free_load_conservation_861  11
    service_0_2_12  unique_nonzero_owner_363  1
    service_0_2_12  service_visit_def_860  1
    service_0_2_12  free_load_conservation_861  12
    service_0_2_13  unique_nonzero_owner_364  1
    service_0_2_13  service_visit_def_860  1
    service_0_2_13  free_load_conservation_861  13
    service_0_2_14  unique_nonzero_owner_365  1
    service_0_2_14  service_visit_def_860  1
    service_0_2_14  free_load_conservation_861  14
    service_0_2_15  unique_nonzero_owner_366  1
    service_0_2_15  service_visit_def_860  1
    service_0_2_15  free_load_conservation_861  15
    service_1_2_1  unique_nonzero_owner_352  1
    service_1_2_1  service_visit_def_1233  1
    service_1_2_1  free_load_conservation_1234  1
    service_1_2_2  unique_nonzero_owner_353  1
    service_1_2_2  service_visit_def_1233  1
    service_1_2_2  free_load_conservation_1234  2
    service_1_2_3  unique_nonzero_owner_354  1
    service_1_2_3  service_visit_def_1233  1
    service_1_2_3  free_load_conservation_1234  3
    service_1_2_4  unique_nonzero_owner_355  1
    service_1_2_4  service_visit_def_1233  1
    service_1_2_4  free_load_conservation_1234  4
    service_1_2_5  unique_nonzero_owner_356  1
    service_1_2_5  service_visit_def_1233  1
    service_1_2_5  free_load_conservation_1234  5
    service_1_2_6  unique_nonzero_owner_357  1
    service_1_2_6  service_visit_def_1233  1
    service_1_2_6  free_load_conservation_1234  6
    service_1_2_7  unique_nonzero_owner_358  1
    service_1_2_7  service_visit_def_1233  1
    service_1_2_7  free_load_conservation_1234  7
    service_1_2_8  unique_nonzero_owner_359  1
    service_1_2_8  service_visit_def_1233  1
    service_1_2_8  free_load_conservation_1234  8
    service_1_2_9  unique_nonzero_owner_360  1
    service_1_2_9  service_visit_def_1233  1
    service_1_2_9  free_load_conservation_1234  9
    service_1_2_10  unique_nonzero_owner_361  1
    service_1_2_10  service_visit_def_1233  1
    service_1_2_10  free_load_conservation_1234  10
    service_1_2_11  unique_nonzero_owner_362  1
    service_1_2_11  service_visit_def_1233  1
    service_1_2_11  free_load_conservation_1234  11
    service_1_2_12  unique_nonzero_owner_363  1
    service_1_2_12  service_visit_def_1233  1
    service_1_2_12  free_load_conservation_1234  12
    service_1_2_13  unique_nonzero_owner_364  1
    service_1_2_13  service_visit_def_1233  1
    service_1_2_13  free_load_conservation_1234  13
    service_1_2_14  unique_nonzero_owner_365  1
    service_1_2_14  service_visit_def_1233  1
    service_1_2_14  free_load_conservation_1234  14
    service_1_2_15  unique_nonzero_owner_366  1
    service_1_2_15  service_visit_def_1233  1
    service_1_2_15  free_load_conservation_1234  15
    service_2_2_1  unique_nonzero_owner_352  1
    service_2_2_1  service_visit_def_1604  1
    service_2_2_1  free_load_conservation_1605  1
    service_2_2_2  unique_nonzero_owner_353  1
    service_2_2_2  service_visit_def_1604  1
    service_2_2_2  free_load_conservation_1605  2
    service_2_2_3  unique_nonzero_owner_354  1
    service_2_2_3  service_visit_def_1604  1
    service_2_2_3  free_load_conservation_1605  3
    service_2_2_4  unique_nonzero_owner_355  1
    service_2_2_4  service_visit_def_1604  1
    service_2_2_4  free_load_conservation_1605  4
    service_2_2_5  unique_nonzero_owner_356  1
    service_2_2_5  service_visit_def_1604  1
    service_2_2_5  free_load_conservation_1605  5
    service_2_2_6  unique_nonzero_owner_357  1
    service_2_2_6  service_visit_def_1604  1
    service_2_2_6  free_load_conservation_1605  6
    service_2_2_7  unique_nonzero_owner_358  1
    service_2_2_7  service_visit_def_1604  1
    service_2_2_7  free_load_conservation_1605  7
    service_2_2_8  unique_nonzero_owner_359  1
    service_2_2_8  service_visit_def_1604  1
    service_2_2_8  free_load_conservation_1605  8
    service_2_2_9  unique_nonzero_owner_360  1
    service_2_2_9  service_visit_def_1604  1
    service_2_2_9  free_load_conservation_1605  9
    service_2_2_10  unique_nonzero_owner_361  1
    service_2_2_10  service_visit_def_1604  1
    service_2_2_10  free_load_conservation_1605  10
    service_2_2_11  unique_nonzero_owner_362  1
    service_2_2_11  service_visit_def_1604  1
    service_2_2_11  free_load_conservation_1605  11
    service_2_2_12  unique_nonzero_owner_363  1
    service_2_2_12  service_visit_def_1604  1
    service_2_2_12  free_load_conservation_1605  12
    service_2_2_13  unique_nonzero_owner_364  1
    service_2_2_13  service_visit_def_1604  1
    service_2_2_13  free_load_conservation_1605  13
    service_2_2_14  unique_nonzero_owner_365  1
    service_2_2_14  service_visit_def_1604  1
    service_2_2_14  free_load_conservation_1605  14
    service_2_2_15  unique_nonzero_owner_366  1
    service_2_2_15  service_visit_def_1604  1
    service_2_2_15  free_load_conservation_1605  15
    service_0_17_0  unique_nonzero_owner_367  1
    service_0_17_0  service_visit_def_866  1
    service_0_17_0  free_load_conservation_867  -3
    service_0_17_0  original_T_including_depot_unload_873  360
    service_0_17_1  unique_nonzero_owner_368  1
    service_0_17_1  service_visit_def_866  1
    service_0_17_1  free_load_conservation_867  -2
    service_0_17_1  original_T_including_depot_unload_873  240
    service_0_17_2  unique_nonzero_owner_369  1
    service_0_17_2  service_visit_def_866  1
    service_0_17_2  free_load_conservation_867  -1
    service_0_17_2  original_T_including_depot_unload_873  120
    service_0_17_4  unique_nonzero_owner_370  1
    service_0_17_4  service_visit_def_866  1
    service_0_17_4  free_load_conservation_867  1
    service_0_17_5  unique_nonzero_owner_371  1
    service_0_17_5  service_visit_def_866  1
    service_0_17_5  free_load_conservation_867  2
    service_0_17_6  unique_nonzero_owner_372  1
    service_0_17_6  service_visit_def_866  1
    service_0_17_6  free_load_conservation_867  3
    service_0_17_7  unique_nonzero_owner_373  1
    service_0_17_7  service_visit_def_866  1
    service_0_17_7  free_load_conservation_867  4
    service_0_17_8  unique_nonzero_owner_374  1
    service_0_17_8  service_visit_def_866  1
    service_0_17_8  free_load_conservation_867  5
    service_0_17_9  unique_nonzero_owner_375  1
    service_0_17_9  service_visit_def_866  1
    service_0_17_9  free_load_conservation_867  6
    service_0_17_10  unique_nonzero_owner_376  1
    service_0_17_10  service_visit_def_866  1
    service_0_17_10  free_load_conservation_867  7
    service_0_17_11  unique_nonzero_owner_377  1
    service_0_17_11  service_visit_def_866  1
    service_0_17_11  free_load_conservation_867  8
    service_0_17_12  unique_nonzero_owner_378  1
    service_0_17_12  service_visit_def_866  1
    service_0_17_12  free_load_conservation_867  9
    service_0_17_13  unique_nonzero_owner_379  1
    service_0_17_13  service_visit_def_866  1
    service_0_17_13  free_load_conservation_867  10
    service_0_17_14  unique_nonzero_owner_380  1
    service_0_17_14  service_visit_def_866  1
    service_0_17_14  free_load_conservation_867  11
    service_0_17_15  unique_nonzero_owner_381  1
    service_0_17_15  service_visit_def_866  1
    service_0_17_15  free_load_conservation_867  12
    service_0_17_16  unique_nonzero_owner_382  1
    service_0_17_16  service_visit_def_866  1
    service_0_17_16  free_load_conservation_867  13
    service_1_17_0  unique_nonzero_owner_367  1
    service_1_17_0  service_visit_def_1239  1
    service_1_17_0  free_load_conservation_1240  -3
    service_1_17_0  original_T_including_depot_unload_1244  360
    service_1_17_1  unique_nonzero_owner_368  1
    service_1_17_1  service_visit_def_1239  1
    service_1_17_1  free_load_conservation_1240  -2
    service_1_17_1  original_T_including_depot_unload_1244  240
    service_1_17_2  unique_nonzero_owner_369  1
    service_1_17_2  service_visit_def_1239  1
    service_1_17_2  free_load_conservation_1240  -1
    service_1_17_2  original_T_including_depot_unload_1244  120
    service_1_17_4  unique_nonzero_owner_370  1
    service_1_17_4  service_visit_def_1239  1
    service_1_17_4  free_load_conservation_1240  1
    service_1_17_5  unique_nonzero_owner_371  1
    service_1_17_5  service_visit_def_1239  1
    service_1_17_5  free_load_conservation_1240  2
    service_1_17_6  unique_nonzero_owner_372  1
    service_1_17_6  service_visit_def_1239  1
    service_1_17_6  free_load_conservation_1240  3
    service_1_17_7  unique_nonzero_owner_373  1
    service_1_17_7  service_visit_def_1239  1
    service_1_17_7  free_load_conservation_1240  4
    service_1_17_8  unique_nonzero_owner_374  1
    service_1_17_8  service_visit_def_1239  1
    service_1_17_8  free_load_conservation_1240  5
    service_1_17_9  unique_nonzero_owner_375  1
    service_1_17_9  service_visit_def_1239  1
    service_1_17_9  free_load_conservation_1240  6
    service_1_17_10  unique_nonzero_owner_376  1
    service_1_17_10  service_visit_def_1239  1
    service_1_17_10  free_load_conservation_1240  7
    service_1_17_11  unique_nonzero_owner_377  1
    service_1_17_11  service_visit_def_1239  1
    service_1_17_11  free_load_conservation_1240  8
    service_1_17_12  unique_nonzero_owner_378  1
    service_1_17_12  service_visit_def_1239  1
    service_1_17_12  free_load_conservation_1240  9
    service_1_17_13  unique_nonzero_owner_379  1
    service_1_17_13  service_visit_def_1239  1
    service_1_17_13  free_load_conservation_1240  10
    service_1_17_14  unique_nonzero_owner_380  1
    service_1_17_14  service_visit_def_1239  1
    service_1_17_14  free_load_conservation_1240  11
    service_1_17_15  unique_nonzero_owner_381  1
    service_1_17_15  service_visit_def_1239  1
    service_1_17_15  free_load_conservation_1240  12
    service_1_17_16  unique_nonzero_owner_382  1
    service_1_17_16  service_visit_def_1239  1
    service_1_17_16  free_load_conservation_1240  13
    service_2_17_0  unique_nonzero_owner_367  1
    service_2_17_0  service_visit_def_1610  1
    service_2_17_0  free_load_conservation_1611  -3
    service_2_17_0  original_T_including_depot_unload_1615  360
    service_2_17_1  unique_nonzero_owner_368  1
    service_2_17_1  service_visit_def_1610  1
    service_2_17_1  free_load_conservation_1611  -2
    service_2_17_1  original_T_including_depot_unload_1615  240
    service_2_17_2  unique_nonzero_owner_369  1
    service_2_17_2  service_visit_def_1610  1
    service_2_17_2  free_load_conservation_1611  -1
    service_2_17_2  original_T_including_depot_unload_1615  120
    service_2_17_4  unique_nonzero_owner_370  1
    service_2_17_4  service_visit_def_1610  1
    service_2_17_4  free_load_conservation_1611  1
    service_2_17_5  unique_nonzero_owner_371  1
    service_2_17_5  service_visit_def_1610  1
    service_2_17_5  free_load_conservation_1611  2
    service_2_17_6  unique_nonzero_owner_372  1
    service_2_17_6  service_visit_def_1610  1
    service_2_17_6  free_load_conservation_1611  3
    service_2_17_7  unique_nonzero_owner_373  1
    service_2_17_7  service_visit_def_1610  1
    service_2_17_7  free_load_conservation_1611  4
    service_2_17_8  unique_nonzero_owner_374  1
    service_2_17_8  service_visit_def_1610  1
    service_2_17_8  free_load_conservation_1611  5
    service_2_17_9  unique_nonzero_owner_375  1
    service_2_17_9  service_visit_def_1610  1
    service_2_17_9  free_load_conservation_1611  6
    service_2_17_10  unique_nonzero_owner_376  1
    service_2_17_10  service_visit_def_1610  1
    service_2_17_10  free_load_conservation_1611  7
    service_2_17_11  unique_nonzero_owner_377  1
    service_2_17_11  service_visit_def_1610  1
    service_2_17_11  free_load_conservation_1611  8
    service_2_17_12  unique_nonzero_owner_378  1
    service_2_17_12  service_visit_def_1610  1
    service_2_17_12  free_load_conservation_1611  9
    service_2_17_13  unique_nonzero_owner_379  1
    service_2_17_13  service_visit_def_1610  1
    service_2_17_13  free_load_conservation_1611  10
    service_2_17_14  unique_nonzero_owner_380  1
    service_2_17_14  service_visit_def_1610  1
    service_2_17_14  free_load_conservation_1611  11
    service_2_17_15  unique_nonzero_owner_381  1
    service_2_17_15  service_visit_def_1610  1
    service_2_17_15  free_load_conservation_1611  12
    service_2_17_16  unique_nonzero_owner_382  1
    service_2_17_16  service_visit_def_1610  1
    service_2_17_16  free_load_conservation_1611  13
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_778  -1
    visit_0_1  in_degree_779  -1
    visit_0_1  order_active_lb_780  -1
    visit_0_1  order_active_ub_781  -14
    order_0_1  connected_order_arc_400  -1
    order_0_1  connected_order_arc_402  -1
    order_0_1  connected_order_arc_404  -1
    order_0_1  connected_order_arc_406  -1
    order_0_1  connected_order_arc_408  -1
    order_0_1  connected_order_arc_410  -1
    order_0_1  connected_order_arc_412  -1
    order_0_1  connected_order_arc_414  -1
    order_0_1  connected_order_arc_416  -1
    order_0_1  connected_order_arc_418  -1
    order_0_1  connected_order_arc_420  -1
    order_0_1  connected_order_arc_422  -1
    order_0_1  connected_order_arc_424  -1
    order_0_1  connected_order_arc_427  1
    order_0_1  connected_order_arc_454  1
    order_0_1  connected_order_arc_481  1
    order_0_1  connected_order_arc_508  1
    order_0_1  connected_order_arc_535  1
    order_0_1  connected_order_arc_562  1
    order_0_1  connected_order_arc_589  1
    order_0_1  connected_order_arc_616  1
    order_0_1  connected_order_arc_643  1
    order_0_1  connected_order_arc_670  1
    order_0_1  connected_order_arc_697  1
    order_0_1  connected_order_arc_724  1
    order_0_1  connected_order_arc_751  1
    order_0_1  order_active_lb_780  1
    order_0_1  order_active_ub_781  1
    order_0_1  fixed_segment_relative_order_868  -1
    visit_0_2  out_degree_785  -1
    visit_0_2  in_degree_786  -1
    visit_0_2  order_active_lb_787  -1
    visit_0_2  order_active_ub_788  -14
    order_0_2  connected_order_arc_400  1
    order_0_2  connected_order_arc_427  -1
    order_0_2  connected_order_arc_429  -1
    order_0_2  connected_order_arc_431  -1
    order_0_2  connected_order_arc_433  -1
    order_0_2  connected_order_arc_435  -1
    order_0_2  connected_order_arc_437  -1
    order_0_2  connected_order_arc_439  -1
    order_0_2  connected_order_arc_441  -1
    order_0_2  connected_order_arc_443  -1
    order_0_2  connected_order_arc_445  -1
    order_0_2  connected_order_arc_447  -1
    order_0_2  connected_order_arc_449  -1
    order_0_2  connected_order_arc_451  -1
    order_0_2  connected_order_arc_456  1
    order_0_2  connected_order_arc_483  1
    order_0_2  connected_order_arc_510  1
    order_0_2  connected_order_arc_537  1
    order_0_2  connected_order_arc_564  1
    order_0_2  connected_order_arc_591  1
    order_0_2  connected_order_arc_618  1
    order_0_2  connected_order_arc_645  1
    order_0_2  connected_order_arc_672  1
    order_0_2  connected_order_arc_699  1
    order_0_2  connected_order_arc_726  1
    order_0_2  connected_order_arc_753  1
    order_0_2  order_active_lb_787  1
    order_0_2  order_active_ub_788  1
    order_0_2  fixed_segment_relative_order_868  1
    order_0_2  fixed_segment_relative_order_869  -1
    visit_0_3  out_degree_792  -1
    visit_0_3  in_degree_793  -1
    visit_0_3  order_active_lb_794  -1
    visit_0_3  order_active_ub_795  -14
    order_0_3  connected_order_arc_402  1
    order_0_3  connected_order_arc_429  1
    order_0_3  connected_order_arc_454  -1
    order_0_3  connected_order_arc_456  -1
    order_0_3  connected_order_arc_458  -1
    order_0_3  connected_order_arc_460  -1
    order_0_3  connected_order_arc_462  -1
    order_0_3  connected_order_arc_464  -1
    order_0_3  connected_order_arc_466  -1
    order_0_3  connected_order_arc_468  -1
    order_0_3  connected_order_arc_470  -1
    order_0_3  connected_order_arc_472  -1
    order_0_3  connected_order_arc_474  -1
    order_0_3  connected_order_arc_476  -1
    order_0_3  connected_order_arc_478  -1
    order_0_3  connected_order_arc_485  1
    order_0_3  connected_order_arc_512  1
    order_0_3  connected_order_arc_539  1
    order_0_3  connected_order_arc_566  1
    order_0_3  connected_order_arc_593  1
    order_0_3  connected_order_arc_620  1
    order_0_3  connected_order_arc_647  1
    order_0_3  connected_order_arc_674  1
    order_0_3  connected_order_arc_701  1
    order_0_3  connected_order_arc_728  1
    order_0_3  connected_order_arc_755  1
    order_0_3  order_active_lb_794  1
    order_0_3  order_active_ub_795  1
    order_0_3  fixed_segment_relative_order_869  1
    order_0_3  fixed_segment_relative_order_870  -1
    visit_0_4  out_degree_799  -1
    visit_0_4  in_degree_800  -1
    visit_0_4  order_active_lb_801  -1
    visit_0_4  order_active_ub_802  -14
    order_0_4  connected_order_arc_404  1
    order_0_4  connected_order_arc_431  1
    order_0_4  connected_order_arc_458  1
    order_0_4  connected_order_arc_481  -1
    order_0_4  connected_order_arc_483  -1
    order_0_4  connected_order_arc_485  -1
    order_0_4  connected_order_arc_487  -1
    order_0_4  connected_order_arc_489  -1
    order_0_4  connected_order_arc_491  -1
    order_0_4  connected_order_arc_493  -1
    order_0_4  connected_order_arc_495  -1
    order_0_4  connected_order_arc_497  -1
    order_0_4  connected_order_arc_499  -1
    order_0_4  connected_order_arc_501  -1
    order_0_4  connected_order_arc_503  -1
    order_0_4  connected_order_arc_505  -1
    order_0_4  connected_order_arc_514  1
    order_0_4  connected_order_arc_541  1
    order_0_4  connected_order_arc_568  1
    order_0_4  connected_order_arc_595  1
    order_0_4  connected_order_arc_622  1
    order_0_4  connected_order_arc_649  1
    order_0_4  connected_order_arc_676  1
    order_0_4  connected_order_arc_703  1
    order_0_4  connected_order_arc_730  1
    order_0_4  connected_order_arc_757  1
    order_0_4  order_active_lb_801  1
    order_0_4  order_active_ub_802  1
    order_0_4  fixed_segment_relative_order_870  1
    order_0_4  fixed_segment_relative_order_871  -1
    visit_0_5  out_degree_806  -1
    visit_0_5  in_degree_807  -1
    visit_0_5  order_active_lb_808  -1
    visit_0_5  order_active_ub_809  -14
    order_0_5  connected_order_arc_406  1
    order_0_5  connected_order_arc_433  1
    order_0_5  connected_order_arc_460  1
    order_0_5  connected_order_arc_487  1
    order_0_5  connected_order_arc_508  -1
    order_0_5  connected_order_arc_510  -1
    order_0_5  connected_order_arc_512  -1
    order_0_5  connected_order_arc_514  -1
    order_0_5  connected_order_arc_516  -1
    order_0_5  connected_order_arc_518  -1
    order_0_5  connected_order_arc_520  -1
    order_0_5  connected_order_arc_522  -1
    order_0_5  connected_order_arc_524  -1
    order_0_5  connected_order_arc_526  -1
    order_0_5  connected_order_arc_528  -1
    order_0_5  connected_order_arc_530  -1
    order_0_5  connected_order_arc_532  -1
    order_0_5  connected_order_arc_543  1
    order_0_5  connected_order_arc_570  1
    order_0_5  connected_order_arc_597  1
    order_0_5  connected_order_arc_624  1
    order_0_5  connected_order_arc_651  1
    order_0_5  connected_order_arc_678  1
    order_0_5  connected_order_arc_705  1
    order_0_5  connected_order_arc_732  1
    order_0_5  connected_order_arc_759  1
    order_0_5  order_active_lb_808  1
    order_0_5  order_active_ub_809  1
    order_0_5  fixed_segment_relative_order_871  1
    order_0_5  fixed_segment_relative_order_872  -1
    visit_0_6  out_degree_813  -1
    visit_0_6  in_degree_814  -1
    visit_0_6  order_active_lb_815  -1
    visit_0_6  order_active_ub_816  -14
    order_0_6  connected_order_arc_408  1
    order_0_6  connected_order_arc_435  1
    order_0_6  connected_order_arc_462  1
    order_0_6  connected_order_arc_489  1
    order_0_6  connected_order_arc_516  1
    order_0_6  connected_order_arc_535  -1
    order_0_6  connected_order_arc_537  -1
    order_0_6  connected_order_arc_539  -1
    order_0_6  connected_order_arc_541  -1
    order_0_6  connected_order_arc_543  -1
    order_0_6  connected_order_arc_545  -1
    order_0_6  connected_order_arc_547  -1
    order_0_6  connected_order_arc_549  -1
    order_0_6  connected_order_arc_551  -1
    order_0_6  connected_order_arc_553  -1
    order_0_6  connected_order_arc_555  -1
    order_0_6  connected_order_arc_557  -1
    order_0_6  connected_order_arc_559  -1
    order_0_6  connected_order_arc_572  1
    order_0_6  connected_order_arc_599  1
    order_0_6  connected_order_arc_626  1
    order_0_6  connected_order_arc_653  1
    order_0_6  connected_order_arc_680  1
    order_0_6  connected_order_arc_707  1
    order_0_6  connected_order_arc_734  1
    order_0_6  connected_order_arc_761  1
    order_0_6  order_active_lb_815  1
    order_0_6  order_active_ub_816  1
    order_0_6  fixed_segment_relative_order_872  1
    visit_0_15  out_degree_820  -1
    visit_0_15  in_degree_821  -1
    visit_0_15  order_active_lb_822  -1
    visit_0_15  order_active_ub_823  -14
    visit_0_15  service_visit_def_824  -1
    order_0_15  connected_order_arc_410  1
    order_0_15  connected_order_arc_437  1
    order_0_15  connected_order_arc_464  1
    order_0_15  connected_order_arc_491  1
    order_0_15  connected_order_arc_518  1
    order_0_15  connected_order_arc_545  1
    order_0_15  connected_order_arc_562  -1
    order_0_15  connected_order_arc_564  -1
    order_0_15  connected_order_arc_566  -1
    order_0_15  connected_order_arc_568  -1
    order_0_15  connected_order_arc_570  -1
    order_0_15  connected_order_arc_572  -1
    order_0_15  connected_order_arc_574  -1
    order_0_15  connected_order_arc_576  -1
    order_0_15  connected_order_arc_578  -1
    order_0_15  connected_order_arc_580  -1
    order_0_15  connected_order_arc_582  -1
    order_0_15  connected_order_arc_584  -1
    order_0_15  connected_order_arc_586  -1
    order_0_15  connected_order_arc_601  1
    order_0_15  connected_order_arc_628  1
    order_0_15  connected_order_arc_655  1
    order_0_15  connected_order_arc_682  1
    order_0_15  connected_order_arc_709  1
    order_0_15  connected_order_arc_736  1
    order_0_15  connected_order_arc_763  1
    order_0_15  order_active_lb_822  1
    order_0_15  order_active_ub_823  1
    visit_0_16  out_degree_826  -1
    visit_0_16  in_degree_827  -1
    visit_0_16  order_active_lb_828  -1
    visit_0_16  order_active_ub_829  -14
    visit_0_16  service_visit_def_830  -1
    order_0_16  connected_order_arc_412  1
    order_0_16  connected_order_arc_439  1
    order_0_16  connected_order_arc_466  1
    order_0_16  connected_order_arc_493  1
    order_0_16  connected_order_arc_520  1
    order_0_16  connected_order_arc_547  1
    order_0_16  connected_order_arc_574  1
    order_0_16  connected_order_arc_589  -1
    order_0_16  connected_order_arc_591  -1
    order_0_16  connected_order_arc_593  -1
    order_0_16  connected_order_arc_595  -1
    order_0_16  connected_order_arc_597  -1
    order_0_16  connected_order_arc_599  -1
    order_0_16  connected_order_arc_601  -1
    order_0_16  connected_order_arc_603  -1
    order_0_16  connected_order_arc_605  -1
    order_0_16  connected_order_arc_607  -1
    order_0_16  connected_order_arc_609  -1
    order_0_16  connected_order_arc_611  -1
    order_0_16  connected_order_arc_613  -1
    order_0_16  connected_order_arc_630  1
    order_0_16  connected_order_arc_657  1
    order_0_16  connected_order_arc_684  1
    order_0_16  connected_order_arc_711  1
    order_0_16  connected_order_arc_738  1
    order_0_16  connected_order_arc_765  1
    order_0_16  order_active_lb_828  1
    order_0_16  order_active_ub_829  1
    visit_0_17  out_degree_832  -1
    visit_0_17  in_degree_833  -1
    visit_0_17  order_active_lb_834  -1
    visit_0_17  order_active_ub_835  -14
    visit_0_17  service_visit_def_836  -1
    order_0_17  connected_order_arc_414  1
    order_0_17  connected_order_arc_441  1
    order_0_17  connected_order_arc_468  1
    order_0_17  connected_order_arc_495  1
    order_0_17  connected_order_arc_522  1
    order_0_17  connected_order_arc_549  1
    order_0_17  connected_order_arc_576  1
    order_0_17  connected_order_arc_603  1
    order_0_17  connected_order_arc_616  -1
    order_0_17  connected_order_arc_618  -1
    order_0_17  connected_order_arc_620  -1
    order_0_17  connected_order_arc_622  -1
    order_0_17  connected_order_arc_624  -1
    order_0_17  connected_order_arc_626  -1
    order_0_17  connected_order_arc_628  -1
    order_0_17  connected_order_arc_630  -1
    order_0_17  connected_order_arc_632  -1
    order_0_17  connected_order_arc_634  -1
    order_0_17  connected_order_arc_636  -1
    order_0_17  connected_order_arc_638  -1
    order_0_17  connected_order_arc_640  -1
    order_0_17  connected_order_arc_659  1
    order_0_17  connected_order_arc_686  1
    order_0_17  connected_order_arc_713  1
    order_0_17  connected_order_arc_740  1
    order_0_17  connected_order_arc_767  1
    order_0_17  order_active_lb_834  1
    order_0_17  order_active_ub_835  1
    visit_0_18  out_degree_838  -1
    visit_0_18  in_degree_839  -1
    visit_0_18  order_active_lb_840  -1
    visit_0_18  order_active_ub_841  -14
    visit_0_18  service_visit_def_842  -1
    order_0_18  connected_order_arc_416  1
    order_0_18  connected_order_arc_443  1
    order_0_18  connected_order_arc_470  1
    order_0_18  connected_order_arc_497  1
    order_0_18  connected_order_arc_524  1
    order_0_18  connected_order_arc_551  1
    order_0_18  connected_order_arc_578  1
    order_0_18  connected_order_arc_605  1
    order_0_18  connected_order_arc_632  1
    order_0_18  connected_order_arc_643  -1
    order_0_18  connected_order_arc_645  -1
    order_0_18  connected_order_arc_647  -1
    order_0_18  connected_order_arc_649  -1
    order_0_18  connected_order_arc_651  -1
    order_0_18  connected_order_arc_653  -1
    order_0_18  connected_order_arc_655  -1
    order_0_18  connected_order_arc_657  -1
    order_0_18  connected_order_arc_659  -1
    order_0_18  connected_order_arc_661  -1
    order_0_18  connected_order_arc_663  -1
    order_0_18  connected_order_arc_665  -1
    order_0_18  connected_order_arc_667  -1
    order_0_18  connected_order_arc_688  1
    order_0_18  connected_order_arc_715  1
    order_0_18  connected_order_arc_742  1
    order_0_18  connected_order_arc_769  1
    order_0_18  order_active_lb_840  1
    order_0_18  order_active_ub_841  1
    visit_0_19  out_degree_844  -1
    visit_0_19  in_degree_845  -1
    visit_0_19  order_active_lb_846  -1
    visit_0_19  order_active_ub_847  -14
    visit_0_19  service_visit_def_848  -1
    order_0_19  connected_order_arc_418  1
    order_0_19  connected_order_arc_445  1
    order_0_19  connected_order_arc_472  1
    order_0_19  connected_order_arc_499  1
    order_0_19  connected_order_arc_526  1
    order_0_19  connected_order_arc_553  1
    order_0_19  connected_order_arc_580  1
    order_0_19  connected_order_arc_607  1
    order_0_19  connected_order_arc_634  1
    order_0_19  connected_order_arc_661  1
    order_0_19  connected_order_arc_670  -1
    order_0_19  connected_order_arc_672  -1
    order_0_19  connected_order_arc_674  -1
    order_0_19  connected_order_arc_676  -1
    order_0_19  connected_order_arc_678  -1
    order_0_19  connected_order_arc_680  -1
    order_0_19  connected_order_arc_682  -1
    order_0_19  connected_order_arc_684  -1
    order_0_19  connected_order_arc_686  -1
    order_0_19  connected_order_arc_688  -1
    order_0_19  connected_order_arc_690  -1
    order_0_19  connected_order_arc_692  -1
    order_0_19  connected_order_arc_694  -1
    order_0_19  connected_order_arc_717  1
    order_0_19  connected_order_arc_744  1
    order_0_19  connected_order_arc_771  1
    order_0_19  order_active_lb_846  1
    order_0_19  order_active_ub_847  1
    visit_0_20  out_degree_850  -1
    visit_0_20  in_degree_851  -1
    visit_0_20  order_active_lb_852  -1
    visit_0_20  order_active_ub_853  -14
    visit_0_20  service_visit_def_854  -1
    order_0_20  connected_order_arc_420  1
    order_0_20  connected_order_arc_447  1
    order_0_20  connected_order_arc_474  1
    order_0_20  connected_order_arc_501  1
    order_0_20  connected_order_arc_528  1
    order_0_20  connected_order_arc_555  1
    order_0_20  connected_order_arc_582  1
    order_0_20  connected_order_arc_609  1
    order_0_20  connected_order_arc_636  1
    order_0_20  connected_order_arc_663  1
    order_0_20  connected_order_arc_690  1
    order_0_20  connected_order_arc_697  -1
    order_0_20  connected_order_arc_699  -1
    order_0_20  connected_order_arc_701  -1
    order_0_20  connected_order_arc_703  -1
    order_0_20  connected_order_arc_705  -1
    order_0_20  connected_order_arc_707  -1
    order_0_20  connected_order_arc_709  -1
    order_0_20  connected_order_arc_711  -1
    order_0_20  connected_order_arc_713  -1
    order_0_20  connected_order_arc_715  -1
    order_0_20  connected_order_arc_717  -1
    order_0_20  connected_order_arc_719  -1
    order_0_20  connected_order_arc_721  -1
    order_0_20  connected_order_arc_746  1
    order_0_20  connected_order_arc_773  1
    order_0_20  order_active_lb_852  1
    order_0_20  order_active_ub_853  1
    visit_0_21  out_degree_856  -1
    visit_0_21  in_degree_857  -1
    visit_0_21  order_active_lb_858  -1
    visit_0_21  order_active_ub_859  -14
    visit_0_21  service_visit_def_860  -1
    order_0_21  connected_order_arc_422  1
    order_0_21  connected_order_arc_449  1
    order_0_21  connected_order_arc_476  1
    order_0_21  connected_order_arc_503  1
    order_0_21  connected_order_arc_530  1
    order_0_21  connected_order_arc_557  1
    order_0_21  connected_order_arc_584  1
    order_0_21  connected_order_arc_611  1
    order_0_21  connected_order_arc_638  1
    order_0_21  connected_order_arc_665  1
    order_0_21  connected_order_arc_692  1
    order_0_21  connected_order_arc_719  1
    order_0_21  connected_order_arc_724  -1
    order_0_21  connected_order_arc_726  -1
    order_0_21  connected_order_arc_728  -1
    order_0_21  connected_order_arc_730  -1
    order_0_21  connected_order_arc_732  -1
    order_0_21  connected_order_arc_734  -1
    order_0_21  connected_order_arc_736  -1
    order_0_21  connected_order_arc_738  -1
    order_0_21  connected_order_arc_740  -1
    order_0_21  connected_order_arc_742  -1
    order_0_21  connected_order_arc_744  -1
    order_0_21  connected_order_arc_746  -1
    order_0_21  connected_order_arc_748  -1
    order_0_21  connected_order_arc_775  1
    order_0_21  order_active_lb_858  1
    order_0_21  order_active_ub_859  1
    visit_0_22  out_degree_862  -1
    visit_0_22  in_degree_863  -1
    visit_0_22  order_active_lb_864  -1
    visit_0_22  order_active_ub_865  -14
    visit_0_22  service_visit_def_866  -1
    order_0_22  connected_order_arc_424  1
    order_0_22  connected_order_arc_451  1
    order_0_22  connected_order_arc_478  1
    order_0_22  connected_order_arc_505  1
    order_0_22  connected_order_arc_532  1
    order_0_22  connected_order_arc_559  1
    order_0_22  connected_order_arc_586  1
    order_0_22  connected_order_arc_613  1
    order_0_22  connected_order_arc_640  1
    order_0_22  connected_order_arc_667  1
    order_0_22  connected_order_arc_694  1
    order_0_22  connected_order_arc_721  1
    order_0_22  connected_order_arc_748  1
    order_0_22  connected_order_arc_751  -1
    order_0_22  connected_order_arc_753  -1
    order_0_22  connected_order_arc_755  -1
    order_0_22  connected_order_arc_757  -1
    order_0_22  connected_order_arc_759  -1
    order_0_22  connected_order_arc_761  -1
    order_0_22  connected_order_arc_763  -1
    order_0_22  connected_order_arc_765  -1
    order_0_22  connected_order_arc_767  -1
    order_0_22  connected_order_arc_769  -1
    order_0_22  connected_order_arc_771  -1
    order_0_22  connected_order_arc_773  -1
    order_0_22  connected_order_arc_775  -1
    order_0_22  order_active_lb_864  1
    order_0_22  order_active_ub_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_383  -20
    arc_0_0_0  depot_departure_or_bypass_776  1
    arc_0_0_0  depot_return_or_bypass_777  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_383  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_384  -20
    arc_0_0_1  depot_departure_or_bypass_776  1
    arc_0_0_1  in_degree_779  1
    arc_0_0_1  original_T_including_depot_unload_873  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_384  1
    load_0_0_1  segment_load_conservation_782  -1
    load_0_0_1  segment_prefix_lb_783  1
    load_0_0_1  segment_prefix_ub_784  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_385  -20
    arc_0_0_2  depot_departure_or_bypass_776  1
    arc_0_0_2  in_degree_786  1
    arc_0_0_2  original_T_including_depot_unload_873  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_385  1
    load_0_0_2  segment_load_conservation_789  -1
    load_0_0_2  segment_prefix_lb_790  1
    load_0_0_2  segment_prefix_ub_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_386  -20
    arc_0_0_3  depot_departure_or_bypass_776  1
    arc_0_0_3  in_degree_793  1
    arc_0_0_3  original_T_including_depot_unload_873  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_386  1
    load_0_0_3  segment_load_conservation_796  -1
    load_0_0_3  segment_prefix_lb_797  1
    load_0_0_3  segment_prefix_ub_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_387  -20
    arc_0_0_4  depot_departure_or_bypass_776  1
    arc_0_0_4  in_degree_800  1
    arc_0_0_4  original_T_including_depot_unload_873  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_387  1
    load_0_0_4  segment_load_conservation_803  -1
    load_0_0_4  segment_prefix_lb_804  1
    load_0_0_4  segment_prefix_ub_805  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_388  -20
    arc_0_0_5  depot_departure_or_bypass_776  1
    arc_0_0_5  in_degree_807  1
    arc_0_0_5  original_T_including_depot_unload_873  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_388  1
    load_0_0_5  segment_load_conservation_810  -1
    load_0_0_5  segment_prefix_lb_811  1
    load_0_0_5  segment_prefix_ub_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_389  -20
    arc_0_0_6  depot_departure_or_bypass_776  1
    arc_0_0_6  in_degree_814  1
    arc_0_0_6  original_T_including_depot_unload_873  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_389  1
    load_0_0_6  segment_load_conservation_817  -1
    load_0_0_6  segment_prefix_lb_818  1
    load_0_0_6  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_390  -20
    arc_0_0_15  depot_departure_or_bypass_776  1
    arc_0_0_15  in_degree_821  1
    arc_0_0_15  original_T_including_depot_unload_873  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_390  1
    load_0_0_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_391  -20
    arc_0_0_16  depot_departure_or_bypass_776  1
    arc_0_0_16  in_degree_827  1
    arc_0_0_16  original_T_including_depot_unload_873  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_391  1
    load_0_0_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_392  -20
    arc_0_0_17  depot_departure_or_bypass_776  1
    arc_0_0_17  in_degree_833  1
    arc_0_0_17  original_T_including_depot_unload_873  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_392  1
    load_0_0_17  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_393  -20
    arc_0_0_18  depot_departure_or_bypass_776  1
    arc_0_0_18  in_degree_839  1
    arc_0_0_18  original_T_including_depot_unload_873  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_393  1
    load_0_0_18  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_394  -20
    arc_0_0_19  depot_departure_or_bypass_776  1
    arc_0_0_19  in_degree_845  1
    arc_0_0_19  original_T_including_depot_unload_873  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_394  1
    load_0_0_19  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_395  -20
    arc_0_0_20  depot_departure_or_bypass_776  1
    arc_0_0_20  in_degree_851  1
    arc_0_0_20  original_T_including_depot_unload_873  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_395  1
    load_0_0_20  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_396  -20
    arc_0_0_21  depot_departure_or_bypass_776  1
    arc_0_0_21  in_degree_857  1
    arc_0_0_21  original_T_including_depot_unload_873  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_396  1
    load_0_0_21  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_22  arc_capacity_397  -20
    arc_0_0_22  depot_departure_or_bypass_776  1
    arc_0_0_22  in_degree_863  1
    arc_0_0_22  original_T_including_depot_unload_873  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_22  arc_capacity_397  1
    load_0_0_22  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_398  -20
    arc_0_1_0  depot_return_or_bypass_777  1
    arc_0_1_0  out_degree_778  1
    arc_0_1_0  original_T_including_depot_unload_873  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_398  1
    load_0_1_0  segment_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_399  -20
    arc_0_1_2  connected_order_arc_400  -15
    arc_0_1_2  out_degree_778  1
    arc_0_1_2  in_degree_786  1
    arc_0_1_2  original_T_including_depot_unload_873  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_399  1
    load_0_1_2  segment_load_conservation_782  1
    load_0_1_2  segment_load_conservation_789  -1
    load_0_1_2  segment_prefix_lb_790  1
    load_0_1_2  segment_prefix_ub_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_401  -20
    arc_0_1_3  connected_order_arc_402  -15
    arc_0_1_3  out_degree_778  1
    arc_0_1_3  in_degree_793  1
    arc_0_1_3  original_T_including_depot_unload_873  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_401  1
    load_0_1_3  segment_load_conservation_782  1
    load_0_1_3  segment_load_conservation_796  -1
    load_0_1_3  segment_prefix_lb_797  1
    load_0_1_3  segment_prefix_ub_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_403  -20
    arc_0_1_4  connected_order_arc_404  -15
    arc_0_1_4  out_degree_778  1
    arc_0_1_4  in_degree_800  1
    arc_0_1_4  original_T_including_depot_unload_873  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_403  1
    load_0_1_4  segment_load_conservation_782  1
    load_0_1_4  segment_load_conservation_803  -1
    load_0_1_4  segment_prefix_lb_804  1
    load_0_1_4  segment_prefix_ub_805  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_405  -20
    arc_0_1_5  connected_order_arc_406  -15
    arc_0_1_5  out_degree_778  1
    arc_0_1_5  in_degree_807  1
    arc_0_1_5  original_T_including_depot_unload_873  7.5688558078083690e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_405  1
    load_0_1_5  segment_load_conservation_782  1
    load_0_1_5  segment_load_conservation_810  -1
    load_0_1_5  segment_prefix_lb_811  1
    load_0_1_5  segment_prefix_ub_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_407  -20
    arc_0_1_6  connected_order_arc_408  -15
    arc_0_1_6  out_degree_778  1
    arc_0_1_6  in_degree_814  1
    arc_0_1_6  original_T_including_depot_unload_873  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_407  1
    load_0_1_6  segment_load_conservation_782  1
    load_0_1_6  segment_load_conservation_817  -1
    load_0_1_6  segment_prefix_lb_818  1
    load_0_1_6  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_409  -20
    arc_0_1_15  connected_order_arc_410  -15
    arc_0_1_15  out_degree_778  1
    arc_0_1_15  in_degree_821  1
    arc_0_1_15  original_T_including_depot_unload_873  1.7022035239152008e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_409  1
    load_0_1_15  segment_load_conservation_782  1
    load_0_1_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_411  -20
    arc_0_1_16  connected_order_arc_412  -15
    arc_0_1_16  out_degree_778  1
    arc_0_1_16  in_degree_827  1
    arc_0_1_16  original_T_including_depot_unload_873  1.8805180645589260e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_411  1
    load_0_1_16  segment_load_conservation_782  1
    load_0_1_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_413  -20
    arc_0_1_17  connected_order_arc_414  -15
    arc_0_1_17  out_degree_778  1
    arc_0_1_17  in_degree_833  1
    arc_0_1_17  original_T_including_depot_unload_873  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_413  1
    load_0_1_17  segment_load_conservation_782  1
    load_0_1_17  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_415  -20
    arc_0_1_18  connected_order_arc_416  -15
    arc_0_1_18  out_degree_778  1
    arc_0_1_18  in_degree_839  1
    arc_0_1_18  original_T_including_depot_unload_873  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_415  1
    load_0_1_18  segment_load_conservation_782  1
    load_0_1_18  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_417  -20
    arc_0_1_19  connected_order_arc_418  -15
    arc_0_1_19  out_degree_778  1
    arc_0_1_19  in_degree_845  1
    arc_0_1_19  original_T_including_depot_unload_873  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_417  1
    load_0_1_19  segment_load_conservation_782  1
    load_0_1_19  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_419  -20
    arc_0_1_20  connected_order_arc_420  -15
    arc_0_1_20  out_degree_778  1
    arc_0_1_20  in_degree_851  1
    arc_0_1_20  original_T_including_depot_unload_873  1.5552905028977075e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_419  1
    load_0_1_20  segment_load_conservation_782  1
    load_0_1_20  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_421  -20
    arc_0_1_21  connected_order_arc_422  -15
    arc_0_1_21  out_degree_778  1
    arc_0_1_21  in_degree_857  1
    arc_0_1_21  original_T_including_depot_unload_873  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_421  1
    load_0_1_21  segment_load_conservation_782  1
    load_0_1_21  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_22  arc_capacity_423  -20
    arc_0_1_22  connected_order_arc_424  -15
    arc_0_1_22  out_degree_778  1
    arc_0_1_22  in_degree_863  1
    arc_0_1_22  original_T_including_depot_unload_873  9.6620394708383776e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_22  arc_capacity_423  1
    load_0_1_22  segment_load_conservation_782  1
    load_0_1_22  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_425  -20
    arc_0_2_0  depot_return_or_bypass_777  1
    arc_0_2_0  out_degree_785  1
    arc_0_2_0  original_T_including_depot_unload_873  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_425  1
    load_0_2_0  segment_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_426  -20
    arc_0_2_1  connected_order_arc_427  -15
    arc_0_2_1  in_degree_779  1
    arc_0_2_1  out_degree_785  1
    arc_0_2_1  original_T_including_depot_unload_873  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_426  1
    load_0_2_1  segment_load_conservation_782  -1
    load_0_2_1  segment_prefix_lb_783  1
    load_0_2_1  segment_prefix_ub_784  1
    load_0_2_1  segment_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_428  -20
    arc_0_2_3  connected_order_arc_429  -15
    arc_0_2_3  out_degree_785  1
    arc_0_2_3  in_degree_793  1
    arc_0_2_3  original_T_including_depot_unload_873  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_428  1
    load_0_2_3  segment_load_conservation_789  1
    load_0_2_3  segment_load_conservation_796  -1
    load_0_2_3  segment_prefix_lb_797  1
    load_0_2_3  segment_prefix_ub_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_430  -20
    arc_0_2_4  connected_order_arc_431  -15
    arc_0_2_4  out_degree_785  1
    arc_0_2_4  in_degree_800  1
    arc_0_2_4  original_T_including_depot_unload_873  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_430  1
    load_0_2_4  segment_load_conservation_789  1
    load_0_2_4  segment_load_conservation_803  -1
    load_0_2_4  segment_prefix_lb_804  1
    load_0_2_4  segment_prefix_ub_805  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_432  -20
    arc_0_2_5  connected_order_arc_433  -15
    arc_0_2_5  out_degree_785  1
    arc_0_2_5  in_degree_807  1
    arc_0_2_5  original_T_including_depot_unload_873  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_432  1
    load_0_2_5  segment_load_conservation_789  1
    load_0_2_5  segment_load_conservation_810  -1
    load_0_2_5  segment_prefix_lb_811  1
    load_0_2_5  segment_prefix_ub_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_434  -20
    arc_0_2_6  connected_order_arc_435  -15
    arc_0_2_6  out_degree_785  1
    arc_0_2_6  in_degree_814  1
    arc_0_2_6  original_T_including_depot_unload_873  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_434  1
    load_0_2_6  segment_load_conservation_789  1
    load_0_2_6  segment_load_conservation_817  -1
    load_0_2_6  segment_prefix_lb_818  1
    load_0_2_6  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_436  -20
    arc_0_2_15  connected_order_arc_437  -15
    arc_0_2_15  out_degree_785  1
    arc_0_2_15  in_degree_821  1
    arc_0_2_15  original_T_including_depot_unload_873  1.5362659379368008e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_436  1
    load_0_2_15  segment_load_conservation_789  1
    load_0_2_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_438  -20
    arc_0_2_16  connected_order_arc_439  -15
    arc_0_2_16  out_degree_785  1
    arc_0_2_16  in_degree_827  1
    arc_0_2_16  original_T_including_depot_unload_873  1.7155529120526971e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_438  1
    load_0_2_16  segment_load_conservation_789  1
    load_0_2_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_440  -20
    arc_0_2_17  connected_order_arc_441  -15
    arc_0_2_17  out_degree_785  1
    arc_0_2_17  in_degree_833  1
    arc_0_2_17  original_T_including_depot_unload_873  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_440  1
    load_0_2_17  segment_load_conservation_789  1
    load_0_2_17  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_442  -20
    arc_0_2_18  connected_order_arc_443  -15
    arc_0_2_18  out_degree_785  1
    arc_0_2_18  in_degree_839  1
    arc_0_2_18  original_T_including_depot_unload_873  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_442  1
    load_0_2_18  segment_load_conservation_789  1
    load_0_2_18  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_444  -20
    arc_0_2_19  connected_order_arc_445  -15
    arc_0_2_19  out_degree_785  1
    arc_0_2_19  in_degree_845  1
    arc_0_2_19  original_T_including_depot_unload_873  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_444  1
    load_0_2_19  segment_load_conservation_789  1
    load_0_2_19  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_446  -20
    arc_0_2_20  connected_order_arc_447  -15
    arc_0_2_20  out_degree_785  1
    arc_0_2_20  in_degree_851  1
    arc_0_2_20  original_T_including_depot_unload_873  1.3812305438169078e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_446  1
    load_0_2_20  segment_load_conservation_789  1
    load_0_2_20  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_448  -20
    arc_0_2_21  connected_order_arc_449  -15
    arc_0_2_21  out_degree_785  1
    arc_0_2_21  in_degree_857  1
    arc_0_2_21  original_T_including_depot_unload_873  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_448  1
    load_0_2_21  segment_load_conservation_789  1
    load_0_2_21  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_22  arc_capacity_450  -20
    arc_0_2_22  connected_order_arc_451  -15
    arc_0_2_22  out_degree_785  1
    arc_0_2_22  in_degree_863  1
    arc_0_2_22  original_T_including_depot_unload_873  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_22  arc_capacity_450  1
    load_0_2_22  segment_load_conservation_789  1
    load_0_2_22  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_452  -20
    arc_0_3_0  depot_return_or_bypass_777  1
    arc_0_3_0  out_degree_792  1
    arc_0_3_0  original_T_including_depot_unload_873  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_452  1
    load_0_3_0  segment_load_conservation_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_453  -20
    arc_0_3_1  connected_order_arc_454  -15
    arc_0_3_1  in_degree_779  1
    arc_0_3_1  out_degree_792  1
    arc_0_3_1  original_T_including_depot_unload_873  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_453  1
    load_0_3_1  segment_load_conservation_782  -1
    load_0_3_1  segment_prefix_lb_783  1
    load_0_3_1  segment_prefix_ub_784  1
    load_0_3_1  segment_load_conservation_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_455  -20
    arc_0_3_2  connected_order_arc_456  -15
    arc_0_3_2  in_degree_786  1
    arc_0_3_2  out_degree_792  1
    arc_0_3_2  original_T_including_depot_unload_873  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_455  1
    load_0_3_2  segment_load_conservation_789  -1
    load_0_3_2  segment_prefix_lb_790  1
    load_0_3_2  segment_prefix_ub_791  1
    load_0_3_2  segment_load_conservation_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_457  -20
    arc_0_3_4  connected_order_arc_458  -15
    arc_0_3_4  out_degree_792  1
    arc_0_3_4  in_degree_800  1
    arc_0_3_4  original_T_including_depot_unload_873  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_457  1
    load_0_3_4  segment_load_conservation_796  1
    load_0_3_4  segment_load_conservation_803  -1
    load_0_3_4  segment_prefix_lb_804  1
    load_0_3_4  segment_prefix_ub_805  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_459  -20
    arc_0_3_5  connected_order_arc_460  -15
    arc_0_3_5  out_degree_792  1
    arc_0_3_5  in_degree_807  1
    arc_0_3_5  original_T_including_depot_unload_873  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_459  1
    load_0_3_5  segment_load_conservation_796  1
    load_0_3_5  segment_load_conservation_810  -1
    load_0_3_5  segment_prefix_lb_811  1
    load_0_3_5  segment_prefix_ub_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_461  -20
    arc_0_3_6  connected_order_arc_462  -15
    arc_0_3_6  out_degree_792  1
    arc_0_3_6  in_degree_814  1
    arc_0_3_6  original_T_including_depot_unload_873  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_461  1
    load_0_3_6  segment_load_conservation_796  1
    load_0_3_6  segment_load_conservation_817  -1
    load_0_3_6  segment_prefix_lb_818  1
    load_0_3_6  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_463  -20
    arc_0_3_15  connected_order_arc_464  -15
    arc_0_3_15  out_degree_792  1
    arc_0_3_15  in_degree_821  1
    arc_0_3_15  original_T_including_depot_unload_873  1.6185675384860760e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_463  1
    load_0_3_15  segment_load_conservation_796  1
    load_0_3_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_465  -20
    arc_0_3_16  connected_order_arc_466  -15
    arc_0_3_16  out_degree_792  1
    arc_0_3_16  in_degree_827  1
    arc_0_3_16  original_T_including_depot_unload_873  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_465  1
    load_0_3_16  segment_load_conservation_796  1
    load_0_3_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_467  -20
    arc_0_3_17  connected_order_arc_468  -15
    arc_0_3_17  out_degree_792  1
    arc_0_3_17  in_degree_833  1
    arc_0_3_17  original_T_including_depot_unload_873  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_467  1
    load_0_3_17  segment_load_conservation_796  1
    load_0_3_17  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_469  -20
    arc_0_3_18  connected_order_arc_470  -15
    arc_0_3_18  out_degree_792  1
    arc_0_3_18  in_degree_839  1
    arc_0_3_18  original_T_including_depot_unload_873  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_469  1
    load_0_3_18  segment_load_conservation_796  1
    load_0_3_18  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_471  -20
    arc_0_3_19  connected_order_arc_472  -15
    arc_0_3_19  out_degree_792  1
    arc_0_3_19  in_degree_845  1
    arc_0_3_19  original_T_including_depot_unload_873  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_471  1
    load_0_3_19  segment_load_conservation_796  1
    load_0_3_19  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_473  -20
    arc_0_3_20  connected_order_arc_474  -15
    arc_0_3_20  out_degree_792  1
    arc_0_3_20  in_degree_851  1
    arc_0_3_20  original_T_including_depot_unload_873  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_473  1
    load_0_3_20  segment_load_conservation_796  1
    load_0_3_20  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_475  -20
    arc_0_3_21  connected_order_arc_476  -15
    arc_0_3_21  out_degree_792  1
    arc_0_3_21  in_degree_857  1
    arc_0_3_21  original_T_including_depot_unload_873  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_475  1
    load_0_3_21  segment_load_conservation_796  1
    load_0_3_21  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_22  arc_capacity_477  -20
    arc_0_3_22  connected_order_arc_478  -15
    arc_0_3_22  out_degree_792  1
    arc_0_3_22  in_degree_863  1
    arc_0_3_22  original_T_including_depot_unload_873  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_22  arc_capacity_477  1
    load_0_3_22  segment_load_conservation_796  1
    load_0_3_22  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_479  -20
    arc_0_4_0  depot_return_or_bypass_777  1
    arc_0_4_0  out_degree_799  1
    arc_0_4_0  original_T_including_depot_unload_873  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_479  1
    load_0_4_0  segment_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_480  -20
    arc_0_4_1  connected_order_arc_481  -15
    arc_0_4_1  in_degree_779  1
    arc_0_4_1  out_degree_799  1
    arc_0_4_1  original_T_including_depot_unload_873  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_480  1
    load_0_4_1  segment_load_conservation_782  -1
    load_0_4_1  segment_prefix_lb_783  1
    load_0_4_1  segment_prefix_ub_784  1
    load_0_4_1  segment_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_482  -20
    arc_0_4_2  connected_order_arc_483  -15
    arc_0_4_2  in_degree_786  1
    arc_0_4_2  out_degree_799  1
    arc_0_4_2  original_T_including_depot_unload_873  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_482  1
    load_0_4_2  segment_load_conservation_789  -1
    load_0_4_2  segment_prefix_lb_790  1
    load_0_4_2  segment_prefix_ub_791  1
    load_0_4_2  segment_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_484  -20
    arc_0_4_3  connected_order_arc_485  -15
    arc_0_4_3  in_degree_793  1
    arc_0_4_3  out_degree_799  1
    arc_0_4_3  original_T_including_depot_unload_873  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_484  1
    load_0_4_3  segment_load_conservation_796  -1
    load_0_4_3  segment_prefix_lb_797  1
    load_0_4_3  segment_prefix_ub_798  1
    load_0_4_3  segment_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_486  -20
    arc_0_4_5  connected_order_arc_487  -15
    arc_0_4_5  out_degree_799  1
    arc_0_4_5  in_degree_807  1
    arc_0_4_5  original_T_including_depot_unload_873  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_486  1
    load_0_4_5  segment_load_conservation_803  1
    load_0_4_5  segment_load_conservation_810  -1
    load_0_4_5  segment_prefix_lb_811  1
    load_0_4_5  segment_prefix_ub_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_488  -20
    arc_0_4_6  connected_order_arc_489  -15
    arc_0_4_6  out_degree_799  1
    arc_0_4_6  in_degree_814  1
    arc_0_4_6  original_T_including_depot_unload_873  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_488  1
    load_0_4_6  segment_load_conservation_803  1
    load_0_4_6  segment_load_conservation_817  -1
    load_0_4_6  segment_prefix_lb_818  1
    load_0_4_6  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_490  -20
    arc_0_4_15  connected_order_arc_491  -15
    arc_0_4_15  out_degree_799  1
    arc_0_4_15  in_degree_821  1
    arc_0_4_15  original_T_including_depot_unload_873  1.3279253844180159e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_490  1
    load_0_4_15  segment_load_conservation_803  1
    load_0_4_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_492  -20
    arc_0_4_16  connected_order_arc_493  -15
    arc_0_4_16  out_degree_799  1
    arc_0_4_16  in_degree_827  1
    arc_0_4_16  original_T_including_depot_unload_873  1.5086201853425566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_492  1
    load_0_4_16  segment_load_conservation_803  1
    load_0_4_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_494  -20
    arc_0_4_17  connected_order_arc_495  -15
    arc_0_4_17  out_degree_799  1
    arc_0_4_17  in_degree_833  1
    arc_0_4_17  original_T_including_depot_unload_873  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_494  1
    load_0_4_17  segment_load_conservation_803  1
    load_0_4_17  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_496  -20
    arc_0_4_18  connected_order_arc_497  -15
    arc_0_4_18  out_degree_799  1
    arc_0_4_18  in_degree_839  1
    arc_0_4_18  original_T_including_depot_unload_873  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_496  1
    load_0_4_18  segment_load_conservation_803  1
    load_0_4_18  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_498  -20
    arc_0_4_19  connected_order_arc_499  -15
    arc_0_4_19  out_degree_799  1
    arc_0_4_19  in_degree_845  1
    arc_0_4_19  original_T_including_depot_unload_873  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_498  1
    load_0_4_19  segment_load_conservation_803  1
    load_0_4_19  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_500  -20
    arc_0_4_20  connected_order_arc_501  -15
    arc_0_4_20  out_degree_799  1
    arc_0_4_20  in_degree_851  1
    arc_0_4_20  original_T_including_depot_unload_873  1.0917254946216958e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_500  1
    load_0_4_20  segment_load_conservation_803  1
    load_0_4_20  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_502  -20
    arc_0_4_21  connected_order_arc_503  -15
    arc_0_4_21  out_degree_799  1
    arc_0_4_21  in_degree_857  1
    arc_0_4_21  original_T_including_depot_unload_873  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_502  1
    load_0_4_21  segment_load_conservation_803  1
    load_0_4_21  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_22  arc_capacity_504  -20
    arc_0_4_22  connected_order_arc_505  -15
    arc_0_4_22  out_degree_799  1
    arc_0_4_22  in_degree_863  1
    arc_0_4_22  original_T_including_depot_unload_873  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_22  arc_capacity_504  1
    load_0_4_22  segment_load_conservation_803  1
    load_0_4_22  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_506  -20
    arc_0_5_0  depot_return_or_bypass_777  1
    arc_0_5_0  out_degree_806  1
    arc_0_5_0  original_T_including_depot_unload_873  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_506  1
    load_0_5_0  segment_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_507  -20
    arc_0_5_1  connected_order_arc_508  -15
    arc_0_5_1  in_degree_779  1
    arc_0_5_1  out_degree_806  1
    arc_0_5_1  original_T_including_depot_unload_873  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_507  1
    load_0_5_1  segment_load_conservation_782  -1
    load_0_5_1  segment_prefix_lb_783  1
    load_0_5_1  segment_prefix_ub_784  1
    load_0_5_1  segment_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_509  -20
    arc_0_5_2  connected_order_arc_510  -15
    arc_0_5_2  in_degree_786  1
    arc_0_5_2  out_degree_806  1
    arc_0_5_2  original_T_including_depot_unload_873  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_509  1
    load_0_5_2  segment_load_conservation_789  -1
    load_0_5_2  segment_prefix_lb_790  1
    load_0_5_2  segment_prefix_ub_791  1
    load_0_5_2  segment_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_511  -20
    arc_0_5_3  connected_order_arc_512  -15
    arc_0_5_3  in_degree_793  1
    arc_0_5_3  out_degree_806  1
    arc_0_5_3  original_T_including_depot_unload_873  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_511  1
    load_0_5_3  segment_load_conservation_796  -1
    load_0_5_3  segment_prefix_lb_797  1
    load_0_5_3  segment_prefix_ub_798  1
    load_0_5_3  segment_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_513  -20
    arc_0_5_4  connected_order_arc_514  -15
    arc_0_5_4  in_degree_800  1
    arc_0_5_4  out_degree_806  1
    arc_0_5_4  original_T_including_depot_unload_873  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_513  1
    load_0_5_4  segment_load_conservation_803  -1
    load_0_5_4  segment_prefix_lb_804  1
    load_0_5_4  segment_prefix_ub_805  1
    load_0_5_4  segment_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_515  -20
    arc_0_5_6  connected_order_arc_516  -15
    arc_0_5_6  out_degree_806  1
    arc_0_5_6  in_degree_814  1
    arc_0_5_6  original_T_including_depot_unload_873  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_515  1
    load_0_5_6  segment_load_conservation_810  1
    load_0_5_6  segment_load_conservation_817  -1
    load_0_5_6  segment_prefix_lb_818  1
    load_0_5_6  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_517  -20
    arc_0_5_15  connected_order_arc_518  -15
    arc_0_5_15  out_degree_806  1
    arc_0_5_15  in_degree_821  1
    arc_0_5_15  original_T_including_depot_unload_873  1.0036317427965961e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_517  1
    load_0_5_15  segment_load_conservation_810  1
    load_0_5_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_519  -20
    arc_0_5_16  connected_order_arc_520  -15
    arc_0_5_16  out_degree_806  1
    arc_0_5_16  in_degree_827  1
    arc_0_5_16  original_T_including_depot_unload_873  1.1848225970179703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_519  1
    load_0_5_16  segment_load_conservation_810  1
    load_0_5_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_521  -20
    arc_0_5_17  connected_order_arc_522  -15
    arc_0_5_17  out_degree_806  1
    arc_0_5_17  in_degree_833  1
    arc_0_5_17  original_T_including_depot_unload_873  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_521  1
    load_0_5_17  segment_load_conservation_810  1
    load_0_5_17  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_523  -20
    arc_0_5_18  connected_order_arc_524  -15
    arc_0_5_18  out_degree_806  1
    arc_0_5_18  in_degree_839  1
    arc_0_5_18  original_T_including_depot_unload_873  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_523  1
    load_0_5_18  segment_load_conservation_810  1
    load_0_5_18  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_525  -20
    arc_0_5_19  connected_order_arc_526  -15
    arc_0_5_19  out_degree_806  1
    arc_0_5_19  in_degree_845  1
    arc_0_5_19  original_T_including_depot_unload_873  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_525  1
    load_0_5_19  segment_load_conservation_810  1
    load_0_5_19  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_527  -20
    arc_0_5_20  connected_order_arc_528  -15
    arc_0_5_20  out_degree_806  1
    arc_0_5_20  in_degree_851  1
    arc_0_5_20  original_T_including_depot_unload_873  8.0231446125927152e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_527  1
    load_0_5_20  segment_load_conservation_810  1
    load_0_5_20  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_529  -20
    arc_0_5_21  connected_order_arc_530  -15
    arc_0_5_21  out_degree_806  1
    arc_0_5_21  in_degree_857  1
    arc_0_5_21  original_T_including_depot_unload_873  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_529  1
    load_0_5_21  segment_load_conservation_810  1
    load_0_5_21  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_22  arc_capacity_531  -20
    arc_0_5_22  connected_order_arc_532  -15
    arc_0_5_22  out_degree_806  1
    arc_0_5_22  in_degree_863  1
    arc_0_5_22  original_T_including_depot_unload_873  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_22  arc_capacity_531  1
    load_0_5_22  segment_load_conservation_810  1
    load_0_5_22  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_533  -20
    arc_0_6_0  depot_return_or_bypass_777  1
    arc_0_6_0  out_degree_813  1
    arc_0_6_0  original_T_including_depot_unload_873  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_533  1
    load_0_6_0  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_534  -20
    arc_0_6_1  connected_order_arc_535  -15
    arc_0_6_1  in_degree_779  1
    arc_0_6_1  out_degree_813  1
    arc_0_6_1  original_T_including_depot_unload_873  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_534  1
    load_0_6_1  segment_load_conservation_782  -1
    load_0_6_1  segment_prefix_lb_783  1
    load_0_6_1  segment_prefix_ub_784  1
    load_0_6_1  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_536  -20
    arc_0_6_2  connected_order_arc_537  -15
    arc_0_6_2  in_degree_786  1
    arc_0_6_2  out_degree_813  1
    arc_0_6_2  original_T_including_depot_unload_873  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_536  1
    load_0_6_2  segment_load_conservation_789  -1
    load_0_6_2  segment_prefix_lb_790  1
    load_0_6_2  segment_prefix_ub_791  1
    load_0_6_2  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_538  -20
    arc_0_6_3  connected_order_arc_539  -15
    arc_0_6_3  in_degree_793  1
    arc_0_6_3  out_degree_813  1
    arc_0_6_3  original_T_including_depot_unload_873  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_538  1
    load_0_6_3  segment_load_conservation_796  -1
    load_0_6_3  segment_prefix_lb_797  1
    load_0_6_3  segment_prefix_ub_798  1
    load_0_6_3  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_540  -20
    arc_0_6_4  connected_order_arc_541  -15
    arc_0_6_4  in_degree_800  1
    arc_0_6_4  out_degree_813  1
    arc_0_6_4  original_T_including_depot_unload_873  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_540  1
    load_0_6_4  segment_load_conservation_803  -1
    load_0_6_4  segment_prefix_lb_804  1
    load_0_6_4  segment_prefix_ub_805  1
    load_0_6_4  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_542  -20
    arc_0_6_5  connected_order_arc_543  -15
    arc_0_6_5  in_degree_807  1
    arc_0_6_5  out_degree_813  1
    arc_0_6_5  original_T_including_depot_unload_873  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_542  1
    load_0_6_5  segment_load_conservation_810  -1
    load_0_6_5  segment_prefix_lb_811  1
    load_0_6_5  segment_prefix_ub_812  1
    load_0_6_5  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_544  -20
    arc_0_6_15  connected_order_arc_545  -15
    arc_0_6_15  out_degree_813  1
    arc_0_6_15  in_degree_821  1
    arc_0_6_15  original_T_including_depot_unload_873  8.6622936529310709e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_544  1
    load_0_6_15  segment_load_conservation_817  1
    load_0_6_15  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_546  -20
    arc_0_6_16  connected_order_arc_547  -15
    arc_0_6_16  out_degree_813  1
    arc_0_6_16  in_degree_827  1
    arc_0_6_16  original_T_including_depot_unload_873  1.0428195034234207e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_546  1
    load_0_6_16  segment_load_conservation_817  1
    load_0_6_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_17  arc_capacity_548  -20
    arc_0_6_17  connected_order_arc_549  -15
    arc_0_6_17  out_degree_813  1
    arc_0_6_17  in_degree_833  1
    arc_0_6_17  original_T_including_depot_unload_873  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_6_17  arc_capacity_548  1
    load_0_6_17  segment_load_conservation_817  1
    load_0_6_17  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_18  arc_capacity_550  -20
    arc_0_6_18  connected_order_arc_551  -15
    arc_0_6_18  out_degree_813  1
    arc_0_6_18  in_degree_839  1
    arc_0_6_18  original_T_including_depot_unload_873  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_18  arc_capacity_550  1
    load_0_6_18  segment_load_conservation_817  1
    load_0_6_18  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_19  arc_capacity_552  -20
    arc_0_6_19  connected_order_arc_553  -15
    arc_0_6_19  out_degree_813  1
    arc_0_6_19  in_degree_845  1
    arc_0_6_19  original_T_including_depot_unload_873  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_19  arc_capacity_552  1
    load_0_6_19  segment_load_conservation_817  1
    load_0_6_19  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_20  arc_capacity_554  -20
    arc_0_6_20  connected_order_arc_555  -15
    arc_0_6_20  out_degree_813  1
    arc_0_6_20  in_degree_851  1
    arc_0_6_20  original_T_including_depot_unload_873  7.8724938919046190e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_20  arc_capacity_554  1
    load_0_6_20  segment_load_conservation_817  1
    load_0_6_20  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_21  arc_capacity_556  -20
    arc_0_6_21  connected_order_arc_557  -15
    arc_0_6_21  out_degree_813  1
    arc_0_6_21  in_degree_857  1
    arc_0_6_21  original_T_including_depot_unload_873  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_21  arc_capacity_556  1
    load_0_6_21  segment_load_conservation_817  1
    load_0_6_21  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_22  arc_capacity_558  -20
    arc_0_6_22  connected_order_arc_559  -15
    arc_0_6_22  out_degree_813  1
    arc_0_6_22  in_degree_863  1
    arc_0_6_22  original_T_including_depot_unload_873  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_22  arc_capacity_558  1
    load_0_6_22  segment_load_conservation_817  1
    load_0_6_22  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_560  -20
    arc_0_15_0  depot_return_or_bypass_777  1
    arc_0_15_0  out_degree_820  1
    arc_0_15_0  original_T_including_depot_unload_873  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_560  1
    load_0_15_0  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_561  -20
    arc_0_15_1  connected_order_arc_562  -15
    arc_0_15_1  in_degree_779  1
    arc_0_15_1  out_degree_820  1
    arc_0_15_1  original_T_including_depot_unload_873  1.5346053834915313e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_561  1
    load_0_15_1  segment_load_conservation_782  -1
    load_0_15_1  segment_prefix_lb_783  1
    load_0_15_1  segment_prefix_ub_784  1
    load_0_15_1  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_563  -20
    arc_0_15_2  connected_order_arc_564  -15
    arc_0_15_2  in_degree_786  1
    arc_0_15_2  out_degree_820  1
    arc_0_15_2  original_T_including_depot_unload_873  1.5362659379368008e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_563  1
    load_0_15_2  segment_load_conservation_789  -1
    load_0_15_2  segment_prefix_lb_790  1
    load_0_15_2  segment_prefix_ub_791  1
    load_0_15_2  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_565  -20
    arc_0_15_3  connected_order_arc_566  -15
    arc_0_15_3  in_degree_793  1
    arc_0_15_3  out_degree_820  1
    arc_0_15_3  original_T_including_depot_unload_873  1.6185675384860760e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_565  1
    load_0_15_3  segment_load_conservation_796  -1
    load_0_15_3  segment_prefix_lb_797  1
    load_0_15_3  segment_prefix_ub_798  1
    load_0_15_3  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_567  -20
    arc_0_15_4  connected_order_arc_568  -15
    arc_0_15_4  in_degree_800  1
    arc_0_15_4  out_degree_820  1
    arc_0_15_4  original_T_including_depot_unload_873  1.3279253844180159e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_567  1
    load_0_15_4  segment_load_conservation_803  -1
    load_0_15_4  segment_prefix_lb_804  1
    load_0_15_4  segment_prefix_ub_805  1
    load_0_15_4  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_569  -20
    arc_0_15_5  connected_order_arc_570  -15
    arc_0_15_5  in_degree_807  1
    arc_0_15_5  out_degree_820  1
    arc_0_15_5  original_T_including_depot_unload_873  1.0036317427965961e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_569  1
    load_0_15_5  segment_load_conservation_810  -1
    load_0_15_5  segment_prefix_lb_811  1
    load_0_15_5  segment_prefix_ub_812  1
    load_0_15_5  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_571  -20
    arc_0_15_6  connected_order_arc_572  -15
    arc_0_15_6  in_degree_814  1
    arc_0_15_6  out_degree_820  1
    arc_0_15_6  original_T_including_depot_unload_873  8.6622936529310709e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_571  1
    load_0_15_6  segment_load_conservation_817  -1
    load_0_15_6  segment_prefix_lb_818  1
    load_0_15_6  segment_prefix_ub_819  1
    load_0_15_6  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_573  -20
    arc_0_15_16  connected_order_arc_574  -15
    arc_0_15_16  out_degree_820  1
    arc_0_15_16  in_degree_827  1
    arc_0_15_16  original_T_including_depot_unload_873  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_573  1
    load_0_15_16  free_load_conservation_825  1
    load_0_15_16  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_575  -20
    arc_0_15_17  connected_order_arc_576  -15
    arc_0_15_17  out_degree_820  1
    arc_0_15_17  in_degree_833  1
    arc_0_15_17  original_T_including_depot_unload_873  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_575  1
    load_0_15_17  free_load_conservation_825  1
    load_0_15_17  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_577  -20
    arc_0_15_18  connected_order_arc_578  -15
    arc_0_15_18  out_degree_820  1
    arc_0_15_18  in_degree_839  1
    arc_0_15_18  original_T_including_depot_unload_873  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_577  1
    load_0_15_18  free_load_conservation_825  1
    load_0_15_18  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_579  -20
    arc_0_15_19  connected_order_arc_580  -15
    arc_0_15_19  out_degree_820  1
    arc_0_15_19  in_degree_845  1
    arc_0_15_19  original_T_including_depot_unload_873  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_579  1
    load_0_15_19  free_load_conservation_825  1
    load_0_15_19  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_581  -20
    arc_0_15_20  connected_order_arc_582  -15
    arc_0_15_20  out_degree_820  1
    arc_0_15_20  in_degree_851  1
    arc_0_15_20  original_T_including_depot_unload_873  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_581  1
    load_0_15_20  free_load_conservation_825  1
    load_0_15_20  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_583  -20
    arc_0_15_21  connected_order_arc_584  -15
    arc_0_15_21  out_degree_820  1
    arc_0_15_21  in_degree_857  1
    arc_0_15_21  original_T_including_depot_unload_873  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_583  1
    load_0_15_21  free_load_conservation_825  1
    load_0_15_21  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_22  arc_capacity_585  -20
    arc_0_15_22  connected_order_arc_586  -15
    arc_0_15_22  out_degree_820  1
    arc_0_15_22  in_degree_863  1
    arc_0_15_22  original_T_including_depot_unload_873  7.9829177317292124e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_22  arc_capacity_585  1
    load_0_15_22  free_load_conservation_825  1
    load_0_15_22  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_587  -20
    arc_0_16_0  depot_return_or_bypass_777  1
    arc_0_16_0  out_degree_826  1
    arc_0_16_0  original_T_including_depot_unload_873  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_587  1
    load_0_16_0  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_588  -20
    arc_0_16_1  connected_order_arc_589  -15
    arc_0_16_1  in_degree_779  1
    arc_0_16_1  out_degree_826  1
    arc_0_16_1  original_T_including_depot_unload_873  1.7069358358556344e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_588  1
    load_0_16_1  segment_load_conservation_782  -1
    load_0_16_1  segment_prefix_lb_783  1
    load_0_16_1  segment_prefix_ub_784  1
    load_0_16_1  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_590  -20
    arc_0_16_2  connected_order_arc_591  -15
    arc_0_16_2  in_degree_786  1
    arc_0_16_2  out_degree_826  1
    arc_0_16_2  original_T_including_depot_unload_873  1.7155529120526971e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_590  1
    load_0_16_2  segment_load_conservation_789  -1
    load_0_16_2  segment_prefix_lb_790  1
    load_0_16_2  segment_prefix_ub_791  1
    load_0_16_2  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_592  -20
    arc_0_16_3  connected_order_arc_593  -15
    arc_0_16_3  in_degree_793  1
    arc_0_16_3  out_degree_826  1
    arc_0_16_3  original_T_including_depot_unload_873  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_592  1
    load_0_16_3  segment_load_conservation_796  -1
    load_0_16_3  segment_prefix_lb_797  1
    load_0_16_3  segment_prefix_ub_798  1
    load_0_16_3  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_594  -20
    arc_0_16_4  connected_order_arc_595  -15
    arc_0_16_4  in_degree_800  1
    arc_0_16_4  out_degree_826  1
    arc_0_16_4  original_T_including_depot_unload_873  1.5086201853425566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_594  1
    load_0_16_4  segment_load_conservation_803  -1
    load_0_16_4  segment_prefix_lb_804  1
    load_0_16_4  segment_prefix_ub_805  1
    load_0_16_4  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_596  -20
    arc_0_16_5  connected_order_arc_597  -15
    arc_0_16_5  in_degree_807  1
    arc_0_16_5  out_degree_826  1
    arc_0_16_5  original_T_including_depot_unload_873  1.1848225970179703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_596  1
    load_0_16_5  segment_load_conservation_810  -1
    load_0_16_5  segment_prefix_lb_811  1
    load_0_16_5  segment_prefix_ub_812  1
    load_0_16_5  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_598  -20
    arc_0_16_6  connected_order_arc_599  -15
    arc_0_16_6  in_degree_814  1
    arc_0_16_6  out_degree_826  1
    arc_0_16_6  original_T_including_depot_unload_873  1.0428195034234207e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_598  1
    load_0_16_6  segment_load_conservation_817  -1
    load_0_16_6  segment_prefix_lb_818  1
    load_0_16_6  segment_prefix_ub_819  1
    load_0_16_6  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_600  -20
    arc_0_16_15  connected_order_arc_601  -15
    arc_0_16_15  in_degree_821  1
    arc_0_16_15  out_degree_826  1
    arc_0_16_15  original_T_including_depot_unload_873  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_600  1
    load_0_16_15  free_load_conservation_825  -1
    load_0_16_15  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_602  -20
    arc_0_16_17  connected_order_arc_603  -15
    arc_0_16_17  out_degree_826  1
    arc_0_16_17  in_degree_833  1
    arc_0_16_17  original_T_including_depot_unload_873  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_602  1
    load_0_16_17  free_load_conservation_831  1
    load_0_16_17  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_604  -20
    arc_0_16_18  connected_order_arc_605  -15
    arc_0_16_18  out_degree_826  1
    arc_0_16_18  in_degree_839  1
    arc_0_16_18  original_T_including_depot_unload_873  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_604  1
    load_0_16_18  free_load_conservation_831  1
    load_0_16_18  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_606  -20
    arc_0_16_19  connected_order_arc_607  -15
    arc_0_16_19  out_degree_826  1
    arc_0_16_19  in_degree_845  1
    arc_0_16_19  original_T_including_depot_unload_873  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_606  1
    load_0_16_19  free_load_conservation_831  1
    load_0_16_19  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_608  -20
    arc_0_16_20  connected_order_arc_609  -15
    arc_0_16_20  out_degree_826  1
    arc_0_16_20  in_degree_851  1
    arc_0_16_20  original_T_including_depot_unload_873  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_608  1
    load_0_16_20  free_load_conservation_831  1
    load_0_16_20  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_610  -20
    arc_0_16_21  connected_order_arc_611  -15
    arc_0_16_21  out_degree_826  1
    arc_0_16_21  in_degree_857  1
    arc_0_16_21  original_T_including_depot_unload_873  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_610  1
    load_0_16_21  free_load_conservation_831  1
    load_0_16_21  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_22  arc_capacity_612  -20
    arc_0_16_22  connected_order_arc_613  -15
    arc_0_16_22  out_degree_826  1
    arc_0_16_22  in_degree_863  1
    arc_0_16_22  original_T_including_depot_unload_873  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_22  arc_capacity_612  1
    load_0_16_22  free_load_conservation_831  1
    load_0_16_22  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_614  -20
    arc_0_17_0  depot_return_or_bypass_777  1
    arc_0_17_0  out_degree_832  1
    arc_0_17_0  original_T_including_depot_unload_873  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_614  1
    load_0_17_0  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_615  -20
    arc_0_17_1  connected_order_arc_616  -15
    arc_0_17_1  in_degree_779  1
    arc_0_17_1  out_degree_832  1
    arc_0_17_1  original_T_including_depot_unload_873  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_615  1
    load_0_17_1  segment_load_conservation_782  -1
    load_0_17_1  segment_prefix_lb_783  1
    load_0_17_1  segment_prefix_ub_784  1
    load_0_17_1  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_617  -20
    arc_0_17_2  connected_order_arc_618  -15
    arc_0_17_2  in_degree_786  1
    arc_0_17_2  out_degree_832  1
    arc_0_17_2  original_T_including_depot_unload_873  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_617  1
    load_0_17_2  segment_load_conservation_789  -1
    load_0_17_2  segment_prefix_lb_790  1
    load_0_17_2  segment_prefix_ub_791  1
    load_0_17_2  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_619  -20
    arc_0_17_3  connected_order_arc_620  -15
    arc_0_17_3  in_degree_793  1
    arc_0_17_3  out_degree_832  1
    arc_0_17_3  original_T_including_depot_unload_873  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_619  1
    load_0_17_3  segment_load_conservation_796  -1
    load_0_17_3  segment_prefix_lb_797  1
    load_0_17_3  segment_prefix_ub_798  1
    load_0_17_3  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_621  -20
    arc_0_17_4  connected_order_arc_622  -15
    arc_0_17_4  in_degree_800  1
    arc_0_17_4  out_degree_832  1
    arc_0_17_4  original_T_including_depot_unload_873  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_621  1
    load_0_17_4  segment_load_conservation_803  -1
    load_0_17_4  segment_prefix_lb_804  1
    load_0_17_4  segment_prefix_ub_805  1
    load_0_17_4  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_623  -20
    arc_0_17_5  connected_order_arc_624  -15
    arc_0_17_5  in_degree_807  1
    arc_0_17_5  out_degree_832  1
    arc_0_17_5  original_T_including_depot_unload_873  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_623  1
    load_0_17_5  segment_load_conservation_810  -1
    load_0_17_5  segment_prefix_lb_811  1
    load_0_17_5  segment_prefix_ub_812  1
    load_0_17_5  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_6  arc_capacity_625  -20
    arc_0_17_6  connected_order_arc_626  -15
    arc_0_17_6  in_degree_814  1
    arc_0_17_6  out_degree_832  1
    arc_0_17_6  original_T_including_depot_unload_873  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_17_6  arc_capacity_625  1
    load_0_17_6  segment_load_conservation_817  -1
    load_0_17_6  segment_prefix_lb_818  1
    load_0_17_6  segment_prefix_ub_819  1
    load_0_17_6  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_627  -20
    arc_0_17_15  connected_order_arc_628  -15
    arc_0_17_15  in_degree_821  1
    arc_0_17_15  out_degree_832  1
    arc_0_17_15  original_T_including_depot_unload_873  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_627  1
    load_0_17_15  free_load_conservation_825  -1
    load_0_17_15  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_629  -20
    arc_0_17_16  connected_order_arc_630  -15
    arc_0_17_16  in_degree_827  1
    arc_0_17_16  out_degree_832  1
    arc_0_17_16  original_T_including_depot_unload_873  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_629  1
    load_0_17_16  free_load_conservation_831  -1
    load_0_17_16  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_631  -20
    arc_0_17_18  connected_order_arc_632  -15
    arc_0_17_18  out_degree_832  1
    arc_0_17_18  in_degree_839  1
    arc_0_17_18  original_T_including_depot_unload_873  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_631  1
    load_0_17_18  free_load_conservation_837  1
    load_0_17_18  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_633  -20
    arc_0_17_19  connected_order_arc_634  -15
    arc_0_17_19  out_degree_832  1
    arc_0_17_19  in_degree_845  1
    arc_0_17_19  original_T_including_depot_unload_873  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_633  1
    load_0_17_19  free_load_conservation_837  1
    load_0_17_19  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_635  -20
    arc_0_17_20  connected_order_arc_636  -15
    arc_0_17_20  out_degree_832  1
    arc_0_17_20  in_degree_851  1
    arc_0_17_20  original_T_including_depot_unload_873  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_635  1
    load_0_17_20  free_load_conservation_837  1
    load_0_17_20  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_637  -20
    arc_0_17_21  connected_order_arc_638  -15
    arc_0_17_21  out_degree_832  1
    arc_0_17_21  in_degree_857  1
    arc_0_17_21  original_T_including_depot_unload_873  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_637  1
    load_0_17_21  free_load_conservation_837  1
    load_0_17_21  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_22  arc_capacity_639  -20
    arc_0_17_22  connected_order_arc_640  -15
    arc_0_17_22  out_degree_832  1
    arc_0_17_22  in_degree_863  1
    arc_0_17_22  original_T_including_depot_unload_873  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_22  arc_capacity_639  1
    load_0_17_22  free_load_conservation_837  1
    load_0_17_22  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_641  -20
    arc_0_18_0  depot_return_or_bypass_777  1
    arc_0_18_0  out_degree_838  1
    arc_0_18_0  original_T_including_depot_unload_873  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_641  1
    load_0_18_0  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_642  -20
    arc_0_18_1  connected_order_arc_643  -15
    arc_0_18_1  in_degree_779  1
    arc_0_18_1  out_degree_838  1
    arc_0_18_1  original_T_including_depot_unload_873  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_642  1
    load_0_18_1  segment_load_conservation_782  -1
    load_0_18_1  segment_prefix_lb_783  1
    load_0_18_1  segment_prefix_ub_784  1
    load_0_18_1  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_644  -20
    arc_0_18_2  connected_order_arc_645  -15
    arc_0_18_2  in_degree_786  1
    arc_0_18_2  out_degree_838  1
    arc_0_18_2  original_T_including_depot_unload_873  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_644  1
    load_0_18_2  segment_load_conservation_789  -1
    load_0_18_2  segment_prefix_lb_790  1
    load_0_18_2  segment_prefix_ub_791  1
    load_0_18_2  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_646  -20
    arc_0_18_3  connected_order_arc_647  -15
    arc_0_18_3  in_degree_793  1
    arc_0_18_3  out_degree_838  1
    arc_0_18_3  original_T_including_depot_unload_873  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_646  1
    load_0_18_3  segment_load_conservation_796  -1
    load_0_18_3  segment_prefix_lb_797  1
    load_0_18_3  segment_prefix_ub_798  1
    load_0_18_3  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_648  -20
    arc_0_18_4  connected_order_arc_649  -15
    arc_0_18_4  in_degree_800  1
    arc_0_18_4  out_degree_838  1
    arc_0_18_4  original_T_including_depot_unload_873  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_648  1
    load_0_18_4  segment_load_conservation_803  -1
    load_0_18_4  segment_prefix_lb_804  1
    load_0_18_4  segment_prefix_ub_805  1
    load_0_18_4  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_650  -20
    arc_0_18_5  connected_order_arc_651  -15
    arc_0_18_5  in_degree_807  1
    arc_0_18_5  out_degree_838  1
    arc_0_18_5  original_T_including_depot_unload_873  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_650  1
    load_0_18_5  segment_load_conservation_810  -1
    load_0_18_5  segment_prefix_lb_811  1
    load_0_18_5  segment_prefix_ub_812  1
    load_0_18_5  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_6  arc_capacity_652  -20
    arc_0_18_6  connected_order_arc_653  -15
    arc_0_18_6  in_degree_814  1
    arc_0_18_6  out_degree_838  1
    arc_0_18_6  original_T_including_depot_unload_873  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_6  arc_capacity_652  1
    load_0_18_6  segment_load_conservation_817  -1
    load_0_18_6  segment_prefix_lb_818  1
    load_0_18_6  segment_prefix_ub_819  1
    load_0_18_6  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_654  -20
    arc_0_18_15  connected_order_arc_655  -15
    arc_0_18_15  in_degree_821  1
    arc_0_18_15  out_degree_838  1
    arc_0_18_15  original_T_including_depot_unload_873  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_654  1
    load_0_18_15  free_load_conservation_825  -1
    load_0_18_15  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_656  -20
    arc_0_18_16  connected_order_arc_657  -15
    arc_0_18_16  in_degree_827  1
    arc_0_18_16  out_degree_838  1
    arc_0_18_16  original_T_including_depot_unload_873  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_656  1
    load_0_18_16  free_load_conservation_831  -1
    load_0_18_16  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_658  -20
    arc_0_18_17  connected_order_arc_659  -15
    arc_0_18_17  in_degree_833  1
    arc_0_18_17  out_degree_838  1
    arc_0_18_17  original_T_including_depot_unload_873  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_658  1
    load_0_18_17  free_load_conservation_837  -1
    load_0_18_17  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_660  -20
    arc_0_18_19  connected_order_arc_661  -15
    arc_0_18_19  out_degree_838  1
    arc_0_18_19  in_degree_845  1
    arc_0_18_19  original_T_including_depot_unload_873  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_660  1
    load_0_18_19  free_load_conservation_843  1
    load_0_18_19  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_662  -20
    arc_0_18_20  connected_order_arc_663  -15
    arc_0_18_20  out_degree_838  1
    arc_0_18_20  in_degree_851  1
    arc_0_18_20  original_T_including_depot_unload_873  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_662  1
    load_0_18_20  free_load_conservation_843  1
    load_0_18_20  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_664  -20
    arc_0_18_21  connected_order_arc_665  -15
    arc_0_18_21  out_degree_838  1
    arc_0_18_21  in_degree_857  1
    arc_0_18_21  original_T_including_depot_unload_873  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_664  1
    load_0_18_21  free_load_conservation_843  1
    load_0_18_21  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_22  arc_capacity_666  -20
    arc_0_18_22  connected_order_arc_667  -15
    arc_0_18_22  out_degree_838  1
    arc_0_18_22  in_degree_863  1
    arc_0_18_22  original_T_including_depot_unload_873  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_22  arc_capacity_666  1
    load_0_18_22  free_load_conservation_843  1
    load_0_18_22  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_668  -20
    arc_0_19_0  depot_return_or_bypass_777  1
    arc_0_19_0  out_degree_844  1
    arc_0_19_0  original_T_including_depot_unload_873  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_668  1
    load_0_19_0  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_669  -20
    arc_0_19_1  connected_order_arc_670  -15
    arc_0_19_1  in_degree_779  1
    arc_0_19_1  out_degree_844  1
    arc_0_19_1  original_T_including_depot_unload_873  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_669  1
    load_0_19_1  segment_load_conservation_782  -1
    load_0_19_1  segment_prefix_lb_783  1
    load_0_19_1  segment_prefix_ub_784  1
    load_0_19_1  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_671  -20
    arc_0_19_2  connected_order_arc_672  -15
    arc_0_19_2  in_degree_786  1
    arc_0_19_2  out_degree_844  1
    arc_0_19_2  original_T_including_depot_unload_873  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_671  1
    load_0_19_2  segment_load_conservation_789  -1
    load_0_19_2  segment_prefix_lb_790  1
    load_0_19_2  segment_prefix_ub_791  1
    load_0_19_2  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_673  -20
    arc_0_19_3  connected_order_arc_674  -15
    arc_0_19_3  in_degree_793  1
    arc_0_19_3  out_degree_844  1
    arc_0_19_3  original_T_including_depot_unload_873  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_673  1
    load_0_19_3  segment_load_conservation_796  -1
    load_0_19_3  segment_prefix_lb_797  1
    load_0_19_3  segment_prefix_ub_798  1
    load_0_19_3  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_675  -20
    arc_0_19_4  connected_order_arc_676  -15
    arc_0_19_4  in_degree_800  1
    arc_0_19_4  out_degree_844  1
    arc_0_19_4  original_T_including_depot_unload_873  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_675  1
    load_0_19_4  segment_load_conservation_803  -1
    load_0_19_4  segment_prefix_lb_804  1
    load_0_19_4  segment_prefix_ub_805  1
    load_0_19_4  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_677  -20
    arc_0_19_5  connected_order_arc_678  -15
    arc_0_19_5  in_degree_807  1
    arc_0_19_5  out_degree_844  1
    arc_0_19_5  original_T_including_depot_unload_873  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_677  1
    load_0_19_5  segment_load_conservation_810  -1
    load_0_19_5  segment_prefix_lb_811  1
    load_0_19_5  segment_prefix_ub_812  1
    load_0_19_5  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_6  arc_capacity_679  -20
    arc_0_19_6  connected_order_arc_680  -15
    arc_0_19_6  in_degree_814  1
    arc_0_19_6  out_degree_844  1
    arc_0_19_6  original_T_including_depot_unload_873  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_6  arc_capacity_679  1
    load_0_19_6  segment_load_conservation_817  -1
    load_0_19_6  segment_prefix_lb_818  1
    load_0_19_6  segment_prefix_ub_819  1
    load_0_19_6  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_681  -20
    arc_0_19_15  connected_order_arc_682  -15
    arc_0_19_15  in_degree_821  1
    arc_0_19_15  out_degree_844  1
    arc_0_19_15  original_T_including_depot_unload_873  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_681  1
    load_0_19_15  free_load_conservation_825  -1
    load_0_19_15  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_683  -20
    arc_0_19_16  connected_order_arc_684  -15
    arc_0_19_16  in_degree_827  1
    arc_0_19_16  out_degree_844  1
    arc_0_19_16  original_T_including_depot_unload_873  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_683  1
    load_0_19_16  free_load_conservation_831  -1
    load_0_19_16  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_685  -20
    arc_0_19_17  connected_order_arc_686  -15
    arc_0_19_17  in_degree_833  1
    arc_0_19_17  out_degree_844  1
    arc_0_19_17  original_T_including_depot_unload_873  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_685  1
    load_0_19_17  free_load_conservation_837  -1
    load_0_19_17  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_687  -20
    arc_0_19_18  connected_order_arc_688  -15
    arc_0_19_18  in_degree_839  1
    arc_0_19_18  out_degree_844  1
    arc_0_19_18  original_T_including_depot_unload_873  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_687  1
    load_0_19_18  free_load_conservation_843  -1
    load_0_19_18  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_689  -20
    arc_0_19_20  connected_order_arc_690  -15
    arc_0_19_20  out_degree_844  1
    arc_0_19_20  in_degree_851  1
    arc_0_19_20  original_T_including_depot_unload_873  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_689  1
    load_0_19_20  free_load_conservation_849  1
    load_0_19_20  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_691  -20
    arc_0_19_21  connected_order_arc_692  -15
    arc_0_19_21  out_degree_844  1
    arc_0_19_21  in_degree_857  1
    arc_0_19_21  original_T_including_depot_unload_873  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_691  1
    load_0_19_21  free_load_conservation_849  1
    load_0_19_21  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_22  arc_capacity_693  -20
    arc_0_19_22  connected_order_arc_694  -15
    arc_0_19_22  out_degree_844  1
    arc_0_19_22  in_degree_863  1
    arc_0_19_22  original_T_including_depot_unload_873  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_22  arc_capacity_693  1
    load_0_19_22  free_load_conservation_849  1
    load_0_19_22  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_695  -20
    arc_0_20_0  depot_return_or_bypass_777  1
    arc_0_20_0  out_degree_850  1
    arc_0_20_0  original_T_including_depot_unload_873  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_695  1
    load_0_20_0  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_696  -20
    arc_0_20_1  connected_order_arc_697  -15
    arc_0_20_1  in_degree_779  1
    arc_0_20_1  out_degree_850  1
    arc_0_20_1  original_T_including_depot_unload_873  1.4479451378803963e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_696  1
    load_0_20_1  segment_load_conservation_782  -1
    load_0_20_1  segment_prefix_lb_783  1
    load_0_20_1  segment_prefix_ub_784  1
    load_0_20_1  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_698  -20
    arc_0_20_2  connected_order_arc_699  -15
    arc_0_20_2  in_degree_786  1
    arc_0_20_2  out_degree_850  1
    arc_0_20_2  original_T_including_depot_unload_873  1.3812305438169078e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_698  1
    load_0_20_2  segment_load_conservation_789  -1
    load_0_20_2  segment_prefix_lb_790  1
    load_0_20_2  segment_prefix_ub_791  1
    load_0_20_2  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_700  -20
    arc_0_20_3  connected_order_arc_701  -15
    arc_0_20_3  in_degree_793  1
    arc_0_20_3  out_degree_850  1
    arc_0_20_3  original_T_including_depot_unload_873  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_700  1
    load_0_20_3  segment_load_conservation_796  -1
    load_0_20_3  segment_prefix_lb_797  1
    load_0_20_3  segment_prefix_ub_798  1
    load_0_20_3  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_702  -20
    arc_0_20_4  connected_order_arc_703  -15
    arc_0_20_4  in_degree_800  1
    arc_0_20_4  out_degree_850  1
    arc_0_20_4  original_T_including_depot_unload_873  1.0917254946216958e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_702  1
    load_0_20_4  segment_load_conservation_803  -1
    load_0_20_4  segment_prefix_lb_804  1
    load_0_20_4  segment_prefix_ub_805  1
    load_0_20_4  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_704  -20
    arc_0_20_5  connected_order_arc_705  -15
    arc_0_20_5  in_degree_807  1
    arc_0_20_5  out_degree_850  1
    arc_0_20_5  original_T_including_depot_unload_873  8.0231446125927152e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_704  1
    load_0_20_5  segment_load_conservation_810  -1
    load_0_20_5  segment_prefix_lb_811  1
    load_0_20_5  segment_prefix_ub_812  1
    load_0_20_5  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_6  arc_capacity_706  -20
    arc_0_20_6  connected_order_arc_707  -15
    arc_0_20_6  in_degree_814  1
    arc_0_20_6  out_degree_850  1
    arc_0_20_6  original_T_including_depot_unload_873  7.8724938919046190e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_6  arc_capacity_706  1
    load_0_20_6  segment_load_conservation_817  -1
    load_0_20_6  segment_prefix_lb_818  1
    load_0_20_6  segment_prefix_ub_819  1
    load_0_20_6  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_708  -20
    arc_0_20_15  connected_order_arc_709  -15
    arc_0_20_15  in_degree_821  1
    arc_0_20_15  out_degree_850  1
    arc_0_20_15  original_T_including_depot_unload_873  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_708  1
    load_0_20_15  free_load_conservation_825  -1
    load_0_20_15  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_710  -20
    arc_0_20_16  connected_order_arc_711  -15
    arc_0_20_16  in_degree_827  1
    arc_0_20_16  out_degree_850  1
    arc_0_20_16  original_T_including_depot_unload_873  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_710  1
    load_0_20_16  free_load_conservation_831  -1
    load_0_20_16  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_712  -20
    arc_0_20_17  connected_order_arc_713  -15
    arc_0_20_17  in_degree_833  1
    arc_0_20_17  out_degree_850  1
    arc_0_20_17  original_T_including_depot_unload_873  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_712  1
    load_0_20_17  free_load_conservation_837  -1
    load_0_20_17  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_714  -20
    arc_0_20_18  connected_order_arc_715  -15
    arc_0_20_18  in_degree_839  1
    arc_0_20_18  out_degree_850  1
    arc_0_20_18  original_T_including_depot_unload_873  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_714  1
    load_0_20_18  free_load_conservation_843  -1
    load_0_20_18  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_716  -20
    arc_0_20_19  connected_order_arc_717  -15
    arc_0_20_19  in_degree_845  1
    arc_0_20_19  out_degree_850  1
    arc_0_20_19  original_T_including_depot_unload_873  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_716  1
    load_0_20_19  free_load_conservation_849  -1
    load_0_20_19  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_718  -20
    arc_0_20_21  connected_order_arc_719  -15
    arc_0_20_21  out_degree_850  1
    arc_0_20_21  in_degree_857  1
    arc_0_20_21  original_T_including_depot_unload_873  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_718  1
    load_0_20_21  free_load_conservation_855  1
    load_0_20_21  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_22  arc_capacity_720  -20
    arc_0_20_22  connected_order_arc_721  -15
    arc_0_20_22  out_degree_850  1
    arc_0_20_22  in_degree_863  1
    arc_0_20_22  original_T_including_depot_unload_873  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_22  arc_capacity_720  1
    load_0_20_22  free_load_conservation_855  1
    load_0_20_22  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_722  -20
    arc_0_21_0  depot_return_or_bypass_777  1
    arc_0_21_0  out_degree_856  1
    arc_0_21_0  original_T_including_depot_unload_873  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_722  1
    load_0_21_0  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_723  -20
    arc_0_21_1  connected_order_arc_724  -15
    arc_0_21_1  in_degree_779  1
    arc_0_21_1  out_degree_856  1
    arc_0_21_1  original_T_including_depot_unload_873  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_723  1
    load_0_21_1  segment_load_conservation_782  -1
    load_0_21_1  segment_prefix_lb_783  1
    load_0_21_1  segment_prefix_ub_784  1
    load_0_21_1  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_725  -20
    arc_0_21_2  connected_order_arc_726  -15
    arc_0_21_2  in_degree_786  1
    arc_0_21_2  out_degree_856  1
    arc_0_21_2  original_T_including_depot_unload_873  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_725  1
    load_0_21_2  segment_load_conservation_789  -1
    load_0_21_2  segment_prefix_lb_790  1
    load_0_21_2  segment_prefix_ub_791  1
    load_0_21_2  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_727  -20
    arc_0_21_3  connected_order_arc_728  -15
    arc_0_21_3  in_degree_793  1
    arc_0_21_3  out_degree_856  1
    arc_0_21_3  original_T_including_depot_unload_873  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_727  1
    load_0_21_3  segment_load_conservation_796  -1
    load_0_21_3  segment_prefix_lb_797  1
    load_0_21_3  segment_prefix_ub_798  1
    load_0_21_3  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_729  -20
    arc_0_21_4  connected_order_arc_730  -15
    arc_0_21_4  in_degree_800  1
    arc_0_21_4  out_degree_856  1
    arc_0_21_4  original_T_including_depot_unload_873  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_729  1
    load_0_21_4  segment_load_conservation_803  -1
    load_0_21_4  segment_prefix_lb_804  1
    load_0_21_4  segment_prefix_ub_805  1
    load_0_21_4  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_731  -20
    arc_0_21_5  connected_order_arc_732  -15
    arc_0_21_5  in_degree_807  1
    arc_0_21_5  out_degree_856  1
    arc_0_21_5  original_T_including_depot_unload_873  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_731  1
    load_0_21_5  segment_load_conservation_810  -1
    load_0_21_5  segment_prefix_lb_811  1
    load_0_21_5  segment_prefix_ub_812  1
    load_0_21_5  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_6  arc_capacity_733  -20
    arc_0_21_6  connected_order_arc_734  -15
    arc_0_21_6  in_degree_814  1
    arc_0_21_6  out_degree_856  1
    arc_0_21_6  original_T_including_depot_unload_873  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_6  arc_capacity_733  1
    load_0_21_6  segment_load_conservation_817  -1
    load_0_21_6  segment_prefix_lb_818  1
    load_0_21_6  segment_prefix_ub_819  1
    load_0_21_6  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_735  -20
    arc_0_21_15  connected_order_arc_736  -15
    arc_0_21_15  in_degree_821  1
    arc_0_21_15  out_degree_856  1
    arc_0_21_15  original_T_including_depot_unload_873  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_735  1
    load_0_21_15  free_load_conservation_825  -1
    load_0_21_15  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_737  -20
    arc_0_21_16  connected_order_arc_738  -15
    arc_0_21_16  in_degree_827  1
    arc_0_21_16  out_degree_856  1
    arc_0_21_16  original_T_including_depot_unload_873  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_737  1
    load_0_21_16  free_load_conservation_831  -1
    load_0_21_16  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_739  -20
    arc_0_21_17  connected_order_arc_740  -15
    arc_0_21_17  in_degree_833  1
    arc_0_21_17  out_degree_856  1
    arc_0_21_17  original_T_including_depot_unload_873  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_739  1
    load_0_21_17  free_load_conservation_837  -1
    load_0_21_17  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_741  -20
    arc_0_21_18  connected_order_arc_742  -15
    arc_0_21_18  in_degree_839  1
    arc_0_21_18  out_degree_856  1
    arc_0_21_18  original_T_including_depot_unload_873  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_741  1
    load_0_21_18  free_load_conservation_843  -1
    load_0_21_18  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_743  -20
    arc_0_21_19  connected_order_arc_744  -15
    arc_0_21_19  in_degree_845  1
    arc_0_21_19  out_degree_856  1
    arc_0_21_19  original_T_including_depot_unload_873  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_743  1
    load_0_21_19  free_load_conservation_849  -1
    load_0_21_19  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_745  -20
    arc_0_21_20  connected_order_arc_746  -15
    arc_0_21_20  in_degree_851  1
    arc_0_21_20  out_degree_856  1
    arc_0_21_20  original_T_including_depot_unload_873  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_745  1
    load_0_21_20  free_load_conservation_855  -1
    load_0_21_20  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_22  arc_capacity_747  -20
    arc_0_21_22  connected_order_arc_748  -15
    arc_0_21_22  out_degree_856  1
    arc_0_21_22  in_degree_863  1
    arc_0_21_22  original_T_including_depot_unload_873  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_22  arc_capacity_747  1
    load_0_21_22  free_load_conservation_861  1
    load_0_21_22  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_0  arc_capacity_749  -20
    arc_0_22_0  depot_return_or_bypass_777  1
    arc_0_22_0  out_degree_862  1
    arc_0_22_0  original_T_including_depot_unload_873  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_0  arc_capacity_749  1
    load_0_22_0  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_1  arc_capacity_750  -20
    arc_0_22_1  connected_order_arc_751  -15
    arc_0_22_1  in_degree_779  1
    arc_0_22_1  out_degree_862  1
    arc_0_22_1  original_T_including_depot_unload_873  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_1  arc_capacity_750  1
    load_0_22_1  segment_load_conservation_782  -1
    load_0_22_1  segment_prefix_lb_783  1
    load_0_22_1  segment_prefix_ub_784  1
    load_0_22_1  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_2  arc_capacity_752  -20
    arc_0_22_2  connected_order_arc_753  -15
    arc_0_22_2  in_degree_786  1
    arc_0_22_2  out_degree_862  1
    arc_0_22_2  original_T_including_depot_unload_873  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_2  arc_capacity_752  1
    load_0_22_2  segment_load_conservation_789  -1
    load_0_22_2  segment_prefix_lb_790  1
    load_0_22_2  segment_prefix_ub_791  1
    load_0_22_2  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_3  arc_capacity_754  -20
    arc_0_22_3  connected_order_arc_755  -15
    arc_0_22_3  in_degree_793  1
    arc_0_22_3  out_degree_862  1
    arc_0_22_3  original_T_including_depot_unload_873  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_3  arc_capacity_754  1
    load_0_22_3  segment_load_conservation_796  -1
    load_0_22_3  segment_prefix_lb_797  1
    load_0_22_3  segment_prefix_ub_798  1
    load_0_22_3  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_4  arc_capacity_756  -20
    arc_0_22_4  connected_order_arc_757  -15
    arc_0_22_4  in_degree_800  1
    arc_0_22_4  out_degree_862  1
    arc_0_22_4  original_T_including_depot_unload_873  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_4  arc_capacity_756  1
    load_0_22_4  segment_load_conservation_803  -1
    load_0_22_4  segment_prefix_lb_804  1
    load_0_22_4  segment_prefix_ub_805  1
    load_0_22_4  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_5  arc_capacity_758  -20
    arc_0_22_5  connected_order_arc_759  -15
    arc_0_22_5  in_degree_807  1
    arc_0_22_5  out_degree_862  1
    arc_0_22_5  original_T_including_depot_unload_873  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_5  arc_capacity_758  1
    load_0_22_5  segment_load_conservation_810  -1
    load_0_22_5  segment_prefix_lb_811  1
    load_0_22_5  segment_prefix_ub_812  1
    load_0_22_5  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_6  arc_capacity_760  -20
    arc_0_22_6  connected_order_arc_761  -15
    arc_0_22_6  in_degree_814  1
    arc_0_22_6  out_degree_862  1
    arc_0_22_6  original_T_including_depot_unload_873  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_6  arc_capacity_760  1
    load_0_22_6  segment_load_conservation_817  -1
    load_0_22_6  segment_prefix_lb_818  1
    load_0_22_6  segment_prefix_ub_819  1
    load_0_22_6  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_15  arc_capacity_762  -20
    arc_0_22_15  connected_order_arc_763  -15
    arc_0_22_15  in_degree_821  1
    arc_0_22_15  out_degree_862  1
    arc_0_22_15  original_T_including_depot_unload_873  7.9829177317292124e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_15  arc_capacity_762  1
    load_0_22_15  free_load_conservation_825  -1
    load_0_22_15  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_16  arc_capacity_764  -20
    arc_0_22_16  connected_order_arc_765  -15
    arc_0_22_16  in_degree_827  1
    arc_0_22_16  out_degree_862  1
    arc_0_22_16  original_T_including_depot_unload_873  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_16  arc_capacity_764  1
    load_0_22_16  free_load_conservation_831  -1
    load_0_22_16  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_17  arc_capacity_766  -20
    arc_0_22_17  connected_order_arc_767  -15
    arc_0_22_17  in_degree_833  1
    arc_0_22_17  out_degree_862  1
    arc_0_22_17  original_T_including_depot_unload_873  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_17  arc_capacity_766  1
    load_0_22_17  free_load_conservation_837  -1
    load_0_22_17  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_18  arc_capacity_768  -20
    arc_0_22_18  connected_order_arc_769  -15
    arc_0_22_18  in_degree_839  1
    arc_0_22_18  out_degree_862  1
    arc_0_22_18  original_T_including_depot_unload_873  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_18  arc_capacity_768  1
    load_0_22_18  free_load_conservation_843  -1
    load_0_22_18  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_19  arc_capacity_770  -20
    arc_0_22_19  connected_order_arc_771  -15
    arc_0_22_19  in_degree_845  1
    arc_0_22_19  out_degree_862  1
    arc_0_22_19  original_T_including_depot_unload_873  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_19  arc_capacity_770  1
    load_0_22_19  free_load_conservation_849  -1
    load_0_22_19  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_20  arc_capacity_772  -20
    arc_0_22_20  connected_order_arc_773  -15
    arc_0_22_20  in_degree_851  1
    arc_0_22_20  out_degree_862  1
    arc_0_22_20  original_T_including_depot_unload_873  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_20  arc_capacity_772  1
    load_0_22_20  free_load_conservation_855  -1
    load_0_22_20  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_21  arc_capacity_774  -20
    arc_0_22_21  connected_order_arc_775  -15
    arc_0_22_21  in_degree_857  1
    arc_0_22_21  out_degree_862  1
    arc_0_22_21  original_T_including_depot_unload_873  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_21  arc_capacity_774  1
    load_0_22_21  free_load_conservation_861  -1
    load_0_22_21  free_load_conservation_867  1
    visit_1_7  out_degree_1165  -1
    visit_1_7  in_degree_1166  -1
    visit_1_7  order_active_lb_1167  -1
    visit_1_7  order_active_ub_1168  -12
    order_1_7  connected_order_arc_889  -1
    order_1_7  connected_order_arc_891  -1
    order_1_7  connected_order_arc_893  -1
    order_1_7  connected_order_arc_895  -1
    order_1_7  connected_order_arc_897  -1
    order_1_7  connected_order_arc_899  -1
    order_1_7  connected_order_arc_901  -1
    order_1_7  connected_order_arc_903  -1
    order_1_7  connected_order_arc_905  -1
    order_1_7  connected_order_arc_907  -1
    order_1_7  connected_order_arc_909  -1
    order_1_7  connected_order_arc_912  1
    order_1_7  connected_order_arc_935  1
    order_1_7  connected_order_arc_958  1
    order_1_7  connected_order_arc_981  1
    order_1_7  connected_order_arc_1004  1
    order_1_7  connected_order_arc_1027  1
    order_1_7  connected_order_arc_1050  1
    order_1_7  connected_order_arc_1073  1
    order_1_7  connected_order_arc_1096  1
    order_1_7  connected_order_arc_1119  1
    order_1_7  connected_order_arc_1142  1
    order_1_7  order_active_lb_1167  1
    order_1_7  order_active_ub_1168  1
    order_1_7  fixed_segment_relative_order_1241  -1
    visit_1_8  out_degree_1172  -1
    visit_1_8  in_degree_1173  -1
    visit_1_8  order_active_lb_1174  -1
    visit_1_8  order_active_ub_1175  -12
    order_1_8  connected_order_arc_889  1
    order_1_8  connected_order_arc_912  -1
    order_1_8  connected_order_arc_914  -1
    order_1_8  connected_order_arc_916  -1
    order_1_8  connected_order_arc_918  -1
    order_1_8  connected_order_arc_920  -1
    order_1_8  connected_order_arc_922  -1
    order_1_8  connected_order_arc_924  -1
    order_1_8  connected_order_arc_926  -1
    order_1_8  connected_order_arc_928  -1
    order_1_8  connected_order_arc_930  -1
    order_1_8  connected_order_arc_932  -1
    order_1_8  connected_order_arc_937  1
    order_1_8  connected_order_arc_960  1
    order_1_8  connected_order_arc_983  1
    order_1_8  connected_order_arc_1006  1
    order_1_8  connected_order_arc_1029  1
    order_1_8  connected_order_arc_1052  1
    order_1_8  connected_order_arc_1075  1
    order_1_8  connected_order_arc_1098  1
    order_1_8  connected_order_arc_1121  1
    order_1_8  connected_order_arc_1144  1
    order_1_8  order_active_lb_1174  1
    order_1_8  order_active_ub_1175  1
    order_1_8  fixed_segment_relative_order_1241  1
    order_1_8  fixed_segment_relative_order_1242  -1
    visit_1_9  out_degree_1179  -1
    visit_1_9  in_degree_1180  -1
    visit_1_9  order_active_lb_1181  -1
    visit_1_9  order_active_ub_1182  -12
    order_1_9  connected_order_arc_891  1
    order_1_9  connected_order_arc_914  1
    order_1_9  connected_order_arc_935  -1
    order_1_9  connected_order_arc_937  -1
    order_1_9  connected_order_arc_939  -1
    order_1_9  connected_order_arc_941  -1
    order_1_9  connected_order_arc_943  -1
    order_1_9  connected_order_arc_945  -1
    order_1_9  connected_order_arc_947  -1
    order_1_9  connected_order_arc_949  -1
    order_1_9  connected_order_arc_951  -1
    order_1_9  connected_order_arc_953  -1
    order_1_9  connected_order_arc_955  -1
    order_1_9  connected_order_arc_962  1
    order_1_9  connected_order_arc_985  1
    order_1_9  connected_order_arc_1008  1
    order_1_9  connected_order_arc_1031  1
    order_1_9  connected_order_arc_1054  1
    order_1_9  connected_order_arc_1077  1
    order_1_9  connected_order_arc_1100  1
    order_1_9  connected_order_arc_1123  1
    order_1_9  connected_order_arc_1146  1
    order_1_9  order_active_lb_1181  1
    order_1_9  order_active_ub_1182  1
    order_1_9  fixed_segment_relative_order_1242  1
    order_1_9  fixed_segment_relative_order_1243  -1
    visit_1_10  out_degree_1186  -1
    visit_1_10  in_degree_1187  -1
    visit_1_10  order_active_lb_1188  -1
    visit_1_10  order_active_ub_1189  -12
    order_1_10  connected_order_arc_893  1
    order_1_10  connected_order_arc_916  1
    order_1_10  connected_order_arc_939  1
    order_1_10  connected_order_arc_958  -1
    order_1_10  connected_order_arc_960  -1
    order_1_10  connected_order_arc_962  -1
    order_1_10  connected_order_arc_964  -1
    order_1_10  connected_order_arc_966  -1
    order_1_10  connected_order_arc_968  -1
    order_1_10  connected_order_arc_970  -1
    order_1_10  connected_order_arc_972  -1
    order_1_10  connected_order_arc_974  -1
    order_1_10  connected_order_arc_976  -1
    order_1_10  connected_order_arc_978  -1
    order_1_10  connected_order_arc_987  1
    order_1_10  connected_order_arc_1010  1
    order_1_10  connected_order_arc_1033  1
    order_1_10  connected_order_arc_1056  1
    order_1_10  connected_order_arc_1079  1
    order_1_10  connected_order_arc_1102  1
    order_1_10  connected_order_arc_1125  1
    order_1_10  connected_order_arc_1148  1
    order_1_10  order_active_lb_1188  1
    order_1_10  order_active_ub_1189  1
    order_1_10  fixed_segment_relative_order_1243  1
    visit_1_15  out_degree_1193  -1
    visit_1_15  in_degree_1194  -1
    visit_1_15  order_active_lb_1195  -1
    visit_1_15  order_active_ub_1196  -12
    visit_1_15  service_visit_def_1197  -1
    order_1_15  connected_order_arc_895  1
    order_1_15  connected_order_arc_918  1
    order_1_15  connected_order_arc_941  1
    order_1_15  connected_order_arc_964  1
    order_1_15  connected_order_arc_981  -1
    order_1_15  connected_order_arc_983  -1
    order_1_15  connected_order_arc_985  -1
    order_1_15  connected_order_arc_987  -1
    order_1_15  connected_order_arc_989  -1
    order_1_15  connected_order_arc_991  -1
    order_1_15  connected_order_arc_993  -1
    order_1_15  connected_order_arc_995  -1
    order_1_15  connected_order_arc_997  -1
    order_1_15  connected_order_arc_999  -1
    order_1_15  connected_order_arc_1001  -1
    order_1_15  connected_order_arc_1012  1
    order_1_15  connected_order_arc_1035  1
    order_1_15  connected_order_arc_1058  1
    order_1_15  connected_order_arc_1081  1
    order_1_15  connected_order_arc_1104  1
    order_1_15  connected_order_arc_1127  1
    order_1_15  connected_order_arc_1150  1
    order_1_15  order_active_lb_1195  1
    order_1_15  order_active_ub_1196  1
    visit_1_16  out_degree_1199  -1
    visit_1_16  in_degree_1200  -1
    visit_1_16  order_active_lb_1201  -1
    visit_1_16  order_active_ub_1202  -12
    visit_1_16  service_visit_def_1203  -1
    order_1_16  connected_order_arc_897  1
    order_1_16  connected_order_arc_920  1
    order_1_16  connected_order_arc_943  1
    order_1_16  connected_order_arc_966  1
    order_1_16  connected_order_arc_989  1
    order_1_16  connected_order_arc_1004  -1
    order_1_16  connected_order_arc_1006  -1
    order_1_16  connected_order_arc_1008  -1
    order_1_16  connected_order_arc_1010  -1
    order_1_16  connected_order_arc_1012  -1
    order_1_16  connected_order_arc_1014  -1
    order_1_16  connected_order_arc_1016  -1
    order_1_16  connected_order_arc_1018  -1
    order_1_16  connected_order_arc_1020  -1
    order_1_16  connected_order_arc_1022  -1
    order_1_16  connected_order_arc_1024  -1
    order_1_16  connected_order_arc_1037  1
    order_1_16  connected_order_arc_1060  1
    order_1_16  connected_order_arc_1083  1
    order_1_16  connected_order_arc_1106  1
    order_1_16  connected_order_arc_1129  1
    order_1_16  connected_order_arc_1152  1
    order_1_16  order_active_lb_1201  1
    order_1_16  order_active_ub_1202  1
    visit_1_17  out_degree_1205  -1
    visit_1_17  in_degree_1206  -1
    visit_1_17  order_active_lb_1207  -1
    visit_1_17  order_active_ub_1208  -12
    visit_1_17  service_visit_def_1209  -1
    order_1_17  connected_order_arc_899  1
    order_1_17  connected_order_arc_922  1
    order_1_17  connected_order_arc_945  1
    order_1_17  connected_order_arc_968  1
    order_1_17  connected_order_arc_991  1
    order_1_17  connected_order_arc_1014  1
    order_1_17  connected_order_arc_1027  -1
    order_1_17  connected_order_arc_1029  -1
    order_1_17  connected_order_arc_1031  -1
    order_1_17  connected_order_arc_1033  -1
    order_1_17  connected_order_arc_1035  -1
    order_1_17  connected_order_arc_1037  -1
    order_1_17  connected_order_arc_1039  -1
    order_1_17  connected_order_arc_1041  -1
    order_1_17  connected_order_arc_1043  -1
    order_1_17  connected_order_arc_1045  -1
    order_1_17  connected_order_arc_1047  -1
    order_1_17  connected_order_arc_1062  1
    order_1_17  connected_order_arc_1085  1
    order_1_17  connected_order_arc_1108  1
    order_1_17  connected_order_arc_1131  1
    order_1_17  connected_order_arc_1154  1
    order_1_17  order_active_lb_1207  1
    order_1_17  order_active_ub_1208  1
    visit_1_18  out_degree_1211  -1
    visit_1_18  in_degree_1212  -1
    visit_1_18  order_active_lb_1213  -1
    visit_1_18  order_active_ub_1214  -12
    visit_1_18  service_visit_def_1215  -1
    order_1_18  connected_order_arc_901  1
    order_1_18  connected_order_arc_924  1
    order_1_18  connected_order_arc_947  1
    order_1_18  connected_order_arc_970  1
    order_1_18  connected_order_arc_993  1
    order_1_18  connected_order_arc_1016  1
    order_1_18  connected_order_arc_1039  1
    order_1_18  connected_order_arc_1050  -1
    order_1_18  connected_order_arc_1052  -1
    order_1_18  connected_order_arc_1054  -1
    order_1_18  connected_order_arc_1056  -1
    order_1_18  connected_order_arc_1058  -1
    order_1_18  connected_order_arc_1060  -1
    order_1_18  connected_order_arc_1062  -1
    order_1_18  connected_order_arc_1064  -1
    order_1_18  connected_order_arc_1066  -1
    order_1_18  connected_order_arc_1068  -1
    order_1_18  connected_order_arc_1070  -1
    order_1_18  connected_order_arc_1087  1
    order_1_18  connected_order_arc_1110  1
    order_1_18  connected_order_arc_1133  1
    order_1_18  connected_order_arc_1156  1
    order_1_18  order_active_lb_1213  1
    order_1_18  order_active_ub_1214  1
    visit_1_19  out_degree_1217  -1
    visit_1_19  in_degree_1218  -1
    visit_1_19  order_active_lb_1219  -1
    visit_1_19  order_active_ub_1220  -12
    visit_1_19  service_visit_def_1221  -1
    order_1_19  connected_order_arc_903  1
    order_1_19  connected_order_arc_926  1
    order_1_19  connected_order_arc_949  1
    order_1_19  connected_order_arc_972  1
    order_1_19  connected_order_arc_995  1
    order_1_19  connected_order_arc_1018  1
    order_1_19  connected_order_arc_1041  1
    order_1_19  connected_order_arc_1064  1
    order_1_19  connected_order_arc_1073  -1
    order_1_19  connected_order_arc_1075  -1
    order_1_19  connected_order_arc_1077  -1
    order_1_19  connected_order_arc_1079  -1
    order_1_19  connected_order_arc_1081  -1
    order_1_19  connected_order_arc_1083  -1
    order_1_19  connected_order_arc_1085  -1
    order_1_19  connected_order_arc_1087  -1
    order_1_19  connected_order_arc_1089  -1
    order_1_19  connected_order_arc_1091  -1
    order_1_19  connected_order_arc_1093  -1
    order_1_19  connected_order_arc_1112  1
    order_1_19  connected_order_arc_1135  1
    order_1_19  connected_order_arc_1158  1
    order_1_19  order_active_lb_1219  1
    order_1_19  order_active_ub_1220  1
    visit_1_20  out_degree_1223  -1
    visit_1_20  in_degree_1224  -1
    visit_1_20  order_active_lb_1225  -1
    visit_1_20  order_active_ub_1226  -12
    visit_1_20  service_visit_def_1227  -1
    order_1_20  connected_order_arc_905  1
    order_1_20  connected_order_arc_928  1
    order_1_20  connected_order_arc_951  1
    order_1_20  connected_order_arc_974  1
    order_1_20  connected_order_arc_997  1
    order_1_20  connected_order_arc_1020  1
    order_1_20  connected_order_arc_1043  1
    order_1_20  connected_order_arc_1066  1
    order_1_20  connected_order_arc_1089  1
    order_1_20  connected_order_arc_1096  -1
    order_1_20  connected_order_arc_1098  -1
    order_1_20  connected_order_arc_1100  -1
    order_1_20  connected_order_arc_1102  -1
    order_1_20  connected_order_arc_1104  -1
    order_1_20  connected_order_arc_1106  -1
    order_1_20  connected_order_arc_1108  -1
    order_1_20  connected_order_arc_1110  -1
    order_1_20  connected_order_arc_1112  -1
    order_1_20  connected_order_arc_1114  -1
    order_1_20  connected_order_arc_1116  -1
    order_1_20  connected_order_arc_1137  1
    order_1_20  connected_order_arc_1160  1
    order_1_20  order_active_lb_1225  1
    order_1_20  order_active_ub_1226  1
    visit_1_21  out_degree_1229  -1
    visit_1_21  in_degree_1230  -1
    visit_1_21  order_active_lb_1231  -1
    visit_1_21  order_active_ub_1232  -12
    visit_1_21  service_visit_def_1233  -1
    order_1_21  connected_order_arc_907  1
    order_1_21  connected_order_arc_930  1
    order_1_21  connected_order_arc_953  1
    order_1_21  connected_order_arc_976  1
    order_1_21  connected_order_arc_999  1
    order_1_21  connected_order_arc_1022  1
    order_1_21  connected_order_arc_1045  1
    order_1_21  connected_order_arc_1068  1
    order_1_21  connected_order_arc_1091  1
    order_1_21  connected_order_arc_1114  1
    order_1_21  connected_order_arc_1119  -1
    order_1_21  connected_order_arc_1121  -1
    order_1_21  connected_order_arc_1123  -1
    order_1_21  connected_order_arc_1125  -1
    order_1_21  connected_order_arc_1127  -1
    order_1_21  connected_order_arc_1129  -1
    order_1_21  connected_order_arc_1131  -1
    order_1_21  connected_order_arc_1133  -1
    order_1_21  connected_order_arc_1135  -1
    order_1_21  connected_order_arc_1137  -1
    order_1_21  connected_order_arc_1139  -1
    order_1_21  connected_order_arc_1162  1
    order_1_21  order_active_lb_1231  1
    order_1_21  order_active_ub_1232  1
    visit_1_22  out_degree_1235  -1
    visit_1_22  in_degree_1236  -1
    visit_1_22  order_active_lb_1237  -1
    visit_1_22  order_active_ub_1238  -12
    visit_1_22  service_visit_def_1239  -1
    order_1_22  connected_order_arc_909  1
    order_1_22  connected_order_arc_932  1
    order_1_22  connected_order_arc_955  1
    order_1_22  connected_order_arc_978  1
    order_1_22  connected_order_arc_1001  1
    order_1_22  connected_order_arc_1024  1
    order_1_22  connected_order_arc_1047  1
    order_1_22  connected_order_arc_1070  1
    order_1_22  connected_order_arc_1093  1
    order_1_22  connected_order_arc_1116  1
    order_1_22  connected_order_arc_1139  1
    order_1_22  connected_order_arc_1142  -1
    order_1_22  connected_order_arc_1144  -1
    order_1_22  connected_order_arc_1146  -1
    order_1_22  connected_order_arc_1148  -1
    order_1_22  connected_order_arc_1150  -1
    order_1_22  connected_order_arc_1152  -1
    order_1_22  connected_order_arc_1154  -1
    order_1_22  connected_order_arc_1156  -1
    order_1_22  connected_order_arc_1158  -1
    order_1_22  connected_order_arc_1160  -1
    order_1_22  connected_order_arc_1162  -1
    order_1_22  order_active_lb_1237  1
    order_1_22  order_active_ub_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_874  -25
    arc_1_0_0  depot_departure_or_bypass_1163  1
    arc_1_0_0  depot_return_or_bypass_1164  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_875  -25
    arc_1_0_7  depot_departure_or_bypass_1163  1
    arc_1_0_7  in_degree_1166  1
    arc_1_0_7  original_T_including_depot_unload_1244  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_875  1
    load_1_0_7  segment_load_conservation_1169  -1
    load_1_0_7  segment_prefix_lb_1170  1
    load_1_0_7  segment_prefix_ub_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_876  -25
    arc_1_0_8  depot_departure_or_bypass_1163  1
    arc_1_0_8  in_degree_1173  1
    arc_1_0_8  original_T_including_depot_unload_1244  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_876  1
    load_1_0_8  segment_load_conservation_1176  -1
    load_1_0_8  segment_prefix_lb_1177  1
    load_1_0_8  segment_prefix_ub_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_877  -25
    arc_1_0_9  depot_departure_or_bypass_1163  1
    arc_1_0_9  in_degree_1180  1
    arc_1_0_9  original_T_including_depot_unload_1244  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_877  1
    load_1_0_9  segment_load_conservation_1183  -1
    load_1_0_9  segment_prefix_lb_1184  1
    load_1_0_9  segment_prefix_ub_1185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_878  -25
    arc_1_0_10  depot_departure_or_bypass_1163  1
    arc_1_0_10  in_degree_1187  1
    arc_1_0_10  original_T_including_depot_unload_1244  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_878  1
    load_1_0_10  segment_load_conservation_1190  -1
    load_1_0_10  segment_prefix_lb_1191  1
    load_1_0_10  segment_prefix_ub_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_879  -25
    arc_1_0_15  depot_departure_or_bypass_1163  1
    arc_1_0_15  in_degree_1194  1
    arc_1_0_15  original_T_including_depot_unload_1244  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_879  1
    load_1_0_15  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_880  -25
    arc_1_0_16  depot_departure_or_bypass_1163  1
    arc_1_0_16  in_degree_1200  1
    arc_1_0_16  original_T_including_depot_unload_1244  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_880  1
    load_1_0_16  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_881  -25
    arc_1_0_17  depot_departure_or_bypass_1163  1
    arc_1_0_17  in_degree_1206  1
    arc_1_0_17  original_T_including_depot_unload_1244  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_881  1
    load_1_0_17  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_882  -25
    arc_1_0_18  depot_departure_or_bypass_1163  1
    arc_1_0_18  in_degree_1212  1
    arc_1_0_18  original_T_including_depot_unload_1244  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_882  1
    load_1_0_18  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_883  -25
    arc_1_0_19  depot_departure_or_bypass_1163  1
    arc_1_0_19  in_degree_1218  1
    arc_1_0_19  original_T_including_depot_unload_1244  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_883  1
    load_1_0_19  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_884  -25
    arc_1_0_20  depot_departure_or_bypass_1163  1
    arc_1_0_20  in_degree_1224  1
    arc_1_0_20  original_T_including_depot_unload_1244  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_884  1
    load_1_0_20  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_885  -25
    arc_1_0_21  depot_departure_or_bypass_1163  1
    arc_1_0_21  in_degree_1230  1
    arc_1_0_21  original_T_including_depot_unload_1244  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_885  1
    load_1_0_21  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_22  arc_capacity_886  -25
    arc_1_0_22  depot_departure_or_bypass_1163  1
    arc_1_0_22  in_degree_1236  1
    arc_1_0_22  original_T_including_depot_unload_1244  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_22  arc_capacity_886  1
    load_1_0_22  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_887  -25
    arc_1_7_0  depot_return_or_bypass_1164  1
    arc_1_7_0  out_degree_1165  1
    arc_1_7_0  original_T_including_depot_unload_1244  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_887  1
    load_1_7_0  segment_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_888  -25
    arc_1_7_8  connected_order_arc_889  -13
    arc_1_7_8  out_degree_1165  1
    arc_1_7_8  in_degree_1173  1
    arc_1_7_8  original_T_including_depot_unload_1244  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_888  1
    load_1_7_8  segment_load_conservation_1169  1
    load_1_7_8  segment_load_conservation_1176  -1
    load_1_7_8  segment_prefix_lb_1177  1
    load_1_7_8  segment_prefix_ub_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_890  -25
    arc_1_7_9  connected_order_arc_891  -13
    arc_1_7_9  out_degree_1165  1
    arc_1_7_9  in_degree_1180  1
    arc_1_7_9  original_T_including_depot_unload_1244  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_890  1
    load_1_7_9  segment_load_conservation_1169  1
    load_1_7_9  segment_load_conservation_1183  -1
    load_1_7_9  segment_prefix_lb_1184  1
    load_1_7_9  segment_prefix_ub_1185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_892  -25
    arc_1_7_10  connected_order_arc_893  -13
    arc_1_7_10  out_degree_1165  1
    arc_1_7_10  in_degree_1187  1
    arc_1_7_10  original_T_including_depot_unload_1244  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_892  1
    load_1_7_10  segment_load_conservation_1169  1
    load_1_7_10  segment_load_conservation_1190  -1
    load_1_7_10  segment_prefix_lb_1191  1
    load_1_7_10  segment_prefix_ub_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_894  -25
    arc_1_7_15  connected_order_arc_895  -13
    arc_1_7_15  out_degree_1165  1
    arc_1_7_15  in_degree_1194  1
    arc_1_7_15  original_T_including_depot_unload_1244  1.6726682877661206e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_894  1
    load_1_7_15  segment_load_conservation_1169  1
    load_1_7_15  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_896  -25
    arc_1_7_16  connected_order_arc_897  -13
    arc_1_7_16  out_degree_1165  1
    arc_1_7_16  in_degree_1200  1
    arc_1_7_16  original_T_including_depot_unload_1244  1.7809992976396034e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_896  1
    load_1_7_16  segment_load_conservation_1169  1
    load_1_7_16  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_898  -25
    arc_1_7_17  connected_order_arc_899  -13
    arc_1_7_17  out_degree_1165  1
    arc_1_7_17  in_degree_1206  1
    arc_1_7_17  original_T_including_depot_unload_1244  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_898  1
    load_1_7_17  segment_load_conservation_1169  1
    load_1_7_17  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_900  -25
    arc_1_7_18  connected_order_arc_901  -13
    arc_1_7_18  out_degree_1165  1
    arc_1_7_18  in_degree_1212  1
    arc_1_7_18  original_T_including_depot_unload_1244  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_900  1
    load_1_7_18  segment_load_conservation_1169  1
    load_1_7_18  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_902  -25
    arc_1_7_19  connected_order_arc_903  -13
    arc_1_7_19  out_degree_1165  1
    arc_1_7_19  in_degree_1218  1
    arc_1_7_19  original_T_including_depot_unload_1244  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_902  1
    load_1_7_19  segment_load_conservation_1169  1
    load_1_7_19  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_904  -25
    arc_1_7_20  connected_order_arc_905  -13
    arc_1_7_20  out_degree_1165  1
    arc_1_7_20  in_degree_1224  1
    arc_1_7_20  original_T_including_depot_unload_1244  1.8250469514445369e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_904  1
    load_1_7_20  segment_load_conservation_1169  1
    load_1_7_20  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_906  -25
    arc_1_7_21  connected_order_arc_907  -13
    arc_1_7_21  out_degree_1165  1
    arc_1_7_21  in_degree_1230  1
    arc_1_7_21  original_T_including_depot_unload_1244  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_906  1
    load_1_7_21  segment_load_conservation_1169  1
    load_1_7_21  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_22  arc_capacity_908  -25
    arc_1_7_22  connected_order_arc_909  -13
    arc_1_7_22  out_degree_1165  1
    arc_1_7_22  in_degree_1236  1
    arc_1_7_22  original_T_including_depot_unload_1244  1.4725441282427828e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_22  arc_capacity_908  1
    load_1_7_22  segment_load_conservation_1169  1
    load_1_7_22  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_910  -25
    arc_1_8_0  depot_return_or_bypass_1164  1
    arc_1_8_0  out_degree_1172  1
    arc_1_8_0  original_T_including_depot_unload_1244  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_910  1
    load_1_8_0  segment_load_conservation_1176  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_911  -25
    arc_1_8_7  connected_order_arc_912  -13
    arc_1_8_7  in_degree_1166  1
    arc_1_8_7  out_degree_1172  1
    arc_1_8_7  original_T_including_depot_unload_1244  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_911  1
    load_1_8_7  segment_load_conservation_1169  -1
    load_1_8_7  segment_prefix_lb_1170  1
    load_1_8_7  segment_prefix_ub_1171  1
    load_1_8_7  segment_load_conservation_1176  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_913  -25
    arc_1_8_9  connected_order_arc_914  -13
    arc_1_8_9  out_degree_1172  1
    arc_1_8_9  in_degree_1180  1
    arc_1_8_9  original_T_including_depot_unload_1244  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_913  1
    load_1_8_9  segment_load_conservation_1176  1
    load_1_8_9  segment_load_conservation_1183  -1
    load_1_8_9  segment_prefix_lb_1184  1
    load_1_8_9  segment_prefix_ub_1185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_915  -25
    arc_1_8_10  connected_order_arc_916  -13
    arc_1_8_10  out_degree_1172  1
    arc_1_8_10  in_degree_1187  1
    arc_1_8_10  original_T_including_depot_unload_1244  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_915  1
    load_1_8_10  segment_load_conservation_1176  1
    load_1_8_10  segment_load_conservation_1190  -1
    load_1_8_10  segment_prefix_lb_1191  1
    load_1_8_10  segment_prefix_ub_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_917  -25
    arc_1_8_15  connected_order_arc_918  -13
    arc_1_8_15  out_degree_1172  1
    arc_1_8_15  in_degree_1194  1
    arc_1_8_15  original_T_including_depot_unload_1244  1.5951553402938971e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_917  1
    load_1_8_15  segment_load_conservation_1176  1
    load_1_8_15  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_919  -25
    arc_1_8_16  connected_order_arc_920  -13
    arc_1_8_16  out_degree_1172  1
    arc_1_8_16  in_degree_1200  1
    arc_1_8_16  original_T_including_depot_unload_1244  1.6785246977297163e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_919  1
    load_1_8_16  segment_load_conservation_1176  1
    load_1_8_16  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_921  -25
    arc_1_8_17  connected_order_arc_922  -13
    arc_1_8_17  out_degree_1172  1
    arc_1_8_17  in_degree_1206  1
    arc_1_8_17  original_T_including_depot_unload_1244  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_921  1
    load_1_8_17  segment_load_conservation_1176  1
    load_1_8_17  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_923  -25
    arc_1_8_18  connected_order_arc_924  -13
    arc_1_8_18  out_degree_1172  1
    arc_1_8_18  in_degree_1212  1
    arc_1_8_18  original_T_including_depot_unload_1244  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_923  1
    load_1_8_18  segment_load_conservation_1176  1
    load_1_8_18  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_925  -25
    arc_1_8_19  connected_order_arc_926  -13
    arc_1_8_19  out_degree_1172  1
    arc_1_8_19  in_degree_1218  1
    arc_1_8_19  original_T_including_depot_unload_1244  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_925  1
    load_1_8_19  segment_load_conservation_1176  1
    load_1_8_19  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_927  -25
    arc_1_8_20  connected_order_arc_928  -13
    arc_1_8_20  out_degree_1172  1
    arc_1_8_20  in_degree_1224  1
    arc_1_8_20  original_T_including_depot_unload_1244  1.8050468619497597e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_927  1
    load_1_8_20  segment_load_conservation_1176  1
    load_1_8_20  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_929  -25
    arc_1_8_21  connected_order_arc_930  -13
    arc_1_8_21  out_degree_1172  1
    arc_1_8_21  in_degree_1230  1
    arc_1_8_21  original_T_including_depot_unload_1244  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_929  1
    load_1_8_21  segment_load_conservation_1176  1
    load_1_8_21  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_22  arc_capacity_931  -25
    arc_1_8_22  connected_order_arc_932  -13
    arc_1_8_22  out_degree_1172  1
    arc_1_8_22  in_degree_1236  1
    arc_1_8_22  original_T_including_depot_unload_1244  1.5393972350798747e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_22  arc_capacity_931  1
    load_1_8_22  segment_load_conservation_1176  1
    load_1_8_22  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_933  -25
    arc_1_9_0  depot_return_or_bypass_1164  1
    arc_1_9_0  out_degree_1179  1
    arc_1_9_0  original_T_including_depot_unload_1244  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_933  1
    load_1_9_0  segment_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_934  -25
    arc_1_9_7  connected_order_arc_935  -13
    arc_1_9_7  in_degree_1166  1
    arc_1_9_7  out_degree_1179  1
    arc_1_9_7  original_T_including_depot_unload_1244  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_934  1
    load_1_9_7  segment_load_conservation_1169  -1
    load_1_9_7  segment_prefix_lb_1170  1
    load_1_9_7  segment_prefix_ub_1171  1
    load_1_9_7  segment_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_936  -25
    arc_1_9_8  connected_order_arc_937  -13
    arc_1_9_8  in_degree_1173  1
    arc_1_9_8  out_degree_1179  1
    arc_1_9_8  original_T_including_depot_unload_1244  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_936  1
    load_1_9_8  segment_load_conservation_1176  -1
    load_1_9_8  segment_prefix_lb_1177  1
    load_1_9_8  segment_prefix_ub_1178  1
    load_1_9_8  segment_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_938  -25
    arc_1_9_10  connected_order_arc_939  -13
    arc_1_9_10  out_degree_1179  1
    arc_1_9_10  in_degree_1187  1
    arc_1_9_10  original_T_including_depot_unload_1244  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_938  1
    load_1_9_10  segment_load_conservation_1183  1
    load_1_9_10  segment_load_conservation_1190  -1
    load_1_9_10  segment_prefix_lb_1191  1
    load_1_9_10  segment_prefix_ub_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_940  -25
    arc_1_9_15  connected_order_arc_941  -13
    arc_1_9_15  out_degree_1179  1
    arc_1_9_15  in_degree_1194  1
    arc_1_9_15  original_T_including_depot_unload_1244  1.3608236268862893e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_940  1
    load_1_9_15  segment_load_conservation_1183  1
    load_1_9_15  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_942  -25
    arc_1_9_16  connected_order_arc_943  -13
    arc_1_9_16  out_degree_1179  1
    arc_1_9_16  in_degree_1200  1
    arc_1_9_16  original_T_including_depot_unload_1244  1.4516198129136008e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_942  1
    load_1_9_16  segment_load_conservation_1183  1
    load_1_9_16  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_944  -25
    arc_1_9_17  connected_order_arc_945  -13
    arc_1_9_17  out_degree_1179  1
    arc_1_9_17  in_degree_1206  1
    arc_1_9_17  original_T_including_depot_unload_1244  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_944  1
    load_1_9_17  segment_load_conservation_1183  1
    load_1_9_17  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_946  -25
    arc_1_9_18  connected_order_arc_947  -13
    arc_1_9_18  out_degree_1179  1
    arc_1_9_18  in_degree_1212  1
    arc_1_9_18  original_T_including_depot_unload_1244  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_946  1
    load_1_9_18  segment_load_conservation_1183  1
    load_1_9_18  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_948  -25
    arc_1_9_19  connected_order_arc_949  -13
    arc_1_9_19  out_degree_1179  1
    arc_1_9_19  in_degree_1218  1
    arc_1_9_19  original_T_including_depot_unload_1244  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_948  1
    load_1_9_19  segment_load_conservation_1183  1
    load_1_9_19  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_950  -25
    arc_1_9_20  connected_order_arc_951  -13
    arc_1_9_20  out_degree_1179  1
    arc_1_9_20  in_degree_1224  1
    arc_1_9_20  original_T_including_depot_unload_1244  1.5636076207019653e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_950  1
    load_1_9_20  segment_load_conservation_1183  1
    load_1_9_20  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_952  -25
    arc_1_9_21  connected_order_arc_953  -13
    arc_1_9_21  out_degree_1179  1
    arc_1_9_21  in_degree_1230  1
    arc_1_9_21  original_T_including_depot_unload_1244  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_952  1
    load_1_9_21  segment_load_conservation_1183  1
    load_1_9_21  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_22  arc_capacity_954  -25
    arc_1_9_22  connected_order_arc_955  -13
    arc_1_9_22  out_degree_1179  1
    arc_1_9_22  in_degree_1236  1
    arc_1_9_22  original_T_including_depot_unload_1244  1.3095620674514091e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_22  arc_capacity_954  1
    load_1_9_22  segment_load_conservation_1183  1
    load_1_9_22  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_956  -25
    arc_1_10_0  depot_return_or_bypass_1164  1
    arc_1_10_0  out_degree_1186  1
    arc_1_10_0  original_T_including_depot_unload_1244  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_956  1
    load_1_10_0  segment_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_957  -25
    arc_1_10_7  connected_order_arc_958  -13
    arc_1_10_7  in_degree_1166  1
    arc_1_10_7  out_degree_1186  1
    arc_1_10_7  original_T_including_depot_unload_1244  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_957  1
    load_1_10_7  segment_load_conservation_1169  -1
    load_1_10_7  segment_prefix_lb_1170  1
    load_1_10_7  segment_prefix_ub_1171  1
    load_1_10_7  segment_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_959  -25
    arc_1_10_8  connected_order_arc_960  -13
    arc_1_10_8  in_degree_1173  1
    arc_1_10_8  out_degree_1186  1
    arc_1_10_8  original_T_including_depot_unload_1244  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_959  1
    load_1_10_8  segment_load_conservation_1176  -1
    load_1_10_8  segment_prefix_lb_1177  1
    load_1_10_8  segment_prefix_ub_1178  1
    load_1_10_8  segment_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_961  -25
    arc_1_10_9  connected_order_arc_962  -13
    arc_1_10_9  in_degree_1180  1
    arc_1_10_9  out_degree_1186  1
    arc_1_10_9  original_T_including_depot_unload_1244  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_961  1
    load_1_10_9  segment_load_conservation_1183  -1
    load_1_10_9  segment_prefix_lb_1184  1
    load_1_10_9  segment_prefix_ub_1185  1
    load_1_10_9  segment_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_963  -25
    arc_1_10_15  connected_order_arc_964  -13
    arc_1_10_15  out_degree_1186  1
    arc_1_10_15  in_degree_1194  1
    arc_1_10_15  original_T_including_depot_unload_1244  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_963  1
    load_1_10_15  segment_load_conservation_1190  1
    load_1_10_15  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_965  -25
    arc_1_10_16  connected_order_arc_966  -13
    arc_1_10_16  out_degree_1186  1
    arc_1_10_16  in_degree_1200  1
    arc_1_10_16  original_T_including_depot_unload_1244  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_965  1
    load_1_10_16  segment_load_conservation_1190  1
    load_1_10_16  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_967  -25
    arc_1_10_17  connected_order_arc_968  -13
    arc_1_10_17  out_degree_1186  1
    arc_1_10_17  in_degree_1206  1
    arc_1_10_17  original_T_including_depot_unload_1244  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_967  1
    load_1_10_17  segment_load_conservation_1190  1
    load_1_10_17  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_969  -25
    arc_1_10_18  connected_order_arc_970  -13
    arc_1_10_18  out_degree_1186  1
    arc_1_10_18  in_degree_1212  1
    arc_1_10_18  original_T_including_depot_unload_1244  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_969  1
    load_1_10_18  segment_load_conservation_1190  1
    load_1_10_18  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_19  arc_capacity_971  -25
    arc_1_10_19  connected_order_arc_972  -13
    arc_1_10_19  out_degree_1186  1
    arc_1_10_19  in_degree_1218  1
    arc_1_10_19  original_T_including_depot_unload_1244  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_19  arc_capacity_971  1
    load_1_10_19  segment_load_conservation_1190  1
    load_1_10_19  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_20  arc_capacity_973  -25
    arc_1_10_20  connected_order_arc_974  -13
    arc_1_10_20  out_degree_1186  1
    arc_1_10_20  in_degree_1224  1
    arc_1_10_20  original_T_including_depot_unload_1244  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_20  arc_capacity_973  1
    load_1_10_20  segment_load_conservation_1190  1
    load_1_10_20  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_21  arc_capacity_975  -25
    arc_1_10_21  connected_order_arc_976  -13
    arc_1_10_21  out_degree_1186  1
    arc_1_10_21  in_degree_1230  1
    arc_1_10_21  original_T_including_depot_unload_1244  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_21  arc_capacity_975  1
    load_1_10_21  segment_load_conservation_1190  1
    load_1_10_21  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_22  arc_capacity_977  -25
    arc_1_10_22  connected_order_arc_978  -13
    arc_1_10_22  out_degree_1186  1
    arc_1_10_22  in_degree_1236  1
    arc_1_10_22  original_T_including_depot_unload_1244  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_22  arc_capacity_977  1
    load_1_10_22  segment_load_conservation_1190  1
    load_1_10_22  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_979  -25
    arc_1_15_0  depot_return_or_bypass_1164  1
    arc_1_15_0  out_degree_1193  1
    arc_1_15_0  original_T_including_depot_unload_1244  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_979  1
    load_1_15_0  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_980  -25
    arc_1_15_7  connected_order_arc_981  -13
    arc_1_15_7  in_degree_1166  1
    arc_1_15_7  out_degree_1193  1
    arc_1_15_7  original_T_including_depot_unload_1244  1.6726682877661206e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_980  1
    load_1_15_7  segment_load_conservation_1169  -1
    load_1_15_7  segment_prefix_lb_1170  1
    load_1_15_7  segment_prefix_ub_1171  1
    load_1_15_7  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_982  -25
    arc_1_15_8  connected_order_arc_983  -13
    arc_1_15_8  in_degree_1173  1
    arc_1_15_8  out_degree_1193  1
    arc_1_15_8  original_T_including_depot_unload_1244  1.5951553402938971e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_982  1
    load_1_15_8  segment_load_conservation_1176  -1
    load_1_15_8  segment_prefix_lb_1177  1
    load_1_15_8  segment_prefix_ub_1178  1
    load_1_15_8  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_984  -25
    arc_1_15_9  connected_order_arc_985  -13
    arc_1_15_9  in_degree_1180  1
    arc_1_15_9  out_degree_1193  1
    arc_1_15_9  original_T_including_depot_unload_1244  1.3608236268862893e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_984  1
    load_1_15_9  segment_load_conservation_1183  -1
    load_1_15_9  segment_prefix_lb_1184  1
    load_1_15_9  segment_prefix_ub_1185  1
    load_1_15_9  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_986  -25
    arc_1_15_10  connected_order_arc_987  -13
    arc_1_15_10  in_degree_1187  1
    arc_1_15_10  out_degree_1193  1
    arc_1_15_10  original_T_including_depot_unload_1244  1.8375396100269363e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_986  1
    load_1_15_10  segment_load_conservation_1190  -1
    load_1_15_10  segment_prefix_lb_1191  1
    load_1_15_10  segment_prefix_ub_1192  1
    load_1_15_10  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_988  -25
    arc_1_15_16  connected_order_arc_989  -13
    arc_1_15_16  out_degree_1193  1
    arc_1_15_16  in_degree_1200  1
    arc_1_15_16  original_T_including_depot_unload_1244  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_988  1
    load_1_15_16  free_load_conservation_1198  1
    load_1_15_16  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_990  -25
    arc_1_15_17  connected_order_arc_991  -13
    arc_1_15_17  out_degree_1193  1
    arc_1_15_17  in_degree_1206  1
    arc_1_15_17  original_T_including_depot_unload_1244  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_990  1
    load_1_15_17  free_load_conservation_1198  1
    load_1_15_17  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_992  -25
    arc_1_15_18  connected_order_arc_993  -13
    arc_1_15_18  out_degree_1193  1
    arc_1_15_18  in_degree_1212  1
    arc_1_15_18  original_T_including_depot_unload_1244  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_992  1
    load_1_15_18  free_load_conservation_1198  1
    load_1_15_18  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_994  -25
    arc_1_15_19  connected_order_arc_995  -13
    arc_1_15_19  out_degree_1193  1
    arc_1_15_19  in_degree_1218  1
    arc_1_15_19  original_T_including_depot_unload_1244  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_994  1
    load_1_15_19  free_load_conservation_1198  1
    load_1_15_19  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_996  -25
    arc_1_15_20  connected_order_arc_997  -13
    arc_1_15_20  out_degree_1193  1
    arc_1_15_20  in_degree_1224  1
    arc_1_15_20  original_T_including_depot_unload_1244  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_996  1
    load_1_15_20  free_load_conservation_1198  1
    load_1_15_20  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_998  -25
    arc_1_15_21  connected_order_arc_999  -13
    arc_1_15_21  out_degree_1193  1
    arc_1_15_21  in_degree_1230  1
    arc_1_15_21  original_T_including_depot_unload_1244  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_998  1
    load_1_15_21  free_load_conservation_1198  1
    load_1_15_21  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_22  arc_capacity_1000  -25
    arc_1_15_22  connected_order_arc_1001  -13
    arc_1_15_22  out_degree_1193  1
    arc_1_15_22  in_degree_1236  1
    arc_1_15_22  original_T_including_depot_unload_1244  7.9829177317292124e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_22  arc_capacity_1000  1
    load_1_15_22  free_load_conservation_1198  1
    load_1_15_22  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1002  -25
    arc_1_16_0  depot_return_or_bypass_1164  1
    arc_1_16_0  out_degree_1199  1
    arc_1_16_0  original_T_including_depot_unload_1244  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1002  1
    load_1_16_0  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1003  -25
    arc_1_16_7  connected_order_arc_1004  -13
    arc_1_16_7  in_degree_1166  1
    arc_1_16_7  out_degree_1199  1
    arc_1_16_7  original_T_including_depot_unload_1244  1.7809992976396034e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1003  1
    load_1_16_7  segment_load_conservation_1169  -1
    load_1_16_7  segment_prefix_lb_1170  1
    load_1_16_7  segment_prefix_ub_1171  1
    load_1_16_7  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1005  -25
    arc_1_16_8  connected_order_arc_1006  -13
    arc_1_16_8  in_degree_1173  1
    arc_1_16_8  out_degree_1199  1
    arc_1_16_8  original_T_including_depot_unload_1244  1.6785246977297163e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1005  1
    load_1_16_8  segment_load_conservation_1176  -1
    load_1_16_8  segment_prefix_lb_1177  1
    load_1_16_8  segment_prefix_ub_1178  1
    load_1_16_8  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1007  -25
    arc_1_16_9  connected_order_arc_1008  -13
    arc_1_16_9  in_degree_1180  1
    arc_1_16_9  out_degree_1199  1
    arc_1_16_9  original_T_including_depot_unload_1244  1.4516198129136008e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1007  1
    load_1_16_9  segment_load_conservation_1183  -1
    load_1_16_9  segment_prefix_lb_1184  1
    load_1_16_9  segment_prefix_ub_1185  1
    load_1_16_9  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1009  -25
    arc_1_16_10  connected_order_arc_1010  -13
    arc_1_16_10  in_degree_1187  1
    arc_1_16_10  out_degree_1199  1
    arc_1_16_10  original_T_including_depot_unload_1244  1.9434430494183746e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1009  1
    load_1_16_10  segment_load_conservation_1190  -1
    load_1_16_10  segment_prefix_lb_1191  1
    load_1_16_10  segment_prefix_ub_1192  1
    load_1_16_10  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1011  -25
    arc_1_16_15  connected_order_arc_1012  -13
    arc_1_16_15  in_degree_1194  1
    arc_1_16_15  out_degree_1199  1
    arc_1_16_15  original_T_including_depot_unload_1244  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1011  1
    load_1_16_15  free_load_conservation_1198  -1
    load_1_16_15  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1013  -25
    arc_1_16_17  connected_order_arc_1014  -13
    arc_1_16_17  out_degree_1199  1
    arc_1_16_17  in_degree_1206  1
    arc_1_16_17  original_T_including_depot_unload_1244  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1013  1
    load_1_16_17  free_load_conservation_1204  1
    load_1_16_17  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1015  -25
    arc_1_16_18  connected_order_arc_1016  -13
    arc_1_16_18  out_degree_1199  1
    arc_1_16_18  in_degree_1212  1
    arc_1_16_18  original_T_including_depot_unload_1244  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1015  1
    load_1_16_18  free_load_conservation_1204  1
    load_1_16_18  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1017  -25
    arc_1_16_19  connected_order_arc_1018  -13
    arc_1_16_19  out_degree_1199  1
    arc_1_16_19  in_degree_1218  1
    arc_1_16_19  original_T_including_depot_unload_1244  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1017  1
    load_1_16_19  free_load_conservation_1204  1
    load_1_16_19  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1019  -25
    arc_1_16_20  connected_order_arc_1020  -13
    arc_1_16_20  out_degree_1199  1
    arc_1_16_20  in_degree_1224  1
    arc_1_16_20  original_T_including_depot_unload_1244  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1019  1
    load_1_16_20  free_load_conservation_1204  1
    load_1_16_20  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1021  -25
    arc_1_16_21  connected_order_arc_1022  -13
    arc_1_16_21  out_degree_1199  1
    arc_1_16_21  in_degree_1230  1
    arc_1_16_21  original_T_including_depot_unload_1244  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1021  1
    load_1_16_21  free_load_conservation_1204  1
    load_1_16_21  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_22  arc_capacity_1023  -25
    arc_1_16_22  connected_order_arc_1024  -13
    arc_1_16_22  out_degree_1199  1
    arc_1_16_22  in_degree_1236  1
    arc_1_16_22  original_T_including_depot_unload_1244  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_22  arc_capacity_1023  1
    load_1_16_22  free_load_conservation_1204  1
    load_1_16_22  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1025  -25
    arc_1_17_0  depot_return_or_bypass_1164  1
    arc_1_17_0  out_degree_1205  1
    arc_1_17_0  original_T_including_depot_unload_1244  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1025  1
    load_1_17_0  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1026  -25
    arc_1_17_7  connected_order_arc_1027  -13
    arc_1_17_7  in_degree_1166  1
    arc_1_17_7  out_degree_1205  1
    arc_1_17_7  original_T_including_depot_unload_1244  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1026  1
    load_1_17_7  segment_load_conservation_1169  -1
    load_1_17_7  segment_prefix_lb_1170  1
    load_1_17_7  segment_prefix_ub_1171  1
    load_1_17_7  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1028  -25
    arc_1_17_8  connected_order_arc_1029  -13
    arc_1_17_8  in_degree_1173  1
    arc_1_17_8  out_degree_1205  1
    arc_1_17_8  original_T_including_depot_unload_1244  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1028  1
    load_1_17_8  segment_load_conservation_1176  -1
    load_1_17_8  segment_prefix_lb_1177  1
    load_1_17_8  segment_prefix_ub_1178  1
    load_1_17_8  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1030  -25
    arc_1_17_9  connected_order_arc_1031  -13
    arc_1_17_9  in_degree_1180  1
    arc_1_17_9  out_degree_1205  1
    arc_1_17_9  original_T_including_depot_unload_1244  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1030  1
    load_1_17_9  segment_load_conservation_1183  -1
    load_1_17_9  segment_prefix_lb_1184  1
    load_1_17_9  segment_prefix_ub_1185  1
    load_1_17_9  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1032  -25
    arc_1_17_10  connected_order_arc_1033  -13
    arc_1_17_10  in_degree_1187  1
    arc_1_17_10  out_degree_1205  1
    arc_1_17_10  original_T_including_depot_unload_1244  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1032  1
    load_1_17_10  segment_load_conservation_1190  -1
    load_1_17_10  segment_prefix_lb_1191  1
    load_1_17_10  segment_prefix_ub_1192  1
    load_1_17_10  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1034  -25
    arc_1_17_15  connected_order_arc_1035  -13
    arc_1_17_15  in_degree_1194  1
    arc_1_17_15  out_degree_1205  1
    arc_1_17_15  original_T_including_depot_unload_1244  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1034  1
    load_1_17_15  free_load_conservation_1198  -1
    load_1_17_15  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1036  -25
    arc_1_17_16  connected_order_arc_1037  -13
    arc_1_17_16  in_degree_1200  1
    arc_1_17_16  out_degree_1205  1
    arc_1_17_16  original_T_including_depot_unload_1244  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1036  1
    load_1_17_16  free_load_conservation_1204  -1
    load_1_17_16  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1038  -25
    arc_1_17_18  connected_order_arc_1039  -13
    arc_1_17_18  out_degree_1205  1
    arc_1_17_18  in_degree_1212  1
    arc_1_17_18  original_T_including_depot_unload_1244  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1038  1
    load_1_17_18  free_load_conservation_1210  1
    load_1_17_18  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1040  -25
    arc_1_17_19  connected_order_arc_1041  -13
    arc_1_17_19  out_degree_1205  1
    arc_1_17_19  in_degree_1218  1
    arc_1_17_19  original_T_including_depot_unload_1244  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1040  1
    load_1_17_19  free_load_conservation_1210  1
    load_1_17_19  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1042  -25
    arc_1_17_20  connected_order_arc_1043  -13
    arc_1_17_20  out_degree_1205  1
    arc_1_17_20  in_degree_1224  1
    arc_1_17_20  original_T_including_depot_unload_1244  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1042  1
    load_1_17_20  free_load_conservation_1210  1
    load_1_17_20  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1044  -25
    arc_1_17_21  connected_order_arc_1045  -13
    arc_1_17_21  out_degree_1205  1
    arc_1_17_21  in_degree_1230  1
    arc_1_17_21  original_T_including_depot_unload_1244  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1044  1
    load_1_17_21  free_load_conservation_1210  1
    load_1_17_21  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_22  arc_capacity_1046  -25
    arc_1_17_22  connected_order_arc_1047  -13
    arc_1_17_22  out_degree_1205  1
    arc_1_17_22  in_degree_1236  1
    arc_1_17_22  original_T_including_depot_unload_1244  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_22  arc_capacity_1046  1
    load_1_17_22  free_load_conservation_1210  1
    load_1_17_22  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1048  -25
    arc_1_18_0  depot_return_or_bypass_1164  1
    arc_1_18_0  out_degree_1211  1
    arc_1_18_0  original_T_including_depot_unload_1244  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1048  1
    load_1_18_0  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1049  -25
    arc_1_18_7  connected_order_arc_1050  -13
    arc_1_18_7  in_degree_1166  1
    arc_1_18_7  out_degree_1211  1
    arc_1_18_7  original_T_including_depot_unload_1244  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1049  1
    load_1_18_7  segment_load_conservation_1169  -1
    load_1_18_7  segment_prefix_lb_1170  1
    load_1_18_7  segment_prefix_ub_1171  1
    load_1_18_7  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1051  -25
    arc_1_18_8  connected_order_arc_1052  -13
    arc_1_18_8  in_degree_1173  1
    arc_1_18_8  out_degree_1211  1
    arc_1_18_8  original_T_including_depot_unload_1244  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1051  1
    load_1_18_8  segment_load_conservation_1176  -1
    load_1_18_8  segment_prefix_lb_1177  1
    load_1_18_8  segment_prefix_ub_1178  1
    load_1_18_8  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1053  -25
    arc_1_18_9  connected_order_arc_1054  -13
    arc_1_18_9  in_degree_1180  1
    arc_1_18_9  out_degree_1211  1
    arc_1_18_9  original_T_including_depot_unload_1244  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1053  1
    load_1_18_9  segment_load_conservation_1183  -1
    load_1_18_9  segment_prefix_lb_1184  1
    load_1_18_9  segment_prefix_ub_1185  1
    load_1_18_9  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1055  -25
    arc_1_18_10  connected_order_arc_1056  -13
    arc_1_18_10  in_degree_1187  1
    arc_1_18_10  out_degree_1211  1
    arc_1_18_10  original_T_including_depot_unload_1244  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1055  1
    load_1_18_10  segment_load_conservation_1190  -1
    load_1_18_10  segment_prefix_lb_1191  1
    load_1_18_10  segment_prefix_ub_1192  1
    load_1_18_10  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1057  -25
    arc_1_18_15  connected_order_arc_1058  -13
    arc_1_18_15  in_degree_1194  1
    arc_1_18_15  out_degree_1211  1
    arc_1_18_15  original_T_including_depot_unload_1244  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1057  1
    load_1_18_15  free_load_conservation_1198  -1
    load_1_18_15  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1059  -25
    arc_1_18_16  connected_order_arc_1060  -13
    arc_1_18_16  in_degree_1200  1
    arc_1_18_16  out_degree_1211  1
    arc_1_18_16  original_T_including_depot_unload_1244  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1059  1
    load_1_18_16  free_load_conservation_1204  -1
    load_1_18_16  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1061  -25
    arc_1_18_17  connected_order_arc_1062  -13
    arc_1_18_17  in_degree_1206  1
    arc_1_18_17  out_degree_1211  1
    arc_1_18_17  original_T_including_depot_unload_1244  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1061  1
    load_1_18_17  free_load_conservation_1210  -1
    load_1_18_17  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1063  -25
    arc_1_18_19  connected_order_arc_1064  -13
    arc_1_18_19  out_degree_1211  1
    arc_1_18_19  in_degree_1218  1
    arc_1_18_19  original_T_including_depot_unload_1244  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1063  1
    load_1_18_19  free_load_conservation_1216  1
    load_1_18_19  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1065  -25
    arc_1_18_20  connected_order_arc_1066  -13
    arc_1_18_20  out_degree_1211  1
    arc_1_18_20  in_degree_1224  1
    arc_1_18_20  original_T_including_depot_unload_1244  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1065  1
    load_1_18_20  free_load_conservation_1216  1
    load_1_18_20  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1067  -25
    arc_1_18_21  connected_order_arc_1068  -13
    arc_1_18_21  out_degree_1211  1
    arc_1_18_21  in_degree_1230  1
    arc_1_18_21  original_T_including_depot_unload_1244  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1067  1
    load_1_18_21  free_load_conservation_1216  1
    load_1_18_21  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_22  arc_capacity_1069  -25
    arc_1_18_22  connected_order_arc_1070  -13
    arc_1_18_22  out_degree_1211  1
    arc_1_18_22  in_degree_1236  1
    arc_1_18_22  original_T_including_depot_unload_1244  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_22  arc_capacity_1069  1
    load_1_18_22  free_load_conservation_1216  1
    load_1_18_22  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1071  -25
    arc_1_19_0  depot_return_or_bypass_1164  1
    arc_1_19_0  out_degree_1217  1
    arc_1_19_0  original_T_including_depot_unload_1244  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1071  1
    load_1_19_0  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1072  -25
    arc_1_19_7  connected_order_arc_1073  -13
    arc_1_19_7  in_degree_1166  1
    arc_1_19_7  out_degree_1217  1
    arc_1_19_7  original_T_including_depot_unload_1244  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1072  1
    load_1_19_7  segment_load_conservation_1169  -1
    load_1_19_7  segment_prefix_lb_1170  1
    load_1_19_7  segment_prefix_ub_1171  1
    load_1_19_7  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1074  -25
    arc_1_19_8  connected_order_arc_1075  -13
    arc_1_19_8  in_degree_1173  1
    arc_1_19_8  out_degree_1217  1
    arc_1_19_8  original_T_including_depot_unload_1244  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1074  1
    load_1_19_8  segment_load_conservation_1176  -1
    load_1_19_8  segment_prefix_lb_1177  1
    load_1_19_8  segment_prefix_ub_1178  1
    load_1_19_8  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1076  -25
    arc_1_19_9  connected_order_arc_1077  -13
    arc_1_19_9  in_degree_1180  1
    arc_1_19_9  out_degree_1217  1
    arc_1_19_9  original_T_including_depot_unload_1244  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1076  1
    load_1_19_9  segment_load_conservation_1183  -1
    load_1_19_9  segment_prefix_lb_1184  1
    load_1_19_9  segment_prefix_ub_1185  1
    load_1_19_9  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_10  arc_capacity_1078  -25
    arc_1_19_10  connected_order_arc_1079  -13
    arc_1_19_10  in_degree_1187  1
    arc_1_19_10  out_degree_1217  1
    arc_1_19_10  original_T_including_depot_unload_1244  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_10  arc_capacity_1078  1
    load_1_19_10  segment_load_conservation_1190  -1
    load_1_19_10  segment_prefix_lb_1191  1
    load_1_19_10  segment_prefix_ub_1192  1
    load_1_19_10  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1080  -25
    arc_1_19_15  connected_order_arc_1081  -13
    arc_1_19_15  in_degree_1194  1
    arc_1_19_15  out_degree_1217  1
    arc_1_19_15  original_T_including_depot_unload_1244  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1080  1
    load_1_19_15  free_load_conservation_1198  -1
    load_1_19_15  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1082  -25
    arc_1_19_16  connected_order_arc_1083  -13
    arc_1_19_16  in_degree_1200  1
    arc_1_19_16  out_degree_1217  1
    arc_1_19_16  original_T_including_depot_unload_1244  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1082  1
    load_1_19_16  free_load_conservation_1204  -1
    load_1_19_16  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1084  -25
    arc_1_19_17  connected_order_arc_1085  -13
    arc_1_19_17  in_degree_1206  1
    arc_1_19_17  out_degree_1217  1
    arc_1_19_17  original_T_including_depot_unload_1244  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1084  1
    load_1_19_17  free_load_conservation_1210  -1
    load_1_19_17  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1086  -25
    arc_1_19_18  connected_order_arc_1087  -13
    arc_1_19_18  in_degree_1212  1
    arc_1_19_18  out_degree_1217  1
    arc_1_19_18  original_T_including_depot_unload_1244  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1086  1
    load_1_19_18  free_load_conservation_1216  -1
    load_1_19_18  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1088  -25
    arc_1_19_20  connected_order_arc_1089  -13
    arc_1_19_20  out_degree_1217  1
    arc_1_19_20  in_degree_1224  1
    arc_1_19_20  original_T_including_depot_unload_1244  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1088  1
    load_1_19_20  free_load_conservation_1222  1
    load_1_19_20  free_load_conservation_1228  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1090  -25
    arc_1_19_21  connected_order_arc_1091  -13
    arc_1_19_21  out_degree_1217  1
    arc_1_19_21  in_degree_1230  1
    arc_1_19_21  original_T_including_depot_unload_1244  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1090  1
    load_1_19_21  free_load_conservation_1222  1
    load_1_19_21  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_22  arc_capacity_1092  -25
    arc_1_19_22  connected_order_arc_1093  -13
    arc_1_19_22  out_degree_1217  1
    arc_1_19_22  in_degree_1236  1
    arc_1_19_22  original_T_including_depot_unload_1244  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_22  arc_capacity_1092  1
    load_1_19_22  free_load_conservation_1222  1
    load_1_19_22  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1094  -25
    arc_1_20_0  depot_return_or_bypass_1164  1
    arc_1_20_0  out_degree_1223  1
    arc_1_20_0  original_T_including_depot_unload_1244  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1094  1
    load_1_20_0  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1095  -25
    arc_1_20_7  connected_order_arc_1096  -13
    arc_1_20_7  in_degree_1166  1
    arc_1_20_7  out_degree_1223  1
    arc_1_20_7  original_T_including_depot_unload_1244  1.8250469514445369e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1095  1
    load_1_20_7  segment_load_conservation_1169  -1
    load_1_20_7  segment_prefix_lb_1170  1
    load_1_20_7  segment_prefix_ub_1171  1
    load_1_20_7  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1097  -25
    arc_1_20_8  connected_order_arc_1098  -13
    arc_1_20_8  in_degree_1173  1
    arc_1_20_8  out_degree_1223  1
    arc_1_20_8  original_T_including_depot_unload_1244  1.8050468619497597e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1097  1
    load_1_20_8  segment_load_conservation_1176  -1
    load_1_20_8  segment_prefix_lb_1177  1
    load_1_20_8  segment_prefix_ub_1178  1
    load_1_20_8  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1099  -25
    arc_1_20_9  connected_order_arc_1100  -13
    arc_1_20_9  in_degree_1180  1
    arc_1_20_9  out_degree_1223  1
    arc_1_20_9  original_T_including_depot_unload_1244  1.5636076207019653e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1099  1
    load_1_20_9  segment_load_conservation_1183  -1
    load_1_20_9  segment_prefix_lb_1184  1
    load_1_20_9  segment_prefix_ub_1185  1
    load_1_20_9  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_10  arc_capacity_1101  -25
    arc_1_20_10  connected_order_arc_1102  -13
    arc_1_20_10  in_degree_1187  1
    arc_1_20_10  out_degree_1223  1
    arc_1_20_10  original_T_including_depot_unload_1244  1.9912760202020529e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_10  arc_capacity_1101  1
    load_1_20_10  segment_load_conservation_1190  -1
    load_1_20_10  segment_prefix_lb_1191  1
    load_1_20_10  segment_prefix_ub_1192  1
    load_1_20_10  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1103  -25
    arc_1_20_15  connected_order_arc_1104  -13
    arc_1_20_15  in_degree_1194  1
    arc_1_20_15  out_degree_1223  1
    arc_1_20_15  original_T_including_depot_unload_1244  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1103  1
    load_1_20_15  free_load_conservation_1198  -1
    load_1_20_15  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1105  -25
    arc_1_20_16  connected_order_arc_1106  -13
    arc_1_20_16  in_degree_1200  1
    arc_1_20_16  out_degree_1223  1
    arc_1_20_16  original_T_including_depot_unload_1244  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1105  1
    load_1_20_16  free_load_conservation_1204  -1
    load_1_20_16  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1107  -25
    arc_1_20_17  connected_order_arc_1108  -13
    arc_1_20_17  in_degree_1206  1
    arc_1_20_17  out_degree_1223  1
    arc_1_20_17  original_T_including_depot_unload_1244  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1107  1
    load_1_20_17  free_load_conservation_1210  -1
    load_1_20_17  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1109  -25
    arc_1_20_18  connected_order_arc_1110  -13
    arc_1_20_18  in_degree_1212  1
    arc_1_20_18  out_degree_1223  1
    arc_1_20_18  original_T_including_depot_unload_1244  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1109  1
    load_1_20_18  free_load_conservation_1216  -1
    load_1_20_18  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1111  -25
    arc_1_20_19  connected_order_arc_1112  -13
    arc_1_20_19  in_degree_1218  1
    arc_1_20_19  out_degree_1223  1
    arc_1_20_19  original_T_including_depot_unload_1244  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1111  1
    load_1_20_19  free_load_conservation_1222  -1
    load_1_20_19  free_load_conservation_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1113  -25
    arc_1_20_21  connected_order_arc_1114  -13
    arc_1_20_21  out_degree_1223  1
    arc_1_20_21  in_degree_1230  1
    arc_1_20_21  original_T_including_depot_unload_1244  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1113  1
    load_1_20_21  free_load_conservation_1228  1
    load_1_20_21  free_load_conservation_1234  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_22  arc_capacity_1115  -25
    arc_1_20_22  connected_order_arc_1116  -13
    arc_1_20_22  out_degree_1223  1
    arc_1_20_22  in_degree_1236  1
    arc_1_20_22  original_T_including_depot_unload_1244  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_22  arc_capacity_1115  1
    load_1_20_22  free_load_conservation_1228  1
    load_1_20_22  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1117  -25
    arc_1_21_0  depot_return_or_bypass_1164  1
    arc_1_21_0  out_degree_1229  1
    arc_1_21_0  original_T_including_depot_unload_1244  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1117  1
    load_1_21_0  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1118  -25
    arc_1_21_7  connected_order_arc_1119  -13
    arc_1_21_7  in_degree_1166  1
    arc_1_21_7  out_degree_1229  1
    arc_1_21_7  original_T_including_depot_unload_1244  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1118  1
    load_1_21_7  segment_load_conservation_1169  -1
    load_1_21_7  segment_prefix_lb_1170  1
    load_1_21_7  segment_prefix_ub_1171  1
    load_1_21_7  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1120  -25
    arc_1_21_8  connected_order_arc_1121  -13
    arc_1_21_8  in_degree_1173  1
    arc_1_21_8  out_degree_1229  1
    arc_1_21_8  original_T_including_depot_unload_1244  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1120  1
    load_1_21_8  segment_load_conservation_1176  -1
    load_1_21_8  segment_prefix_lb_1177  1
    load_1_21_8  segment_prefix_ub_1178  1
    load_1_21_8  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1122  -25
    arc_1_21_9  connected_order_arc_1123  -13
    arc_1_21_9  in_degree_1180  1
    arc_1_21_9  out_degree_1229  1
    arc_1_21_9  original_T_including_depot_unload_1244  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1122  1
    load_1_21_9  segment_load_conservation_1183  -1
    load_1_21_9  segment_prefix_lb_1184  1
    load_1_21_9  segment_prefix_ub_1185  1
    load_1_21_9  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_10  arc_capacity_1124  -25
    arc_1_21_10  connected_order_arc_1125  -13
    arc_1_21_10  in_degree_1187  1
    arc_1_21_10  out_degree_1229  1
    arc_1_21_10  original_T_including_depot_unload_1244  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_10  arc_capacity_1124  1
    load_1_21_10  segment_load_conservation_1190  -1
    load_1_21_10  segment_prefix_lb_1191  1
    load_1_21_10  segment_prefix_ub_1192  1
    load_1_21_10  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1126  -25
    arc_1_21_15  connected_order_arc_1127  -13
    arc_1_21_15  in_degree_1194  1
    arc_1_21_15  out_degree_1229  1
    arc_1_21_15  original_T_including_depot_unload_1244  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1126  1
    load_1_21_15  free_load_conservation_1198  -1
    load_1_21_15  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1128  -25
    arc_1_21_16  connected_order_arc_1129  -13
    arc_1_21_16  in_degree_1200  1
    arc_1_21_16  out_degree_1229  1
    arc_1_21_16  original_T_including_depot_unload_1244  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1128  1
    load_1_21_16  free_load_conservation_1204  -1
    load_1_21_16  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1130  -25
    arc_1_21_17  connected_order_arc_1131  -13
    arc_1_21_17  in_degree_1206  1
    arc_1_21_17  out_degree_1229  1
    arc_1_21_17  original_T_including_depot_unload_1244  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1130  1
    load_1_21_17  free_load_conservation_1210  -1
    load_1_21_17  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1132  -25
    arc_1_21_18  connected_order_arc_1133  -13
    arc_1_21_18  in_degree_1212  1
    arc_1_21_18  out_degree_1229  1
    arc_1_21_18  original_T_including_depot_unload_1244  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1132  1
    load_1_21_18  free_load_conservation_1216  -1
    load_1_21_18  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1134  -25
    arc_1_21_19  connected_order_arc_1135  -13
    arc_1_21_19  in_degree_1218  1
    arc_1_21_19  out_degree_1229  1
    arc_1_21_19  original_T_including_depot_unload_1244  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1134  1
    load_1_21_19  free_load_conservation_1222  -1
    load_1_21_19  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1136  -25
    arc_1_21_20  connected_order_arc_1137  -13
    arc_1_21_20  in_degree_1224  1
    arc_1_21_20  out_degree_1229  1
    arc_1_21_20  original_T_including_depot_unload_1244  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1136  1
    load_1_21_20  free_load_conservation_1228  -1
    load_1_21_20  free_load_conservation_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_22  arc_capacity_1138  -25
    arc_1_21_22  connected_order_arc_1139  -13
    arc_1_21_22  out_degree_1229  1
    arc_1_21_22  in_degree_1236  1
    arc_1_21_22  original_T_including_depot_unload_1244  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_22  arc_capacity_1138  1
    load_1_21_22  free_load_conservation_1234  1
    load_1_21_22  free_load_conservation_1240  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_0  arc_capacity_1140  -25
    arc_1_22_0  depot_return_or_bypass_1164  1
    arc_1_22_0  out_degree_1235  1
    arc_1_22_0  original_T_including_depot_unload_1244  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_0  arc_capacity_1140  1
    load_1_22_0  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_7  arc_capacity_1141  -25
    arc_1_22_7  connected_order_arc_1142  -13
    arc_1_22_7  in_degree_1166  1
    arc_1_22_7  out_degree_1235  1
    arc_1_22_7  original_T_including_depot_unload_1244  1.4725441282427828e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_7  arc_capacity_1141  1
    load_1_22_7  segment_load_conservation_1169  -1
    load_1_22_7  segment_prefix_lb_1170  1
    load_1_22_7  segment_prefix_ub_1171  1
    load_1_22_7  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_8  arc_capacity_1143  -25
    arc_1_22_8  connected_order_arc_1144  -13
    arc_1_22_8  in_degree_1173  1
    arc_1_22_8  out_degree_1235  1
    arc_1_22_8  original_T_including_depot_unload_1244  1.5393972350798747e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_8  arc_capacity_1143  1
    load_1_22_8  segment_load_conservation_1176  -1
    load_1_22_8  segment_prefix_lb_1177  1
    load_1_22_8  segment_prefix_ub_1178  1
    load_1_22_8  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_9  arc_capacity_1145  -25
    arc_1_22_9  connected_order_arc_1146  -13
    arc_1_22_9  in_degree_1180  1
    arc_1_22_9  out_degree_1235  1
    arc_1_22_9  original_T_including_depot_unload_1244  1.3095620674514091e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_9  arc_capacity_1145  1
    load_1_22_9  segment_load_conservation_1183  -1
    load_1_22_9  segment_prefix_lb_1184  1
    load_1_22_9  segment_prefix_ub_1185  1
    load_1_22_9  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_10  arc_capacity_1147  -25
    arc_1_22_10  connected_order_arc_1148  -13
    arc_1_22_10  in_degree_1187  1
    arc_1_22_10  out_degree_1235  1
    arc_1_22_10  original_T_including_depot_unload_1244  1.6299527591666472e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_10  arc_capacity_1147  1
    load_1_22_10  segment_load_conservation_1190  -1
    load_1_22_10  segment_prefix_lb_1191  1
    load_1_22_10  segment_prefix_ub_1192  1
    load_1_22_10  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_15  arc_capacity_1149  -25
    arc_1_22_15  connected_order_arc_1150  -13
    arc_1_22_15  in_degree_1194  1
    arc_1_22_15  out_degree_1235  1
    arc_1_22_15  original_T_including_depot_unload_1244  7.9829177317292124e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_15  arc_capacity_1149  1
    load_1_22_15  free_load_conservation_1198  -1
    load_1_22_15  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_16  arc_capacity_1151  -25
    arc_1_22_16  connected_order_arc_1152  -13
    arc_1_22_16  in_degree_1200  1
    arc_1_22_16  out_degree_1235  1
    arc_1_22_16  original_T_including_depot_unload_1244  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_16  arc_capacity_1151  1
    load_1_22_16  free_load_conservation_1204  -1
    load_1_22_16  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_17  arc_capacity_1153  -25
    arc_1_22_17  connected_order_arc_1154  -13
    arc_1_22_17  in_degree_1206  1
    arc_1_22_17  out_degree_1235  1
    arc_1_22_17  original_T_including_depot_unload_1244  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_17  arc_capacity_1153  1
    load_1_22_17  free_load_conservation_1210  -1
    load_1_22_17  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_18  arc_capacity_1155  -25
    arc_1_22_18  connected_order_arc_1156  -13
    arc_1_22_18  in_degree_1212  1
    arc_1_22_18  out_degree_1235  1
    arc_1_22_18  original_T_including_depot_unload_1244  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_18  arc_capacity_1155  1
    load_1_22_18  free_load_conservation_1216  -1
    load_1_22_18  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_19  arc_capacity_1157  -25
    arc_1_22_19  connected_order_arc_1158  -13
    arc_1_22_19  in_degree_1218  1
    arc_1_22_19  out_degree_1235  1
    arc_1_22_19  original_T_including_depot_unload_1244  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_19  arc_capacity_1157  1
    load_1_22_19  free_load_conservation_1222  -1
    load_1_22_19  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_20  arc_capacity_1159  -25
    arc_1_22_20  connected_order_arc_1160  -13
    arc_1_22_20  in_degree_1224  1
    arc_1_22_20  out_degree_1235  1
    arc_1_22_20  original_T_including_depot_unload_1244  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_20  arc_capacity_1159  1
    load_1_22_20  free_load_conservation_1228  -1
    load_1_22_20  free_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_21  arc_capacity_1161  -25
    arc_1_22_21  connected_order_arc_1162  -13
    arc_1_22_21  in_degree_1230  1
    arc_1_22_21  out_degree_1235  1
    arc_1_22_21  original_T_including_depot_unload_1244  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_21  arc_capacity_1161  1
    load_1_22_21  free_load_conservation_1234  -1
    load_1_22_21  free_load_conservation_1240  1
    visit_2_11  out_degree_1536  -1
    visit_2_11  in_degree_1537  -1
    visit_2_11  order_active_lb_1538  -1
    visit_2_11  order_active_ub_1539  -12
    order_2_11  connected_order_arc_1260  -1
    order_2_11  connected_order_arc_1262  -1
    order_2_11  connected_order_arc_1264  -1
    order_2_11  connected_order_arc_1266  -1
    order_2_11  connected_order_arc_1268  -1
    order_2_11  connected_order_arc_1270  -1
    order_2_11  connected_order_arc_1272  -1
    order_2_11  connected_order_arc_1274  -1
    order_2_11  connected_order_arc_1276  -1
    order_2_11  connected_order_arc_1278  -1
    order_2_11  connected_order_arc_1280  -1
    order_2_11  connected_order_arc_1283  1
    order_2_11  connected_order_arc_1306  1
    order_2_11  connected_order_arc_1329  1
    order_2_11  connected_order_arc_1352  1
    order_2_11  connected_order_arc_1375  1
    order_2_11  connected_order_arc_1398  1
    order_2_11  connected_order_arc_1421  1
    order_2_11  connected_order_arc_1444  1
    order_2_11  connected_order_arc_1467  1
    order_2_11  connected_order_arc_1490  1
    order_2_11  connected_order_arc_1513  1
    order_2_11  order_active_lb_1538  1
    order_2_11  order_active_ub_1539  1
    order_2_11  fixed_segment_relative_order_1612  -1
    visit_2_12  out_degree_1543  -1
    visit_2_12  in_degree_1544  -1
    visit_2_12  order_active_lb_1545  -1
    visit_2_12  order_active_ub_1546  -12
    order_2_12  connected_order_arc_1260  1
    order_2_12  connected_order_arc_1283  -1
    order_2_12  connected_order_arc_1285  -1
    order_2_12  connected_order_arc_1287  -1
    order_2_12  connected_order_arc_1289  -1
    order_2_12  connected_order_arc_1291  -1
    order_2_12  connected_order_arc_1293  -1
    order_2_12  connected_order_arc_1295  -1
    order_2_12  connected_order_arc_1297  -1
    order_2_12  connected_order_arc_1299  -1
    order_2_12  connected_order_arc_1301  -1
    order_2_12  connected_order_arc_1303  -1
    order_2_12  connected_order_arc_1308  1
    order_2_12  connected_order_arc_1331  1
    order_2_12  connected_order_arc_1354  1
    order_2_12  connected_order_arc_1377  1
    order_2_12  connected_order_arc_1400  1
    order_2_12  connected_order_arc_1423  1
    order_2_12  connected_order_arc_1446  1
    order_2_12  connected_order_arc_1469  1
    order_2_12  connected_order_arc_1492  1
    order_2_12  connected_order_arc_1515  1
    order_2_12  order_active_lb_1545  1
    order_2_12  order_active_ub_1546  1
    order_2_12  fixed_segment_relative_order_1612  1
    order_2_12  fixed_segment_relative_order_1613  -1
    visit_2_13  out_degree_1550  -1
    visit_2_13  in_degree_1551  -1
    visit_2_13  order_active_lb_1552  -1
    visit_2_13  order_active_ub_1553  -12
    order_2_13  connected_order_arc_1262  1
    order_2_13  connected_order_arc_1285  1
    order_2_13  connected_order_arc_1306  -1
    order_2_13  connected_order_arc_1308  -1
    order_2_13  connected_order_arc_1310  -1
    order_2_13  connected_order_arc_1312  -1
    order_2_13  connected_order_arc_1314  -1
    order_2_13  connected_order_arc_1316  -1
    order_2_13  connected_order_arc_1318  -1
    order_2_13  connected_order_arc_1320  -1
    order_2_13  connected_order_arc_1322  -1
    order_2_13  connected_order_arc_1324  -1
    order_2_13  connected_order_arc_1326  -1
    order_2_13  connected_order_arc_1333  1
    order_2_13  connected_order_arc_1356  1
    order_2_13  connected_order_arc_1379  1
    order_2_13  connected_order_arc_1402  1
    order_2_13  connected_order_arc_1425  1
    order_2_13  connected_order_arc_1448  1
    order_2_13  connected_order_arc_1471  1
    order_2_13  connected_order_arc_1494  1
    order_2_13  connected_order_arc_1517  1
    order_2_13  order_active_lb_1552  1
    order_2_13  order_active_ub_1553  1
    order_2_13  fixed_segment_relative_order_1613  1
    order_2_13  fixed_segment_relative_order_1614  -1
    visit_2_14  out_degree_1557  -1
    visit_2_14  in_degree_1558  -1
    visit_2_14  order_active_lb_1559  -1
    visit_2_14  order_active_ub_1560  -12
    order_2_14  connected_order_arc_1264  1
    order_2_14  connected_order_arc_1287  1
    order_2_14  connected_order_arc_1310  1
    order_2_14  connected_order_arc_1329  -1
    order_2_14  connected_order_arc_1331  -1
    order_2_14  connected_order_arc_1333  -1
    order_2_14  connected_order_arc_1335  -1
    order_2_14  connected_order_arc_1337  -1
    order_2_14  connected_order_arc_1339  -1
    order_2_14  connected_order_arc_1341  -1
    order_2_14  connected_order_arc_1343  -1
    order_2_14  connected_order_arc_1345  -1
    order_2_14  connected_order_arc_1347  -1
    order_2_14  connected_order_arc_1349  -1
    order_2_14  connected_order_arc_1358  1
    order_2_14  connected_order_arc_1381  1
    order_2_14  connected_order_arc_1404  1
    order_2_14  connected_order_arc_1427  1
    order_2_14  connected_order_arc_1450  1
    order_2_14  connected_order_arc_1473  1
    order_2_14  connected_order_arc_1496  1
    order_2_14  connected_order_arc_1519  1
    order_2_14  order_active_lb_1559  1
    order_2_14  order_active_ub_1560  1
    order_2_14  fixed_segment_relative_order_1614  1
    visit_2_15  out_degree_1564  -1
    visit_2_15  in_degree_1565  -1
    visit_2_15  order_active_lb_1566  -1
    visit_2_15  order_active_ub_1567  -12
    visit_2_15  service_visit_def_1568  -1
    order_2_15  connected_order_arc_1266  1
    order_2_15  connected_order_arc_1289  1
    order_2_15  connected_order_arc_1312  1
    order_2_15  connected_order_arc_1335  1
    order_2_15  connected_order_arc_1352  -1
    order_2_15  connected_order_arc_1354  -1
    order_2_15  connected_order_arc_1356  -1
    order_2_15  connected_order_arc_1358  -1
    order_2_15  connected_order_arc_1360  -1
    order_2_15  connected_order_arc_1362  -1
    order_2_15  connected_order_arc_1364  -1
    order_2_15  connected_order_arc_1366  -1
    order_2_15  connected_order_arc_1368  -1
    order_2_15  connected_order_arc_1370  -1
    order_2_15  connected_order_arc_1372  -1
    order_2_15  connected_order_arc_1383  1
    order_2_15  connected_order_arc_1406  1
    order_2_15  connected_order_arc_1429  1
    order_2_15  connected_order_arc_1452  1
    order_2_15  connected_order_arc_1475  1
    order_2_15  connected_order_arc_1498  1
    order_2_15  connected_order_arc_1521  1
    order_2_15  order_active_lb_1566  1
    order_2_15  order_active_ub_1567  1
    visit_2_16  out_degree_1570  -1
    visit_2_16  in_degree_1571  -1
    visit_2_16  order_active_lb_1572  -1
    visit_2_16  order_active_ub_1573  -12
    visit_2_16  service_visit_def_1574  -1
    order_2_16  connected_order_arc_1268  1
    order_2_16  connected_order_arc_1291  1
    order_2_16  connected_order_arc_1314  1
    order_2_16  connected_order_arc_1337  1
    order_2_16  connected_order_arc_1360  1
    order_2_16  connected_order_arc_1375  -1
    order_2_16  connected_order_arc_1377  -1
    order_2_16  connected_order_arc_1379  -1
    order_2_16  connected_order_arc_1381  -1
    order_2_16  connected_order_arc_1383  -1
    order_2_16  connected_order_arc_1385  -1
    order_2_16  connected_order_arc_1387  -1
    order_2_16  connected_order_arc_1389  -1
    order_2_16  connected_order_arc_1391  -1
    order_2_16  connected_order_arc_1393  -1
    order_2_16  connected_order_arc_1395  -1
    order_2_16  connected_order_arc_1408  1
    order_2_16  connected_order_arc_1431  1
    order_2_16  connected_order_arc_1454  1
    order_2_16  connected_order_arc_1477  1
    order_2_16  connected_order_arc_1500  1
    order_2_16  connected_order_arc_1523  1
    order_2_16  order_active_lb_1572  1
    order_2_16  order_active_ub_1573  1
    visit_2_17  out_degree_1576  -1
    visit_2_17  in_degree_1577  -1
    visit_2_17  order_active_lb_1578  -1
    visit_2_17  order_active_ub_1579  -12
    visit_2_17  service_visit_def_1580  -1
    order_2_17  connected_order_arc_1270  1
    order_2_17  connected_order_arc_1293  1
    order_2_17  connected_order_arc_1316  1
    order_2_17  connected_order_arc_1339  1
    order_2_17  connected_order_arc_1362  1
    order_2_17  connected_order_arc_1385  1
    order_2_17  connected_order_arc_1398  -1
    order_2_17  connected_order_arc_1400  -1
    order_2_17  connected_order_arc_1402  -1
    order_2_17  connected_order_arc_1404  -1
    order_2_17  connected_order_arc_1406  -1
    order_2_17  connected_order_arc_1408  -1
    order_2_17  connected_order_arc_1410  -1
    order_2_17  connected_order_arc_1412  -1
    order_2_17  connected_order_arc_1414  -1
    order_2_17  connected_order_arc_1416  -1
    order_2_17  connected_order_arc_1418  -1
    order_2_17  connected_order_arc_1433  1
    order_2_17  connected_order_arc_1456  1
    order_2_17  connected_order_arc_1479  1
    order_2_17  connected_order_arc_1502  1
    order_2_17  connected_order_arc_1525  1
    order_2_17  order_active_lb_1578  1
    order_2_17  order_active_ub_1579  1
    visit_2_18  out_degree_1582  -1
    visit_2_18  in_degree_1583  -1
    visit_2_18  order_active_lb_1584  -1
    visit_2_18  order_active_ub_1585  -12
    visit_2_18  service_visit_def_1586  -1
    order_2_18  connected_order_arc_1272  1
    order_2_18  connected_order_arc_1295  1
    order_2_18  connected_order_arc_1318  1
    order_2_18  connected_order_arc_1341  1
    order_2_18  connected_order_arc_1364  1
    order_2_18  connected_order_arc_1387  1
    order_2_18  connected_order_arc_1410  1
    order_2_18  connected_order_arc_1421  -1
    order_2_18  connected_order_arc_1423  -1
    order_2_18  connected_order_arc_1425  -1
    order_2_18  connected_order_arc_1427  -1
    order_2_18  connected_order_arc_1429  -1
    order_2_18  connected_order_arc_1431  -1
    order_2_18  connected_order_arc_1433  -1
    order_2_18  connected_order_arc_1435  -1
    order_2_18  connected_order_arc_1437  -1
    order_2_18  connected_order_arc_1439  -1
    order_2_18  connected_order_arc_1441  -1
    order_2_18  connected_order_arc_1458  1
    order_2_18  connected_order_arc_1481  1
    order_2_18  connected_order_arc_1504  1
    order_2_18  connected_order_arc_1527  1
    order_2_18  order_active_lb_1584  1
    order_2_18  order_active_ub_1585  1
    visit_2_19  out_degree_1588  -1
    visit_2_19  in_degree_1589  -1
    visit_2_19  order_active_lb_1590  -1
    visit_2_19  order_active_ub_1591  -12
    visit_2_19  service_visit_def_1592  -1
    order_2_19  connected_order_arc_1274  1
    order_2_19  connected_order_arc_1297  1
    order_2_19  connected_order_arc_1320  1
    order_2_19  connected_order_arc_1343  1
    order_2_19  connected_order_arc_1366  1
    order_2_19  connected_order_arc_1389  1
    order_2_19  connected_order_arc_1412  1
    order_2_19  connected_order_arc_1435  1
    order_2_19  connected_order_arc_1444  -1
    order_2_19  connected_order_arc_1446  -1
    order_2_19  connected_order_arc_1448  -1
    order_2_19  connected_order_arc_1450  -1
    order_2_19  connected_order_arc_1452  -1
    order_2_19  connected_order_arc_1454  -1
    order_2_19  connected_order_arc_1456  -1
    order_2_19  connected_order_arc_1458  -1
    order_2_19  connected_order_arc_1460  -1
    order_2_19  connected_order_arc_1462  -1
    order_2_19  connected_order_arc_1464  -1
    order_2_19  connected_order_arc_1483  1
    order_2_19  connected_order_arc_1506  1
    order_2_19  connected_order_arc_1529  1
    order_2_19  order_active_lb_1590  1
    order_2_19  order_active_ub_1591  1
    visit_2_20  out_degree_1594  -1
    visit_2_20  in_degree_1595  -1
    visit_2_20  order_active_lb_1596  -1
    visit_2_20  order_active_ub_1597  -12
    visit_2_20  service_visit_def_1598  -1
    order_2_20  connected_order_arc_1276  1
    order_2_20  connected_order_arc_1299  1
    order_2_20  connected_order_arc_1322  1
    order_2_20  connected_order_arc_1345  1
    order_2_20  connected_order_arc_1368  1
    order_2_20  connected_order_arc_1391  1
    order_2_20  connected_order_arc_1414  1
    order_2_20  connected_order_arc_1437  1
    order_2_20  connected_order_arc_1460  1
    order_2_20  connected_order_arc_1467  -1
    order_2_20  connected_order_arc_1469  -1
    order_2_20  connected_order_arc_1471  -1
    order_2_20  connected_order_arc_1473  -1
    order_2_20  connected_order_arc_1475  -1
    order_2_20  connected_order_arc_1477  -1
    order_2_20  connected_order_arc_1479  -1
    order_2_20  connected_order_arc_1481  -1
    order_2_20  connected_order_arc_1483  -1
    order_2_20  connected_order_arc_1485  -1
    order_2_20  connected_order_arc_1487  -1
    order_2_20  connected_order_arc_1508  1
    order_2_20  connected_order_arc_1531  1
    order_2_20  order_active_lb_1596  1
    order_2_20  order_active_ub_1597  1
    visit_2_21  out_degree_1600  -1
    visit_2_21  in_degree_1601  -1
    visit_2_21  order_active_lb_1602  -1
    visit_2_21  order_active_ub_1603  -12
    visit_2_21  service_visit_def_1604  -1
    order_2_21  connected_order_arc_1278  1
    order_2_21  connected_order_arc_1301  1
    order_2_21  connected_order_arc_1324  1
    order_2_21  connected_order_arc_1347  1
    order_2_21  connected_order_arc_1370  1
    order_2_21  connected_order_arc_1393  1
    order_2_21  connected_order_arc_1416  1
    order_2_21  connected_order_arc_1439  1
    order_2_21  connected_order_arc_1462  1
    order_2_21  connected_order_arc_1485  1
    order_2_21  connected_order_arc_1490  -1
    order_2_21  connected_order_arc_1492  -1
    order_2_21  connected_order_arc_1494  -1
    order_2_21  connected_order_arc_1496  -1
    order_2_21  connected_order_arc_1498  -1
    order_2_21  connected_order_arc_1500  -1
    order_2_21  connected_order_arc_1502  -1
    order_2_21  connected_order_arc_1504  -1
    order_2_21  connected_order_arc_1506  -1
    order_2_21  connected_order_arc_1508  -1
    order_2_21  connected_order_arc_1510  -1
    order_2_21  connected_order_arc_1533  1
    order_2_21  order_active_lb_1602  1
    order_2_21  order_active_ub_1603  1
    visit_2_22  out_degree_1606  -1
    visit_2_22  in_degree_1607  -1
    visit_2_22  order_active_lb_1608  -1
    visit_2_22  order_active_ub_1609  -12
    visit_2_22  service_visit_def_1610  -1
    order_2_22  connected_order_arc_1280  1
    order_2_22  connected_order_arc_1303  1
    order_2_22  connected_order_arc_1326  1
    order_2_22  connected_order_arc_1349  1
    order_2_22  connected_order_arc_1372  1
    order_2_22  connected_order_arc_1395  1
    order_2_22  connected_order_arc_1418  1
    order_2_22  connected_order_arc_1441  1
    order_2_22  connected_order_arc_1464  1
    order_2_22  connected_order_arc_1487  1
    order_2_22  connected_order_arc_1510  1
    order_2_22  connected_order_arc_1513  -1
    order_2_22  connected_order_arc_1515  -1
    order_2_22  connected_order_arc_1517  -1
    order_2_22  connected_order_arc_1519  -1
    order_2_22  connected_order_arc_1521  -1
    order_2_22  connected_order_arc_1523  -1
    order_2_22  connected_order_arc_1525  -1
    order_2_22  connected_order_arc_1527  -1
    order_2_22  connected_order_arc_1529  -1
    order_2_22  connected_order_arc_1531  -1
    order_2_22  connected_order_arc_1533  -1
    order_2_22  order_active_lb_1608  1
    order_2_22  order_active_ub_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1245  -30
    arc_2_0_0  depot_departure_or_bypass_1534  1
    arc_2_0_0  depot_return_or_bypass_1535  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1245  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1246  -30
    arc_2_0_11  depot_departure_or_bypass_1534  1
    arc_2_0_11  in_degree_1537  1
    arc_2_0_11  original_T_including_depot_unload_1615  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1246  1
    load_2_0_11  segment_load_conservation_1540  -1
    load_2_0_11  segment_prefix_lb_1541  1
    load_2_0_11  segment_prefix_ub_1542  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1247  -30
    arc_2_0_12  depot_departure_or_bypass_1534  1
    arc_2_0_12  in_degree_1544  1
    arc_2_0_12  original_T_including_depot_unload_1615  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1247  1
    load_2_0_12  segment_load_conservation_1547  -1
    load_2_0_12  segment_prefix_lb_1548  1
    load_2_0_12  segment_prefix_ub_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1248  -30
    arc_2_0_13  depot_departure_or_bypass_1534  1
    arc_2_0_13  in_degree_1551  1
    arc_2_0_13  original_T_including_depot_unload_1615  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1248  1
    load_2_0_13  segment_load_conservation_1554  -1
    load_2_0_13  segment_prefix_lb_1555  1
    load_2_0_13  segment_prefix_ub_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1249  -30
    arc_2_0_14  depot_departure_or_bypass_1534  1
    arc_2_0_14  in_degree_1558  1
    arc_2_0_14  original_T_including_depot_unload_1615  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1249  1
    load_2_0_14  segment_load_conservation_1561  -1
    load_2_0_14  segment_prefix_lb_1562  1
    load_2_0_14  segment_prefix_ub_1563  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1250  -30
    arc_2_0_15  depot_departure_or_bypass_1534  1
    arc_2_0_15  in_degree_1565  1
    arc_2_0_15  original_T_including_depot_unload_1615  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1250  1
    load_2_0_15  free_load_conservation_1569  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1251  -30
    arc_2_0_16  depot_departure_or_bypass_1534  1
    arc_2_0_16  in_degree_1571  1
    arc_2_0_16  original_T_including_depot_unload_1615  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1251  1
    load_2_0_16  free_load_conservation_1575  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1252  -30
    arc_2_0_17  depot_departure_or_bypass_1534  1
    arc_2_0_17  in_degree_1577  1
    arc_2_0_17  original_T_including_depot_unload_1615  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1252  1
    load_2_0_17  free_load_conservation_1581  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1253  -30
    arc_2_0_18  depot_departure_or_bypass_1534  1
    arc_2_0_18  in_degree_1583  1
    arc_2_0_18  original_T_including_depot_unload_1615  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1253  1
    load_2_0_18  free_load_conservation_1587  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1254  -30
    arc_2_0_19  depot_departure_or_bypass_1534  1
    arc_2_0_19  in_degree_1589  1
    arc_2_0_19  original_T_including_depot_unload_1615  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1254  1
    load_2_0_19  free_load_conservation_1593  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1255  -30
    arc_2_0_20  depot_departure_or_bypass_1534  1
    arc_2_0_20  in_degree_1595  1
    arc_2_0_20  original_T_including_depot_unload_1615  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1255  1
    load_2_0_20  free_load_conservation_1599  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1256  -30
    arc_2_0_21  depot_departure_or_bypass_1534  1
    arc_2_0_21  in_degree_1601  1
    arc_2_0_21  original_T_including_depot_unload_1615  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1256  1
    load_2_0_21  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_22  arc_capacity_1257  -30
    arc_2_0_22  depot_departure_or_bypass_1534  1
    arc_2_0_22  in_degree_1607  1
    arc_2_0_22  original_T_including_depot_unload_1615  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_22  arc_capacity_1257  1
    load_2_0_22  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1258  -30
    arc_2_11_0  depot_return_or_bypass_1535  1
    arc_2_11_0  out_degree_1536  1
    arc_2_11_0  original_T_including_depot_unload_1615  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1258  1
    load_2_11_0  segment_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1259  -30
    arc_2_11_12  connected_order_arc_1260  -13
    arc_2_11_12  out_degree_1536  1
    arc_2_11_12  in_degree_1544  1
    arc_2_11_12  original_T_including_depot_unload_1615  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1259  1
    load_2_11_12  segment_load_conservation_1540  1
    load_2_11_12  segment_load_conservation_1547  -1
    load_2_11_12  segment_prefix_lb_1548  1
    load_2_11_12  segment_prefix_ub_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1261  -30
    arc_2_11_13  connected_order_arc_1262  -13
    arc_2_11_13  out_degree_1536  1
    arc_2_11_13  in_degree_1551  1
    arc_2_11_13  original_T_including_depot_unload_1615  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1261  1
    load_2_11_13  segment_load_conservation_1540  1
    load_2_11_13  segment_load_conservation_1554  -1
    load_2_11_13  segment_prefix_lb_1555  1
    load_2_11_13  segment_prefix_ub_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1263  -30
    arc_2_11_14  connected_order_arc_1264  -13
    arc_2_11_14  out_degree_1536  1
    arc_2_11_14  in_degree_1558  1
    arc_2_11_14  original_T_including_depot_unload_1615  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1263  1
    load_2_11_14  segment_load_conservation_1540  1
    load_2_11_14  segment_load_conservation_1561  -1
    load_2_11_14  segment_prefix_lb_1562  1
    load_2_11_14  segment_prefix_ub_1563  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1265  -30
    arc_2_11_15  connected_order_arc_1266  -13
    arc_2_11_15  out_degree_1536  1
    arc_2_11_15  in_degree_1565  1
    arc_2_11_15  original_T_including_depot_unload_1615  1.1077505469776054e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1265  1
    load_2_11_15  segment_load_conservation_1540  1
    load_2_11_15  free_load_conservation_1569  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1267  -30
    arc_2_11_16  connected_order_arc_1268  -13
    arc_2_11_16  out_degree_1536  1
    arc_2_11_16  in_degree_1571  1
    arc_2_11_16  original_T_including_depot_unload_1615  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1267  1
    load_2_11_16  segment_load_conservation_1540  1
    load_2_11_16  free_load_conservation_1575  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1269  -30
    arc_2_11_17  connected_order_arc_1270  -13
    arc_2_11_17  out_degree_1536  1
    arc_2_11_17  in_degree_1577  1
    arc_2_11_17  original_T_including_depot_unload_1615  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1269  1
    load_2_11_17  segment_load_conservation_1540  1
    load_2_11_17  free_load_conservation_1581  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1271  -30
    arc_2_11_18  connected_order_arc_1272  -13
    arc_2_11_18  out_degree_1536  1
    arc_2_11_18  in_degree_1583  1
    arc_2_11_18  original_T_including_depot_unload_1615  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1271  1
    load_2_11_18  segment_load_conservation_1540  1
    load_2_11_18  free_load_conservation_1587  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1273  -30
    arc_2_11_19  connected_order_arc_1274  -13
    arc_2_11_19  out_degree_1536  1
    arc_2_11_19  in_degree_1589  1
    arc_2_11_19  original_T_including_depot_unload_1615  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1273  1
    load_2_11_19  segment_load_conservation_1540  1
    load_2_11_19  free_load_conservation_1593  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1275  -30
    arc_2_11_20  connected_order_arc_1276  -13
    arc_2_11_20  out_degree_1536  1
    arc_2_11_20  in_degree_1595  1
    arc_2_11_20  original_T_including_depot_unload_1615  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1275  1
    load_2_11_20  segment_load_conservation_1540  1
    load_2_11_20  free_load_conservation_1599  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1277  -30
    arc_2_11_21  connected_order_arc_1278  -13
    arc_2_11_21  out_degree_1536  1
    arc_2_11_21  in_degree_1601  1
    arc_2_11_21  original_T_including_depot_unload_1615  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1277  1
    load_2_11_21  segment_load_conservation_1540  1
    load_2_11_21  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_22  arc_capacity_1279  -30
    arc_2_11_22  connected_order_arc_1280  -13
    arc_2_11_22  out_degree_1536  1
    arc_2_11_22  in_degree_1607  1
    arc_2_11_22  original_T_including_depot_unload_1615  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_22  arc_capacity_1279  1
    load_2_11_22  segment_load_conservation_1540  1
    load_2_11_22  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1281  -30
    arc_2_12_0  depot_return_or_bypass_1535  1
    arc_2_12_0  out_degree_1543  1
    arc_2_12_0  original_T_including_depot_unload_1615  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1281  1
    load_2_12_0  segment_load_conservation_1547  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1282  -30
    arc_2_12_11  connected_order_arc_1283  -13
    arc_2_12_11  in_degree_1537  1
    arc_2_12_11  out_degree_1543  1
    arc_2_12_11  original_T_including_depot_unload_1615  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1282  1
    load_2_12_11  segment_load_conservation_1540  -1
    load_2_12_11  segment_prefix_lb_1541  1
    load_2_12_11  segment_prefix_ub_1542  1
    load_2_12_11  segment_load_conservation_1547  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1284  -30
    arc_2_12_13  connected_order_arc_1285  -13
    arc_2_12_13  out_degree_1543  1
    arc_2_12_13  in_degree_1551  1
    arc_2_12_13  original_T_including_depot_unload_1615  1.0363003610648061e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1284  1
    load_2_12_13  segment_load_conservation_1547  1
    load_2_12_13  segment_load_conservation_1554  -1
    load_2_12_13  segment_prefix_lb_1555  1
    load_2_12_13  segment_prefix_ub_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1286  -30
    arc_2_12_14  connected_order_arc_1287  -13
    arc_2_12_14  out_degree_1543  1
    arc_2_12_14  in_degree_1558  1
    arc_2_12_14  original_T_including_depot_unload_1615  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1286  1
    load_2_12_14  segment_load_conservation_1547  1
    load_2_12_14  segment_load_conservation_1561  -1
    load_2_12_14  segment_prefix_lb_1562  1
    load_2_12_14  segment_prefix_ub_1563  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1288  -30
    arc_2_12_15  connected_order_arc_1289  -13
    arc_2_12_15  out_degree_1543  1
    arc_2_12_15  in_degree_1565  1
    arc_2_12_15  original_T_including_depot_unload_1615  1.2528205851183418e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1288  1
    load_2_12_15  segment_load_conservation_1547  1
    load_2_12_15  free_load_conservation_1569  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1290  -30
    arc_2_12_16  connected_order_arc_1291  -13
    arc_2_12_16  out_degree_1543  1
    arc_2_12_16  in_degree_1571  1
    arc_2_12_16  original_T_including_depot_unload_1615  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1290  1
    load_2_12_16  segment_load_conservation_1547  1
    load_2_12_16  free_load_conservation_1575  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1292  -30
    arc_2_12_17  connected_order_arc_1293  -13
    arc_2_12_17  out_degree_1543  1
    arc_2_12_17  in_degree_1577  1
    arc_2_12_17  original_T_including_depot_unload_1615  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1292  1
    load_2_12_17  segment_load_conservation_1547  1
    load_2_12_17  free_load_conservation_1581  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1294  -30
    arc_2_12_18  connected_order_arc_1295  -13
    arc_2_12_18  out_degree_1543  1
    arc_2_12_18  in_degree_1583  1
    arc_2_12_18  original_T_including_depot_unload_1615  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1294  1
    load_2_12_18  segment_load_conservation_1547  1
    load_2_12_18  free_load_conservation_1587  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1296  -30
    arc_2_12_19  connected_order_arc_1297  -13
    arc_2_12_19  out_degree_1543  1
    arc_2_12_19  in_degree_1589  1
    arc_2_12_19  original_T_including_depot_unload_1615  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1296  1
    load_2_12_19  segment_load_conservation_1547  1
    load_2_12_19  free_load_conservation_1593  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1298  -30
    arc_2_12_20  connected_order_arc_1299  -13
    arc_2_12_20  out_degree_1543  1
    arc_2_12_20  in_degree_1595  1
    arc_2_12_20  original_T_including_depot_unload_1615  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1298  1
    load_2_12_20  segment_load_conservation_1547  1
    load_2_12_20  free_load_conservation_1599  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1300  -30
    arc_2_12_21  connected_order_arc_1301  -13
    arc_2_12_21  out_degree_1543  1
    arc_2_12_21  in_degree_1601  1
    arc_2_12_21  original_T_including_depot_unload_1615  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1300  1
    load_2_12_21  segment_load_conservation_1547  1
    load_2_12_21  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_22  arc_capacity_1302  -30
    arc_2_12_22  connected_order_arc_1303  -13
    arc_2_12_22  out_degree_1543  1
    arc_2_12_22  in_degree_1607  1
    arc_2_12_22  original_T_including_depot_unload_1615  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_22  arc_capacity_1302  1
    load_2_12_22  segment_load_conservation_1547  1
    load_2_12_22  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1304  -30
    arc_2_13_0  depot_return_or_bypass_1535  1
    arc_2_13_0  out_degree_1550  1
    arc_2_13_0  original_T_including_depot_unload_1615  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1304  1
    load_2_13_0  segment_load_conservation_1554  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1305  -30
    arc_2_13_11  connected_order_arc_1306  -13
    arc_2_13_11  in_degree_1537  1
    arc_2_13_11  out_degree_1550  1
    arc_2_13_11  original_T_including_depot_unload_1615  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1305  1
    load_2_13_11  segment_load_conservation_1540  -1
    load_2_13_11  segment_prefix_lb_1541  1
    load_2_13_11  segment_prefix_ub_1542  1
    load_2_13_11  segment_load_conservation_1554  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1307  -30
    arc_2_13_12  connected_order_arc_1308  -13
    arc_2_13_12  in_degree_1544  1
    arc_2_13_12  out_degree_1550  1
    arc_2_13_12  original_T_including_depot_unload_1615  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1307  1
    load_2_13_12  segment_load_conservation_1547  -1
    load_2_13_12  segment_prefix_lb_1548  1
    load_2_13_12  segment_prefix_ub_1549  1
    load_2_13_12  segment_load_conservation_1554  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1309  -30
    arc_2_13_14  connected_order_arc_1310  -13
    arc_2_13_14  out_degree_1550  1
    arc_2_13_14  in_degree_1558  1
    arc_2_13_14  original_T_including_depot_unload_1615  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1309  1
    load_2_13_14  segment_load_conservation_1554  1
    load_2_13_14  segment_load_conservation_1561  -1
    load_2_13_14  segment_prefix_lb_1562  1
    load_2_13_14  segment_prefix_ub_1563  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1311  -30
    arc_2_13_15  connected_order_arc_1312  -13
    arc_2_13_15  out_degree_1550  1
    arc_2_13_15  in_degree_1565  1
    arc_2_13_15  original_T_including_depot_unload_1615  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1311  1
    load_2_13_15  segment_load_conservation_1554  1
    load_2_13_15  free_load_conservation_1569  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1313  -30
    arc_2_13_16  connected_order_arc_1314  -13
    arc_2_13_16  out_degree_1550  1
    arc_2_13_16  in_degree_1571  1
    arc_2_13_16  original_T_including_depot_unload_1615  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1313  1
    load_2_13_16  segment_load_conservation_1554  1
    load_2_13_16  free_load_conservation_1575  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1315  -30
    arc_2_13_17  connected_order_arc_1316  -13
    arc_2_13_17  out_degree_1550  1
    arc_2_13_17  in_degree_1577  1
    arc_2_13_17  original_T_including_depot_unload_1615  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1315  1
    load_2_13_17  segment_load_conservation_1554  1
    load_2_13_17  free_load_conservation_1581  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1317  -30
    arc_2_13_18  connected_order_arc_1318  -13
    arc_2_13_18  out_degree_1550  1
    arc_2_13_18  in_degree_1583  1
    arc_2_13_18  original_T_including_depot_unload_1615  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1317  1
    load_2_13_18  segment_load_conservation_1554  1
    load_2_13_18  free_load_conservation_1587  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1319  -30
    arc_2_13_19  connected_order_arc_1320  -13
    arc_2_13_19  out_degree_1550  1
    arc_2_13_19  in_degree_1589  1
    arc_2_13_19  original_T_including_depot_unload_1615  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1319  1
    load_2_13_19  segment_load_conservation_1554  1
    load_2_13_19  free_load_conservation_1593  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1321  -30
    arc_2_13_20  connected_order_arc_1322  -13
    arc_2_13_20  out_degree_1550  1
    arc_2_13_20  in_degree_1595  1
    arc_2_13_20  original_T_including_depot_unload_1615  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1321  1
    load_2_13_20  segment_load_conservation_1554  1
    load_2_13_20  free_load_conservation_1599  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1323  -30
    arc_2_13_21  connected_order_arc_1324  -13
    arc_2_13_21  out_degree_1550  1
    arc_2_13_21  in_degree_1601  1
    arc_2_13_21  original_T_including_depot_unload_1615  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1323  1
    load_2_13_21  segment_load_conservation_1554  1
    load_2_13_21  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_22  arc_capacity_1325  -30
    arc_2_13_22  connected_order_arc_1326  -13
    arc_2_13_22  out_degree_1550  1
    arc_2_13_22  in_degree_1607  1
    arc_2_13_22  original_T_including_depot_unload_1615  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_22  arc_capacity_1325  1
    load_2_13_22  segment_load_conservation_1554  1
    load_2_13_22  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1327  -30
    arc_2_14_0  depot_return_or_bypass_1535  1
    arc_2_14_0  out_degree_1557  1
    arc_2_14_0  original_T_including_depot_unload_1615  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1327  1
    load_2_14_0  segment_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1328  -30
    arc_2_14_11  connected_order_arc_1329  -13
    arc_2_14_11  in_degree_1537  1
    arc_2_14_11  out_degree_1557  1
    arc_2_14_11  original_T_including_depot_unload_1615  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1328  1
    load_2_14_11  segment_load_conservation_1540  -1
    load_2_14_11  segment_prefix_lb_1541  1
    load_2_14_11  segment_prefix_ub_1542  1
    load_2_14_11  segment_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1330  -30
    arc_2_14_12  connected_order_arc_1331  -13
    arc_2_14_12  in_degree_1544  1
    arc_2_14_12  out_degree_1557  1
    arc_2_14_12  original_T_including_depot_unload_1615  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1330  1
    load_2_14_12  segment_load_conservation_1547  -1
    load_2_14_12  segment_prefix_lb_1548  1
    load_2_14_12  segment_prefix_ub_1549  1
    load_2_14_12  segment_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1332  -30
    arc_2_14_13  connected_order_arc_1333  -13
    arc_2_14_13  in_degree_1551  1
    arc_2_14_13  out_degree_1557  1
    arc_2_14_13  original_T_including_depot_unload_1615  1.4593103211867947e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1332  1
    load_2_14_13  segment_load_conservation_1554  -1
    load_2_14_13  segment_prefix_lb_1555  1
    load_2_14_13  segment_prefix_ub_1556  1
    load_2_14_13  segment_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1334  -30
    arc_2_14_15  connected_order_arc_1335  -13
    arc_2_14_15  out_degree_1557  1
    arc_2_14_15  in_degree_1565  1
    arc_2_14_15  original_T_including_depot_unload_1615  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1334  1
    load_2_14_15  segment_load_conservation_1561  1
    load_2_14_15  free_load_conservation_1569  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1336  -30
    arc_2_14_16  connected_order_arc_1337  -13
    arc_2_14_16  out_degree_1557  1
    arc_2_14_16  in_degree_1571  1
    arc_2_14_16  original_T_including_depot_unload_1615  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1336  1
    load_2_14_16  segment_load_conservation_1561  1
    load_2_14_16  free_load_conservation_1575  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1338  -30
    arc_2_14_17  connected_order_arc_1339  -13
    arc_2_14_17  out_degree_1557  1
    arc_2_14_17  in_degree_1577  1
    arc_2_14_17  original_T_including_depot_unload_1615  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1338  1
    load_2_14_17  segment_load_conservation_1561  1
    load_2_14_17  free_load_conservation_1581  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1340  -30
    arc_2_14_18  connected_order_arc_1341  -13
    arc_2_14_18  out_degree_1557  1
    arc_2_14_18  in_degree_1583  1
    arc_2_14_18  original_T_including_depot_unload_1615  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1340  1
    load_2_14_18  segment_load_conservation_1561  1
    load_2_14_18  free_load_conservation_1587  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1342  -30
    arc_2_14_19  connected_order_arc_1343  -13
    arc_2_14_19  out_degree_1557  1
    arc_2_14_19  in_degree_1589  1
    arc_2_14_19  original_T_including_depot_unload_1615  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1342  1
    load_2_14_19  segment_load_conservation_1561  1
    load_2_14_19  free_load_conservation_1593  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1344  -30
    arc_2_14_20  connected_order_arc_1345  -13
    arc_2_14_20  out_degree_1557  1
    arc_2_14_20  in_degree_1595  1
    arc_2_14_20  original_T_including_depot_unload_1615  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1344  1
    load_2_14_20  segment_load_conservation_1561  1
    load_2_14_20  free_load_conservation_1599  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1346  -30
    arc_2_14_21  connected_order_arc_1347  -13
    arc_2_14_21  out_degree_1557  1
    arc_2_14_21  in_degree_1601  1
    arc_2_14_21  original_T_including_depot_unload_1615  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1346  1
    load_2_14_21  segment_load_conservation_1561  1
    load_2_14_21  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_22  arc_capacity_1348  -30
    arc_2_14_22  connected_order_arc_1349  -13
    arc_2_14_22  out_degree_1557  1
    arc_2_14_22  in_degree_1607  1
    arc_2_14_22  original_T_including_depot_unload_1615  7.9613989083692911e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_22  arc_capacity_1348  1
    load_2_14_22  segment_load_conservation_1561  1
    load_2_14_22  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1350  -30
    arc_2_15_0  depot_return_or_bypass_1535  1
    arc_2_15_0  out_degree_1564  1
    arc_2_15_0  original_T_including_depot_unload_1615  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1350  1
    load_2_15_0  free_load_conservation_1569  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1351  -30
    arc_2_15_11  connected_order_arc_1352  -13
    arc_2_15_11  in_degree_1537  1
    arc_2_15_11  out_degree_1564  1
    arc_2_15_11  original_T_including_depot_unload_1615  1.1077505469776054e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1351  1
    load_2_15_11  segment_load_conservation_1540  -1
    load_2_15_11  segment_prefix_lb_1541  1
    load_2_15_11  segment_prefix_ub_1542  1
    load_2_15_11  free_load_conservation_1569  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1353  -30
    arc_2_15_12  connected_order_arc_1354  -13
    arc_2_15_12  in_degree_1544  1
    arc_2_15_12  out_degree_1564  1
    arc_2_15_12  original_T_including_depot_unload_1615  1.2528205851183418e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1353  1
    load_2_15_12  segment_load_conservation_1547  -1
    load_2_15_12  segment_prefix_lb_1548  1
    load_2_15_12  segment_prefix_ub_1549  1
    load_2_15_12  free_load_conservation_1569  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1355  -30
    arc_2_15_13  connected_order_arc_1356  -13
    arc_2_15_13  in_degree_1551  1
    arc_2_15_13  out_degree_1564  1
    arc_2_15_13  original_T_including_depot_unload_1615  2184.10509638866
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1355  1
    load_2_15_13  segment_load_conservation_1554  -1
    load_2_15_13  segment_prefix_lb_1555  1
    load_2_15_13  segment_prefix_ub_1556  1
    load_2_15_13  free_load_conservation_1569  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1357  -30
    arc_2_15_14  connected_order_arc_1358  -13
    arc_2_15_14  in_degree_1558  1
    arc_2_15_14  out_degree_1564  1
    arc_2_15_14  original_T_including_depot_unload_1615  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1357  1
    load_2_15_14  segment_load_conservation_1561  -1
    load_2_15_14  segment_prefix_lb_1562  1
    load_2_15_14  segment_prefix_ub_1563  1
    load_2_15_14  free_load_conservation_1569  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1359  -30
    arc_2_15_16  connected_order_arc_1360  -13
    arc_2_15_16  out_degree_1564  1
    arc_2_15_16  in_degree_1571  1
    arc_2_15_16  original_T_including_depot_unload_1615  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1359  1
    load_2_15_16  free_load_conservation_1569  1
    load_2_15_16  free_load_conservation_1575  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1361  -30
    arc_2_15_17  connected_order_arc_1362  -13
    arc_2_15_17  out_degree_1564  1
    arc_2_15_17  in_degree_1577  1
    arc_2_15_17  original_T_including_depot_unload_1615  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1361  1
    load_2_15_17  free_load_conservation_1569  1
    load_2_15_17  free_load_conservation_1581  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1363  -30
    arc_2_15_18  connected_order_arc_1364  -13
    arc_2_15_18  out_degree_1564  1
    arc_2_15_18  in_degree_1583  1
    arc_2_15_18  original_T_including_depot_unload_1615  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1363  1
    load_2_15_18  free_load_conservation_1569  1
    load_2_15_18  free_load_conservation_1587  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1365  -30
    arc_2_15_19  connected_order_arc_1366  -13
    arc_2_15_19  out_degree_1564  1
    arc_2_15_19  in_degree_1589  1
    arc_2_15_19  original_T_including_depot_unload_1615  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1365  1
    load_2_15_19  free_load_conservation_1569  1
    load_2_15_19  free_load_conservation_1593  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1367  -30
    arc_2_15_20  connected_order_arc_1368  -13
    arc_2_15_20  out_degree_1564  1
    arc_2_15_20  in_degree_1595  1
    arc_2_15_20  original_T_including_depot_unload_1615  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1367  1
    load_2_15_20  free_load_conservation_1569  1
    load_2_15_20  free_load_conservation_1599  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1369  -30
    arc_2_15_21  connected_order_arc_1370  -13
    arc_2_15_21  out_degree_1564  1
    arc_2_15_21  in_degree_1601  1
    arc_2_15_21  original_T_including_depot_unload_1615  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1369  1
    load_2_15_21  free_load_conservation_1569  1
    load_2_15_21  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_22  arc_capacity_1371  -30
    arc_2_15_22  connected_order_arc_1372  -13
    arc_2_15_22  out_degree_1564  1
    arc_2_15_22  in_degree_1607  1
    arc_2_15_22  original_T_including_depot_unload_1615  7.9829177317292124e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_22  arc_capacity_1371  1
    load_2_15_22  free_load_conservation_1569  1
    load_2_15_22  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1373  -30
    arc_2_16_0  depot_return_or_bypass_1535  1
    arc_2_16_0  out_degree_1570  1
    arc_2_16_0  original_T_including_depot_unload_1615  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1373  1
    load_2_16_0  free_load_conservation_1575  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1374  -30
    arc_2_16_11  connected_order_arc_1375  -13
    arc_2_16_11  in_degree_1537  1
    arc_2_16_11  out_degree_1570  1
    arc_2_16_11  original_T_including_depot_unload_1615  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1374  1
    load_2_16_11  segment_load_conservation_1540  -1
    load_2_16_11  segment_prefix_lb_1541  1
    load_2_16_11  segment_prefix_ub_1542  1
    load_2_16_11  free_load_conservation_1575  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1376  -30
    arc_2_16_12  connected_order_arc_1377  -13
    arc_2_16_12  in_degree_1544  1
    arc_2_16_12  out_degree_1570  1
    arc_2_16_12  original_T_including_depot_unload_1615  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1376  1
    load_2_16_12  segment_load_conservation_1547  -1
    load_2_16_12  segment_prefix_lb_1548  1
    load_2_16_12  segment_prefix_ub_1549  1
    load_2_16_12  free_load_conservation_1575  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1378  -30
    arc_2_16_13  connected_order_arc_1379  -13
    arc_2_16_13  in_degree_1551  1
    arc_2_16_13  out_degree_1570  1
    arc_2_16_13  original_T_including_depot_unload_1615  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1378  1
    load_2_16_13  segment_load_conservation_1554  -1
    load_2_16_13  segment_prefix_lb_1555  1
    load_2_16_13  segment_prefix_ub_1556  1
    load_2_16_13  free_load_conservation_1575  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1380  -30
    arc_2_16_14  connected_order_arc_1381  -13
    arc_2_16_14  in_degree_1558  1
    arc_2_16_14  out_degree_1570  1
    arc_2_16_14  original_T_including_depot_unload_1615  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1380  1
    load_2_16_14  segment_load_conservation_1561  -1
    load_2_16_14  segment_prefix_lb_1562  1
    load_2_16_14  segment_prefix_ub_1563  1
    load_2_16_14  free_load_conservation_1575  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1382  -30
    arc_2_16_15  connected_order_arc_1383  -13
    arc_2_16_15  in_degree_1565  1
    arc_2_16_15  out_degree_1570  1
    arc_2_16_15  original_T_including_depot_unload_1615  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1382  1
    load_2_16_15  free_load_conservation_1569  -1
    load_2_16_15  free_load_conservation_1575  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1384  -30
    arc_2_16_17  connected_order_arc_1385  -13
    arc_2_16_17  out_degree_1570  1
    arc_2_16_17  in_degree_1577  1
    arc_2_16_17  original_T_including_depot_unload_1615  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1384  1
    load_2_16_17  free_load_conservation_1575  1
    load_2_16_17  free_load_conservation_1581  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1386  -30
    arc_2_16_18  connected_order_arc_1387  -13
    arc_2_16_18  out_degree_1570  1
    arc_2_16_18  in_degree_1583  1
    arc_2_16_18  original_T_including_depot_unload_1615  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1386  1
    load_2_16_18  free_load_conservation_1575  1
    load_2_16_18  free_load_conservation_1587  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1388  -30
    arc_2_16_19  connected_order_arc_1389  -13
    arc_2_16_19  out_degree_1570  1
    arc_2_16_19  in_degree_1589  1
    arc_2_16_19  original_T_including_depot_unload_1615  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1388  1
    load_2_16_19  free_load_conservation_1575  1
    load_2_16_19  free_load_conservation_1593  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1390  -30
    arc_2_16_20  connected_order_arc_1391  -13
    arc_2_16_20  out_degree_1570  1
    arc_2_16_20  in_degree_1595  1
    arc_2_16_20  original_T_including_depot_unload_1615  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1390  1
    load_2_16_20  free_load_conservation_1575  1
    load_2_16_20  free_load_conservation_1599  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1392  -30
    arc_2_16_21  connected_order_arc_1393  -13
    arc_2_16_21  out_degree_1570  1
    arc_2_16_21  in_degree_1601  1
    arc_2_16_21  original_T_including_depot_unload_1615  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1392  1
    load_2_16_21  free_load_conservation_1575  1
    load_2_16_21  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_22  arc_capacity_1394  -30
    arc_2_16_22  connected_order_arc_1395  -13
    arc_2_16_22  out_degree_1570  1
    arc_2_16_22  in_degree_1607  1
    arc_2_16_22  original_T_including_depot_unload_1615  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_22  arc_capacity_1394  1
    load_2_16_22  free_load_conservation_1575  1
    load_2_16_22  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1396  -30
    arc_2_17_0  depot_return_or_bypass_1535  1
    arc_2_17_0  out_degree_1576  1
    arc_2_17_0  original_T_including_depot_unload_1615  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1396  1
    load_2_17_0  free_load_conservation_1581  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1397  -30
    arc_2_17_11  connected_order_arc_1398  -13
    arc_2_17_11  in_degree_1537  1
    arc_2_17_11  out_degree_1576  1
    arc_2_17_11  original_T_including_depot_unload_1615  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1397  1
    load_2_17_11  segment_load_conservation_1540  -1
    load_2_17_11  segment_prefix_lb_1541  1
    load_2_17_11  segment_prefix_ub_1542  1
    load_2_17_11  free_load_conservation_1581  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1399  -30
    arc_2_17_12  connected_order_arc_1400  -13
    arc_2_17_12  in_degree_1544  1
    arc_2_17_12  out_degree_1576  1
    arc_2_17_12  original_T_including_depot_unload_1615  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1399  1
    load_2_17_12  segment_load_conservation_1547  -1
    load_2_17_12  segment_prefix_lb_1548  1
    load_2_17_12  segment_prefix_ub_1549  1
    load_2_17_12  free_load_conservation_1581  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1401  -30
    arc_2_17_13  connected_order_arc_1402  -13
    arc_2_17_13  in_degree_1551  1
    arc_2_17_13  out_degree_1576  1
    arc_2_17_13  original_T_including_depot_unload_1615  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1401  1
    load_2_17_13  segment_load_conservation_1554  -1
    load_2_17_13  segment_prefix_lb_1555  1
    load_2_17_13  segment_prefix_ub_1556  1
    load_2_17_13  free_load_conservation_1581  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1403  -30
    arc_2_17_14  connected_order_arc_1404  -13
    arc_2_17_14  in_degree_1558  1
    arc_2_17_14  out_degree_1576  1
    arc_2_17_14  original_T_including_depot_unload_1615  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1403  1
    load_2_17_14  segment_load_conservation_1561  -1
    load_2_17_14  segment_prefix_lb_1562  1
    load_2_17_14  segment_prefix_ub_1563  1
    load_2_17_14  free_load_conservation_1581  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1405  -30
    arc_2_17_15  connected_order_arc_1406  -13
    arc_2_17_15  in_degree_1565  1
    arc_2_17_15  out_degree_1576  1
    arc_2_17_15  original_T_including_depot_unload_1615  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1405  1
    load_2_17_15  free_load_conservation_1569  -1
    load_2_17_15  free_load_conservation_1581  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1407  -30
    arc_2_17_16  connected_order_arc_1408  -13
    arc_2_17_16  in_degree_1571  1
    arc_2_17_16  out_degree_1576  1
    arc_2_17_16  original_T_including_depot_unload_1615  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1407  1
    load_2_17_16  free_load_conservation_1575  -1
    load_2_17_16  free_load_conservation_1581  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1409  -30
    arc_2_17_18  connected_order_arc_1410  -13
    arc_2_17_18  out_degree_1576  1
    arc_2_17_18  in_degree_1583  1
    arc_2_17_18  original_T_including_depot_unload_1615  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1409  1
    load_2_17_18  free_load_conservation_1581  1
    load_2_17_18  free_load_conservation_1587  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1411  -30
    arc_2_17_19  connected_order_arc_1412  -13
    arc_2_17_19  out_degree_1576  1
    arc_2_17_19  in_degree_1589  1
    arc_2_17_19  original_T_including_depot_unload_1615  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1411  1
    load_2_17_19  free_load_conservation_1581  1
    load_2_17_19  free_load_conservation_1593  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1413  -30
    arc_2_17_20  connected_order_arc_1414  -13
    arc_2_17_20  out_degree_1576  1
    arc_2_17_20  in_degree_1595  1
    arc_2_17_20  original_T_including_depot_unload_1615  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1413  1
    load_2_17_20  free_load_conservation_1581  1
    load_2_17_20  free_load_conservation_1599  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1415  -30
    arc_2_17_21  connected_order_arc_1416  -13
    arc_2_17_21  out_degree_1576  1
    arc_2_17_21  in_degree_1601  1
    arc_2_17_21  original_T_including_depot_unload_1615  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1415  1
    load_2_17_21  free_load_conservation_1581  1
    load_2_17_21  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_22  arc_capacity_1417  -30
    arc_2_17_22  connected_order_arc_1418  -13
    arc_2_17_22  out_degree_1576  1
    arc_2_17_22  in_degree_1607  1
    arc_2_17_22  original_T_including_depot_unload_1615  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_22  arc_capacity_1417  1
    load_2_17_22  free_load_conservation_1581  1
    load_2_17_22  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1419  -30
    arc_2_18_0  depot_return_or_bypass_1535  1
    arc_2_18_0  out_degree_1582  1
    arc_2_18_0  original_T_including_depot_unload_1615  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1419  1
    load_2_18_0  free_load_conservation_1587  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1420  -30
    arc_2_18_11  connected_order_arc_1421  -13
    arc_2_18_11  in_degree_1537  1
    arc_2_18_11  out_degree_1582  1
    arc_2_18_11  original_T_including_depot_unload_1615  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1420  1
    load_2_18_11  segment_load_conservation_1540  -1
    load_2_18_11  segment_prefix_lb_1541  1
    load_2_18_11  segment_prefix_ub_1542  1
    load_2_18_11  free_load_conservation_1587  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1422  -30
    arc_2_18_12  connected_order_arc_1423  -13
    arc_2_18_12  in_degree_1544  1
    arc_2_18_12  out_degree_1582  1
    arc_2_18_12  original_T_including_depot_unload_1615  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1422  1
    load_2_18_12  segment_load_conservation_1547  -1
    load_2_18_12  segment_prefix_lb_1548  1
    load_2_18_12  segment_prefix_ub_1549  1
    load_2_18_12  free_load_conservation_1587  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1424  -30
    arc_2_18_13  connected_order_arc_1425  -13
    arc_2_18_13  in_degree_1551  1
    arc_2_18_13  out_degree_1582  1
    arc_2_18_13  original_T_including_depot_unload_1615  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1424  1
    load_2_18_13  segment_load_conservation_1554  -1
    load_2_18_13  segment_prefix_lb_1555  1
    load_2_18_13  segment_prefix_ub_1556  1
    load_2_18_13  free_load_conservation_1587  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1426  -30
    arc_2_18_14  connected_order_arc_1427  -13
    arc_2_18_14  in_degree_1558  1
    arc_2_18_14  out_degree_1582  1
    arc_2_18_14  original_T_including_depot_unload_1615  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1426  1
    load_2_18_14  segment_load_conservation_1561  -1
    load_2_18_14  segment_prefix_lb_1562  1
    load_2_18_14  segment_prefix_ub_1563  1
    load_2_18_14  free_load_conservation_1587  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1428  -30
    arc_2_18_15  connected_order_arc_1429  -13
    arc_2_18_15  in_degree_1565  1
    arc_2_18_15  out_degree_1582  1
    arc_2_18_15  original_T_including_depot_unload_1615  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1428  1
    load_2_18_15  free_load_conservation_1569  -1
    load_2_18_15  free_load_conservation_1587  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1430  -30
    arc_2_18_16  connected_order_arc_1431  -13
    arc_2_18_16  in_degree_1571  1
    arc_2_18_16  out_degree_1582  1
    arc_2_18_16  original_T_including_depot_unload_1615  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1430  1
    load_2_18_16  free_load_conservation_1575  -1
    load_2_18_16  free_load_conservation_1587  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1432  -30
    arc_2_18_17  connected_order_arc_1433  -13
    arc_2_18_17  in_degree_1577  1
    arc_2_18_17  out_degree_1582  1
    arc_2_18_17  original_T_including_depot_unload_1615  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1432  1
    load_2_18_17  free_load_conservation_1581  -1
    load_2_18_17  free_load_conservation_1587  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1434  -30
    arc_2_18_19  connected_order_arc_1435  -13
    arc_2_18_19  out_degree_1582  1
    arc_2_18_19  in_degree_1589  1
    arc_2_18_19  original_T_including_depot_unload_1615  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1434  1
    load_2_18_19  free_load_conservation_1587  1
    load_2_18_19  free_load_conservation_1593  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1436  -30
    arc_2_18_20  connected_order_arc_1437  -13
    arc_2_18_20  out_degree_1582  1
    arc_2_18_20  in_degree_1595  1
    arc_2_18_20  original_T_including_depot_unload_1615  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1436  1
    load_2_18_20  free_load_conservation_1587  1
    load_2_18_20  free_load_conservation_1599  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1438  -30
    arc_2_18_21  connected_order_arc_1439  -13
    arc_2_18_21  out_degree_1582  1
    arc_2_18_21  in_degree_1601  1
    arc_2_18_21  original_T_including_depot_unload_1615  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1438  1
    load_2_18_21  free_load_conservation_1587  1
    load_2_18_21  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_22  arc_capacity_1440  -30
    arc_2_18_22  connected_order_arc_1441  -13
    arc_2_18_22  out_degree_1582  1
    arc_2_18_22  in_degree_1607  1
    arc_2_18_22  original_T_including_depot_unload_1615  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_22  arc_capacity_1440  1
    load_2_18_22  free_load_conservation_1587  1
    load_2_18_22  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1442  -30
    arc_2_19_0  depot_return_or_bypass_1535  1
    arc_2_19_0  out_degree_1588  1
    arc_2_19_0  original_T_including_depot_unload_1615  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1442  1
    load_2_19_0  free_load_conservation_1593  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1443  -30
    arc_2_19_11  connected_order_arc_1444  -13
    arc_2_19_11  in_degree_1537  1
    arc_2_19_11  out_degree_1588  1
    arc_2_19_11  original_T_including_depot_unload_1615  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1443  1
    load_2_19_11  segment_load_conservation_1540  -1
    load_2_19_11  segment_prefix_lb_1541  1
    load_2_19_11  segment_prefix_ub_1542  1
    load_2_19_11  free_load_conservation_1593  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1445  -30
    arc_2_19_12  connected_order_arc_1446  -13
    arc_2_19_12  in_degree_1544  1
    arc_2_19_12  out_degree_1588  1
    arc_2_19_12  original_T_including_depot_unload_1615  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1445  1
    load_2_19_12  segment_load_conservation_1547  -1
    load_2_19_12  segment_prefix_lb_1548  1
    load_2_19_12  segment_prefix_ub_1549  1
    load_2_19_12  free_load_conservation_1593  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1447  -30
    arc_2_19_13  connected_order_arc_1448  -13
    arc_2_19_13  in_degree_1551  1
    arc_2_19_13  out_degree_1588  1
    arc_2_19_13  original_T_including_depot_unload_1615  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1447  1
    load_2_19_13  segment_load_conservation_1554  -1
    load_2_19_13  segment_prefix_lb_1555  1
    load_2_19_13  segment_prefix_ub_1556  1
    load_2_19_13  free_load_conservation_1593  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1449  -30
    arc_2_19_14  connected_order_arc_1450  -13
    arc_2_19_14  in_degree_1558  1
    arc_2_19_14  out_degree_1588  1
    arc_2_19_14  original_T_including_depot_unload_1615  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1449  1
    load_2_19_14  segment_load_conservation_1561  -1
    load_2_19_14  segment_prefix_lb_1562  1
    load_2_19_14  segment_prefix_ub_1563  1
    load_2_19_14  free_load_conservation_1593  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1451  -30
    arc_2_19_15  connected_order_arc_1452  -13
    arc_2_19_15  in_degree_1565  1
    arc_2_19_15  out_degree_1588  1
    arc_2_19_15  original_T_including_depot_unload_1615  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1451  1
    load_2_19_15  free_load_conservation_1569  -1
    load_2_19_15  free_load_conservation_1593  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1453  -30
    arc_2_19_16  connected_order_arc_1454  -13
    arc_2_19_16  in_degree_1571  1
    arc_2_19_16  out_degree_1588  1
    arc_2_19_16  original_T_including_depot_unload_1615  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1453  1
    load_2_19_16  free_load_conservation_1575  -1
    load_2_19_16  free_load_conservation_1593  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1455  -30
    arc_2_19_17  connected_order_arc_1456  -13
    arc_2_19_17  in_degree_1577  1
    arc_2_19_17  out_degree_1588  1
    arc_2_19_17  original_T_including_depot_unload_1615  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1455  1
    load_2_19_17  free_load_conservation_1581  -1
    load_2_19_17  free_load_conservation_1593  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1457  -30
    arc_2_19_18  connected_order_arc_1458  -13
    arc_2_19_18  in_degree_1583  1
    arc_2_19_18  out_degree_1588  1
    arc_2_19_18  original_T_including_depot_unload_1615  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1457  1
    load_2_19_18  free_load_conservation_1587  -1
    load_2_19_18  free_load_conservation_1593  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1459  -30
    arc_2_19_20  connected_order_arc_1460  -13
    arc_2_19_20  out_degree_1588  1
    arc_2_19_20  in_degree_1595  1
    arc_2_19_20  original_T_including_depot_unload_1615  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1459  1
    load_2_19_20  free_load_conservation_1593  1
    load_2_19_20  free_load_conservation_1599  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1461  -30
    arc_2_19_21  connected_order_arc_1462  -13
    arc_2_19_21  out_degree_1588  1
    arc_2_19_21  in_degree_1601  1
    arc_2_19_21  original_T_including_depot_unload_1615  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1461  1
    load_2_19_21  free_load_conservation_1593  1
    load_2_19_21  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_22  arc_capacity_1463  -30
    arc_2_19_22  connected_order_arc_1464  -13
    arc_2_19_22  out_degree_1588  1
    arc_2_19_22  in_degree_1607  1
    arc_2_19_22  original_T_including_depot_unload_1615  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_22  arc_capacity_1463  1
    load_2_19_22  free_load_conservation_1593  1
    load_2_19_22  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1465  -30
    arc_2_20_0  depot_return_or_bypass_1535  1
    arc_2_20_0  out_degree_1594  1
    arc_2_20_0  original_T_including_depot_unload_1615  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1465  1
    load_2_20_0  free_load_conservation_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1466  -30
    arc_2_20_11  connected_order_arc_1467  -13
    arc_2_20_11  in_degree_1537  1
    arc_2_20_11  out_degree_1594  1
    arc_2_20_11  original_T_including_depot_unload_1615  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1466  1
    load_2_20_11  segment_load_conservation_1540  -1
    load_2_20_11  segment_prefix_lb_1541  1
    load_2_20_11  segment_prefix_ub_1542  1
    load_2_20_11  free_load_conservation_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1468  -30
    arc_2_20_12  connected_order_arc_1469  -13
    arc_2_20_12  in_degree_1544  1
    arc_2_20_12  out_degree_1594  1
    arc_2_20_12  original_T_including_depot_unload_1615  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1468  1
    load_2_20_12  segment_load_conservation_1547  -1
    load_2_20_12  segment_prefix_lb_1548  1
    load_2_20_12  segment_prefix_ub_1549  1
    load_2_20_12  free_load_conservation_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1470  -30
    arc_2_20_13  connected_order_arc_1471  -13
    arc_2_20_13  in_degree_1551  1
    arc_2_20_13  out_degree_1594  1
    arc_2_20_13  original_T_including_depot_unload_1615  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1470  1
    load_2_20_13  segment_load_conservation_1554  -1
    load_2_20_13  segment_prefix_lb_1555  1
    load_2_20_13  segment_prefix_ub_1556  1
    load_2_20_13  free_load_conservation_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1472  -30
    arc_2_20_14  connected_order_arc_1473  -13
    arc_2_20_14  in_degree_1558  1
    arc_2_20_14  out_degree_1594  1
    arc_2_20_14  original_T_including_depot_unload_1615  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1472  1
    load_2_20_14  segment_load_conservation_1561  -1
    load_2_20_14  segment_prefix_lb_1562  1
    load_2_20_14  segment_prefix_ub_1563  1
    load_2_20_14  free_load_conservation_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1474  -30
    arc_2_20_15  connected_order_arc_1475  -13
    arc_2_20_15  in_degree_1565  1
    arc_2_20_15  out_degree_1594  1
    arc_2_20_15  original_T_including_depot_unload_1615  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1474  1
    load_2_20_15  free_load_conservation_1569  -1
    load_2_20_15  free_load_conservation_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1476  -30
    arc_2_20_16  connected_order_arc_1477  -13
    arc_2_20_16  in_degree_1571  1
    arc_2_20_16  out_degree_1594  1
    arc_2_20_16  original_T_including_depot_unload_1615  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1476  1
    load_2_20_16  free_load_conservation_1575  -1
    load_2_20_16  free_load_conservation_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1478  -30
    arc_2_20_17  connected_order_arc_1479  -13
    arc_2_20_17  in_degree_1577  1
    arc_2_20_17  out_degree_1594  1
    arc_2_20_17  original_T_including_depot_unload_1615  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1478  1
    load_2_20_17  free_load_conservation_1581  -1
    load_2_20_17  free_load_conservation_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1480  -30
    arc_2_20_18  connected_order_arc_1481  -13
    arc_2_20_18  in_degree_1583  1
    arc_2_20_18  out_degree_1594  1
    arc_2_20_18  original_T_including_depot_unload_1615  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1480  1
    load_2_20_18  free_load_conservation_1587  -1
    load_2_20_18  free_load_conservation_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1482  -30
    arc_2_20_19  connected_order_arc_1483  -13
    arc_2_20_19  in_degree_1589  1
    arc_2_20_19  out_degree_1594  1
    arc_2_20_19  original_T_including_depot_unload_1615  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1482  1
    load_2_20_19  free_load_conservation_1593  -1
    load_2_20_19  free_load_conservation_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1484  -30
    arc_2_20_21  connected_order_arc_1485  -13
    arc_2_20_21  out_degree_1594  1
    arc_2_20_21  in_degree_1601  1
    arc_2_20_21  original_T_including_depot_unload_1615  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1484  1
    load_2_20_21  free_load_conservation_1599  1
    load_2_20_21  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_22  arc_capacity_1486  -30
    arc_2_20_22  connected_order_arc_1487  -13
    arc_2_20_22  out_degree_1594  1
    arc_2_20_22  in_degree_1607  1
    arc_2_20_22  original_T_including_depot_unload_1615  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_22  arc_capacity_1486  1
    load_2_20_22  free_load_conservation_1599  1
    load_2_20_22  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1488  -30
    arc_2_21_0  depot_return_or_bypass_1535  1
    arc_2_21_0  out_degree_1600  1
    arc_2_21_0  original_T_including_depot_unload_1615  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1488  1
    load_2_21_0  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1489  -30
    arc_2_21_11  connected_order_arc_1490  -13
    arc_2_21_11  in_degree_1537  1
    arc_2_21_11  out_degree_1600  1
    arc_2_21_11  original_T_including_depot_unload_1615  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1489  1
    load_2_21_11  segment_load_conservation_1540  -1
    load_2_21_11  segment_prefix_lb_1541  1
    load_2_21_11  segment_prefix_ub_1542  1
    load_2_21_11  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1491  -30
    arc_2_21_12  connected_order_arc_1492  -13
    arc_2_21_12  in_degree_1544  1
    arc_2_21_12  out_degree_1600  1
    arc_2_21_12  original_T_including_depot_unload_1615  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1491  1
    load_2_21_12  segment_load_conservation_1547  -1
    load_2_21_12  segment_prefix_lb_1548  1
    load_2_21_12  segment_prefix_ub_1549  1
    load_2_21_12  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1493  -30
    arc_2_21_13  connected_order_arc_1494  -13
    arc_2_21_13  in_degree_1551  1
    arc_2_21_13  out_degree_1600  1
    arc_2_21_13  original_T_including_depot_unload_1615  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1493  1
    load_2_21_13  segment_load_conservation_1554  -1
    load_2_21_13  segment_prefix_lb_1555  1
    load_2_21_13  segment_prefix_ub_1556  1
    load_2_21_13  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1495  -30
    arc_2_21_14  connected_order_arc_1496  -13
    arc_2_21_14  in_degree_1558  1
    arc_2_21_14  out_degree_1600  1
    arc_2_21_14  original_T_including_depot_unload_1615  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1495  1
    load_2_21_14  segment_load_conservation_1561  -1
    load_2_21_14  segment_prefix_lb_1562  1
    load_2_21_14  segment_prefix_ub_1563  1
    load_2_21_14  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1497  -30
    arc_2_21_15  connected_order_arc_1498  -13
    arc_2_21_15  in_degree_1565  1
    arc_2_21_15  out_degree_1600  1
    arc_2_21_15  original_T_including_depot_unload_1615  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1497  1
    load_2_21_15  free_load_conservation_1569  -1
    load_2_21_15  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1499  -30
    arc_2_21_16  connected_order_arc_1500  -13
    arc_2_21_16  in_degree_1571  1
    arc_2_21_16  out_degree_1600  1
    arc_2_21_16  original_T_including_depot_unload_1615  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1499  1
    load_2_21_16  free_load_conservation_1575  -1
    load_2_21_16  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1501  -30
    arc_2_21_17  connected_order_arc_1502  -13
    arc_2_21_17  in_degree_1577  1
    arc_2_21_17  out_degree_1600  1
    arc_2_21_17  original_T_including_depot_unload_1615  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1501  1
    load_2_21_17  free_load_conservation_1581  -1
    load_2_21_17  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1503  -30
    arc_2_21_18  connected_order_arc_1504  -13
    arc_2_21_18  in_degree_1583  1
    arc_2_21_18  out_degree_1600  1
    arc_2_21_18  original_T_including_depot_unload_1615  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1503  1
    load_2_21_18  free_load_conservation_1587  -1
    load_2_21_18  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1505  -30
    arc_2_21_19  connected_order_arc_1506  -13
    arc_2_21_19  in_degree_1589  1
    arc_2_21_19  out_degree_1600  1
    arc_2_21_19  original_T_including_depot_unload_1615  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1505  1
    load_2_21_19  free_load_conservation_1593  -1
    load_2_21_19  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1507  -30
    arc_2_21_20  connected_order_arc_1508  -13
    arc_2_21_20  in_degree_1595  1
    arc_2_21_20  out_degree_1600  1
    arc_2_21_20  original_T_including_depot_unload_1615  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1507  1
    load_2_21_20  free_load_conservation_1599  -1
    load_2_21_20  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_22  arc_capacity_1509  -30
    arc_2_21_22  connected_order_arc_1510  -13
    arc_2_21_22  out_degree_1600  1
    arc_2_21_22  in_degree_1607  1
    arc_2_21_22  original_T_including_depot_unload_1615  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_22  arc_capacity_1509  1
    load_2_21_22  free_load_conservation_1605  1
    load_2_21_22  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_0  arc_capacity_1511  -30
    arc_2_22_0  depot_return_or_bypass_1535  1
    arc_2_22_0  out_degree_1606  1
    arc_2_22_0  original_T_including_depot_unload_1615  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_0  arc_capacity_1511  1
    load_2_22_0  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_11  arc_capacity_1512  -30
    arc_2_22_11  connected_order_arc_1513  -13
    arc_2_22_11  in_degree_1537  1
    arc_2_22_11  out_degree_1606  1
    arc_2_22_11  original_T_including_depot_unload_1615  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_11  arc_capacity_1512  1
    load_2_22_11  segment_load_conservation_1540  -1
    load_2_22_11  segment_prefix_lb_1541  1
    load_2_22_11  segment_prefix_ub_1542  1
    load_2_22_11  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_12  arc_capacity_1514  -30
    arc_2_22_12  connected_order_arc_1515  -13
    arc_2_22_12  in_degree_1544  1
    arc_2_22_12  out_degree_1606  1
    arc_2_22_12  original_T_including_depot_unload_1615  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_12  arc_capacity_1514  1
    load_2_22_12  segment_load_conservation_1547  -1
    load_2_22_12  segment_prefix_lb_1548  1
    load_2_22_12  segment_prefix_ub_1549  1
    load_2_22_12  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_13  arc_capacity_1516  -30
    arc_2_22_13  connected_order_arc_1517  -13
    arc_2_22_13  in_degree_1551  1
    arc_2_22_13  out_degree_1606  1
    arc_2_22_13  original_T_including_depot_unload_1615  1.3889860796771311e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_13  arc_capacity_1516  1
    load_2_22_13  segment_load_conservation_1554  -1
    load_2_22_13  segment_prefix_lb_1555  1
    load_2_22_13  segment_prefix_ub_1556  1
    load_2_22_13  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_14  arc_capacity_1518  -30
    arc_2_22_14  connected_order_arc_1519  -13
    arc_2_22_14  in_degree_1558  1
    arc_2_22_14  out_degree_1606  1
    arc_2_22_14  original_T_including_depot_unload_1615  7.9613989083692911e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_14  arc_capacity_1518  1
    load_2_22_14  segment_load_conservation_1561  -1
    load_2_22_14  segment_prefix_lb_1562  1
    load_2_22_14  segment_prefix_ub_1563  1
    load_2_22_14  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_15  arc_capacity_1520  -30
    arc_2_22_15  connected_order_arc_1521  -13
    arc_2_22_15  in_degree_1565  1
    arc_2_22_15  out_degree_1606  1
    arc_2_22_15  original_T_including_depot_unload_1615  7.9829177317292124e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_15  arc_capacity_1520  1
    load_2_22_15  free_load_conservation_1569  -1
    load_2_22_15  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_16  arc_capacity_1522  -30
    arc_2_22_16  connected_order_arc_1523  -13
    arc_2_22_16  in_degree_1571  1
    arc_2_22_16  out_degree_1606  1
    arc_2_22_16  original_T_including_depot_unload_1615  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_16  arc_capacity_1522  1
    load_2_22_16  free_load_conservation_1575  -1
    load_2_22_16  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_17  arc_capacity_1524  -30
    arc_2_22_17  connected_order_arc_1525  -13
    arc_2_22_17  in_degree_1577  1
    arc_2_22_17  out_degree_1606  1
    arc_2_22_17  original_T_including_depot_unload_1615  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_17  arc_capacity_1524  1
    load_2_22_17  free_load_conservation_1581  -1
    load_2_22_17  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_18  arc_capacity_1526  -30
    arc_2_22_18  connected_order_arc_1527  -13
    arc_2_22_18  in_degree_1583  1
    arc_2_22_18  out_degree_1606  1
    arc_2_22_18  original_T_including_depot_unload_1615  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_18  arc_capacity_1526  1
    load_2_22_18  free_load_conservation_1587  -1
    load_2_22_18  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_19  arc_capacity_1528  -30
    arc_2_22_19  connected_order_arc_1529  -13
    arc_2_22_19  in_degree_1589  1
    arc_2_22_19  out_degree_1606  1
    arc_2_22_19  original_T_including_depot_unload_1615  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_19  arc_capacity_1528  1
    load_2_22_19  free_load_conservation_1593  -1
    load_2_22_19  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_20  arc_capacity_1530  -30
    arc_2_22_20  connected_order_arc_1531  -13
    arc_2_22_20  in_degree_1595  1
    arc_2_22_20  out_degree_1606  1
    arc_2_22_20  original_T_including_depot_unload_1615  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_20  arc_capacity_1530  1
    load_2_22_20  free_load_conservation_1599  -1
    load_2_22_20  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_21  arc_capacity_1532  -30
    arc_2_22_21  connected_order_arc_1533  -13
    arc_2_22_21  in_degree_1601  1
    arc_2_22_21  out_degree_1606  1
    arc_2_22_21  original_T_including_depot_unload_1615  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_21  arc_capacity_1532  1
    load_2_22_21  free_load_conservation_1605  -1
    load_2_22_21  free_load_conservation_1611  1
RHS
    RHS1      OBJ       -4.0875000000000006e-01
    RHS1      onehot_30_18  1
    RHS1      onehot_35_53  1
    RHS1      onehot_31_82  1
    RHS1      onehot_32_111  1
    RHS1      onehot_19_132  1
    RHS1      onehot_26_153  1
    RHS1      onehot_2_188  1
    RHS1      onehot_17_225  1
    RHS1      stock_ub_229  28
    RHS1      parent_nonstrict_scope_230  3.5189660134431267e-01
    RHS1      normalization_287  1
    RHS1      connected_order_arc_400  -14
    RHS1      connected_order_arc_402  -14
    RHS1      connected_order_arc_404  -14
    RHS1      connected_order_arc_406  -14
    RHS1      connected_order_arc_408  -14
    RHS1      connected_order_arc_410  -14
    RHS1      connected_order_arc_412  -14
    RHS1      connected_order_arc_414  -14
    RHS1      connected_order_arc_416  -14
    RHS1      connected_order_arc_418  -14
    RHS1      connected_order_arc_420  -14
    RHS1      connected_order_arc_422  -14
    RHS1      connected_order_arc_424  -14
    RHS1      connected_order_arc_427  -14
    RHS1      connected_order_arc_429  -14
    RHS1      connected_order_arc_431  -14
    RHS1      connected_order_arc_433  -14
    RHS1      connected_order_arc_435  -14
    RHS1      connected_order_arc_437  -14
    RHS1      connected_order_arc_439  -14
    RHS1      connected_order_arc_441  -14
    RHS1      connected_order_arc_443  -14
    RHS1      connected_order_arc_445  -14
    RHS1      connected_order_arc_447  -14
    RHS1      connected_order_arc_449  -14
    RHS1      connected_order_arc_451  -14
    RHS1      connected_order_arc_454  -14
    RHS1      connected_order_arc_456  -14
    RHS1      connected_order_arc_458  -14
    RHS1      connected_order_arc_460  -14
    RHS1      connected_order_arc_462  -14
    RHS1      connected_order_arc_464  -14
    RHS1      connected_order_arc_466  -14
    RHS1      connected_order_arc_468  -14
    RHS1      connected_order_arc_470  -14
    RHS1      connected_order_arc_472  -14
    RHS1      connected_order_arc_474  -14
    RHS1      connected_order_arc_476  -14
    RHS1      connected_order_arc_478  -14
    RHS1      connected_order_arc_481  -14
    RHS1      connected_order_arc_483  -14
    RHS1      connected_order_arc_485  -14
    RHS1      connected_order_arc_487  -14
    RHS1      connected_order_arc_489  -14
    RHS1      connected_order_arc_491  -14
    RHS1      connected_order_arc_493  -14
    RHS1      connected_order_arc_495  -14
    RHS1      connected_order_arc_497  -14
    RHS1      connected_order_arc_499  -14
    RHS1      connected_order_arc_501  -14
    RHS1      connected_order_arc_503  -14
    RHS1      connected_order_arc_505  -14
    RHS1      connected_order_arc_508  -14
    RHS1      connected_order_arc_510  -14
    RHS1      connected_order_arc_512  -14
    RHS1      connected_order_arc_514  -14
    RHS1      connected_order_arc_516  -14
    RHS1      connected_order_arc_518  -14
    RHS1      connected_order_arc_520  -14
    RHS1      connected_order_arc_522  -14
    RHS1      connected_order_arc_524  -14
    RHS1      connected_order_arc_526  -14
    RHS1      connected_order_arc_528  -14
    RHS1      connected_order_arc_530  -14
    RHS1      connected_order_arc_532  -14
    RHS1      connected_order_arc_535  -14
    RHS1      connected_order_arc_537  -14
    RHS1      connected_order_arc_539  -14
    RHS1      connected_order_arc_541  -14
    RHS1      connected_order_arc_543  -14
    RHS1      connected_order_arc_545  -14
    RHS1      connected_order_arc_547  -14
    RHS1      connected_order_arc_549  -14
    RHS1      connected_order_arc_551  -14
    RHS1      connected_order_arc_553  -14
    RHS1      connected_order_arc_555  -14
    RHS1      connected_order_arc_557  -14
    RHS1      connected_order_arc_559  -14
    RHS1      connected_order_arc_562  -14
    RHS1      connected_order_arc_564  -14
    RHS1      connected_order_arc_566  -14
    RHS1      connected_order_arc_568  -14
    RHS1      connected_order_arc_570  -14
    RHS1      connected_order_arc_572  -14
    RHS1      connected_order_arc_574  -14
    RHS1      connected_order_arc_576  -14
    RHS1      connected_order_arc_578  -14
    RHS1      connected_order_arc_580  -14
    RHS1      connected_order_arc_582  -14
    RHS1      connected_order_arc_584  -14
    RHS1      connected_order_arc_586  -14
    RHS1      connected_order_arc_589  -14
    RHS1      connected_order_arc_591  -14
    RHS1      connected_order_arc_593  -14
    RHS1      connected_order_arc_595  -14
    RHS1      connected_order_arc_597  -14
    RHS1      connected_order_arc_599  -14
    RHS1      connected_order_arc_601  -14
    RHS1      connected_order_arc_603  -14
    RHS1      connected_order_arc_605  -14
    RHS1      connected_order_arc_607  -14
    RHS1      connected_order_arc_609  -14
    RHS1      connected_order_arc_611  -14
    RHS1      connected_order_arc_613  -14
    RHS1      connected_order_arc_616  -14
    RHS1      connected_order_arc_618  -14
    RHS1      connected_order_arc_620  -14
    RHS1      connected_order_arc_622  -14
    RHS1      connected_order_arc_624  -14
    RHS1      connected_order_arc_626  -14
    RHS1      connected_order_arc_628  -14
    RHS1      connected_order_arc_630  -14
    RHS1      connected_order_arc_632  -14
    RHS1      connected_order_arc_634  -14
    RHS1      connected_order_arc_636  -14
    RHS1      connected_order_arc_638  -14
    RHS1      connected_order_arc_640  -14
    RHS1      connected_order_arc_643  -14
    RHS1      connected_order_arc_645  -14
    RHS1      connected_order_arc_647  -14
    RHS1      connected_order_arc_649  -14
    RHS1      connected_order_arc_651  -14
    RHS1      connected_order_arc_653  -14
    RHS1      connected_order_arc_655  -14
    RHS1      connected_order_arc_657  -14
    RHS1      connected_order_arc_659  -14
    RHS1      connected_order_arc_661  -14
    RHS1      connected_order_arc_663  -14
    RHS1      connected_order_arc_665  -14
    RHS1      connected_order_arc_667  -14
    RHS1      connected_order_arc_670  -14
    RHS1      connected_order_arc_672  -14
    RHS1      connected_order_arc_674  -14
    RHS1      connected_order_arc_676  -14
    RHS1      connected_order_arc_678  -14
    RHS1      connected_order_arc_680  -14
    RHS1      connected_order_arc_682  -14
    RHS1      connected_order_arc_684  -14
    RHS1      connected_order_arc_686  -14
    RHS1      connected_order_arc_688  -14
    RHS1      connected_order_arc_690  -14
    RHS1      connected_order_arc_692  -14
    RHS1      connected_order_arc_694  -14
    RHS1      connected_order_arc_697  -14
    RHS1      connected_order_arc_699  -14
    RHS1      connected_order_arc_701  -14
    RHS1      connected_order_arc_703  -14
    RHS1      connected_order_arc_705  -14
    RHS1      connected_order_arc_707  -14
    RHS1      connected_order_arc_709  -14
    RHS1      connected_order_arc_711  -14
    RHS1      connected_order_arc_713  -14
    RHS1      connected_order_arc_715  -14
    RHS1      connected_order_arc_717  -14
    RHS1      connected_order_arc_719  -14
    RHS1      connected_order_arc_721  -14
    RHS1      connected_order_arc_724  -14
    RHS1      connected_order_arc_726  -14
    RHS1      connected_order_arc_728  -14
    RHS1      connected_order_arc_730  -14
    RHS1      connected_order_arc_732  -14
    RHS1      connected_order_arc_734  -14
    RHS1      connected_order_arc_736  -14
    RHS1      connected_order_arc_738  -14
    RHS1      connected_order_arc_740  -14
    RHS1      connected_order_arc_742  -14
    RHS1      connected_order_arc_744  -14
    RHS1      connected_order_arc_746  -14
    RHS1      connected_order_arc_748  -14
    RHS1      connected_order_arc_751  -14
    RHS1      connected_order_arc_753  -14
    RHS1      connected_order_arc_755  -14
    RHS1      connected_order_arc_757  -14
    RHS1      connected_order_arc_759  -14
    RHS1      connected_order_arc_761  -14
    RHS1      connected_order_arc_763  -14
    RHS1      connected_order_arc_765  -14
    RHS1      connected_order_arc_767  -14
    RHS1      connected_order_arc_769  -14
    RHS1      connected_order_arc_771  -14
    RHS1      connected_order_arc_773  -14
    RHS1      connected_order_arc_775  -14
    RHS1      depot_departure_or_bypass_776  1
    RHS1      depot_return_or_bypass_777  1
    RHS1      segment_load_conservation_782  19
    RHS1      segment_prefix_ub_784  1
    RHS1      segment_load_conservation_789  -8
    RHS1      segment_prefix_lb_790  8
    RHS1      segment_prefix_ub_791  20
    RHS1      segment_load_conservation_796  -5
    RHS1      segment_prefix_lb_797  5
    RHS1      segment_prefix_ub_798  20
    RHS1      segment_load_conservation_803  5
    RHS1      segment_prefix_ub_805  15
    RHS1      segment_load_conservation_810  6
    RHS1      segment_prefix_ub_812  14
    RHS1      segment_load_conservation_817  -6
    RHS1      segment_prefix_lb_818  6
    RHS1      segment_prefix_ub_819  20
    RHS1      fixed_segment_relative_order_868  1
    RHS1      fixed_segment_relative_order_869  1
    RHS1      fixed_segment_relative_order_870  1
    RHS1      fixed_segment_relative_order_871  1
    RHS1      fixed_segment_relative_order_872  1
    RHS1      original_T_including_depot_unload_873  2.5355290443038703e+03
    RHS1      connected_order_arc_889  -12
    RHS1      connected_order_arc_891  -12
    RHS1      connected_order_arc_893  -12
    RHS1      connected_order_arc_895  -12
    RHS1      connected_order_arc_897  -12
    RHS1      connected_order_arc_899  -12
    RHS1      connected_order_arc_901  -12
    RHS1      connected_order_arc_903  -12
    RHS1      connected_order_arc_905  -12
    RHS1      connected_order_arc_907  -12
    RHS1      connected_order_arc_909  -12
    RHS1      connected_order_arc_912  -12
    RHS1      connected_order_arc_914  -12
    RHS1      connected_order_arc_916  -12
    RHS1      connected_order_arc_918  -12
    RHS1      connected_order_arc_920  -12
    RHS1      connected_order_arc_922  -12
    RHS1      connected_order_arc_924  -12
    RHS1      connected_order_arc_926  -12
    RHS1      connected_order_arc_928  -12
    RHS1      connected_order_arc_930  -12
    RHS1      connected_order_arc_932  -12
    RHS1      connected_order_arc_935  -12
    RHS1      connected_order_arc_937  -12
    RHS1      connected_order_arc_939  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_943  -12
    RHS1      connected_order_arc_945  -12
    RHS1      connected_order_arc_947  -12
    RHS1      connected_order_arc_949  -12
    RHS1      connected_order_arc_951  -12
    RHS1      connected_order_arc_953  -12
    RHS1      connected_order_arc_955  -12
    RHS1      connected_order_arc_958  -12
    RHS1      connected_order_arc_960  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_966  -12
    RHS1      connected_order_arc_968  -12
    RHS1      connected_order_arc_970  -12
    RHS1      connected_order_arc_972  -12
    RHS1      connected_order_arc_974  -12
    RHS1      connected_order_arc_976  -12
    RHS1      connected_order_arc_978  -12
    RHS1      connected_order_arc_981  -12
    RHS1      connected_order_arc_983  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_989  -12
    RHS1      connected_order_arc_991  -12
    RHS1      connected_order_arc_993  -12
    RHS1      connected_order_arc_995  -12
    RHS1      connected_order_arc_997  -12
    RHS1      connected_order_arc_999  -12
    RHS1      connected_order_arc_1001  -12
    RHS1      connected_order_arc_1004  -12
    RHS1      connected_order_arc_1006  -12
    RHS1      connected_order_arc_1008  -12
    RHS1      connected_order_arc_1010  -12
    RHS1      connected_order_arc_1012  -12
    RHS1      connected_order_arc_1014  -12
    RHS1      connected_order_arc_1016  -12
    RHS1      connected_order_arc_1018  -12
    RHS1      connected_order_arc_1020  -12
    RHS1      connected_order_arc_1022  -12
    RHS1      connected_order_arc_1024  -12
    RHS1      connected_order_arc_1027  -12
    RHS1      connected_order_arc_1029  -12
    RHS1      connected_order_arc_1031  -12
    RHS1      connected_order_arc_1033  -12
    RHS1      connected_order_arc_1035  -12
    RHS1      connected_order_arc_1037  -12
    RHS1      connected_order_arc_1039  -12
    RHS1      connected_order_arc_1041  -12
    RHS1      connected_order_arc_1043  -12
    RHS1      connected_order_arc_1045  -12
    RHS1      connected_order_arc_1047  -12
    RHS1      connected_order_arc_1050  -12
    RHS1      connected_order_arc_1052  -12
    RHS1      connected_order_arc_1054  -12
    RHS1      connected_order_arc_1056  -12
    RHS1      connected_order_arc_1058  -12
    RHS1      connected_order_arc_1060  -12
    RHS1      connected_order_arc_1062  -12
    RHS1      connected_order_arc_1064  -12
    RHS1      connected_order_arc_1066  -12
    RHS1      connected_order_arc_1068  -12
    RHS1      connected_order_arc_1070  -12
    RHS1      connected_order_arc_1073  -12
    RHS1      connected_order_arc_1075  -12
    RHS1      connected_order_arc_1077  -12
    RHS1      connected_order_arc_1079  -12
    RHS1      connected_order_arc_1081  -12
    RHS1      connected_order_arc_1083  -12
    RHS1      connected_order_arc_1085  -12
    RHS1      connected_order_arc_1087  -12
    RHS1      connected_order_arc_1089  -12
    RHS1      connected_order_arc_1091  -12
    RHS1      connected_order_arc_1093  -12
    RHS1      connected_order_arc_1096  -12
    RHS1      connected_order_arc_1098  -12
    RHS1      connected_order_arc_1100  -12
    RHS1      connected_order_arc_1102  -12
    RHS1      connected_order_arc_1104  -12
    RHS1      connected_order_arc_1106  -12
    RHS1      connected_order_arc_1108  -12
    RHS1      connected_order_arc_1110  -12
    RHS1      connected_order_arc_1112  -12
    RHS1      connected_order_arc_1114  -12
    RHS1      connected_order_arc_1116  -12
    RHS1      connected_order_arc_1119  -12
    RHS1      connected_order_arc_1121  -12
    RHS1      connected_order_arc_1123  -12
    RHS1      connected_order_arc_1125  -12
    RHS1      connected_order_arc_1127  -12
    RHS1      connected_order_arc_1129  -12
    RHS1      connected_order_arc_1131  -12
    RHS1      connected_order_arc_1133  -12
    RHS1      connected_order_arc_1135  -12
    RHS1      connected_order_arc_1137  -12
    RHS1      connected_order_arc_1139  -12
    RHS1      connected_order_arc_1142  -12
    RHS1      connected_order_arc_1144  -12
    RHS1      connected_order_arc_1146  -12
    RHS1      connected_order_arc_1148  -12
    RHS1      connected_order_arc_1150  -12
    RHS1      connected_order_arc_1152  -12
    RHS1      connected_order_arc_1154  -12
    RHS1      connected_order_arc_1156  -12
    RHS1      connected_order_arc_1158  -12
    RHS1      connected_order_arc_1160  -12
    RHS1      connected_order_arc_1162  -12
    RHS1      depot_departure_or_bypass_1163  1
    RHS1      depot_return_or_bypass_1164  1
    RHS1      segment_load_conservation_1169  4
    RHS1      segment_prefix_ub_1171  21
    RHS1      segment_load_conservation_1176  3
    RHS1      segment_prefix_ub_1178  22
    RHS1      segment_load_conservation_1183  -5
    RHS1      segment_prefix_lb_1184  5
    RHS1      segment_prefix_ub_1185  25
    RHS1      segment_load_conservation_1190  -2
    RHS1      segment_prefix_lb_1191  2
    RHS1      segment_prefix_ub_1192  16
    RHS1      fixed_segment_relative_order_1241  1
    RHS1      fixed_segment_relative_order_1242  1
    RHS1      fixed_segment_relative_order_1243  1
    RHS1      original_T_including_depot_unload_1244  2.5466013138995804e+03
    RHS1      connected_order_arc_1260  -12
    RHS1      connected_order_arc_1262  -12
    RHS1      connected_order_arc_1264  -12
    RHS1      connected_order_arc_1266  -12
    RHS1      connected_order_arc_1268  -12
    RHS1      connected_order_arc_1270  -12
    RHS1      connected_order_arc_1272  -12
    RHS1      connected_order_arc_1274  -12
    RHS1      connected_order_arc_1276  -12
    RHS1      connected_order_arc_1278  -12
    RHS1      connected_order_arc_1280  -12
    RHS1      connected_order_arc_1283  -12
    RHS1      connected_order_arc_1285  -12
    RHS1      connected_order_arc_1287  -12
    RHS1      connected_order_arc_1289  -12
    RHS1      connected_order_arc_1291  -12
    RHS1      connected_order_arc_1293  -12
    RHS1      connected_order_arc_1295  -12
    RHS1      connected_order_arc_1297  -12
    RHS1      connected_order_arc_1299  -12
    RHS1      connected_order_arc_1301  -12
    RHS1      connected_order_arc_1303  -12
    RHS1      connected_order_arc_1306  -12
    RHS1      connected_order_arc_1308  -12
    RHS1      connected_order_arc_1310  -12
    RHS1      connected_order_arc_1312  -12
    RHS1      connected_order_arc_1314  -12
    RHS1      connected_order_arc_1316  -12
    RHS1      connected_order_arc_1318  -12
    RHS1      connected_order_arc_1320  -12
    RHS1      connected_order_arc_1322  -12
    RHS1      connected_order_arc_1324  -12
    RHS1      connected_order_arc_1326  -12
    RHS1      connected_order_arc_1329  -12
    RHS1      connected_order_arc_1331  -12
    RHS1      connected_order_arc_1333  -12
    RHS1      connected_order_arc_1335  -12
    RHS1      connected_order_arc_1337  -12
    RHS1      connected_order_arc_1339  -12
    RHS1      connected_order_arc_1341  -12
    RHS1      connected_order_arc_1343  -12
    RHS1      connected_order_arc_1345  -12
    RHS1      connected_order_arc_1347  -12
    RHS1      connected_order_arc_1349  -12
    RHS1      connected_order_arc_1352  -12
    RHS1      connected_order_arc_1354  -12
    RHS1      connected_order_arc_1356  -12
    RHS1      connected_order_arc_1358  -12
    RHS1      connected_order_arc_1360  -12
    RHS1      connected_order_arc_1362  -12
    RHS1      connected_order_arc_1364  -12
    RHS1      connected_order_arc_1366  -12
    RHS1      connected_order_arc_1368  -12
    RHS1      connected_order_arc_1370  -12
    RHS1      connected_order_arc_1372  -12
    RHS1      connected_order_arc_1375  -12
    RHS1      connected_order_arc_1377  -12
    RHS1      connected_order_arc_1379  -12
    RHS1      connected_order_arc_1381  -12
    RHS1      connected_order_arc_1383  -12
    RHS1      connected_order_arc_1385  -12
    RHS1      connected_order_arc_1387  -12
    RHS1      connected_order_arc_1389  -12
    RHS1      connected_order_arc_1391  -12
    RHS1      connected_order_arc_1393  -12
    RHS1      connected_order_arc_1395  -12
    RHS1      connected_order_arc_1398  -12
    RHS1      connected_order_arc_1400  -12
    RHS1      connected_order_arc_1402  -12
    RHS1      connected_order_arc_1404  -12
    RHS1      connected_order_arc_1406  -12
    RHS1      connected_order_arc_1408  -12
    RHS1      connected_order_arc_1410  -12
    RHS1      connected_order_arc_1412  -12
    RHS1      connected_order_arc_1414  -12
    RHS1      connected_order_arc_1416  -12
    RHS1      connected_order_arc_1418  -12
    RHS1      connected_order_arc_1421  -12
    RHS1      connected_order_arc_1423  -12
    RHS1      connected_order_arc_1425  -12
    RHS1      connected_order_arc_1427  -12
    RHS1      connected_order_arc_1429  -12
    RHS1      connected_order_arc_1431  -12
    RHS1      connected_order_arc_1433  -12
    RHS1      connected_order_arc_1435  -12
    RHS1      connected_order_arc_1437  -12
    RHS1      connected_order_arc_1439  -12
    RHS1      connected_order_arc_1441  -12
    RHS1      connected_order_arc_1444  -12
    RHS1      connected_order_arc_1446  -12
    RHS1      connected_order_arc_1448  -12
    RHS1      connected_order_arc_1450  -12
    RHS1      connected_order_arc_1452  -12
    RHS1      connected_order_arc_1454  -12
    RHS1      connected_order_arc_1456  -12
    RHS1      connected_order_arc_1458  -12
    RHS1      connected_order_arc_1460  -12
    RHS1      connected_order_arc_1462  -12
    RHS1      connected_order_arc_1464  -12
    RHS1      connected_order_arc_1467  -12
    RHS1      connected_order_arc_1469  -12
    RHS1      connected_order_arc_1471  -12
    RHS1      connected_order_arc_1473  -12
    RHS1      connected_order_arc_1475  -12
    RHS1      connected_order_arc_1477  -12
    RHS1      connected_order_arc_1479  -12
    RHS1      connected_order_arc_1481  -12
    RHS1      connected_order_arc_1483  -12
    RHS1      connected_order_arc_1485  -12
    RHS1      connected_order_arc_1487  -12
    RHS1      connected_order_arc_1490  -12
    RHS1      connected_order_arc_1492  -12
    RHS1      connected_order_arc_1494  -12
    RHS1      connected_order_arc_1496  -12
    RHS1      connected_order_arc_1498  -12
    RHS1      connected_order_arc_1500  -12
    RHS1      connected_order_arc_1502  -12
    RHS1      connected_order_arc_1504  -12
    RHS1      connected_order_arc_1506  -12
    RHS1      connected_order_arc_1508  -12
    RHS1      connected_order_arc_1510  -12
    RHS1      connected_order_arc_1513  -12
    RHS1      connected_order_arc_1515  -12
    RHS1      connected_order_arc_1517  -12
    RHS1      connected_order_arc_1519  -12
    RHS1      connected_order_arc_1521  -12
    RHS1      connected_order_arc_1523  -12
    RHS1      connected_order_arc_1525  -12
    RHS1      connected_order_arc_1527  -12
    RHS1      connected_order_arc_1529  -12
    RHS1      connected_order_arc_1531  -12
    RHS1      connected_order_arc_1533  -12
    RHS1      depot_departure_or_bypass_1534  1
    RHS1      depot_return_or_bypass_1535  1
    RHS1      segment_load_conservation_1540  2
    RHS1      segment_prefix_ub_1542  28
    RHS1      segment_load_conservation_1547  -1
    RHS1      segment_prefix_lb_1548  1
    RHS1      segment_prefix_ub_1549  30
    RHS1      segment_prefix_ub_1556  25
    RHS1      segment_load_conservation_1561  -5
    RHS1      segment_prefix_lb_1562  5
    RHS1      segment_prefix_ub_1563  30
    RHS1      fixed_segment_relative_order_1612  1
    RHS1      fixed_segment_relative_order_1613  1
    RHS1      fixed_segment_relative_order_1614  1
    RHS1      original_T_including_depot_unload_1615  5.3669329281192686e+03
BOUNDS
 LO BND1      t         2.4708547000141974e-02
 UP BND1      t         4.0713454827493223e-02
 UP BND1      q         5.1089660134431270e-01
 BV BND1      x_30_0  
 UP BND1      w_30_0    4.0713454827493223e-02
 BV BND1      x_30_1  
 UP BND1      w_30_1    4.0713454827493223e-02
 BV BND1      x_30_2  
 UP BND1      w_30_2    4.0713454827493223e-02
 BV BND1      x_30_3  
 UP BND1      w_30_3    4.0713454827493223e-02
 BV BND1      x_30_4  
 UP BND1      w_30_4    4.0713454827493223e-02
 BV BND1      x_30_5  
 UP BND1      w_30_5    4.0713454827493223e-02
 BV BND1      x_30_6  
 UP BND1      w_30_6    4.0713454827493223e-02
 BV BND1      x_30_7  
 UP BND1      w_30_7    4.0713454827493223e-02
 BV BND1      x_30_8  
 UP BND1      w_30_8    4.0713454827493223e-02
 UP BND1      rho_30    1
 BV BND1      x_35_0  
 UP BND1      w_35_0    4.0713454827493223e-02
 BV BND1      x_35_1  
 UP BND1      w_35_1    4.0713454827493223e-02
 BV BND1      x_35_2  
 UP BND1      w_35_2    4.0713454827493223e-02
 BV BND1      x_35_3  
 UP BND1      w_35_3    4.0713454827493223e-02
 BV BND1      x_35_4  
 UP BND1      w_35_4    4.0713454827493223e-02
 BV BND1      x_35_5  
 UP BND1      w_35_5    4.0713454827493223e-02
 BV BND1      x_35_6  
 UP BND1      w_35_6    4.0713454827493223e-02
 BV BND1      x_35_7  
 UP BND1      w_35_7    4.0713454827493223e-02
 BV BND1      x_35_8  
 UP BND1      w_35_8    4.0713454827493223e-02
 BV BND1      x_35_9  
 UP BND1      w_35_9    4.0713454827493223e-02
 BV BND1      x_35_10 
 UP BND1      w_35_10   4.0713454827493223e-02
 BV BND1      x_35_11 
 UP BND1      w_35_11   4.0713454827493223e-02
 BV BND1      x_35_12 
 UP BND1      w_35_12   4.0713454827493223e-02
 BV BND1      x_35_13 
 UP BND1      w_35_13   4.0713454827493223e-02
 BV BND1      x_35_14 
 UP BND1      w_35_14   4.0713454827493223e-02
 BV BND1      x_35_15 
 UP BND1      w_35_15   4.0713454827493223e-02
 UP BND1      rho_35    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.0713454827493223e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.0713454827493223e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.0713454827493223e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.0713454827493223e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.0713454827493223e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.0713454827493223e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.0713454827493223e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.0713454827493223e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.0713454827493223e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.0713454827493223e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.0713454827493223e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.0713454827493223e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.0713454827493223e-02
 UP BND1      rho_31    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.0713454827493223e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.0713454827493223e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.0713454827493223e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.0713454827493223e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.0713454827493223e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.0713454827493223e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.0713454827493223e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.0713454827493223e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.0713454827493223e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.0713454827493223e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.0713454827493223e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.0713454827493223e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.0713454827493223e-02
 UP BND1      rho_32    1
 BV BND1      x_19_0  
 UP BND1      w_19_0    4.0713454827493223e-02
 BV BND1      x_19_1  
 UP BND1      w_19_1    4.0713454827493223e-02
 BV BND1      x_19_2  
 UP BND1      w_19_2    4.0713454827493223e-02
 BV BND1      x_19_3  
 UP BND1      w_19_3    4.0713454827493223e-02
 BV BND1      x_19_4  
 UP BND1      w_19_4    4.0713454827493223e-02
 BV BND1      x_19_5  
 UP BND1      w_19_5    4.0713454827493223e-02
 BV BND1      x_19_6  
 UP BND1      w_19_6    4.0713454827493223e-02
 BV BND1      x_19_7  
 UP BND1      w_19_7    4.0713454827493223e-02
 BV BND1      x_19_8  
 UP BND1      w_19_8    4.0713454827493223e-02
 UP BND1      rho_19    1
 BV BND1      x_26_0  
 UP BND1      w_26_0    4.0713454827493223e-02
 BV BND1      x_26_1  
 UP BND1      w_26_1    4.0713454827493223e-02
 BV BND1      x_26_2  
 UP BND1      w_26_2    4.0713454827493223e-02
 BV BND1      x_26_3  
 UP BND1      w_26_3    4.0713454827493223e-02
 BV BND1      x_26_4  
 UP BND1      w_26_4    4.0713454827493223e-02
 BV BND1      x_26_5  
 UP BND1      w_26_5    4.0713454827493223e-02
 BV BND1      x_26_6  
 UP BND1      w_26_6    4.0713454827493223e-02
 BV BND1      x_26_7  
 UP BND1      w_26_7    4.0713454827493223e-02
 BV BND1      x_26_8  
 UP BND1      w_26_8    4.0713454827493223e-02
 UP BND1      rho_26    1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.0713454827493223e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.0713454827493223e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.0713454827493223e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.0713454827493223e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.0713454827493223e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.0713454827493223e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.0713454827493223e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.0713454827493223e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.0713454827493223e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.0713454827493223e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.0713454827493223e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.0713454827493223e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.0713454827493223e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.0713454827493223e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.0713454827493223e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.0713454827493223e-02
 UP BND1      rho_2     1
 BV BND1      x_17_0  
 UP BND1      w_17_0    4.0713454827493223e-02
 BV BND1      x_17_1  
 UP BND1      w_17_1    4.0713454827493223e-02
 BV BND1      x_17_2  
 UP BND1      w_17_2    4.0713454827493223e-02
 BV BND1      x_17_3  
 UP BND1      w_17_3    4.0713454827493223e-02
 BV BND1      x_17_4  
 UP BND1      w_17_4    4.0713454827493223e-02
 BV BND1      x_17_5  
 UP BND1      w_17_5    4.0713454827493223e-02
 BV BND1      x_17_6  
 UP BND1      w_17_6    4.0713454827493223e-02
 BV BND1      x_17_7  
 UP BND1      w_17_7    4.0713454827493223e-02
 BV BND1      x_17_8  
 UP BND1      w_17_8    4.0713454827493223e-02
 BV BND1      x_17_9  
 UP BND1      w_17_9    4.0713454827493223e-02
 BV BND1      x_17_10 
 UP BND1      w_17_10   4.0713454827493223e-02
 BV BND1      x_17_11 
 UP BND1      w_17_11   4.0713454827493223e-02
 BV BND1      x_17_12 
 UP BND1      w_17_12   4.0713454827493223e-02
 BV BND1      x_17_13 
 UP BND1      w_17_13   4.0713454827493223e-02
 BV BND1      x_17_14 
 UP BND1      w_17_14   4.0713454827493223e-02
 BV BND1      x_17_15 
 UP BND1      w_17_15   4.0713454827493223e-02
 BV BND1      x_17_16 
 UP BND1      w_17_16   4.0713454827493223e-02
 UP BND1      rho_17    1
 UP BND1      a_30_35   1
 UP BND1      a_30_31   1
 UP BND1      a_30_32   1
 UP BND1      a_30_19   1
 UP BND1      a_30_26   1
 UP BND1      a_30_2    1
 UP BND1      a_30_17   1
 UP BND1      a_35_31   1
 UP BND1      a_35_32   1
 UP BND1      a_35_19   1
 UP BND1      a_35_26   1
 UP BND1      a_35_2    1
 UP BND1      a_35_17   1
 UP BND1      a_31_32   1
 UP BND1      a_31_19   1
 UP BND1      a_31_26   1
 UP BND1      a_31_2    1
 UP BND1      a_31_17   1
 UP BND1      a_32_19   1
 UP BND1      a_32_26   1
 UP BND1      a_32_2    1
 UP BND1      a_32_17   1
 UP BND1      a_19_26   1
 UP BND1      a_19_2    1
 UP BND1      a_19_17   1
 UP BND1      a_26_2    1
 UP BND1      a_26_17   1
 UP BND1      a_2_17    1
 BV BND1      service_0_30_0
 BV BND1      service_0_30_1
 BV BND1      service_0_30_2
 BV BND1      service_0_30_3
 BV BND1      service_0_30_4
 BV BND1      service_0_30_6
 BV BND1      service_0_30_7
 BV BND1      service_0_30_8
 BV BND1      service_1_30_0
 BV BND1      service_1_30_1
 BV BND1      service_1_30_2
 BV BND1      service_1_30_3
 BV BND1      service_1_30_4
 BV BND1      service_1_30_6
 BV BND1      service_1_30_7
 BV BND1      service_1_30_8
 BV BND1      service_2_30_0
 BV BND1      service_2_30_1
 BV BND1      service_2_30_2
 BV BND1      service_2_30_3
 BV BND1      service_2_30_4
 BV BND1      service_2_30_6
 BV BND1      service_2_30_7
 BV BND1      service_2_30_8
 BV BND1      service_0_35_0
 BV BND1      service_0_35_1
 BV BND1      service_0_35_2
 BV BND1      service_0_35_3
 BV BND1      service_0_35_4
 BV BND1      service_0_35_5
 BV BND1      service_0_35_6
 BV BND1      service_0_35_7
 BV BND1      service_0_35_8
 BV BND1      service_0_35_9
 BV BND1      service_0_35_10
 BV BND1      service_0_35_12
 BV BND1      service_0_35_13
 BV BND1      service_0_35_14
 BV BND1      service_0_35_15
 BV BND1      service_1_35_0
 BV BND1      service_1_35_1
 BV BND1      service_1_35_2
 BV BND1      service_1_35_3
 BV BND1      service_1_35_4
 BV BND1      service_1_35_5
 BV BND1      service_1_35_6
 BV BND1      service_1_35_7
 BV BND1      service_1_35_8
 BV BND1      service_1_35_9
 BV BND1      service_1_35_10
 BV BND1      service_1_35_12
 BV BND1      service_1_35_13
 BV BND1      service_1_35_14
 BV BND1      service_1_35_15
 BV BND1      service_2_35_0
 BV BND1      service_2_35_1
 BV BND1      service_2_35_2
 BV BND1      service_2_35_3
 BV BND1      service_2_35_4
 BV BND1      service_2_35_5
 BV BND1      service_2_35_6
 BV BND1      service_2_35_7
 BV BND1      service_2_35_8
 BV BND1      service_2_35_9
 BV BND1      service_2_35_10
 BV BND1      service_2_35_12
 BV BND1      service_2_35_13
 BV BND1      service_2_35_14
 BV BND1      service_2_35_15
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_2_19_1
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 BV BND1      service_0_26_1
 BV BND1      service_0_26_2
 BV BND1      service_0_26_3
 BV BND1      service_0_26_4
 BV BND1      service_0_26_5
 BV BND1      service_0_26_6
 BV BND1      service_0_26_7
 BV BND1      service_0_26_8
 BV BND1      service_1_26_1
 BV BND1      service_1_26_2
 BV BND1      service_1_26_3
 BV BND1      service_1_26_4
 BV BND1      service_1_26_5
 BV BND1      service_1_26_6
 BV BND1      service_1_26_7
 BV BND1      service_1_26_8
 BV BND1      service_2_26_1
 BV BND1      service_2_26_2
 BV BND1      service_2_26_3
 BV BND1      service_2_26_4
 BV BND1      service_2_26_5
 BV BND1      service_2_26_6
 BV BND1      service_2_26_7
 BV BND1      service_2_26_8
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_2_17_0
 BV BND1      service_2_17_1
 BV BND1      service_2_17_2
 BV BND1      service_2_17_4
 BV BND1      service_2_17_5
 BV BND1      service_2_17_6
 BV BND1      service_2_17_7
 BV BND1      service_2_17_8
 BV BND1      service_2_17_9
 BV BND1      service_2_17_10
 BV BND1      service_2_17_11
 BV BND1      service_2_17_12
 BV BND1      service_2_17_13
 BV BND1      service_2_17_14
 BV BND1      service_2_17_15
 BV BND1      service_2_17_16
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  14
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  14
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  14
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  14
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  14
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  14
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  14
 UP BND1      visit_0_22  1
 UP BND1      order_0_22  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_0_22
 FX BND1      load_0_0_22  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_1_22
 UP BND1      load_0_1_22  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_2_22
 UP BND1      load_0_2_22  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_3_22
 UP BND1      load_0_3_22  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_4_22
 UP BND1      load_0_4_22  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_5_22
 UP BND1      load_0_5_22  20
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  20
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  20
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  20
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  20
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  20
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  20
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  20
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  20
 BV BND1      arc_0_6_17
 UP BND1      load_0_6_17  20
 BV BND1      arc_0_6_18
 UP BND1      load_0_6_18  20
 BV BND1      arc_0_6_19
 UP BND1      load_0_6_19  20
 BV BND1      arc_0_6_20
 UP BND1      load_0_6_20  20
 BV BND1      arc_0_6_21
 UP BND1      load_0_6_21  20
 BV BND1      arc_0_6_22
 UP BND1      load_0_6_22  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_15_22
 UP BND1      load_0_15_22  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_16_22
 UP BND1      load_0_16_22  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_6
 UP BND1      load_0_17_6  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_17_22
 UP BND1      load_0_17_22  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_6
 UP BND1      load_0_18_6  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_18_22
 UP BND1      load_0_18_22  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_6
 UP BND1      load_0_19_6  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_19_22
 UP BND1      load_0_19_22  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_6
 UP BND1      load_0_20_6  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_20_22
 UP BND1      load_0_20_22  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_6
 UP BND1      load_0_21_6  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 BV BND1      arc_0_21_22
 UP BND1      load_0_21_22  20
 BV BND1      arc_0_22_0
 UP BND1      load_0_22_0  20
 BV BND1      arc_0_22_1
 UP BND1      load_0_22_1  20
 BV BND1      arc_0_22_2
 UP BND1      load_0_22_2  20
 BV BND1      arc_0_22_3
 UP BND1      load_0_22_3  20
 BV BND1      arc_0_22_4
 UP BND1      load_0_22_4  20
 BV BND1      arc_0_22_5
 UP BND1      load_0_22_5  20
 BV BND1      arc_0_22_6
 UP BND1      load_0_22_6  20
 BV BND1      arc_0_22_15
 UP BND1      load_0_22_15  20
 BV BND1      arc_0_22_16
 UP BND1      load_0_22_16  20
 BV BND1      arc_0_22_17
 UP BND1      load_0_22_17  20
 BV BND1      arc_0_22_18
 UP BND1      load_0_22_18  20
 BV BND1      arc_0_22_19
 UP BND1      load_0_22_19  20
 BV BND1      arc_0_22_20
 UP BND1      load_0_22_20  20
 BV BND1      arc_0_22_21
 UP BND1      load_0_22_21  20
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  12
 UP BND1      visit_1_22  1
 UP BND1      order_1_22  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_0_22
 FX BND1      load_1_0_22  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_7_22
 UP BND1      load_1_7_22  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_8_22
 UP BND1      load_1_8_22  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_9_22
 UP BND1      load_1_9_22  25
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  25
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  25
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  25
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  25
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  25
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  25
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  25
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  25
 BV BND1      arc_1_10_19
 UP BND1      load_1_10_19  25
 BV BND1      arc_1_10_20
 UP BND1      load_1_10_20  25
 BV BND1      arc_1_10_21
 UP BND1      load_1_10_21  25
 BV BND1      arc_1_10_22
 UP BND1      load_1_10_22  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_15_22
 UP BND1      load_1_15_22  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_16_22
 UP BND1      load_1_16_22  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_17_22
 UP BND1      load_1_17_22  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_18_22
 UP BND1      load_1_18_22  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_10
 UP BND1      load_1_19_10  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_19_22
 UP BND1      load_1_19_22  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_10
 UP BND1      load_1_20_10  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_20_22
 UP BND1      load_1_20_22  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_10
 UP BND1      load_1_21_10  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 BV BND1      arc_1_21_22
 UP BND1      load_1_21_22  25
 BV BND1      arc_1_22_0
 UP BND1      load_1_22_0  25
 BV BND1      arc_1_22_7
 UP BND1      load_1_22_7  25
 BV BND1      arc_1_22_8
 UP BND1      load_1_22_8  25
 BV BND1      arc_1_22_9
 UP BND1      load_1_22_9  25
 BV BND1      arc_1_22_10
 UP BND1      load_1_22_10  25
 BV BND1      arc_1_22_15
 UP BND1      load_1_22_15  25
 BV BND1      arc_1_22_16
 UP BND1      load_1_22_16  25
 BV BND1      arc_1_22_17
 UP BND1      load_1_22_17  25
 BV BND1      arc_1_22_18
 UP BND1      load_1_22_18  25
 BV BND1      arc_1_22_19
 UP BND1      load_1_22_19  25
 BV BND1      arc_1_22_20
 UP BND1      load_1_22_20  25
 BV BND1      arc_1_22_21
 UP BND1      load_1_22_21  25
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  12
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  12
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  12
 FX BND1      visit_2_14  1
 UP BND1      order_2_14  12
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  12
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  12
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  12
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  12
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  12
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  12
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  12
 UP BND1      visit_2_22  1
 UP BND1      order_2_22  12
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_0_22
 FX BND1      load_2_0_22  0
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_11_22
 UP BND1      load_2_11_22  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_12_22
 UP BND1      load_2_12_22  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_13_22
 UP BND1      load_2_13_22  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_14_22
 UP BND1      load_2_14_22  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_15_22
 UP BND1      load_2_15_22  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_16_22
 UP BND1      load_2_16_22  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_17_22
 UP BND1      load_2_17_22  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_18_22
 UP BND1      load_2_18_22  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_19_22
 UP BND1      load_2_19_22  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_20_22
 UP BND1      load_2_20_22  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
 BV BND1      arc_2_21_22
 UP BND1      load_2_21_22  30
 BV BND1      arc_2_22_0
 UP BND1      load_2_22_0  30
 BV BND1      arc_2_22_11
 UP BND1      load_2_22_11  30
 BV BND1      arc_2_22_12
 UP BND1      load_2_22_12  30
 BV BND1      arc_2_22_13
 UP BND1      load_2_22_13  30
 BV BND1      arc_2_22_14
 UP BND1      load_2_22_14  30
 BV BND1      arc_2_22_15
 UP BND1      load_2_22_15  30
 BV BND1      arc_2_22_16
 UP BND1      load_2_22_16  30
 BV BND1      arc_2_22_17
 UP BND1      load_2_22_17  30
 BV BND1      arc_2_22_18
 UP BND1      load_2_22_18  30
 BV BND1      arc_2_22_19
 UP BND1      load_2_22_19  30
 BV BND1      arc_2_22_20
 UP BND1      load_2_22_20  30
 BV BND1      arc_2_22_21
 UP BND1      load_2_22_21  30
ENDATA
