* Signature: 0x8cc5903eff6b58d0
NAME 
OBJSENSE MAX
ROWS
 N  OBJ
 L  column_0
 L  column_1
 L  column_2
 L  column_3
 L  column_4
 L  column_5
 L  column_6
 L  column_7
 L  column_8
 L  column_9
 L  column_10
COLUMNS
    psi[1,11]  OBJ       1
    psi[1,11]  column_0  1
    psi[1,11]  column_1  1
    psi[1,11]  column_2  1
    psi[1,11]  column_3  1
    psi[1,11]  column_4  1
    psi[1,11]  column_5  1
    psi[1,11]  column_6  1
    psi[1,11]  column_7  1
    psi[1,11]  column_8  1
    psi[1,11]  column_9  1
    psi[1,11]  column_10  1
    psi[2,14]  OBJ       1
    psi[2,14]  column_0  1
    psi[2,14]  column_1  1
    psi[2,14]  column_2  1
    psi[2,14]  column_3  1
    psi[2,14]  column_4  1
    psi[2,14]  column_5  1
    psi[2,14]  column_6  1
    psi[2,14]  column_7  1
    psi[2,14]  column_8  1
    psi[2,14]  column_9  1
    psi[2,14]  column_10  1
    psi[3,15]  OBJ       9.9784836060869320e-01
    psi[3,15]  column_0  1
    psi[3,15]  column_1  1
    psi[3,15]  column_2  1
    psi[3,15]  column_3  1
    psi[3,15]  column_4  1
    psi[3,15]  column_5  1
    psi[3,15]  column_6  1
    psi[3,15]  column_7  1
    psi[3,15]  column_8  1
    psi[3,15]  column_9  1
    psi[3,24]  OBJ       2.1516393913068037e-03
    psi[3,24]  column_10  1
    psi[4,11]  OBJ       1
    psi[4,11]  column_0  1
    psi[4,11]  column_1  1
    psi[4,11]  column_2  1
    psi[4,11]  column_3  1
    psi[4,11]  column_4  1
    psi[4,11]  column_5  1
    psi[4,11]  column_6  1
    psi[4,11]  column_7  1
    psi[4,11]  column_8  1
    psi[4,11]  column_9  1
    psi[4,11]  column_10  1
    psi[5,11]  OBJ       0.619140848113076
    psi[5,11]  column_0  1
    psi[5,11]  column_1  1
    psi[5,11]  column_2  1
    psi[5,11]  column_3  1
    psi[5,11]  column_4  1
    psi[5,11]  column_10  1
    psi[5,18]  OBJ       3.8085915188692393e-01
    psi[5,18]  column_5  1
    psi[5,18]  column_6  1
    psi[5,18]  column_7  1
    psi[5,18]  column_8  1
    psi[5,18]  column_9  1
    psi[6,11]  OBJ       6.0545944245203920e-01
    psi[6,11]  column_0  1
    psi[6,11]  column_1  1
    psi[6,11]  column_2  1
    psi[6,11]  column_5  1
    psi[6,11]  column_6  1
    psi[6,11]  column_7  1
    psi[6,11]  column_8  1
    psi[6,12]  OBJ       1.1060636934039732e-01
    psi[6,12]  column_9  1
    psi[6,12]  column_10  1
    psi[6,20]  OBJ       2.8393418820756344e-01
    psi[6,20]  column_3  1
    psi[6,20]  column_4  1
    psi[7,10]  OBJ       1
    psi[7,10]  column_0  1
    psi[7,10]  column_1  1
    psi[7,10]  column_2  1
    psi[7,10]  column_3  1
    psi[7,10]  column_4  1
    psi[7,10]  column_5  1
    psi[7,10]  column_6  1
    psi[7,10]  column_7  1
    psi[7,10]  column_8  1
    psi[7,10]  column_9  1
    psi[7,10]  column_10  1
    psi[8,11]  OBJ       1
    psi[8,11]  column_0  1
    psi[8,11]  column_1  1
    psi[8,11]  column_2  1
    psi[8,11]  column_3  1
    psi[8,11]  column_4  1
    psi[8,11]  column_5  1
    psi[8,11]  column_6  1
    psi[8,11]  column_7  1
    psi[8,11]  column_8  1
    psi[8,11]  column_9  1
    psi[8,11]  column_10  1
    psi[9,9]  OBJ       1
    psi[9,9]  column_0  1
    psi[9,9]  column_1  1
    psi[9,9]  column_2  1
    psi[9,9]  column_3  1
    psi[9,9]  column_4  1
    psi[9,9]  column_5  1
    psi[9,9]  column_6  1
    psi[9,9]  column_7  1
    psi[9,9]  column_8  1
    psi[9,9]  column_9  1
    psi[9,9]  column_10  1
    psi[10,16]  OBJ       1
    psi[10,16]  column_0  1
    psi[10,16]  column_1  1
    psi[10,16]  column_2  1
    psi[10,16]  column_3  1
    psi[10,16]  column_4  1
    psi[10,16]  column_5  1
    psi[10,16]  column_6  1
    psi[10,16]  column_7  1
    psi[10,16]  column_8  1
    psi[10,16]  column_9  1
    psi[10,16]  column_10  1
    psi[11,17]  OBJ       1
    psi[11,17]  column_0  1
    psi[11,17]  column_1  1
    psi[11,17]  column_2  1
    psi[11,17]  column_3  1
    psi[11,17]  column_4  1
    psi[11,17]  column_5  1
    psi[11,17]  column_6  1
    psi[11,17]  column_7  1
    psi[11,17]  column_8  1
    psi[11,17]  column_9  1
    psi[11,17]  column_10  1
    psi[12,10]  OBJ       6.9704385645358324e-01
    psi[12,10]  column_0  1
    psi[12,10]  column_1  1
    psi[12,10]  column_2  1
    psi[12,10]  column_3  1
    psi[12,10]  column_5  1
    psi[12,10]  column_6  1
    psi[12,10]  column_7  1
    psi[12,18]  OBJ       3.0295614354641676e-01
    psi[12,18]  column_4  1
    psi[12,18]  column_8  1
    psi[12,18]  column_9  1
    psi[12,18]  column_10  1
    psi[13,13]  OBJ       1
    psi[13,13]  column_0  1
    psi[13,13]  column_1  1
    psi[13,13]  column_2  1
    psi[13,13]  column_3  1
    psi[13,13]  column_4  1
    psi[13,13]  column_5  1
    psi[13,13]  column_6  1
    psi[13,13]  column_7  1
    psi[13,13]  column_8  1
    psi[13,13]  column_9  1
    psi[13,13]  column_10  1
    psi[14,13]  OBJ       1
    psi[14,13]  column_0  1
    psi[14,13]  column_1  1
    psi[14,13]  column_2  1
    psi[14,13]  column_3  1
    psi[14,13]  column_4  1
    psi[14,13]  column_5  1
    psi[14,13]  column_6  1
    psi[14,13]  column_7  1
    psi[14,13]  column_8  1
    psi[14,13]  column_9  1
    psi[14,13]  column_10  1
    psi[15,14]  OBJ       1
    psi[15,14]  column_0  1
    psi[15,14]  column_1  1
    psi[15,14]  column_2  1
    psi[15,14]  column_3  1
    psi[15,14]  column_4  1
    psi[15,14]  column_5  1
    psi[15,14]  column_6  1
    psi[15,14]  column_7  1
    psi[15,14]  column_8  1
    psi[15,14]  column_9  1
    psi[15,14]  column_10  1
    psi[16,12]  OBJ       6.7684678021715539e-01
    psi[16,12]  column_0  1
    psi[16,12]  column_1  1
    psi[16,12]  column_3  1
    psi[16,12]  column_5  1
    psi[16,12]  column_6  1
    psi[16,12]  column_7  1
    psi[16,12]  column_8  1
    psi[16,21]  OBJ       3.2315321978284456e-01
    psi[16,21]  column_2  1
    psi[16,21]  column_4  1
    psi[16,21]  column_9  1
    psi[16,21]  column_10  1
    psi[17,8]  OBJ       7.5763508516286659e-01
    psi[17,8]  column_0  1
    psi[17,8]  column_1  1
    psi[17,8]  column_2  1
    psi[17,8]  column_3  1
    psi[17,8]  column_4  1
    psi[17,8]  column_8  1
    psi[17,8]  column_9  1
    psi[17,8]  column_10  1
    psi[17,16]  OBJ       2.4236491483713341e-01
    psi[17,16]  column_5  1
    psi[17,16]  column_6  1
    psi[17,16]  column_7  1
    psi[18,11]  OBJ       7.0377621519905909e-01
    psi[18,11]  column_0  1
    psi[18,11]  column_4  1
    psi[18,11]  column_5  1
    psi[18,11]  column_6  1
    psi[18,11]  column_9  1
    psi[18,11]  column_10  1
    psi[18,20]  OBJ       2.9622378480094091e-01
    psi[18,20]  column_1  1
    psi[18,20]  column_2  1
    psi[18,20]  column_3  1
    psi[18,20]  column_7  1
    psi[18,20]  column_8  1
    psi[19,12]  OBJ       6.3645262774429989e-01
    psi[19,12]  column_0  1
    psi[19,12]  column_4  1
    psi[19,12]  column_5  1
    psi[19,12]  column_7  1
    psi[19,12]  column_8  1
    psi[19,12]  column_9  1
    psi[19,12]  column_10  1
    psi[19,20]  OBJ       3.6354737225570011e-01
    psi[19,20]  column_1  1
    psi[19,20]  column_2  1
    psi[19,20]  column_3  1
    psi[19,20]  column_6  1
    psi[20,13]  OBJ       6.0615701338965833e-01
    psi[20,13]  column_2  1
    psi[20,13]  column_3  1
    psi[20,13]  column_4  1
    psi[20,13]  column_6  1
    psi[20,13]  column_7  1
    psi[20,13]  column_8  1
    psi[20,13]  column_9  1
    psi[20,13]  column_10  1
    psi[20,21]  OBJ       3.9384298661034167e-01
    psi[20,21]  column_0  1
    psi[20,21]  column_1  1
    psi[20,21]  column_5  1
    a         OBJ       1
    a         column_0  1
    a         column_1  1
    a         column_2  1
    a         column_3  1
    a         column_4  1
    a         column_5  1
    a         column_6  1
    a         column_7  1
    a         column_8  1
    a         column_9  1
    a         column_10  1
RHS
    RHS1      column_0  2.8358208955223906e-02
    RHS1      column_1  8.1694968885138719e-02
    RHS1      column_2  8.6115843270868839e-02
    RHS1      column_3  8.8451086956521763e-02
    RHS1      column_4  9.0296687665108746e-02
    RHS1      column_5  0.0877435575109994
    RHS1      column_6  0.0894021739130435
    RHS1      column_7  9.4534412955465608e-02
    RHS1      column_8  8.6928104575163423e-02
    RHS1      column_9  8.6808814527647438e-02
    RHS1      column_10  8.5724504394032314e-02
BOUNDS
 FX BND1      psi[1,11]  0
 FX BND1      psi[2,14]  0
 FX BND1      psi[3,15]  0
 LO BND1      psi[3,24]  -0.05
 UP BND1      psi[3,24]  0.05
 FX BND1      psi[4,11]  0
 FX BND1      psi[5,11]  0
 LO BND1      psi[5,18]  -0.05
 UP BND1      psi[5,18]  0.05
 FX BND1      psi[6,11]  0
 LO BND1      psi[6,12]  -0.05
 UP BND1      psi[6,12]  0.05
 LO BND1      psi[6,20]  -0.05
 UP BND1      psi[6,20]  0.05
 FX BND1      psi[7,10]  0
 FX BND1      psi[8,11]  0
 FX BND1      psi[9,9]  0
 FX BND1      psi[10,16]  0
 FX BND1      psi[11,17]  0
 FX BND1      psi[12,10]  0
 LO BND1      psi[12,18]  -0.05
 UP BND1      psi[12,18]  0.05
 FX BND1      psi[13,13]  0
 FX BND1      psi[14,13]  0
 FX BND1      psi[15,14]  0
 FX BND1      psi[16,12]  0
 LO BND1      psi[16,21]  -0.05
 UP BND1      psi[16,21]  0.05
 FX BND1      psi[17,8]  0
 LO BND1      psi[17,16]  -0.05
 UP BND1      psi[17,16]  0.05
 FX BND1      psi[18,11]  0
 LO BND1      psi[18,20]  -0.05
 UP BND1      psi[18,20]  0.05
 FX BND1      psi[19,12]  0
 LO BND1      psi[19,20]  -0.05
 UP BND1      psi[19,20]  0.05
 FX BND1      psi[20,13]  0
 LO BND1      psi[20,21]  -0.05
 UP BND1      psi[20,21]  0.05
 FR BND1      a       
ENDATA
