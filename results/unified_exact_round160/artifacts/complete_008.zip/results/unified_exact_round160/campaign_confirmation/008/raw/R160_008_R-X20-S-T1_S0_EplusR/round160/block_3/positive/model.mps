* Signature: 0x4bfe2273928a3c60
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_11_32
 E  normalized_mass_11_33
 E  normalized_ratio_11_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 E  onehot_10_39
 E  normalized_mass_10_40
 E  normalized_ratio_10_41
 G  product_lb_42
 L  product_ub_43
 G  product_lb_44
 L  product_ub_45
 G  product_lb_46
 L  product_ub_47
 G  product_lb_48
 L  product_ub_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 E  onehot_18_74
 E  normalized_mass_18_75
 E  normalized_ratio_18_76
 G  product_lb_77
 L  product_ub_78
 G  product_lb_79
 L  product_ub_80
 E  onehot_9_81
 E  normalized_mass_9_82
 E  normalized_ratio_9_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 G  product_lb_108
 L  product_ub_109
 G  product_lb_110
 L  product_ub_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 E  onehot_17_118
 E  normalized_mass_17_119
 E  normalized_ratio_17_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 E  onehot_7_143
 E  normalized_mass_7_144
 E  normalized_ratio_7_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 E  onehot_20_178
 E  normalized_mass_20_179
 E  normalized_ratio_20_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 E  onehot_6_185
 E  normalized_mass_6_186
 E  normalized_ratio_6_187
 G  stock_lb_188
 L  stock_ub_189
 L  parent_nonstrict_scope_190
 G  block_pair_pos_191
 G  block_pair_neg_192
 G  block_pair_pos_193
 G  block_pair_neg_194
 G  block_pair_pos_195
 G  block_pair_neg_196
 G  block_pair_pos_197
 G  block_pair_neg_198
 G  block_pair_pos_199
 G  block_pair_neg_200
 G  block_pair_pos_201
 G  block_pair_neg_202
 G  block_pair_pos_203
 G  block_pair_neg_204
 G  block_pair_pos_205
 G  block_pair_neg_206
 G  block_pair_pos_207
 G  block_pair_neg_208
 G  block_pair_pos_209
 G  block_pair_neg_210
 G  block_pair_pos_211
 G  block_pair_neg_212
 G  block_pair_pos_213
 G  block_pair_neg_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 E  normalization_247
 G  full_original_Gini_248
 E  unique_nonzero_owner_249
 E  unique_nonzero_owner_250
 E  unique_nonzero_owner_251
 E  unique_nonzero_owner_252
 E  unique_nonzero_owner_253
 E  unique_nonzero_owner_254
 E  unique_nonzero_owner_255
 E  unique_nonzero_owner_256
 E  unique_nonzero_owner_257
 E  unique_nonzero_owner_258
 E  unique_nonzero_owner_259
 E  unique_nonzero_owner_260
 E  unique_nonzero_owner_261
 E  unique_nonzero_owner_262
 E  unique_nonzero_owner_263
 E  unique_nonzero_owner_264
 E  unique_nonzero_owner_265
 E  unique_nonzero_owner_266
 E  unique_nonzero_owner_267
 E  unique_nonzero_owner_268
 E  unique_nonzero_owner_269
 E  unique_nonzero_owner_270
 E  unique_nonzero_owner_271
 E  unique_nonzero_owner_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 L  arc_capacity_323
 L  arc_capacity_324
 L  arc_capacity_325
 L  arc_capacity_326
 L  arc_capacity_327
 L  arc_capacity_328
 L  arc_capacity_329
 L  arc_capacity_330
 L  arc_capacity_331
 L  arc_capacity_332
 L  arc_capacity_333
 L  arc_capacity_334
 L  arc_capacity_335
 L  arc_capacity_336
 L  arc_capacity_337
 L  arc_capacity_338
 G  connected_order_arc_339
 L  arc_capacity_340
 G  connected_order_arc_341
 L  arc_capacity_342
 G  connected_order_arc_343
 L  arc_capacity_344
 G  connected_order_arc_345
 L  arc_capacity_346
 G  connected_order_arc_347
 L  arc_capacity_348
 G  connected_order_arc_349
 L  arc_capacity_350
 G  connected_order_arc_351
 L  arc_capacity_352
 G  connected_order_arc_353
 L  arc_capacity_354
 G  connected_order_arc_355
 L  arc_capacity_356
 G  connected_order_arc_357
 L  arc_capacity_358
 G  connected_order_arc_359
 L  arc_capacity_360
 G  connected_order_arc_361
 L  arc_capacity_362
 L  arc_capacity_363
 G  connected_order_arc_364
 L  arc_capacity_365
 G  connected_order_arc_366
 L  arc_capacity_367
 G  connected_order_arc_368
 L  arc_capacity_369
 G  connected_order_arc_370
 L  arc_capacity_371
 G  connected_order_arc_372
 L  arc_capacity_373
 G  connected_order_arc_374
 L  arc_capacity_375
 G  connected_order_arc_376
 L  arc_capacity_377
 G  connected_order_arc_378
 L  arc_capacity_379
 G  connected_order_arc_380
 L  arc_capacity_381
 G  connected_order_arc_382
 L  arc_capacity_383
 G  connected_order_arc_384
 L  arc_capacity_385
 G  connected_order_arc_386
 L  arc_capacity_387
 L  arc_capacity_388
 G  connected_order_arc_389
 L  arc_capacity_390
 G  connected_order_arc_391
 L  arc_capacity_392
 G  connected_order_arc_393
 L  arc_capacity_394
 G  connected_order_arc_395
 L  arc_capacity_396
 G  connected_order_arc_397
 L  arc_capacity_398
 G  connected_order_arc_399
 L  arc_capacity_400
 G  connected_order_arc_401
 L  arc_capacity_402
 G  connected_order_arc_403
 L  arc_capacity_404
 G  connected_order_arc_405
 L  arc_capacity_406
 G  connected_order_arc_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 L  arc_capacity_413
 G  connected_order_arc_414
 L  arc_capacity_415
 G  connected_order_arc_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 G  connected_order_arc_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 E  depot_departure_or_bypass_662
 E  depot_return_or_bypass_663
 E  out_degree_664
 E  in_degree_665
 G  order_active_lb_666
 L  order_active_ub_667
 E  segment_load_conservation_668
 G  segment_prefix_lb_669
 L  segment_prefix_ub_670
 E  out_degree_671
 E  in_degree_672
 G  order_active_lb_673
 L  order_active_ub_674
 E  segment_load_conservation_675
 G  segment_prefix_lb_676
 L  segment_prefix_ub_677
 E  out_degree_678
 E  in_degree_679
 G  order_active_lb_680
 L  order_active_ub_681
 E  segment_load_conservation_682
 G  segment_prefix_lb_683
 L  segment_prefix_ub_684
 E  out_degree_685
 E  in_degree_686
 G  order_active_lb_687
 L  order_active_ub_688
 E  segment_load_conservation_689
 G  segment_prefix_lb_690
 L  segment_prefix_ub_691
 E  out_degree_692
 E  in_degree_693
 G  order_active_lb_694
 L  order_active_ub_695
 E  segment_load_conservation_696
 G  segment_prefix_lb_697
 L  segment_prefix_ub_698
 E  out_degree_699
 E  in_degree_700
 G  order_active_lb_701
 L  order_active_ub_702
 E  service_visit_def_703
 E  free_load_conservation_704
 E  out_degree_705
 E  in_degree_706
 G  order_active_lb_707
 L  order_active_ub_708
 E  service_visit_def_709
 E  free_load_conservation_710
 E  out_degree_711
 E  in_degree_712
 G  order_active_lb_713
 L  order_active_ub_714
 E  service_visit_def_715
 E  free_load_conservation_716
 E  out_degree_717
 E  in_degree_718
 G  order_active_lb_719
 L  order_active_ub_720
 E  service_visit_def_721
 E  free_load_conservation_722
 E  out_degree_723
 E  in_degree_724
 G  order_active_lb_725
 L  order_active_ub_726
 E  service_visit_def_727
 E  free_load_conservation_728
 E  out_degree_729
 E  in_degree_730
 G  order_active_lb_731
 L  order_active_ub_732
 E  service_visit_def_733
 E  free_load_conservation_734
 E  out_degree_735
 E  in_degree_736
 G  order_active_lb_737
 L  order_active_ub_738
 E  service_visit_def_739
 E  free_load_conservation_740
 E  out_degree_741
 E  in_degree_742
 G  order_active_lb_743
 L  order_active_ub_744
 E  service_visit_def_745
 E  free_load_conservation_746
 G  fixed_segment_relative_order_747
 G  fixed_segment_relative_order_748
 G  fixed_segment_relative_order_749
 G  fixed_segment_relative_order_750
 L  original_T_including_depot_unload_751
 L  arc_capacity_752
 L  arc_capacity_753
 L  arc_capacity_754
 L  arc_capacity_755
 L  arc_capacity_756
 L  arc_capacity_757
 L  arc_capacity_758
 L  arc_capacity_759
 L  arc_capacity_760
 L  arc_capacity_761
 L  arc_capacity_762
 L  arc_capacity_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 L  arc_capacity_768
 G  connected_order_arc_769
 L  arc_capacity_770
 G  connected_order_arc_771
 L  arc_capacity_772
 G  connected_order_arc_773
 L  arc_capacity_774
 G  connected_order_arc_775
 L  arc_capacity_776
 G  connected_order_arc_777
 L  arc_capacity_778
 G  connected_order_arc_779
 L  arc_capacity_780
 G  connected_order_arc_781
 L  arc_capacity_782
 L  arc_capacity_783
 G  connected_order_arc_784
 L  arc_capacity_785
 G  connected_order_arc_786
 L  arc_capacity_787
 G  connected_order_arc_788
 L  arc_capacity_789
 G  connected_order_arc_790
 L  arc_capacity_791
 G  connected_order_arc_792
 L  arc_capacity_793
 G  connected_order_arc_794
 L  arc_capacity_795
 G  connected_order_arc_796
 L  arc_capacity_797
 G  connected_order_arc_798
 L  arc_capacity_799
 G  connected_order_arc_800
 L  arc_capacity_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 G  connected_order_arc_807
 L  arc_capacity_808
 G  connected_order_arc_809
 L  arc_capacity_810
 G  connected_order_arc_811
 L  arc_capacity_812
 G  connected_order_arc_813
 L  arc_capacity_814
 G  connected_order_arc_815
 L  arc_capacity_816
 G  connected_order_arc_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 G  connected_order_arc_836
 L  arc_capacity_837
 G  connected_order_arc_838
 L  arc_capacity_839
 L  arc_capacity_840
 G  connected_order_arc_841
 L  arc_capacity_842
 G  connected_order_arc_843
 L  arc_capacity_844
 G  connected_order_arc_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 G  connected_order_arc_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 E  depot_departure_or_bypass_953
 E  depot_return_or_bypass_954
 E  out_degree_955
 E  in_degree_956
 G  order_active_lb_957
 L  order_active_ub_958
 E  segment_load_conservation_959
 G  segment_prefix_lb_960
 L  segment_prefix_ub_961
 E  out_degree_962
 E  in_degree_963
 G  order_active_lb_964
 L  order_active_ub_965
 E  segment_load_conservation_966
 G  segment_prefix_lb_967
 L  segment_prefix_ub_968
 E  out_degree_969
 E  in_degree_970
 G  order_active_lb_971
 L  order_active_ub_972
 E  service_visit_def_973
 E  free_load_conservation_974
 E  out_degree_975
 E  in_degree_976
 G  order_active_lb_977
 L  order_active_ub_978
 E  service_visit_def_979
 E  free_load_conservation_980
 E  out_degree_981
 E  in_degree_982
 G  order_active_lb_983
 L  order_active_ub_984
 E  service_visit_def_985
 E  free_load_conservation_986
 E  out_degree_987
 E  in_degree_988
 G  order_active_lb_989
 L  order_active_ub_990
 E  service_visit_def_991
 E  free_load_conservation_992
 E  out_degree_993
 E  in_degree_994
 G  order_active_lb_995
 L  order_active_ub_996
 E  service_visit_def_997
 E  free_load_conservation_998
 E  out_degree_999
 E  in_degree_1000
 G  order_active_lb_1001
 L  order_active_ub_1002
 E  service_visit_def_1003
 E  free_load_conservation_1004
 E  out_degree_1005
 E  in_degree_1006
 G  order_active_lb_1007
 L  order_active_ub_1008
 E  service_visit_def_1009
 E  free_load_conservation_1010
 E  out_degree_1011
 E  in_degree_1012
 G  order_active_lb_1013
 L  order_active_ub_1014
 E  service_visit_def_1015
 E  free_load_conservation_1016
 G  fixed_segment_relative_order_1017
 L  original_T_including_depot_unload_1018
COLUMNS
    t         normalized_mass_11_33  -1
    t         normalized_mass_10_40  -1
    t         normalized_mass_18_75  -1
    t         normalized_mass_9_82  -1
    t         normalized_mass_17_119  -1
    t         normalized_mass_7_144  -1
    t         normalized_mass_20_179  -1
    t         normalized_mass_6_186  -1
    t         normalization_247  7.8392857142857135e+00
    t         full_original_Gini_248  -3.5982142857142854e+01
    q         OBJ       1
    q         parent_nonstrict_scope_190  1
    q         full_original_Gini_248  20
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       5.0078236648368350e-02
    x_11_0    product_lb_0  -0.0487568927154393
    x_11_0    product_ub_1  -1.2756264236914810e-01
    x_11_0    onehot_11_32  1
    x_11_0    parent_nonstrict_scope_190  1.0015647329673670e-01
    x_11_0    unique_nonzero_owner_249  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_0  1
    w_11_0    product_ub_1  1
    w_11_0    normalized_mass_11_33  1
    w_11_0    full_original_Gini_248  -7.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7558677486276261e-02
    x_11_1    product_lb_2  -0.0487568927154393
    x_11_1    product_ub_3  -1.2756264236914810e-01
    x_11_1    onehot_11_32  1
    x_11_1    stock_lb_188  1
    x_11_1    stock_ub_189  1
    x_11_1    parent_nonstrict_scope_190  8.7636914134644611e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_2  1
    w_11_1    product_ub_3  1
    w_11_1    normalized_mass_11_33  1
    w_11_1    normalized_ratio_11_34  -0.125
    w_11_1    full_original_Gini_248  -7.3392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       2.5039118324184172e-02
    x_11_2    product_lb_4  -0.0487568927154393
    x_11_2    product_ub_5  -1.2756264236914810e-01
    x_11_2    onehot_11_32  1
    x_11_2    stock_lb_188  2
    x_11_2    stock_ub_189  2
    x_11_2    parent_nonstrict_scope_190  7.5117354972552522e-02
    x_11_2    unique_nonzero_owner_250  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_4  1
    w_11_2    product_ub_5  1
    w_11_2    normalized_mass_11_33  1
    w_11_2    normalized_ratio_11_34  -0.25
    w_11_2    full_original_Gini_248  -6.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       1.2519559162092082e-02
    x_11_3    product_lb_6  -0.0487568927154393
    x_11_3    product_ub_7  -1.2756264236914810e-01
    x_11_3    onehot_11_32  1
    x_11_3    stock_lb_188  3
    x_11_3    stock_ub_189  3
    x_11_3    parent_nonstrict_scope_190  6.2597795810460433e-02
    x_11_3    unique_nonzero_owner_251  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_6  1
    w_11_3    product_ub_7  1
    w_11_3    normalized_mass_11_33  1
    w_11_3    normalized_ratio_11_34  -0.375
    w_11_3    full_original_Gini_248  -6.3392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    product_lb_8  -0.0487568927154393
    x_11_4    product_ub_9  -1.2756264236914810e-01
    x_11_4    onehot_11_32  1
    x_11_4    stock_lb_188  4
    x_11_4    stock_ub_189  4
    x_11_4    parent_nonstrict_scope_190  5.0078236648368350e-02
    x_11_4    unique_nonzero_owner_252  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_8  1
    w_11_4    product_ub_9  1
    w_11_4    normalized_mass_11_33  1
    w_11_4    normalized_ratio_11_34  -0.5
    w_11_4    full_original_Gini_248  -5.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -1.2519559162092089e-02
    x_11_5    product_lb_10  -0.0487568927154393
    x_11_5    product_ub_11  -1.2756264236914810e-01
    x_11_5    onehot_11_32  1
    x_11_5    stock_lb_188  5
    x_11_5    stock_ub_189  5
    x_11_5    parent_nonstrict_scope_190  3.7558677486276261e-02
    x_11_5    unique_nonzero_owner_253  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_10  1
    w_11_5    product_ub_11  1
    w_11_5    normalized_mass_11_33  1
    w_11_5    normalized_ratio_11_34  -0.625
    w_11_5    full_original_Gini_248  -5.4464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -2.5039118324184175e-02
    x_11_6    product_lb_12  -0.0487568927154393
    x_11_6    product_ub_13  -1.2756264236914810e-01
    x_11_6    onehot_11_32  1
    x_11_6    stock_lb_188  6
    x_11_6    stock_ub_189  6
    x_11_6    parent_nonstrict_scope_190  2.5039118324184175e-02
    x_11_6    unique_nonzero_owner_254  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_12  1
    w_11_6    product_ub_13  1
    w_11_6    normalized_mass_11_33  1
    w_11_6    normalized_ratio_11_34  -0.75
    w_11_6    full_original_Gini_248  -5.1964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -3.7558677486276261e-02
    x_11_7    product_lb_14  -0.0487568927154393
    x_11_7    product_ub_15  -1.2756264236914810e-01
    x_11_7    onehot_11_32  1
    x_11_7    stock_lb_188  7
    x_11_7    stock_ub_189  7
    x_11_7    parent_nonstrict_scope_190  1.2519559162092088e-02
    x_11_7    unique_nonzero_owner_255  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_14  1
    w_11_7    product_ub_15  1
    w_11_7    normalized_mass_11_33  1
    w_11_7    normalized_ratio_11_34  -0.875
    w_11_7    full_original_Gini_248  -4.9464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -5.0078236648368350e-02
    x_11_8    product_lb_16  -0.0487568927154393
    x_11_8    product_ub_17  -1.2756264236914810e-01
    x_11_8    onehot_11_32  1
    x_11_8    stock_lb_188  8
    x_11_8    stock_ub_189  8
    x_11_8    unique_nonzero_owner_256  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_16  1
    w_11_8    product_ub_17  1
    w_11_8    normalized_mass_11_33  1
    w_11_8    normalized_ratio_11_34  -1
    w_11_8    full_original_Gini_248  -4.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       -3.7558677486276261e-02
    x_11_9    product_lb_18  -0.0487568927154393
    x_11_9    product_ub_19  -1.2756264236914810e-01
    x_11_9    onehot_11_32  1
    x_11_9    stock_lb_188  9
    x_11_9    stock_ub_189  9
    x_11_9    parent_nonstrict_scope_190  1.2519559162092088e-02
    x_11_9    unique_nonzero_owner_257  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_18  1
    w_11_9    product_ub_19  1
    w_11_9    normalized_mass_11_33  1
    w_11_9    normalized_ratio_11_34  -1.125
    w_11_9    full_original_Gini_248  -5.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       -2.5039118324184175e-02
    x_11_10   product_lb_20  -0.0487568927154393
    x_11_10   product_ub_21  -1.2756264236914810e-01
    x_11_10   onehot_11_32  1
    x_11_10   stock_lb_188  10
    x_11_10   stock_ub_189  10
    x_11_10   parent_nonstrict_scope_190  2.5039118324184175e-02
    x_11_10   unique_nonzero_owner_258  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_20  1
    w_11_10   product_ub_21  1
    w_11_10   normalized_mass_11_33  1
    w_11_10   normalized_ratio_11_34  -1.25
    w_11_10   full_original_Gini_248  -7.1607142857142865e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       -1.2519559162092089e-02
    x_11_11   product_lb_22  -0.0487568927154393
    x_11_11   product_ub_23  -1.2756264236914810e-01
    x_11_11   onehot_11_32  1
    x_11_11   stock_lb_188  11
    x_11_11   stock_ub_189  11
    x_11_11   parent_nonstrict_scope_190  3.7558677486276261e-02
    x_11_11   unique_nonzero_owner_259  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_22  1
    w_11_11   product_ub_23  1
    w_11_11   normalized_mass_11_33  1
    w_11_11   normalized_ratio_11_34  -1.375
    w_11_11   full_original_Gini_248  -8.6607142857142865e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_12   product_lb_24  -0.0487568927154393
    x_11_12   product_ub_25  -1.2756264236914810e-01
    x_11_12   onehot_11_32  1
    x_11_12   stock_lb_188  12
    x_11_12   stock_ub_189  12
    x_11_12   parent_nonstrict_scope_190  5.0078236648368350e-02
    x_11_12   unique_nonzero_owner_260  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_24  1
    w_11_12   product_ub_25  1
    w_11_12   normalized_mass_11_33  1
    w_11_12   normalized_ratio_11_34  -1.5
    w_11_12   full_original_Gini_248  -1.0160714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_13   OBJ       1.2519559162092082e-02
    x_11_13   product_lb_26  -0.0487568927154393
    x_11_13   product_ub_27  -1.2756264236914810e-01
    x_11_13   onehot_11_32  1
    x_11_13   stock_lb_188  13
    x_11_13   stock_ub_189  13
    x_11_13   parent_nonstrict_scope_190  6.2597795810460433e-02
    x_11_13   unique_nonzero_owner_261  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_13   product_lb_26  1
    w_11_13   product_ub_27  1
    w_11_13   normalized_mass_11_33  1
    w_11_13   normalized_ratio_11_34  -1.625
    w_11_13   full_original_Gini_248  -1.1660714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_14   OBJ       2.5039118324184172e-02
    x_11_14   product_lb_28  -0.0487568927154393
    x_11_14   product_ub_29  -1.2756264236914810e-01
    x_11_14   onehot_11_32  1
    x_11_14   stock_lb_188  14
    x_11_14   stock_ub_189  14
    x_11_14   parent_nonstrict_scope_190  7.5117354972552522e-02
    x_11_14   unique_nonzero_owner_262  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_14   product_lb_28  1
    w_11_14   product_ub_29  1
    w_11_14   normalized_mass_11_33  1
    w_11_14   normalized_ratio_11_34  -1.75
    w_11_14   full_original_Gini_248  -1.3160714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_15   OBJ       3.7558677486276261e-02
    x_11_15   product_lb_30  -0.0487568927154393
    x_11_15   product_ub_31  -1.2756264236914810e-01
    x_11_15   onehot_11_32  1
    x_11_15   stock_lb_188  15
    x_11_15   stock_ub_189  15
    x_11_15   parent_nonstrict_scope_190  8.7636914134644611e-02
    x_11_15   unique_nonzero_owner_263  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_15   product_lb_30  1
    w_11_15   product_ub_31  1
    w_11_15   normalized_mass_11_33  1
    w_11_15   normalized_ratio_11_34  -1.875
    w_11_15   full_original_Gini_248  -1.4660714285714286e+01
    rho_11    normalized_ratio_11_34  1
    rho_11    block_pair_pos_215  -1
    rho_11    block_pair_neg_216  1
    rho_11    block_pair_pos_217  -1
    rho_11    block_pair_neg_218  1
    rho_11    block_pair_pos_219  -1
    rho_11    block_pair_neg_220  1
    rho_11    block_pair_pos_221  -1
    rho_11    block_pair_neg_222  1
    rho_11    block_pair_pos_223  -1
    rho_11    block_pair_neg_224  1
    rho_11    block_pair_pos_225  -1
    rho_11    block_pair_neg_226  1
    rho_11    block_pair_pos_227  -1
    rho_11    block_pair_neg_228  1
    rho_11    normalization_247  1
    MARKER    'MARKER'                 'INTORG'
    x_10_0    OBJ       6.3380304899829966e-03
    x_10_0    product_lb_35  -0.0487568927154393
    x_10_0    product_ub_36  -1.2756264236914810e-01
    x_10_0    onehot_10_39  1
    x_10_0    parent_nonstrict_scope_190  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_10_0    product_lb_35  1
    w_10_0    product_ub_36  1
    w_10_0    normalized_mass_10_40  1
    w_10_0    full_original_Gini_248  -7.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_1    OBJ       -6.3380304899829966e-03
    x_10_1    product_lb_37  -0.0487568927154393
    x_10_1    product_ub_38  -1.2756264236914810e-01
    x_10_1    onehot_10_39  1
    x_10_1    stock_lb_188  1
    x_10_1    stock_ub_189  1
    x_10_1    unique_nonzero_owner_264  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_1    product_lb_37  1
    w_10_1    product_ub_38  1
    w_10_1    normalized_mass_10_40  1
    w_10_1    normalized_ratio_10_41  -1
    w_10_1    full_original_Gini_248  -4.6964285714285712e+00
    rho_10    normalized_ratio_10_41  1
    rho_10    block_pair_pos_203  -1
    rho_10    block_pair_neg_204  1
    rho_10    block_pair_pos_205  -1
    rho_10    block_pair_neg_206  1
    rho_10    block_pair_pos_207  -1
    rho_10    block_pair_neg_208  1
    rho_10    block_pair_pos_209  -1
    rho_10    block_pair_neg_210  1
    rho_10    block_pair_pos_211  -1
    rho_10    block_pair_neg_212  1
    rho_10    block_pair_pos_213  -1
    rho_10    block_pair_neg_214  1
    rho_10    block_pair_pos_221  1
    rho_10    block_pair_neg_222  -1
    rho_10    normalization_247  1
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       3.2863847044708572e-02
    x_18_0    product_lb_42  -0.0487568927154393
    x_18_0    product_ub_43  -1.2756264236914810e-01
    x_18_0    onehot_18_74  1
    x_18_0    parent_nonstrict_scope_190  7.6682309770986667e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_42  1
    w_18_0    product_ub_43  1
    w_18_0    normalized_mass_18_75  1
    w_18_0    full_original_Gini_248  -7.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       2.1909231363139048e-02
    x_18_1    product_lb_44  -0.0487568927154393
    x_18_1    product_ub_45  -1.2756264236914810e-01
    x_18_1    onehot_18_74  1
    x_18_1    stock_lb_188  1
    x_18_1    stock_ub_189  1
    x_18_1    parent_nonstrict_scope_190  6.5727694089417144e-02
    x_18_1    unique_nonzero_owner_265  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_44  1
    w_18_1    product_ub_45  1
    w_18_1    normalized_mass_18_75  1
    w_18_1    normalized_ratio_18_76  -1.4285714285714285e-01
    w_18_1    full_original_Gini_248  -7.2678571428571432e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       1.0954615681569524e-02
    x_18_2    product_lb_46  -0.0487568927154393
    x_18_2    product_ub_47  -1.2756264236914810e-01
    x_18_2    onehot_18_74  1
    x_18_2    stock_lb_188  2
    x_18_2    stock_ub_189  2
    x_18_2    parent_nonstrict_scope_190  5.4773078407847620e-02
    x_18_2    unique_nonzero_owner_266  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_46  1
    w_18_2    product_ub_47  1
    w_18_2    normalized_mass_18_75  1
    w_18_2    normalized_ratio_18_76  -2.8571428571428570e-01
    w_18_2    full_original_Gini_248  -6.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_3    product_lb_48  -0.0487568927154393
    x_18_3    product_ub_49  -1.2756264236914810e-01
    x_18_3    onehot_18_74  1
    x_18_3    stock_lb_188  3
    x_18_3    stock_ub_189  3
    x_18_3    parent_nonstrict_scope_190  4.3818462726278096e-02
    x_18_3    unique_nonzero_owner_267  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_48  1
    w_18_3    product_ub_49  1
    w_18_3    normalized_mass_18_75  1
    w_18_3    normalized_ratio_18_76  -4.2857142857142855e-01
    w_18_3    full_original_Gini_248  -6.1249999999999991e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       -1.0954615681569524e-02
    x_18_4    product_lb_50  -0.0487568927154393
    x_18_4    product_ub_51  -1.2756264236914810e-01
    x_18_4    onehot_18_74  1
    x_18_4    stock_lb_188  4
    x_18_4    stock_ub_189  4
    x_18_4    parent_nonstrict_scope_190  3.2863847044708572e-02
    x_18_4    unique_nonzero_owner_268  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_50  1
    w_18_4    product_ub_51  1
    w_18_4    normalized_mass_18_75  1
    w_18_4    normalized_ratio_18_76  -5.7142857142857140e-01
    w_18_4    full_original_Gini_248  -5.5535714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -2.1909231363139041e-02
    x_18_5    product_lb_52  -0.0487568927154393
    x_18_5    product_ub_53  -1.2756264236914810e-01
    x_18_5    onehot_18_74  1
    x_18_5    stock_lb_188  5
    x_18_5    stock_ub_189  5
    x_18_5    parent_nonstrict_scope_190  2.1909231363139055e-02
    x_18_5    unique_nonzero_owner_269  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_52  1
    w_18_5    product_ub_53  1
    w_18_5    normalized_mass_18_75  1
    w_18_5    normalized_ratio_18_76  -7.1428571428571419e-01
    w_18_5    full_original_Gini_248  -5.2678571428571432e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -3.2863847044708572e-02
    x_18_6    product_lb_54  -0.0487568927154393
    x_18_6    product_ub_55  -1.2756264236914810e-01
    x_18_6    onehot_18_74  1
    x_18_6    stock_lb_188  6
    x_18_6    stock_ub_189  6
    x_18_6    parent_nonstrict_scope_190  1.0954615681569527e-02
    x_18_6    unique_nonzero_owner_270  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_54  1
    w_18_6    product_ub_55  1
    w_18_6    normalized_mass_18_75  1
    w_18_6    normalized_ratio_18_76  -8.5714285714285710e-01
    w_18_6    full_original_Gini_248  -4.9821428571428568e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -4.3818462726278096e-02
    x_18_7    product_lb_56  -0.0487568927154393
    x_18_7    product_ub_57  -1.2756264236914810e-01
    x_18_7    onehot_18_74  1
    x_18_7    stock_lb_188  7
    x_18_7    stock_ub_189  7
    x_18_7    unique_nonzero_owner_271  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_56  1
    w_18_7    product_ub_57  1
    w_18_7    normalized_mass_18_75  1
    w_18_7    normalized_ratio_18_76  -1
    w_18_7    full_original_Gini_248  -4.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       -3.2863847044708579e-02
    x_18_8    product_lb_58  -0.0487568927154393
    x_18_8    product_ub_59  -1.2756264236914810e-01
    x_18_8    onehot_18_74  1
    x_18_8    stock_lb_188  8
    x_18_8    stock_ub_189  8
    x_18_8    parent_nonstrict_scope_190  1.0954615681569519e-02
    x_18_8    unique_nonzero_owner_272  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_58  1
    w_18_8    product_ub_59  1
    w_18_8    normalized_mass_18_75  1
    w_18_8    normalized_ratio_18_76  -1.1428571428571428e+00
    w_18_8    full_original_Gini_248  -5.8749999999999982e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       -2.1909231363139058e-02
    x_18_9    product_lb_60  -0.0487568927154393
    x_18_9    product_ub_61  -1.2756264236914810e-01
    x_18_9    onehot_18_74  1
    x_18_9    stock_lb_188  9
    x_18_9    stock_ub_189  9
    x_18_9    parent_nonstrict_scope_190  2.1909231363139037e-02
    x_18_9    unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_60  1
    w_18_9    product_ub_61  1
    w_18_9    normalized_mass_18_75  1
    w_18_9    normalized_ratio_18_76  -1.2857142857142856e+00
    w_18_9    full_original_Gini_248  -7.5892857142857126e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       -1.0954615681569538e-02
    x_18_10   product_lb_62  -0.0487568927154393
    x_18_10   product_ub_63  -1.2756264236914810e-01
    x_18_10   onehot_18_74  1
    x_18_10   stock_lb_188  10
    x_18_10   stock_ub_189  10
    x_18_10   parent_nonstrict_scope_190  3.2863847044708558e-02
    x_18_10   unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_62  1
    w_18_10   product_ub_63  1
    w_18_10   normalized_mass_18_75  1
    w_18_10   normalized_ratio_18_76  -1.4285714285714284e+00
    w_18_10   full_original_Gini_248  -9.3035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_11   product_lb_64  -0.0487568927154393
    x_18_11   product_ub_65  -1.2756264236914810e-01
    x_18_11   onehot_18_74  1
    x_18_11   stock_lb_188  11
    x_18_11   stock_ub_189  11
    x_18_11   parent_nonstrict_scope_190  4.3818462726278096e-02
    x_18_11   unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_11   product_lb_64  1
    w_18_11   product_ub_65  1
    w_18_11   normalized_mass_18_75  1
    w_18_11   normalized_ratio_18_76  -1.5714285714285714e+00
    w_18_11   full_original_Gini_248  -1.1017857142857141e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_12   OBJ       1.0954615681569517e-02
    x_18_12   product_lb_66  -0.0487568927154393
    x_18_12   product_ub_67  -1.2756264236914810e-01
    x_18_12   onehot_18_74  1
    x_18_12   stock_lb_188  12
    x_18_12   stock_ub_189  12
    x_18_12   parent_nonstrict_scope_190  5.4773078407847613e-02
    x_18_12   unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_12   product_lb_66  1
    w_18_12   product_ub_67  1
    w_18_12   normalized_mass_18_75  1
    w_18_12   normalized_ratio_18_76  -1.7142857142857142e+00
    w_18_12   full_original_Gini_248  -1.2732142857142854e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_13   OBJ       2.1909231363139034e-02
    x_18_13   product_lb_68  -0.0487568927154393
    x_18_13   product_ub_69  -1.2756264236914810e-01
    x_18_13   onehot_18_74  1
    x_18_13   stock_lb_188  13
    x_18_13   stock_ub_189  13
    x_18_13   parent_nonstrict_scope_190  6.5727694089417130e-02
    x_18_13   unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_13   product_lb_68  1
    w_18_13   product_ub_69  1
    w_18_13   normalized_mass_18_75  1
    w_18_13   normalized_ratio_18_76  -1.8571428571428570e+00
    w_18_13   full_original_Gini_248  -1.4446428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_14   OBJ       3.2863847044708572e-02
    x_18_14   product_lb_70  -0.0487568927154393
    x_18_14   product_ub_71  -1.2756264236914810e-01
    x_18_14   onehot_18_74  1
    x_18_14   stock_lb_188  14
    x_18_14   stock_ub_189  14
    x_18_14   parent_nonstrict_scope_190  7.6682309770986667e-02
    x_18_14   unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_14   product_lb_70  1
    w_18_14   product_ub_71  1
    w_18_14   normalized_mass_18_75  1
    w_18_14   normalized_ratio_18_76  -2
    w_18_14   full_original_Gini_248  -1.6160714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_15   OBJ       4.3818462726278096e-02
    x_18_15   product_lb_72  -0.0487568927154393
    x_18_15   product_ub_73  -1.2756264236914810e-01
    x_18_15   onehot_18_74  1
    x_18_15   stock_lb_188  15
    x_18_15   stock_ub_189  15
    x_18_15   parent_nonstrict_scope_190  8.7636925452556191e-02
    x_18_15   unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_15   product_lb_72  1
    w_18_15   product_ub_73  1
    w_18_15   normalized_mass_18_75  1
    w_18_15   normalized_ratio_18_76  -2.1428571428571428e+00
    w_18_15   full_original_Gini_248  -1.7874999999999996e+01
    rho_18    normalized_ratio_18_76  1
    rho_18    block_pair_pos_211  1
    rho_18    block_pair_neg_212  -1
    rho_18    block_pair_pos_225  1
    rho_18    block_pair_neg_226  -1
    rho_18    block_pair_pos_235  -1
    rho_18    block_pair_neg_236  1
    rho_18    block_pair_pos_237  -1
    rho_18    block_pair_neg_238  1
    rho_18    block_pair_pos_239  -1
    rho_18    block_pair_neg_240  1
    rho_18    block_pair_pos_241  -1
    rho_18    block_pair_neg_242  1
    rho_18    block_pair_pos_243  -1
    rho_18    block_pair_neg_244  1
    rho_18    normalization_247  1
    MARKER    'MARKER'                 'INTORG'
    x_9_0     OBJ       6.3380304899829966e-03
    x_9_0     product_lb_77  -0.0487568927154393
    x_9_0     product_ub_78  -1.2756264236914810e-01
    x_9_0     onehot_9_81  1
    x_9_0     parent_nonstrict_scope_190  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_9_0     product_lb_77  1
    w_9_0     product_ub_78  1
    w_9_0     normalized_mass_9_82  1
    w_9_0     full_original_Gini_248  -7.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_1     OBJ       -6.3380304899829966e-03
    x_9_1     product_lb_79  -0.0487568927154393
    x_9_1     product_ub_80  -1.2756264236914810e-01
    x_9_1     onehot_9_81  1
    x_9_1     stock_lb_188  1
    x_9_1     stock_ub_189  1
    x_9_1     unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_1     product_lb_79  1
    w_9_1     product_ub_80  1
    w_9_1     normalized_mass_9_82  1
    w_9_1     normalized_ratio_9_83  -1
    w_9_1     full_original_Gini_248  -4.6964285714285712e+00
    rho_9     normalized_ratio_9_83  1
    rho_9     block_pair_pos_195  -1
    rho_9     block_pair_neg_196  1
    rho_9     block_pair_pos_197  -1
    rho_9     block_pair_neg_198  1
    rho_9     block_pair_pos_199  -1
    rho_9     block_pair_neg_200  1
    rho_9     block_pair_pos_201  -1
    rho_9     block_pair_neg_202  1
    rho_9     block_pair_pos_207  1
    rho_9     block_pair_neg_208  -1
    rho_9     block_pair_pos_219  1
    rho_9     block_pair_neg_220  -1
    rho_9     block_pair_pos_239  1
    rho_9     block_pair_neg_240  -1
    rho_9     normalization_247  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       6.3380304899829959e-02
    x_17_0    product_lb_84  -0.0487568927154393
    x_17_0    product_ub_85  -1.2756264236914810e-01
    x_17_0    onehot_17_118  1
    x_17_0    parent_nonstrict_scope_190  1.2676060979965992e-01
    x_17_0    unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_84  1
    w_17_0    product_ub_85  1
    w_17_0    normalized_mass_17_119  1
    w_17_0    full_original_Gini_248  -7.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.9295792699867738e-02
    x_17_1    product_lb_86  -0.0487568927154393
    x_17_1    product_ub_87  -1.2756264236914810e-01
    x_17_1    onehot_17_118  1
    x_17_1    stock_lb_188  1
    x_17_1    stock_ub_189  1
    x_17_1    parent_nonstrict_scope_190  1.1267609759969770e-01
    x_17_1    unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_86  1
    w_17_1    product_ub_87  1
    w_17_1    normalized_mass_17_119  1
    w_17_1    normalized_ratio_17_120  -1.1111111111111110e-01
    w_17_1    full_original_Gini_248  -7.3948412698412689e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       3.5211280499905531e-02
    x_17_2    product_lb_88  -0.0487568927154393
    x_17_2    product_ub_89  -1.2756264236914810e-01
    x_17_2    onehot_17_118  1
    x_17_2    stock_lb_188  2
    x_17_2    stock_ub_189  2
    x_17_2    parent_nonstrict_scope_190  9.8591585399735490e-02
    x_17_2    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_88  1
    w_17_2    product_ub_89  1
    w_17_2    normalized_mass_17_119  1
    w_17_2    normalized_ratio_17_120  -2.2222222222222221e-01
    w_17_2    full_original_Gini_248  -6.9503968253968251e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.1126768299943324e-02
    x_17_3    product_lb_90  -0.0487568927154393
    x_17_3    product_ub_91  -1.2756264236914810e-01
    x_17_3    onehot_17_118  1
    x_17_3    stock_lb_188  3
    x_17_3    stock_ub_189  3
    x_17_3    parent_nonstrict_scope_190  8.4507073199773283e-02
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_90  1
    w_17_3    product_ub_91  1
    w_17_3    normalized_mass_17_119  1
    w_17_3    normalized_ratio_17_120  -3.3333333333333331e-01
    w_17_3    full_original_Gini_248  -6.5059523809523823e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       7.0422560999811035e-03
    x_17_4    product_lb_92  -0.0487568927154393
    x_17_4    product_ub_93  -1.2756264236914810e-01
    x_17_4    onehot_17_118  1
    x_17_4    stock_lb_188  4
    x_17_4    stock_ub_189  4
    x_17_4    parent_nonstrict_scope_190  7.0422560999811062e-02
    x_17_4    unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_92  1
    w_17_4    product_ub_93  1
    w_17_4    normalized_mass_17_119  1
    w_17_4    normalized_ratio_17_120  -4.4444444444444442e-01
    w_17_4    full_original_Gini_248  -6.0615079365079367e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -0.00704225609998111
    x_17_5    product_lb_94  -0.0487568927154393
    x_17_5    product_ub_95  -1.2756264236914810e-01
    x_17_5    onehot_17_118  1
    x_17_5    stock_lb_188  5
    x_17_5    stock_ub_189  5
    x_17_5    parent_nonstrict_scope_190  5.6338048799848849e-02
    x_17_5    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_94  1
    w_17_5    product_ub_95  1
    w_17_5    normalized_mass_17_119  1
    w_17_5    normalized_ratio_17_120  -5.5555555555555558e-01
    w_17_5    full_original_Gini_248  -5.6170634920634921e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.1126768299943317e-02
    x_17_6    product_lb_96  -0.0487568927154393
    x_17_6    product_ub_97  -1.2756264236914810e-01
    x_17_6    onehot_17_118  1
    x_17_6    stock_lb_188  6
    x_17_6    stock_ub_189  6
    x_17_6    parent_nonstrict_scope_190  4.2253536599886642e-02
    x_17_6    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_96  1
    w_17_6    product_ub_97  1
    w_17_6    normalized_mass_17_119  1
    w_17_6    normalized_ratio_17_120  -6.6666666666666663e-01
    w_17_6    full_original_Gini_248  -5.3630952380952390e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.5211280499905517e-02
    x_17_7    product_lb_98  -0.0487568927154393
    x_17_7    product_ub_99  -1.2756264236914810e-01
    x_17_7    onehot_17_118  1
    x_17_7    stock_lb_188  7
    x_17_7    stock_ub_189  7
    x_17_7    parent_nonstrict_scope_190  2.8169024399924438e-02
    x_17_7    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_98  1
    w_17_7    product_ub_99  1
    w_17_7    normalized_mass_17_119  1
    w_17_7    normalized_ratio_17_120  -7.7777777777777768e-01
    w_17_7    full_original_Gini_248  -5.1408730158730158e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.9295792699867738e-02
    x_17_8    product_lb_100  -0.0487568927154393
    x_17_8    product_ub_101  -1.2756264236914810e-01
    x_17_8    onehot_17_118  1
    x_17_8    stock_lb_188  8
    x_17_8    stock_ub_189  8
    x_17_8    parent_nonstrict_scope_190  1.4084512199962219e-02
    x_17_8    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_100  1
    w_17_8    product_ub_101  1
    w_17_8    normalized_mass_17_119  1
    w_17_8    normalized_ratio_17_120  -8.8888888888888884e-01
    w_17_8    full_original_Gini_248  -4.9186507936507944e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -6.3380304899829959e-02
    x_17_9    product_lb_102  -0.0487568927154393
    x_17_9    product_ub_103  -1.2756264236914810e-01
    x_17_9    onehot_17_118  1
    x_17_9    stock_lb_188  9
    x_17_9    stock_ub_189  9
    x_17_9    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_102  1
    w_17_9    product_ub_103  1
    w_17_9    normalized_mass_17_119  1
    w_17_9    normalized_ratio_17_120  -1
    w_17_9    full_original_Gini_248  -4.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.9295792699867738e-02
    x_17_10   product_lb_104  -0.0487568927154393
    x_17_10   product_ub_105  -1.2756264236914810e-01
    x_17_10   onehot_17_118  1
    x_17_10   stock_lb_188  10
    x_17_10   stock_ub_189  10
    x_17_10   parent_nonstrict_scope_190  1.4084512199962219e-02
    x_17_10   unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_104  1
    w_17_10   product_ub_105  1
    w_17_10   normalized_mass_17_119  1
    w_17_10   normalized_ratio_17_120  -1.1111111111111112e+00
    w_17_10   full_original_Gini_248  -5.5853174603174605e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.5211280499905545e-02
    x_17_11   product_lb_106  -0.0487568927154393
    x_17_11   product_ub_107  -1.2756264236914810e-01
    x_17_11   onehot_17_118  1
    x_17_11   stock_lb_188  11
    x_17_11   stock_ub_189  11
    x_17_11   parent_nonstrict_scope_190  2.8169024399924410e-02
    x_17_11   unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_106  1
    w_17_11   product_ub_107  1
    w_17_11   normalized_mass_17_119  1
    w_17_11   normalized_ratio_17_120  -1.2222222222222221e+00
    w_17_11   full_original_Gini_248  -6.8273809523809526e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.1126768299943331e-02
    x_17_12   product_lb_108  -0.0487568927154393
    x_17_12   product_ub_109  -1.2756264236914810e-01
    x_17_12   onehot_17_118  1
    x_17_12   stock_lb_188  12
    x_17_12   stock_ub_189  12
    x_17_12   parent_nonstrict_scope_190  4.2253536599886628e-02
    x_17_12   unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_108  1
    w_17_12   product_ub_109  1
    w_17_12   normalized_mass_17_119  1
    w_17_12   normalized_ratio_17_120  -1.3333333333333333e+00
    w_17_12   full_original_Gini_248  -8.1607142857142829e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -0.00704225609998111
    x_17_13   product_lb_110  -0.0487568927154393
    x_17_13   product_ub_111  -1.2756264236914810e-01
    x_17_13   onehot_17_118  1
    x_17_13   stock_lb_188  13
    x_17_13   stock_ub_189  13
    x_17_13   parent_nonstrict_scope_190  5.6338048799848849e-02
    x_17_13   unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_110  1
    w_17_13   product_ub_111  1
    w_17_13   normalized_mass_17_119  1
    w_17_13   normalized_ratio_17_120  -1.4444444444444444e+00
    w_17_13   full_original_Gini_248  -9.49404761904762
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       7.0422560999810757e-03
    x_17_14   product_lb_112  -0.0487568927154393
    x_17_14   product_ub_113  -1.2756264236914810e-01
    x_17_14   onehot_17_118  1
    x_17_14   stock_lb_188  14
    x_17_14   stock_ub_189  14
    x_17_14   parent_nonstrict_scope_190  7.0422560999811035e-02
    x_17_14   unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_112  1
    w_17_14   product_ub_113  1
    w_17_14   normalized_mass_17_119  1
    w_17_14   normalized_ratio_17_120  -1.5555555555555554e+00
    w_17_14   full_original_Gini_248  -1.0827380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.1126768299943297e-02
    x_17_15   product_lb_114  -0.0487568927154393
    x_17_15   product_ub_115  -1.2756264236914810e-01
    x_17_15   onehot_17_118  1
    x_17_15   stock_lb_188  15
    x_17_15   stock_ub_189  15
    x_17_15   parent_nonstrict_scope_190  8.4507073199773255e-02
    x_17_15   unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_114  1
    w_17_15   product_ub_115  1
    w_17_15   normalized_mass_17_119  1
    w_17_15   normalized_ratio_17_120  -1.6666666666666665e+00
    w_17_15   full_original_Gini_248  -1.2160714285714281e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.5211280499905517e-02
    x_17_16   product_lb_116  -0.0487568927154393
    x_17_16   product_ub_117  -1.2756264236914810e-01
    x_17_16   onehot_17_118  1
    x_17_16   stock_lb_188  16
    x_17_16   stock_ub_189  16
    x_17_16   parent_nonstrict_scope_190  9.8591585399735476e-02
    x_17_16   unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_116  1
    w_17_16   product_ub_117  1
    w_17_16   normalized_mass_17_119  1
    w_17_16   normalized_ratio_17_120  -1.7777777777777777e+00
    w_17_16   full_original_Gini_248  -1.3494047619047620e+01
    rho_17    normalized_ratio_17_120  1
    rho_17    block_pair_pos_199  1
    rho_17    block_pair_neg_200  -1
    rho_17    block_pair_pos_209  1
    rho_17    block_pair_neg_210  -1
    rho_17    block_pair_pos_223  1
    rho_17    block_pair_neg_224  -1
    rho_17    block_pair_pos_229  -1
    rho_17    block_pair_neg_230  1
    rho_17    block_pair_pos_231  -1
    rho_17    block_pair_neg_232  1
    rho_17    block_pair_pos_233  -1
    rho_17    block_pair_neg_234  1
    rho_17    block_pair_pos_241  1
    rho_17    block_pair_neg_242  -1
    rho_17    normalization_247  1
    MARKER    'MARKER'                 'INTORG'
    x_7_0     OBJ       1.9561824064893318e-02
    x_7_0     product_lb_121  -0.0487568927154393
    x_7_0     product_ub_122  -1.2756264236914810e-01
    x_7_0     onehot_7_143  1
    x_7_0     parent_nonstrict_scope_190  3.9123648129786637e-02
    x_7_0     unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_0     product_lb_121  1
    w_7_0     product_ub_122  1
    w_7_0     normalized_mass_7_144  1
    w_7_0     full_original_Gini_248  -7.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_1     OBJ       1.1737094438935995e-02
    x_7_1     product_lb_123  -0.0487568927154393
    x_7_1     product_ub_124  -1.2756264236914810e-01
    x_7_1     onehot_7_143  1
    x_7_1     stock_lb_188  1
    x_7_1     stock_ub_189  1
    x_7_1     parent_nonstrict_scope_190  3.1298918503829314e-02
    MARKER    'MARKER'                 'INTEND'
    w_7_1     product_lb_123  1
    w_7_1     product_ub_124  1
    w_7_1     normalized_mass_7_144  1
    w_7_1     normalized_ratio_7_145  -0.2
    w_7_1     full_original_Gini_248  -7.0392857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_2     OBJ       3.9123648129786616e-03
    x_7_2     product_lb_125  -0.0487568927154393
    x_7_2     product_ub_126  -1.2756264236914810e-01
    x_7_2     onehot_7_143  1
    x_7_2     stock_lb_188  2
    x_7_2     stock_ub_189  2
    x_7_2     parent_nonstrict_scope_190  2.3474188877871980e-02
    x_7_2     unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_2     product_lb_125  1
    w_7_2     product_ub_126  1
    w_7_2     normalized_mass_7_144  1
    w_7_2     normalized_ratio_7_145  -0.4
    w_7_2     full_original_Gini_248  -6.2392857142857139e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_3     OBJ       -3.9123648129786685e-03
    x_7_3     product_lb_127  -0.0487568927154393
    x_7_3     product_ub_128  -1.2756264236914810e-01
    x_7_3     onehot_7_143  1
    x_7_3     stock_lb_188  3
    x_7_3     stock_ub_189  3
    x_7_3     parent_nonstrict_scope_190  1.5649459251914650e-02
    x_7_3     unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_3     product_lb_127  1
    w_7_3     product_ub_128  1
    w_7_3     normalized_mass_7_144  1
    w_7_3     normalized_ratio_7_145  -6.0000000000000009e-01
    w_7_3     full_original_Gini_248  -5.4964285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_4     OBJ       -1.1737094438935993e-02
    x_7_4     product_lb_129  -0.0487568927154393
    x_7_4     product_ub_130  -1.2756264236914810e-01
    x_7_4     onehot_7_143  1
    x_7_4     stock_lb_188  4
    x_7_4     stock_ub_189  4
    x_7_4     parent_nonstrict_scope_190  7.8247296259573249e-03
    x_7_4     unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_4     product_lb_129  1
    w_7_4     product_ub_130  1
    w_7_4     normalized_mass_7_144  1
    w_7_4     normalized_ratio_7_145  -0.8
    w_7_4     full_original_Gini_248  -5.0964285714285715e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_5     OBJ       -1.9561824064893318e-02
    x_7_5     product_lb_131  -0.0487568927154393
    x_7_5     product_ub_132  -1.2756264236914810e-01
    x_7_5     onehot_7_143  1
    x_7_5     stock_lb_188  5
    x_7_5     stock_ub_189  5
    x_7_5     unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_5     product_lb_131  1
    w_7_5     product_ub_132  1
    w_7_5     normalized_mass_7_144  1
    w_7_5     normalized_ratio_7_145  -1
    w_7_5     full_original_Gini_248  -4.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_6     OBJ       -1.1737094438935985e-02
    x_7_6     product_lb_133  -0.0487568927154393
    x_7_6     product_ub_134  -1.2756264236914810e-01
    x_7_6     onehot_7_143  1
    x_7_6     stock_lb_188  6
    x_7_6     stock_ub_189  6
    x_7_6     parent_nonstrict_scope_190  7.8247296259573336e-03
    x_7_6     unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_6     product_lb_133  1
    w_7_6     product_ub_134  1
    w_7_6     normalized_mass_7_144  1
    w_7_6     normalized_ratio_7_145  -1.2000000000000002e+00
    w_7_6     full_original_Gini_248  -6.5607142857142886e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_7     OBJ       -3.9123648129786581e-03
    x_7_7     product_lb_135  -0.0487568927154393
    x_7_7     product_ub_136  -1.2756264236914810e-01
    x_7_7     onehot_7_143  1
    x_7_7     stock_lb_188  7
    x_7_7     stock_ub_189  7
    x_7_7     parent_nonstrict_scope_190  1.5649459251914660e-02
    x_7_7     unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_7     product_lb_135  1
    w_7_7     product_ub_136  1
    w_7_7     normalized_mass_7_144  1
    w_7_7     normalized_ratio_7_145  -1.4000000000000001e+00
    w_7_7     full_original_Gini_248  -8.9607142857142890e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_8     OBJ       3.9123648129786685e-03
    x_7_8     product_lb_137  -0.0487568927154393
    x_7_8     product_ub_138  -1.2756264236914810e-01
    x_7_8     onehot_7_143  1
    x_7_8     stock_lb_188  8
    x_7_8     stock_ub_189  8
    x_7_8     parent_nonstrict_scope_190  2.3474188877871987e-02
    x_7_8     unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_8     product_lb_137  1
    w_7_8     product_ub_138  1
    w_7_8     normalized_mass_7_144  1
    w_7_8     normalized_ratio_7_145  -1.6
    w_7_8     full_original_Gini_248  -1.1360714285714284e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_9     OBJ       1.1737094438935995e-02
    x_7_9     product_lb_139  -0.0487568927154393
    x_7_9     product_ub_140  -1.2756264236914810e-01
    x_7_9     onehot_7_143  1
    x_7_9     stock_lb_188  9
    x_7_9     stock_ub_189  9
    x_7_9     parent_nonstrict_scope_190  3.1298918503829314e-02
    x_7_9     unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_9     product_lb_139  1
    w_7_9     product_ub_140  1
    w_7_9     normalized_mass_7_144  1
    w_7_9     normalized_ratio_7_145  -1.8
    w_7_9     full_original_Gini_248  -1.3760714285714288e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_10    OBJ       1.9561824064893318e-02
    x_7_10    product_lb_141  -0.0487568927154393
    x_7_10    product_ub_142  -1.2756264236914810e-01
    x_7_10    onehot_7_143  1
    x_7_10    stock_lb_188  10
    x_7_10    stock_ub_189  10
    x_7_10    parent_nonstrict_scope_190  3.9123648129786637e-02
    x_7_10    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_10    product_lb_141  1
    w_7_10    product_ub_142  1
    w_7_10    normalized_mass_7_144  1
    w_7_10    normalized_ratio_7_145  -2
    w_7_10    full_original_Gini_248  -1.6160714285714285e+01
    rho_7     normalized_ratio_7_145  1
    rho_7     block_pair_pos_191  -1
    rho_7     block_pair_neg_192  1
    rho_7     block_pair_pos_193  -1
    rho_7     block_pair_neg_194  1
    rho_7     block_pair_pos_197  1
    rho_7     block_pair_neg_198  -1
    rho_7     block_pair_pos_205  1
    rho_7     block_pair_neg_206  -1
    rho_7     block_pair_pos_217  1
    rho_7     block_pair_neg_218  -1
    rho_7     block_pair_pos_231  1
    rho_7     block_pair_neg_232  -1
    rho_7     block_pair_pos_237  1
    rho_7     block_pair_neg_238  -1
    rho_7     normalization_247  1
    MARKER    'MARKER'                 'INTORG'
    x_20_0    OBJ       5.0078236648368350e-02
    x_20_0    product_lb_146  -0.0487568927154393
    x_20_0    product_ub_147  -1.2756264236914810e-01
    x_20_0    onehot_20_178  1
    x_20_0    parent_nonstrict_scope_190  1.0015647329673670e-01
    x_20_0    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_0    product_lb_146  1
    w_20_0    product_ub_147  1
    w_20_0    normalized_mass_20_179  1
    w_20_0    full_original_Gini_248  -7.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_1    OBJ       3.7558677486276261e-02
    x_20_1    product_lb_148  -0.0487568927154393
    x_20_1    product_ub_149  -1.2756264236914810e-01
    x_20_1    onehot_20_178  1
    x_20_1    stock_lb_188  1
    x_20_1    stock_ub_189  1
    x_20_1    parent_nonstrict_scope_190  8.7636914134644611e-02
    x_20_1    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_1    product_lb_148  1
    w_20_1    product_ub_149  1
    w_20_1    normalized_mass_20_179  1
    w_20_1    normalized_ratio_20_180  -0.125
    w_20_1    full_original_Gini_248  -7.3392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_2    OBJ       2.5039118324184172e-02
    x_20_2    product_lb_150  -0.0487568927154393
    x_20_2    product_ub_151  -1.2756264236914810e-01
    x_20_2    onehot_20_178  1
    x_20_2    stock_lb_188  2
    x_20_2    stock_ub_189  2
    x_20_2    parent_nonstrict_scope_190  7.5117354972552522e-02
    x_20_2    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_2    product_lb_150  1
    w_20_2    product_ub_151  1
    w_20_2    normalized_mass_20_179  1
    w_20_2    normalized_ratio_20_180  -0.25
    w_20_2    full_original_Gini_248  -6.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_3    OBJ       1.2519559162092082e-02
    x_20_3    product_lb_152  -0.0487568927154393
    x_20_3    product_ub_153  -1.2756264236914810e-01
    x_20_3    onehot_20_178  1
    x_20_3    stock_lb_188  3
    x_20_3    stock_ub_189  3
    x_20_3    parent_nonstrict_scope_190  6.2597795810460433e-02
    x_20_3    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_3    product_lb_152  1
    w_20_3    product_ub_153  1
    w_20_3    normalized_mass_20_179  1
    w_20_3    normalized_ratio_20_180  -0.375
    w_20_3    full_original_Gini_248  -6.3392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_4    product_lb_154  -0.0487568927154393
    x_20_4    product_ub_155  -1.2756264236914810e-01
    x_20_4    onehot_20_178  1
    x_20_4    stock_lb_188  4
    x_20_4    stock_ub_189  4
    x_20_4    parent_nonstrict_scope_190  5.0078236648368350e-02
    x_20_4    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_4    product_lb_154  1
    w_20_4    product_ub_155  1
    w_20_4    normalized_mass_20_179  1
    w_20_4    normalized_ratio_20_180  -0.5
    w_20_4    full_original_Gini_248  -5.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_5    OBJ       -1.2519559162092089e-02
    x_20_5    product_lb_156  -0.0487568927154393
    x_20_5    product_ub_157  -1.2756264236914810e-01
    x_20_5    onehot_20_178  1
    x_20_5    stock_lb_188  5
    x_20_5    stock_ub_189  5
    x_20_5    parent_nonstrict_scope_190  3.7558677486276261e-02
    x_20_5    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_5    product_lb_156  1
    w_20_5    product_ub_157  1
    w_20_5    normalized_mass_20_179  1
    w_20_5    normalized_ratio_20_180  -0.625
    w_20_5    full_original_Gini_248  -5.4464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_6    OBJ       -2.5039118324184175e-02
    x_20_6    product_lb_158  -0.0487568927154393
    x_20_6    product_ub_159  -1.2756264236914810e-01
    x_20_6    onehot_20_178  1
    x_20_6    stock_lb_188  6
    x_20_6    stock_ub_189  6
    x_20_6    parent_nonstrict_scope_190  2.5039118324184175e-02
    x_20_6    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_6    product_lb_158  1
    w_20_6    product_ub_159  1
    w_20_6    normalized_mass_20_179  1
    w_20_6    normalized_ratio_20_180  -0.75
    w_20_6    full_original_Gini_248  -5.1964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_7    OBJ       -3.7558677486276261e-02
    x_20_7    product_lb_160  -0.0487568927154393
    x_20_7    product_ub_161  -1.2756264236914810e-01
    x_20_7    onehot_20_178  1
    x_20_7    stock_lb_188  7
    x_20_7    stock_ub_189  7
    x_20_7    parent_nonstrict_scope_190  1.2519559162092088e-02
    x_20_7    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_7    product_lb_160  1
    w_20_7    product_ub_161  1
    w_20_7    normalized_mass_20_179  1
    w_20_7    normalized_ratio_20_180  -0.875
    w_20_7    full_original_Gini_248  -4.9464285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_8    OBJ       -5.0078236648368350e-02
    x_20_8    product_lb_162  -0.0487568927154393
    x_20_8    product_ub_163  -1.2756264236914810e-01
    x_20_8    onehot_20_178  1
    x_20_8    stock_lb_188  8
    x_20_8    stock_ub_189  8
    x_20_8    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_8    product_lb_162  1
    w_20_8    product_ub_163  1
    w_20_8    normalized_mass_20_179  1
    w_20_8    normalized_ratio_20_180  -1
    w_20_8    full_original_Gini_248  -4.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_9    OBJ       -3.7558677486276261e-02
    x_20_9    product_lb_164  -0.0487568927154393
    x_20_9    product_ub_165  -1.2756264236914810e-01
    x_20_9    onehot_20_178  1
    x_20_9    stock_lb_188  9
    x_20_9    stock_ub_189  9
    x_20_9    parent_nonstrict_scope_190  1.2519559162092088e-02
    x_20_9    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_9    product_lb_164  1
    w_20_9    product_ub_165  1
    w_20_9    normalized_mass_20_179  1
    w_20_9    normalized_ratio_20_180  -1.125
    w_20_9    full_original_Gini_248  -5.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_10   OBJ       -2.5039118324184175e-02
    x_20_10   product_lb_166  -0.0487568927154393
    x_20_10   product_ub_167  -1.2756264236914810e-01
    x_20_10   onehot_20_178  1
    x_20_10   stock_lb_188  10
    x_20_10   stock_ub_189  10
    x_20_10   parent_nonstrict_scope_190  2.5039118324184175e-02
    x_20_10   unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_10   product_lb_166  1
    w_20_10   product_ub_167  1
    w_20_10   normalized_mass_20_179  1
    w_20_10   normalized_ratio_20_180  -1.25
    w_20_10   full_original_Gini_248  -7.1607142857142865e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_11   OBJ       -1.2519559162092089e-02
    x_20_11   product_lb_168  -0.0487568927154393
    x_20_11   product_ub_169  -1.2756264236914810e-01
    x_20_11   onehot_20_178  1
    x_20_11   stock_lb_188  11
    x_20_11   stock_ub_189  11
    x_20_11   parent_nonstrict_scope_190  3.7558677486276261e-02
    x_20_11   unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_11   product_lb_168  1
    w_20_11   product_ub_169  1
    w_20_11   normalized_mass_20_179  1
    w_20_11   normalized_ratio_20_180  -1.375
    w_20_11   full_original_Gini_248  -8.6607142857142865e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_12   product_lb_170  -0.0487568927154393
    x_20_12   product_ub_171  -1.2756264236914810e-01
    x_20_12   onehot_20_178  1
    x_20_12   stock_lb_188  12
    x_20_12   stock_ub_189  12
    x_20_12   parent_nonstrict_scope_190  5.0078236648368350e-02
    MARKER    'MARKER'                 'INTEND'
    w_20_12   product_lb_170  1
    w_20_12   product_ub_171  1
    w_20_12   normalized_mass_20_179  1
    w_20_12   normalized_ratio_20_180  -1.5
    w_20_12   full_original_Gini_248  -1.0160714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_13   OBJ       1.2519559162092082e-02
    x_20_13   product_lb_172  -0.0487568927154393
    x_20_13   product_ub_173  -1.2756264236914810e-01
    x_20_13   onehot_20_178  1
    x_20_13   stock_lb_188  13
    x_20_13   stock_ub_189  13
    x_20_13   parent_nonstrict_scope_190  6.2597795810460433e-02
    x_20_13   unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_13   product_lb_172  1
    w_20_13   product_ub_173  1
    w_20_13   normalized_mass_20_179  1
    w_20_13   normalized_ratio_20_180  -1.625
    w_20_13   full_original_Gini_248  -1.1660714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_14   OBJ       2.5039118324184172e-02
    x_20_14   product_lb_174  -0.0487568927154393
    x_20_14   product_ub_175  -1.2756264236914810e-01
    x_20_14   onehot_20_178  1
    x_20_14   stock_lb_188  14
    x_20_14   stock_ub_189  14
    x_20_14   parent_nonstrict_scope_190  7.5117354972552522e-02
    x_20_14   unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_14   product_lb_174  1
    w_20_14   product_ub_175  1
    w_20_14   normalized_mass_20_179  1
    w_20_14   normalized_ratio_20_180  -1.75
    w_20_14   full_original_Gini_248  -1.3160714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_15   OBJ       3.7558677486276261e-02
    x_20_15   product_lb_176  -0.0487568927154393
    x_20_15   product_ub_177  -1.2756264236914810e-01
    x_20_15   onehot_20_178  1
    x_20_15   stock_lb_188  15
    x_20_15   stock_ub_189  15
    x_20_15   parent_nonstrict_scope_190  8.7636914134644611e-02
    x_20_15   unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_15   product_lb_176  1
    w_20_15   product_ub_177  1
    w_20_15   normalized_mass_20_179  1
    w_20_15   normalized_ratio_20_180  -1.875
    w_20_15   full_original_Gini_248  -1.4660714285714286e+01
    rho_20    normalized_ratio_20_180  1
    rho_20    block_pair_pos_193  1
    rho_20    block_pair_neg_194  -1
    rho_20    block_pair_pos_201  1
    rho_20    block_pair_neg_202  -1
    rho_20    block_pair_pos_213  1
    rho_20    block_pair_neg_214  -1
    rho_20    block_pair_pos_227  1
    rho_20    block_pair_neg_228  -1
    rho_20    block_pair_pos_233  1
    rho_20    block_pair_neg_234  -1
    rho_20    block_pair_pos_243  1
    rho_20    block_pair_neg_244  -1
    rho_20    block_pair_pos_245  -1
    rho_20    block_pair_neg_246  1
    rho_20    normalization_247  1
    MARKER    'MARKER'                 'INTORG'
    x_6_0     OBJ       6.3380304899829966e-03
    x_6_0     product_lb_181  -0.0487568927154393
    x_6_0     product_ub_182  -1.2756264236914810e-01
    x_6_0     onehot_6_185  1
    x_6_0     parent_nonstrict_scope_190  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_6_0     product_lb_181  1
    w_6_0     product_ub_182  1
    w_6_0     normalized_mass_6_186  1
    w_6_0     full_original_Gini_248  -7.8392857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_1     OBJ       -6.3380304899829966e-03
    x_6_1     product_lb_183  -0.0487568927154393
    x_6_1     product_ub_184  -1.2756264236914810e-01
    x_6_1     onehot_6_185  1
    x_6_1     stock_lb_188  1
    x_6_1     stock_ub_189  1
    x_6_1     unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_1     product_lb_183  1
    w_6_1     product_ub_184  1
    w_6_1     normalized_mass_6_186  1
    w_6_1     normalized_ratio_6_187  -1
    w_6_1     full_original_Gini_248  -4.6964285714285712e+00
    rho_6     normalized_ratio_6_187  1
    rho_6     block_pair_pos_191  1
    rho_6     block_pair_neg_192  -1
    rho_6     block_pair_pos_195  1
    rho_6     block_pair_neg_196  -1
    rho_6     block_pair_pos_203  1
    rho_6     block_pair_neg_204  -1
    rho_6     block_pair_pos_215  1
    rho_6     block_pair_neg_216  -1
    rho_6     block_pair_pos_229  1
    rho_6     block_pair_neg_230  -1
    rho_6     block_pair_pos_235  1
    rho_6     block_pair_neg_236  -1
    rho_6     block_pair_pos_245  1
    rho_6     block_pair_neg_246  -1
    rho_6     normalization_247  1
    a_11_10   block_pair_pos_221  1
    a_11_10   block_pair_neg_222  1
    a_11_10   full_original_Gini_248  -1
    a_11_18   block_pair_pos_225  1
    a_11_18   block_pair_neg_226  1
    a_11_18   full_original_Gini_248  -1
    a_11_9    block_pair_pos_219  1
    a_11_9    block_pair_neg_220  1
    a_11_9    full_original_Gini_248  -1
    a_11_17   block_pair_pos_223  1
    a_11_17   block_pair_neg_224  1
    a_11_17   full_original_Gini_248  -1
    a_11_7    block_pair_pos_217  1
    a_11_7    block_pair_neg_218  1
    a_11_7    full_original_Gini_248  -1
    a_11_20   block_pair_pos_227  1
    a_11_20   block_pair_neg_228  1
    a_11_20   full_original_Gini_248  -1
    a_11_6    block_pair_pos_215  1
    a_11_6    block_pair_neg_216  1
    a_11_6    full_original_Gini_248  -1
    a_10_18   block_pair_pos_211  1
    a_10_18   block_pair_neg_212  1
    a_10_18   full_original_Gini_248  -1
    a_10_9    block_pair_pos_207  1
    a_10_9    block_pair_neg_208  1
    a_10_9    full_original_Gini_248  -1
    a_10_17   block_pair_pos_209  1
    a_10_17   block_pair_neg_210  1
    a_10_17   full_original_Gini_248  -1
    a_10_7    block_pair_pos_205  1
    a_10_7    block_pair_neg_206  1
    a_10_7    full_original_Gini_248  -1
    a_10_20   block_pair_pos_213  1
    a_10_20   block_pair_neg_214  1
    a_10_20   full_original_Gini_248  -1
    a_10_6    block_pair_pos_203  1
    a_10_6    block_pair_neg_204  1
    a_10_6    full_original_Gini_248  -1
    a_18_9    block_pair_pos_239  1
    a_18_9    block_pair_neg_240  1
    a_18_9    full_original_Gini_248  -1
    a_18_17   block_pair_pos_241  1
    a_18_17   block_pair_neg_242  1
    a_18_17   full_original_Gini_248  -1
    a_18_7    block_pair_pos_237  1
    a_18_7    block_pair_neg_238  1
    a_18_7    full_original_Gini_248  -1
    a_18_20   block_pair_pos_243  1
    a_18_20   block_pair_neg_244  1
    a_18_20   full_original_Gini_248  -1
    a_18_6    block_pair_pos_235  1
    a_18_6    block_pair_neg_236  1
    a_18_6    full_original_Gini_248  -1
    a_9_17    block_pair_pos_199  1
    a_9_17    block_pair_neg_200  1
    a_9_17    full_original_Gini_248  -1
    a_9_7     block_pair_pos_197  1
    a_9_7     block_pair_neg_198  1
    a_9_7     full_original_Gini_248  -1
    a_9_20    block_pair_pos_201  1
    a_9_20    block_pair_neg_202  1
    a_9_20    full_original_Gini_248  -1
    a_9_6     block_pair_pos_195  1
    a_9_6     block_pair_neg_196  1
    a_9_6     full_original_Gini_248  -1
    a_17_7    block_pair_pos_231  1
    a_17_7    block_pair_neg_232  1
    a_17_7    full_original_Gini_248  -1
    a_17_20   block_pair_pos_233  1
    a_17_20   block_pair_neg_234  1
    a_17_20   full_original_Gini_248  -1
    a_17_6    block_pair_pos_229  1
    a_17_6    block_pair_neg_230  1
    a_17_6    full_original_Gini_248  -1
    a_7_20    block_pair_pos_193  1
    a_7_20    block_pair_neg_194  1
    a_7_20    full_original_Gini_248  -1
    a_7_6     block_pair_pos_191  1
    a_7_6     block_pair_neg_192  1
    a_7_6     full_original_Gini_248  -1
    a_20_6    block_pair_pos_245  1
    a_20_6    block_pair_neg_246  1
    a_20_6    full_original_Gini_248  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_11_0  unique_nonzero_owner_249  1
    service_0_11_0  service_visit_def_703  1
    service_0_11_0  free_load_conservation_704  -1
    service_0_11_0  original_T_including_depot_unload_751  120
    service_0_11_2  unique_nonzero_owner_250  1
    service_0_11_2  service_visit_def_703  1
    service_0_11_2  free_load_conservation_704  1
    service_0_11_3  unique_nonzero_owner_251  1
    service_0_11_3  service_visit_def_703  1
    service_0_11_3  free_load_conservation_704  2
    service_0_11_4  unique_nonzero_owner_252  1
    service_0_11_4  service_visit_def_703  1
    service_0_11_4  free_load_conservation_704  3
    service_0_11_5  unique_nonzero_owner_253  1
    service_0_11_5  service_visit_def_703  1
    service_0_11_5  free_load_conservation_704  4
    service_0_11_6  unique_nonzero_owner_254  1
    service_0_11_6  service_visit_def_703  1
    service_0_11_6  free_load_conservation_704  5
    service_0_11_7  unique_nonzero_owner_255  1
    service_0_11_7  service_visit_def_703  1
    service_0_11_7  free_load_conservation_704  6
    service_0_11_8  unique_nonzero_owner_256  1
    service_0_11_8  service_visit_def_703  1
    service_0_11_8  free_load_conservation_704  7
    service_0_11_9  unique_nonzero_owner_257  1
    service_0_11_9  service_visit_def_703  1
    service_0_11_9  free_load_conservation_704  8
    service_0_11_10  unique_nonzero_owner_258  1
    service_0_11_10  service_visit_def_703  1
    service_0_11_10  free_load_conservation_704  9
    service_0_11_11  unique_nonzero_owner_259  1
    service_0_11_11  service_visit_def_703  1
    service_0_11_11  free_load_conservation_704  10
    service_0_11_12  unique_nonzero_owner_260  1
    service_0_11_12  service_visit_def_703  1
    service_0_11_12  free_load_conservation_704  11
    service_0_11_13  unique_nonzero_owner_261  1
    service_0_11_13  service_visit_def_703  1
    service_0_11_13  free_load_conservation_704  12
    service_0_11_14  unique_nonzero_owner_262  1
    service_0_11_14  service_visit_def_703  1
    service_0_11_14  free_load_conservation_704  13
    service_0_11_15  unique_nonzero_owner_263  1
    service_0_11_15  service_visit_def_703  1
    service_0_11_15  free_load_conservation_704  14
    service_1_11_0  unique_nonzero_owner_249  1
    service_1_11_0  service_visit_def_973  1
    service_1_11_0  free_load_conservation_974  -1
    service_1_11_0  original_T_including_depot_unload_1018  120
    service_1_11_2  unique_nonzero_owner_250  1
    service_1_11_2  service_visit_def_973  1
    service_1_11_2  free_load_conservation_974  1
    service_1_11_3  unique_nonzero_owner_251  1
    service_1_11_3  service_visit_def_973  1
    service_1_11_3  free_load_conservation_974  2
    service_1_11_4  unique_nonzero_owner_252  1
    service_1_11_4  service_visit_def_973  1
    service_1_11_4  free_load_conservation_974  3
    service_1_11_5  unique_nonzero_owner_253  1
    service_1_11_5  service_visit_def_973  1
    service_1_11_5  free_load_conservation_974  4
    service_1_11_6  unique_nonzero_owner_254  1
    service_1_11_6  service_visit_def_973  1
    service_1_11_6  free_load_conservation_974  5
    service_1_11_7  unique_nonzero_owner_255  1
    service_1_11_7  service_visit_def_973  1
    service_1_11_7  free_load_conservation_974  6
    service_1_11_8  unique_nonzero_owner_256  1
    service_1_11_8  service_visit_def_973  1
    service_1_11_8  free_load_conservation_974  7
    service_1_11_9  unique_nonzero_owner_257  1
    service_1_11_9  service_visit_def_973  1
    service_1_11_9  free_load_conservation_974  8
    service_1_11_10  unique_nonzero_owner_258  1
    service_1_11_10  service_visit_def_973  1
    service_1_11_10  free_load_conservation_974  9
    service_1_11_11  unique_nonzero_owner_259  1
    service_1_11_11  service_visit_def_973  1
    service_1_11_11  free_load_conservation_974  10
    service_1_11_12  unique_nonzero_owner_260  1
    service_1_11_12  service_visit_def_973  1
    service_1_11_12  free_load_conservation_974  11
    service_1_11_13  unique_nonzero_owner_261  1
    service_1_11_13  service_visit_def_973  1
    service_1_11_13  free_load_conservation_974  12
    service_1_11_14  unique_nonzero_owner_262  1
    service_1_11_14  service_visit_def_973  1
    service_1_11_14  free_load_conservation_974  13
    service_1_11_15  unique_nonzero_owner_263  1
    service_1_11_15  service_visit_def_973  1
    service_1_11_15  free_load_conservation_974  14
    service_0_10_1  unique_nonzero_owner_264  1
    service_0_10_1  service_visit_def_709  1
    service_0_10_1  free_load_conservation_710  1
    service_1_10_1  unique_nonzero_owner_264  1
    service_1_10_1  service_visit_def_979  1
    service_1_10_1  free_load_conservation_980  1
    service_0_18_1  unique_nonzero_owner_265  1
    service_0_18_1  service_visit_def_715  1
    service_0_18_1  free_load_conservation_716  1
    service_0_18_2  unique_nonzero_owner_266  1
    service_0_18_2  service_visit_def_715  1
    service_0_18_2  free_load_conservation_716  2
    service_0_18_3  unique_nonzero_owner_267  1
    service_0_18_3  service_visit_def_715  1
    service_0_18_3  free_load_conservation_716  3
    service_0_18_4  unique_nonzero_owner_268  1
    service_0_18_4  service_visit_def_715  1
    service_0_18_4  free_load_conservation_716  4
    service_0_18_5  unique_nonzero_owner_269  1
    service_0_18_5  service_visit_def_715  1
    service_0_18_5  free_load_conservation_716  5
    service_0_18_6  unique_nonzero_owner_270  1
    service_0_18_6  service_visit_def_715  1
    service_0_18_6  free_load_conservation_716  6
    service_0_18_7  unique_nonzero_owner_271  1
    service_0_18_7  service_visit_def_715  1
    service_0_18_7  free_load_conservation_716  7
    service_0_18_8  unique_nonzero_owner_272  1
    service_0_18_8  service_visit_def_715  1
    service_0_18_8  free_load_conservation_716  8
    service_0_18_9  unique_nonzero_owner_273  1
    service_0_18_9  service_visit_def_715  1
    service_0_18_9  free_load_conservation_716  9
    service_0_18_10  unique_nonzero_owner_274  1
    service_0_18_10  service_visit_def_715  1
    service_0_18_10  free_load_conservation_716  10
    service_0_18_11  unique_nonzero_owner_275  1
    service_0_18_11  service_visit_def_715  1
    service_0_18_11  free_load_conservation_716  11
    service_0_18_12  unique_nonzero_owner_276  1
    service_0_18_12  service_visit_def_715  1
    service_0_18_12  free_load_conservation_716  12
    service_0_18_13  unique_nonzero_owner_277  1
    service_0_18_13  service_visit_def_715  1
    service_0_18_13  free_load_conservation_716  13
    service_0_18_14  unique_nonzero_owner_278  1
    service_0_18_14  service_visit_def_715  1
    service_0_18_14  free_load_conservation_716  14
    service_0_18_15  unique_nonzero_owner_279  1
    service_0_18_15  service_visit_def_715  1
    service_0_18_15  free_load_conservation_716  15
    service_1_18_1  unique_nonzero_owner_265  1
    service_1_18_1  service_visit_def_985  1
    service_1_18_1  free_load_conservation_986  1
    service_1_18_2  unique_nonzero_owner_266  1
    service_1_18_2  service_visit_def_985  1
    service_1_18_2  free_load_conservation_986  2
    service_1_18_3  unique_nonzero_owner_267  1
    service_1_18_3  service_visit_def_985  1
    service_1_18_3  free_load_conservation_986  3
    service_1_18_4  unique_nonzero_owner_268  1
    service_1_18_4  service_visit_def_985  1
    service_1_18_4  free_load_conservation_986  4
    service_1_18_5  unique_nonzero_owner_269  1
    service_1_18_5  service_visit_def_985  1
    service_1_18_5  free_load_conservation_986  5
    service_1_18_6  unique_nonzero_owner_270  1
    service_1_18_6  service_visit_def_985  1
    service_1_18_6  free_load_conservation_986  6
    service_1_18_7  unique_nonzero_owner_271  1
    service_1_18_7  service_visit_def_985  1
    service_1_18_7  free_load_conservation_986  7
    service_1_18_8  unique_nonzero_owner_272  1
    service_1_18_8  service_visit_def_985  1
    service_1_18_8  free_load_conservation_986  8
    service_1_18_9  unique_nonzero_owner_273  1
    service_1_18_9  service_visit_def_985  1
    service_1_18_9  free_load_conservation_986  9
    service_1_18_10  unique_nonzero_owner_274  1
    service_1_18_10  service_visit_def_985  1
    service_1_18_10  free_load_conservation_986  10
    service_1_18_11  unique_nonzero_owner_275  1
    service_1_18_11  service_visit_def_985  1
    service_1_18_11  free_load_conservation_986  11
    service_1_18_12  unique_nonzero_owner_276  1
    service_1_18_12  service_visit_def_985  1
    service_1_18_12  free_load_conservation_986  12
    service_1_18_13  unique_nonzero_owner_277  1
    service_1_18_13  service_visit_def_985  1
    service_1_18_13  free_load_conservation_986  13
    service_1_18_14  unique_nonzero_owner_278  1
    service_1_18_14  service_visit_def_985  1
    service_1_18_14  free_load_conservation_986  14
    service_1_18_15  unique_nonzero_owner_279  1
    service_1_18_15  service_visit_def_985  1
    service_1_18_15  free_load_conservation_986  15
    service_0_9_1  unique_nonzero_owner_280  1
    service_0_9_1  service_visit_def_721  1
    service_0_9_1  free_load_conservation_722  1
    service_1_9_1  unique_nonzero_owner_280  1
    service_1_9_1  service_visit_def_991  1
    service_1_9_1  free_load_conservation_992  1
    service_0_17_0  unique_nonzero_owner_281  1
    service_0_17_0  service_visit_def_727  1
    service_0_17_0  free_load_conservation_728  -3
    service_0_17_0  original_T_including_depot_unload_751  360
    service_0_17_1  unique_nonzero_owner_282  1
    service_0_17_1  service_visit_def_727  1
    service_0_17_1  free_load_conservation_728  -2
    service_0_17_1  original_T_including_depot_unload_751  240
    service_0_17_2  unique_nonzero_owner_283  1
    service_0_17_2  service_visit_def_727  1
    service_0_17_2  free_load_conservation_728  -1
    service_0_17_2  original_T_including_depot_unload_751  120
    service_0_17_4  unique_nonzero_owner_284  1
    service_0_17_4  service_visit_def_727  1
    service_0_17_4  free_load_conservation_728  1
    service_0_17_5  unique_nonzero_owner_285  1
    service_0_17_5  service_visit_def_727  1
    service_0_17_5  free_load_conservation_728  2
    service_0_17_6  unique_nonzero_owner_286  1
    service_0_17_6  service_visit_def_727  1
    service_0_17_6  free_load_conservation_728  3
    service_0_17_7  unique_nonzero_owner_287  1
    service_0_17_7  service_visit_def_727  1
    service_0_17_7  free_load_conservation_728  4
    service_0_17_8  unique_nonzero_owner_288  1
    service_0_17_8  service_visit_def_727  1
    service_0_17_8  free_load_conservation_728  5
    service_0_17_9  unique_nonzero_owner_289  1
    service_0_17_9  service_visit_def_727  1
    service_0_17_9  free_load_conservation_728  6
    service_0_17_10  unique_nonzero_owner_290  1
    service_0_17_10  service_visit_def_727  1
    service_0_17_10  free_load_conservation_728  7
    service_0_17_11  unique_nonzero_owner_291  1
    service_0_17_11  service_visit_def_727  1
    service_0_17_11  free_load_conservation_728  8
    service_0_17_12  unique_nonzero_owner_292  1
    service_0_17_12  service_visit_def_727  1
    service_0_17_12  free_load_conservation_728  9
    service_0_17_13  unique_nonzero_owner_293  1
    service_0_17_13  service_visit_def_727  1
    service_0_17_13  free_load_conservation_728  10
    service_0_17_14  unique_nonzero_owner_294  1
    service_0_17_14  service_visit_def_727  1
    service_0_17_14  free_load_conservation_728  11
    service_0_17_15  unique_nonzero_owner_295  1
    service_0_17_15  service_visit_def_727  1
    service_0_17_15  free_load_conservation_728  12
    service_0_17_16  unique_nonzero_owner_296  1
    service_0_17_16  service_visit_def_727  1
    service_0_17_16  free_load_conservation_728  13
    service_1_17_0  unique_nonzero_owner_281  1
    service_1_17_0  service_visit_def_997  1
    service_1_17_0  free_load_conservation_998  -3
    service_1_17_0  original_T_including_depot_unload_1018  360
    service_1_17_1  unique_nonzero_owner_282  1
    service_1_17_1  service_visit_def_997  1
    service_1_17_1  free_load_conservation_998  -2
    service_1_17_1  original_T_including_depot_unload_1018  240
    service_1_17_2  unique_nonzero_owner_283  1
    service_1_17_2  service_visit_def_997  1
    service_1_17_2  free_load_conservation_998  -1
    service_1_17_2  original_T_including_depot_unload_1018  120
    service_1_17_4  unique_nonzero_owner_284  1
    service_1_17_4  service_visit_def_997  1
    service_1_17_4  free_load_conservation_998  1
    service_1_17_5  unique_nonzero_owner_285  1
    service_1_17_5  service_visit_def_997  1
    service_1_17_5  free_load_conservation_998  2
    service_1_17_6  unique_nonzero_owner_286  1
    service_1_17_6  service_visit_def_997  1
    service_1_17_6  free_load_conservation_998  3
    service_1_17_7  unique_nonzero_owner_287  1
    service_1_17_7  service_visit_def_997  1
    service_1_17_7  free_load_conservation_998  4
    service_1_17_8  unique_nonzero_owner_288  1
    service_1_17_8  service_visit_def_997  1
    service_1_17_8  free_load_conservation_998  5
    service_1_17_9  unique_nonzero_owner_289  1
    service_1_17_9  service_visit_def_997  1
    service_1_17_9  free_load_conservation_998  6
    service_1_17_10  unique_nonzero_owner_290  1
    service_1_17_10  service_visit_def_997  1
    service_1_17_10  free_load_conservation_998  7
    service_1_17_11  unique_nonzero_owner_291  1
    service_1_17_11  service_visit_def_997  1
    service_1_17_11  free_load_conservation_998  8
    service_1_17_12  unique_nonzero_owner_292  1
    service_1_17_12  service_visit_def_997  1
    service_1_17_12  free_load_conservation_998  9
    service_1_17_13  unique_nonzero_owner_293  1
    service_1_17_13  service_visit_def_997  1
    service_1_17_13  free_load_conservation_998  10
    service_1_17_14  unique_nonzero_owner_294  1
    service_1_17_14  service_visit_def_997  1
    service_1_17_14  free_load_conservation_998  11
    service_1_17_15  unique_nonzero_owner_295  1
    service_1_17_15  service_visit_def_997  1
    service_1_17_15  free_load_conservation_998  12
    service_1_17_16  unique_nonzero_owner_296  1
    service_1_17_16  service_visit_def_997  1
    service_1_17_16  free_load_conservation_998  13
    service_0_7_0  unique_nonzero_owner_297  1
    service_0_7_0  service_visit_def_733  1
    service_0_7_0  free_load_conservation_734  -1
    service_0_7_0  original_T_including_depot_unload_751  120
    service_0_7_2  unique_nonzero_owner_298  1
    service_0_7_2  service_visit_def_733  1
    service_0_7_2  free_load_conservation_734  1
    service_0_7_3  unique_nonzero_owner_299  1
    service_0_7_3  service_visit_def_733  1
    service_0_7_3  free_load_conservation_734  2
    service_0_7_4  unique_nonzero_owner_300  1
    service_0_7_4  service_visit_def_733  1
    service_0_7_4  free_load_conservation_734  3
    service_0_7_5  unique_nonzero_owner_301  1
    service_0_7_5  service_visit_def_733  1
    service_0_7_5  free_load_conservation_734  4
    service_0_7_6  unique_nonzero_owner_302  1
    service_0_7_6  service_visit_def_733  1
    service_0_7_6  free_load_conservation_734  5
    service_0_7_7  unique_nonzero_owner_303  1
    service_0_7_7  service_visit_def_733  1
    service_0_7_7  free_load_conservation_734  6
    service_0_7_8  unique_nonzero_owner_304  1
    service_0_7_8  service_visit_def_733  1
    service_0_7_8  free_load_conservation_734  7
    service_0_7_9  unique_nonzero_owner_305  1
    service_0_7_9  service_visit_def_733  1
    service_0_7_9  free_load_conservation_734  8
    service_0_7_10  unique_nonzero_owner_306  1
    service_0_7_10  service_visit_def_733  1
    service_0_7_10  free_load_conservation_734  9
    service_1_7_0  unique_nonzero_owner_297  1
    service_1_7_0  service_visit_def_1003  1
    service_1_7_0  free_load_conservation_1004  -1
    service_1_7_0  original_T_including_depot_unload_1018  120
    service_1_7_2  unique_nonzero_owner_298  1
    service_1_7_2  service_visit_def_1003  1
    service_1_7_2  free_load_conservation_1004  1
    service_1_7_3  unique_nonzero_owner_299  1
    service_1_7_3  service_visit_def_1003  1
    service_1_7_3  free_load_conservation_1004  2
    service_1_7_4  unique_nonzero_owner_300  1
    service_1_7_4  service_visit_def_1003  1
    service_1_7_4  free_load_conservation_1004  3
    service_1_7_5  unique_nonzero_owner_301  1
    service_1_7_5  service_visit_def_1003  1
    service_1_7_5  free_load_conservation_1004  4
    service_1_7_6  unique_nonzero_owner_302  1
    service_1_7_6  service_visit_def_1003  1
    service_1_7_6  free_load_conservation_1004  5
    service_1_7_7  unique_nonzero_owner_303  1
    service_1_7_7  service_visit_def_1003  1
    service_1_7_7  free_load_conservation_1004  6
    service_1_7_8  unique_nonzero_owner_304  1
    service_1_7_8  service_visit_def_1003  1
    service_1_7_8  free_load_conservation_1004  7
    service_1_7_9  unique_nonzero_owner_305  1
    service_1_7_9  service_visit_def_1003  1
    service_1_7_9  free_load_conservation_1004  8
    service_1_7_10  unique_nonzero_owner_306  1
    service_1_7_10  service_visit_def_1003  1
    service_1_7_10  free_load_conservation_1004  9
    service_0_20_0  unique_nonzero_owner_307  1
    service_0_20_0  service_visit_def_739  1
    service_0_20_0  free_load_conservation_740  -12
    service_0_20_0  original_T_including_depot_unload_751  1440
    service_0_20_1  unique_nonzero_owner_308  1
    service_0_20_1  service_visit_def_739  1
    service_0_20_1  free_load_conservation_740  -11
    service_0_20_1  original_T_including_depot_unload_751  1320
    service_0_20_2  unique_nonzero_owner_309  1
    service_0_20_2  service_visit_def_739  1
    service_0_20_2  free_load_conservation_740  -10
    service_0_20_2  original_T_including_depot_unload_751  1200
    service_0_20_3  unique_nonzero_owner_310  1
    service_0_20_3  service_visit_def_739  1
    service_0_20_3  free_load_conservation_740  -9
    service_0_20_3  original_T_including_depot_unload_751  1080
    service_0_20_4  unique_nonzero_owner_311  1
    service_0_20_4  service_visit_def_739  1
    service_0_20_4  free_load_conservation_740  -8
    service_0_20_4  original_T_including_depot_unload_751  960
    service_0_20_5  unique_nonzero_owner_312  1
    service_0_20_5  service_visit_def_739  1
    service_0_20_5  free_load_conservation_740  -7
    service_0_20_5  original_T_including_depot_unload_751  840
    service_0_20_6  unique_nonzero_owner_313  1
    service_0_20_6  service_visit_def_739  1
    service_0_20_6  free_load_conservation_740  -6
    service_0_20_6  original_T_including_depot_unload_751  720
    service_0_20_7  unique_nonzero_owner_314  1
    service_0_20_7  service_visit_def_739  1
    service_0_20_7  free_load_conservation_740  -5
    service_0_20_7  original_T_including_depot_unload_751  600
    service_0_20_8  unique_nonzero_owner_315  1
    service_0_20_8  service_visit_def_739  1
    service_0_20_8  free_load_conservation_740  -4
    service_0_20_8  original_T_including_depot_unload_751  480
    service_0_20_9  unique_nonzero_owner_316  1
    service_0_20_9  service_visit_def_739  1
    service_0_20_9  free_load_conservation_740  -3
    service_0_20_9  original_T_including_depot_unload_751  360
    service_0_20_10  unique_nonzero_owner_317  1
    service_0_20_10  service_visit_def_739  1
    service_0_20_10  free_load_conservation_740  -2
    service_0_20_10  original_T_including_depot_unload_751  240
    service_0_20_11  unique_nonzero_owner_318  1
    service_0_20_11  service_visit_def_739  1
    service_0_20_11  free_load_conservation_740  -1
    service_0_20_11  original_T_including_depot_unload_751  120
    service_0_20_13  unique_nonzero_owner_319  1
    service_0_20_13  service_visit_def_739  1
    service_0_20_13  free_load_conservation_740  1
    service_0_20_14  unique_nonzero_owner_320  1
    service_0_20_14  service_visit_def_739  1
    service_0_20_14  free_load_conservation_740  2
    service_0_20_15  unique_nonzero_owner_321  1
    service_0_20_15  service_visit_def_739  1
    service_0_20_15  free_load_conservation_740  3
    service_1_20_0  unique_nonzero_owner_307  1
    service_1_20_0  service_visit_def_1009  1
    service_1_20_0  free_load_conservation_1010  -12
    service_1_20_0  original_T_including_depot_unload_1018  1440
    service_1_20_1  unique_nonzero_owner_308  1
    service_1_20_1  service_visit_def_1009  1
    service_1_20_1  free_load_conservation_1010  -11
    service_1_20_1  original_T_including_depot_unload_1018  1320
    service_1_20_2  unique_nonzero_owner_309  1
    service_1_20_2  service_visit_def_1009  1
    service_1_20_2  free_load_conservation_1010  -10
    service_1_20_2  original_T_including_depot_unload_1018  1200
    service_1_20_3  unique_nonzero_owner_310  1
    service_1_20_3  service_visit_def_1009  1
    service_1_20_3  free_load_conservation_1010  -9
    service_1_20_3  original_T_including_depot_unload_1018  1080
    service_1_20_4  unique_nonzero_owner_311  1
    service_1_20_4  service_visit_def_1009  1
    service_1_20_4  free_load_conservation_1010  -8
    service_1_20_4  original_T_including_depot_unload_1018  960
    service_1_20_5  unique_nonzero_owner_312  1
    service_1_20_5  service_visit_def_1009  1
    service_1_20_5  free_load_conservation_1010  -7
    service_1_20_5  original_T_including_depot_unload_1018  840
    service_1_20_6  unique_nonzero_owner_313  1
    service_1_20_6  service_visit_def_1009  1
    service_1_20_6  free_load_conservation_1010  -6
    service_1_20_6  original_T_including_depot_unload_1018  720
    service_1_20_7  unique_nonzero_owner_314  1
    service_1_20_7  service_visit_def_1009  1
    service_1_20_7  free_load_conservation_1010  -5
    service_1_20_7  original_T_including_depot_unload_1018  600
    service_1_20_8  unique_nonzero_owner_315  1
    service_1_20_8  service_visit_def_1009  1
    service_1_20_8  free_load_conservation_1010  -4
    service_1_20_8  original_T_including_depot_unload_1018  480
    service_1_20_9  unique_nonzero_owner_316  1
    service_1_20_9  service_visit_def_1009  1
    service_1_20_9  free_load_conservation_1010  -3
    service_1_20_9  original_T_including_depot_unload_1018  360
    service_1_20_10  unique_nonzero_owner_317  1
    service_1_20_10  service_visit_def_1009  1
    service_1_20_10  free_load_conservation_1010  -2
    service_1_20_10  original_T_including_depot_unload_1018  240
    service_1_20_11  unique_nonzero_owner_318  1
    service_1_20_11  service_visit_def_1009  1
    service_1_20_11  free_load_conservation_1010  -1
    service_1_20_11  original_T_including_depot_unload_1018  120
    service_1_20_13  unique_nonzero_owner_319  1
    service_1_20_13  service_visit_def_1009  1
    service_1_20_13  free_load_conservation_1010  1
    service_1_20_14  unique_nonzero_owner_320  1
    service_1_20_14  service_visit_def_1009  1
    service_1_20_14  free_load_conservation_1010  2
    service_1_20_15  unique_nonzero_owner_321  1
    service_1_20_15  service_visit_def_1009  1
    service_1_20_15  free_load_conservation_1010  3
    service_0_6_1  unique_nonzero_owner_322  1
    service_0_6_1  service_visit_def_745  1
    service_0_6_1  free_load_conservation_746  1
    service_1_6_1  unique_nonzero_owner_322  1
    service_1_6_1  service_visit_def_1015  1
    service_1_6_1  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_664  -1
    visit_0_1  in_degree_665  -1
    visit_0_1  order_active_lb_666  -1
    visit_0_1  order_active_ub_667  -13
    order_0_1  connected_order_arc_339  -1
    order_0_1  connected_order_arc_341  -1
    order_0_1  connected_order_arc_343  -1
    order_0_1  connected_order_arc_345  -1
    order_0_1  connected_order_arc_347  -1
    order_0_1  connected_order_arc_349  -1
    order_0_1  connected_order_arc_351  -1
    order_0_1  connected_order_arc_353  -1
    order_0_1  connected_order_arc_355  -1
    order_0_1  connected_order_arc_357  -1
    order_0_1  connected_order_arc_359  -1
    order_0_1  connected_order_arc_361  -1
    order_0_1  connected_order_arc_364  1
    order_0_1  connected_order_arc_389  1
    order_0_1  connected_order_arc_414  1
    order_0_1  connected_order_arc_439  1
    order_0_1  connected_order_arc_464  1
    order_0_1  connected_order_arc_489  1
    order_0_1  connected_order_arc_514  1
    order_0_1  connected_order_arc_539  1
    order_0_1  connected_order_arc_564  1
    order_0_1  connected_order_arc_589  1
    order_0_1  connected_order_arc_614  1
    order_0_1  connected_order_arc_639  1
    order_0_1  order_active_lb_666  1
    order_0_1  order_active_ub_667  1
    order_0_1  fixed_segment_relative_order_747  -1
    visit_0_2  out_degree_671  -1
    visit_0_2  in_degree_672  -1
    visit_0_2  order_active_lb_673  -1
    visit_0_2  order_active_ub_674  -13
    order_0_2  connected_order_arc_339  1
    order_0_2  connected_order_arc_364  -1
    order_0_2  connected_order_arc_366  -1
    order_0_2  connected_order_arc_368  -1
    order_0_2  connected_order_arc_370  -1
    order_0_2  connected_order_arc_372  -1
    order_0_2  connected_order_arc_374  -1
    order_0_2  connected_order_arc_376  -1
    order_0_2  connected_order_arc_378  -1
    order_0_2  connected_order_arc_380  -1
    order_0_2  connected_order_arc_382  -1
    order_0_2  connected_order_arc_384  -1
    order_0_2  connected_order_arc_386  -1
    order_0_2  connected_order_arc_391  1
    order_0_2  connected_order_arc_416  1
    order_0_2  connected_order_arc_441  1
    order_0_2  connected_order_arc_466  1
    order_0_2  connected_order_arc_491  1
    order_0_2  connected_order_arc_516  1
    order_0_2  connected_order_arc_541  1
    order_0_2  connected_order_arc_566  1
    order_0_2  connected_order_arc_591  1
    order_0_2  connected_order_arc_616  1
    order_0_2  connected_order_arc_641  1
    order_0_2  order_active_lb_673  1
    order_0_2  order_active_ub_674  1
    order_0_2  fixed_segment_relative_order_747  1
    order_0_2  fixed_segment_relative_order_748  -1
    visit_0_3  out_degree_678  -1
    visit_0_3  in_degree_679  -1
    visit_0_3  order_active_lb_680  -1
    visit_0_3  order_active_ub_681  -13
    order_0_3  connected_order_arc_341  1
    order_0_3  connected_order_arc_366  1
    order_0_3  connected_order_arc_389  -1
    order_0_3  connected_order_arc_391  -1
    order_0_3  connected_order_arc_393  -1
    order_0_3  connected_order_arc_395  -1
    order_0_3  connected_order_arc_397  -1
    order_0_3  connected_order_arc_399  -1
    order_0_3  connected_order_arc_401  -1
    order_0_3  connected_order_arc_403  -1
    order_0_3  connected_order_arc_405  -1
    order_0_3  connected_order_arc_407  -1
    order_0_3  connected_order_arc_409  -1
    order_0_3  connected_order_arc_411  -1
    order_0_3  connected_order_arc_418  1
    order_0_3  connected_order_arc_443  1
    order_0_3  connected_order_arc_468  1
    order_0_3  connected_order_arc_493  1
    order_0_3  connected_order_arc_518  1
    order_0_3  connected_order_arc_543  1
    order_0_3  connected_order_arc_568  1
    order_0_3  connected_order_arc_593  1
    order_0_3  connected_order_arc_618  1
    order_0_3  connected_order_arc_643  1
    order_0_3  order_active_lb_680  1
    order_0_3  order_active_ub_681  1
    order_0_3  fixed_segment_relative_order_748  1
    order_0_3  fixed_segment_relative_order_749  -1
    visit_0_4  out_degree_685  -1
    visit_0_4  in_degree_686  -1
    visit_0_4  order_active_lb_687  -1
    visit_0_4  order_active_ub_688  -13
    order_0_4  connected_order_arc_343  1
    order_0_4  connected_order_arc_368  1
    order_0_4  connected_order_arc_393  1
    order_0_4  connected_order_arc_414  -1
    order_0_4  connected_order_arc_416  -1
    order_0_4  connected_order_arc_418  -1
    order_0_4  connected_order_arc_420  -1
    order_0_4  connected_order_arc_422  -1
    order_0_4  connected_order_arc_424  -1
    order_0_4  connected_order_arc_426  -1
    order_0_4  connected_order_arc_428  -1
    order_0_4  connected_order_arc_430  -1
    order_0_4  connected_order_arc_432  -1
    order_0_4  connected_order_arc_434  -1
    order_0_4  connected_order_arc_436  -1
    order_0_4  connected_order_arc_445  1
    order_0_4  connected_order_arc_470  1
    order_0_4  connected_order_arc_495  1
    order_0_4  connected_order_arc_520  1
    order_0_4  connected_order_arc_545  1
    order_0_4  connected_order_arc_570  1
    order_0_4  connected_order_arc_595  1
    order_0_4  connected_order_arc_620  1
    order_0_4  connected_order_arc_645  1
    order_0_4  order_active_lb_687  1
    order_0_4  order_active_ub_688  1
    order_0_4  fixed_segment_relative_order_749  1
    order_0_4  fixed_segment_relative_order_750  -1
    visit_0_5  out_degree_692  -1
    visit_0_5  in_degree_693  -1
    visit_0_5  order_active_lb_694  -1
    visit_0_5  order_active_ub_695  -13
    order_0_5  connected_order_arc_345  1
    order_0_5  connected_order_arc_370  1
    order_0_5  connected_order_arc_395  1
    order_0_5  connected_order_arc_420  1
    order_0_5  connected_order_arc_439  -1
    order_0_5  connected_order_arc_441  -1
    order_0_5  connected_order_arc_443  -1
    order_0_5  connected_order_arc_445  -1
    order_0_5  connected_order_arc_447  -1
    order_0_5  connected_order_arc_449  -1
    order_0_5  connected_order_arc_451  -1
    order_0_5  connected_order_arc_453  -1
    order_0_5  connected_order_arc_455  -1
    order_0_5  connected_order_arc_457  -1
    order_0_5  connected_order_arc_459  -1
    order_0_5  connected_order_arc_461  -1
    order_0_5  connected_order_arc_472  1
    order_0_5  connected_order_arc_497  1
    order_0_5  connected_order_arc_522  1
    order_0_5  connected_order_arc_547  1
    order_0_5  connected_order_arc_572  1
    order_0_5  connected_order_arc_597  1
    order_0_5  connected_order_arc_622  1
    order_0_5  connected_order_arc_647  1
    order_0_5  order_active_lb_694  1
    order_0_5  order_active_ub_695  1
    order_0_5  fixed_segment_relative_order_750  1
    visit_0_8  out_degree_699  -1
    visit_0_8  in_degree_700  -1
    visit_0_8  order_active_lb_701  -1
    visit_0_8  order_active_ub_702  -13
    visit_0_8  service_visit_def_703  -1
    order_0_8  connected_order_arc_347  1
    order_0_8  connected_order_arc_372  1
    order_0_8  connected_order_arc_397  1
    order_0_8  connected_order_arc_422  1
    order_0_8  connected_order_arc_447  1
    order_0_8  connected_order_arc_464  -1
    order_0_8  connected_order_arc_466  -1
    order_0_8  connected_order_arc_468  -1
    order_0_8  connected_order_arc_470  -1
    order_0_8  connected_order_arc_472  -1
    order_0_8  connected_order_arc_474  -1
    order_0_8  connected_order_arc_476  -1
    order_0_8  connected_order_arc_478  -1
    order_0_8  connected_order_arc_480  -1
    order_0_8  connected_order_arc_482  -1
    order_0_8  connected_order_arc_484  -1
    order_0_8  connected_order_arc_486  -1
    order_0_8  connected_order_arc_499  1
    order_0_8  connected_order_arc_524  1
    order_0_8  connected_order_arc_549  1
    order_0_8  connected_order_arc_574  1
    order_0_8  connected_order_arc_599  1
    order_0_8  connected_order_arc_624  1
    order_0_8  connected_order_arc_649  1
    order_0_8  order_active_lb_701  1
    order_0_8  order_active_ub_702  1
    visit_0_9  out_degree_705  -1
    visit_0_9  in_degree_706  -1
    visit_0_9  order_active_lb_707  -1
    visit_0_9  order_active_ub_708  -13
    visit_0_9  service_visit_def_709  -1
    order_0_9  connected_order_arc_349  1
    order_0_9  connected_order_arc_374  1
    order_0_9  connected_order_arc_399  1
    order_0_9  connected_order_arc_424  1
    order_0_9  connected_order_arc_449  1
    order_0_9  connected_order_arc_474  1
    order_0_9  connected_order_arc_489  -1
    order_0_9  connected_order_arc_491  -1
    order_0_9  connected_order_arc_493  -1
    order_0_9  connected_order_arc_495  -1
    order_0_9  connected_order_arc_497  -1
    order_0_9  connected_order_arc_499  -1
    order_0_9  connected_order_arc_501  -1
    order_0_9  connected_order_arc_503  -1
    order_0_9  connected_order_arc_505  -1
    order_0_9  connected_order_arc_507  -1
    order_0_9  connected_order_arc_509  -1
    order_0_9  connected_order_arc_511  -1
    order_0_9  connected_order_arc_526  1
    order_0_9  connected_order_arc_551  1
    order_0_9  connected_order_arc_576  1
    order_0_9  connected_order_arc_601  1
    order_0_9  connected_order_arc_626  1
    order_0_9  connected_order_arc_651  1
    order_0_9  order_active_lb_707  1
    order_0_9  order_active_ub_708  1
    visit_0_10  out_degree_711  -1
    visit_0_10  in_degree_712  -1
    visit_0_10  order_active_lb_713  -1
    visit_0_10  order_active_ub_714  -13
    visit_0_10  service_visit_def_715  -1
    order_0_10  connected_order_arc_351  1
    order_0_10  connected_order_arc_376  1
    order_0_10  connected_order_arc_401  1
    order_0_10  connected_order_arc_426  1
    order_0_10  connected_order_arc_451  1
    order_0_10  connected_order_arc_476  1
    order_0_10  connected_order_arc_501  1
    order_0_10  connected_order_arc_514  -1
    order_0_10  connected_order_arc_516  -1
    order_0_10  connected_order_arc_518  -1
    order_0_10  connected_order_arc_520  -1
    order_0_10  connected_order_arc_522  -1
    order_0_10  connected_order_arc_524  -1
    order_0_10  connected_order_arc_526  -1
    order_0_10  connected_order_arc_528  -1
    order_0_10  connected_order_arc_530  -1
    order_0_10  connected_order_arc_532  -1
    order_0_10  connected_order_arc_534  -1
    order_0_10  connected_order_arc_536  -1
    order_0_10  connected_order_arc_553  1
    order_0_10  connected_order_arc_578  1
    order_0_10  connected_order_arc_603  1
    order_0_10  connected_order_arc_628  1
    order_0_10  connected_order_arc_653  1
    order_0_10  order_active_lb_713  1
    order_0_10  order_active_ub_714  1
    visit_0_11  out_degree_717  -1
    visit_0_11  in_degree_718  -1
    visit_0_11  order_active_lb_719  -1
    visit_0_11  order_active_ub_720  -13
    visit_0_11  service_visit_def_721  -1
    order_0_11  connected_order_arc_353  1
    order_0_11  connected_order_arc_378  1
    order_0_11  connected_order_arc_403  1
    order_0_11  connected_order_arc_428  1
    order_0_11  connected_order_arc_453  1
    order_0_11  connected_order_arc_478  1
    order_0_11  connected_order_arc_503  1
    order_0_11  connected_order_arc_528  1
    order_0_11  connected_order_arc_539  -1
    order_0_11  connected_order_arc_541  -1
    order_0_11  connected_order_arc_543  -1
    order_0_11  connected_order_arc_545  -1
    order_0_11  connected_order_arc_547  -1
    order_0_11  connected_order_arc_549  -1
    order_0_11  connected_order_arc_551  -1
    order_0_11  connected_order_arc_553  -1
    order_0_11  connected_order_arc_555  -1
    order_0_11  connected_order_arc_557  -1
    order_0_11  connected_order_arc_559  -1
    order_0_11  connected_order_arc_561  -1
    order_0_11  connected_order_arc_580  1
    order_0_11  connected_order_arc_605  1
    order_0_11  connected_order_arc_630  1
    order_0_11  connected_order_arc_655  1
    order_0_11  order_active_lb_719  1
    order_0_11  order_active_ub_720  1
    visit_0_12  out_degree_723  -1
    visit_0_12  in_degree_724  -1
    visit_0_12  order_active_lb_725  -1
    visit_0_12  order_active_ub_726  -13
    visit_0_12  service_visit_def_727  -1
    order_0_12  connected_order_arc_355  1
    order_0_12  connected_order_arc_380  1
    order_0_12  connected_order_arc_405  1
    order_0_12  connected_order_arc_430  1
    order_0_12  connected_order_arc_455  1
    order_0_12  connected_order_arc_480  1
    order_0_12  connected_order_arc_505  1
    order_0_12  connected_order_arc_530  1
    order_0_12  connected_order_arc_555  1
    order_0_12  connected_order_arc_564  -1
    order_0_12  connected_order_arc_566  -1
    order_0_12  connected_order_arc_568  -1
    order_0_12  connected_order_arc_570  -1
    order_0_12  connected_order_arc_572  -1
    order_0_12  connected_order_arc_574  -1
    order_0_12  connected_order_arc_576  -1
    order_0_12  connected_order_arc_578  -1
    order_0_12  connected_order_arc_580  -1
    order_0_12  connected_order_arc_582  -1
    order_0_12  connected_order_arc_584  -1
    order_0_12  connected_order_arc_586  -1
    order_0_12  connected_order_arc_607  1
    order_0_12  connected_order_arc_632  1
    order_0_12  connected_order_arc_657  1
    order_0_12  order_active_lb_725  1
    order_0_12  order_active_ub_726  1
    visit_0_13  out_degree_729  -1
    visit_0_13  in_degree_730  -1
    visit_0_13  order_active_lb_731  -1
    visit_0_13  order_active_ub_732  -13
    visit_0_13  service_visit_def_733  -1
    order_0_13  connected_order_arc_357  1
    order_0_13  connected_order_arc_382  1
    order_0_13  connected_order_arc_407  1
    order_0_13  connected_order_arc_432  1
    order_0_13  connected_order_arc_457  1
    order_0_13  connected_order_arc_482  1
    order_0_13  connected_order_arc_507  1
    order_0_13  connected_order_arc_532  1
    order_0_13  connected_order_arc_557  1
    order_0_13  connected_order_arc_582  1
    order_0_13  connected_order_arc_589  -1
    order_0_13  connected_order_arc_591  -1
    order_0_13  connected_order_arc_593  -1
    order_0_13  connected_order_arc_595  -1
    order_0_13  connected_order_arc_597  -1
    order_0_13  connected_order_arc_599  -1
    order_0_13  connected_order_arc_601  -1
    order_0_13  connected_order_arc_603  -1
    order_0_13  connected_order_arc_605  -1
    order_0_13  connected_order_arc_607  -1
    order_0_13  connected_order_arc_609  -1
    order_0_13  connected_order_arc_611  -1
    order_0_13  connected_order_arc_634  1
    order_0_13  connected_order_arc_659  1
    order_0_13  order_active_lb_731  1
    order_0_13  order_active_ub_732  1
    visit_0_14  out_degree_735  -1
    visit_0_14  in_degree_736  -1
    visit_0_14  order_active_lb_737  -1
    visit_0_14  order_active_ub_738  -13
    visit_0_14  service_visit_def_739  -1
    order_0_14  connected_order_arc_359  1
    order_0_14  connected_order_arc_384  1
    order_0_14  connected_order_arc_409  1
    order_0_14  connected_order_arc_434  1
    order_0_14  connected_order_arc_459  1
    order_0_14  connected_order_arc_484  1
    order_0_14  connected_order_arc_509  1
    order_0_14  connected_order_arc_534  1
    order_0_14  connected_order_arc_559  1
    order_0_14  connected_order_arc_584  1
    order_0_14  connected_order_arc_609  1
    order_0_14  connected_order_arc_614  -1
    order_0_14  connected_order_arc_616  -1
    order_0_14  connected_order_arc_618  -1
    order_0_14  connected_order_arc_620  -1
    order_0_14  connected_order_arc_622  -1
    order_0_14  connected_order_arc_624  -1
    order_0_14  connected_order_arc_626  -1
    order_0_14  connected_order_arc_628  -1
    order_0_14  connected_order_arc_630  -1
    order_0_14  connected_order_arc_632  -1
    order_0_14  connected_order_arc_634  -1
    order_0_14  connected_order_arc_636  -1
    order_0_14  connected_order_arc_661  1
    order_0_14  order_active_lb_737  1
    order_0_14  order_active_ub_738  1
    visit_0_15  out_degree_741  -1
    visit_0_15  in_degree_742  -1
    visit_0_15  order_active_lb_743  -1
    visit_0_15  order_active_ub_744  -13
    visit_0_15  service_visit_def_745  -1
    order_0_15  connected_order_arc_361  1
    order_0_15  connected_order_arc_386  1
    order_0_15  connected_order_arc_411  1
    order_0_15  connected_order_arc_436  1
    order_0_15  connected_order_arc_461  1
    order_0_15  connected_order_arc_486  1
    order_0_15  connected_order_arc_511  1
    order_0_15  connected_order_arc_536  1
    order_0_15  connected_order_arc_561  1
    order_0_15  connected_order_arc_586  1
    order_0_15  connected_order_arc_611  1
    order_0_15  connected_order_arc_636  1
    order_0_15  connected_order_arc_639  -1
    order_0_15  connected_order_arc_641  -1
    order_0_15  connected_order_arc_643  -1
    order_0_15  connected_order_arc_645  -1
    order_0_15  connected_order_arc_647  -1
    order_0_15  connected_order_arc_649  -1
    order_0_15  connected_order_arc_651  -1
    order_0_15  connected_order_arc_653  -1
    order_0_15  connected_order_arc_655  -1
    order_0_15  connected_order_arc_657  -1
    order_0_15  connected_order_arc_659  -1
    order_0_15  connected_order_arc_661  -1
    order_0_15  order_active_lb_743  1
    order_0_15  order_active_ub_744  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_323  -30
    arc_0_0_0  depot_departure_or_bypass_662  1
    arc_0_0_0  depot_return_or_bypass_663  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_323  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_324  -30
    arc_0_0_1  depot_departure_or_bypass_662  1
    arc_0_0_1  in_degree_665  1
    arc_0_0_1  original_T_including_depot_unload_751  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_324  1
    load_0_0_1  segment_load_conservation_668  -1
    load_0_0_1  segment_prefix_lb_669  1
    load_0_0_1  segment_prefix_ub_670  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_325  -30
    arc_0_0_2  depot_departure_or_bypass_662  1
    arc_0_0_2  in_degree_672  1
    arc_0_0_2  original_T_including_depot_unload_751  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_325  1
    load_0_0_2  segment_load_conservation_675  -1
    load_0_0_2  segment_prefix_lb_676  1
    load_0_0_2  segment_prefix_ub_677  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_326  -30
    arc_0_0_3  depot_departure_or_bypass_662  1
    arc_0_0_3  in_degree_679  1
    arc_0_0_3  original_T_including_depot_unload_751  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_326  1
    load_0_0_3  segment_load_conservation_682  -1
    load_0_0_3  segment_prefix_lb_683  1
    load_0_0_3  segment_prefix_ub_684  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_327  -30
    arc_0_0_4  depot_departure_or_bypass_662  1
    arc_0_0_4  in_degree_686  1
    arc_0_0_4  original_T_including_depot_unload_751  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_327  1
    load_0_0_4  segment_load_conservation_689  -1
    load_0_0_4  segment_prefix_lb_690  1
    load_0_0_4  segment_prefix_ub_691  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_328  -30
    arc_0_0_5  depot_departure_or_bypass_662  1
    arc_0_0_5  in_degree_693  1
    arc_0_0_5  original_T_including_depot_unload_751  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_328  1
    load_0_0_5  segment_load_conservation_696  -1
    load_0_0_5  segment_prefix_lb_697  1
    load_0_0_5  segment_prefix_ub_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_8  arc_capacity_329  -30
    arc_0_0_8  depot_departure_or_bypass_662  1
    arc_0_0_8  in_degree_700  1
    arc_0_0_8  original_T_including_depot_unload_751  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_8  arc_capacity_329  1
    load_0_0_8  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_9  arc_capacity_330  -30
    arc_0_0_9  depot_departure_or_bypass_662  1
    arc_0_0_9  in_degree_706  1
    arc_0_0_9  original_T_including_depot_unload_751  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_9  arc_capacity_330  1
    load_0_0_9  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_10  arc_capacity_331  -30
    arc_0_0_10  depot_departure_or_bypass_662  1
    arc_0_0_10  in_degree_712  1
    arc_0_0_10  original_T_including_depot_unload_751  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_10  arc_capacity_331  1
    load_0_0_10  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_11  arc_capacity_332  -30
    arc_0_0_11  depot_departure_or_bypass_662  1
    arc_0_0_11  in_degree_718  1
    arc_0_0_11  original_T_including_depot_unload_751  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_11  arc_capacity_332  1
    load_0_0_11  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_333  -30
    arc_0_0_12  depot_departure_or_bypass_662  1
    arc_0_0_12  in_degree_724  1
    arc_0_0_12  original_T_including_depot_unload_751  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_333  1
    load_0_0_12  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_334  -30
    arc_0_0_13  depot_departure_or_bypass_662  1
    arc_0_0_13  in_degree_730  1
    arc_0_0_13  original_T_including_depot_unload_751  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_334  1
    load_0_0_13  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_335  -30
    arc_0_0_14  depot_departure_or_bypass_662  1
    arc_0_0_14  in_degree_736  1
    arc_0_0_14  original_T_including_depot_unload_751  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_335  1
    load_0_0_14  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_336  -30
    arc_0_0_15  depot_departure_or_bypass_662  1
    arc_0_0_15  in_degree_742  1
    arc_0_0_15  original_T_including_depot_unload_751  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_336  1
    load_0_0_15  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_337  -30
    arc_0_1_0  depot_return_or_bypass_663  1
    arc_0_1_0  out_degree_664  1
    arc_0_1_0  original_T_including_depot_unload_751  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_337  1
    load_0_1_0  segment_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_338  -30
    arc_0_1_2  connected_order_arc_339  -14
    arc_0_1_2  out_degree_664  1
    arc_0_1_2  in_degree_672  1
    arc_0_1_2  original_T_including_depot_unload_751  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_338  1
    load_0_1_2  segment_load_conservation_668  1
    load_0_1_2  segment_load_conservation_675  -1
    load_0_1_2  segment_prefix_lb_676  1
    load_0_1_2  segment_prefix_ub_677  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_340  -30
    arc_0_1_3  connected_order_arc_341  -14
    arc_0_1_3  out_degree_664  1
    arc_0_1_3  in_degree_679  1
    arc_0_1_3  original_T_including_depot_unload_751  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_340  1
    load_0_1_3  segment_load_conservation_668  1
    load_0_1_3  segment_load_conservation_682  -1
    load_0_1_3  segment_prefix_lb_683  1
    load_0_1_3  segment_prefix_ub_684  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_342  -30
    arc_0_1_4  connected_order_arc_343  -14
    arc_0_1_4  out_degree_664  1
    arc_0_1_4  in_degree_686  1
    arc_0_1_4  original_T_including_depot_unload_751  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_342  1
    load_0_1_4  segment_load_conservation_668  1
    load_0_1_4  segment_load_conservation_689  -1
    load_0_1_4  segment_prefix_lb_690  1
    load_0_1_4  segment_prefix_ub_691  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_344  -30
    arc_0_1_5  connected_order_arc_345  -14
    arc_0_1_5  out_degree_664  1
    arc_0_1_5  in_degree_693  1
    arc_0_1_5  original_T_including_depot_unload_751  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_344  1
    load_0_1_5  segment_load_conservation_668  1
    load_0_1_5  segment_load_conservation_696  -1
    load_0_1_5  segment_prefix_lb_697  1
    load_0_1_5  segment_prefix_ub_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_8  arc_capacity_346  -30
    arc_0_1_8  connected_order_arc_347  -14
    arc_0_1_8  out_degree_664  1
    arc_0_1_8  in_degree_700  1
    arc_0_1_8  original_T_including_depot_unload_751  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_8  arc_capacity_346  1
    load_0_1_8  segment_load_conservation_668  1
    load_0_1_8  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_9  arc_capacity_348  -30
    arc_0_1_9  connected_order_arc_349  -14
    arc_0_1_9  out_degree_664  1
    arc_0_1_9  in_degree_706  1
    arc_0_1_9  original_T_including_depot_unload_751  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_9  arc_capacity_348  1
    load_0_1_9  segment_load_conservation_668  1
    load_0_1_9  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_10  arc_capacity_350  -30
    arc_0_1_10  connected_order_arc_351  -14
    arc_0_1_10  out_degree_664  1
    arc_0_1_10  in_degree_712  1
    arc_0_1_10  original_T_including_depot_unload_751  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_10  arc_capacity_350  1
    load_0_1_10  segment_load_conservation_668  1
    load_0_1_10  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_11  arc_capacity_352  -30
    arc_0_1_11  connected_order_arc_353  -14
    arc_0_1_11  out_degree_664  1
    arc_0_1_11  in_degree_718  1
    arc_0_1_11  original_T_including_depot_unload_751  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_11  arc_capacity_352  1
    load_0_1_11  segment_load_conservation_668  1
    load_0_1_11  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_354  -30
    arc_0_1_12  connected_order_arc_355  -14
    arc_0_1_12  out_degree_664  1
    arc_0_1_12  in_degree_724  1
    arc_0_1_12  original_T_including_depot_unload_751  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_354  1
    load_0_1_12  segment_load_conservation_668  1
    load_0_1_12  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_356  -30
    arc_0_1_13  connected_order_arc_357  -14
    arc_0_1_13  out_degree_664  1
    arc_0_1_13  in_degree_730  1
    arc_0_1_13  original_T_including_depot_unload_751  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_356  1
    load_0_1_13  segment_load_conservation_668  1
    load_0_1_13  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_358  -30
    arc_0_1_14  connected_order_arc_359  -14
    arc_0_1_14  out_degree_664  1
    arc_0_1_14  in_degree_736  1
    arc_0_1_14  original_T_including_depot_unload_751  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_358  1
    load_0_1_14  segment_load_conservation_668  1
    load_0_1_14  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_360  -30
    arc_0_1_15  connected_order_arc_361  -14
    arc_0_1_15  out_degree_664  1
    arc_0_1_15  in_degree_742  1
    arc_0_1_15  original_T_including_depot_unload_751  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_360  1
    load_0_1_15  segment_load_conservation_668  1
    load_0_1_15  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_362  -30
    arc_0_2_0  depot_return_or_bypass_663  1
    arc_0_2_0  out_degree_671  1
    arc_0_2_0  original_T_including_depot_unload_751  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_362  1
    load_0_2_0  segment_load_conservation_675  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_363  -30
    arc_0_2_1  connected_order_arc_364  -14
    arc_0_2_1  in_degree_665  1
    arc_0_2_1  out_degree_671  1
    arc_0_2_1  original_T_including_depot_unload_751  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_363  1
    load_0_2_1  segment_load_conservation_668  -1
    load_0_2_1  segment_prefix_lb_669  1
    load_0_2_1  segment_prefix_ub_670  1
    load_0_2_1  segment_load_conservation_675  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_365  -30
    arc_0_2_3  connected_order_arc_366  -14
    arc_0_2_3  out_degree_671  1
    arc_0_2_3  in_degree_679  1
    arc_0_2_3  original_T_including_depot_unload_751  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_365  1
    load_0_2_3  segment_load_conservation_675  1
    load_0_2_3  segment_load_conservation_682  -1
    load_0_2_3  segment_prefix_lb_683  1
    load_0_2_3  segment_prefix_ub_684  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_367  -30
    arc_0_2_4  connected_order_arc_368  -14
    arc_0_2_4  out_degree_671  1
    arc_0_2_4  in_degree_686  1
    arc_0_2_4  original_T_including_depot_unload_751  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_367  1
    load_0_2_4  segment_load_conservation_675  1
    load_0_2_4  segment_load_conservation_689  -1
    load_0_2_4  segment_prefix_lb_690  1
    load_0_2_4  segment_prefix_ub_691  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_369  -30
    arc_0_2_5  connected_order_arc_370  -14
    arc_0_2_5  out_degree_671  1
    arc_0_2_5  in_degree_693  1
    arc_0_2_5  original_T_including_depot_unload_751  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_369  1
    load_0_2_5  segment_load_conservation_675  1
    load_0_2_5  segment_load_conservation_696  -1
    load_0_2_5  segment_prefix_lb_697  1
    load_0_2_5  segment_prefix_ub_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_8  arc_capacity_371  -30
    arc_0_2_8  connected_order_arc_372  -14
    arc_0_2_8  out_degree_671  1
    arc_0_2_8  in_degree_700  1
    arc_0_2_8  original_T_including_depot_unload_751  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_8  arc_capacity_371  1
    load_0_2_8  segment_load_conservation_675  1
    load_0_2_8  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_9  arc_capacity_373  -30
    arc_0_2_9  connected_order_arc_374  -14
    arc_0_2_9  out_degree_671  1
    arc_0_2_9  in_degree_706  1
    arc_0_2_9  original_T_including_depot_unload_751  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_9  arc_capacity_373  1
    load_0_2_9  segment_load_conservation_675  1
    load_0_2_9  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_10  arc_capacity_375  -30
    arc_0_2_10  connected_order_arc_376  -14
    arc_0_2_10  out_degree_671  1
    arc_0_2_10  in_degree_712  1
    arc_0_2_10  original_T_including_depot_unload_751  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_10  arc_capacity_375  1
    load_0_2_10  segment_load_conservation_675  1
    load_0_2_10  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_11  arc_capacity_377  -30
    arc_0_2_11  connected_order_arc_378  -14
    arc_0_2_11  out_degree_671  1
    arc_0_2_11  in_degree_718  1
    arc_0_2_11  original_T_including_depot_unload_751  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_11  arc_capacity_377  1
    load_0_2_11  segment_load_conservation_675  1
    load_0_2_11  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_379  -30
    arc_0_2_12  connected_order_arc_380  -14
    arc_0_2_12  out_degree_671  1
    arc_0_2_12  in_degree_724  1
    arc_0_2_12  original_T_including_depot_unload_751  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_379  1
    load_0_2_12  segment_load_conservation_675  1
    load_0_2_12  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_381  -30
    arc_0_2_13  connected_order_arc_382  -14
    arc_0_2_13  out_degree_671  1
    arc_0_2_13  in_degree_730  1
    arc_0_2_13  original_T_including_depot_unload_751  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_381  1
    load_0_2_13  segment_load_conservation_675  1
    load_0_2_13  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_383  -30
    arc_0_2_14  connected_order_arc_384  -14
    arc_0_2_14  out_degree_671  1
    arc_0_2_14  in_degree_736  1
    arc_0_2_14  original_T_including_depot_unload_751  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_383  1
    load_0_2_14  segment_load_conservation_675  1
    load_0_2_14  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_385  -30
    arc_0_2_15  connected_order_arc_386  -14
    arc_0_2_15  out_degree_671  1
    arc_0_2_15  in_degree_742  1
    arc_0_2_15  original_T_including_depot_unload_751  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_385  1
    load_0_2_15  segment_load_conservation_675  1
    load_0_2_15  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_387  -30
    arc_0_3_0  depot_return_or_bypass_663  1
    arc_0_3_0  out_degree_678  1
    arc_0_3_0  original_T_including_depot_unload_751  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_387  1
    load_0_3_0  segment_load_conservation_682  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_388  -30
    arc_0_3_1  connected_order_arc_389  -14
    arc_0_3_1  in_degree_665  1
    arc_0_3_1  out_degree_678  1
    arc_0_3_1  original_T_including_depot_unload_751  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_388  1
    load_0_3_1  segment_load_conservation_668  -1
    load_0_3_1  segment_prefix_lb_669  1
    load_0_3_1  segment_prefix_ub_670  1
    load_0_3_1  segment_load_conservation_682  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_390  -30
    arc_0_3_2  connected_order_arc_391  -14
    arc_0_3_2  in_degree_672  1
    arc_0_3_2  out_degree_678  1
    arc_0_3_2  original_T_including_depot_unload_751  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_390  1
    load_0_3_2  segment_load_conservation_675  -1
    load_0_3_2  segment_prefix_lb_676  1
    load_0_3_2  segment_prefix_ub_677  1
    load_0_3_2  segment_load_conservation_682  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_392  -30
    arc_0_3_4  connected_order_arc_393  -14
    arc_0_3_4  out_degree_678  1
    arc_0_3_4  in_degree_686  1
    arc_0_3_4  original_T_including_depot_unload_751  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_392  1
    load_0_3_4  segment_load_conservation_682  1
    load_0_3_4  segment_load_conservation_689  -1
    load_0_3_4  segment_prefix_lb_690  1
    load_0_3_4  segment_prefix_ub_691  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_394  -30
    arc_0_3_5  connected_order_arc_395  -14
    arc_0_3_5  out_degree_678  1
    arc_0_3_5  in_degree_693  1
    arc_0_3_5  original_T_including_depot_unload_751  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_394  1
    load_0_3_5  segment_load_conservation_682  1
    load_0_3_5  segment_load_conservation_696  -1
    load_0_3_5  segment_prefix_lb_697  1
    load_0_3_5  segment_prefix_ub_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_8  arc_capacity_396  -30
    arc_0_3_8  connected_order_arc_397  -14
    arc_0_3_8  out_degree_678  1
    arc_0_3_8  in_degree_700  1
    arc_0_3_8  original_T_including_depot_unload_751  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_8  arc_capacity_396  1
    load_0_3_8  segment_load_conservation_682  1
    load_0_3_8  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_9  arc_capacity_398  -30
    arc_0_3_9  connected_order_arc_399  -14
    arc_0_3_9  out_degree_678  1
    arc_0_3_9  in_degree_706  1
    arc_0_3_9  original_T_including_depot_unload_751  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_9  arc_capacity_398  1
    load_0_3_9  segment_load_conservation_682  1
    load_0_3_9  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_10  arc_capacity_400  -30
    arc_0_3_10  connected_order_arc_401  -14
    arc_0_3_10  out_degree_678  1
    arc_0_3_10  in_degree_712  1
    arc_0_3_10  original_T_including_depot_unload_751  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_10  arc_capacity_400  1
    load_0_3_10  segment_load_conservation_682  1
    load_0_3_10  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_11  arc_capacity_402  -30
    arc_0_3_11  connected_order_arc_403  -14
    arc_0_3_11  out_degree_678  1
    arc_0_3_11  in_degree_718  1
    arc_0_3_11  original_T_including_depot_unload_751  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_11  arc_capacity_402  1
    load_0_3_11  segment_load_conservation_682  1
    load_0_3_11  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_404  -30
    arc_0_3_12  connected_order_arc_405  -14
    arc_0_3_12  out_degree_678  1
    arc_0_3_12  in_degree_724  1
    arc_0_3_12  original_T_including_depot_unload_751  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_404  1
    load_0_3_12  segment_load_conservation_682  1
    load_0_3_12  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_406  -30
    arc_0_3_13  connected_order_arc_407  -14
    arc_0_3_13  out_degree_678  1
    arc_0_3_13  in_degree_730  1
    arc_0_3_13  original_T_including_depot_unload_751  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_406  1
    load_0_3_13  segment_load_conservation_682  1
    load_0_3_13  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_408  -30
    arc_0_3_14  connected_order_arc_409  -14
    arc_0_3_14  out_degree_678  1
    arc_0_3_14  in_degree_736  1
    arc_0_3_14  original_T_including_depot_unload_751  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_408  1
    load_0_3_14  segment_load_conservation_682  1
    load_0_3_14  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_410  -30
    arc_0_3_15  connected_order_arc_411  -14
    arc_0_3_15  out_degree_678  1
    arc_0_3_15  in_degree_742  1
    arc_0_3_15  original_T_including_depot_unload_751  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_410  1
    load_0_3_15  segment_load_conservation_682  1
    load_0_3_15  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_412  -30
    arc_0_4_0  depot_return_or_bypass_663  1
    arc_0_4_0  out_degree_685  1
    arc_0_4_0  original_T_including_depot_unload_751  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_412  1
    load_0_4_0  segment_load_conservation_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_413  -30
    arc_0_4_1  connected_order_arc_414  -14
    arc_0_4_1  in_degree_665  1
    arc_0_4_1  out_degree_685  1
    arc_0_4_1  original_T_including_depot_unload_751  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_413  1
    load_0_4_1  segment_load_conservation_668  -1
    load_0_4_1  segment_prefix_lb_669  1
    load_0_4_1  segment_prefix_ub_670  1
    load_0_4_1  segment_load_conservation_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_415  -30
    arc_0_4_2  connected_order_arc_416  -14
    arc_0_4_2  in_degree_672  1
    arc_0_4_2  out_degree_685  1
    arc_0_4_2  original_T_including_depot_unload_751  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_415  1
    load_0_4_2  segment_load_conservation_675  -1
    load_0_4_2  segment_prefix_lb_676  1
    load_0_4_2  segment_prefix_ub_677  1
    load_0_4_2  segment_load_conservation_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_417  -30
    arc_0_4_3  connected_order_arc_418  -14
    arc_0_4_3  in_degree_679  1
    arc_0_4_3  out_degree_685  1
    arc_0_4_3  original_T_including_depot_unload_751  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_417  1
    load_0_4_3  segment_load_conservation_682  -1
    load_0_4_3  segment_prefix_lb_683  1
    load_0_4_3  segment_prefix_ub_684  1
    load_0_4_3  segment_load_conservation_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_419  -30
    arc_0_4_5  connected_order_arc_420  -14
    arc_0_4_5  out_degree_685  1
    arc_0_4_5  in_degree_693  1
    arc_0_4_5  original_T_including_depot_unload_751  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_419  1
    load_0_4_5  segment_load_conservation_689  1
    load_0_4_5  segment_load_conservation_696  -1
    load_0_4_5  segment_prefix_lb_697  1
    load_0_4_5  segment_prefix_ub_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_8  arc_capacity_421  -30
    arc_0_4_8  connected_order_arc_422  -14
    arc_0_4_8  out_degree_685  1
    arc_0_4_8  in_degree_700  1
    arc_0_4_8  original_T_including_depot_unload_751  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_8  arc_capacity_421  1
    load_0_4_8  segment_load_conservation_689  1
    load_0_4_8  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_9  arc_capacity_423  -30
    arc_0_4_9  connected_order_arc_424  -14
    arc_0_4_9  out_degree_685  1
    arc_0_4_9  in_degree_706  1
    arc_0_4_9  original_T_including_depot_unload_751  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_9  arc_capacity_423  1
    load_0_4_9  segment_load_conservation_689  1
    load_0_4_9  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_10  arc_capacity_425  -30
    arc_0_4_10  connected_order_arc_426  -14
    arc_0_4_10  out_degree_685  1
    arc_0_4_10  in_degree_712  1
    arc_0_4_10  original_T_including_depot_unload_751  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_10  arc_capacity_425  1
    load_0_4_10  segment_load_conservation_689  1
    load_0_4_10  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_11  arc_capacity_427  -30
    arc_0_4_11  connected_order_arc_428  -14
    arc_0_4_11  out_degree_685  1
    arc_0_4_11  in_degree_718  1
    arc_0_4_11  original_T_including_depot_unload_751  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_11  arc_capacity_427  1
    load_0_4_11  segment_load_conservation_689  1
    load_0_4_11  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_429  -30
    arc_0_4_12  connected_order_arc_430  -14
    arc_0_4_12  out_degree_685  1
    arc_0_4_12  in_degree_724  1
    arc_0_4_12  original_T_including_depot_unload_751  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_429  1
    load_0_4_12  segment_load_conservation_689  1
    load_0_4_12  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_431  -30
    arc_0_4_13  connected_order_arc_432  -14
    arc_0_4_13  out_degree_685  1
    arc_0_4_13  in_degree_730  1
    arc_0_4_13  original_T_including_depot_unload_751  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_431  1
    load_0_4_13  segment_load_conservation_689  1
    load_0_4_13  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_433  -30
    arc_0_4_14  connected_order_arc_434  -14
    arc_0_4_14  out_degree_685  1
    arc_0_4_14  in_degree_736  1
    arc_0_4_14  original_T_including_depot_unload_751  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_433  1
    load_0_4_14  segment_load_conservation_689  1
    load_0_4_14  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_435  -30
    arc_0_4_15  connected_order_arc_436  -14
    arc_0_4_15  out_degree_685  1
    arc_0_4_15  in_degree_742  1
    arc_0_4_15  original_T_including_depot_unload_751  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_435  1
    load_0_4_15  segment_load_conservation_689  1
    load_0_4_15  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_437  -30
    arc_0_5_0  depot_return_or_bypass_663  1
    arc_0_5_0  out_degree_692  1
    arc_0_5_0  original_T_including_depot_unload_751  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_437  1
    load_0_5_0  segment_load_conservation_696  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_438  -30
    arc_0_5_1  connected_order_arc_439  -14
    arc_0_5_1  in_degree_665  1
    arc_0_5_1  out_degree_692  1
    arc_0_5_1  original_T_including_depot_unload_751  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_438  1
    load_0_5_1  segment_load_conservation_668  -1
    load_0_5_1  segment_prefix_lb_669  1
    load_0_5_1  segment_prefix_ub_670  1
    load_0_5_1  segment_load_conservation_696  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_440  -30
    arc_0_5_2  connected_order_arc_441  -14
    arc_0_5_2  in_degree_672  1
    arc_0_5_2  out_degree_692  1
    arc_0_5_2  original_T_including_depot_unload_751  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_440  1
    load_0_5_2  segment_load_conservation_675  -1
    load_0_5_2  segment_prefix_lb_676  1
    load_0_5_2  segment_prefix_ub_677  1
    load_0_5_2  segment_load_conservation_696  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_442  -30
    arc_0_5_3  connected_order_arc_443  -14
    arc_0_5_3  in_degree_679  1
    arc_0_5_3  out_degree_692  1
    arc_0_5_3  original_T_including_depot_unload_751  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_442  1
    load_0_5_3  segment_load_conservation_682  -1
    load_0_5_3  segment_prefix_lb_683  1
    load_0_5_3  segment_prefix_ub_684  1
    load_0_5_3  segment_load_conservation_696  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_444  -30
    arc_0_5_4  connected_order_arc_445  -14
    arc_0_5_4  in_degree_686  1
    arc_0_5_4  out_degree_692  1
    arc_0_5_4  original_T_including_depot_unload_751  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_444  1
    load_0_5_4  segment_load_conservation_689  -1
    load_0_5_4  segment_prefix_lb_690  1
    load_0_5_4  segment_prefix_ub_691  1
    load_0_5_4  segment_load_conservation_696  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_8  arc_capacity_446  -30
    arc_0_5_8  connected_order_arc_447  -14
    arc_0_5_8  out_degree_692  1
    arc_0_5_8  in_degree_700  1
    arc_0_5_8  original_T_including_depot_unload_751  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_8  arc_capacity_446  1
    load_0_5_8  segment_load_conservation_696  1
    load_0_5_8  free_load_conservation_704  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_9  arc_capacity_448  -30
    arc_0_5_9  connected_order_arc_449  -14
    arc_0_5_9  out_degree_692  1
    arc_0_5_9  in_degree_706  1
    arc_0_5_9  original_T_including_depot_unload_751  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_9  arc_capacity_448  1
    load_0_5_9  segment_load_conservation_696  1
    load_0_5_9  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_10  arc_capacity_450  -30
    arc_0_5_10  connected_order_arc_451  -14
    arc_0_5_10  out_degree_692  1
    arc_0_5_10  in_degree_712  1
    arc_0_5_10  original_T_including_depot_unload_751  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_10  arc_capacity_450  1
    load_0_5_10  segment_load_conservation_696  1
    load_0_5_10  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_11  arc_capacity_452  -30
    arc_0_5_11  connected_order_arc_453  -14
    arc_0_5_11  out_degree_692  1
    arc_0_5_11  in_degree_718  1
    arc_0_5_11  original_T_including_depot_unload_751  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_11  arc_capacity_452  1
    load_0_5_11  segment_load_conservation_696  1
    load_0_5_11  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_12  arc_capacity_454  -30
    arc_0_5_12  connected_order_arc_455  -14
    arc_0_5_12  out_degree_692  1
    arc_0_5_12  in_degree_724  1
    arc_0_5_12  original_T_including_depot_unload_751  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_12  arc_capacity_454  1
    load_0_5_12  segment_load_conservation_696  1
    load_0_5_12  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_456  -30
    arc_0_5_13  connected_order_arc_457  -14
    arc_0_5_13  out_degree_692  1
    arc_0_5_13  in_degree_730  1
    arc_0_5_13  original_T_including_depot_unload_751  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_456  1
    load_0_5_13  segment_load_conservation_696  1
    load_0_5_13  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_458  -30
    arc_0_5_14  connected_order_arc_459  -14
    arc_0_5_14  out_degree_692  1
    arc_0_5_14  in_degree_736  1
    arc_0_5_14  original_T_including_depot_unload_751  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_458  1
    load_0_5_14  segment_load_conservation_696  1
    load_0_5_14  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_460  -30
    arc_0_5_15  connected_order_arc_461  -14
    arc_0_5_15  out_degree_692  1
    arc_0_5_15  in_degree_742  1
    arc_0_5_15  original_T_including_depot_unload_751  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_460  1
    load_0_5_15  segment_load_conservation_696  1
    load_0_5_15  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_0  arc_capacity_462  -30
    arc_0_8_0  depot_return_or_bypass_663  1
    arc_0_8_0  out_degree_699  1
    arc_0_8_0  original_T_including_depot_unload_751  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_0  arc_capacity_462  1
    load_0_8_0  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_1  arc_capacity_463  -30
    arc_0_8_1  connected_order_arc_464  -14
    arc_0_8_1  in_degree_665  1
    arc_0_8_1  out_degree_699  1
    arc_0_8_1  original_T_including_depot_unload_751  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_1  arc_capacity_463  1
    load_0_8_1  segment_load_conservation_668  -1
    load_0_8_1  segment_prefix_lb_669  1
    load_0_8_1  segment_prefix_ub_670  1
    load_0_8_1  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_2  arc_capacity_465  -30
    arc_0_8_2  connected_order_arc_466  -14
    arc_0_8_2  in_degree_672  1
    arc_0_8_2  out_degree_699  1
    arc_0_8_2  original_T_including_depot_unload_751  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_2  arc_capacity_465  1
    load_0_8_2  segment_load_conservation_675  -1
    load_0_8_2  segment_prefix_lb_676  1
    load_0_8_2  segment_prefix_ub_677  1
    load_0_8_2  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_3  arc_capacity_467  -30
    arc_0_8_3  connected_order_arc_468  -14
    arc_0_8_3  in_degree_679  1
    arc_0_8_3  out_degree_699  1
    arc_0_8_3  original_T_including_depot_unload_751  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_3  arc_capacity_467  1
    load_0_8_3  segment_load_conservation_682  -1
    load_0_8_3  segment_prefix_lb_683  1
    load_0_8_3  segment_prefix_ub_684  1
    load_0_8_3  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_4  arc_capacity_469  -30
    arc_0_8_4  connected_order_arc_470  -14
    arc_0_8_4  in_degree_686  1
    arc_0_8_4  out_degree_699  1
    arc_0_8_4  original_T_including_depot_unload_751  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_4  arc_capacity_469  1
    load_0_8_4  segment_load_conservation_689  -1
    load_0_8_4  segment_prefix_lb_690  1
    load_0_8_4  segment_prefix_ub_691  1
    load_0_8_4  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_5  arc_capacity_471  -30
    arc_0_8_5  connected_order_arc_472  -14
    arc_0_8_5  in_degree_693  1
    arc_0_8_5  out_degree_699  1
    arc_0_8_5  original_T_including_depot_unload_751  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_5  arc_capacity_471  1
    load_0_8_5  segment_load_conservation_696  -1
    load_0_8_5  segment_prefix_lb_697  1
    load_0_8_5  segment_prefix_ub_698  1
    load_0_8_5  free_load_conservation_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_9  arc_capacity_473  -30
    arc_0_8_9  connected_order_arc_474  -14
    arc_0_8_9  out_degree_699  1
    arc_0_8_9  in_degree_706  1
    arc_0_8_9  original_T_including_depot_unload_751  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_9  arc_capacity_473  1
    load_0_8_9  free_load_conservation_704  1
    load_0_8_9  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_10  arc_capacity_475  -30
    arc_0_8_10  connected_order_arc_476  -14
    arc_0_8_10  out_degree_699  1
    arc_0_8_10  in_degree_712  1
    arc_0_8_10  original_T_including_depot_unload_751  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_10  arc_capacity_475  1
    load_0_8_10  free_load_conservation_704  1
    load_0_8_10  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_11  arc_capacity_477  -30
    arc_0_8_11  connected_order_arc_478  -14
    arc_0_8_11  out_degree_699  1
    arc_0_8_11  in_degree_718  1
    arc_0_8_11  original_T_including_depot_unload_751  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_11  arc_capacity_477  1
    load_0_8_11  free_load_conservation_704  1
    load_0_8_11  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_12  arc_capacity_479  -30
    arc_0_8_12  connected_order_arc_480  -14
    arc_0_8_12  out_degree_699  1
    arc_0_8_12  in_degree_724  1
    arc_0_8_12  original_T_including_depot_unload_751  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_12  arc_capacity_479  1
    load_0_8_12  free_load_conservation_704  1
    load_0_8_12  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_13  arc_capacity_481  -30
    arc_0_8_13  connected_order_arc_482  -14
    arc_0_8_13  out_degree_699  1
    arc_0_8_13  in_degree_730  1
    arc_0_8_13  original_T_including_depot_unload_751  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_13  arc_capacity_481  1
    load_0_8_13  free_load_conservation_704  1
    load_0_8_13  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_14  arc_capacity_483  -30
    arc_0_8_14  connected_order_arc_484  -14
    arc_0_8_14  out_degree_699  1
    arc_0_8_14  in_degree_736  1
    arc_0_8_14  original_T_including_depot_unload_751  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_14  arc_capacity_483  1
    load_0_8_14  free_load_conservation_704  1
    load_0_8_14  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_15  arc_capacity_485  -30
    arc_0_8_15  connected_order_arc_486  -14
    arc_0_8_15  out_degree_699  1
    arc_0_8_15  in_degree_742  1
    arc_0_8_15  original_T_including_depot_unload_751  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_15  arc_capacity_485  1
    load_0_8_15  free_load_conservation_704  1
    load_0_8_15  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_0  arc_capacity_487  -30
    arc_0_9_0  depot_return_or_bypass_663  1
    arc_0_9_0  out_degree_705  1
    arc_0_9_0  original_T_including_depot_unload_751  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_0  arc_capacity_487  1
    load_0_9_0  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_1  arc_capacity_488  -30
    arc_0_9_1  connected_order_arc_489  -14
    arc_0_9_1  in_degree_665  1
    arc_0_9_1  out_degree_705  1
    arc_0_9_1  original_T_including_depot_unload_751  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_1  arc_capacity_488  1
    load_0_9_1  segment_load_conservation_668  -1
    load_0_9_1  segment_prefix_lb_669  1
    load_0_9_1  segment_prefix_ub_670  1
    load_0_9_1  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_2  arc_capacity_490  -30
    arc_0_9_2  connected_order_arc_491  -14
    arc_0_9_2  in_degree_672  1
    arc_0_9_2  out_degree_705  1
    arc_0_9_2  original_T_including_depot_unload_751  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_2  arc_capacity_490  1
    load_0_9_2  segment_load_conservation_675  -1
    load_0_9_2  segment_prefix_lb_676  1
    load_0_9_2  segment_prefix_ub_677  1
    load_0_9_2  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_3  arc_capacity_492  -30
    arc_0_9_3  connected_order_arc_493  -14
    arc_0_9_3  in_degree_679  1
    arc_0_9_3  out_degree_705  1
    arc_0_9_3  original_T_including_depot_unload_751  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_3  arc_capacity_492  1
    load_0_9_3  segment_load_conservation_682  -1
    load_0_9_3  segment_prefix_lb_683  1
    load_0_9_3  segment_prefix_ub_684  1
    load_0_9_3  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_4  arc_capacity_494  -30
    arc_0_9_4  connected_order_arc_495  -14
    arc_0_9_4  in_degree_686  1
    arc_0_9_4  out_degree_705  1
    arc_0_9_4  original_T_including_depot_unload_751  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_4  arc_capacity_494  1
    load_0_9_4  segment_load_conservation_689  -1
    load_0_9_4  segment_prefix_lb_690  1
    load_0_9_4  segment_prefix_ub_691  1
    load_0_9_4  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_5  arc_capacity_496  -30
    arc_0_9_5  connected_order_arc_497  -14
    arc_0_9_5  in_degree_693  1
    arc_0_9_5  out_degree_705  1
    arc_0_9_5  original_T_including_depot_unload_751  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_5  arc_capacity_496  1
    load_0_9_5  segment_load_conservation_696  -1
    load_0_9_5  segment_prefix_lb_697  1
    load_0_9_5  segment_prefix_ub_698  1
    load_0_9_5  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_8  arc_capacity_498  -30
    arc_0_9_8  connected_order_arc_499  -14
    arc_0_9_8  in_degree_700  1
    arc_0_9_8  out_degree_705  1
    arc_0_9_8  original_T_including_depot_unload_751  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_8  arc_capacity_498  1
    load_0_9_8  free_load_conservation_704  -1
    load_0_9_8  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_10  arc_capacity_500  -30
    arc_0_9_10  connected_order_arc_501  -14
    arc_0_9_10  out_degree_705  1
    arc_0_9_10  in_degree_712  1
    arc_0_9_10  original_T_including_depot_unload_751  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_10  arc_capacity_500  1
    load_0_9_10  free_load_conservation_710  1
    load_0_9_10  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_11  arc_capacity_502  -30
    arc_0_9_11  connected_order_arc_503  -14
    arc_0_9_11  out_degree_705  1
    arc_0_9_11  in_degree_718  1
    arc_0_9_11  original_T_including_depot_unload_751  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_11  arc_capacity_502  1
    load_0_9_11  free_load_conservation_710  1
    load_0_9_11  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_12  arc_capacity_504  -30
    arc_0_9_12  connected_order_arc_505  -14
    arc_0_9_12  out_degree_705  1
    arc_0_9_12  in_degree_724  1
    arc_0_9_12  original_T_including_depot_unload_751  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_12  arc_capacity_504  1
    load_0_9_12  free_load_conservation_710  1
    load_0_9_12  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_13  arc_capacity_506  -30
    arc_0_9_13  connected_order_arc_507  -14
    arc_0_9_13  out_degree_705  1
    arc_0_9_13  in_degree_730  1
    arc_0_9_13  original_T_including_depot_unload_751  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_13  arc_capacity_506  1
    load_0_9_13  free_load_conservation_710  1
    load_0_9_13  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_14  arc_capacity_508  -30
    arc_0_9_14  connected_order_arc_509  -14
    arc_0_9_14  out_degree_705  1
    arc_0_9_14  in_degree_736  1
    arc_0_9_14  original_T_including_depot_unload_751  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_14  arc_capacity_508  1
    load_0_9_14  free_load_conservation_710  1
    load_0_9_14  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_15  arc_capacity_510  -30
    arc_0_9_15  connected_order_arc_511  -14
    arc_0_9_15  out_degree_705  1
    arc_0_9_15  in_degree_742  1
    arc_0_9_15  original_T_including_depot_unload_751  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_9_15  arc_capacity_510  1
    load_0_9_15  free_load_conservation_710  1
    load_0_9_15  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_0  arc_capacity_512  -30
    arc_0_10_0  depot_return_or_bypass_663  1
    arc_0_10_0  out_degree_711  1
    arc_0_10_0  original_T_including_depot_unload_751  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_0  arc_capacity_512  1
    load_0_10_0  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_1  arc_capacity_513  -30
    arc_0_10_1  connected_order_arc_514  -14
    arc_0_10_1  in_degree_665  1
    arc_0_10_1  out_degree_711  1
    arc_0_10_1  original_T_including_depot_unload_751  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_1  arc_capacity_513  1
    load_0_10_1  segment_load_conservation_668  -1
    load_0_10_1  segment_prefix_lb_669  1
    load_0_10_1  segment_prefix_ub_670  1
    load_0_10_1  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_2  arc_capacity_515  -30
    arc_0_10_2  connected_order_arc_516  -14
    arc_0_10_2  in_degree_672  1
    arc_0_10_2  out_degree_711  1
    arc_0_10_2  original_T_including_depot_unload_751  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_2  arc_capacity_515  1
    load_0_10_2  segment_load_conservation_675  -1
    load_0_10_2  segment_prefix_lb_676  1
    load_0_10_2  segment_prefix_ub_677  1
    load_0_10_2  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_3  arc_capacity_517  -30
    arc_0_10_3  connected_order_arc_518  -14
    arc_0_10_3  in_degree_679  1
    arc_0_10_3  out_degree_711  1
    arc_0_10_3  original_T_including_depot_unload_751  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_3  arc_capacity_517  1
    load_0_10_3  segment_load_conservation_682  -1
    load_0_10_3  segment_prefix_lb_683  1
    load_0_10_3  segment_prefix_ub_684  1
    load_0_10_3  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_4  arc_capacity_519  -30
    arc_0_10_4  connected_order_arc_520  -14
    arc_0_10_4  in_degree_686  1
    arc_0_10_4  out_degree_711  1
    arc_0_10_4  original_T_including_depot_unload_751  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_4  arc_capacity_519  1
    load_0_10_4  segment_load_conservation_689  -1
    load_0_10_4  segment_prefix_lb_690  1
    load_0_10_4  segment_prefix_ub_691  1
    load_0_10_4  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_5  arc_capacity_521  -30
    arc_0_10_5  connected_order_arc_522  -14
    arc_0_10_5  in_degree_693  1
    arc_0_10_5  out_degree_711  1
    arc_0_10_5  original_T_including_depot_unload_751  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_5  arc_capacity_521  1
    load_0_10_5  segment_load_conservation_696  -1
    load_0_10_5  segment_prefix_lb_697  1
    load_0_10_5  segment_prefix_ub_698  1
    load_0_10_5  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_8  arc_capacity_523  -30
    arc_0_10_8  connected_order_arc_524  -14
    arc_0_10_8  in_degree_700  1
    arc_0_10_8  out_degree_711  1
    arc_0_10_8  original_T_including_depot_unload_751  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_8  arc_capacity_523  1
    load_0_10_8  free_load_conservation_704  -1
    load_0_10_8  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_9  arc_capacity_525  -30
    arc_0_10_9  connected_order_arc_526  -14
    arc_0_10_9  in_degree_706  1
    arc_0_10_9  out_degree_711  1
    arc_0_10_9  original_T_including_depot_unload_751  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_9  arc_capacity_525  1
    load_0_10_9  free_load_conservation_710  -1
    load_0_10_9  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_11  arc_capacity_527  -30
    arc_0_10_11  connected_order_arc_528  -14
    arc_0_10_11  out_degree_711  1
    arc_0_10_11  in_degree_718  1
    arc_0_10_11  original_T_including_depot_unload_751  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_11  arc_capacity_527  1
    load_0_10_11  free_load_conservation_716  1
    load_0_10_11  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_12  arc_capacity_529  -30
    arc_0_10_12  connected_order_arc_530  -14
    arc_0_10_12  out_degree_711  1
    arc_0_10_12  in_degree_724  1
    arc_0_10_12  original_T_including_depot_unload_751  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_12  arc_capacity_529  1
    load_0_10_12  free_load_conservation_716  1
    load_0_10_12  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_13  arc_capacity_531  -30
    arc_0_10_13  connected_order_arc_532  -14
    arc_0_10_13  out_degree_711  1
    arc_0_10_13  in_degree_730  1
    arc_0_10_13  original_T_including_depot_unload_751  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_13  arc_capacity_531  1
    load_0_10_13  free_load_conservation_716  1
    load_0_10_13  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_14  arc_capacity_533  -30
    arc_0_10_14  connected_order_arc_534  -14
    arc_0_10_14  out_degree_711  1
    arc_0_10_14  in_degree_736  1
    arc_0_10_14  original_T_including_depot_unload_751  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_14  arc_capacity_533  1
    load_0_10_14  free_load_conservation_716  1
    load_0_10_14  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_15  arc_capacity_535  -30
    arc_0_10_15  connected_order_arc_536  -14
    arc_0_10_15  out_degree_711  1
    arc_0_10_15  in_degree_742  1
    arc_0_10_15  original_T_including_depot_unload_751  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_15  arc_capacity_535  1
    load_0_10_15  free_load_conservation_716  1
    load_0_10_15  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_0  arc_capacity_537  -30
    arc_0_11_0  depot_return_or_bypass_663  1
    arc_0_11_0  out_degree_717  1
    arc_0_11_0  original_T_including_depot_unload_751  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_0  arc_capacity_537  1
    load_0_11_0  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_1  arc_capacity_538  -30
    arc_0_11_1  connected_order_arc_539  -14
    arc_0_11_1  in_degree_665  1
    arc_0_11_1  out_degree_717  1
    arc_0_11_1  original_T_including_depot_unload_751  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_1  arc_capacity_538  1
    load_0_11_1  segment_load_conservation_668  -1
    load_0_11_1  segment_prefix_lb_669  1
    load_0_11_1  segment_prefix_ub_670  1
    load_0_11_1  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_2  arc_capacity_540  -30
    arc_0_11_2  connected_order_arc_541  -14
    arc_0_11_2  in_degree_672  1
    arc_0_11_2  out_degree_717  1
    arc_0_11_2  original_T_including_depot_unload_751  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_2  arc_capacity_540  1
    load_0_11_2  segment_load_conservation_675  -1
    load_0_11_2  segment_prefix_lb_676  1
    load_0_11_2  segment_prefix_ub_677  1
    load_0_11_2  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_3  arc_capacity_542  -30
    arc_0_11_3  connected_order_arc_543  -14
    arc_0_11_3  in_degree_679  1
    arc_0_11_3  out_degree_717  1
    arc_0_11_3  original_T_including_depot_unload_751  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_3  arc_capacity_542  1
    load_0_11_3  segment_load_conservation_682  -1
    load_0_11_3  segment_prefix_lb_683  1
    load_0_11_3  segment_prefix_ub_684  1
    load_0_11_3  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_4  arc_capacity_544  -30
    arc_0_11_4  connected_order_arc_545  -14
    arc_0_11_4  in_degree_686  1
    arc_0_11_4  out_degree_717  1
    arc_0_11_4  original_T_including_depot_unload_751  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_4  arc_capacity_544  1
    load_0_11_4  segment_load_conservation_689  -1
    load_0_11_4  segment_prefix_lb_690  1
    load_0_11_4  segment_prefix_ub_691  1
    load_0_11_4  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_5  arc_capacity_546  -30
    arc_0_11_5  connected_order_arc_547  -14
    arc_0_11_5  in_degree_693  1
    arc_0_11_5  out_degree_717  1
    arc_0_11_5  original_T_including_depot_unload_751  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_5  arc_capacity_546  1
    load_0_11_5  segment_load_conservation_696  -1
    load_0_11_5  segment_prefix_lb_697  1
    load_0_11_5  segment_prefix_ub_698  1
    load_0_11_5  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_8  arc_capacity_548  -30
    arc_0_11_8  connected_order_arc_549  -14
    arc_0_11_8  in_degree_700  1
    arc_0_11_8  out_degree_717  1
    arc_0_11_8  original_T_including_depot_unload_751  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_8  arc_capacity_548  1
    load_0_11_8  free_load_conservation_704  -1
    load_0_11_8  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_9  arc_capacity_550  -30
    arc_0_11_9  connected_order_arc_551  -14
    arc_0_11_9  in_degree_706  1
    arc_0_11_9  out_degree_717  1
    arc_0_11_9  original_T_including_depot_unload_751  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_9  arc_capacity_550  1
    load_0_11_9  free_load_conservation_710  -1
    load_0_11_9  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_10  arc_capacity_552  -30
    arc_0_11_10  connected_order_arc_553  -14
    arc_0_11_10  in_degree_712  1
    arc_0_11_10  out_degree_717  1
    arc_0_11_10  original_T_including_depot_unload_751  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_10  arc_capacity_552  1
    load_0_11_10  free_load_conservation_716  -1
    load_0_11_10  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_12  arc_capacity_554  -30
    arc_0_11_12  connected_order_arc_555  -14
    arc_0_11_12  out_degree_717  1
    arc_0_11_12  in_degree_724  1
    arc_0_11_12  original_T_including_depot_unload_751  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_12  arc_capacity_554  1
    load_0_11_12  free_load_conservation_722  1
    load_0_11_12  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_13  arc_capacity_556  -30
    arc_0_11_13  connected_order_arc_557  -14
    arc_0_11_13  out_degree_717  1
    arc_0_11_13  in_degree_730  1
    arc_0_11_13  original_T_including_depot_unload_751  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_13  arc_capacity_556  1
    load_0_11_13  free_load_conservation_722  1
    load_0_11_13  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_14  arc_capacity_558  -30
    arc_0_11_14  connected_order_arc_559  -14
    arc_0_11_14  out_degree_717  1
    arc_0_11_14  in_degree_736  1
    arc_0_11_14  original_T_including_depot_unload_751  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_14  arc_capacity_558  1
    load_0_11_14  free_load_conservation_722  1
    load_0_11_14  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_15  arc_capacity_560  -30
    arc_0_11_15  connected_order_arc_561  -14
    arc_0_11_15  out_degree_717  1
    arc_0_11_15  in_degree_742  1
    arc_0_11_15  original_T_including_depot_unload_751  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_15  arc_capacity_560  1
    load_0_11_15  free_load_conservation_722  1
    load_0_11_15  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_562  -30
    arc_0_12_0  depot_return_or_bypass_663  1
    arc_0_12_0  out_degree_723  1
    arc_0_12_0  original_T_including_depot_unload_751  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_562  1
    load_0_12_0  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_563  -30
    arc_0_12_1  connected_order_arc_564  -14
    arc_0_12_1  in_degree_665  1
    arc_0_12_1  out_degree_723  1
    arc_0_12_1  original_T_including_depot_unload_751  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_563  1
    load_0_12_1  segment_load_conservation_668  -1
    load_0_12_1  segment_prefix_lb_669  1
    load_0_12_1  segment_prefix_ub_670  1
    load_0_12_1  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_565  -30
    arc_0_12_2  connected_order_arc_566  -14
    arc_0_12_2  in_degree_672  1
    arc_0_12_2  out_degree_723  1
    arc_0_12_2  original_T_including_depot_unload_751  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_565  1
    load_0_12_2  segment_load_conservation_675  -1
    load_0_12_2  segment_prefix_lb_676  1
    load_0_12_2  segment_prefix_ub_677  1
    load_0_12_2  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_567  -30
    arc_0_12_3  connected_order_arc_568  -14
    arc_0_12_3  in_degree_679  1
    arc_0_12_3  out_degree_723  1
    arc_0_12_3  original_T_including_depot_unload_751  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_567  1
    load_0_12_3  segment_load_conservation_682  -1
    load_0_12_3  segment_prefix_lb_683  1
    load_0_12_3  segment_prefix_ub_684  1
    load_0_12_3  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_569  -30
    arc_0_12_4  connected_order_arc_570  -14
    arc_0_12_4  in_degree_686  1
    arc_0_12_4  out_degree_723  1
    arc_0_12_4  original_T_including_depot_unload_751  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_569  1
    load_0_12_4  segment_load_conservation_689  -1
    load_0_12_4  segment_prefix_lb_690  1
    load_0_12_4  segment_prefix_ub_691  1
    load_0_12_4  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_5  arc_capacity_571  -30
    arc_0_12_5  connected_order_arc_572  -14
    arc_0_12_5  in_degree_693  1
    arc_0_12_5  out_degree_723  1
    arc_0_12_5  original_T_including_depot_unload_751  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_5  arc_capacity_571  1
    load_0_12_5  segment_load_conservation_696  -1
    load_0_12_5  segment_prefix_lb_697  1
    load_0_12_5  segment_prefix_ub_698  1
    load_0_12_5  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_8  arc_capacity_573  -30
    arc_0_12_8  connected_order_arc_574  -14
    arc_0_12_8  in_degree_700  1
    arc_0_12_8  out_degree_723  1
    arc_0_12_8  original_T_including_depot_unload_751  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_8  arc_capacity_573  1
    load_0_12_8  free_load_conservation_704  -1
    load_0_12_8  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_9  arc_capacity_575  -30
    arc_0_12_9  connected_order_arc_576  -14
    arc_0_12_9  in_degree_706  1
    arc_0_12_9  out_degree_723  1
    arc_0_12_9  original_T_including_depot_unload_751  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_9  arc_capacity_575  1
    load_0_12_9  free_load_conservation_710  -1
    load_0_12_9  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_10  arc_capacity_577  -30
    arc_0_12_10  connected_order_arc_578  -14
    arc_0_12_10  in_degree_712  1
    arc_0_12_10  out_degree_723  1
    arc_0_12_10  original_T_including_depot_unload_751  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_10  arc_capacity_577  1
    load_0_12_10  free_load_conservation_716  -1
    load_0_12_10  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_11  arc_capacity_579  -30
    arc_0_12_11  connected_order_arc_580  -14
    arc_0_12_11  in_degree_718  1
    arc_0_12_11  out_degree_723  1
    arc_0_12_11  original_T_including_depot_unload_751  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_11  arc_capacity_579  1
    load_0_12_11  free_load_conservation_722  -1
    load_0_12_11  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_581  -30
    arc_0_12_13  connected_order_arc_582  -14
    arc_0_12_13  out_degree_723  1
    arc_0_12_13  in_degree_730  1
    arc_0_12_13  original_T_including_depot_unload_751  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_581  1
    load_0_12_13  free_load_conservation_728  1
    load_0_12_13  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_583  -30
    arc_0_12_14  connected_order_arc_584  -14
    arc_0_12_14  out_degree_723  1
    arc_0_12_14  in_degree_736  1
    arc_0_12_14  original_T_including_depot_unload_751  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_583  1
    load_0_12_14  free_load_conservation_728  1
    load_0_12_14  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_585  -30
    arc_0_12_15  connected_order_arc_586  -14
    arc_0_12_15  out_degree_723  1
    arc_0_12_15  in_degree_742  1
    arc_0_12_15  original_T_including_depot_unload_751  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_585  1
    load_0_12_15  free_load_conservation_728  1
    load_0_12_15  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_587  -30
    arc_0_13_0  depot_return_or_bypass_663  1
    arc_0_13_0  out_degree_729  1
    arc_0_13_0  original_T_including_depot_unload_751  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_587  1
    load_0_13_0  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_588  -30
    arc_0_13_1  connected_order_arc_589  -14
    arc_0_13_1  in_degree_665  1
    arc_0_13_1  out_degree_729  1
    arc_0_13_1  original_T_including_depot_unload_751  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_588  1
    load_0_13_1  segment_load_conservation_668  -1
    load_0_13_1  segment_prefix_lb_669  1
    load_0_13_1  segment_prefix_ub_670  1
    load_0_13_1  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_590  -30
    arc_0_13_2  connected_order_arc_591  -14
    arc_0_13_2  in_degree_672  1
    arc_0_13_2  out_degree_729  1
    arc_0_13_2  original_T_including_depot_unload_751  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_590  1
    load_0_13_2  segment_load_conservation_675  -1
    load_0_13_2  segment_prefix_lb_676  1
    load_0_13_2  segment_prefix_ub_677  1
    load_0_13_2  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_592  -30
    arc_0_13_3  connected_order_arc_593  -14
    arc_0_13_3  in_degree_679  1
    arc_0_13_3  out_degree_729  1
    arc_0_13_3  original_T_including_depot_unload_751  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_592  1
    load_0_13_3  segment_load_conservation_682  -1
    load_0_13_3  segment_prefix_lb_683  1
    load_0_13_3  segment_prefix_ub_684  1
    load_0_13_3  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_594  -30
    arc_0_13_4  connected_order_arc_595  -14
    arc_0_13_4  in_degree_686  1
    arc_0_13_4  out_degree_729  1
    arc_0_13_4  original_T_including_depot_unload_751  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_594  1
    load_0_13_4  segment_load_conservation_689  -1
    load_0_13_4  segment_prefix_lb_690  1
    load_0_13_4  segment_prefix_ub_691  1
    load_0_13_4  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_596  -30
    arc_0_13_5  connected_order_arc_597  -14
    arc_0_13_5  in_degree_693  1
    arc_0_13_5  out_degree_729  1
    arc_0_13_5  original_T_including_depot_unload_751  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_596  1
    load_0_13_5  segment_load_conservation_696  -1
    load_0_13_5  segment_prefix_lb_697  1
    load_0_13_5  segment_prefix_ub_698  1
    load_0_13_5  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_8  arc_capacity_598  -30
    arc_0_13_8  connected_order_arc_599  -14
    arc_0_13_8  in_degree_700  1
    arc_0_13_8  out_degree_729  1
    arc_0_13_8  original_T_including_depot_unload_751  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_8  arc_capacity_598  1
    load_0_13_8  free_load_conservation_704  -1
    load_0_13_8  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_9  arc_capacity_600  -30
    arc_0_13_9  connected_order_arc_601  -14
    arc_0_13_9  in_degree_706  1
    arc_0_13_9  out_degree_729  1
    arc_0_13_9  original_T_including_depot_unload_751  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_9  arc_capacity_600  1
    load_0_13_9  free_load_conservation_710  -1
    load_0_13_9  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_10  arc_capacity_602  -30
    arc_0_13_10  connected_order_arc_603  -14
    arc_0_13_10  in_degree_712  1
    arc_0_13_10  out_degree_729  1
    arc_0_13_10  original_T_including_depot_unload_751  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_10  arc_capacity_602  1
    load_0_13_10  free_load_conservation_716  -1
    load_0_13_10  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_11  arc_capacity_604  -30
    arc_0_13_11  connected_order_arc_605  -14
    arc_0_13_11  in_degree_718  1
    arc_0_13_11  out_degree_729  1
    arc_0_13_11  original_T_including_depot_unload_751  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_11  arc_capacity_604  1
    load_0_13_11  free_load_conservation_722  -1
    load_0_13_11  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_606  -30
    arc_0_13_12  connected_order_arc_607  -14
    arc_0_13_12  in_degree_724  1
    arc_0_13_12  out_degree_729  1
    arc_0_13_12  original_T_including_depot_unload_751  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_606  1
    load_0_13_12  free_load_conservation_728  -1
    load_0_13_12  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_608  -30
    arc_0_13_14  connected_order_arc_609  -14
    arc_0_13_14  out_degree_729  1
    arc_0_13_14  in_degree_736  1
    arc_0_13_14  original_T_including_depot_unload_751  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_608  1
    load_0_13_14  free_load_conservation_734  1
    load_0_13_14  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_610  -30
    arc_0_13_15  connected_order_arc_611  -14
    arc_0_13_15  out_degree_729  1
    arc_0_13_15  in_degree_742  1
    arc_0_13_15  original_T_including_depot_unload_751  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_610  1
    load_0_13_15  free_load_conservation_734  1
    load_0_13_15  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_612  -30
    arc_0_14_0  depot_return_or_bypass_663  1
    arc_0_14_0  out_degree_735  1
    arc_0_14_0  original_T_including_depot_unload_751  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_612  1
    load_0_14_0  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_613  -30
    arc_0_14_1  connected_order_arc_614  -14
    arc_0_14_1  in_degree_665  1
    arc_0_14_1  out_degree_735  1
    arc_0_14_1  original_T_including_depot_unload_751  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_613  1
    load_0_14_1  segment_load_conservation_668  -1
    load_0_14_1  segment_prefix_lb_669  1
    load_0_14_1  segment_prefix_ub_670  1
    load_0_14_1  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_615  -30
    arc_0_14_2  connected_order_arc_616  -14
    arc_0_14_2  in_degree_672  1
    arc_0_14_2  out_degree_735  1
    arc_0_14_2  original_T_including_depot_unload_751  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_615  1
    load_0_14_2  segment_load_conservation_675  -1
    load_0_14_2  segment_prefix_lb_676  1
    load_0_14_2  segment_prefix_ub_677  1
    load_0_14_2  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_617  -30
    arc_0_14_3  connected_order_arc_618  -14
    arc_0_14_3  in_degree_679  1
    arc_0_14_3  out_degree_735  1
    arc_0_14_3  original_T_including_depot_unload_751  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_617  1
    load_0_14_3  segment_load_conservation_682  -1
    load_0_14_3  segment_prefix_lb_683  1
    load_0_14_3  segment_prefix_ub_684  1
    load_0_14_3  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_619  -30
    arc_0_14_4  connected_order_arc_620  -14
    arc_0_14_4  in_degree_686  1
    arc_0_14_4  out_degree_735  1
    arc_0_14_4  original_T_including_depot_unload_751  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_619  1
    load_0_14_4  segment_load_conservation_689  -1
    load_0_14_4  segment_prefix_lb_690  1
    load_0_14_4  segment_prefix_ub_691  1
    load_0_14_4  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_621  -30
    arc_0_14_5  connected_order_arc_622  -14
    arc_0_14_5  in_degree_693  1
    arc_0_14_5  out_degree_735  1
    arc_0_14_5  original_T_including_depot_unload_751  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_621  1
    load_0_14_5  segment_load_conservation_696  -1
    load_0_14_5  segment_prefix_lb_697  1
    load_0_14_5  segment_prefix_ub_698  1
    load_0_14_5  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_8  arc_capacity_623  -30
    arc_0_14_8  connected_order_arc_624  -14
    arc_0_14_8  in_degree_700  1
    arc_0_14_8  out_degree_735  1
    arc_0_14_8  original_T_including_depot_unload_751  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_8  arc_capacity_623  1
    load_0_14_8  free_load_conservation_704  -1
    load_0_14_8  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_9  arc_capacity_625  -30
    arc_0_14_9  connected_order_arc_626  -14
    arc_0_14_9  in_degree_706  1
    arc_0_14_9  out_degree_735  1
    arc_0_14_9  original_T_including_depot_unload_751  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_9  arc_capacity_625  1
    load_0_14_9  free_load_conservation_710  -1
    load_0_14_9  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_10  arc_capacity_627  -30
    arc_0_14_10  connected_order_arc_628  -14
    arc_0_14_10  in_degree_712  1
    arc_0_14_10  out_degree_735  1
    arc_0_14_10  original_T_including_depot_unload_751  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_10  arc_capacity_627  1
    load_0_14_10  free_load_conservation_716  -1
    load_0_14_10  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_11  arc_capacity_629  -30
    arc_0_14_11  connected_order_arc_630  -14
    arc_0_14_11  in_degree_718  1
    arc_0_14_11  out_degree_735  1
    arc_0_14_11  original_T_including_depot_unload_751  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_11  arc_capacity_629  1
    load_0_14_11  free_load_conservation_722  -1
    load_0_14_11  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_631  -30
    arc_0_14_12  connected_order_arc_632  -14
    arc_0_14_12  in_degree_724  1
    arc_0_14_12  out_degree_735  1
    arc_0_14_12  original_T_including_depot_unload_751  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_631  1
    load_0_14_12  free_load_conservation_728  -1
    load_0_14_12  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_633  -30
    arc_0_14_13  connected_order_arc_634  -14
    arc_0_14_13  in_degree_730  1
    arc_0_14_13  out_degree_735  1
    arc_0_14_13  original_T_including_depot_unload_751  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_633  1
    load_0_14_13  free_load_conservation_734  -1
    load_0_14_13  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_635  -30
    arc_0_14_15  connected_order_arc_636  -14
    arc_0_14_15  out_degree_735  1
    arc_0_14_15  in_degree_742  1
    arc_0_14_15  original_T_including_depot_unload_751  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_635  1
    load_0_14_15  free_load_conservation_740  1
    load_0_14_15  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_637  -30
    arc_0_15_0  depot_return_or_bypass_663  1
    arc_0_15_0  out_degree_741  1
    arc_0_15_0  original_T_including_depot_unload_751  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_637  1
    load_0_15_0  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_638  -30
    arc_0_15_1  connected_order_arc_639  -14
    arc_0_15_1  in_degree_665  1
    arc_0_15_1  out_degree_741  1
    arc_0_15_1  original_T_including_depot_unload_751  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_638  1
    load_0_15_1  segment_load_conservation_668  -1
    load_0_15_1  segment_prefix_lb_669  1
    load_0_15_1  segment_prefix_ub_670  1
    load_0_15_1  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_640  -30
    arc_0_15_2  connected_order_arc_641  -14
    arc_0_15_2  in_degree_672  1
    arc_0_15_2  out_degree_741  1
    arc_0_15_2  original_T_including_depot_unload_751  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_640  1
    load_0_15_2  segment_load_conservation_675  -1
    load_0_15_2  segment_prefix_lb_676  1
    load_0_15_2  segment_prefix_ub_677  1
    load_0_15_2  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_642  -30
    arc_0_15_3  connected_order_arc_643  -14
    arc_0_15_3  in_degree_679  1
    arc_0_15_3  out_degree_741  1
    arc_0_15_3  original_T_including_depot_unload_751  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_642  1
    load_0_15_3  segment_load_conservation_682  -1
    load_0_15_3  segment_prefix_lb_683  1
    load_0_15_3  segment_prefix_ub_684  1
    load_0_15_3  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_644  -30
    arc_0_15_4  connected_order_arc_645  -14
    arc_0_15_4  in_degree_686  1
    arc_0_15_4  out_degree_741  1
    arc_0_15_4  original_T_including_depot_unload_751  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_644  1
    load_0_15_4  segment_load_conservation_689  -1
    load_0_15_4  segment_prefix_lb_690  1
    load_0_15_4  segment_prefix_ub_691  1
    load_0_15_4  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_646  -30
    arc_0_15_5  connected_order_arc_647  -14
    arc_0_15_5  in_degree_693  1
    arc_0_15_5  out_degree_741  1
    arc_0_15_5  original_T_including_depot_unload_751  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_646  1
    load_0_15_5  segment_load_conservation_696  -1
    load_0_15_5  segment_prefix_lb_697  1
    load_0_15_5  segment_prefix_ub_698  1
    load_0_15_5  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_8  arc_capacity_648  -30
    arc_0_15_8  connected_order_arc_649  -14
    arc_0_15_8  in_degree_700  1
    arc_0_15_8  out_degree_741  1
    arc_0_15_8  original_T_including_depot_unload_751  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_8  arc_capacity_648  1
    load_0_15_8  free_load_conservation_704  -1
    load_0_15_8  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_9  arc_capacity_650  -30
    arc_0_15_9  connected_order_arc_651  -14
    arc_0_15_9  in_degree_706  1
    arc_0_15_9  out_degree_741  1
    arc_0_15_9  original_T_including_depot_unload_751  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_15_9  arc_capacity_650  1
    load_0_15_9  free_load_conservation_710  -1
    load_0_15_9  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_10  arc_capacity_652  -30
    arc_0_15_10  connected_order_arc_653  -14
    arc_0_15_10  in_degree_712  1
    arc_0_15_10  out_degree_741  1
    arc_0_15_10  original_T_including_depot_unload_751  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_10  arc_capacity_652  1
    load_0_15_10  free_load_conservation_716  -1
    load_0_15_10  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_11  arc_capacity_654  -30
    arc_0_15_11  connected_order_arc_655  -14
    arc_0_15_11  in_degree_718  1
    arc_0_15_11  out_degree_741  1
    arc_0_15_11  original_T_including_depot_unload_751  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_11  arc_capacity_654  1
    load_0_15_11  free_load_conservation_722  -1
    load_0_15_11  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_656  -30
    arc_0_15_12  connected_order_arc_657  -14
    arc_0_15_12  in_degree_724  1
    arc_0_15_12  out_degree_741  1
    arc_0_15_12  original_T_including_depot_unload_751  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_656  1
    load_0_15_12  free_load_conservation_728  -1
    load_0_15_12  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_658  -30
    arc_0_15_13  connected_order_arc_659  -14
    arc_0_15_13  in_degree_730  1
    arc_0_15_13  out_degree_741  1
    arc_0_15_13  original_T_including_depot_unload_751  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_658  1
    load_0_15_13  free_load_conservation_734  -1
    load_0_15_13  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_660  -30
    arc_0_15_14  connected_order_arc_661  -14
    arc_0_15_14  in_degree_736  1
    arc_0_15_14  out_degree_741  1
    arc_0_15_14  original_T_including_depot_unload_751  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_660  1
    load_0_15_14  free_load_conservation_740  -1
    load_0_15_14  free_load_conservation_746  1
    visit_1_6  out_degree_955  -1
    visit_1_6  in_degree_956  -1
    visit_1_6  order_active_lb_957  -1
    visit_1_6  order_active_ub_958  -10
    order_1_6  connected_order_arc_765  -1
    order_1_6  connected_order_arc_767  -1
    order_1_6  connected_order_arc_769  -1
    order_1_6  connected_order_arc_771  -1
    order_1_6  connected_order_arc_773  -1
    order_1_6  connected_order_arc_775  -1
    order_1_6  connected_order_arc_777  -1
    order_1_6  connected_order_arc_779  -1
    order_1_6  connected_order_arc_781  -1
    order_1_6  connected_order_arc_784  1
    order_1_6  connected_order_arc_803  1
    order_1_6  connected_order_arc_822  1
    order_1_6  connected_order_arc_841  1
    order_1_6  connected_order_arc_860  1
    order_1_6  connected_order_arc_879  1
    order_1_6  connected_order_arc_898  1
    order_1_6  connected_order_arc_917  1
    order_1_6  connected_order_arc_936  1
    order_1_6  order_active_lb_957  1
    order_1_6  order_active_ub_958  1
    order_1_6  fixed_segment_relative_order_1017  -1
    visit_1_7  out_degree_962  -1
    visit_1_7  in_degree_963  -1
    visit_1_7  order_active_lb_964  -1
    visit_1_7  order_active_ub_965  -10
    order_1_7  connected_order_arc_765  1
    order_1_7  connected_order_arc_784  -1
    order_1_7  connected_order_arc_786  -1
    order_1_7  connected_order_arc_788  -1
    order_1_7  connected_order_arc_790  -1
    order_1_7  connected_order_arc_792  -1
    order_1_7  connected_order_arc_794  -1
    order_1_7  connected_order_arc_796  -1
    order_1_7  connected_order_arc_798  -1
    order_1_7  connected_order_arc_800  -1
    order_1_7  connected_order_arc_805  1
    order_1_7  connected_order_arc_824  1
    order_1_7  connected_order_arc_843  1
    order_1_7  connected_order_arc_862  1
    order_1_7  connected_order_arc_881  1
    order_1_7  connected_order_arc_900  1
    order_1_7  connected_order_arc_919  1
    order_1_7  connected_order_arc_938  1
    order_1_7  order_active_lb_964  1
    order_1_7  order_active_ub_965  1
    order_1_7  fixed_segment_relative_order_1017  1
    visit_1_8  out_degree_969  -1
    visit_1_8  in_degree_970  -1
    visit_1_8  order_active_lb_971  -1
    visit_1_8  order_active_ub_972  -10
    visit_1_8  service_visit_def_973  -1
    order_1_8  connected_order_arc_767  1
    order_1_8  connected_order_arc_786  1
    order_1_8  connected_order_arc_803  -1
    order_1_8  connected_order_arc_805  -1
    order_1_8  connected_order_arc_807  -1
    order_1_8  connected_order_arc_809  -1
    order_1_8  connected_order_arc_811  -1
    order_1_8  connected_order_arc_813  -1
    order_1_8  connected_order_arc_815  -1
    order_1_8  connected_order_arc_817  -1
    order_1_8  connected_order_arc_819  -1
    order_1_8  connected_order_arc_826  1
    order_1_8  connected_order_arc_845  1
    order_1_8  connected_order_arc_864  1
    order_1_8  connected_order_arc_883  1
    order_1_8  connected_order_arc_902  1
    order_1_8  connected_order_arc_921  1
    order_1_8  connected_order_arc_940  1
    order_1_8  order_active_lb_971  1
    order_1_8  order_active_ub_972  1
    visit_1_9  out_degree_975  -1
    visit_1_9  in_degree_976  -1
    visit_1_9  order_active_lb_977  -1
    visit_1_9  order_active_ub_978  -10
    visit_1_9  service_visit_def_979  -1
    order_1_9  connected_order_arc_769  1
    order_1_9  connected_order_arc_788  1
    order_1_9  connected_order_arc_807  1
    order_1_9  connected_order_arc_822  -1
    order_1_9  connected_order_arc_824  -1
    order_1_9  connected_order_arc_826  -1
    order_1_9  connected_order_arc_828  -1
    order_1_9  connected_order_arc_830  -1
    order_1_9  connected_order_arc_832  -1
    order_1_9  connected_order_arc_834  -1
    order_1_9  connected_order_arc_836  -1
    order_1_9  connected_order_arc_838  -1
    order_1_9  connected_order_arc_847  1
    order_1_9  connected_order_arc_866  1
    order_1_9  connected_order_arc_885  1
    order_1_9  connected_order_arc_904  1
    order_1_9  connected_order_arc_923  1
    order_1_9  connected_order_arc_942  1
    order_1_9  order_active_lb_977  1
    order_1_9  order_active_ub_978  1
    visit_1_10  out_degree_981  -1
    visit_1_10  in_degree_982  -1
    visit_1_10  order_active_lb_983  -1
    visit_1_10  order_active_ub_984  -10
    visit_1_10  service_visit_def_985  -1
    order_1_10  connected_order_arc_771  1
    order_1_10  connected_order_arc_790  1
    order_1_10  connected_order_arc_809  1
    order_1_10  connected_order_arc_828  1
    order_1_10  connected_order_arc_841  -1
    order_1_10  connected_order_arc_843  -1
    order_1_10  connected_order_arc_845  -1
    order_1_10  connected_order_arc_847  -1
    order_1_10  connected_order_arc_849  -1
    order_1_10  connected_order_arc_851  -1
    order_1_10  connected_order_arc_853  -1
    order_1_10  connected_order_arc_855  -1
    order_1_10  connected_order_arc_857  -1
    order_1_10  connected_order_arc_868  1
    order_1_10  connected_order_arc_887  1
    order_1_10  connected_order_arc_906  1
    order_1_10  connected_order_arc_925  1
    order_1_10  connected_order_arc_944  1
    order_1_10  order_active_lb_983  1
    order_1_10  order_active_ub_984  1
    visit_1_11  out_degree_987  -1
    visit_1_11  in_degree_988  -1
    visit_1_11  order_active_lb_989  -1
    visit_1_11  order_active_ub_990  -10
    visit_1_11  service_visit_def_991  -1
    order_1_11  connected_order_arc_773  1
    order_1_11  connected_order_arc_792  1
    order_1_11  connected_order_arc_811  1
    order_1_11  connected_order_arc_830  1
    order_1_11  connected_order_arc_849  1
    order_1_11  connected_order_arc_860  -1
    order_1_11  connected_order_arc_862  -1
    order_1_11  connected_order_arc_864  -1
    order_1_11  connected_order_arc_866  -1
    order_1_11  connected_order_arc_868  -1
    order_1_11  connected_order_arc_870  -1
    order_1_11  connected_order_arc_872  -1
    order_1_11  connected_order_arc_874  -1
    order_1_11  connected_order_arc_876  -1
    order_1_11  connected_order_arc_889  1
    order_1_11  connected_order_arc_908  1
    order_1_11  connected_order_arc_927  1
    order_1_11  connected_order_arc_946  1
    order_1_11  order_active_lb_989  1
    order_1_11  order_active_ub_990  1
    visit_1_12  out_degree_993  -1
    visit_1_12  in_degree_994  -1
    visit_1_12  order_active_lb_995  -1
    visit_1_12  order_active_ub_996  -10
    visit_1_12  service_visit_def_997  -1
    order_1_12  connected_order_arc_775  1
    order_1_12  connected_order_arc_794  1
    order_1_12  connected_order_arc_813  1
    order_1_12  connected_order_arc_832  1
    order_1_12  connected_order_arc_851  1
    order_1_12  connected_order_arc_870  1
    order_1_12  connected_order_arc_879  -1
    order_1_12  connected_order_arc_881  -1
    order_1_12  connected_order_arc_883  -1
    order_1_12  connected_order_arc_885  -1
    order_1_12  connected_order_arc_887  -1
    order_1_12  connected_order_arc_889  -1
    order_1_12  connected_order_arc_891  -1
    order_1_12  connected_order_arc_893  -1
    order_1_12  connected_order_arc_895  -1
    order_1_12  connected_order_arc_910  1
    order_1_12  connected_order_arc_929  1
    order_1_12  connected_order_arc_948  1
    order_1_12  order_active_lb_995  1
    order_1_12  order_active_ub_996  1
    visit_1_13  out_degree_999  -1
    visit_1_13  in_degree_1000  -1
    visit_1_13  order_active_lb_1001  -1
    visit_1_13  order_active_ub_1002  -10
    visit_1_13  service_visit_def_1003  -1
    order_1_13  connected_order_arc_777  1
    order_1_13  connected_order_arc_796  1
    order_1_13  connected_order_arc_815  1
    order_1_13  connected_order_arc_834  1
    order_1_13  connected_order_arc_853  1
    order_1_13  connected_order_arc_872  1
    order_1_13  connected_order_arc_891  1
    order_1_13  connected_order_arc_898  -1
    order_1_13  connected_order_arc_900  -1
    order_1_13  connected_order_arc_902  -1
    order_1_13  connected_order_arc_904  -1
    order_1_13  connected_order_arc_906  -1
    order_1_13  connected_order_arc_908  -1
    order_1_13  connected_order_arc_910  -1
    order_1_13  connected_order_arc_912  -1
    order_1_13  connected_order_arc_914  -1
    order_1_13  connected_order_arc_931  1
    order_1_13  connected_order_arc_950  1
    order_1_13  order_active_lb_1001  1
    order_1_13  order_active_ub_1002  1
    visit_1_14  out_degree_1005  -1
    visit_1_14  in_degree_1006  -1
    visit_1_14  order_active_lb_1007  -1
    visit_1_14  order_active_ub_1008  -10
    visit_1_14  service_visit_def_1009  -1
    order_1_14  connected_order_arc_779  1
    order_1_14  connected_order_arc_798  1
    order_1_14  connected_order_arc_817  1
    order_1_14  connected_order_arc_836  1
    order_1_14  connected_order_arc_855  1
    order_1_14  connected_order_arc_874  1
    order_1_14  connected_order_arc_893  1
    order_1_14  connected_order_arc_912  1
    order_1_14  connected_order_arc_917  -1
    order_1_14  connected_order_arc_919  -1
    order_1_14  connected_order_arc_921  -1
    order_1_14  connected_order_arc_923  -1
    order_1_14  connected_order_arc_925  -1
    order_1_14  connected_order_arc_927  -1
    order_1_14  connected_order_arc_929  -1
    order_1_14  connected_order_arc_931  -1
    order_1_14  connected_order_arc_933  -1
    order_1_14  connected_order_arc_952  1
    order_1_14  order_active_lb_1007  1
    order_1_14  order_active_ub_1008  1
    visit_1_15  out_degree_1011  -1
    visit_1_15  in_degree_1012  -1
    visit_1_15  order_active_lb_1013  -1
    visit_1_15  order_active_ub_1014  -10
    visit_1_15  service_visit_def_1015  -1
    order_1_15  connected_order_arc_781  1
    order_1_15  connected_order_arc_800  1
    order_1_15  connected_order_arc_819  1
    order_1_15  connected_order_arc_838  1
    order_1_15  connected_order_arc_857  1
    order_1_15  connected_order_arc_876  1
    order_1_15  connected_order_arc_895  1
    order_1_15  connected_order_arc_914  1
    order_1_15  connected_order_arc_933  1
    order_1_15  connected_order_arc_936  -1
    order_1_15  connected_order_arc_938  -1
    order_1_15  connected_order_arc_940  -1
    order_1_15  connected_order_arc_942  -1
    order_1_15  connected_order_arc_944  -1
    order_1_15  connected_order_arc_946  -1
    order_1_15  connected_order_arc_948  -1
    order_1_15  connected_order_arc_950  -1
    order_1_15  connected_order_arc_952  -1
    order_1_15  order_active_lb_1013  1
    order_1_15  order_active_ub_1014  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_752  -30
    arc_1_0_0  depot_departure_or_bypass_953  1
    arc_1_0_0  depot_return_or_bypass_954  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_753  -30
    arc_1_0_6  depot_departure_or_bypass_953  1
    arc_1_0_6  in_degree_956  1
    arc_1_0_6  original_T_including_depot_unload_1018  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_753  1
    load_1_0_6  segment_load_conservation_959  -1
    load_1_0_6  segment_prefix_lb_960  1
    load_1_0_6  segment_prefix_ub_961  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_754  -30
    arc_1_0_7  depot_departure_or_bypass_953  1
    arc_1_0_7  in_degree_963  1
    arc_1_0_7  original_T_including_depot_unload_1018  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_754  1
    load_1_0_7  segment_load_conservation_966  -1
    load_1_0_7  segment_prefix_lb_967  1
    load_1_0_7  segment_prefix_ub_968  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_755  -30
    arc_1_0_8  depot_departure_or_bypass_953  1
    arc_1_0_8  in_degree_970  1
    arc_1_0_8  original_T_including_depot_unload_1018  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_755  1
    load_1_0_8  free_load_conservation_974  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_756  -30
    arc_1_0_9  depot_departure_or_bypass_953  1
    arc_1_0_9  in_degree_976  1
    arc_1_0_9  original_T_including_depot_unload_1018  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_756  1
    load_1_0_9  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_757  -30
    arc_1_0_10  depot_departure_or_bypass_953  1
    arc_1_0_10  in_degree_982  1
    arc_1_0_10  original_T_including_depot_unload_1018  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_757  1
    load_1_0_10  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_758  -30
    arc_1_0_11  depot_departure_or_bypass_953  1
    arc_1_0_11  in_degree_988  1
    arc_1_0_11  original_T_including_depot_unload_1018  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_758  1
    load_1_0_11  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_759  -30
    arc_1_0_12  depot_departure_or_bypass_953  1
    arc_1_0_12  in_degree_994  1
    arc_1_0_12  original_T_including_depot_unload_1018  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_759  1
    load_1_0_12  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_760  -30
    arc_1_0_13  depot_departure_or_bypass_953  1
    arc_1_0_13  in_degree_1000  1
    arc_1_0_13  original_T_including_depot_unload_1018  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_760  1
    load_1_0_13  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_761  -30
    arc_1_0_14  depot_departure_or_bypass_953  1
    arc_1_0_14  in_degree_1006  1
    arc_1_0_14  original_T_including_depot_unload_1018  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_761  1
    load_1_0_14  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_762  -30
    arc_1_0_15  depot_departure_or_bypass_953  1
    arc_1_0_15  in_degree_1012  1
    arc_1_0_15  original_T_including_depot_unload_1018  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_762  1
    load_1_0_15  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_763  -30
    arc_1_6_0  depot_return_or_bypass_954  1
    arc_1_6_0  out_degree_955  1
    arc_1_6_0  original_T_including_depot_unload_1018  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_763  1
    load_1_6_0  segment_load_conservation_959  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_764  -30
    arc_1_6_7  connected_order_arc_765  -11
    arc_1_6_7  out_degree_955  1
    arc_1_6_7  in_degree_963  1
    arc_1_6_7  original_T_including_depot_unload_1018  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_764  1
    load_1_6_7  segment_load_conservation_959  1
    load_1_6_7  segment_load_conservation_966  -1
    load_1_6_7  segment_prefix_lb_967  1
    load_1_6_7  segment_prefix_ub_968  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_766  -30
    arc_1_6_8  connected_order_arc_767  -11
    arc_1_6_8  out_degree_955  1
    arc_1_6_8  in_degree_970  1
    arc_1_6_8  original_T_including_depot_unload_1018  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_766  1
    load_1_6_8  segment_load_conservation_959  1
    load_1_6_8  free_load_conservation_974  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_768  -30
    arc_1_6_9  connected_order_arc_769  -11
    arc_1_6_9  out_degree_955  1
    arc_1_6_9  in_degree_976  1
    arc_1_6_9  original_T_including_depot_unload_1018  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_768  1
    load_1_6_9  segment_load_conservation_959  1
    load_1_6_9  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_10  arc_capacity_770  -30
    arc_1_6_10  connected_order_arc_771  -11
    arc_1_6_10  out_degree_955  1
    arc_1_6_10  in_degree_982  1
    arc_1_6_10  original_T_including_depot_unload_1018  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_10  arc_capacity_770  1
    load_1_6_10  segment_load_conservation_959  1
    load_1_6_10  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_11  arc_capacity_772  -30
    arc_1_6_11  connected_order_arc_773  -11
    arc_1_6_11  out_degree_955  1
    arc_1_6_11  in_degree_988  1
    arc_1_6_11  original_T_including_depot_unload_1018  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_11  arc_capacity_772  1
    load_1_6_11  segment_load_conservation_959  1
    load_1_6_11  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_12  arc_capacity_774  -30
    arc_1_6_12  connected_order_arc_775  -11
    arc_1_6_12  out_degree_955  1
    arc_1_6_12  in_degree_994  1
    arc_1_6_12  original_T_including_depot_unload_1018  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_12  arc_capacity_774  1
    load_1_6_12  segment_load_conservation_959  1
    load_1_6_12  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_776  -30
    arc_1_6_13  connected_order_arc_777  -11
    arc_1_6_13  out_degree_955  1
    arc_1_6_13  in_degree_1000  1
    arc_1_6_13  original_T_including_depot_unload_1018  1.8739441025189553e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_776  1
    load_1_6_13  segment_load_conservation_959  1
    load_1_6_13  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_778  -30
    arc_1_6_14  connected_order_arc_779  -11
    arc_1_6_14  out_degree_955  1
    arc_1_6_14  in_degree_1006  1
    arc_1_6_14  original_T_including_depot_unload_1018  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_778  1
    load_1_6_14  segment_load_conservation_959  1
    load_1_6_14  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_780  -30
    arc_1_6_15  connected_order_arc_781  -11
    arc_1_6_15  out_degree_955  1
    arc_1_6_15  in_degree_1012  1
    arc_1_6_15  original_T_including_depot_unload_1018  1.9740618091449423e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_780  1
    load_1_6_15  segment_load_conservation_959  1
    load_1_6_15  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_782  -30
    arc_1_7_0  depot_return_or_bypass_954  1
    arc_1_7_0  out_degree_962  1
    arc_1_7_0  original_T_including_depot_unload_1018  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_782  1
    load_1_7_0  segment_load_conservation_966  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_783  -30
    arc_1_7_6  connected_order_arc_784  -11
    arc_1_7_6  in_degree_956  1
    arc_1_7_6  out_degree_962  1
    arc_1_7_6  original_T_including_depot_unload_1018  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_783  1
    load_1_7_6  segment_load_conservation_959  -1
    load_1_7_6  segment_prefix_lb_960  1
    load_1_7_6  segment_prefix_ub_961  1
    load_1_7_6  segment_load_conservation_966  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_785  -30
    arc_1_7_8  connected_order_arc_786  -11
    arc_1_7_8  out_degree_962  1
    arc_1_7_8  in_degree_970  1
    arc_1_7_8  original_T_including_depot_unload_1018  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_785  1
    load_1_7_8  segment_load_conservation_966  1
    load_1_7_8  free_load_conservation_974  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_787  -30
    arc_1_7_9  connected_order_arc_788  -11
    arc_1_7_9  out_degree_962  1
    arc_1_7_9  in_degree_976  1
    arc_1_7_9  original_T_including_depot_unload_1018  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_787  1
    load_1_7_9  segment_load_conservation_966  1
    load_1_7_9  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_789  -30
    arc_1_7_10  connected_order_arc_790  -11
    arc_1_7_10  out_degree_962  1
    arc_1_7_10  in_degree_982  1
    arc_1_7_10  original_T_including_depot_unload_1018  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_789  1
    load_1_7_10  segment_load_conservation_966  1
    load_1_7_10  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_11  arc_capacity_791  -30
    arc_1_7_11  connected_order_arc_792  -11
    arc_1_7_11  out_degree_962  1
    arc_1_7_11  in_degree_988  1
    arc_1_7_11  original_T_including_depot_unload_1018  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_11  arc_capacity_791  1
    load_1_7_11  segment_load_conservation_966  1
    load_1_7_11  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_793  -30
    arc_1_7_12  connected_order_arc_794  -11
    arc_1_7_12  out_degree_962  1
    arc_1_7_12  in_degree_994  1
    arc_1_7_12  original_T_including_depot_unload_1018  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_793  1
    load_1_7_12  segment_load_conservation_966  1
    load_1_7_12  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_795  -30
    arc_1_7_13  connected_order_arc_796  -11
    arc_1_7_13  out_degree_962  1
    arc_1_7_13  in_degree_1000  1
    arc_1_7_13  original_T_including_depot_unload_1018  1.8467456333549035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_795  1
    load_1_7_13  segment_load_conservation_966  1
    load_1_7_13  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_797  -30
    arc_1_7_14  connected_order_arc_798  -11
    arc_1_7_14  out_degree_962  1
    arc_1_7_14  in_degree_1006  1
    arc_1_7_14  original_T_including_depot_unload_1018  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_797  1
    load_1_7_14  segment_load_conservation_966  1
    load_1_7_14  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_799  -30
    arc_1_7_15  connected_order_arc_800  -11
    arc_1_7_15  out_degree_962  1
    arc_1_7_15  in_degree_1012  1
    arc_1_7_15  original_T_including_depot_unload_1018  1.9548039027038737e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_799  1
    load_1_7_15  segment_load_conservation_966  1
    load_1_7_15  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_801  -30
    arc_1_8_0  depot_return_or_bypass_954  1
    arc_1_8_0  out_degree_969  1
    arc_1_8_0  original_T_including_depot_unload_1018  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_801  1
    load_1_8_0  free_load_conservation_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_802  -30
    arc_1_8_6  connected_order_arc_803  -11
    arc_1_8_6  in_degree_956  1
    arc_1_8_6  out_degree_969  1
    arc_1_8_6  original_T_including_depot_unload_1018  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_802  1
    load_1_8_6  segment_load_conservation_959  -1
    load_1_8_6  segment_prefix_lb_960  1
    load_1_8_6  segment_prefix_ub_961  1
    load_1_8_6  free_load_conservation_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_804  -30
    arc_1_8_7  connected_order_arc_805  -11
    arc_1_8_7  in_degree_963  1
    arc_1_8_7  out_degree_969  1
    arc_1_8_7  original_T_including_depot_unload_1018  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_804  1
    load_1_8_7  segment_load_conservation_966  -1
    load_1_8_7  segment_prefix_lb_967  1
    load_1_8_7  segment_prefix_ub_968  1
    load_1_8_7  free_load_conservation_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_806  -30
    arc_1_8_9  connected_order_arc_807  -11
    arc_1_8_9  out_degree_969  1
    arc_1_8_9  in_degree_976  1
    arc_1_8_9  original_T_including_depot_unload_1018  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_806  1
    load_1_8_9  free_load_conservation_974  1
    load_1_8_9  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_808  -30
    arc_1_8_10  connected_order_arc_809  -11
    arc_1_8_10  out_degree_969  1
    arc_1_8_10  in_degree_982  1
    arc_1_8_10  original_T_including_depot_unload_1018  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_808  1
    load_1_8_10  free_load_conservation_974  1
    load_1_8_10  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_11  arc_capacity_810  -30
    arc_1_8_11  connected_order_arc_811  -11
    arc_1_8_11  out_degree_969  1
    arc_1_8_11  in_degree_988  1
    arc_1_8_11  original_T_including_depot_unload_1018  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_11  arc_capacity_810  1
    load_1_8_11  free_load_conservation_974  1
    load_1_8_11  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_812  -30
    arc_1_8_12  connected_order_arc_813  -11
    arc_1_8_12  out_degree_969  1
    arc_1_8_12  in_degree_994  1
    arc_1_8_12  original_T_including_depot_unload_1018  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_812  1
    load_1_8_12  free_load_conservation_974  1
    load_1_8_12  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_814  -30
    arc_1_8_13  connected_order_arc_815  -11
    arc_1_8_13  out_degree_969  1
    arc_1_8_13  in_degree_1000  1
    arc_1_8_13  original_T_including_depot_unload_1018  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_814  1
    load_1_8_13  free_load_conservation_974  1
    load_1_8_13  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_816  -30
    arc_1_8_14  connected_order_arc_817  -11
    arc_1_8_14  out_degree_969  1
    arc_1_8_14  in_degree_1006  1
    arc_1_8_14  original_T_including_depot_unload_1018  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_816  1
    load_1_8_14  free_load_conservation_974  1
    load_1_8_14  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_818  -30
    arc_1_8_15  connected_order_arc_819  -11
    arc_1_8_15  out_degree_969  1
    arc_1_8_15  in_degree_1012  1
    arc_1_8_15  original_T_including_depot_unload_1018  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_818  1
    load_1_8_15  free_load_conservation_974  1
    load_1_8_15  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_820  -30
    arc_1_9_0  depot_return_or_bypass_954  1
    arc_1_9_0  out_degree_975  1
    arc_1_9_0  original_T_including_depot_unload_1018  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_820  1
    load_1_9_0  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_821  -30
    arc_1_9_6  connected_order_arc_822  -11
    arc_1_9_6  in_degree_956  1
    arc_1_9_6  out_degree_975  1
    arc_1_9_6  original_T_including_depot_unload_1018  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_821  1
    load_1_9_6  segment_load_conservation_959  -1
    load_1_9_6  segment_prefix_lb_960  1
    load_1_9_6  segment_prefix_ub_961  1
    load_1_9_6  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_823  -30
    arc_1_9_7  connected_order_arc_824  -11
    arc_1_9_7  in_degree_963  1
    arc_1_9_7  out_degree_975  1
    arc_1_9_7  original_T_including_depot_unload_1018  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_823  1
    load_1_9_7  segment_load_conservation_966  -1
    load_1_9_7  segment_prefix_lb_967  1
    load_1_9_7  segment_prefix_ub_968  1
    load_1_9_7  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_825  -30
    arc_1_9_8  connected_order_arc_826  -11
    arc_1_9_8  in_degree_970  1
    arc_1_9_8  out_degree_975  1
    arc_1_9_8  original_T_including_depot_unload_1018  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_825  1
    load_1_9_8  free_load_conservation_974  -1
    load_1_9_8  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_827  -30
    arc_1_9_10  connected_order_arc_828  -11
    arc_1_9_10  out_degree_975  1
    arc_1_9_10  in_degree_982  1
    arc_1_9_10  original_T_including_depot_unload_1018  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_827  1
    load_1_9_10  free_load_conservation_980  1
    load_1_9_10  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_829  -30
    arc_1_9_11  connected_order_arc_830  -11
    arc_1_9_11  out_degree_975  1
    arc_1_9_11  in_degree_988  1
    arc_1_9_11  original_T_including_depot_unload_1018  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_829  1
    load_1_9_11  free_load_conservation_980  1
    load_1_9_11  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_12  arc_capacity_831  -30
    arc_1_9_12  connected_order_arc_832  -11
    arc_1_9_12  out_degree_975  1
    arc_1_9_12  in_degree_994  1
    arc_1_9_12  original_T_including_depot_unload_1018  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_12  arc_capacity_831  1
    load_1_9_12  free_load_conservation_980  1
    load_1_9_12  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_833  -30
    arc_1_9_13  connected_order_arc_834  -11
    arc_1_9_13  out_degree_975  1
    arc_1_9_13  in_degree_1000  1
    arc_1_9_13  original_T_including_depot_unload_1018  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_833  1
    load_1_9_13  free_load_conservation_980  1
    load_1_9_13  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_835  -30
    arc_1_9_14  connected_order_arc_836  -11
    arc_1_9_14  out_degree_975  1
    arc_1_9_14  in_degree_1006  1
    arc_1_9_14  original_T_including_depot_unload_1018  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_835  1
    load_1_9_14  free_load_conservation_980  1
    load_1_9_14  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_837  -30
    arc_1_9_15  connected_order_arc_838  -11
    arc_1_9_15  out_degree_975  1
    arc_1_9_15  in_degree_1012  1
    arc_1_9_15  original_T_including_depot_unload_1018  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_837  1
    load_1_9_15  free_load_conservation_980  1
    load_1_9_15  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_839  -30
    arc_1_10_0  depot_return_or_bypass_954  1
    arc_1_10_0  out_degree_981  1
    arc_1_10_0  original_T_including_depot_unload_1018  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_839  1
    load_1_10_0  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_6  arc_capacity_840  -30
    arc_1_10_6  connected_order_arc_841  -11
    arc_1_10_6  in_degree_956  1
    arc_1_10_6  out_degree_981  1
    arc_1_10_6  original_T_including_depot_unload_1018  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_6  arc_capacity_840  1
    load_1_10_6  segment_load_conservation_959  -1
    load_1_10_6  segment_prefix_lb_960  1
    load_1_10_6  segment_prefix_ub_961  1
    load_1_10_6  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_842  -30
    arc_1_10_7  connected_order_arc_843  -11
    arc_1_10_7  in_degree_963  1
    arc_1_10_7  out_degree_981  1
    arc_1_10_7  original_T_including_depot_unload_1018  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_842  1
    load_1_10_7  segment_load_conservation_966  -1
    load_1_10_7  segment_prefix_lb_967  1
    load_1_10_7  segment_prefix_ub_968  1
    load_1_10_7  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_844  -30
    arc_1_10_8  connected_order_arc_845  -11
    arc_1_10_8  in_degree_970  1
    arc_1_10_8  out_degree_981  1
    arc_1_10_8  original_T_including_depot_unload_1018  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_844  1
    load_1_10_8  free_load_conservation_974  -1
    load_1_10_8  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_846  -30
    arc_1_10_9  connected_order_arc_847  -11
    arc_1_10_9  in_degree_976  1
    arc_1_10_9  out_degree_981  1
    arc_1_10_9  original_T_including_depot_unload_1018  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_846  1
    load_1_10_9  free_load_conservation_980  -1
    load_1_10_9  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_848  -30
    arc_1_10_11  connected_order_arc_849  -11
    arc_1_10_11  out_degree_981  1
    arc_1_10_11  in_degree_988  1
    arc_1_10_11  original_T_including_depot_unload_1018  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_848  1
    load_1_10_11  free_load_conservation_986  1
    load_1_10_11  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_12  arc_capacity_850  -30
    arc_1_10_12  connected_order_arc_851  -11
    arc_1_10_12  out_degree_981  1
    arc_1_10_12  in_degree_994  1
    arc_1_10_12  original_T_including_depot_unload_1018  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_12  arc_capacity_850  1
    load_1_10_12  free_load_conservation_986  1
    load_1_10_12  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_13  arc_capacity_852  -30
    arc_1_10_13  connected_order_arc_853  -11
    arc_1_10_13  out_degree_981  1
    arc_1_10_13  in_degree_1000  1
    arc_1_10_13  original_T_including_depot_unload_1018  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_13  arc_capacity_852  1
    load_1_10_13  free_load_conservation_986  1
    load_1_10_13  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_854  -30
    arc_1_10_14  connected_order_arc_855  -11
    arc_1_10_14  out_degree_981  1
    arc_1_10_14  in_degree_1006  1
    arc_1_10_14  original_T_including_depot_unload_1018  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_854  1
    load_1_10_14  free_load_conservation_986  1
    load_1_10_14  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_856  -30
    arc_1_10_15  connected_order_arc_857  -11
    arc_1_10_15  out_degree_981  1
    arc_1_10_15  in_degree_1012  1
    arc_1_10_15  original_T_including_depot_unload_1018  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_856  1
    load_1_10_15  free_load_conservation_986  1
    load_1_10_15  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_858  -30
    arc_1_11_0  depot_return_or_bypass_954  1
    arc_1_11_0  out_degree_987  1
    arc_1_11_0  original_T_including_depot_unload_1018  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_858  1
    load_1_11_0  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_6  arc_capacity_859  -30
    arc_1_11_6  connected_order_arc_860  -11
    arc_1_11_6  in_degree_956  1
    arc_1_11_6  out_degree_987  1
    arc_1_11_6  original_T_including_depot_unload_1018  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_6  arc_capacity_859  1
    load_1_11_6  segment_load_conservation_959  -1
    load_1_11_6  segment_prefix_lb_960  1
    load_1_11_6  segment_prefix_ub_961  1
    load_1_11_6  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_7  arc_capacity_861  -30
    arc_1_11_7  connected_order_arc_862  -11
    arc_1_11_7  in_degree_963  1
    arc_1_11_7  out_degree_987  1
    arc_1_11_7  original_T_including_depot_unload_1018  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_7  arc_capacity_861  1
    load_1_11_7  segment_load_conservation_966  -1
    load_1_11_7  segment_prefix_lb_967  1
    load_1_11_7  segment_prefix_ub_968  1
    load_1_11_7  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_8  arc_capacity_863  -30
    arc_1_11_8  connected_order_arc_864  -11
    arc_1_11_8  in_degree_970  1
    arc_1_11_8  out_degree_987  1
    arc_1_11_8  original_T_including_depot_unload_1018  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_8  arc_capacity_863  1
    load_1_11_8  free_load_conservation_974  -1
    load_1_11_8  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_865  -30
    arc_1_11_9  connected_order_arc_866  -11
    arc_1_11_9  in_degree_976  1
    arc_1_11_9  out_degree_987  1
    arc_1_11_9  original_T_including_depot_unload_1018  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_865  1
    load_1_11_9  free_load_conservation_980  -1
    load_1_11_9  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_867  -30
    arc_1_11_10  connected_order_arc_868  -11
    arc_1_11_10  in_degree_982  1
    arc_1_11_10  out_degree_987  1
    arc_1_11_10  original_T_including_depot_unload_1018  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_867  1
    load_1_11_10  free_load_conservation_986  -1
    load_1_11_10  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_12  arc_capacity_869  -30
    arc_1_11_12  connected_order_arc_870  -11
    arc_1_11_12  out_degree_987  1
    arc_1_11_12  in_degree_994  1
    arc_1_11_12  original_T_including_depot_unload_1018  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_12  arc_capacity_869  1
    load_1_11_12  free_load_conservation_992  1
    load_1_11_12  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_13  arc_capacity_871  -30
    arc_1_11_13  connected_order_arc_872  -11
    arc_1_11_13  out_degree_987  1
    arc_1_11_13  in_degree_1000  1
    arc_1_11_13  original_T_including_depot_unload_1018  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_13  arc_capacity_871  1
    load_1_11_13  free_load_conservation_992  1
    load_1_11_13  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_14  arc_capacity_873  -30
    arc_1_11_14  connected_order_arc_874  -11
    arc_1_11_14  out_degree_987  1
    arc_1_11_14  in_degree_1006  1
    arc_1_11_14  original_T_including_depot_unload_1018  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_14  arc_capacity_873  1
    load_1_11_14  free_load_conservation_992  1
    load_1_11_14  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_15  arc_capacity_875  -30
    arc_1_11_15  connected_order_arc_876  -11
    arc_1_11_15  out_degree_987  1
    arc_1_11_15  in_degree_1012  1
    arc_1_11_15  original_T_including_depot_unload_1018  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_15  arc_capacity_875  1
    load_1_11_15  free_load_conservation_992  1
    load_1_11_15  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_877  -30
    arc_1_12_0  depot_return_or_bypass_954  1
    arc_1_12_0  out_degree_993  1
    arc_1_12_0  original_T_including_depot_unload_1018  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_877  1
    load_1_12_0  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_6  arc_capacity_878  -30
    arc_1_12_6  connected_order_arc_879  -11
    arc_1_12_6  in_degree_956  1
    arc_1_12_6  out_degree_993  1
    arc_1_12_6  original_T_including_depot_unload_1018  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_6  arc_capacity_878  1
    load_1_12_6  segment_load_conservation_959  -1
    load_1_12_6  segment_prefix_lb_960  1
    load_1_12_6  segment_prefix_ub_961  1
    load_1_12_6  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_880  -30
    arc_1_12_7  connected_order_arc_881  -11
    arc_1_12_7  in_degree_963  1
    arc_1_12_7  out_degree_993  1
    arc_1_12_7  original_T_including_depot_unload_1018  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_880  1
    load_1_12_7  segment_load_conservation_966  -1
    load_1_12_7  segment_prefix_lb_967  1
    load_1_12_7  segment_prefix_ub_968  1
    load_1_12_7  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_882  -30
    arc_1_12_8  connected_order_arc_883  -11
    arc_1_12_8  in_degree_970  1
    arc_1_12_8  out_degree_993  1
    arc_1_12_8  original_T_including_depot_unload_1018  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_882  1
    load_1_12_8  free_load_conservation_974  -1
    load_1_12_8  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_9  arc_capacity_884  -30
    arc_1_12_9  connected_order_arc_885  -11
    arc_1_12_9  in_degree_976  1
    arc_1_12_9  out_degree_993  1
    arc_1_12_9  original_T_including_depot_unload_1018  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_9  arc_capacity_884  1
    load_1_12_9  free_load_conservation_980  -1
    load_1_12_9  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_10  arc_capacity_886  -30
    arc_1_12_10  connected_order_arc_887  -11
    arc_1_12_10  in_degree_982  1
    arc_1_12_10  out_degree_993  1
    arc_1_12_10  original_T_including_depot_unload_1018  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_10  arc_capacity_886  1
    load_1_12_10  free_load_conservation_986  -1
    load_1_12_10  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_11  arc_capacity_888  -30
    arc_1_12_11  connected_order_arc_889  -11
    arc_1_12_11  in_degree_988  1
    arc_1_12_11  out_degree_993  1
    arc_1_12_11  original_T_including_depot_unload_1018  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_11  arc_capacity_888  1
    load_1_12_11  free_load_conservation_992  -1
    load_1_12_11  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_890  -30
    arc_1_12_13  connected_order_arc_891  -11
    arc_1_12_13  out_degree_993  1
    arc_1_12_13  in_degree_1000  1
    arc_1_12_13  original_T_including_depot_unload_1018  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_890  1
    load_1_12_13  free_load_conservation_998  1
    load_1_12_13  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_892  -30
    arc_1_12_14  connected_order_arc_893  -11
    arc_1_12_14  out_degree_993  1
    arc_1_12_14  in_degree_1006  1
    arc_1_12_14  original_T_including_depot_unload_1018  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_892  1
    load_1_12_14  free_load_conservation_998  1
    load_1_12_14  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_894  -30
    arc_1_12_15  connected_order_arc_895  -11
    arc_1_12_15  out_degree_993  1
    arc_1_12_15  in_degree_1012  1
    arc_1_12_15  original_T_including_depot_unload_1018  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_894  1
    load_1_12_15  free_load_conservation_998  1
    load_1_12_15  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_896  -30
    arc_1_13_0  depot_return_or_bypass_954  1
    arc_1_13_0  out_degree_999  1
    arc_1_13_0  original_T_including_depot_unload_1018  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_896  1
    load_1_13_0  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_897  -30
    arc_1_13_6  connected_order_arc_898  -11
    arc_1_13_6  in_degree_956  1
    arc_1_13_6  out_degree_999  1
    arc_1_13_6  original_T_including_depot_unload_1018  1.8739441025189553e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_897  1
    load_1_13_6  segment_load_conservation_959  -1
    load_1_13_6  segment_prefix_lb_960  1
    load_1_13_6  segment_prefix_ub_961  1
    load_1_13_6  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_899  -30
    arc_1_13_7  connected_order_arc_900  -11
    arc_1_13_7  in_degree_963  1
    arc_1_13_7  out_degree_999  1
    arc_1_13_7  original_T_including_depot_unload_1018  1.8467456333549035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_899  1
    load_1_13_7  segment_load_conservation_966  -1
    load_1_13_7  segment_prefix_lb_967  1
    load_1_13_7  segment_prefix_ub_968  1
    load_1_13_7  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_901  -30
    arc_1_13_8  connected_order_arc_902  -11
    arc_1_13_8  in_degree_970  1
    arc_1_13_8  out_degree_999  1
    arc_1_13_8  original_T_including_depot_unload_1018  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_901  1
    load_1_13_8  free_load_conservation_974  -1
    load_1_13_8  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_903  -30
    arc_1_13_9  connected_order_arc_904  -11
    arc_1_13_9  in_degree_976  1
    arc_1_13_9  out_degree_999  1
    arc_1_13_9  original_T_including_depot_unload_1018  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_903  1
    load_1_13_9  free_load_conservation_980  -1
    load_1_13_9  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_10  arc_capacity_905  -30
    arc_1_13_10  connected_order_arc_906  -11
    arc_1_13_10  in_degree_982  1
    arc_1_13_10  out_degree_999  1
    arc_1_13_10  original_T_including_depot_unload_1018  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_10  arc_capacity_905  1
    load_1_13_10  free_load_conservation_986  -1
    load_1_13_10  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_11  arc_capacity_907  -30
    arc_1_13_11  connected_order_arc_908  -11
    arc_1_13_11  in_degree_988  1
    arc_1_13_11  out_degree_999  1
    arc_1_13_11  original_T_including_depot_unload_1018  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_11  arc_capacity_907  1
    load_1_13_11  free_load_conservation_992  -1
    load_1_13_11  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_909  -30
    arc_1_13_12  connected_order_arc_910  -11
    arc_1_13_12  in_degree_994  1
    arc_1_13_12  out_degree_999  1
    arc_1_13_12  original_T_including_depot_unload_1018  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_909  1
    load_1_13_12  free_load_conservation_998  -1
    load_1_13_12  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_911  -30
    arc_1_13_14  connected_order_arc_912  -11
    arc_1_13_14  out_degree_999  1
    arc_1_13_14  in_degree_1006  1
    arc_1_13_14  original_T_including_depot_unload_1018  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_911  1
    load_1_13_14  free_load_conservation_1004  1
    load_1_13_14  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_913  -30
    arc_1_13_15  connected_order_arc_914  -11
    arc_1_13_15  out_degree_999  1
    arc_1_13_15  in_degree_1012  1
    arc_1_13_15  original_T_including_depot_unload_1018  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_913  1
    load_1_13_15  free_load_conservation_1004  1
    load_1_13_15  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_915  -30
    arc_1_14_0  depot_return_or_bypass_954  1
    arc_1_14_0  out_degree_1005  1
    arc_1_14_0  original_T_including_depot_unload_1018  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_915  1
    load_1_14_0  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_916  -30
    arc_1_14_6  connected_order_arc_917  -11
    arc_1_14_6  in_degree_956  1
    arc_1_14_6  out_degree_1005  1
    arc_1_14_6  original_T_including_depot_unload_1018  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_916  1
    load_1_14_6  segment_load_conservation_959  -1
    load_1_14_6  segment_prefix_lb_960  1
    load_1_14_6  segment_prefix_ub_961  1
    load_1_14_6  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_918  -30
    arc_1_14_7  connected_order_arc_919  -11
    arc_1_14_7  in_degree_963  1
    arc_1_14_7  out_degree_1005  1
    arc_1_14_7  original_T_including_depot_unload_1018  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_918  1
    load_1_14_7  segment_load_conservation_966  -1
    load_1_14_7  segment_prefix_lb_967  1
    load_1_14_7  segment_prefix_ub_968  1
    load_1_14_7  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_920  -30
    arc_1_14_8  connected_order_arc_921  -11
    arc_1_14_8  in_degree_970  1
    arc_1_14_8  out_degree_1005  1
    arc_1_14_8  original_T_including_depot_unload_1018  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_920  1
    load_1_14_8  free_load_conservation_974  -1
    load_1_14_8  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_922  -30
    arc_1_14_9  connected_order_arc_923  -11
    arc_1_14_9  in_degree_976  1
    arc_1_14_9  out_degree_1005  1
    arc_1_14_9  original_T_including_depot_unload_1018  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_922  1
    load_1_14_9  free_load_conservation_980  -1
    load_1_14_9  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_924  -30
    arc_1_14_10  connected_order_arc_925  -11
    arc_1_14_10  in_degree_982  1
    arc_1_14_10  out_degree_1005  1
    arc_1_14_10  original_T_including_depot_unload_1018  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_924  1
    load_1_14_10  free_load_conservation_986  -1
    load_1_14_10  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_11  arc_capacity_926  -30
    arc_1_14_11  connected_order_arc_927  -11
    arc_1_14_11  in_degree_988  1
    arc_1_14_11  out_degree_1005  1
    arc_1_14_11  original_T_including_depot_unload_1018  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_11  arc_capacity_926  1
    load_1_14_11  free_load_conservation_992  -1
    load_1_14_11  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_928  -30
    arc_1_14_12  connected_order_arc_929  -11
    arc_1_14_12  in_degree_994  1
    arc_1_14_12  out_degree_1005  1
    arc_1_14_12  original_T_including_depot_unload_1018  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_928  1
    load_1_14_12  free_load_conservation_998  -1
    load_1_14_12  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_930  -30
    arc_1_14_13  connected_order_arc_931  -11
    arc_1_14_13  in_degree_1000  1
    arc_1_14_13  out_degree_1005  1
    arc_1_14_13  original_T_including_depot_unload_1018  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_930  1
    load_1_14_13  free_load_conservation_1004  -1
    load_1_14_13  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_932  -30
    arc_1_14_15  connected_order_arc_933  -11
    arc_1_14_15  out_degree_1005  1
    arc_1_14_15  in_degree_1012  1
    arc_1_14_15  original_T_including_depot_unload_1018  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_932  1
    load_1_14_15  free_load_conservation_1010  1
    load_1_14_15  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_934  -30
    arc_1_15_0  depot_return_or_bypass_954  1
    arc_1_15_0  out_degree_1011  1
    arc_1_15_0  original_T_including_depot_unload_1018  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_934  1
    load_1_15_0  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_935  -30
    arc_1_15_6  connected_order_arc_936  -11
    arc_1_15_6  in_degree_956  1
    arc_1_15_6  out_degree_1011  1
    arc_1_15_6  original_T_including_depot_unload_1018  1.9740618091449423e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_935  1
    load_1_15_6  segment_load_conservation_959  -1
    load_1_15_6  segment_prefix_lb_960  1
    load_1_15_6  segment_prefix_ub_961  1
    load_1_15_6  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_937  -30
    arc_1_15_7  connected_order_arc_938  -11
    arc_1_15_7  in_degree_963  1
    arc_1_15_7  out_degree_1011  1
    arc_1_15_7  original_T_including_depot_unload_1018  1.9548039027038737e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_937  1
    load_1_15_7  segment_load_conservation_966  -1
    load_1_15_7  segment_prefix_lb_967  1
    load_1_15_7  segment_prefix_ub_968  1
    load_1_15_7  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_939  -30
    arc_1_15_8  connected_order_arc_940  -11
    arc_1_15_8  in_degree_970  1
    arc_1_15_8  out_degree_1011  1
    arc_1_15_8  original_T_including_depot_unload_1018  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_939  1
    load_1_15_8  free_load_conservation_974  -1
    load_1_15_8  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_941  -30
    arc_1_15_9  connected_order_arc_942  -11
    arc_1_15_9  in_degree_976  1
    arc_1_15_9  out_degree_1011  1
    arc_1_15_9  original_T_including_depot_unload_1018  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_941  1
    load_1_15_9  free_load_conservation_980  -1
    load_1_15_9  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_943  -30
    arc_1_15_10  connected_order_arc_944  -11
    arc_1_15_10  in_degree_982  1
    arc_1_15_10  out_degree_1011  1
    arc_1_15_10  original_T_including_depot_unload_1018  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_943  1
    load_1_15_10  free_load_conservation_986  -1
    load_1_15_10  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_11  arc_capacity_945  -30
    arc_1_15_11  connected_order_arc_946  -11
    arc_1_15_11  in_degree_988  1
    arc_1_15_11  out_degree_1011  1
    arc_1_15_11  original_T_including_depot_unload_1018  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_11  arc_capacity_945  1
    load_1_15_11  free_load_conservation_992  -1
    load_1_15_11  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_947  -30
    arc_1_15_12  connected_order_arc_948  -11
    arc_1_15_12  in_degree_994  1
    arc_1_15_12  out_degree_1011  1
    arc_1_15_12  original_T_including_depot_unload_1018  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_947  1
    load_1_15_12  free_load_conservation_998  -1
    load_1_15_12  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_949  -30
    arc_1_15_13  connected_order_arc_950  -11
    arc_1_15_13  in_degree_1000  1
    arc_1_15_13  out_degree_1011  1
    arc_1_15_13  original_T_including_depot_unload_1018  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_949  1
    load_1_15_13  free_load_conservation_1004  -1
    load_1_15_13  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_951  -30
    arc_1_15_14  connected_order_arc_952  -11
    arc_1_15_14  in_degree_1006  1
    arc_1_15_14  out_degree_1011  1
    arc_1_15_14  original_T_including_depot_unload_1018  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_951  1
    load_1_15_14  free_load_conservation_1010  -1
    load_1_15_14  free_load_conservation_1016  1
RHS
    RHS1      OBJ       -3.5297342226592121e-01
    RHS1      onehot_11_32  1
    RHS1      onehot_10_39  1
    RHS1      onehot_18_74  1
    RHS1      onehot_9_81  1
    RHS1      onehot_17_118  1
    RHS1      onehot_7_143  1
    RHS1      onehot_20_178  1
    RHS1      onehot_6_185  1
    RHS1      stock_ub_189  26
    RHS1      parent_nonstrict_scope_190  6.4601166228144780e-01
    RHS1      normalization_247  1
    RHS1      connected_order_arc_339  -13
    RHS1      connected_order_arc_341  -13
    RHS1      connected_order_arc_343  -13
    RHS1      connected_order_arc_345  -13
    RHS1      connected_order_arc_347  -13
    RHS1      connected_order_arc_349  -13
    RHS1      connected_order_arc_351  -13
    RHS1      connected_order_arc_353  -13
    RHS1      connected_order_arc_355  -13
    RHS1      connected_order_arc_357  -13
    RHS1      connected_order_arc_359  -13
    RHS1      connected_order_arc_361  -13
    RHS1      connected_order_arc_364  -13
    RHS1      connected_order_arc_366  -13
    RHS1      connected_order_arc_368  -13
    RHS1      connected_order_arc_370  -13
    RHS1      connected_order_arc_372  -13
    RHS1      connected_order_arc_374  -13
    RHS1      connected_order_arc_376  -13
    RHS1      connected_order_arc_378  -13
    RHS1      connected_order_arc_380  -13
    RHS1      connected_order_arc_382  -13
    RHS1      connected_order_arc_384  -13
    RHS1      connected_order_arc_386  -13
    RHS1      connected_order_arc_389  -13
    RHS1      connected_order_arc_391  -13
    RHS1      connected_order_arc_393  -13
    RHS1      connected_order_arc_395  -13
    RHS1      connected_order_arc_397  -13
    RHS1      connected_order_arc_399  -13
    RHS1      connected_order_arc_401  -13
    RHS1      connected_order_arc_403  -13
    RHS1      connected_order_arc_405  -13
    RHS1      connected_order_arc_407  -13
    RHS1      connected_order_arc_409  -13
    RHS1      connected_order_arc_411  -13
    RHS1      connected_order_arc_414  -13
    RHS1      connected_order_arc_416  -13
    RHS1      connected_order_arc_418  -13
    RHS1      connected_order_arc_420  -13
    RHS1      connected_order_arc_422  -13
    RHS1      connected_order_arc_424  -13
    RHS1      connected_order_arc_426  -13
    RHS1      connected_order_arc_428  -13
    RHS1      connected_order_arc_430  -13
    RHS1      connected_order_arc_432  -13
    RHS1      connected_order_arc_434  -13
    RHS1      connected_order_arc_436  -13
    RHS1      connected_order_arc_439  -13
    RHS1      connected_order_arc_441  -13
    RHS1      connected_order_arc_443  -13
    RHS1      connected_order_arc_445  -13
    RHS1      connected_order_arc_447  -13
    RHS1      connected_order_arc_449  -13
    RHS1      connected_order_arc_451  -13
    RHS1      connected_order_arc_453  -13
    RHS1      connected_order_arc_455  -13
    RHS1      connected_order_arc_457  -13
    RHS1      connected_order_arc_459  -13
    RHS1      connected_order_arc_461  -13
    RHS1      connected_order_arc_464  -13
    RHS1      connected_order_arc_466  -13
    RHS1      connected_order_arc_468  -13
    RHS1      connected_order_arc_470  -13
    RHS1      connected_order_arc_472  -13
    RHS1      connected_order_arc_474  -13
    RHS1      connected_order_arc_476  -13
    RHS1      connected_order_arc_478  -13
    RHS1      connected_order_arc_480  -13
    RHS1      connected_order_arc_482  -13
    RHS1      connected_order_arc_484  -13
    RHS1      connected_order_arc_486  -13
    RHS1      connected_order_arc_489  -13
    RHS1      connected_order_arc_491  -13
    RHS1      connected_order_arc_493  -13
    RHS1      connected_order_arc_495  -13
    RHS1      connected_order_arc_497  -13
    RHS1      connected_order_arc_499  -13
    RHS1      connected_order_arc_501  -13
    RHS1      connected_order_arc_503  -13
    RHS1      connected_order_arc_505  -13
    RHS1      connected_order_arc_507  -13
    RHS1      connected_order_arc_509  -13
    RHS1      connected_order_arc_511  -13
    RHS1      connected_order_arc_514  -13
    RHS1      connected_order_arc_516  -13
    RHS1      connected_order_arc_518  -13
    RHS1      connected_order_arc_520  -13
    RHS1      connected_order_arc_522  -13
    RHS1      connected_order_arc_524  -13
    RHS1      connected_order_arc_526  -13
    RHS1      connected_order_arc_528  -13
    RHS1      connected_order_arc_530  -13
    RHS1      connected_order_arc_532  -13
    RHS1      connected_order_arc_534  -13
    RHS1      connected_order_arc_536  -13
    RHS1      connected_order_arc_539  -13
    RHS1      connected_order_arc_541  -13
    RHS1      connected_order_arc_543  -13
    RHS1      connected_order_arc_545  -13
    RHS1      connected_order_arc_547  -13
    RHS1      connected_order_arc_549  -13
    RHS1      connected_order_arc_551  -13
    RHS1      connected_order_arc_553  -13
    RHS1      connected_order_arc_555  -13
    RHS1      connected_order_arc_557  -13
    RHS1      connected_order_arc_559  -13
    RHS1      connected_order_arc_561  -13
    RHS1      connected_order_arc_564  -13
    RHS1      connected_order_arc_566  -13
    RHS1      connected_order_arc_568  -13
    RHS1      connected_order_arc_570  -13
    RHS1      connected_order_arc_572  -13
    RHS1      connected_order_arc_574  -13
    RHS1      connected_order_arc_576  -13
    RHS1      connected_order_arc_578  -13
    RHS1      connected_order_arc_580  -13
    RHS1      connected_order_arc_582  -13
    RHS1      connected_order_arc_584  -13
    RHS1      connected_order_arc_586  -13
    RHS1      connected_order_arc_589  -13
    RHS1      connected_order_arc_591  -13
    RHS1      connected_order_arc_593  -13
    RHS1      connected_order_arc_595  -13
    RHS1      connected_order_arc_597  -13
    RHS1      connected_order_arc_599  -13
    RHS1      connected_order_arc_601  -13
    RHS1      connected_order_arc_603  -13
    RHS1      connected_order_arc_605  -13
    RHS1      connected_order_arc_607  -13
    RHS1      connected_order_arc_609  -13
    RHS1      connected_order_arc_611  -13
    RHS1      connected_order_arc_614  -13
    RHS1      connected_order_arc_616  -13
    RHS1      connected_order_arc_618  -13
    RHS1      connected_order_arc_620  -13
    RHS1      connected_order_arc_622  -13
    RHS1      connected_order_arc_624  -13
    RHS1      connected_order_arc_626  -13
    RHS1      connected_order_arc_628  -13
    RHS1      connected_order_arc_630  -13
    RHS1      connected_order_arc_632  -13
    RHS1      connected_order_arc_634  -13
    RHS1      connected_order_arc_636  -13
    RHS1      connected_order_arc_639  -13
    RHS1      connected_order_arc_641  -13
    RHS1      connected_order_arc_643  -13
    RHS1      connected_order_arc_645  -13
    RHS1      connected_order_arc_647  -13
    RHS1      connected_order_arc_649  -13
    RHS1      connected_order_arc_651  -13
    RHS1      connected_order_arc_653  -13
    RHS1      connected_order_arc_655  -13
    RHS1      connected_order_arc_657  -13
    RHS1      connected_order_arc_659  -13
    RHS1      connected_order_arc_661  -13
    RHS1      depot_departure_or_bypass_662  1
    RHS1      depot_return_or_bypass_663  1
    RHS1      segment_load_conservation_668  3
    RHS1      segment_prefix_ub_670  27
    RHS1      segment_load_conservation_675  3
    RHS1      segment_prefix_ub_677  27
    RHS1      segment_load_conservation_682  -3
    RHS1      segment_prefix_lb_683  3
    RHS1      segment_prefix_ub_684  30
    RHS1      segment_load_conservation_689  4
    RHS1      segment_prefix_ub_691  26
    RHS1      segment_load_conservation_696  -1
    RHS1      segment_prefix_lb_697  1
    RHS1      segment_prefix_ub_698  30
    RHS1      fixed_segment_relative_order_747  1
    RHS1      fixed_segment_relative_order_748  1
    RHS1      fixed_segment_relative_order_749  1
    RHS1      fixed_segment_relative_order_750  1
    RHS1      original_T_including_depot_unload_751  3600
    RHS1      connected_order_arc_765  -10
    RHS1      connected_order_arc_767  -10
    RHS1      connected_order_arc_769  -10
    RHS1      connected_order_arc_771  -10
    RHS1      connected_order_arc_773  -10
    RHS1      connected_order_arc_775  -10
    RHS1      connected_order_arc_777  -10
    RHS1      connected_order_arc_779  -10
    RHS1      connected_order_arc_781  -10
    RHS1      connected_order_arc_784  -10
    RHS1      connected_order_arc_786  -10
    RHS1      connected_order_arc_788  -10
    RHS1      connected_order_arc_790  -10
    RHS1      connected_order_arc_792  -10
    RHS1      connected_order_arc_794  -10
    RHS1      connected_order_arc_796  -10
    RHS1      connected_order_arc_798  -10
    RHS1      connected_order_arc_800  -10
    RHS1      connected_order_arc_803  -10
    RHS1      connected_order_arc_805  -10
    RHS1      connected_order_arc_807  -10
    RHS1      connected_order_arc_809  -10
    RHS1      connected_order_arc_811  -10
    RHS1      connected_order_arc_813  -10
    RHS1      connected_order_arc_815  -10
    RHS1      connected_order_arc_817  -10
    RHS1      connected_order_arc_819  -10
    RHS1      connected_order_arc_822  -10
    RHS1      connected_order_arc_824  -10
    RHS1      connected_order_arc_826  -10
    RHS1      connected_order_arc_828  -10
    RHS1      connected_order_arc_830  -10
    RHS1      connected_order_arc_832  -10
    RHS1      connected_order_arc_834  -10
    RHS1      connected_order_arc_836  -10
    RHS1      connected_order_arc_838  -10
    RHS1      connected_order_arc_841  -10
    RHS1      connected_order_arc_843  -10
    RHS1      connected_order_arc_845  -10
    RHS1      connected_order_arc_847  -10
    RHS1      connected_order_arc_849  -10
    RHS1      connected_order_arc_851  -10
    RHS1      connected_order_arc_853  -10
    RHS1      connected_order_arc_855  -10
    RHS1      connected_order_arc_857  -10
    RHS1      connected_order_arc_860  -10
    RHS1      connected_order_arc_862  -10
    RHS1      connected_order_arc_864  -10
    RHS1      connected_order_arc_866  -10
    RHS1      connected_order_arc_868  -10
    RHS1      connected_order_arc_870  -10
    RHS1      connected_order_arc_872  -10
    RHS1      connected_order_arc_874  -10
    RHS1      connected_order_arc_876  -10
    RHS1      connected_order_arc_879  -10
    RHS1      connected_order_arc_881  -10
    RHS1      connected_order_arc_883  -10
    RHS1      connected_order_arc_885  -10
    RHS1      connected_order_arc_887  -10
    RHS1      connected_order_arc_889  -10
    RHS1      connected_order_arc_891  -10
    RHS1      connected_order_arc_893  -10
    RHS1      connected_order_arc_895  -10
    RHS1      connected_order_arc_898  -10
    RHS1      connected_order_arc_900  -10
    RHS1      connected_order_arc_902  -10
    RHS1      connected_order_arc_904  -10
    RHS1      connected_order_arc_906  -10
    RHS1      connected_order_arc_908  -10
    RHS1      connected_order_arc_910  -10
    RHS1      connected_order_arc_912  -10
    RHS1      connected_order_arc_914  -10
    RHS1      connected_order_arc_917  -10
    RHS1      connected_order_arc_919  -10
    RHS1      connected_order_arc_921  -10
    RHS1      connected_order_arc_923  -10
    RHS1      connected_order_arc_925  -10
    RHS1      connected_order_arc_927  -10
    RHS1      connected_order_arc_929  -10
    RHS1      connected_order_arc_931  -10
    RHS1      connected_order_arc_933  -10
    RHS1      connected_order_arc_936  -10
    RHS1      connected_order_arc_938  -10
    RHS1      connected_order_arc_940  -10
    RHS1      connected_order_arc_942  -10
    RHS1      connected_order_arc_944  -10
    RHS1      connected_order_arc_946  -10
    RHS1      connected_order_arc_948  -10
    RHS1      connected_order_arc_950  -10
    RHS1      connected_order_arc_952  -10
    RHS1      depot_departure_or_bypass_953  1
    RHS1      depot_return_or_bypass_954  1
    RHS1      segment_load_conservation_959  4
    RHS1      segment_prefix_ub_961  26
    RHS1      segment_load_conservation_966  -1
    RHS1      segment_prefix_lb_967  1
    RHS1      segment_prefix_ub_968  30
    RHS1      fixed_segment_relative_order_1017  1
    RHS1      original_T_including_depot_unload_1018  4320
BOUNDS
 LO BND1      t         0.0487568927154393
 UP BND1      t         1.2756264236914810e-01
 UP BND1      q         0.753053928089682
 BV BND1      x_11_0  
 UP BND1      w_11_0    1.2756264236914810e-01
 BV BND1      x_11_1  
 UP BND1      w_11_1    1.2756264236914810e-01
 BV BND1      x_11_2  
 UP BND1      w_11_2    1.2756264236914810e-01
 BV BND1      x_11_3  
 UP BND1      w_11_3    1.2756264236914810e-01
 BV BND1      x_11_4  
 UP BND1      w_11_4    1.2756264236914810e-01
 BV BND1      x_11_5  
 UP BND1      w_11_5    1.2756264236914810e-01
 BV BND1      x_11_6  
 UP BND1      w_11_6    1.2756264236914810e-01
 BV BND1      x_11_7  
 UP BND1      w_11_7    1.2756264236914810e-01
 BV BND1      x_11_8  
 UP BND1      w_11_8    1.2756264236914810e-01
 BV BND1      x_11_9  
 UP BND1      w_11_9    1.2756264236914810e-01
 BV BND1      x_11_10 
 UP BND1      w_11_10   1.2756264236914810e-01
 BV BND1      x_11_11 
 UP BND1      w_11_11   1.2756264236914810e-01
 BV BND1      x_11_12 
 UP BND1      w_11_12   1.2756264236914810e-01
 BV BND1      x_11_13 
 UP BND1      w_11_13   1.2756264236914810e-01
 BV BND1      x_11_14 
 UP BND1      w_11_14   1.2756264236914810e-01
 BV BND1      x_11_15 
 UP BND1      w_11_15   1.2756264236914810e-01
 UP BND1      rho_11    1
 BV BND1      x_10_0  
 UP BND1      w_10_0    1.2756264236914810e-01
 BV BND1      x_10_1  
 UP BND1      w_10_1    1.2756264236914810e-01
 UP BND1      rho_10    1
 BV BND1      x_18_0  
 UP BND1      w_18_0    1.2756264236914810e-01
 BV BND1      x_18_1  
 UP BND1      w_18_1    1.2756264236914810e-01
 BV BND1      x_18_2  
 UP BND1      w_18_2    1.2756264236914810e-01
 BV BND1      x_18_3  
 UP BND1      w_18_3    1.2756264236914810e-01
 BV BND1      x_18_4  
 UP BND1      w_18_4    1.2756264236914810e-01
 BV BND1      x_18_5  
 UP BND1      w_18_5    1.2756264236914810e-01
 BV BND1      x_18_6  
 UP BND1      w_18_6    1.2756264236914810e-01
 BV BND1      x_18_7  
 UP BND1      w_18_7    1.2756264236914810e-01
 BV BND1      x_18_8  
 UP BND1      w_18_8    1.2756264236914810e-01
 BV BND1      x_18_9  
 UP BND1      w_18_9    1.2756264236914810e-01
 BV BND1      x_18_10 
 UP BND1      w_18_10   1.2756264236914810e-01
 BV BND1      x_18_11 
 UP BND1      w_18_11   1.2756264236914810e-01
 BV BND1      x_18_12 
 UP BND1      w_18_12   1.2756264236914810e-01
 BV BND1      x_18_13 
 UP BND1      w_18_13   1.2756264236914810e-01
 BV BND1      x_18_14 
 UP BND1      w_18_14   1.2756264236914810e-01
 BV BND1      x_18_15 
 UP BND1      w_18_15   1.2756264236914810e-01
 UP BND1      rho_18    1
 BV BND1      x_9_0   
 UP BND1      w_9_0     1.2756264236914810e-01
 BV BND1      x_9_1   
 UP BND1      w_9_1     1.2756264236914810e-01
 UP BND1      rho_9     1
 BV BND1      x_17_0  
 UP BND1      w_17_0    1.2756264236914810e-01
 BV BND1      x_17_1  
 UP BND1      w_17_1    1.2756264236914810e-01
 BV BND1      x_17_2  
 UP BND1      w_17_2    1.2756264236914810e-01
 BV BND1      x_17_3  
 UP BND1      w_17_3    1.2756264236914810e-01
 BV BND1      x_17_4  
 UP BND1      w_17_4    1.2756264236914810e-01
 BV BND1      x_17_5  
 UP BND1      w_17_5    1.2756264236914810e-01
 BV BND1      x_17_6  
 UP BND1      w_17_6    1.2756264236914810e-01
 BV BND1      x_17_7  
 UP BND1      w_17_7    1.2756264236914810e-01
 BV BND1      x_17_8  
 UP BND1      w_17_8    1.2756264236914810e-01
 BV BND1      x_17_9  
 UP BND1      w_17_9    1.2756264236914810e-01
 BV BND1      x_17_10 
 UP BND1      w_17_10   1.2756264236914810e-01
 BV BND1      x_17_11 
 UP BND1      w_17_11   1.2756264236914810e-01
 BV BND1      x_17_12 
 UP BND1      w_17_12   1.2756264236914810e-01
 BV BND1      x_17_13 
 UP BND1      w_17_13   1.2756264236914810e-01
 BV BND1      x_17_14 
 UP BND1      w_17_14   1.2756264236914810e-01
 BV BND1      x_17_15 
 UP BND1      w_17_15   1.2756264236914810e-01
 BV BND1      x_17_16 
 UP BND1      w_17_16   1.2756264236914810e-01
 UP BND1      rho_17    1
 BV BND1      x_7_0   
 UP BND1      w_7_0     1.2756264236914810e-01
 BV BND1      x_7_1   
 UP BND1      w_7_1     1.2756264236914810e-01
 BV BND1      x_7_2   
 UP BND1      w_7_2     1.2756264236914810e-01
 BV BND1      x_7_3   
 UP BND1      w_7_3     1.2756264236914810e-01
 BV BND1      x_7_4   
 UP BND1      w_7_4     1.2756264236914810e-01
 BV BND1      x_7_5   
 UP BND1      w_7_5     1.2756264236914810e-01
 BV BND1      x_7_6   
 UP BND1      w_7_6     1.2756264236914810e-01
 BV BND1      x_7_7   
 UP BND1      w_7_7     1.2756264236914810e-01
 BV BND1      x_7_8   
 UP BND1      w_7_8     1.2756264236914810e-01
 BV BND1      x_7_9   
 UP BND1      w_7_9     1.2756264236914810e-01
 BV BND1      x_7_10  
 UP BND1      w_7_10    1.2756264236914810e-01
 UP BND1      rho_7     1
 BV BND1      x_20_0  
 UP BND1      w_20_0    1.2756264236914810e-01
 BV BND1      x_20_1  
 UP BND1      w_20_1    1.2756264236914810e-01
 BV BND1      x_20_2  
 UP BND1      w_20_2    1.2756264236914810e-01
 BV BND1      x_20_3  
 UP BND1      w_20_3    1.2756264236914810e-01
 BV BND1      x_20_4  
 UP BND1      w_20_4    1.2756264236914810e-01
 BV BND1      x_20_5  
 UP BND1      w_20_5    1.2756264236914810e-01
 BV BND1      x_20_6  
 UP BND1      w_20_6    1.2756264236914810e-01
 BV BND1      x_20_7  
 UP BND1      w_20_7    1.2756264236914810e-01
 BV BND1      x_20_8  
 UP BND1      w_20_8    1.2756264236914810e-01
 BV BND1      x_20_9  
 UP BND1      w_20_9    1.2756264236914810e-01
 BV BND1      x_20_10 
 UP BND1      w_20_10   1.2756264236914810e-01
 BV BND1      x_20_11 
 UP BND1      w_20_11   1.2756264236914810e-01
 BV BND1      x_20_12 
 UP BND1      w_20_12   1.2756264236914810e-01
 BV BND1      x_20_13 
 UP BND1      w_20_13   1.2756264236914810e-01
 BV BND1      x_20_14 
 UP BND1      w_20_14   1.2756264236914810e-01
 BV BND1      x_20_15 
 UP BND1      w_20_15   1.2756264236914810e-01
 UP BND1      rho_20    1
 BV BND1      x_6_0   
 UP BND1      w_6_0     1.2756264236914810e-01
 BV BND1      x_6_1   
 UP BND1      w_6_1     1.2756264236914810e-01
 UP BND1      rho_6     1
 UP BND1      a_11_10   1
 UP BND1      a_11_18   1
 UP BND1      a_11_9    1
 UP BND1      a_11_17   1
 UP BND1      a_11_7    1
 UP BND1      a_11_20   1
 UP BND1      a_11_6    1
 UP BND1      a_10_18   1
 UP BND1      a_10_9    1
 UP BND1      a_10_17   1
 UP BND1      a_10_7    1
 UP BND1      a_10_20   1
 UP BND1      a_10_6    1
 UP BND1      a_18_9    1
 UP BND1      a_18_17   1
 UP BND1      a_18_7    1
 UP BND1      a_18_20   1
 UP BND1      a_18_6    1
 UP BND1      a_9_17    1
 UP BND1      a_9_7     1
 UP BND1      a_9_20    1
 UP BND1      a_9_6     1
 UP BND1      a_17_7    1
 UP BND1      a_17_20   1
 UP BND1      a_17_6    1
 UP BND1      a_7_20    1
 UP BND1      a_7_6     1
 UP BND1      a_20_6    1
 BV BND1      service_0_11_0
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_7
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_0_11_13
 BV BND1      service_0_11_14
 BV BND1      service_0_11_15
 BV BND1      service_1_11_0
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_7
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_1_11_13
 BV BND1      service_1_11_14
 BV BND1      service_1_11_15
 BV BND1      service_0_10_1
 BV BND1      service_1_10_1
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_8
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_0_18_11
 BV BND1      service_0_18_12
 BV BND1      service_0_18_13
 BV BND1      service_0_18_14
 BV BND1      service_0_18_15
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_8
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_1_18_11
 BV BND1      service_1_18_12
 BV BND1      service_1_18_13
 BV BND1      service_1_18_14
 BV BND1      service_1_18_15
 BV BND1      service_0_9_1
 BV BND1      service_1_9_1
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_0_7_0
 BV BND1      service_0_7_2
 BV BND1      service_0_7_3
 BV BND1      service_0_7_4
 BV BND1      service_0_7_5
 BV BND1      service_0_7_6
 BV BND1      service_0_7_7
 BV BND1      service_0_7_8
 BV BND1      service_0_7_9
 BV BND1      service_0_7_10
 BV BND1      service_1_7_0
 BV BND1      service_1_7_2
 BV BND1      service_1_7_3
 BV BND1      service_1_7_4
 BV BND1      service_1_7_5
 BV BND1      service_1_7_6
 BV BND1      service_1_7_7
 BV BND1      service_1_7_8
 BV BND1      service_1_7_9
 BV BND1      service_1_7_10
 BV BND1      service_0_20_0
 BV BND1      service_0_20_1
 BV BND1      service_0_20_2
 BV BND1      service_0_20_3
 BV BND1      service_0_20_4
 BV BND1      service_0_20_5
 BV BND1      service_0_20_6
 BV BND1      service_0_20_7
 BV BND1      service_0_20_8
 BV BND1      service_0_20_9
 BV BND1      service_0_20_10
 BV BND1      service_0_20_11
 BV BND1      service_0_20_13
 BV BND1      service_0_20_14
 BV BND1      service_0_20_15
 BV BND1      service_1_20_0
 BV BND1      service_1_20_1
 BV BND1      service_1_20_2
 BV BND1      service_1_20_3
 BV BND1      service_1_20_4
 BV BND1      service_1_20_5
 BV BND1      service_1_20_6
 BV BND1      service_1_20_7
 BV BND1      service_1_20_8
 BV BND1      service_1_20_9
 BV BND1      service_1_20_10
 BV BND1      service_1_20_11
 BV BND1      service_1_20_13
 BV BND1      service_1_20_14
 BV BND1      service_1_20_15
 BV BND1      service_0_6_1
 BV BND1      service_1_6_1
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_8  1
 UP BND1      order_0_8  13
 UP BND1      visit_0_9  1
 UP BND1      order_0_9  13
 UP BND1      visit_0_10  1
 UP BND1      order_0_10  13
 UP BND1      visit_0_11  1
 UP BND1      order_0_11  13
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  13
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_8
 FX BND1      load_0_0_8  0
 BV BND1      arc_0_0_9
 FX BND1      load_0_0_9  0
 BV BND1      arc_0_0_10
 FX BND1      load_0_0_10  0
 BV BND1      arc_0_0_11
 FX BND1      load_0_0_11  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  30
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  30
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  30
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  30
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  30
 BV BND1      arc_0_1_8
 UP BND1      load_0_1_8  30
 BV BND1      arc_0_1_9
 UP BND1      load_0_1_9  30
 BV BND1      arc_0_1_10
 UP BND1      load_0_1_10  30
 BV BND1      arc_0_1_11
 UP BND1      load_0_1_11  30
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  30
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  30
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  30
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  30
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  30
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  30
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  30
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  30
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  30
 BV BND1      arc_0_2_8
 UP BND1      load_0_2_8  30
 BV BND1      arc_0_2_9
 UP BND1      load_0_2_9  30
 BV BND1      arc_0_2_10
 UP BND1      load_0_2_10  30
 BV BND1      arc_0_2_11
 UP BND1      load_0_2_11  30
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  30
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  30
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  30
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  30
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  30
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  30
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  30
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  30
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  30
 BV BND1      arc_0_3_8
 UP BND1      load_0_3_8  30
 BV BND1      arc_0_3_9
 UP BND1      load_0_3_9  30
 BV BND1      arc_0_3_10
 UP BND1      load_0_3_10  30
 BV BND1      arc_0_3_11
 UP BND1      load_0_3_11  30
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  30
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  30
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  30
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  30
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  30
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  30
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  30
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  30
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  30
 BV BND1      arc_0_4_8
 UP BND1      load_0_4_8  30
 BV BND1      arc_0_4_9
 UP BND1      load_0_4_9  30
 BV BND1      arc_0_4_10
 UP BND1      load_0_4_10  30
 BV BND1      arc_0_4_11
 UP BND1      load_0_4_11  30
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  30
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  30
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  30
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  30
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  30
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  30
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  30
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  30
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  30
 BV BND1      arc_0_5_8
 UP BND1      load_0_5_8  30
 BV BND1      arc_0_5_9
 UP BND1      load_0_5_9  30
 BV BND1      arc_0_5_10
 UP BND1      load_0_5_10  30
 BV BND1      arc_0_5_11
 UP BND1      load_0_5_11  30
 BV BND1      arc_0_5_12
 UP BND1      load_0_5_12  30
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  30
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  30
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  30
 BV BND1      arc_0_8_0
 UP BND1      load_0_8_0  30
 BV BND1      arc_0_8_1
 UP BND1      load_0_8_1  30
 BV BND1      arc_0_8_2
 UP BND1      load_0_8_2  30
 BV BND1      arc_0_8_3
 UP BND1      load_0_8_3  30
 BV BND1      arc_0_8_4
 UP BND1      load_0_8_4  30
 BV BND1      arc_0_8_5
 UP BND1      load_0_8_5  30
 BV BND1      arc_0_8_9
 UP BND1      load_0_8_9  30
 BV BND1      arc_0_8_10
 UP BND1      load_0_8_10  30
 BV BND1      arc_0_8_11
 UP BND1      load_0_8_11  30
 BV BND1      arc_0_8_12
 UP BND1      load_0_8_12  30
 BV BND1      arc_0_8_13
 UP BND1      load_0_8_13  30
 BV BND1      arc_0_8_14
 UP BND1      load_0_8_14  30
 BV BND1      arc_0_8_15
 UP BND1      load_0_8_15  30
 BV BND1      arc_0_9_0
 UP BND1      load_0_9_0  30
 BV BND1      arc_0_9_1
 UP BND1      load_0_9_1  30
 BV BND1      arc_0_9_2
 UP BND1      load_0_9_2  30
 BV BND1      arc_0_9_3
 UP BND1      load_0_9_3  30
 BV BND1      arc_0_9_4
 UP BND1      load_0_9_4  30
 BV BND1      arc_0_9_5
 UP BND1      load_0_9_5  30
 BV BND1      arc_0_9_8
 UP BND1      load_0_9_8  30
 BV BND1      arc_0_9_10
 UP BND1      load_0_9_10  30
 BV BND1      arc_0_9_11
 UP BND1      load_0_9_11  30
 BV BND1      arc_0_9_12
 UP BND1      load_0_9_12  30
 BV BND1      arc_0_9_13
 UP BND1      load_0_9_13  30
 BV BND1      arc_0_9_14
 UP BND1      load_0_9_14  30
 BV BND1      arc_0_9_15
 UP BND1      load_0_9_15  30
 BV BND1      arc_0_10_0
 UP BND1      load_0_10_0  30
 BV BND1      arc_0_10_1
 UP BND1      load_0_10_1  30
 BV BND1      arc_0_10_2
 UP BND1      load_0_10_2  30
 BV BND1      arc_0_10_3
 UP BND1      load_0_10_3  30
 BV BND1      arc_0_10_4
 UP BND1      load_0_10_4  30
 BV BND1      arc_0_10_5
 UP BND1      load_0_10_5  30
 BV BND1      arc_0_10_8
 UP BND1      load_0_10_8  30
 BV BND1      arc_0_10_9
 UP BND1      load_0_10_9  30
 BV BND1      arc_0_10_11
 UP BND1      load_0_10_11  30
 BV BND1      arc_0_10_12
 UP BND1      load_0_10_12  30
 BV BND1      arc_0_10_13
 UP BND1      load_0_10_13  30
 BV BND1      arc_0_10_14
 UP BND1      load_0_10_14  30
 BV BND1      arc_0_10_15
 UP BND1      load_0_10_15  30
 BV BND1      arc_0_11_0
 UP BND1      load_0_11_0  30
 BV BND1      arc_0_11_1
 UP BND1      load_0_11_1  30
 BV BND1      arc_0_11_2
 UP BND1      load_0_11_2  30
 BV BND1      arc_0_11_3
 UP BND1      load_0_11_3  30
 BV BND1      arc_0_11_4
 UP BND1      load_0_11_4  30
 BV BND1      arc_0_11_5
 UP BND1      load_0_11_5  30
 BV BND1      arc_0_11_8
 UP BND1      load_0_11_8  30
 BV BND1      arc_0_11_9
 UP BND1      load_0_11_9  30
 BV BND1      arc_0_11_10
 UP BND1      load_0_11_10  30
 BV BND1      arc_0_11_12
 UP BND1      load_0_11_12  30
 BV BND1      arc_0_11_13
 UP BND1      load_0_11_13  30
 BV BND1      arc_0_11_14
 UP BND1      load_0_11_14  30
 BV BND1      arc_0_11_15
 UP BND1      load_0_11_15  30
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  30
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  30
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  30
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  30
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  30
 BV BND1      arc_0_12_5
 UP BND1      load_0_12_5  30
 BV BND1      arc_0_12_8
 UP BND1      load_0_12_8  30
 BV BND1      arc_0_12_9
 UP BND1      load_0_12_9  30
 BV BND1      arc_0_12_10
 UP BND1      load_0_12_10  30
 BV BND1      arc_0_12_11
 UP BND1      load_0_12_11  30
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  30
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  30
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  30
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  30
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  30
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  30
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  30
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  30
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  30
 BV BND1      arc_0_13_8
 UP BND1      load_0_13_8  30
 BV BND1      arc_0_13_9
 UP BND1      load_0_13_9  30
 BV BND1      arc_0_13_10
 UP BND1      load_0_13_10  30
 BV BND1      arc_0_13_11
 UP BND1      load_0_13_11  30
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  30
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  30
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  30
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  30
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  30
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  30
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  30
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  30
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  30
 BV BND1      arc_0_14_8
 UP BND1      load_0_14_8  30
 BV BND1      arc_0_14_9
 UP BND1      load_0_14_9  30
 BV BND1      arc_0_14_10
 UP BND1      load_0_14_10  30
 BV BND1      arc_0_14_11
 UP BND1      load_0_14_11  30
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  30
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  30
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  30
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  30
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  30
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  30
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  30
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  30
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  30
 BV BND1      arc_0_15_8
 UP BND1      load_0_15_8  30
 BV BND1      arc_0_15_9
 UP BND1      load_0_15_9  30
 BV BND1      arc_0_15_10
 UP BND1      load_0_15_10  30
 BV BND1      arc_0_15_11
 UP BND1      load_0_15_11  30
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  30
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  30
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  30
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  10
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  10
 UP BND1      visit_1_8  1
 UP BND1      order_1_8  10
 UP BND1      visit_1_9  1
 UP BND1      order_1_9  10
 UP BND1      visit_1_10  1
 UP BND1      order_1_10  10
 UP BND1      visit_1_11  1
 UP BND1      order_1_11  10
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  10
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  10
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  10
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  10
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  30
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  30
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  30
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  30
 BV BND1      arc_1_6_10
 UP BND1      load_1_6_10  30
 BV BND1      arc_1_6_11
 UP BND1      load_1_6_11  30
 BV BND1      arc_1_6_12
 UP BND1      load_1_6_12  30
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  30
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  30
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  30
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  30
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  30
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  30
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  30
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  30
 BV BND1      arc_1_7_11
 UP BND1      load_1_7_11  30
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  30
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  30
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  30
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  30
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  30
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  30
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  30
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  30
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  30
 BV BND1      arc_1_8_11
 UP BND1      load_1_8_11  30
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  30
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  30
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  30
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  30
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  30
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  30
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  30
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  30
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  30
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  30
 BV BND1      arc_1_9_12
 UP BND1      load_1_9_12  30
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  30
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  30
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  30
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  30
 BV BND1      arc_1_10_6
 UP BND1      load_1_10_6  30
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  30
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  30
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  30
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  30
 BV BND1      arc_1_10_12
 UP BND1      load_1_10_12  30
 BV BND1      arc_1_10_13
 UP BND1      load_1_10_13  30
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  30
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  30
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  30
 BV BND1      arc_1_11_6
 UP BND1      load_1_11_6  30
 BV BND1      arc_1_11_7
 UP BND1      load_1_11_7  30
 BV BND1      arc_1_11_8
 UP BND1      load_1_11_8  30
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  30
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  30
 BV BND1      arc_1_11_12
 UP BND1      load_1_11_12  30
 BV BND1      arc_1_11_13
 UP BND1      load_1_11_13  30
 BV BND1      arc_1_11_14
 UP BND1      load_1_11_14  30
 BV BND1      arc_1_11_15
 UP BND1      load_1_11_15  30
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  30
 BV BND1      arc_1_12_6
 UP BND1      load_1_12_6  30
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  30
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  30
 BV BND1      arc_1_12_9
 UP BND1      load_1_12_9  30
 BV BND1      arc_1_12_10
 UP BND1      load_1_12_10  30
 BV BND1      arc_1_12_11
 UP BND1      load_1_12_11  30
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  30
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  30
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  30
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  30
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  30
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  30
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  30
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  30
 BV BND1      arc_1_13_10
 UP BND1      load_1_13_10  30
 BV BND1      arc_1_13_11
 UP BND1      load_1_13_11  30
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  30
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  30
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  30
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  30
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  30
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  30
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  30
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  30
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  30
 BV BND1      arc_1_14_11
 UP BND1      load_1_14_11  30
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  30
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  30
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  30
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  30
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  30
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  30
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  30
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  30
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  30
 BV BND1      arc_1_15_11
 UP BND1      load_1_15_11  30
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  30
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  30
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  30
ENDATA
