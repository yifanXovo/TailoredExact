* Signature: 0x919e1a22c127bd75
NAME 
OBJSENSE MAX
ROWS
 N  OBJ
 L  column_0
 L  column_1
 L  column_2
 L  column_3
 L  column_4
 L  column_5
 L  column_6
 L  column_7
 L  column_8
COLUMNS
    psi[1,11]  OBJ       1
    psi[1,11]  column_0  1
    psi[1,11]  column_1  1
    psi[1,11]  column_2  1
    psi[1,11]  column_3  1
    psi[1,11]  column_4  1
    psi[1,11]  column_5  1
    psi[1,11]  column_6  1
    psi[1,11]  column_7  1
    psi[1,11]  column_8  1
    psi[2,14]  OBJ       1
    psi[2,14]  column_0  1
    psi[2,14]  column_1  1
    psi[2,14]  column_2  1
    psi[2,14]  column_3  1
    psi[2,14]  column_4  1
    psi[2,14]  column_5  1
    psi[2,14]  column_6  1
    psi[2,14]  column_7  1
    psi[2,14]  column_8  1
    psi[3,15]  OBJ       1
    psi[3,15]  column_0  1
    psi[3,15]  column_1  1
    psi[3,15]  column_2  1
    psi[3,15]  column_3  1
    psi[3,15]  column_4  1
    psi[3,15]  column_5  1
    psi[3,15]  column_6  1
    psi[3,15]  column_7  1
    psi[3,15]  column_8  1
    psi[4,11]  OBJ       1
    psi[4,11]  column_0  1
    psi[4,11]  column_1  1
    psi[4,11]  column_2  1
    psi[4,11]  column_3  1
    psi[4,11]  column_4  1
    psi[4,11]  column_5  1
    psi[4,11]  column_6  1
    psi[4,11]  column_7  1
    psi[4,11]  column_8  1
    psi[5,11]  OBJ       6.1900427668443114e-01
    psi[5,11]  column_0  1
    psi[5,11]  column_1  1
    psi[5,11]  column_2  1
    psi[5,11]  column_3  1
    psi[5,11]  column_4  1
    psi[5,18]  OBJ       3.8099572331556886e-01
    psi[5,18]  column_5  1
    psi[5,18]  column_6  1
    psi[5,18]  column_7  1
    psi[5,18]  column_8  1
    psi[6,11]  OBJ       7.0366999297677979e-01
    psi[6,11]  column_0  1
    psi[6,11]  column_1  1
    psi[6,11]  column_2  1
    psi[6,11]  column_3  1
    psi[6,11]  column_5  1
    psi[6,11]  column_6  1
    psi[6,11]  column_7  1
    psi[6,20]  OBJ       2.9633000702322021e-01
    psi[6,20]  column_4  1
    psi[6,20]  column_8  1
    psi[7,10]  OBJ       1
    psi[7,10]  column_0  1
    psi[7,10]  column_1  1
    psi[7,10]  column_2  1
    psi[7,10]  column_3  1
    psi[7,10]  column_4  1
    psi[7,10]  column_5  1
    psi[7,10]  column_6  1
    psi[7,10]  column_7  1
    psi[7,10]  column_8  1
    psi[8,11]  OBJ       1
    psi[8,11]  column_0  1
    psi[8,11]  column_1  1
    psi[8,11]  column_2  1
    psi[8,11]  column_3  1
    psi[8,11]  column_4  1
    psi[8,11]  column_5  1
    psi[8,11]  column_6  1
    psi[8,11]  column_7  1
    psi[8,11]  column_8  1
    psi[9,9]  OBJ       1
    psi[9,9]  column_0  1
    psi[9,9]  column_1  1
    psi[9,9]  column_2  1
    psi[9,9]  column_3  1
    psi[9,9]  column_4  1
    psi[9,9]  column_5  1
    psi[9,9]  column_6  1
    psi[9,9]  column_7  1
    psi[9,9]  column_8  1
    psi[10,16]  OBJ       1
    psi[10,16]  column_0  1
    psi[10,16]  column_1  1
    psi[10,16]  column_2  1
    psi[10,16]  column_3  1
    psi[10,16]  column_4  1
    psi[10,16]  column_5  1
    psi[10,16]  column_6  1
    psi[10,16]  column_7  1
    psi[10,16]  column_8  1
    psi[11,17]  OBJ       1
    psi[11,17]  column_0  1
    psi[11,17]  column_1  1
    psi[11,17]  column_2  1
    psi[11,17]  column_3  1
    psi[11,17]  column_4  1
    psi[11,17]  column_5  1
    psi[11,17]  column_6  1
    psi[11,17]  column_7  1
    psi[11,17]  column_8  1
    psi[12,10]  OBJ       6.9693522008988840e-01
    psi[12,10]  column_0  1
    psi[12,10]  column_1  1
    psi[12,10]  column_2  1
    psi[12,10]  column_5  1
    psi[12,10]  column_6  1
    psi[12,10]  column_8  1
    psi[12,18]  OBJ       3.0306477991011160e-01
    psi[12,18]  column_3  1
    psi[12,18]  column_4  1
    psi[12,18]  column_7  1
    psi[13,13]  OBJ       1
    psi[13,13]  column_0  1
    psi[13,13]  column_1  1
    psi[13,13]  column_2  1
    psi[13,13]  column_3  1
    psi[13,13]  column_4  1
    psi[13,13]  column_5  1
    psi[13,13]  column_6  1
    psi[13,13]  column_7  1
    psi[13,13]  column_8  1
    psi[14,13]  OBJ       1
    psi[14,13]  column_0  1
    psi[14,13]  column_1  1
    psi[14,13]  column_2  1
    psi[14,13]  column_3  1
    psi[14,13]  column_4  1
    psi[14,13]  column_5  1
    psi[14,13]  column_6  1
    psi[14,13]  column_7  1
    psi[14,13]  column_8  1
    psi[15,14]  OBJ       1
    psi[15,14]  column_0  1
    psi[15,14]  column_1  1
    psi[15,14]  column_2  1
    psi[15,14]  column_3  1
    psi[15,14]  column_4  1
    psi[15,14]  column_5  1
    psi[15,14]  column_6  1
    psi[15,14]  column_7  1
    psi[15,14]  column_8  1
    psi[16,12]  OBJ       6.7673090142921422e-01
    psi[16,12]  column_0  1
    psi[16,12]  column_1  1
    psi[16,12]  column_2  1
    psi[16,12]  column_3  1
    psi[16,12]  column_5  1
    psi[16,12]  column_6  1
    psi[16,21]  OBJ       3.2326909857078573e-01
    psi[16,21]  column_4  1
    psi[16,21]  column_7  1
    psi[16,21]  column_8  1
    psi[17,8]  OBJ       7.5754817607191072e-01
    psi[17,8]  column_0  1
    psi[17,8]  column_1  1
    psi[17,8]  column_3  1
    psi[17,8]  column_4  1
    psi[17,8]  column_5  1
    psi[17,8]  column_6  1
    psi[17,8]  column_7  1
    psi[17,8]  column_8  1
    psi[17,16]  OBJ       2.4245182392808928e-01
    psi[17,16]  column_2  1
    psi[18,11]  OBJ       7.0366999297677979e-01
    psi[18,11]  column_0  1
    psi[18,11]  column_1  1
    psi[18,11]  column_4  1
    psi[18,11]  column_5  1
    psi[18,11]  column_7  1
    psi[18,11]  column_8  1
    psi[18,20]  OBJ       2.9633000702322021e-01
    psi[18,20]  column_2  1
    psi[18,20]  column_3  1
    psi[18,20]  column_6  1
    psi[19,12]  OBJ       6.3632226410786608e-01
    psi[19,12]  column_0  1
    psi[19,12]  column_4  1
    psi[19,12]  column_5  1
    psi[19,12]  column_6  1
    psi[19,12]  column_7  1
    psi[19,12]  column_8  1
    psi[19,20]  OBJ       3.6367773589213392e-01
    psi[19,20]  column_1  1
    psi[19,20]  column_2  1
    psi[19,20]  column_3  1
    psi[20,13]  OBJ       0.606015786116855
    psi[20,13]  column_0  1
    psi[20,13]  column_2  1
    psi[20,13]  column_3  1
    psi[20,13]  column_4  1
    psi[20,13]  column_7  1
    psi[20,13]  column_8  1
    psi[20,21]  OBJ       0.393984213883145
    psi[20,21]  column_1  1
    psi[20,21]  column_5  1
    psi[20,21]  column_6  1
    a         OBJ       1
    a         column_0  1
    a         column_1  1
    a         column_2  1
    a         column_3  1
    a         column_4  1
    a         column_5  1
    a         column_6  1
    a         column_7  1
    a         column_8  1
RHS
    RHS1      column_0  2.3037127760972e-17
    RHS1      column_1  5.4337349397590377e-02
    RHS1      column_2  9.5417789757412413e-02
    RHS1      column_3  8.7829752515637766e-02
    RHS1      column_4  9.0296687665108746e-02
    RHS1      column_5  5.3060217176702888e-02
    RHS1      column_6  8.0640050697084950e-02
    RHS1      column_7  8.4501126818274971e-02
    RHS1      column_8  8.5209825997952932e-02
BOUNDS
 FX BND1      psi[1,11]  0
 FX BND1      psi[2,14]  0
 FX BND1      psi[3,15]  0
 FX BND1      psi[4,11]  0
 FX BND1      psi[5,11]  0
 LO BND1      psi[5,18]  -0.05
 UP BND1      psi[5,18]  0.05
 FX BND1      psi[6,11]  0
 LO BND1      psi[6,20]  -0.05
 UP BND1      psi[6,20]  0.05
 FX BND1      psi[7,10]  0
 FX BND1      psi[8,11]  0
 FX BND1      psi[9,9]  0
 FX BND1      psi[10,16]  0
 FX BND1      psi[11,17]  0
 FX BND1      psi[12,10]  0
 LO BND1      psi[12,18]  -0.05
 UP BND1      psi[12,18]  0.05
 FX BND1      psi[13,13]  0
 FX BND1      psi[14,13]  0
 FX BND1      psi[15,14]  0
 FX BND1      psi[16,12]  0
 LO BND1      psi[16,21]  -0.05
 UP BND1      psi[16,21]  0.05
 FX BND1      psi[17,8]  0
 LO BND1      psi[17,16]  -0.05
 UP BND1      psi[17,16]  0.05
 FX BND1      psi[18,11]  0
 LO BND1      psi[18,20]  -0.05
 UP BND1      psi[18,20]  0.05
 FX BND1      psi[19,12]  0
 LO BND1      psi[19,20]  -0.05
 UP BND1      psi[19,20]  0.05
 FX BND1      psi[20,13]  0
 LO BND1      psi[20,21]  -0.05
 UP BND1      psi[20,21]  0.05
 FR BND1      a       
ENDATA
