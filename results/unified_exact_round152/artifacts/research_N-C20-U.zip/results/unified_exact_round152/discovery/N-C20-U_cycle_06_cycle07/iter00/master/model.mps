* Signature: 0x1327b72f51c59e31
NAME 
OBJSENSE MAX
ROWS
 N  OBJ
 L  column_0
 L  column_1
 L  column_2
 L  column_3
 L  column_4
 L  column_5
 L  column_6
 L  column_7
 L  column_8
 L  column_9
 L  column_10
 L  column_11
 L  column_12
COLUMNS
    psi[1,11]  OBJ       1
    psi[1,11]  column_0  1
    psi[1,11]  column_1  1
    psi[1,11]  column_2  1
    psi[1,11]  column_3  1
    psi[1,11]  column_4  1
    psi[1,11]  column_5  1
    psi[1,11]  column_6  1
    psi[1,11]  column_7  1
    psi[1,11]  column_8  1
    psi[1,11]  column_9  1
    psi[1,11]  column_10  1
    psi[1,11]  column_11  1
    psi[1,11]  column_12  1
    psi[2,14]  OBJ       1
    psi[2,14]  column_0  1
    psi[2,14]  column_1  1
    psi[2,14]  column_2  1
    psi[2,14]  column_3  1
    psi[2,14]  column_4  1
    psi[2,14]  column_5  1
    psi[2,14]  column_6  1
    psi[2,14]  column_7  1
    psi[2,14]  column_8  1
    psi[2,14]  column_9  1
    psi[2,14]  column_10  1
    psi[2,14]  column_11  1
    psi[2,14]  column_12  1
    psi[3,15]  OBJ       1
    psi[3,15]  column_0  1
    psi[3,15]  column_1  1
    psi[3,15]  column_2  1
    psi[3,15]  column_3  1
    psi[3,15]  column_4  1
    psi[3,15]  column_5  1
    psi[3,15]  column_6  1
    psi[3,15]  column_7  1
    psi[3,15]  column_8  1
    psi[3,15]  column_9  1
    psi[3,15]  column_10  1
    psi[3,15]  column_11  1
    psi[3,15]  column_12  1
    psi[4,11]  OBJ       1
    psi[4,11]  column_0  1
    psi[4,11]  column_1  1
    psi[4,11]  column_2  1
    psi[4,11]  column_3  1
    psi[4,11]  column_4  1
    psi[4,11]  column_5  1
    psi[4,11]  column_6  1
    psi[4,11]  column_7  1
    psi[4,11]  column_8  1
    psi[4,11]  column_9  1
    psi[4,11]  column_10  1
    psi[4,11]  column_11  1
    psi[4,11]  column_12  1
    psi[5,11]  OBJ       5.8366498343674644e-01
    psi[5,11]  column_0  1
    psi[5,11]  column_1  1
    psi[5,11]  column_2  1
    psi[5,11]  column_3  1
    psi[5,11]  column_4  1
    psi[5,11]  column_5  1
    psi[5,12]  OBJ       4.0854293433190136e-02
    psi[5,12]  column_6  1
    psi[5,12]  column_7  1
    psi[5,18]  OBJ       3.7548072313006337e-01
    psi[5,18]  column_8  1
    psi[5,18]  column_9  1
    psi[5,18]  column_10  1
    psi[5,18]  column_11  1
    psi[5,18]  column_12  1
    psi[6,11]  OBJ       7.0342007162848508e-01
    psi[6,11]  column_0  1
    psi[6,11]  column_1  1
    psi[6,11]  column_2  1
    psi[6,11]  column_3  1
    psi[6,11]  column_6  1
    psi[6,11]  column_8  1
    psi[6,11]  column_9  1
    psi[6,11]  column_10  1
    psi[6,11]  column_11  1
    psi[6,11]  column_12  1
    psi[6,20]  OBJ       2.9657992837151487e-01
    psi[6,20]  column_4  1
    psi[6,20]  column_5  1
    psi[6,20]  column_7  1
    psi[7,10]  OBJ       1
    psi[7,10]  column_0  1
    psi[7,10]  column_1  1
    psi[7,10]  column_2  1
    psi[7,10]  column_3  1
    psi[7,10]  column_4  1
    psi[7,10]  column_5  1
    psi[7,10]  column_6  1
    psi[7,10]  column_7  1
    psi[7,10]  column_8  1
    psi[7,10]  column_9  1
    psi[7,10]  column_10  1
    psi[7,10]  column_11  1
    psi[7,10]  column_12  1
    psi[8,11]  OBJ       1
    psi[8,11]  column_0  1
    psi[8,11]  column_1  1
    psi[8,11]  column_2  1
    psi[8,11]  column_3  1
    psi[8,11]  column_4  1
    psi[8,11]  column_5  1
    psi[8,11]  column_6  1
    psi[8,11]  column_7  1
    psi[8,11]  column_8  1
    psi[8,11]  column_9  1
    psi[8,11]  column_10  1
    psi[8,11]  column_11  1
    psi[8,11]  column_12  1
    psi[9,9]  OBJ       1
    psi[9,9]  column_0  1
    psi[9,9]  column_1  1
    psi[9,9]  column_2  1
    psi[9,9]  column_3  1
    psi[9,9]  column_4  1
    psi[9,9]  column_5  1
    psi[9,9]  column_6  1
    psi[9,9]  column_7  1
    psi[9,9]  column_8  1
    psi[9,9]  column_9  1
    psi[9,9]  column_10  1
    psi[9,9]  column_11  1
    psi[9,9]  column_12  1
    psi[10,16]  OBJ       1
    psi[10,16]  column_0  1
    psi[10,16]  column_1  1
    psi[10,16]  column_2  1
    psi[10,16]  column_3  1
    psi[10,16]  column_4  1
    psi[10,16]  column_5  1
    psi[10,16]  column_6  1
    psi[10,16]  column_7  1
    psi[10,16]  column_8  1
    psi[10,16]  column_9  1
    psi[10,16]  column_10  1
    psi[10,16]  column_11  1
    psi[10,16]  column_12  1
    psi[11,17]  OBJ       1
    psi[11,17]  column_0  1
    psi[11,17]  column_1  1
    psi[11,17]  column_2  1
    psi[11,17]  column_3  1
    psi[11,17]  column_4  1
    psi[11,17]  column_5  1
    psi[11,17]  column_6  1
    psi[11,17]  column_7  1
    psi[11,17]  column_8  1
    psi[11,17]  column_9  1
    psi[11,17]  column_10  1
    psi[11,17]  column_11  1
    psi[11,17]  column_12  1
    psi[12,10]  OBJ       6.9667961871095074e-01
    psi[12,10]  column_0  1
    psi[12,10]  column_1  1
    psi[12,10]  column_2  1
    psi[12,10]  column_3  1
    psi[12,10]  column_4  1
    psi[12,10]  column_5  1
    psi[12,10]  column_6  1
    psi[12,10]  column_7  1
    psi[12,10]  column_8  1
    psi[12,10]  column_9  1
    psi[12,18]  OBJ       3.0332038128904920e-01
    psi[12,18]  column_10  1
    psi[12,18]  column_11  1
    psi[12,18]  column_12  1
    psi[13,13]  OBJ       1
    psi[13,13]  column_0  1
    psi[13,13]  column_1  1
    psi[13,13]  column_2  1
    psi[13,13]  column_3  1
    psi[13,13]  column_4  1
    psi[13,13]  column_5  1
    psi[13,13]  column_6  1
    psi[13,13]  column_7  1
    psi[13,13]  column_8  1
    psi[13,13]  column_9  1
    psi[13,13]  column_10  1
    psi[13,13]  column_11  1
    psi[13,13]  column_12  1
    psi[14,13]  OBJ       1
    psi[14,13]  column_0  1
    psi[14,13]  column_1  1
    psi[14,13]  column_2  1
    psi[14,13]  column_3  1
    psi[14,13]  column_4  1
    psi[14,13]  column_5  1
    psi[14,13]  column_6  1
    psi[14,13]  column_7  1
    psi[14,13]  column_8  1
    psi[14,13]  column_9  1
    psi[14,13]  column_10  1
    psi[14,13]  column_11  1
    psi[14,13]  column_12  1
    psi[15,14]  OBJ       1
    psi[15,14]  column_0  1
    psi[15,14]  column_1  1
    psi[15,14]  column_2  1
    psi[15,14]  column_3  1
    psi[15,14]  column_4  1
    psi[15,14]  column_5  1
    psi[15,14]  column_6  1
    psi[15,14]  column_7  1
    psi[15,14]  column_8  1
    psi[15,14]  column_9  1
    psi[15,14]  column_10  1
    psi[15,14]  column_11  1
    psi[15,14]  column_12  1
    psi[16,12]  OBJ       6.5550458502778541e-01
    psi[16,12]  column_0  1
    psi[16,12]  column_1  1
    psi[16,12]  column_2  1
    psi[16,12]  column_6  1
    psi[16,12]  column_8  1
    psi[16,12]  column_9  1
    psi[16,12]  column_10  1
    psi[16,13]  OBJ       2.3572884296882535e-02
    psi[16,13]  column_3  1
    psi[16,13]  column_7  1
    psi[16,21]  OBJ       3.2092253067533211e-01
    psi[16,21]  column_4  1
    psi[16,21]  column_5  1
    psi[16,21]  column_11  1
    psi[16,21]  column_12  1
    psi[17,8]  OBJ       7.2181758671719853e-01
    psi[17,8]  column_0  1
    psi[17,8]  column_1  1
    psi[17,8]  column_3  1
    psi[17,8]  column_4  1
    psi[17,8]  column_6  1
    psi[17,8]  column_8  1
    psi[17,8]  column_9  1
    psi[17,8]  column_10  1
    psi[17,8]  column_11  1
    psi[17,8]  column_12  1
    psi[17,9]  OBJ       4.0601266573213834e-02
    psi[17,9]  column_2  1
    psi[17,9]  column_7  1
    psi[17,16]  OBJ       2.3758114670958763e-01
    psi[17,16]  column_5  1
    psi[18,11]  OBJ       7.0342007162848530e-01
    psi[18,11]  column_0  1
    psi[18,11]  column_2  1
    psi[18,11]  column_3  1
    psi[18,11]  column_4  1
    psi[18,11]  column_5  1
    psi[18,11]  column_6  1
    psi[18,11]  column_8  1
    psi[18,11]  column_10  1
    psi[18,11]  column_11  1
    psi[18,11]  column_12  1
    psi[18,20]  OBJ       2.9657992837151476e-01
    psi[18,20]  column_1  1
    psi[18,20]  column_7  1
    psi[18,20]  column_9  1
    psi[19,12]  OBJ       6.3601554245314107e-01
    psi[19,12]  column_0  1
    psi[19,12]  column_1  1
    psi[19,12]  column_5  1
    psi[19,12]  column_8  1
    psi[19,12]  column_11  1
    psi[19,12]  column_12  1
    psi[19,20]  OBJ       3.6398445754685893e-01
    psi[19,20]  column_2  1
    psi[19,20]  column_3  1
    psi[19,20]  column_4  1
    psi[19,20]  column_6  1
    psi[19,20]  column_7  1
    psi[19,20]  column_9  1
    psi[19,20]  column_10  1
    psi[20,13]  OBJ       5.8802693631120828e-01
    psi[20,13]  column_0  1
    psi[20,13]  column_4  1
    psi[20,13]  column_5  1
    psi[20,13]  column_7  1
    psi[20,13]  column_10  1
    psi[20,13]  column_11  1
    psi[20,14]  OBJ       2.0178934872031817e-02
    psi[20,14]  column_9  1
    psi[20,14]  column_12  1
    psi[20,21]  OBJ       3.9179412881675985e-01
    psi[20,21]  column_1  1
    psi[20,21]  column_2  1
    psi[20,21]  column_3  1
    psi[20,21]  column_6  1
    psi[20,21]  column_8  1
    a         OBJ       1
    a         column_0  1
    a         column_1  1
    a         column_2  1
    a         column_3  1
    a         column_4  1
    a         column_5  1
    a         column_6  1
    a         column_7  1
    a         column_8  1
    a         column_9  1
    a         column_10  1
    a         column_11  1
    a         column_12  1
RHS
    RHS1      column_0  2.3037127760972e-17
    RHS1      column_1  6.0668841761827109e-02
    RHS1      column_2  5.8399460997155282e-02
    RHS1      column_3  5.7050705070507066e-02
    RHS1      column_4  8.6115843270868839e-02
    RHS1      column_5  9.7834843907351476e-02
    RHS1      column_6  5.7296324571927161e-02
    RHS1      column_7  9.4746103569632992e-02
    RHS1      column_8  5.3060217176702888e-02
    RHS1      column_9  0.084295915152788
    RHS1      column_10  8.1615026048807257e-02
    RHS1      column_11  8.4501126818274971e-02
    RHS1      column_12  8.6455012328616548e-02
BOUNDS
 FX BND1      psi[1,11]  0
 FX BND1      psi[2,14]  0
 FX BND1      psi[3,15]  0
 FX BND1      psi[4,11]  0
 FX BND1      psi[5,11]  0
 LO BND1      psi[5,12]  -0.05
 UP BND1      psi[5,12]  0.05
 LO BND1      psi[5,18]  -0.05
 UP BND1      psi[5,18]  0.05
 FX BND1      psi[6,11]  0
 LO BND1      psi[6,20]  -0.05
 UP BND1      psi[6,20]  0.05
 FX BND1      psi[7,10]  0
 FX BND1      psi[8,11]  0
 FX BND1      psi[9,9]  0
 FX BND1      psi[10,16]  0
 FX BND1      psi[11,17]  0
 FX BND1      psi[12,10]  0
 LO BND1      psi[12,18]  -0.05
 UP BND1      psi[12,18]  0.05
 FX BND1      psi[13,13]  0
 FX BND1      psi[14,13]  0
 FX BND1      psi[15,14]  0
 FX BND1      psi[16,12]  0
 LO BND1      psi[16,13]  -0.05
 UP BND1      psi[16,13]  0.05
 LO BND1      psi[16,21]  -0.05
 UP BND1      psi[16,21]  0.05
 FX BND1      psi[17,8]  0
 LO BND1      psi[17,9]  -0.05
 UP BND1      psi[17,9]  0.05
 LO BND1      psi[17,16]  -0.05
 UP BND1      psi[17,16]  0.05
 FX BND1      psi[18,11]  0
 LO BND1      psi[18,20]  -0.05
 UP BND1      psi[18,20]  0.05
 FX BND1      psi[19,12]  0
 LO BND1      psi[19,20]  -0.05
 UP BND1      psi[19,20]  0.05
 FX BND1      psi[20,13]  0
 LO BND1      psi[20,14]  -0.05
 UP BND1      psi[20,14]  0.05
 LO BND1      psi[20,21]  -0.05
 UP BND1      psi[20,21]  0.05
 FR BND1      a       
ENDATA
