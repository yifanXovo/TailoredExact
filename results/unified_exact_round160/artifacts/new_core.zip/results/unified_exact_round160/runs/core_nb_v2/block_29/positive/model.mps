* Signature: 0x926b331f407144e0
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 E  onehot_22_26
 E  normalized_mass_22_27
 E  normalized_ratio_22_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 E  onehot_18_65
 E  normalized_mass_18_66
 E  normalized_ratio_18_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 E  onehot_31_94
 E  normalized_mass_31_95
 E  normalized_ratio_31_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 E  onehot_14_129
 E  normalized_mass_14_130
 E  normalized_ratio_14_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 E  onehot_32_158
 E  normalized_mass_32_159
 E  normalized_ratio_32_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 E  onehot_5_195
 E  normalized_mass_5_196
 E  normalized_ratio_5_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 E  onehot_19_216
 E  normalized_mass_19_217
 E  normalized_ratio_19_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 G  product_lb_255
 L  product_ub_256
 G  product_lb_257
 L  product_ub_258
 G  product_lb_259
 L  product_ub_260
 G  product_lb_261
 L  product_ub_262
 E  onehot_8_263
 E  normalized_mass_8_264
 E  normalized_ratio_8_265
 G  stock_lb_266
 L  stock_ub_267
 L  parent_nonstrict_scope_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 G  block_pair_pos_317
 G  block_pair_neg_318
 G  block_pair_pos_319
 G  block_pair_neg_320
 G  block_pair_pos_321
 G  block_pair_neg_322
 G  block_pair_pos_323
 G  block_pair_neg_324
 E  normalization_325
 G  full_original_Gini_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 E  unique_nonzero_owner_428
 E  unique_nonzero_owner_429
 E  unique_nonzero_owner_430
 E  unique_nonzero_owner_431
 E  unique_nonzero_owner_432
 E  unique_nonzero_owner_433
 E  unique_nonzero_owner_434
 E  unique_nonzero_owner_435
 E  unique_nonzero_owner_436
 E  unique_nonzero_owner_437
 E  unique_nonzero_owner_438
 E  unique_nonzero_owner_439
 L  arc_capacity_440
 L  arc_capacity_441
 L  arc_capacity_442
 L  arc_capacity_443
 L  arc_capacity_444
 L  arc_capacity_445
 L  arc_capacity_446
 L  arc_capacity_447
 L  arc_capacity_448
 L  arc_capacity_449
 L  arc_capacity_450
 L  arc_capacity_451
 L  arc_capacity_452
 L  arc_capacity_453
 L  arc_capacity_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 G  connected_order_arc_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 G  connected_order_arc_728
 L  arc_capacity_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 L  arc_capacity_740
 G  connected_order_arc_741
 L  arc_capacity_742
 G  connected_order_arc_743
 L  arc_capacity_744
 G  connected_order_arc_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 L  arc_capacity_755
 G  connected_order_arc_756
 L  arc_capacity_757
 G  connected_order_arc_758
 L  arc_capacity_759
 G  connected_order_arc_760
 L  arc_capacity_761
 G  connected_order_arc_762
 L  arc_capacity_763
 G  connected_order_arc_764
 L  arc_capacity_765
 G  connected_order_arc_766
 L  arc_capacity_767
 G  connected_order_arc_768
 L  arc_capacity_769
 G  connected_order_arc_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 G  connected_order_arc_774
 L  arc_capacity_775
 G  connected_order_arc_776
 L  arc_capacity_777
 G  connected_order_arc_778
 E  depot_departure_or_bypass_779
 E  depot_return_or_bypass_780
 E  out_degree_781
 E  in_degree_782
 G  order_active_lb_783
 L  order_active_ub_784
 E  segment_load_conservation_785
 G  segment_prefix_lb_786
 L  segment_prefix_ub_787
 E  out_degree_788
 E  in_degree_789
 G  order_active_lb_790
 L  order_active_ub_791
 E  segment_load_conservation_792
 G  segment_prefix_lb_793
 L  segment_prefix_ub_794
 E  out_degree_795
 E  in_degree_796
 G  order_active_lb_797
 L  order_active_ub_798
 E  segment_load_conservation_799
 G  segment_prefix_lb_800
 L  segment_prefix_ub_801
 E  out_degree_802
 E  in_degree_803
 G  order_active_lb_804
 L  order_active_ub_805
 E  segment_load_conservation_806
 G  segment_prefix_lb_807
 L  segment_prefix_ub_808
 E  out_degree_809
 E  in_degree_810
 G  order_active_lb_811
 L  order_active_ub_812
 E  segment_load_conservation_813
 G  segment_prefix_lb_814
 L  segment_prefix_ub_815
 E  out_degree_816
 E  in_degree_817
 G  order_active_lb_818
 L  order_active_ub_819
 E  service_visit_def_820
 E  free_load_conservation_821
 E  out_degree_822
 E  in_degree_823
 G  order_active_lb_824
 L  order_active_ub_825
 E  service_visit_def_826
 E  free_load_conservation_827
 E  out_degree_828
 E  in_degree_829
 G  order_active_lb_830
 L  order_active_ub_831
 E  service_visit_def_832
 E  free_load_conservation_833
 E  out_degree_834
 E  in_degree_835
 G  order_active_lb_836
 L  order_active_ub_837
 E  service_visit_def_838
 E  free_load_conservation_839
 E  out_degree_840
 E  in_degree_841
 G  order_active_lb_842
 L  order_active_ub_843
 E  service_visit_def_844
 E  free_load_conservation_845
 E  out_degree_846
 E  in_degree_847
 G  order_active_lb_848
 L  order_active_ub_849
 E  service_visit_def_850
 E  free_load_conservation_851
 E  out_degree_852
 E  in_degree_853
 G  order_active_lb_854
 L  order_active_ub_855
 E  service_visit_def_856
 E  free_load_conservation_857
 E  out_degree_858
 E  in_degree_859
 G  order_active_lb_860
 L  order_active_ub_861
 E  service_visit_def_862
 E  free_load_conservation_863
 G  fixed_segment_relative_order_864
 G  fixed_segment_relative_order_865
 G  fixed_segment_relative_order_866
 G  fixed_segment_relative_order_867
 L  original_T_including_depot_unload_868
 L  arc_capacity_869
 L  arc_capacity_870
 L  arc_capacity_871
 L  arc_capacity_872
 L  arc_capacity_873
 L  arc_capacity_874
 L  arc_capacity_875
 L  arc_capacity_876
 L  arc_capacity_877
 L  arc_capacity_878
 L  arc_capacity_879
 L  arc_capacity_880
 L  arc_capacity_881
 L  arc_capacity_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 G  connected_order_arc_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 L  arc_capacity_1136
 G  connected_order_arc_1137
 L  arc_capacity_1138
 G  connected_order_arc_1139
 L  arc_capacity_1140
 G  connected_order_arc_1141
 L  arc_capacity_1142
 G  connected_order_arc_1143
 L  arc_capacity_1144
 G  connected_order_arc_1145
 L  arc_capacity_1146
 G  connected_order_arc_1147
 L  arc_capacity_1148
 G  connected_order_arc_1149
 L  arc_capacity_1150
 G  connected_order_arc_1151
 L  arc_capacity_1152
 G  connected_order_arc_1153
 L  arc_capacity_1154
 G  connected_order_arc_1155
 L  arc_capacity_1156
 G  connected_order_arc_1157
 E  depot_departure_or_bypass_1158
 E  depot_return_or_bypass_1159
 E  out_degree_1160
 E  in_degree_1161
 G  order_active_lb_1162
 L  order_active_ub_1163
 E  segment_load_conservation_1164
 G  segment_prefix_lb_1165
 L  segment_prefix_ub_1166
 E  out_degree_1167
 E  in_degree_1168
 G  order_active_lb_1169
 L  order_active_ub_1170
 E  segment_load_conservation_1171
 G  segment_prefix_lb_1172
 L  segment_prefix_ub_1173
 E  out_degree_1174
 E  in_degree_1175
 G  order_active_lb_1176
 L  order_active_ub_1177
 E  segment_load_conservation_1178
 G  segment_prefix_lb_1179
 L  segment_prefix_ub_1180
 E  out_degree_1181
 E  in_degree_1182
 G  order_active_lb_1183
 L  order_active_ub_1184
 E  segment_load_conservation_1185
 G  segment_prefix_lb_1186
 L  segment_prefix_ub_1187
 E  out_degree_1188
 E  in_degree_1189
 G  order_active_lb_1190
 L  order_active_ub_1191
 E  service_visit_def_1192
 E  free_load_conservation_1193
 E  out_degree_1194
 E  in_degree_1195
 G  order_active_lb_1196
 L  order_active_ub_1197
 E  service_visit_def_1198
 E  free_load_conservation_1199
 E  out_degree_1200
 E  in_degree_1201
 G  order_active_lb_1202
 L  order_active_ub_1203
 E  service_visit_def_1204
 E  free_load_conservation_1205
 E  out_degree_1206
 E  in_degree_1207
 G  order_active_lb_1208
 L  order_active_ub_1209
 E  service_visit_def_1210
 E  free_load_conservation_1211
 E  out_degree_1212
 E  in_degree_1213
 G  order_active_lb_1214
 L  order_active_ub_1215
 E  service_visit_def_1216
 E  free_load_conservation_1217
 E  out_degree_1218
 E  in_degree_1219
 G  order_active_lb_1220
 L  order_active_ub_1221
 E  service_visit_def_1222
 E  free_load_conservation_1223
 E  out_degree_1224
 E  in_degree_1225
 G  order_active_lb_1226
 L  order_active_ub_1227
 E  service_visit_def_1228
 E  free_load_conservation_1229
 E  out_degree_1230
 E  in_degree_1231
 G  order_active_lb_1232
 L  order_active_ub_1233
 E  service_visit_def_1234
 E  free_load_conservation_1235
 G  fixed_segment_relative_order_1236
 G  fixed_segment_relative_order_1237
 G  fixed_segment_relative_order_1238
 L  original_T_including_depot_unload_1239
 L  arc_capacity_1240
 L  arc_capacity_1241
 L  arc_capacity_1242
 L  arc_capacity_1243
 L  arc_capacity_1244
 L  arc_capacity_1245
 L  arc_capacity_1246
 L  arc_capacity_1247
 L  arc_capacity_1248
 L  arc_capacity_1249
 L  arc_capacity_1250
 L  arc_capacity_1251
 L  arc_capacity_1252
 L  arc_capacity_1253
 L  arc_capacity_1254
 G  connected_order_arc_1255
 L  arc_capacity_1256
 G  connected_order_arc_1257
 L  arc_capacity_1258
 G  connected_order_arc_1259
 L  arc_capacity_1260
 G  connected_order_arc_1261
 L  arc_capacity_1262
 G  connected_order_arc_1263
 L  arc_capacity_1264
 G  connected_order_arc_1265
 L  arc_capacity_1266
 G  connected_order_arc_1267
 L  arc_capacity_1268
 G  connected_order_arc_1269
 L  arc_capacity_1270
 G  connected_order_arc_1271
 L  arc_capacity_1272
 G  connected_order_arc_1273
 L  arc_capacity_1274
 G  connected_order_arc_1275
 L  arc_capacity_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 G  connected_order_arc_1280
 L  arc_capacity_1281
 G  connected_order_arc_1282
 L  arc_capacity_1283
 G  connected_order_arc_1284
 L  arc_capacity_1285
 G  connected_order_arc_1286
 L  arc_capacity_1287
 G  connected_order_arc_1288
 L  arc_capacity_1289
 G  connected_order_arc_1290
 L  arc_capacity_1291
 G  connected_order_arc_1292
 L  arc_capacity_1293
 G  connected_order_arc_1294
 L  arc_capacity_1295
 G  connected_order_arc_1296
 L  arc_capacity_1297
 G  connected_order_arc_1298
 L  arc_capacity_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 G  connected_order_arc_1305
 L  arc_capacity_1306
 G  connected_order_arc_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 G  connected_order_arc_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 G  connected_order_arc_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 G  connected_order_arc_1418
 L  arc_capacity_1419
 G  connected_order_arc_1420
 L  arc_capacity_1421
 G  connected_order_arc_1422
 L  arc_capacity_1423
 G  connected_order_arc_1424
 L  arc_capacity_1425
 G  connected_order_arc_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 G  connected_order_arc_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 G  connected_order_arc_1436
 L  arc_capacity_1437
 L  arc_capacity_1438
 G  connected_order_arc_1439
 L  arc_capacity_1440
 G  connected_order_arc_1441
 L  arc_capacity_1442
 G  connected_order_arc_1443
 L  arc_capacity_1444
 G  connected_order_arc_1445
 L  arc_capacity_1446
 G  connected_order_arc_1447
 L  arc_capacity_1448
 G  connected_order_arc_1449
 L  arc_capacity_1450
 G  connected_order_arc_1451
 L  arc_capacity_1452
 G  connected_order_arc_1453
 L  arc_capacity_1454
 G  connected_order_arc_1455
 L  arc_capacity_1456
 G  connected_order_arc_1457
 L  arc_capacity_1458
 G  connected_order_arc_1459
 L  arc_capacity_1460
 L  arc_capacity_1461
 G  connected_order_arc_1462
 L  arc_capacity_1463
 G  connected_order_arc_1464
 L  arc_capacity_1465
 G  connected_order_arc_1466
 L  arc_capacity_1467
 G  connected_order_arc_1468
 L  arc_capacity_1469
 G  connected_order_arc_1470
 L  arc_capacity_1471
 G  connected_order_arc_1472
 L  arc_capacity_1473
 G  connected_order_arc_1474
 L  arc_capacity_1475
 G  connected_order_arc_1476
 L  arc_capacity_1477
 G  connected_order_arc_1478
 L  arc_capacity_1479
 G  connected_order_arc_1480
 L  arc_capacity_1481
 G  connected_order_arc_1482
 L  arc_capacity_1483
 L  arc_capacity_1484
 G  connected_order_arc_1485
 L  arc_capacity_1486
 G  connected_order_arc_1487
 L  arc_capacity_1488
 G  connected_order_arc_1489
 L  arc_capacity_1490
 G  connected_order_arc_1491
 L  arc_capacity_1492
 G  connected_order_arc_1493
 L  arc_capacity_1494
 G  connected_order_arc_1495
 L  arc_capacity_1496
 G  connected_order_arc_1497
 L  arc_capacity_1498
 G  connected_order_arc_1499
 L  arc_capacity_1500
 G  connected_order_arc_1501
 L  arc_capacity_1502
 G  connected_order_arc_1503
 L  arc_capacity_1504
 G  connected_order_arc_1505
 L  arc_capacity_1506
 L  arc_capacity_1507
 G  connected_order_arc_1508
 L  arc_capacity_1509
 G  connected_order_arc_1510
 L  arc_capacity_1511
 G  connected_order_arc_1512
 L  arc_capacity_1513
 G  connected_order_arc_1514
 L  arc_capacity_1515
 G  connected_order_arc_1516
 L  arc_capacity_1517
 G  connected_order_arc_1518
 L  arc_capacity_1519
 G  connected_order_arc_1520
 L  arc_capacity_1521
 G  connected_order_arc_1522
 L  arc_capacity_1523
 G  connected_order_arc_1524
 L  arc_capacity_1525
 G  connected_order_arc_1526
 L  arc_capacity_1527
 G  connected_order_arc_1528
 E  depot_departure_or_bypass_1529
 E  depot_return_or_bypass_1530
 E  out_degree_1531
 E  in_degree_1532
 G  order_active_lb_1533
 L  order_active_ub_1534
 E  segment_load_conservation_1535
 G  segment_prefix_lb_1536
 L  segment_prefix_ub_1537
 E  out_degree_1538
 E  in_degree_1539
 G  order_active_lb_1540
 L  order_active_ub_1541
 E  segment_load_conservation_1542
 G  segment_prefix_lb_1543
 L  segment_prefix_ub_1544
 E  out_degree_1545
 E  in_degree_1546
 G  order_active_lb_1547
 L  order_active_ub_1548
 E  segment_load_conservation_1549
 G  segment_prefix_lb_1550
 L  segment_prefix_ub_1551
 E  out_degree_1552
 E  in_degree_1553
 G  order_active_lb_1554
 L  order_active_ub_1555
 E  segment_load_conservation_1556
 G  segment_prefix_lb_1557
 L  segment_prefix_ub_1558
 E  out_degree_1559
 E  in_degree_1560
 G  order_active_lb_1561
 L  order_active_ub_1562
 E  service_visit_def_1563
 E  free_load_conservation_1564
 E  out_degree_1565
 E  in_degree_1566
 G  order_active_lb_1567
 L  order_active_ub_1568
 E  service_visit_def_1569
 E  free_load_conservation_1570
 E  out_degree_1571
 E  in_degree_1572
 G  order_active_lb_1573
 L  order_active_ub_1574
 E  service_visit_def_1575
 E  free_load_conservation_1576
 E  out_degree_1577
 E  in_degree_1578
 G  order_active_lb_1579
 L  order_active_ub_1580
 E  service_visit_def_1581
 E  free_load_conservation_1582
 E  out_degree_1583
 E  in_degree_1584
 G  order_active_lb_1585
 L  order_active_ub_1586
 E  service_visit_def_1587
 E  free_load_conservation_1588
 E  out_degree_1589
 E  in_degree_1590
 G  order_active_lb_1591
 L  order_active_ub_1592
 E  service_visit_def_1593
 E  free_load_conservation_1594
 E  out_degree_1595
 E  in_degree_1596
 G  order_active_lb_1597
 L  order_active_ub_1598
 E  service_visit_def_1599
 E  free_load_conservation_1600
 E  out_degree_1601
 E  in_degree_1602
 G  order_active_lb_1603
 L  order_active_ub_1604
 E  service_visit_def_1605
 E  free_load_conservation_1606
 G  fixed_segment_relative_order_1607
 G  fixed_segment_relative_order_1608
 G  fixed_segment_relative_order_1609
 L  original_T_including_depot_unload_1610
COLUMNS
    t         normalized_mass_22_27  -1
    t         normalized_mass_18_66  -1
    t         normalized_mass_31_95  -1
    t         normalized_mass_14_130  -1
    t         normalized_mass_32_159  -1
    t         normalized_mass_5_196  -1
    t         normalized_mass_19_217  -1
    t         normalized_mass_8_264  -1
    t         normalization_325  2.3526190476190479e+01
    t         full_original_Gini_326  -8.0083333333333385e+01
    q         OBJ       1
    q         parent_nonstrict_scope_268  1
    q         full_original_Gini_326  35
    MARKER    'MARKER'                 'INTORG'
    x_22_0    OBJ       0.027
    x_22_0    product_lb_0  -0.0253136583258579
    x_22_0    product_ub_1  -4.2505819249106368e-02
    x_22_0    onehot_22_26  1
    x_22_0    parent_nonstrict_scope_268  0.054
    x_22_0    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_0    product_lb_0  1
    w_22_0    product_ub_1  1
    w_22_0    normalized_mass_22_27  1
    w_22_0    full_original_Gini_326  -2.3526190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_1    OBJ       0.018
    x_22_1    product_lb_2  -0.0253136583258579
    x_22_1    product_ub_3  -4.2505819249106368e-02
    x_22_1    onehot_22_26  1
    x_22_1    stock_lb_266  1
    x_22_1    stock_ub_267  1
    x_22_1    parent_nonstrict_scope_268  0.045
    x_22_1    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_1    product_lb_2  1
    w_22_1    product_ub_3  1
    w_22_1    normalized_mass_22_27  1
    w_22_1    normalized_ratio_22_28  -1.6666666666666666e-01
    w_22_1    full_original_Gini_326  -1.9359523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_2    OBJ       9.0000000000000045e-03
    x_22_2    product_lb_4  -0.0253136583258579
    x_22_2    product_ub_5  -4.2505819249106368e-02
    x_22_2    onehot_22_26  1
    x_22_2    stock_lb_266  2
    x_22_2    stock_ub_267  2
    x_22_2    parent_nonstrict_scope_268  3.6000000000000004e-02
    x_22_2    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_2    product_lb_4  1
    w_22_2    product_ub_5  1
    w_22_2    normalized_mass_22_27  1
    w_22_2    normalized_ratio_22_28  -3.3333333333333331e-01
    w_22_2    full_original_Gini_326  -1.5192857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_3    product_lb_6  -0.0253136583258579
    x_22_3    product_ub_7  -4.2505819249106368e-02
    x_22_3    onehot_22_26  1
    x_22_3    stock_lb_266  3
    x_22_3    stock_ub_267  3
    x_22_3    parent_nonstrict_scope_268  0.027
    x_22_3    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_3    product_lb_6  1
    w_22_3    product_ub_7  1
    w_22_3    normalized_mass_22_27  1
    w_22_3    normalized_ratio_22_28  -0.5
    w_22_3    full_original_Gini_326  -1.1426190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_4    OBJ       -8.9999999999999976e-03
    x_22_4    product_lb_8  -0.0253136583258579
    x_22_4    product_ub_9  -4.2505819249106368e-02
    x_22_4    onehot_22_26  1
    x_22_4    stock_lb_266  4
    x_22_4    stock_ub_267  4
    x_22_4    parent_nonstrict_scope_268  1.8000000000000002e-02
    x_22_4    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_4    product_lb_8  1
    w_22_4    product_ub_9  1
    w_22_4    normalized_mass_22_27  1
    w_22_4    normalized_ratio_22_28  -6.6666666666666663e-01
    w_22_4    full_original_Gini_326  -7.9261904761904756e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_5    OBJ       -1.7999999999999995e-02
    x_22_5    product_lb_10  -0.0253136583258579
    x_22_5    product_ub_11  -4.2505819249106368e-02
    x_22_5    onehot_22_26  1
    x_22_5    stock_lb_266  5
    x_22_5    stock_ub_267  5
    x_22_5    parent_nonstrict_scope_268  9.0000000000000045e-03
    x_22_5    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_5    product_lb_10  1
    w_22_5    product_ub_11  1
    w_22_5    normalized_mass_22_27  1
    w_22_5    normalized_ratio_22_28  -8.3333333333333326e-01
    w_22_5    full_original_Gini_326  -4.9690476190476227e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_6    OBJ       -0.027
    x_22_6    product_lb_12  -0.0253136583258579
    x_22_6    product_ub_13  -4.2505819249106368e-02
    x_22_6    onehot_22_26  1
    x_22_6    stock_lb_266  6
    x_22_6    stock_ub_267  6
    x_22_6    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_6    product_lb_12  1
    w_22_6    product_ub_13  1
    w_22_6    normalized_mass_22_27  1
    w_22_6    normalized_ratio_22_28  -1
    w_22_6    full_original_Gini_326  -3.8738095238095243e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_7    OBJ       -1.8000000000000009e-02
    x_22_7    product_lb_14  -0.0253136583258579
    x_22_7    product_ub_15  -4.2505819249106368e-02
    x_22_7    onehot_22_26  1
    x_22_7    stock_lb_266  7
    x_22_7    stock_ub_267  7
    x_22_7    parent_nonstrict_scope_268  8.9999999999999924e-03
    x_22_7    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_7    product_lb_14  1
    w_22_7    product_ub_15  1
    w_22_7    normalized_mass_22_27  1
    w_22_7    normalized_ratio_22_28  -1.1666666666666665e+00
    w_22_7    full_original_Gini_326  -8.0404761904761859e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_8    OBJ       -9.0000000000000045e-03
    x_22_8    product_lb_16  -0.0253136583258579
    x_22_8    product_ub_17  -4.2505819249106368e-02
    x_22_8    onehot_22_26  1
    x_22_8    stock_lb_266  8
    x_22_8    stock_ub_267  8
    x_22_8    parent_nonstrict_scope_268  1.7999999999999995e-02
    MARKER    'MARKER'                 'INTEND'
    w_22_8    product_lb_16  1
    w_22_8    product_ub_17  1
    w_22_8    normalized_mass_22_27  1
    w_22_8    normalized_ratio_22_28  -1.3333333333333333e+00
    w_22_8    full_original_Gini_326  -1.2473809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_9    product_lb_18  -0.0253136583258579
    x_22_9    product_ub_19  -4.2505819249106368e-02
    x_22_9    onehot_22_26  1
    x_22_9    stock_lb_266  9
    x_22_9    stock_ub_267  9
    x_22_9    parent_nonstrict_scope_268  0.027
    x_22_9    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_9    product_lb_18  1
    w_22_9    product_ub_19  1
    w_22_9    normalized_mass_22_27  1
    w_22_9    normalized_ratio_22_28  -1.5
    w_22_9    full_original_Gini_326  -1.6973809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_10   OBJ       0.00899999999999999
    x_22_10   product_lb_20  -0.0253136583258579
    x_22_10   product_ub_21  -4.2505819249106368e-02
    x_22_10   onehot_22_26  1
    x_22_10   stock_lb_266  10
    x_22_10   stock_ub_267  10
    x_22_10   parent_nonstrict_scope_268  3.5999999999999990e-02
    x_22_10   unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_10   product_lb_20  1
    w_22_10   product_ub_21  1
    w_22_10   normalized_mass_22_27  1
    w_22_10   normalized_ratio_22_28  -1.6666666666666665e+00
    w_22_10   full_original_Gini_326  -2.1473809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_11   OBJ       0.018
    x_22_11   product_lb_22  -0.0253136583258579
    x_22_11   product_ub_23  -4.2505819249106368e-02
    x_22_11   onehot_22_26  1
    x_22_11   stock_lb_266  11
    x_22_11   stock_ub_267  11
    x_22_11   parent_nonstrict_scope_268  0.045
    x_22_11   unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_11   product_lb_22  1
    w_22_11   product_ub_23  1
    w_22_11   normalized_mass_22_27  1
    w_22_11   normalized_ratio_22_28  -1.8333333333333333e+00
    w_22_11   full_original_Gini_326  -2.5973809523809514e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_12   OBJ       0.027
    x_22_12   product_lb_24  -0.0253136583258579
    x_22_12   product_ub_25  -4.2505819249106368e-02
    x_22_12   onehot_22_26  1
    x_22_12   stock_lb_266  12
    x_22_12   stock_ub_267  12
    x_22_12   parent_nonstrict_scope_268  0.054
    x_22_12   unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_12   product_lb_24  1
    w_22_12   product_ub_25  1
    w_22_12   normalized_mass_22_27  1
    w_22_12   normalized_ratio_22_28  -2
    w_22_12   full_original_Gini_326  -3.0473809523809525e+01
    rho_22    normalized_ratio_22_28  1
    rho_22    block_pair_pos_295  -1
    rho_22    block_pair_neg_296  1
    rho_22    block_pair_pos_297  -1
    rho_22    block_pair_neg_298  1
    rho_22    block_pair_pos_299  -1
    rho_22    block_pair_neg_300  1
    rho_22    block_pair_pos_301  -1
    rho_22    block_pair_neg_302  1
    rho_22    block_pair_pos_303  -1
    rho_22    block_pair_neg_304  1
    rho_22    block_pair_pos_305  -1
    rho_22    block_pair_neg_306  1
    rho_22    block_pair_pos_307  -1
    rho_22    block_pair_neg_308  1
    rho_22    normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       0.06075
    x_18_0    product_lb_29  -0.0253136583258579
    x_18_0    product_ub_30  -4.2505819249106368e-02
    x_18_0    onehot_18_65  1
    x_18_0    parent_nonstrict_scope_268  0.1215
    x_18_0    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_29  1
    w_18_0    product_ub_30  1
    w_18_0    normalized_mass_18_66  1
    w_18_0    full_original_Gini_326  -2.3526190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       4.7249999999999986e-02
    x_18_1    product_lb_31  -0.0253136583258579
    x_18_1    product_ub_32  -4.2505819249106368e-02
    x_18_1    onehot_18_65  1
    x_18_1    stock_lb_266  1
    x_18_1    stock_ub_267  1
    x_18_1    parent_nonstrict_scope_268  1.0799999999999998e-01
    x_18_1    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_31  1
    w_18_1    product_ub_32  1
    w_18_1    normalized_mass_18_66  1
    w_18_1    normalized_ratio_18_67  -1.1111111111111110e-01
    w_18_1    full_original_Gini_326  -20.7484126984127
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       0.03375
    x_18_2    product_lb_33  -0.0253136583258579
    x_18_2    product_ub_34  -4.2505819249106368e-02
    x_18_2    onehot_18_65  1
    x_18_2    stock_lb_266  2
    x_18_2    stock_ub_267  2
    x_18_2    parent_nonstrict_scope_268  0.0945
    x_18_2    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_33  1
    w_18_2    product_ub_34  1
    w_18_2    normalized_mass_18_66  1
    w_18_2    normalized_ratio_18_67  -2.2222222222222221e-01
    w_18_2    full_original_Gini_326  -1.7970634920634925e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_3    OBJ       2.0250000000000004e-02
    x_18_3    product_lb_35  -0.0253136583258579
    x_18_3    product_ub_36  -4.2505819249106368e-02
    x_18_3    onehot_18_65  1
    x_18_3    stock_lb_266  3
    x_18_3    stock_ub_267  3
    x_18_3    parent_nonstrict_scope_268  0.081
    x_18_3    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_35  1
    w_18_3    product_ub_36  1
    w_18_3    normalized_mass_18_66  1
    w_18_3    normalized_ratio_18_67  -3.3333333333333331e-01
    w_18_3    full_original_Gini_326  -1.5192857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       6.7500000000000060e-03
    x_18_4    product_lb_37  -0.0253136583258579
    x_18_4    product_ub_38  -4.2505819249106368e-02
    x_18_4    onehot_18_65  1
    x_18_4    stock_lb_266  4
    x_18_4    stock_ub_267  4
    x_18_4    parent_nonstrict_scope_268  0.0675
    x_18_4    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_37  1
    w_18_4    product_ub_38  1
    w_18_4    normalized_mass_18_66  1
    w_18_4    normalized_ratio_18_67  -4.4444444444444442e-01
    w_18_4    full_original_Gini_326  -1.2592857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -6.7500000000000060e-03
    x_18_5    product_lb_39  -0.0253136583258579
    x_18_5    product_ub_40  -4.2505819249106368e-02
    x_18_5    onehot_18_65  1
    x_18_5    stock_lb_266  5
    x_18_5    stock_ub_267  5
    x_18_5    parent_nonstrict_scope_268  5.3999999999999992e-02
    x_18_5    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_39  1
    w_18_5    product_ub_40  1
    w_18_5    normalized_mass_18_66  1
    w_18_5    normalized_ratio_18_67  -5.5555555555555558e-01
    w_18_5    full_original_Gini_326  -1.0259523809523811e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -2.0249999999999997e-02
    x_18_6    product_lb_41  -0.0253136583258579
    x_18_6    product_ub_42  -4.2505819249106368e-02
    x_18_6    onehot_18_65  1
    x_18_6    stock_lb_266  6
    x_18_6    stock_ub_267  6
    x_18_6    parent_nonstrict_scope_268  0.0405
    x_18_6    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_41  1
    w_18_6    product_ub_42  1
    w_18_6    normalized_mass_18_66  1
    w_18_6    normalized_ratio_18_67  -6.6666666666666663e-01
    w_18_6    full_original_Gini_326  -7.9261904761904756e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -3.3749999999999988e-02
    x_18_7    product_lb_43  -0.0253136583258579
    x_18_7    product_ub_44  -4.2505819249106368e-02
    x_18_7    onehot_18_65  1
    x_18_7    stock_lb_266  7
    x_18_7    stock_ub_267  7
    x_18_7    parent_nonstrict_scope_268  2.7000000000000010e-02
    x_18_7    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_43  1
    w_18_7    product_ub_44  1
    w_18_7    normalized_mass_18_66  1
    w_18_7    normalized_ratio_18_67  -7.7777777777777768e-01
    w_18_7    full_original_Gini_326  -5.8468253968253983e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       -4.7249999999999993e-02
    x_18_8    product_lb_45  -0.0253136583258579
    x_18_8    product_ub_46  -4.2505819249106368e-02
    x_18_8    onehot_18_65  1
    x_18_8    stock_lb_266  8
    x_18_8    stock_ub_267  8
    x_18_8    parent_nonstrict_scope_268  1.3500000000000005e-02
    x_18_8    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_45  1
    w_18_8    product_ub_46  1
    w_18_8    normalized_mass_18_66  1
    w_18_8    normalized_ratio_18_67  -8.8888888888888884e-01
    w_18_8    full_original_Gini_326  -4.4293650793650805e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       -0.06075
    x_18_9    product_lb_47  -0.0253136583258579
    x_18_9    product_ub_48  -4.2505819249106368e-02
    x_18_9    onehot_18_65  1
    x_18_9    stock_lb_266  9
    x_18_9    stock_ub_267  9
    x_18_9    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_47  1
    w_18_9    product_ub_48  1
    w_18_9    normalized_mass_18_66  1
    w_18_9    normalized_ratio_18_67  -1
    w_18_9    full_original_Gini_326  -3.8738095238095243e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       -4.7249999999999993e-02
    x_18_10   product_lb_49  -0.0253136583258579
    x_18_10   product_ub_50  -4.2505819249106368e-02
    x_18_10   onehot_18_65  1
    x_18_10   stock_lb_266  10
    x_18_10   stock_ub_267  10
    x_18_10   parent_nonstrict_scope_268  1.3500000000000005e-02
    x_18_10   unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_49  1
    w_18_10   product_ub_50  1
    w_18_10   normalized_mass_18_66  1
    w_18_10   normalized_ratio_18_67  -1.1111111111111112e+00
    w_18_10   full_original_Gini_326  -6.6515873015873019e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_11   OBJ       -3.3750000000000016e-02
    x_18_11   product_lb_51  -0.0253136583258579
    x_18_11   product_ub_52  -4.2505819249106368e-02
    x_18_11   onehot_18_65  1
    x_18_11   stock_lb_266  11
    x_18_11   stock_ub_267  11
    x_18_11   parent_nonstrict_scope_268  2.6999999999999986e-02
    x_18_11   unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_11   product_lb_51  1
    w_18_11   product_ub_52  1
    w_18_11   normalized_mass_18_66  1
    w_18_11   normalized_ratio_18_67  -1.2222222222222221e+00
    w_18_11   full_original_Gini_326  -9.4738095238095230e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_12   OBJ       -2.0250000000000011e-02
    x_18_12   product_lb_53  -0.0253136583258579
    x_18_12   product_ub_54  -4.2505819249106368e-02
    x_18_12   onehot_18_65  1
    x_18_12   stock_lb_266  12
    x_18_12   stock_ub_267  12
    x_18_12   parent_nonstrict_scope_268  4.0499999999999987e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_12   product_lb_53  1
    w_18_12   product_ub_54  1
    w_18_12   normalized_mass_18_66  1
    w_18_12   normalized_ratio_18_67  -1.3333333333333333e+00
    w_18_12   full_original_Gini_326  -1.2473809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_13   OBJ       -6.7500000000000060e-03
    x_18_13   product_lb_55  -0.0253136583258579
    x_18_13   product_ub_56  -4.2505819249106368e-02
    x_18_13   onehot_18_65  1
    x_18_13   stock_lb_266  13
    x_18_13   stock_ub_267  13
    x_18_13   parent_nonstrict_scope_268  5.3999999999999992e-02
    x_18_13   unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_13   product_lb_55  1
    w_18_13   product_ub_56  1
    w_18_13   normalized_mass_18_66  1
    w_18_13   normalized_ratio_18_67  -1.4444444444444444e+00
    w_18_13   full_original_Gini_326  -1.5473809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_14   OBJ       6.7499999999999782e-03
    x_18_14   product_lb_57  -0.0253136583258579
    x_18_14   product_ub_58  -4.2505819249106368e-02
    x_18_14   onehot_18_65  1
    x_18_14   stock_lb_266  14
    x_18_14   stock_ub_267  14
    x_18_14   parent_nonstrict_scope_268  6.7499999999999977e-02
    x_18_14   unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_14   product_lb_57  1
    w_18_14   product_ub_58  1
    w_18_14   normalized_mass_18_66  1
    w_18_14   normalized_ratio_18_67  -1.5555555555555554e+00
    w_18_14   full_original_Gini_326  -1.8473809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_15   OBJ       2.0249999999999976e-02
    x_18_15   product_lb_59  -0.0253136583258579
    x_18_15   product_ub_60  -4.2505819249106368e-02
    x_18_15   onehot_18_65  1
    x_18_15   stock_lb_266  15
    x_18_15   stock_ub_267  15
    x_18_15   parent_nonstrict_scope_268  8.0999999999999975e-02
    x_18_15   unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_15   product_lb_59  1
    w_18_15   product_ub_60  1
    w_18_15   normalized_mass_18_66  1
    w_18_15   normalized_ratio_18_67  -1.6666666666666665e+00
    w_18_15   full_original_Gini_326  -2.1473809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_16   OBJ       3.3749999999999988e-02
    x_18_16   product_lb_61  -0.0253136583258579
    x_18_16   product_ub_62  -4.2505819249106368e-02
    x_18_16   onehot_18_65  1
    x_18_16   stock_lb_266  16
    x_18_16   stock_ub_267  16
    x_18_16   parent_nonstrict_scope_268  9.4499999999999987e-02
    x_18_16   unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_16   product_lb_61  1
    w_18_16   product_ub_62  1
    w_18_16   normalized_mass_18_66  1
    w_18_16   normalized_ratio_18_67  -1.7777777777777777e+00
    w_18_16   full_original_Gini_326  -2.4473809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_17   OBJ       4.7249999999999986e-02
    x_18_17   product_lb_63  -0.0253136583258579
    x_18_17   product_ub_64  -4.2505819249106368e-02
    x_18_17   onehot_18_65  1
    x_18_17   stock_lb_266  17
    x_18_17   stock_ub_267  17
    x_18_17   parent_nonstrict_scope_268  1.0799999999999998e-01
    x_18_17   unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_17   product_lb_63  1
    w_18_17   product_ub_64  1
    w_18_17   normalized_mass_18_66  1
    w_18_17   normalized_ratio_18_67  -1.8888888888888888e+00
    w_18_17   full_original_Gini_326  -2.7473809523809525e+01
    rho_18    normalized_ratio_18_67  1
    rho_18    block_pair_pos_281  -1
    rho_18    block_pair_neg_282  1
    rho_18    block_pair_pos_283  -1
    rho_18    block_pair_neg_284  1
    rho_18    block_pair_pos_285  -1
    rho_18    block_pair_neg_286  1
    rho_18    block_pair_pos_287  -1
    rho_18    block_pair_neg_288  1
    rho_18    block_pair_pos_289  -1
    rho_18    block_pair_neg_290  1
    rho_18    block_pair_pos_291  -1
    rho_18    block_pair_neg_292  1
    rho_18    block_pair_pos_301  1
    rho_18    block_pair_neg_302  -1
    rho_18    normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_68  -0.0253136583258579
    x_31_0    product_ub_69  -4.2505819249106368e-02
    x_31_0    onehot_31_94  1
    x_31_0    parent_nonstrict_scope_268  0.0735
    x_31_0    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_68  1
    w_31_0    product_ub_69  1
    w_31_0    normalized_mass_31_95  1
    w_31_0    full_original_Gini_326  -2.3526190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_70  -0.0253136583258579
    x_31_1    product_ub_71  -4.2505819249106368e-02
    x_31_1    onehot_31_94  1
    x_31_1    stock_lb_266  1
    x_31_1    stock_ub_267  1
    x_31_1    parent_nonstrict_scope_268  0.063
    x_31_1    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_70  1
    w_31_1    product_ub_71  1
    w_31_1    normalized_mass_31_95  1
    w_31_1    normalized_ratio_31_96  -1.4285714285714285e-01
    w_31_1    full_original_Gini_326  -1.9954761904761909e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_72  -0.0253136583258579
    x_31_2    product_ub_73  -4.2505819249106368e-02
    x_31_2    onehot_31_94  1
    x_31_2    stock_lb_266  2
    x_31_2    stock_ub_267  2
    x_31_2    parent_nonstrict_scope_268  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_72  1
    w_31_2    product_ub_73  1
    w_31_2    normalized_mass_31_95  1
    w_31_2    normalized_ratio_31_96  -2.8571428571428570e-01
    w_31_2    full_original_Gini_326  -1.6383333333333329e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_74  -0.0253136583258579
    x_31_3    product_ub_75  -4.2505819249106368e-02
    x_31_3    onehot_31_94  1
    x_31_3    stock_lb_266  3
    x_31_3    stock_ub_267  3
    x_31_3    parent_nonstrict_scope_268  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_74  1
    w_31_3    product_ub_75  1
    w_31_3    normalized_mass_31_95  1
    w_31_3    normalized_ratio_31_96  -4.2857142857142855e-01
    w_31_3    full_original_Gini_326  -1.2926190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_76  -0.0253136583258579
    x_31_4    product_ub_77  -4.2505819249106368e-02
    x_31_4    onehot_31_94  1
    x_31_4    stock_lb_266  4
    x_31_4    stock_ub_267  4
    x_31_4    parent_nonstrict_scope_268  0.0315
    x_31_4    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_76  1
    w_31_4    product_ub_77  1
    w_31_4    normalized_mass_31_95  1
    w_31_4    normalized_ratio_31_96  -5.7142857142857140e-01
    w_31_4    full_original_Gini_326  -9.92619047619048
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_78  -0.0253136583258579
    x_31_5    product_ub_79  -4.2505819249106368e-02
    x_31_5    onehot_31_94  1
    x_31_5    stock_lb_266  5
    x_31_5    stock_ub_267  5
    x_31_5    parent_nonstrict_scope_268  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_78  1
    w_31_5    product_ub_79  1
    w_31_5    normalized_mass_31_95  1
    w_31_5    normalized_ratio_31_96  -7.1428571428571419e-01
    w_31_5    full_original_Gini_326  -6.9261904761904773e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_80  -0.0253136583258579
    x_31_6    product_ub_81  -4.2505819249106368e-02
    x_31_6    onehot_31_94  1
    x_31_6    stock_lb_266  6
    x_31_6    stock_ub_267  6
    x_31_6    parent_nonstrict_scope_268  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_80  1
    w_31_6    product_ub_81  1
    w_31_6    normalized_mass_31_95  1
    w_31_6    normalized_ratio_31_96  -8.5714285714285710e-01
    w_31_6    full_original_Gini_326  -4.65952380952381
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_82  -0.0253136583258579
    x_31_7    product_ub_83  -4.2505819249106368e-02
    x_31_7    onehot_31_94  1
    x_31_7    stock_lb_266  7
    x_31_7    stock_ub_267  7
    x_31_7    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_82  1
    w_31_7    product_ub_83  1
    w_31_7    normalized_mass_31_95  1
    w_31_7    normalized_ratio_31_96  -1
    w_31_7    full_original_Gini_326  -3.8738095238095243e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_84  -0.0253136583258579
    x_31_8    product_ub_85  -4.2505819249106368e-02
    x_31_8    onehot_31_94  1
    x_31_8    stock_lb_266  8
    x_31_8    stock_ub_267  8
    x_31_8    parent_nonstrict_scope_268  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_84  1
    w_31_8    product_ub_85  1
    w_31_8    normalized_mass_31_95  1
    w_31_8    normalized_ratio_31_96  -1.1428571428571428e+00
    w_31_8    full_original_Gini_326  -7.4452380952380928e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_86  -0.0253136583258579
    x_31_9    product_ub_87  -4.2505819249106368e-02
    x_31_9    onehot_31_94  1
    x_31_9    stock_lb_266  9
    x_31_9    stock_ub_267  9
    x_31_9    parent_nonstrict_scope_268  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_86  1
    w_31_9    product_ub_87  1
    w_31_9    normalized_mass_31_95  1
    w_31_9    normalized_ratio_31_96  -1.2857142857142856e+00
    w_31_9    full_original_Gini_326  -1.1188095238095233e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_88  -0.0253136583258579
    x_31_10   product_ub_89  -4.2505819249106368e-02
    x_31_10   onehot_31_94  1
    x_31_10   stock_lb_266  10
    x_31_10   stock_ub_267  10
    x_31_10   parent_nonstrict_scope_268  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_88  1
    w_31_10   product_ub_89  1
    w_31_10   normalized_mass_31_95  1
    w_31_10   normalized_ratio_31_96  -1.4285714285714284e+00
    w_31_10   full_original_Gini_326  -1.5045238095238094e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_90  -0.0253136583258579
    x_31_11   product_ub_91  -4.2505819249106368e-02
    x_31_11   onehot_31_94  1
    x_31_11   stock_lb_266  11
    x_31_11   stock_ub_267  11
    x_31_11   parent_nonstrict_scope_268  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_90  1
    w_31_11   product_ub_91  1
    w_31_11   normalized_mass_31_95  1
    w_31_11   normalized_ratio_31_96  -1.5714285714285714e+00
    w_31_11   full_original_Gini_326  -1.8902380952380952e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_92  -0.0253136583258579
    x_31_12   product_ub_93  -4.2505819249106368e-02
    x_31_12   onehot_31_94  1
    x_31_12   stock_lb_266  12
    x_31_12   stock_ub_267  12
    x_31_12   parent_nonstrict_scope_268  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_92  1
    w_31_12   product_ub_93  1
    w_31_12   normalized_mass_31_95  1
    w_31_12   normalized_ratio_31_96  -1.7142857142857142e+00
    w_31_12   full_original_Gini_326  -2.2759523809523809e+01
    rho_31    normalized_ratio_31_96  1
    rho_31    block_pair_pos_289  1
    rho_31    block_pair_neg_290  -1
    rho_31    block_pair_pos_305  1
    rho_31    block_pair_neg_306  -1
    rho_31    block_pair_pos_309  -1
    rho_31    block_pair_neg_310  1
    rho_31    block_pair_pos_311  -1
    rho_31    block_pair_neg_312  1
    rho_31    block_pair_pos_313  -1
    rho_31    block_pair_neg_314  1
    rho_31    block_pair_pos_315  -1
    rho_31    block_pair_neg_316  1
    rho_31    block_pair_pos_317  -1
    rho_31    block_pair_neg_318  1
    rho_31    normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_14_0    OBJ       0.048
    x_14_0    product_lb_97  -0.0253136583258579
    x_14_0    product_ub_98  -4.2505819249106368e-02
    x_14_0    onehot_14_129  1
    x_14_0    parent_nonstrict_scope_268  0.096
    x_14_0    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_0    product_lb_97  1
    w_14_0    product_ub_98  1
    w_14_0    normalized_mass_14_130  1
    w_14_0    full_original_Gini_326  -2.3526190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_1    OBJ       3.6000000000000004e-02
    x_14_1    product_lb_99  -0.0253136583258579
    x_14_1    product_ub_100  -4.2505819249106368e-02
    x_14_1    onehot_14_129  1
    x_14_1    stock_lb_266  1
    x_14_1    stock_ub_267  1
    x_14_1    parent_nonstrict_scope_268  0.084
    x_14_1    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_1    product_lb_99  1
    w_14_1    product_ub_100  1
    w_14_1    normalized_mass_14_130  1
    w_14_1    normalized_ratio_14_131  -0.125
    w_14_1    full_original_Gini_326  -2.0401190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_2    OBJ       2.4000000000000007e-02
    x_14_2    product_lb_101  -0.0253136583258579
    x_14_2    product_ub_102  -4.2505819249106368e-02
    x_14_2    onehot_14_129  1
    x_14_2    stock_lb_266  2
    x_14_2    stock_ub_267  2
    x_14_2    parent_nonstrict_scope_268  7.2000000000000008e-02
    MARKER    'MARKER'                 'INTEND'
    w_14_2    product_lb_101  1
    w_14_2    product_ub_102  1
    w_14_2    normalized_mass_14_130  1
    w_14_2    normalized_ratio_14_131  -0.25
    w_14_2    full_original_Gini_326  -1.7276190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_3    OBJ       1.1999999999999997e-02
    x_14_3    product_lb_103  -0.0253136583258579
    x_14_3    product_ub_104  -4.2505819249106368e-02
    x_14_3    onehot_14_129  1
    x_14_3    stock_lb_266  3
    x_14_3    stock_ub_267  3
    x_14_3    parent_nonstrict_scope_268  0.06
    x_14_3    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_3    product_lb_103  1
    w_14_3    product_ub_104  1
    w_14_3    normalized_mass_14_130  1
    w_14_3    normalized_ratio_14_131  -0.375
    w_14_3    full_original_Gini_326  -1.4151190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_4    product_lb_105  -0.0253136583258579
    x_14_4    product_ub_106  -4.2505819249106368e-02
    x_14_4    onehot_14_129  1
    x_14_4    stock_lb_266  4
    x_14_4    stock_ub_267  4
    x_14_4    parent_nonstrict_scope_268  0.048
    x_14_4    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_4    product_lb_105  1
    w_14_4    product_ub_106  1
    w_14_4    normalized_mass_14_130  1
    w_14_4    normalized_ratio_14_131  -0.5
    w_14_4    full_original_Gini_326  -1.1426190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_5    OBJ       -1.1999999999999997e-02
    x_14_5    product_lb_107  -0.0253136583258579
    x_14_5    product_ub_108  -4.2505819249106368e-02
    x_14_5    onehot_14_129  1
    x_14_5    stock_lb_266  5
    x_14_5    stock_ub_267  5
    x_14_5    parent_nonstrict_scope_268  3.6000000000000004e-02
    x_14_5    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_5    product_lb_107  1
    w_14_5    product_ub_108  1
    w_14_5    normalized_mass_14_130  1
    w_14_5    normalized_ratio_14_131  -0.625
    w_14_5    full_original_Gini_326  -8.8011904761904756e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_6    OBJ       -0.024
    x_14_6    product_lb_109  -0.0253136583258579
    x_14_6    product_ub_110  -4.2505819249106368e-02
    x_14_6    onehot_14_129  1
    x_14_6    stock_lb_266  6
    x_14_6    stock_ub_267  6
    x_14_6    parent_nonstrict_scope_268  0.024
    x_14_6    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_6    product_lb_109  1
    w_14_6    product_ub_110  1
    w_14_6    normalized_mass_14_130  1
    w_14_6    normalized_ratio_14_131  -0.75
    w_14_6    full_original_Gini_326  -6.3190476190476188e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_7    OBJ       -3.6000000000000004e-02
    x_14_7    product_lb_111  -0.0253136583258579
    x_14_7    product_ub_112  -4.2505819249106368e-02
    x_14_7    onehot_14_129  1
    x_14_7    stock_lb_266  7
    x_14_7    stock_ub_267  7
    x_14_7    parent_nonstrict_scope_268  0.012
    x_14_7    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_7    product_lb_111  1
    w_14_7    product_ub_112  1
    w_14_7    normalized_mass_14_130  1
    w_14_7    normalized_ratio_14_131  -0.875
    w_14_7    full_original_Gini_326  -4.4988095238095234e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_8    OBJ       -0.048
    x_14_8    product_lb_113  -0.0253136583258579
    x_14_8    product_ub_114  -4.2505819249106368e-02
    x_14_8    onehot_14_129  1
    x_14_8    stock_lb_266  8
    x_14_8    stock_ub_267  8
    x_14_8    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_8    product_lb_113  1
    w_14_8    product_ub_114  1
    w_14_8    normalized_mass_14_130  1
    w_14_8    normalized_ratio_14_131  -1
    w_14_8    full_original_Gini_326  -3.8738095238095243e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_9    OBJ       -3.6000000000000004e-02
    x_14_9    product_lb_115  -0.0253136583258579
    x_14_9    product_ub_116  -4.2505819249106368e-02
    x_14_9    onehot_14_129  1
    x_14_9    stock_lb_266  9
    x_14_9    stock_ub_267  9
    x_14_9    parent_nonstrict_scope_268  0.012
    x_14_9    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_9    product_lb_115  1
    w_14_9    product_ub_116  1
    w_14_9    normalized_mass_14_130  1
    w_14_9    normalized_ratio_14_131  -1.125
    w_14_9    full_original_Gini_326  -6.9988095238095251e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_10   OBJ       -0.024
    x_14_10   product_lb_117  -0.0253136583258579
    x_14_10   product_ub_118  -4.2505819249106368e-02
    x_14_10   onehot_14_129  1
    x_14_10   stock_lb_266  10
    x_14_10   stock_ub_267  10
    x_14_10   parent_nonstrict_scope_268  0.024
    x_14_10   unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_10   product_lb_117  1
    w_14_10   product_ub_118  1
    w_14_10   normalized_mass_14_130  1
    w_14_10   normalized_ratio_14_131  -1.25
    w_14_10   full_original_Gini_326  -1.0223809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_11   OBJ       -1.1999999999999997e-02
    x_14_11   product_lb_119  -0.0253136583258579
    x_14_11   product_ub_120  -4.2505819249106368e-02
    x_14_11   onehot_14_129  1
    x_14_11   stock_lb_266  11
    x_14_11   stock_ub_267  11
    x_14_11   parent_nonstrict_scope_268  3.6000000000000004e-02
    x_14_11   unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_11   product_lb_119  1
    w_14_11   product_ub_120  1
    w_14_11   normalized_mass_14_130  1
    w_14_11   normalized_ratio_14_131  -1.375
    w_14_11   full_original_Gini_326  -1.3598809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_12   product_lb_121  -0.0253136583258579
    x_14_12   product_ub_122  -4.2505819249106368e-02
    x_14_12   onehot_14_129  1
    x_14_12   stock_lb_266  12
    x_14_12   stock_ub_267  12
    x_14_12   parent_nonstrict_scope_268  0.048
    x_14_12   unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_12   product_lb_121  1
    w_14_12   product_ub_122  1
    w_14_12   normalized_mass_14_130  1
    w_14_12   normalized_ratio_14_131  -1.5
    w_14_12   full_original_Gini_326  -1.6973809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_13   OBJ       1.1999999999999997e-02
    x_14_13   product_lb_123  -0.0253136583258579
    x_14_13   product_ub_124  -4.2505819249106368e-02
    x_14_13   onehot_14_129  1
    x_14_13   stock_lb_266  13
    x_14_13   stock_ub_267  13
    x_14_13   parent_nonstrict_scope_268  0.06
    x_14_13   unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_13   product_lb_123  1
    w_14_13   product_ub_124  1
    w_14_13   normalized_mass_14_130  1
    w_14_13   normalized_ratio_14_131  -1.625
    w_14_13   full_original_Gini_326  -2.0348809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_14   OBJ       2.4000000000000007e-02
    x_14_14   product_lb_125  -0.0253136583258579
    x_14_14   product_ub_126  -4.2505819249106368e-02
    x_14_14   onehot_14_129  1
    x_14_14   stock_lb_266  14
    x_14_14   stock_ub_267  14
    x_14_14   parent_nonstrict_scope_268  7.2000000000000008e-02
    x_14_14   unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_14   product_lb_125  1
    w_14_14   product_ub_126  1
    w_14_14   normalized_mass_14_130  1
    w_14_14   normalized_ratio_14_131  -1.75
    w_14_14   full_original_Gini_326  -2.3723809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_15   OBJ       3.6000000000000004e-02
    x_14_15   product_lb_127  -0.0253136583258579
    x_14_15   product_ub_128  -4.2505819249106368e-02
    x_14_15   onehot_14_129  1
    x_14_15   stock_lb_266  15
    x_14_15   stock_ub_267  15
    x_14_15   parent_nonstrict_scope_268  0.084
    x_14_15   unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_15   product_lb_127  1
    w_14_15   product_ub_128  1
    w_14_15   normalized_mass_14_130  1
    w_14_15   normalized_ratio_14_131  -1.875
    w_14_15   full_original_Gini_326  -2.7098809523809525e+01
    rho_14    normalized_ratio_14_131  1
    rho_14    block_pair_pos_273  -1
    rho_14    block_pair_neg_274  1
    rho_14    block_pair_pos_275  -1
    rho_14    block_pair_neg_276  1
    rho_14    block_pair_pos_277  -1
    rho_14    block_pair_neg_278  1
    rho_14    block_pair_pos_279  -1
    rho_14    block_pair_neg_280  1
    rho_14    block_pair_pos_285  1
    rho_14    block_pair_neg_286  -1
    rho_14    block_pair_pos_299  1
    rho_14    block_pair_neg_300  -1
    rho_14    block_pair_pos_313  1
    rho_14    block_pair_neg_314  -1
    rho_14    normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_132  -0.0253136583258579
    x_32_0    product_ub_133  -4.2505819249106368e-02
    x_32_0    onehot_32_158  1
    x_32_0    parent_nonstrict_scope_268  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_132  1
    w_32_0    product_ub_133  1
    w_32_0    normalized_mass_32_159  1
    w_32_0    full_original_Gini_326  -2.3526190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_134  -0.0253136583258579
    x_32_1    product_ub_135  -4.2505819249106368e-02
    x_32_1    onehot_32_158  1
    x_32_1    stock_lb_266  1
    x_32_1    stock_ub_267  1
    x_32_1    parent_nonstrict_scope_268  0.03
    x_32_1    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_134  1
    w_32_1    product_ub_135  1
    w_32_1    normalized_mass_32_159  1
    w_32_1    normalized_ratio_32_160  -0.2
    w_32_1    full_original_Gini_326  -1.8526190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_136  -0.0253136583258579
    x_32_2    product_ub_137  -4.2505819249106368e-02
    x_32_2    onehot_32_158  1
    x_32_2    stock_lb_266  2
    x_32_2    stock_ub_267  2
    x_32_2    parent_nonstrict_scope_268  0.0225
    x_32_2    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_136  1
    w_32_2    product_ub_137  1
    w_32_2    normalized_mass_32_159  1
    w_32_2    normalized_ratio_32_160  -0.4
    w_32_2    full_original_Gini_326  -1.3526190476190473e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_138  -0.0253136583258579
    x_32_3    product_ub_139  -4.2505819249106368e-02
    x_32_3    onehot_32_158  1
    x_32_3    stock_lb_266  3
    x_32_3    stock_ub_267  3
    x_32_3    parent_nonstrict_scope_268  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_138  1
    w_32_3    product_ub_139  1
    w_32_3    normalized_mass_32_159  1
    w_32_3    normalized_ratio_32_160  -6.0000000000000009e-01
    w_32_3    full_original_Gini_326  -9.3261904761904759e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_140  -0.0253136583258579
    x_32_4    product_ub_141  -4.2505819249106368e-02
    x_32_4    onehot_32_158  1
    x_32_4    stock_lb_266  4
    x_32_4    stock_ub_267  4
    x_32_4    parent_nonstrict_scope_268  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_140  1
    w_32_4    product_ub_141  1
    w_32_4    normalized_mass_32_159  1
    w_32_4    normalized_ratio_32_160  -0.8
    w_32_4    full_original_Gini_326  -5.4690476190476209e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_142  -0.0253136583258579
    x_32_5    product_ub_143  -4.2505819249106368e-02
    x_32_5    onehot_32_158  1
    x_32_5    stock_lb_266  5
    x_32_5    stock_ub_267  5
    x_32_5    unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_142  1
    w_32_5    product_ub_143  1
    w_32_5    normalized_mass_32_159  1
    w_32_5    normalized_ratio_32_160  -1
    w_32_5    full_original_Gini_326  -3.8738095238095243e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_144  -0.0253136583258579
    x_32_6    product_ub_145  -4.2505819249106368e-02
    x_32_6    onehot_32_158  1
    x_32_6    stock_lb_266  6
    x_32_6    stock_ub_267  6
    x_32_6    parent_nonstrict_scope_268  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_144  1
    w_32_6    product_ub_145  1
    w_32_6    normalized_mass_32_159  1
    w_32_6    normalized_ratio_32_160  -1.2000000000000002e+00
    w_32_6    full_original_Gini_326  -8.87380952380953
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_146  -0.0253136583258579
    x_32_7    product_ub_147  -4.2505819249106368e-02
    x_32_7    onehot_32_158  1
    x_32_7    stock_lb_266  7
    x_32_7    stock_ub_267  7
    x_32_7    parent_nonstrict_scope_268  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_146  1
    w_32_7    product_ub_147  1
    w_32_7    normalized_mass_32_159  1
    w_32_7    normalized_ratio_32_160  -1.4000000000000001e+00
    w_32_7    full_original_Gini_326  -1.4273809523809529e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_148  -0.0253136583258579
    x_32_8    product_ub_149  -4.2505819249106368e-02
    x_32_8    onehot_32_158  1
    x_32_8    stock_lb_266  8
    x_32_8    stock_ub_267  8
    x_32_8    parent_nonstrict_scope_268  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_148  1
    w_32_8    product_ub_149  1
    w_32_8    normalized_mass_32_159  1
    w_32_8    normalized_ratio_32_160  -1.6
    w_32_8    full_original_Gini_326  -1.9673809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_150  -0.0253136583258579
    x_32_9    product_ub_151  -4.2505819249106368e-02
    x_32_9    onehot_32_158  1
    x_32_9    stock_lb_266  9
    x_32_9    stock_ub_267  9
    x_32_9    parent_nonstrict_scope_268  0.03
    x_32_9    unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_150  1
    w_32_9    product_ub_151  1
    w_32_9    normalized_mass_32_159  1
    w_32_9    normalized_ratio_32_160  -1.8
    w_32_9    full_original_Gini_326  -2.5073809523809530e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_152  -0.0253136583258579
    x_32_10   product_ub_153  -4.2505819249106368e-02
    x_32_10   onehot_32_158  1
    x_32_10   stock_lb_266  10
    x_32_10   stock_ub_267  10
    x_32_10   parent_nonstrict_scope_268  0.0375
    x_32_10   unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_152  1
    w_32_10   product_ub_153  1
    w_32_10   normalized_mass_32_159  1
    w_32_10   normalized_ratio_32_160  -2
    w_32_10   full_original_Gini_326  -3.0473809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_154  -0.0253136583258579
    x_32_11   product_ub_155  -4.2505819249106368e-02
    x_32_11   onehot_32_158  1
    x_32_11   stock_lb_266  11
    x_32_11   stock_ub_267  11
    x_32_11   parent_nonstrict_scope_268  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_154  1
    w_32_11   product_ub_155  1
    w_32_11   normalized_mass_32_159  1
    w_32_11   normalized_ratio_32_160  -2.2
    w_32_11   full_original_Gini_326  -3.5873809523809513e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_156  -0.0253136583258579
    x_32_12   product_ub_157  -4.2505819249106368e-02
    x_32_12   onehot_32_158  1
    x_32_12   stock_lb_266  12
    x_32_12   stock_ub_267  12
    x_32_12   parent_nonstrict_scope_268  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_156  1
    w_32_12   product_ub_157  1
    w_32_12   normalized_mass_32_159  1
    w_32_12   normalized_ratio_32_160  -2.4000000000000004e+00
    w_32_12   full_original_Gini_326  -4.1273809523809518e+01
    rho_32    normalized_ratio_32_160  1
    rho_32    block_pair_pos_279  1
    rho_32    block_pair_neg_280  -1
    rho_32    block_pair_pos_291  1
    rho_32    block_pair_neg_292  -1
    rho_32    block_pair_pos_307  1
    rho_32    block_pair_neg_308  -1
    rho_32    block_pair_pos_317  1
    rho_32    block_pair_neg_318  -1
    rho_32    block_pair_pos_319  -1
    rho_32    block_pair_neg_320  1
    rho_32    block_pair_pos_321  -1
    rho_32    block_pair_neg_322  1
    rho_32    block_pair_pos_323  -1
    rho_32    block_pair_neg_324  1
    rho_32    normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_5_0     OBJ       0.048
    x_5_0     product_lb_161  -0.0253136583258579
    x_5_0     product_ub_162  -4.2505819249106368e-02
    x_5_0     onehot_5_195  1
    x_5_0     parent_nonstrict_scope_268  0.096
    x_5_0     unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_0     product_lb_161  1
    w_5_0     product_ub_162  1
    w_5_0     normalized_mass_5_196  1
    w_5_0     full_original_Gini_326  -2.3526190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_1     OBJ       3.6000000000000004e-02
    x_5_1     product_lb_163  -0.0253136583258579
    x_5_1     product_ub_164  -4.2505819249106368e-02
    x_5_1     onehot_5_195  1
    x_5_1     stock_lb_266  1
    x_5_1     stock_ub_267  1
    x_5_1     parent_nonstrict_scope_268  0.084
    x_5_1     unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_1     product_lb_163  1
    w_5_1     product_ub_164  1
    w_5_1     normalized_mass_5_196  1
    w_5_1     normalized_ratio_5_197  -0.125
    w_5_1     full_original_Gini_326  -2.0401190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_2     OBJ       2.4000000000000007e-02
    x_5_2     product_lb_165  -0.0253136583258579
    x_5_2     product_ub_166  -4.2505819249106368e-02
    x_5_2     onehot_5_195  1
    x_5_2     stock_lb_266  2
    x_5_2     stock_ub_267  2
    x_5_2     parent_nonstrict_scope_268  7.2000000000000008e-02
    MARKER    'MARKER'                 'INTEND'
    w_5_2     product_lb_165  1
    w_5_2     product_ub_166  1
    w_5_2     normalized_mass_5_196  1
    w_5_2     normalized_ratio_5_197  -0.25
    w_5_2     full_original_Gini_326  -1.7276190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_3     OBJ       1.1999999999999997e-02
    x_5_3     product_lb_167  -0.0253136583258579
    x_5_3     product_ub_168  -4.2505819249106368e-02
    x_5_3     onehot_5_195  1
    x_5_3     stock_lb_266  3
    x_5_3     stock_ub_267  3
    x_5_3     parent_nonstrict_scope_268  0.06
    x_5_3     unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_3     product_lb_167  1
    w_5_3     product_ub_168  1
    w_5_3     normalized_mass_5_196  1
    w_5_3     normalized_ratio_5_197  -0.375
    w_5_3     full_original_Gini_326  -1.4151190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_4     product_lb_169  -0.0253136583258579
    x_5_4     product_ub_170  -4.2505819249106368e-02
    x_5_4     onehot_5_195  1
    x_5_4     stock_lb_266  4
    x_5_4     stock_ub_267  4
    x_5_4     parent_nonstrict_scope_268  0.048
    x_5_4     unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_4     product_lb_169  1
    w_5_4     product_ub_170  1
    w_5_4     normalized_mass_5_196  1
    w_5_4     normalized_ratio_5_197  -0.5
    w_5_4     full_original_Gini_326  -1.1426190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_5     OBJ       -1.1999999999999997e-02
    x_5_5     product_lb_171  -0.0253136583258579
    x_5_5     product_ub_172  -4.2505819249106368e-02
    x_5_5     onehot_5_195  1
    x_5_5     stock_lb_266  5
    x_5_5     stock_ub_267  5
    x_5_5     parent_nonstrict_scope_268  3.6000000000000004e-02
    x_5_5     unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_5     product_lb_171  1
    w_5_5     product_ub_172  1
    w_5_5     normalized_mass_5_196  1
    w_5_5     normalized_ratio_5_197  -0.625
    w_5_5     full_original_Gini_326  -8.8011904761904756e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_6     OBJ       -0.024
    x_5_6     product_lb_173  -0.0253136583258579
    x_5_6     product_ub_174  -4.2505819249106368e-02
    x_5_6     onehot_5_195  1
    x_5_6     stock_lb_266  6
    x_5_6     stock_ub_267  6
    x_5_6     parent_nonstrict_scope_268  0.024
    x_5_6     unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_6     product_lb_173  1
    w_5_6     product_ub_174  1
    w_5_6     normalized_mass_5_196  1
    w_5_6     normalized_ratio_5_197  -0.75
    w_5_6     full_original_Gini_326  -6.3190476190476188e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_7     OBJ       -3.6000000000000004e-02
    x_5_7     product_lb_175  -0.0253136583258579
    x_5_7     product_ub_176  -4.2505819249106368e-02
    x_5_7     onehot_5_195  1
    x_5_7     stock_lb_266  7
    x_5_7     stock_ub_267  7
    x_5_7     parent_nonstrict_scope_268  0.012
    x_5_7     unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_7     product_lb_175  1
    w_5_7     product_ub_176  1
    w_5_7     normalized_mass_5_196  1
    w_5_7     normalized_ratio_5_197  -0.875
    w_5_7     full_original_Gini_326  -4.4988095238095234e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_8     OBJ       -0.048
    x_5_8     product_lb_177  -0.0253136583258579
    x_5_8     product_ub_178  -4.2505819249106368e-02
    x_5_8     onehot_5_195  1
    x_5_8     stock_lb_266  8
    x_5_8     stock_ub_267  8
    x_5_8     unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_8     product_lb_177  1
    w_5_8     product_ub_178  1
    w_5_8     normalized_mass_5_196  1
    w_5_8     normalized_ratio_5_197  -1
    w_5_8     full_original_Gini_326  -3.8738095238095243e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_9     OBJ       -3.6000000000000004e-02
    x_5_9     product_lb_179  -0.0253136583258579
    x_5_9     product_ub_180  -4.2505819249106368e-02
    x_5_9     onehot_5_195  1
    x_5_9     stock_lb_266  9
    x_5_9     stock_ub_267  9
    x_5_9     parent_nonstrict_scope_268  0.012
    x_5_9     unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_9     product_lb_179  1
    w_5_9     product_ub_180  1
    w_5_9     normalized_mass_5_196  1
    w_5_9     normalized_ratio_5_197  -1.125
    w_5_9     full_original_Gini_326  -6.9988095238095251e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_10    OBJ       -0.024
    x_5_10    product_lb_181  -0.0253136583258579
    x_5_10    product_ub_182  -4.2505819249106368e-02
    x_5_10    onehot_5_195  1
    x_5_10    stock_lb_266  10
    x_5_10    stock_ub_267  10
    x_5_10    parent_nonstrict_scope_268  0.024
    x_5_10    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_10    product_lb_181  1
    w_5_10    product_ub_182  1
    w_5_10    normalized_mass_5_196  1
    w_5_10    normalized_ratio_5_197  -1.25
    w_5_10    full_original_Gini_326  -1.0223809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_11    OBJ       -1.1999999999999997e-02
    x_5_11    product_lb_183  -0.0253136583258579
    x_5_11    product_ub_184  -4.2505819249106368e-02
    x_5_11    onehot_5_195  1
    x_5_11    stock_lb_266  11
    x_5_11    stock_ub_267  11
    x_5_11    parent_nonstrict_scope_268  3.6000000000000004e-02
    x_5_11    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_11    product_lb_183  1
    w_5_11    product_ub_184  1
    w_5_11    normalized_mass_5_196  1
    w_5_11    normalized_ratio_5_197  -1.375
    w_5_11    full_original_Gini_326  -1.3598809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_12    product_lb_185  -0.0253136583258579
    x_5_12    product_ub_186  -4.2505819249106368e-02
    x_5_12    onehot_5_195  1
    x_5_12    stock_lb_266  12
    x_5_12    stock_ub_267  12
    x_5_12    parent_nonstrict_scope_268  0.048
    x_5_12    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_12    product_lb_185  1
    w_5_12    product_ub_186  1
    w_5_12    normalized_mass_5_196  1
    w_5_12    normalized_ratio_5_197  -1.5
    w_5_12    full_original_Gini_326  -1.6973809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_13    OBJ       1.1999999999999997e-02
    x_5_13    product_lb_187  -0.0253136583258579
    x_5_13    product_ub_188  -4.2505819249106368e-02
    x_5_13    onehot_5_195  1
    x_5_13    stock_lb_266  13
    x_5_13    stock_ub_267  13
    x_5_13    parent_nonstrict_scope_268  0.06
    x_5_13    unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_13    product_lb_187  1
    w_5_13    product_ub_188  1
    w_5_13    normalized_mass_5_196  1
    w_5_13    normalized_ratio_5_197  -1.625
    w_5_13    full_original_Gini_326  -2.0348809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_14    OBJ       2.4000000000000007e-02
    x_5_14    product_lb_189  -0.0253136583258579
    x_5_14    product_ub_190  -4.2505819249106368e-02
    x_5_14    onehot_5_195  1
    x_5_14    stock_lb_266  14
    x_5_14    stock_ub_267  14
    x_5_14    parent_nonstrict_scope_268  7.2000000000000008e-02
    x_5_14    unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_14    product_lb_189  1
    w_5_14    product_ub_190  1
    w_5_14    normalized_mass_5_196  1
    w_5_14    normalized_ratio_5_197  -1.75
    w_5_14    full_original_Gini_326  -2.3723809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_15    OBJ       3.6000000000000004e-02
    x_5_15    product_lb_191  -0.0253136583258579
    x_5_15    product_ub_192  -4.2505819249106368e-02
    x_5_15    onehot_5_195  1
    x_5_15    stock_lb_266  15
    x_5_15    stock_ub_267  15
    x_5_15    parent_nonstrict_scope_268  0.084
    x_5_15    unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_15    product_lb_191  1
    w_5_15    product_ub_192  1
    w_5_15    normalized_mass_5_196  1
    w_5_15    normalized_ratio_5_197  -1.875
    w_5_15    full_original_Gini_326  -2.7098809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_16    OBJ       0.048
    x_5_16    product_lb_193  -0.0253136583258579
    x_5_16    product_ub_194  -4.2505819249106368e-02
    x_5_16    onehot_5_195  1
    x_5_16    stock_lb_266  16
    x_5_16    stock_ub_267  16
    x_5_16    parent_nonstrict_scope_268  0.096
    x_5_16    unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_16    product_lb_193  1
    w_5_16    product_ub_194  1
    w_5_16    normalized_mass_5_196  1
    w_5_16    normalized_ratio_5_197  -2
    w_5_16    full_original_Gini_326  -3.0473809523809525e+01
    rho_5     normalized_ratio_5_197  1
    rho_5     block_pair_pos_269  -1
    rho_5     block_pair_neg_270  1
    rho_5     block_pair_pos_271  -1
    rho_5     block_pair_neg_272  1
    rho_5     block_pair_pos_273  1
    rho_5     block_pair_neg_274  -1
    rho_5     block_pair_pos_281  1
    rho_5     block_pair_neg_282  -1
    rho_5     block_pair_pos_295  1
    rho_5     block_pair_neg_296  -1
    rho_5     block_pair_pos_309  1
    rho_5     block_pair_neg_310  -1
    rho_5     block_pair_pos_319  1
    rho_5     block_pair_neg_320  -1
    rho_5     normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       0.012
    x_19_0    product_lb_198  -0.0253136583258579
    x_19_0    product_ub_199  -4.2505819249106368e-02
    x_19_0    onehot_19_216  1
    x_19_0    parent_nonstrict_scope_268  0.024
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_198  1
    w_19_0    product_ub_199  1
    w_19_0    normalized_mass_19_217  1
    w_19_0    full_original_Gini_326  -2.3526190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.0000000000000019e-03
    x_19_1    product_lb_200  -0.0253136583258579
    x_19_1    product_ub_201  -4.2505819249106368e-02
    x_19_1    onehot_19_216  1
    x_19_1    stock_lb_266  1
    x_19_1    stock_ub_267  1
    x_19_1    parent_nonstrict_scope_268  1.8000000000000002e-02
    x_19_1    unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_200  1
    w_19_1    product_ub_201  1
    w_19_1    normalized_mass_19_217  1
    w_19_1    normalized_ratio_19_218  -0.25
    w_19_1    full_original_Gini_326  -1.7276190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    product_lb_202  -0.0253136583258579
    x_19_2    product_ub_203  -4.2505819249106368e-02
    x_19_2    onehot_19_216  1
    x_19_2    stock_lb_266  2
    x_19_2    stock_ub_267  2
    x_19_2    parent_nonstrict_scope_268  0.012
    x_19_2    unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_202  1
    w_19_2    product_ub_203  1
    w_19_2    normalized_mass_19_217  1
    w_19_2    normalized_ratio_19_218  -0.5
    w_19_2    full_original_Gini_326  -1.1426190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.006
    x_19_3    product_lb_204  -0.0253136583258579
    x_19_3    product_ub_205  -4.2505819249106368e-02
    x_19_3    onehot_19_216  1
    x_19_3    stock_lb_266  3
    x_19_3    stock_ub_267  3
    x_19_3    parent_nonstrict_scope_268  0.006
    x_19_3    unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_204  1
    w_19_3    product_ub_205  1
    w_19_3    normalized_mass_19_217  1
    w_19_3    normalized_ratio_19_218  -0.75
    w_19_3    full_original_Gini_326  -6.3190476190476188e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -0.012
    x_19_4    product_lb_206  -0.0253136583258579
    x_19_4    product_ub_207  -4.2505819249106368e-02
    x_19_4    onehot_19_216  1
    x_19_4    stock_lb_266  4
    x_19_4    stock_ub_267  4
    x_19_4    unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_206  1
    w_19_4    product_ub_207  1
    w_19_4    normalized_mass_19_217  1
    w_19_4    normalized_ratio_19_218  -1
    w_19_4    full_original_Gini_326  -3.8738095238095243e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -0.006
    x_19_5    product_lb_208  -0.0253136583258579
    x_19_5    product_ub_209  -4.2505819249106368e-02
    x_19_5    onehot_19_216  1
    x_19_5    stock_lb_266  5
    x_19_5    stock_ub_267  5
    x_19_5    parent_nonstrict_scope_268  0.006
    x_19_5    unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_208  1
    w_19_5    product_ub_209  1
    w_19_5    normalized_mass_19_217  1
    w_19_5    normalized_ratio_19_218  -1.25
    w_19_5    full_original_Gini_326  -1.0223809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_6    product_lb_210  -0.0253136583258579
    x_19_6    product_ub_211  -4.2505819249106368e-02
    x_19_6    onehot_19_216  1
    x_19_6    stock_lb_266  6
    x_19_6    stock_ub_267  6
    x_19_6    parent_nonstrict_scope_268  0.012
    x_19_6    unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_210  1
    w_19_6    product_ub_211  1
    w_19_6    normalized_mass_19_217  1
    w_19_6    normalized_ratio_19_218  -1.5
    w_19_6    full_original_Gini_326  -1.6973809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       6.0000000000000019e-03
    x_19_7    product_lb_212  -0.0253136583258579
    x_19_7    product_ub_213  -4.2505819249106368e-02
    x_19_7    onehot_19_216  1
    x_19_7    stock_lb_266  7
    x_19_7    stock_ub_267  7
    x_19_7    parent_nonstrict_scope_268  1.8000000000000002e-02
    x_19_7    unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_212  1
    w_19_7    product_ub_213  1
    w_19_7    normalized_mass_19_217  1
    w_19_7    normalized_ratio_19_218  -1.75
    w_19_7    full_original_Gini_326  -2.3723809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.012
    x_19_8    product_lb_214  -0.0253136583258579
    x_19_8    product_ub_215  -4.2505819249106368e-02
    x_19_8    onehot_19_216  1
    x_19_8    stock_lb_266  8
    x_19_8    stock_ub_267  8
    x_19_8    parent_nonstrict_scope_268  0.024
    x_19_8    unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_214  1
    w_19_8    product_ub_215  1
    w_19_8    normalized_mass_19_217  1
    w_19_8    normalized_ratio_19_218  -2
    w_19_8    full_original_Gini_326  -3.0473809523809525e+01
    rho_19    normalized_ratio_19_218  1
    rho_19    block_pair_pos_271  1
    rho_19    block_pair_neg_272  -1
    rho_19    block_pair_pos_277  1
    rho_19    block_pair_neg_278  -1
    rho_19    block_pair_pos_287  1
    rho_19    block_pair_neg_288  -1
    rho_19    block_pair_pos_293  -1
    rho_19    block_pair_neg_294  1
    rho_19    block_pair_pos_303  1
    rho_19    block_pair_neg_304  -1
    rho_19    block_pair_pos_315  1
    rho_19    block_pair_neg_316  -1
    rho_19    block_pair_pos_323  1
    rho_19    block_pair_neg_324  -1
    rho_19    normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_8_0     OBJ       6.7499999999999991e-02
    x_8_0     product_lb_219  -0.0253136583258579
    x_8_0     product_ub_220  -4.2505819249106368e-02
    x_8_0     onehot_8_263  1
    x_8_0     parent_nonstrict_scope_268  0.15
    x_8_0     unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_0     product_lb_219  1
    w_8_0     product_ub_220  1
    w_8_0     normalized_mass_8_264  1
    w_8_0     full_original_Gini_326  -2.3526190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_1     OBJ       5.2500000000000005e-02
    x_8_1     product_lb_221  -0.0253136583258579
    x_8_1     product_ub_222  -4.2505819249106368e-02
    x_8_1     onehot_8_263  1
    x_8_1     stock_lb_266  1
    x_8_1     stock_ub_267  1
    x_8_1     parent_nonstrict_scope_268  0.135
    x_8_1     unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_1     product_lb_221  1
    w_8_1     product_ub_222  1
    w_8_1     normalized_mass_8_264  1
    w_8_1     normalized_ratio_8_265  -0.1
    w_8_1     full_original_Gini_326  -2.1026190476190472e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_2     OBJ       3.7499999999999992e-02
    x_8_2     product_lb_223  -0.0253136583258579
    x_8_2     product_ub_224  -4.2505819249106368e-02
    x_8_2     onehot_8_263  1
    x_8_2     stock_lb_266  2
    x_8_2     stock_ub_267  2
    x_8_2     parent_nonstrict_scope_268  0.12
    x_8_2     unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_2     product_lb_223  1
    w_8_2     product_ub_224  1
    w_8_2     normalized_mass_8_264  1
    w_8_2     normalized_ratio_8_265  -0.2
    w_8_2     full_original_Gini_326  -1.8526190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_3     OBJ       2.2499999999999992e-02
    x_8_3     product_lb_225  -0.0253136583258579
    x_8_3     product_ub_226  -4.2505819249106368e-02
    x_8_3     onehot_8_263  1
    x_8_3     stock_lb_266  3
    x_8_3     stock_ub_267  3
    x_8_3     parent_nonstrict_scope_268  0.105
    x_8_3     unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_3     product_lb_225  1
    w_8_3     product_ub_226  1
    w_8_3     normalized_mass_8_264  1
    w_8_3     normalized_ratio_8_265  -3.0000000000000004e-01
    w_8_3     full_original_Gini_326  -1.6026190476190472e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_4     OBJ       7.4999999999999928e-03
    x_8_4     product_lb_227  -0.0253136583258579
    x_8_4     product_ub_228  -4.2505819249106368e-02
    x_8_4     onehot_8_263  1
    x_8_4     stock_lb_266  4
    x_8_4     stock_ub_267  4
    x_8_4     parent_nonstrict_scope_268  0.09
    x_8_4     unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_4     product_lb_227  1
    w_8_4     product_ub_228  1
    w_8_4     normalized_mass_8_264  1
    w_8_4     normalized_ratio_8_265  -0.4
    w_8_4     full_original_Gini_326  -1.3526190476190473e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_5     OBJ       -7.5000000000000067e-03
    x_8_5     product_lb_229  -0.0253136583258579
    x_8_5     product_ub_230  -4.2505819249106368e-02
    x_8_5     onehot_8_263  1
    x_8_5     stock_lb_266  5
    x_8_5     stock_ub_267  5
    x_8_5     parent_nonstrict_scope_268  0.075
    x_8_5     unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_5     product_lb_229  1
    w_8_5     product_ub_230  1
    w_8_5     normalized_mass_8_264  1
    w_8_5     normalized_ratio_8_265  -0.5
    w_8_5     full_original_Gini_326  -1.1426190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_6     OBJ       -2.2500000000000020e-02
    x_8_6     product_lb_231  -0.0253136583258579
    x_8_6     product_ub_232  -4.2505819249106368e-02
    x_8_6     onehot_8_263  1
    x_8_6     stock_lb_266  6
    x_8_6     stock_ub_267  6
    x_8_6     parent_nonstrict_scope_268  5.9999999999999984e-02
    x_8_6     unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_6     product_lb_231  1
    w_8_6     product_ub_232  1
    w_8_6     normalized_mass_8_264  1
    w_8_6     normalized_ratio_8_265  -6.0000000000000009e-01
    w_8_6     full_original_Gini_326  -9.3261904761904759e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_7     OBJ       -3.7500000000000012e-02
    x_8_7     product_lb_233  -0.0253136583258579
    x_8_7     product_ub_234  -4.2505819249106368e-02
    x_8_7     onehot_8_263  1
    x_8_7     stock_lb_266  7
    x_8_7     stock_ub_267  7
    x_8_7     parent_nonstrict_scope_268  4.4999999999999991e-02
    x_8_7     unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_7     product_lb_233  1
    w_8_7     product_ub_234  1
    w_8_7     normalized_mass_8_264  1
    w_8_7     normalized_ratio_8_265  -7.0000000000000007e-01
    w_8_7     full_original_Gini_326  -7.2261904761904727e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_8     OBJ       -5.2500000000000012e-02
    x_8_8     product_lb_235  -0.0253136583258579
    x_8_8     product_ub_236  -4.2505819249106368e-02
    x_8_8     onehot_8_263  1
    x_8_8     stock_lb_266  8
    x_8_8     stock_ub_267  8
    x_8_8     parent_nonstrict_scope_268  2.9999999999999992e-02
    x_8_8     unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_8     product_lb_235  1
    w_8_8     product_ub_236  1
    w_8_8     normalized_mass_8_264  1
    w_8_8     normalized_ratio_8_265  -0.8
    w_8_8     full_original_Gini_326  -5.4690476190476209e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_9     OBJ       -0.0675
    x_8_9     product_lb_237  -0.0253136583258579
    x_8_9     product_ub_238  -4.2505819249106368e-02
    x_8_9     onehot_8_263  1
    x_8_9     stock_lb_266  9
    x_8_9     stock_ub_267  9
    x_8_9     parent_nonstrict_scope_268  1.4999999999999996e-02
    x_8_9     unique_nonzero_owner_428  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_9     product_lb_237  1
    w_8_9     product_ub_238  1
    w_8_9     normalized_mass_8_264  1
    w_8_9     normalized_ratio_8_265  -0.9
    w_8_9     full_original_Gini_326  -4.3738095238095251e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_10    OBJ       -0.0825
    x_8_10    product_lb_239  -0.0253136583258579
    x_8_10    product_ub_240  -4.2505819249106368e-02
    x_8_10    onehot_8_263  1
    x_8_10    stock_lb_266  10
    x_8_10    stock_ub_267  10
    x_8_10    unique_nonzero_owner_429  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_10    product_lb_239  1
    w_8_10    product_ub_240  1
    w_8_10    normalized_mass_8_264  1
    w_8_10    normalized_ratio_8_265  -1
    w_8_10    full_original_Gini_326  -3.8738095238095243e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_11    OBJ       -6.7499999999999991e-02
    x_8_11    product_lb_241  -0.0253136583258579
    x_8_11    product_ub_242  -4.2505819249106368e-02
    x_8_11    onehot_8_263  1
    x_8_11    stock_lb_266  11
    x_8_11    stock_ub_267  11
    x_8_11    parent_nonstrict_scope_268  1.5000000000000013e-02
    x_8_11    unique_nonzero_owner_430  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_11    product_lb_241  1
    w_8_11    product_ub_242  1
    w_8_11    normalized_mass_8_264  1
    w_8_11    normalized_ratio_8_265  -1.1
    w_8_11    full_original_Gini_326  -6.3738095238095251e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_12    OBJ       -5.2499999999999977e-02
    x_8_12    product_lb_243  -0.0253136583258579
    x_8_12    product_ub_244  -4.2505819249106368e-02
    x_8_12    onehot_8_263  1
    x_8_12    stock_lb_266  12
    x_8_12    stock_ub_267  12
    x_8_12    parent_nonstrict_scope_268  3.0000000000000027e-02
    x_8_12    unique_nonzero_owner_431  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_12    product_lb_243  1
    w_8_12    product_ub_244  1
    w_8_12    normalized_mass_8_264  1
    w_8_12    normalized_ratio_8_265  -1.2000000000000002e+00
    w_8_12    full_original_Gini_326  -8.87380952380953
    MARKER    'MARKER'                 'INTORG'
    x_8_13    OBJ       -0.0375
    x_8_13    product_lb_245  -0.0253136583258579
    x_8_13    product_ub_246  -4.2505819249106368e-02
    x_8_13    onehot_8_263  1
    x_8_13    stock_lb_266  13
    x_8_13    stock_ub_267  13
    x_8_13    parent_nonstrict_scope_268  4.5000000000000005e-02
    x_8_13    unique_nonzero_owner_432  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_13    product_lb_245  1
    w_8_13    product_ub_246  1
    w_8_13    normalized_mass_8_264  1
    w_8_13    normalized_ratio_8_265  -1.3
    w_8_13    full_original_Gini_326  -1.1573809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_14    OBJ       -2.2499999999999985e-02
    x_8_14    product_lb_247  -0.0253136583258579
    x_8_14    product_ub_248  -4.2505819249106368e-02
    x_8_14    onehot_8_263  1
    x_8_14    stock_lb_266  14
    x_8_14    stock_ub_267  14
    x_8_14    parent_nonstrict_scope_268  6.0000000000000019e-02
    x_8_14    unique_nonzero_owner_433  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_14    product_lb_247  1
    w_8_14    product_ub_248  1
    w_8_14    normalized_mass_8_264  1
    w_8_14    normalized_ratio_8_265  -1.4000000000000001e+00
    w_8_14    full_original_Gini_326  -1.4273809523809529e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_15    OBJ       -7.5000000000000067e-03
    x_8_15    product_lb_249  -0.0253136583258579
    x_8_15    product_ub_250  -4.2505819249106368e-02
    x_8_15    onehot_8_263  1
    x_8_15    stock_lb_266  15
    x_8_15    stock_ub_267  15
    x_8_15    parent_nonstrict_scope_268  0.075
    MARKER    'MARKER'                 'INTEND'
    w_8_15    product_lb_249  1
    w_8_15    product_ub_250  1
    w_8_15    normalized_mass_8_264  1
    w_8_15    normalized_ratio_8_265  -1.5
    w_8_15    full_original_Gini_326  -1.6973809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_16    OBJ       7.5000000000000067e-03
    x_8_16    product_lb_251  -0.0253136583258579
    x_8_16    product_ub_252  -4.2505819249106368e-02
    x_8_16    onehot_8_263  1
    x_8_16    stock_lb_266  16
    x_8_16    stock_ub_267  16
    x_8_16    parent_nonstrict_scope_268  9.0000000000000011e-02
    x_8_16    unique_nonzero_owner_434  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_16    product_lb_251  1
    w_8_16    product_ub_252  1
    w_8_16    normalized_mass_8_264  1
    w_8_16    normalized_ratio_8_265  -1.6
    w_8_16    full_original_Gini_326  -1.9673809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_17    OBJ       2.2500000000000020e-02
    x_8_17    product_lb_253  -0.0253136583258579
    x_8_17    product_ub_254  -4.2505819249106368e-02
    x_8_17    onehot_8_263  1
    x_8_17    stock_lb_266  17
    x_8_17    stock_ub_267  17
    x_8_17    parent_nonstrict_scope_268  1.0500000000000002e-01
    x_8_17    unique_nonzero_owner_435  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_17    product_lb_253  1
    w_8_17    product_ub_254  1
    w_8_17    normalized_mass_8_264  1
    w_8_17    normalized_ratio_8_265  -1.7000000000000002e+00
    w_8_17    full_original_Gini_326  -2.2373809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_18    OBJ       3.7499999999999992e-02
    x_8_18    product_lb_255  -0.0253136583258579
    x_8_18    product_ub_256  -4.2505819249106368e-02
    x_8_18    onehot_8_263  1
    x_8_18    stock_lb_266  18
    x_8_18    stock_ub_267  18
    x_8_18    parent_nonstrict_scope_268  0.12
    x_8_18    unique_nonzero_owner_436  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_18    product_lb_255  1
    w_8_18    product_ub_256  1
    w_8_18    normalized_mass_8_264  1
    w_8_18    normalized_ratio_8_265  -1.8
    w_8_18    full_original_Gini_326  -2.5073809523809530e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_19    OBJ       5.2500000000000005e-02
    x_8_19    product_lb_257  -0.0253136583258579
    x_8_19    product_ub_258  -4.2505819249106368e-02
    x_8_19    onehot_8_263  1
    x_8_19    stock_lb_266  19
    x_8_19    stock_ub_267  19
    x_8_19    parent_nonstrict_scope_268  0.135
    x_8_19    unique_nonzero_owner_437  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_19    product_lb_257  1
    w_8_19    product_ub_258  1
    w_8_19    normalized_mass_8_264  1
    w_8_19    normalized_ratio_8_265  -1.9000000000000001e+00
    w_8_19    full_original_Gini_326  -2.7773809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_20    OBJ       6.7499999999999991e-02
    x_8_20    product_lb_259  -0.0253136583258579
    x_8_20    product_ub_260  -4.2505819249106368e-02
    x_8_20    onehot_8_263  1
    x_8_20    stock_lb_266  20
    x_8_20    stock_ub_267  20
    x_8_20    parent_nonstrict_scope_268  0.15
    x_8_20    unique_nonzero_owner_438  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_20    product_lb_259  1
    w_8_20    product_ub_260  1
    w_8_20    normalized_mass_8_264  1
    w_8_20    normalized_ratio_8_265  -2
    w_8_20    full_original_Gini_326  -3.0473809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_21    OBJ       0.0825
    x_8_21    product_lb_261  -0.0253136583258579
    x_8_21    product_ub_262  -4.2505819249106368e-02
    x_8_21    onehot_8_263  1
    x_8_21    stock_lb_266  21
    x_8_21    stock_ub_267  21
    x_8_21    parent_nonstrict_scope_268  0.165
    x_8_21    unique_nonzero_owner_439  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_21    product_lb_261  1
    w_8_21    product_ub_262  1
    w_8_21    normalized_mass_8_264  1
    w_8_21    normalized_ratio_8_265  -2.1
    w_8_21    full_original_Gini_326  -3.3173809523809538e+01
    rho_8     normalized_ratio_8_265  1
    rho_8     block_pair_pos_269  1
    rho_8     block_pair_neg_270  -1
    rho_8     block_pair_pos_275  1
    rho_8     block_pair_neg_276  -1
    rho_8     block_pair_pos_283  1
    rho_8     block_pair_neg_284  -1
    rho_8     block_pair_pos_293  1
    rho_8     block_pair_neg_294  -1
    rho_8     block_pair_pos_297  1
    rho_8     block_pair_neg_298  -1
    rho_8     block_pair_pos_311  1
    rho_8     block_pair_neg_312  -1
    rho_8     block_pair_pos_321  1
    rho_8     block_pair_neg_322  -1
    rho_8     normalization_325  1
    a_22_18   block_pair_pos_301  1
    a_22_18   block_pair_neg_302  1
    a_22_18   full_original_Gini_326  -1
    a_22_31   block_pair_pos_305  1
    a_22_31   block_pair_neg_306  1
    a_22_31   full_original_Gini_326  -1
    a_22_14   block_pair_pos_299  1
    a_22_14   block_pair_neg_300  1
    a_22_14   full_original_Gini_326  -1
    a_22_32   block_pair_pos_307  1
    a_22_32   block_pair_neg_308  1
    a_22_32   full_original_Gini_326  -1
    a_22_5    block_pair_pos_295  1
    a_22_5    block_pair_neg_296  1
    a_22_5    full_original_Gini_326  -1
    a_22_19   block_pair_pos_303  1
    a_22_19   block_pair_neg_304  1
    a_22_19   full_original_Gini_326  -1
    a_22_8    block_pair_pos_297  1
    a_22_8    block_pair_neg_298  1
    a_22_8    full_original_Gini_326  -1
    a_18_31   block_pair_pos_289  1
    a_18_31   block_pair_neg_290  1
    a_18_31   full_original_Gini_326  -1
    a_18_14   block_pair_pos_285  1
    a_18_14   block_pair_neg_286  1
    a_18_14   full_original_Gini_326  -1
    a_18_32   block_pair_pos_291  1
    a_18_32   block_pair_neg_292  1
    a_18_32   full_original_Gini_326  -1
    a_18_5    block_pair_pos_281  1
    a_18_5    block_pair_neg_282  1
    a_18_5    full_original_Gini_326  -1
    a_18_19   block_pair_pos_287  1
    a_18_19   block_pair_neg_288  1
    a_18_19   full_original_Gini_326  -1
    a_18_8    block_pair_pos_283  1
    a_18_8    block_pair_neg_284  1
    a_18_8    full_original_Gini_326  -1
    a_31_14   block_pair_pos_313  1
    a_31_14   block_pair_neg_314  1
    a_31_14   full_original_Gini_326  -1
    a_31_32   block_pair_pos_317  1
    a_31_32   block_pair_neg_318  1
    a_31_32   full_original_Gini_326  -1
    a_31_5    block_pair_pos_309  1
    a_31_5    block_pair_neg_310  1
    a_31_5    full_original_Gini_326  -1
    a_31_19   block_pair_pos_315  1
    a_31_19   block_pair_neg_316  1
    a_31_19   full_original_Gini_326  -1
    a_31_8    block_pair_pos_311  1
    a_31_8    block_pair_neg_312  1
    a_31_8    full_original_Gini_326  -1
    a_14_32   block_pair_pos_279  1
    a_14_32   block_pair_neg_280  1
    a_14_32   full_original_Gini_326  -1
    a_14_5    block_pair_pos_273  1
    a_14_5    block_pair_neg_274  1
    a_14_5    full_original_Gini_326  -1
    a_14_19   block_pair_pos_277  1
    a_14_19   block_pair_neg_278  1
    a_14_19   full_original_Gini_326  -1
    a_14_8    block_pair_pos_275  1
    a_14_8    block_pair_neg_276  1
    a_14_8    full_original_Gini_326  -1
    a_32_5    block_pair_pos_319  1
    a_32_5    block_pair_neg_320  1
    a_32_5    full_original_Gini_326  -1
    a_32_19   block_pair_pos_323  1
    a_32_19   block_pair_neg_324  1
    a_32_19   full_original_Gini_326  -1
    a_32_8    block_pair_pos_321  1
    a_32_8    block_pair_neg_322  1
    a_32_8    full_original_Gini_326  -1
    a_5_19    block_pair_pos_271  1
    a_5_19    block_pair_neg_272  1
    a_5_19    full_original_Gini_326  -1
    a_5_8     block_pair_pos_269  1
    a_5_8     block_pair_neg_270  1
    a_5_8     full_original_Gini_326  -1
    a_19_8    block_pair_pos_293  1
    a_19_8    block_pair_neg_294  1
    a_19_8    full_original_Gini_326  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_22_0  unique_nonzero_owner_327  1
    service_0_22_0  service_visit_def_820  1
    service_0_22_0  free_load_conservation_821  -8
    service_0_22_0  original_T_including_depot_unload_868  960
    service_0_22_1  unique_nonzero_owner_328  1
    service_0_22_1  service_visit_def_820  1
    service_0_22_1  free_load_conservation_821  -7
    service_0_22_1  original_T_including_depot_unload_868  840
    service_0_22_2  unique_nonzero_owner_329  1
    service_0_22_2  service_visit_def_820  1
    service_0_22_2  free_load_conservation_821  -6
    service_0_22_2  original_T_including_depot_unload_868  720
    service_0_22_3  unique_nonzero_owner_330  1
    service_0_22_3  service_visit_def_820  1
    service_0_22_3  free_load_conservation_821  -5
    service_0_22_3  original_T_including_depot_unload_868  600
    service_0_22_4  unique_nonzero_owner_331  1
    service_0_22_4  service_visit_def_820  1
    service_0_22_4  free_load_conservation_821  -4
    service_0_22_4  original_T_including_depot_unload_868  480
    service_0_22_5  unique_nonzero_owner_332  1
    service_0_22_5  service_visit_def_820  1
    service_0_22_5  free_load_conservation_821  -3
    service_0_22_5  original_T_including_depot_unload_868  360
    service_0_22_6  unique_nonzero_owner_333  1
    service_0_22_6  service_visit_def_820  1
    service_0_22_6  free_load_conservation_821  -2
    service_0_22_6  original_T_including_depot_unload_868  240
    service_0_22_7  unique_nonzero_owner_334  1
    service_0_22_7  service_visit_def_820  1
    service_0_22_7  free_load_conservation_821  -1
    service_0_22_7  original_T_including_depot_unload_868  120
    service_0_22_9  unique_nonzero_owner_335  1
    service_0_22_9  service_visit_def_820  1
    service_0_22_9  free_load_conservation_821  1
    service_0_22_10  unique_nonzero_owner_336  1
    service_0_22_10  service_visit_def_820  1
    service_0_22_10  free_load_conservation_821  2
    service_0_22_11  unique_nonzero_owner_337  1
    service_0_22_11  service_visit_def_820  1
    service_0_22_11  free_load_conservation_821  3
    service_0_22_12  unique_nonzero_owner_338  1
    service_0_22_12  service_visit_def_820  1
    service_0_22_12  free_load_conservation_821  4
    service_1_22_0  unique_nonzero_owner_327  1
    service_1_22_0  service_visit_def_1192  1
    service_1_22_0  free_load_conservation_1193  -8
    service_1_22_0  original_T_including_depot_unload_1239  960
    service_1_22_1  unique_nonzero_owner_328  1
    service_1_22_1  service_visit_def_1192  1
    service_1_22_1  free_load_conservation_1193  -7
    service_1_22_1  original_T_including_depot_unload_1239  840
    service_1_22_2  unique_nonzero_owner_329  1
    service_1_22_2  service_visit_def_1192  1
    service_1_22_2  free_load_conservation_1193  -6
    service_1_22_2  original_T_including_depot_unload_1239  720
    service_1_22_3  unique_nonzero_owner_330  1
    service_1_22_3  service_visit_def_1192  1
    service_1_22_3  free_load_conservation_1193  -5
    service_1_22_3  original_T_including_depot_unload_1239  600
    service_1_22_4  unique_nonzero_owner_331  1
    service_1_22_4  service_visit_def_1192  1
    service_1_22_4  free_load_conservation_1193  -4
    service_1_22_4  original_T_including_depot_unload_1239  480
    service_1_22_5  unique_nonzero_owner_332  1
    service_1_22_5  service_visit_def_1192  1
    service_1_22_5  free_load_conservation_1193  -3
    service_1_22_5  original_T_including_depot_unload_1239  360
    service_1_22_6  unique_nonzero_owner_333  1
    service_1_22_6  service_visit_def_1192  1
    service_1_22_6  free_load_conservation_1193  -2
    service_1_22_6  original_T_including_depot_unload_1239  240
    service_1_22_7  unique_nonzero_owner_334  1
    service_1_22_7  service_visit_def_1192  1
    service_1_22_7  free_load_conservation_1193  -1
    service_1_22_7  original_T_including_depot_unload_1239  120
    service_1_22_9  unique_nonzero_owner_335  1
    service_1_22_9  service_visit_def_1192  1
    service_1_22_9  free_load_conservation_1193  1
    service_1_22_10  unique_nonzero_owner_336  1
    service_1_22_10  service_visit_def_1192  1
    service_1_22_10  free_load_conservation_1193  2
    service_1_22_11  unique_nonzero_owner_337  1
    service_1_22_11  service_visit_def_1192  1
    service_1_22_11  free_load_conservation_1193  3
    service_1_22_12  unique_nonzero_owner_338  1
    service_1_22_12  service_visit_def_1192  1
    service_1_22_12  free_load_conservation_1193  4
    service_2_22_0  unique_nonzero_owner_327  1
    service_2_22_0  service_visit_def_1563  1
    service_2_22_0  free_load_conservation_1564  -8
    service_2_22_0  original_T_including_depot_unload_1610  960
    service_2_22_1  unique_nonzero_owner_328  1
    service_2_22_1  service_visit_def_1563  1
    service_2_22_1  free_load_conservation_1564  -7
    service_2_22_1  original_T_including_depot_unload_1610  840
    service_2_22_2  unique_nonzero_owner_329  1
    service_2_22_2  service_visit_def_1563  1
    service_2_22_2  free_load_conservation_1564  -6
    service_2_22_2  original_T_including_depot_unload_1610  720
    service_2_22_3  unique_nonzero_owner_330  1
    service_2_22_3  service_visit_def_1563  1
    service_2_22_3  free_load_conservation_1564  -5
    service_2_22_3  original_T_including_depot_unload_1610  600
    service_2_22_4  unique_nonzero_owner_331  1
    service_2_22_4  service_visit_def_1563  1
    service_2_22_4  free_load_conservation_1564  -4
    service_2_22_4  original_T_including_depot_unload_1610  480
    service_2_22_5  unique_nonzero_owner_332  1
    service_2_22_5  service_visit_def_1563  1
    service_2_22_5  free_load_conservation_1564  -3
    service_2_22_5  original_T_including_depot_unload_1610  360
    service_2_22_6  unique_nonzero_owner_333  1
    service_2_22_6  service_visit_def_1563  1
    service_2_22_6  free_load_conservation_1564  -2
    service_2_22_6  original_T_including_depot_unload_1610  240
    service_2_22_7  unique_nonzero_owner_334  1
    service_2_22_7  service_visit_def_1563  1
    service_2_22_7  free_load_conservation_1564  -1
    service_2_22_7  original_T_including_depot_unload_1610  120
    service_2_22_9  unique_nonzero_owner_335  1
    service_2_22_9  service_visit_def_1563  1
    service_2_22_9  free_load_conservation_1564  1
    service_2_22_10  unique_nonzero_owner_336  1
    service_2_22_10  service_visit_def_1563  1
    service_2_22_10  free_load_conservation_1564  2
    service_2_22_11  unique_nonzero_owner_337  1
    service_2_22_11  service_visit_def_1563  1
    service_2_22_11  free_load_conservation_1564  3
    service_2_22_12  unique_nonzero_owner_338  1
    service_2_22_12  service_visit_def_1563  1
    service_2_22_12  free_load_conservation_1564  4
    service_0_18_0  unique_nonzero_owner_339  1
    service_0_18_0  service_visit_def_826  1
    service_0_18_0  free_load_conservation_827  -12
    service_0_18_0  original_T_including_depot_unload_868  1440
    service_0_18_1  unique_nonzero_owner_340  1
    service_0_18_1  service_visit_def_826  1
    service_0_18_1  free_load_conservation_827  -11
    service_0_18_1  original_T_including_depot_unload_868  1320
    service_0_18_2  unique_nonzero_owner_341  1
    service_0_18_2  service_visit_def_826  1
    service_0_18_2  free_load_conservation_827  -10
    service_0_18_2  original_T_including_depot_unload_868  1200
    service_0_18_3  unique_nonzero_owner_342  1
    service_0_18_3  service_visit_def_826  1
    service_0_18_3  free_load_conservation_827  -9
    service_0_18_3  original_T_including_depot_unload_868  1080
    service_0_18_4  unique_nonzero_owner_343  1
    service_0_18_4  service_visit_def_826  1
    service_0_18_4  free_load_conservation_827  -8
    service_0_18_4  original_T_including_depot_unload_868  960
    service_0_18_5  unique_nonzero_owner_344  1
    service_0_18_5  service_visit_def_826  1
    service_0_18_5  free_load_conservation_827  -7
    service_0_18_5  original_T_including_depot_unload_868  840
    service_0_18_6  unique_nonzero_owner_345  1
    service_0_18_6  service_visit_def_826  1
    service_0_18_6  free_load_conservation_827  -6
    service_0_18_6  original_T_including_depot_unload_868  720
    service_0_18_7  unique_nonzero_owner_346  1
    service_0_18_7  service_visit_def_826  1
    service_0_18_7  free_load_conservation_827  -5
    service_0_18_7  original_T_including_depot_unload_868  600
    service_0_18_8  unique_nonzero_owner_347  1
    service_0_18_8  service_visit_def_826  1
    service_0_18_8  free_load_conservation_827  -4
    service_0_18_8  original_T_including_depot_unload_868  480
    service_0_18_9  unique_nonzero_owner_348  1
    service_0_18_9  service_visit_def_826  1
    service_0_18_9  free_load_conservation_827  -3
    service_0_18_9  original_T_including_depot_unload_868  360
    service_0_18_10  unique_nonzero_owner_349  1
    service_0_18_10  service_visit_def_826  1
    service_0_18_10  free_load_conservation_827  -2
    service_0_18_10  original_T_including_depot_unload_868  240
    service_0_18_11  unique_nonzero_owner_350  1
    service_0_18_11  service_visit_def_826  1
    service_0_18_11  free_load_conservation_827  -1
    service_0_18_11  original_T_including_depot_unload_868  120
    service_0_18_13  unique_nonzero_owner_351  1
    service_0_18_13  service_visit_def_826  1
    service_0_18_13  free_load_conservation_827  1
    service_0_18_14  unique_nonzero_owner_352  1
    service_0_18_14  service_visit_def_826  1
    service_0_18_14  free_load_conservation_827  2
    service_0_18_15  unique_nonzero_owner_353  1
    service_0_18_15  service_visit_def_826  1
    service_0_18_15  free_load_conservation_827  3
    service_0_18_16  unique_nonzero_owner_354  1
    service_0_18_16  service_visit_def_826  1
    service_0_18_16  free_load_conservation_827  4
    service_0_18_17  unique_nonzero_owner_355  1
    service_0_18_17  service_visit_def_826  1
    service_0_18_17  free_load_conservation_827  5
    service_1_18_0  unique_nonzero_owner_339  1
    service_1_18_0  service_visit_def_1198  1
    service_1_18_0  free_load_conservation_1199  -12
    service_1_18_0  original_T_including_depot_unload_1239  1440
    service_1_18_1  unique_nonzero_owner_340  1
    service_1_18_1  service_visit_def_1198  1
    service_1_18_1  free_load_conservation_1199  -11
    service_1_18_1  original_T_including_depot_unload_1239  1320
    service_1_18_2  unique_nonzero_owner_341  1
    service_1_18_2  service_visit_def_1198  1
    service_1_18_2  free_load_conservation_1199  -10
    service_1_18_2  original_T_including_depot_unload_1239  1200
    service_1_18_3  unique_nonzero_owner_342  1
    service_1_18_3  service_visit_def_1198  1
    service_1_18_3  free_load_conservation_1199  -9
    service_1_18_3  original_T_including_depot_unload_1239  1080
    service_1_18_4  unique_nonzero_owner_343  1
    service_1_18_4  service_visit_def_1198  1
    service_1_18_4  free_load_conservation_1199  -8
    service_1_18_4  original_T_including_depot_unload_1239  960
    service_1_18_5  unique_nonzero_owner_344  1
    service_1_18_5  service_visit_def_1198  1
    service_1_18_5  free_load_conservation_1199  -7
    service_1_18_5  original_T_including_depot_unload_1239  840
    service_1_18_6  unique_nonzero_owner_345  1
    service_1_18_6  service_visit_def_1198  1
    service_1_18_6  free_load_conservation_1199  -6
    service_1_18_6  original_T_including_depot_unload_1239  720
    service_1_18_7  unique_nonzero_owner_346  1
    service_1_18_7  service_visit_def_1198  1
    service_1_18_7  free_load_conservation_1199  -5
    service_1_18_7  original_T_including_depot_unload_1239  600
    service_1_18_8  unique_nonzero_owner_347  1
    service_1_18_8  service_visit_def_1198  1
    service_1_18_8  free_load_conservation_1199  -4
    service_1_18_8  original_T_including_depot_unload_1239  480
    service_1_18_9  unique_nonzero_owner_348  1
    service_1_18_9  service_visit_def_1198  1
    service_1_18_9  free_load_conservation_1199  -3
    service_1_18_9  original_T_including_depot_unload_1239  360
    service_1_18_10  unique_nonzero_owner_349  1
    service_1_18_10  service_visit_def_1198  1
    service_1_18_10  free_load_conservation_1199  -2
    service_1_18_10  original_T_including_depot_unload_1239  240
    service_1_18_11  unique_nonzero_owner_350  1
    service_1_18_11  service_visit_def_1198  1
    service_1_18_11  free_load_conservation_1199  -1
    service_1_18_11  original_T_including_depot_unload_1239  120
    service_1_18_13  unique_nonzero_owner_351  1
    service_1_18_13  service_visit_def_1198  1
    service_1_18_13  free_load_conservation_1199  1
    service_1_18_14  unique_nonzero_owner_352  1
    service_1_18_14  service_visit_def_1198  1
    service_1_18_14  free_load_conservation_1199  2
    service_1_18_15  unique_nonzero_owner_353  1
    service_1_18_15  service_visit_def_1198  1
    service_1_18_15  free_load_conservation_1199  3
    service_1_18_16  unique_nonzero_owner_354  1
    service_1_18_16  service_visit_def_1198  1
    service_1_18_16  free_load_conservation_1199  4
    service_1_18_17  unique_nonzero_owner_355  1
    service_1_18_17  service_visit_def_1198  1
    service_1_18_17  free_load_conservation_1199  5
    service_2_18_0  unique_nonzero_owner_339  1
    service_2_18_0  service_visit_def_1569  1
    service_2_18_0  free_load_conservation_1570  -12
    service_2_18_0  original_T_including_depot_unload_1610  1440
    service_2_18_1  unique_nonzero_owner_340  1
    service_2_18_1  service_visit_def_1569  1
    service_2_18_1  free_load_conservation_1570  -11
    service_2_18_1  original_T_including_depot_unload_1610  1320
    service_2_18_2  unique_nonzero_owner_341  1
    service_2_18_2  service_visit_def_1569  1
    service_2_18_2  free_load_conservation_1570  -10
    service_2_18_2  original_T_including_depot_unload_1610  1200
    service_2_18_3  unique_nonzero_owner_342  1
    service_2_18_3  service_visit_def_1569  1
    service_2_18_3  free_load_conservation_1570  -9
    service_2_18_3  original_T_including_depot_unload_1610  1080
    service_2_18_4  unique_nonzero_owner_343  1
    service_2_18_4  service_visit_def_1569  1
    service_2_18_4  free_load_conservation_1570  -8
    service_2_18_4  original_T_including_depot_unload_1610  960
    service_2_18_5  unique_nonzero_owner_344  1
    service_2_18_5  service_visit_def_1569  1
    service_2_18_5  free_load_conservation_1570  -7
    service_2_18_5  original_T_including_depot_unload_1610  840
    service_2_18_6  unique_nonzero_owner_345  1
    service_2_18_6  service_visit_def_1569  1
    service_2_18_6  free_load_conservation_1570  -6
    service_2_18_6  original_T_including_depot_unload_1610  720
    service_2_18_7  unique_nonzero_owner_346  1
    service_2_18_7  service_visit_def_1569  1
    service_2_18_7  free_load_conservation_1570  -5
    service_2_18_7  original_T_including_depot_unload_1610  600
    service_2_18_8  unique_nonzero_owner_347  1
    service_2_18_8  service_visit_def_1569  1
    service_2_18_8  free_load_conservation_1570  -4
    service_2_18_8  original_T_including_depot_unload_1610  480
    service_2_18_9  unique_nonzero_owner_348  1
    service_2_18_9  service_visit_def_1569  1
    service_2_18_9  free_load_conservation_1570  -3
    service_2_18_9  original_T_including_depot_unload_1610  360
    service_2_18_10  unique_nonzero_owner_349  1
    service_2_18_10  service_visit_def_1569  1
    service_2_18_10  free_load_conservation_1570  -2
    service_2_18_10  original_T_including_depot_unload_1610  240
    service_2_18_11  unique_nonzero_owner_350  1
    service_2_18_11  service_visit_def_1569  1
    service_2_18_11  free_load_conservation_1570  -1
    service_2_18_11  original_T_including_depot_unload_1610  120
    service_2_18_13  unique_nonzero_owner_351  1
    service_2_18_13  service_visit_def_1569  1
    service_2_18_13  free_load_conservation_1570  1
    service_2_18_14  unique_nonzero_owner_352  1
    service_2_18_14  service_visit_def_1569  1
    service_2_18_14  free_load_conservation_1570  2
    service_2_18_15  unique_nonzero_owner_353  1
    service_2_18_15  service_visit_def_1569  1
    service_2_18_15  free_load_conservation_1570  3
    service_2_18_16  unique_nonzero_owner_354  1
    service_2_18_16  service_visit_def_1569  1
    service_2_18_16  free_load_conservation_1570  4
    service_2_18_17  unique_nonzero_owner_355  1
    service_2_18_17  service_visit_def_1569  1
    service_2_18_17  free_load_conservation_1570  5
    service_0_31_0  unique_nonzero_owner_356  1
    service_0_31_0  service_visit_def_832  1
    service_0_31_0  free_load_conservation_833  -2
    service_0_31_0  original_T_including_depot_unload_868  240
    service_0_31_1  unique_nonzero_owner_357  1
    service_0_31_1  service_visit_def_832  1
    service_0_31_1  free_load_conservation_833  -1
    service_0_31_1  original_T_including_depot_unload_868  120
    service_0_31_3  unique_nonzero_owner_358  1
    service_0_31_3  service_visit_def_832  1
    service_0_31_3  free_load_conservation_833  1
    service_0_31_4  unique_nonzero_owner_359  1
    service_0_31_4  service_visit_def_832  1
    service_0_31_4  free_load_conservation_833  2
    service_0_31_5  unique_nonzero_owner_360  1
    service_0_31_5  service_visit_def_832  1
    service_0_31_5  free_load_conservation_833  3
    service_0_31_6  unique_nonzero_owner_361  1
    service_0_31_6  service_visit_def_832  1
    service_0_31_6  free_load_conservation_833  4
    service_0_31_7  unique_nonzero_owner_362  1
    service_0_31_7  service_visit_def_832  1
    service_0_31_7  free_load_conservation_833  5
    service_0_31_8  unique_nonzero_owner_363  1
    service_0_31_8  service_visit_def_832  1
    service_0_31_8  free_load_conservation_833  6
    service_0_31_9  unique_nonzero_owner_364  1
    service_0_31_9  service_visit_def_832  1
    service_0_31_9  free_load_conservation_833  7
    service_0_31_10  unique_nonzero_owner_365  1
    service_0_31_10  service_visit_def_832  1
    service_0_31_10  free_load_conservation_833  8
    service_0_31_11  unique_nonzero_owner_366  1
    service_0_31_11  service_visit_def_832  1
    service_0_31_11  free_load_conservation_833  9
    service_0_31_12  unique_nonzero_owner_367  1
    service_0_31_12  service_visit_def_832  1
    service_0_31_12  free_load_conservation_833  10
    service_1_31_0  unique_nonzero_owner_356  1
    service_1_31_0  service_visit_def_1204  1
    service_1_31_0  free_load_conservation_1205  -2
    service_1_31_0  original_T_including_depot_unload_1239  240
    service_1_31_1  unique_nonzero_owner_357  1
    service_1_31_1  service_visit_def_1204  1
    service_1_31_1  free_load_conservation_1205  -1
    service_1_31_1  original_T_including_depot_unload_1239  120
    service_1_31_3  unique_nonzero_owner_358  1
    service_1_31_3  service_visit_def_1204  1
    service_1_31_3  free_load_conservation_1205  1
    service_1_31_4  unique_nonzero_owner_359  1
    service_1_31_4  service_visit_def_1204  1
    service_1_31_4  free_load_conservation_1205  2
    service_1_31_5  unique_nonzero_owner_360  1
    service_1_31_5  service_visit_def_1204  1
    service_1_31_5  free_load_conservation_1205  3
    service_1_31_6  unique_nonzero_owner_361  1
    service_1_31_6  service_visit_def_1204  1
    service_1_31_6  free_load_conservation_1205  4
    service_1_31_7  unique_nonzero_owner_362  1
    service_1_31_7  service_visit_def_1204  1
    service_1_31_7  free_load_conservation_1205  5
    service_1_31_8  unique_nonzero_owner_363  1
    service_1_31_8  service_visit_def_1204  1
    service_1_31_8  free_load_conservation_1205  6
    service_1_31_9  unique_nonzero_owner_364  1
    service_1_31_9  service_visit_def_1204  1
    service_1_31_9  free_load_conservation_1205  7
    service_1_31_10  unique_nonzero_owner_365  1
    service_1_31_10  service_visit_def_1204  1
    service_1_31_10  free_load_conservation_1205  8
    service_1_31_11  unique_nonzero_owner_366  1
    service_1_31_11  service_visit_def_1204  1
    service_1_31_11  free_load_conservation_1205  9
    service_1_31_12  unique_nonzero_owner_367  1
    service_1_31_12  service_visit_def_1204  1
    service_1_31_12  free_load_conservation_1205  10
    service_2_31_0  unique_nonzero_owner_356  1
    service_2_31_0  service_visit_def_1575  1
    service_2_31_0  free_load_conservation_1576  -2
    service_2_31_0  original_T_including_depot_unload_1610  240
    service_2_31_1  unique_nonzero_owner_357  1
    service_2_31_1  service_visit_def_1575  1
    service_2_31_1  free_load_conservation_1576  -1
    service_2_31_1  original_T_including_depot_unload_1610  120
    service_2_31_3  unique_nonzero_owner_358  1
    service_2_31_3  service_visit_def_1575  1
    service_2_31_3  free_load_conservation_1576  1
    service_2_31_4  unique_nonzero_owner_359  1
    service_2_31_4  service_visit_def_1575  1
    service_2_31_4  free_load_conservation_1576  2
    service_2_31_5  unique_nonzero_owner_360  1
    service_2_31_5  service_visit_def_1575  1
    service_2_31_5  free_load_conservation_1576  3
    service_2_31_6  unique_nonzero_owner_361  1
    service_2_31_6  service_visit_def_1575  1
    service_2_31_6  free_load_conservation_1576  4
    service_2_31_7  unique_nonzero_owner_362  1
    service_2_31_7  service_visit_def_1575  1
    service_2_31_7  free_load_conservation_1576  5
    service_2_31_8  unique_nonzero_owner_363  1
    service_2_31_8  service_visit_def_1575  1
    service_2_31_8  free_load_conservation_1576  6
    service_2_31_9  unique_nonzero_owner_364  1
    service_2_31_9  service_visit_def_1575  1
    service_2_31_9  free_load_conservation_1576  7
    service_2_31_10  unique_nonzero_owner_365  1
    service_2_31_10  service_visit_def_1575  1
    service_2_31_10  free_load_conservation_1576  8
    service_2_31_11  unique_nonzero_owner_366  1
    service_2_31_11  service_visit_def_1575  1
    service_2_31_11  free_load_conservation_1576  9
    service_2_31_12  unique_nonzero_owner_367  1
    service_2_31_12  service_visit_def_1575  1
    service_2_31_12  free_load_conservation_1576  10
    service_0_14_0  unique_nonzero_owner_368  1
    service_0_14_0  service_visit_def_838  1
    service_0_14_0  free_load_conservation_839  -2
    service_0_14_0  original_T_including_depot_unload_868  240
    service_0_14_1  unique_nonzero_owner_369  1
    service_0_14_1  service_visit_def_838  1
    service_0_14_1  free_load_conservation_839  -1
    service_0_14_1  original_T_including_depot_unload_868  120
    service_0_14_3  unique_nonzero_owner_370  1
    service_0_14_3  service_visit_def_838  1
    service_0_14_3  free_load_conservation_839  1
    service_0_14_4  unique_nonzero_owner_371  1
    service_0_14_4  service_visit_def_838  1
    service_0_14_4  free_load_conservation_839  2
    service_0_14_5  unique_nonzero_owner_372  1
    service_0_14_5  service_visit_def_838  1
    service_0_14_5  free_load_conservation_839  3
    service_0_14_6  unique_nonzero_owner_373  1
    service_0_14_6  service_visit_def_838  1
    service_0_14_6  free_load_conservation_839  4
    service_0_14_7  unique_nonzero_owner_374  1
    service_0_14_7  service_visit_def_838  1
    service_0_14_7  free_load_conservation_839  5
    service_0_14_8  unique_nonzero_owner_375  1
    service_0_14_8  service_visit_def_838  1
    service_0_14_8  free_load_conservation_839  6
    service_0_14_9  unique_nonzero_owner_376  1
    service_0_14_9  service_visit_def_838  1
    service_0_14_9  free_load_conservation_839  7
    service_0_14_10  unique_nonzero_owner_377  1
    service_0_14_10  service_visit_def_838  1
    service_0_14_10  free_load_conservation_839  8
    service_0_14_11  unique_nonzero_owner_378  1
    service_0_14_11  service_visit_def_838  1
    service_0_14_11  free_load_conservation_839  9
    service_0_14_12  unique_nonzero_owner_379  1
    service_0_14_12  service_visit_def_838  1
    service_0_14_12  free_load_conservation_839  10
    service_0_14_13  unique_nonzero_owner_380  1
    service_0_14_13  service_visit_def_838  1
    service_0_14_13  free_load_conservation_839  11
    service_0_14_14  unique_nonzero_owner_381  1
    service_0_14_14  service_visit_def_838  1
    service_0_14_14  free_load_conservation_839  12
    service_0_14_15  unique_nonzero_owner_382  1
    service_0_14_15  service_visit_def_838  1
    service_0_14_15  free_load_conservation_839  13
    service_1_14_0  unique_nonzero_owner_368  1
    service_1_14_0  service_visit_def_1210  1
    service_1_14_0  free_load_conservation_1211  -2
    service_1_14_0  original_T_including_depot_unload_1239  240
    service_1_14_1  unique_nonzero_owner_369  1
    service_1_14_1  service_visit_def_1210  1
    service_1_14_1  free_load_conservation_1211  -1
    service_1_14_1  original_T_including_depot_unload_1239  120
    service_1_14_3  unique_nonzero_owner_370  1
    service_1_14_3  service_visit_def_1210  1
    service_1_14_3  free_load_conservation_1211  1
    service_1_14_4  unique_nonzero_owner_371  1
    service_1_14_4  service_visit_def_1210  1
    service_1_14_4  free_load_conservation_1211  2
    service_1_14_5  unique_nonzero_owner_372  1
    service_1_14_5  service_visit_def_1210  1
    service_1_14_5  free_load_conservation_1211  3
    service_1_14_6  unique_nonzero_owner_373  1
    service_1_14_6  service_visit_def_1210  1
    service_1_14_6  free_load_conservation_1211  4
    service_1_14_7  unique_nonzero_owner_374  1
    service_1_14_7  service_visit_def_1210  1
    service_1_14_7  free_load_conservation_1211  5
    service_1_14_8  unique_nonzero_owner_375  1
    service_1_14_8  service_visit_def_1210  1
    service_1_14_8  free_load_conservation_1211  6
    service_1_14_9  unique_nonzero_owner_376  1
    service_1_14_9  service_visit_def_1210  1
    service_1_14_9  free_load_conservation_1211  7
    service_1_14_10  unique_nonzero_owner_377  1
    service_1_14_10  service_visit_def_1210  1
    service_1_14_10  free_load_conservation_1211  8
    service_1_14_11  unique_nonzero_owner_378  1
    service_1_14_11  service_visit_def_1210  1
    service_1_14_11  free_load_conservation_1211  9
    service_1_14_12  unique_nonzero_owner_379  1
    service_1_14_12  service_visit_def_1210  1
    service_1_14_12  free_load_conservation_1211  10
    service_1_14_13  unique_nonzero_owner_380  1
    service_1_14_13  service_visit_def_1210  1
    service_1_14_13  free_load_conservation_1211  11
    service_1_14_14  unique_nonzero_owner_381  1
    service_1_14_14  service_visit_def_1210  1
    service_1_14_14  free_load_conservation_1211  12
    service_1_14_15  unique_nonzero_owner_382  1
    service_1_14_15  service_visit_def_1210  1
    service_1_14_15  free_load_conservation_1211  13
    service_2_14_0  unique_nonzero_owner_368  1
    service_2_14_0  service_visit_def_1581  1
    service_2_14_0  free_load_conservation_1582  -2
    service_2_14_0  original_T_including_depot_unload_1610  240
    service_2_14_1  unique_nonzero_owner_369  1
    service_2_14_1  service_visit_def_1581  1
    service_2_14_1  free_load_conservation_1582  -1
    service_2_14_1  original_T_including_depot_unload_1610  120
    service_2_14_3  unique_nonzero_owner_370  1
    service_2_14_3  service_visit_def_1581  1
    service_2_14_3  free_load_conservation_1582  1
    service_2_14_4  unique_nonzero_owner_371  1
    service_2_14_4  service_visit_def_1581  1
    service_2_14_4  free_load_conservation_1582  2
    service_2_14_5  unique_nonzero_owner_372  1
    service_2_14_5  service_visit_def_1581  1
    service_2_14_5  free_load_conservation_1582  3
    service_2_14_6  unique_nonzero_owner_373  1
    service_2_14_6  service_visit_def_1581  1
    service_2_14_6  free_load_conservation_1582  4
    service_2_14_7  unique_nonzero_owner_374  1
    service_2_14_7  service_visit_def_1581  1
    service_2_14_7  free_load_conservation_1582  5
    service_2_14_8  unique_nonzero_owner_375  1
    service_2_14_8  service_visit_def_1581  1
    service_2_14_8  free_load_conservation_1582  6
    service_2_14_9  unique_nonzero_owner_376  1
    service_2_14_9  service_visit_def_1581  1
    service_2_14_9  free_load_conservation_1582  7
    service_2_14_10  unique_nonzero_owner_377  1
    service_2_14_10  service_visit_def_1581  1
    service_2_14_10  free_load_conservation_1582  8
    service_2_14_11  unique_nonzero_owner_378  1
    service_2_14_11  service_visit_def_1581  1
    service_2_14_11  free_load_conservation_1582  9
    service_2_14_12  unique_nonzero_owner_379  1
    service_2_14_12  service_visit_def_1581  1
    service_2_14_12  free_load_conservation_1582  10
    service_2_14_13  unique_nonzero_owner_380  1
    service_2_14_13  service_visit_def_1581  1
    service_2_14_13  free_load_conservation_1582  11
    service_2_14_14  unique_nonzero_owner_381  1
    service_2_14_14  service_visit_def_1581  1
    service_2_14_14  free_load_conservation_1582  12
    service_2_14_15  unique_nonzero_owner_382  1
    service_2_14_15  service_visit_def_1581  1
    service_2_14_15  free_load_conservation_1582  13
    service_0_32_1  unique_nonzero_owner_383  1
    service_0_32_1  service_visit_def_844  1
    service_0_32_1  free_load_conservation_845  1
    service_0_32_2  unique_nonzero_owner_384  1
    service_0_32_2  service_visit_def_844  1
    service_0_32_2  free_load_conservation_845  2
    service_0_32_3  unique_nonzero_owner_385  1
    service_0_32_3  service_visit_def_844  1
    service_0_32_3  free_load_conservation_845  3
    service_0_32_4  unique_nonzero_owner_386  1
    service_0_32_4  service_visit_def_844  1
    service_0_32_4  free_load_conservation_845  4
    service_0_32_5  unique_nonzero_owner_387  1
    service_0_32_5  service_visit_def_844  1
    service_0_32_5  free_load_conservation_845  5
    service_0_32_6  unique_nonzero_owner_388  1
    service_0_32_6  service_visit_def_844  1
    service_0_32_6  free_load_conservation_845  6
    service_0_32_7  unique_nonzero_owner_389  1
    service_0_32_7  service_visit_def_844  1
    service_0_32_7  free_load_conservation_845  7
    service_0_32_8  unique_nonzero_owner_390  1
    service_0_32_8  service_visit_def_844  1
    service_0_32_8  free_load_conservation_845  8
    service_0_32_9  unique_nonzero_owner_391  1
    service_0_32_9  service_visit_def_844  1
    service_0_32_9  free_load_conservation_845  9
    service_0_32_10  unique_nonzero_owner_392  1
    service_0_32_10  service_visit_def_844  1
    service_0_32_10  free_load_conservation_845  10
    service_0_32_11  unique_nonzero_owner_393  1
    service_0_32_11  service_visit_def_844  1
    service_0_32_11  free_load_conservation_845  11
    service_0_32_12  unique_nonzero_owner_394  1
    service_0_32_12  service_visit_def_844  1
    service_0_32_12  free_load_conservation_845  12
    service_1_32_1  unique_nonzero_owner_383  1
    service_1_32_1  service_visit_def_1216  1
    service_1_32_1  free_load_conservation_1217  1
    service_1_32_2  unique_nonzero_owner_384  1
    service_1_32_2  service_visit_def_1216  1
    service_1_32_2  free_load_conservation_1217  2
    service_1_32_3  unique_nonzero_owner_385  1
    service_1_32_3  service_visit_def_1216  1
    service_1_32_3  free_load_conservation_1217  3
    service_1_32_4  unique_nonzero_owner_386  1
    service_1_32_4  service_visit_def_1216  1
    service_1_32_4  free_load_conservation_1217  4
    service_1_32_5  unique_nonzero_owner_387  1
    service_1_32_5  service_visit_def_1216  1
    service_1_32_5  free_load_conservation_1217  5
    service_1_32_6  unique_nonzero_owner_388  1
    service_1_32_6  service_visit_def_1216  1
    service_1_32_6  free_load_conservation_1217  6
    service_1_32_7  unique_nonzero_owner_389  1
    service_1_32_7  service_visit_def_1216  1
    service_1_32_7  free_load_conservation_1217  7
    service_1_32_8  unique_nonzero_owner_390  1
    service_1_32_8  service_visit_def_1216  1
    service_1_32_8  free_load_conservation_1217  8
    service_1_32_9  unique_nonzero_owner_391  1
    service_1_32_9  service_visit_def_1216  1
    service_1_32_9  free_load_conservation_1217  9
    service_1_32_10  unique_nonzero_owner_392  1
    service_1_32_10  service_visit_def_1216  1
    service_1_32_10  free_load_conservation_1217  10
    service_1_32_11  unique_nonzero_owner_393  1
    service_1_32_11  service_visit_def_1216  1
    service_1_32_11  free_load_conservation_1217  11
    service_1_32_12  unique_nonzero_owner_394  1
    service_1_32_12  service_visit_def_1216  1
    service_1_32_12  free_load_conservation_1217  12
    service_2_32_1  unique_nonzero_owner_383  1
    service_2_32_1  service_visit_def_1587  1
    service_2_32_1  free_load_conservation_1588  1
    service_2_32_2  unique_nonzero_owner_384  1
    service_2_32_2  service_visit_def_1587  1
    service_2_32_2  free_load_conservation_1588  2
    service_2_32_3  unique_nonzero_owner_385  1
    service_2_32_3  service_visit_def_1587  1
    service_2_32_3  free_load_conservation_1588  3
    service_2_32_4  unique_nonzero_owner_386  1
    service_2_32_4  service_visit_def_1587  1
    service_2_32_4  free_load_conservation_1588  4
    service_2_32_5  unique_nonzero_owner_387  1
    service_2_32_5  service_visit_def_1587  1
    service_2_32_5  free_load_conservation_1588  5
    service_2_32_6  unique_nonzero_owner_388  1
    service_2_32_6  service_visit_def_1587  1
    service_2_32_6  free_load_conservation_1588  6
    service_2_32_7  unique_nonzero_owner_389  1
    service_2_32_7  service_visit_def_1587  1
    service_2_32_7  free_load_conservation_1588  7
    service_2_32_8  unique_nonzero_owner_390  1
    service_2_32_8  service_visit_def_1587  1
    service_2_32_8  free_load_conservation_1588  8
    service_2_32_9  unique_nonzero_owner_391  1
    service_2_32_9  service_visit_def_1587  1
    service_2_32_9  free_load_conservation_1588  9
    service_2_32_10  unique_nonzero_owner_392  1
    service_2_32_10  service_visit_def_1587  1
    service_2_32_10  free_load_conservation_1588  10
    service_2_32_11  unique_nonzero_owner_393  1
    service_2_32_11  service_visit_def_1587  1
    service_2_32_11  free_load_conservation_1588  11
    service_2_32_12  unique_nonzero_owner_394  1
    service_2_32_12  service_visit_def_1587  1
    service_2_32_12  free_load_conservation_1588  12
    service_0_5_0  unique_nonzero_owner_395  1
    service_0_5_0  service_visit_def_850  1
    service_0_5_0  free_load_conservation_851  -2
    service_0_5_0  original_T_including_depot_unload_868  240
    service_0_5_1  unique_nonzero_owner_396  1
    service_0_5_1  service_visit_def_850  1
    service_0_5_1  free_load_conservation_851  -1
    service_0_5_1  original_T_including_depot_unload_868  120
    service_0_5_3  unique_nonzero_owner_397  1
    service_0_5_3  service_visit_def_850  1
    service_0_5_3  free_load_conservation_851  1
    service_0_5_4  unique_nonzero_owner_398  1
    service_0_5_4  service_visit_def_850  1
    service_0_5_4  free_load_conservation_851  2
    service_0_5_5  unique_nonzero_owner_399  1
    service_0_5_5  service_visit_def_850  1
    service_0_5_5  free_load_conservation_851  3
    service_0_5_6  unique_nonzero_owner_400  1
    service_0_5_6  service_visit_def_850  1
    service_0_5_6  free_load_conservation_851  4
    service_0_5_7  unique_nonzero_owner_401  1
    service_0_5_7  service_visit_def_850  1
    service_0_5_7  free_load_conservation_851  5
    service_0_5_8  unique_nonzero_owner_402  1
    service_0_5_8  service_visit_def_850  1
    service_0_5_8  free_load_conservation_851  6
    service_0_5_9  unique_nonzero_owner_403  1
    service_0_5_9  service_visit_def_850  1
    service_0_5_9  free_load_conservation_851  7
    service_0_5_10  unique_nonzero_owner_404  1
    service_0_5_10  service_visit_def_850  1
    service_0_5_10  free_load_conservation_851  8
    service_0_5_11  unique_nonzero_owner_405  1
    service_0_5_11  service_visit_def_850  1
    service_0_5_11  free_load_conservation_851  9
    service_0_5_12  unique_nonzero_owner_406  1
    service_0_5_12  service_visit_def_850  1
    service_0_5_12  free_load_conservation_851  10
    service_0_5_13  unique_nonzero_owner_407  1
    service_0_5_13  service_visit_def_850  1
    service_0_5_13  free_load_conservation_851  11
    service_0_5_14  unique_nonzero_owner_408  1
    service_0_5_14  service_visit_def_850  1
    service_0_5_14  free_load_conservation_851  12
    service_0_5_15  unique_nonzero_owner_409  1
    service_0_5_15  service_visit_def_850  1
    service_0_5_15  free_load_conservation_851  13
    service_0_5_16  unique_nonzero_owner_410  1
    service_0_5_16  service_visit_def_850  1
    service_0_5_16  free_load_conservation_851  14
    service_1_5_0  unique_nonzero_owner_395  1
    service_1_5_0  service_visit_def_1222  1
    service_1_5_0  free_load_conservation_1223  -2
    service_1_5_0  original_T_including_depot_unload_1239  240
    service_1_5_1  unique_nonzero_owner_396  1
    service_1_5_1  service_visit_def_1222  1
    service_1_5_1  free_load_conservation_1223  -1
    service_1_5_1  original_T_including_depot_unload_1239  120
    service_1_5_3  unique_nonzero_owner_397  1
    service_1_5_3  service_visit_def_1222  1
    service_1_5_3  free_load_conservation_1223  1
    service_1_5_4  unique_nonzero_owner_398  1
    service_1_5_4  service_visit_def_1222  1
    service_1_5_4  free_load_conservation_1223  2
    service_1_5_5  unique_nonzero_owner_399  1
    service_1_5_5  service_visit_def_1222  1
    service_1_5_5  free_load_conservation_1223  3
    service_1_5_6  unique_nonzero_owner_400  1
    service_1_5_6  service_visit_def_1222  1
    service_1_5_6  free_load_conservation_1223  4
    service_1_5_7  unique_nonzero_owner_401  1
    service_1_5_7  service_visit_def_1222  1
    service_1_5_7  free_load_conservation_1223  5
    service_1_5_8  unique_nonzero_owner_402  1
    service_1_5_8  service_visit_def_1222  1
    service_1_5_8  free_load_conservation_1223  6
    service_1_5_9  unique_nonzero_owner_403  1
    service_1_5_9  service_visit_def_1222  1
    service_1_5_9  free_load_conservation_1223  7
    service_1_5_10  unique_nonzero_owner_404  1
    service_1_5_10  service_visit_def_1222  1
    service_1_5_10  free_load_conservation_1223  8
    service_1_5_11  unique_nonzero_owner_405  1
    service_1_5_11  service_visit_def_1222  1
    service_1_5_11  free_load_conservation_1223  9
    service_1_5_12  unique_nonzero_owner_406  1
    service_1_5_12  service_visit_def_1222  1
    service_1_5_12  free_load_conservation_1223  10
    service_1_5_13  unique_nonzero_owner_407  1
    service_1_5_13  service_visit_def_1222  1
    service_1_5_13  free_load_conservation_1223  11
    service_1_5_14  unique_nonzero_owner_408  1
    service_1_5_14  service_visit_def_1222  1
    service_1_5_14  free_load_conservation_1223  12
    service_1_5_15  unique_nonzero_owner_409  1
    service_1_5_15  service_visit_def_1222  1
    service_1_5_15  free_load_conservation_1223  13
    service_1_5_16  unique_nonzero_owner_410  1
    service_1_5_16  service_visit_def_1222  1
    service_1_5_16  free_load_conservation_1223  14
    service_2_5_0  unique_nonzero_owner_395  1
    service_2_5_0  service_visit_def_1593  1
    service_2_5_0  free_load_conservation_1594  -2
    service_2_5_0  original_T_including_depot_unload_1610  240
    service_2_5_1  unique_nonzero_owner_396  1
    service_2_5_1  service_visit_def_1593  1
    service_2_5_1  free_load_conservation_1594  -1
    service_2_5_1  original_T_including_depot_unload_1610  120
    service_2_5_3  unique_nonzero_owner_397  1
    service_2_5_3  service_visit_def_1593  1
    service_2_5_3  free_load_conservation_1594  1
    service_2_5_4  unique_nonzero_owner_398  1
    service_2_5_4  service_visit_def_1593  1
    service_2_5_4  free_load_conservation_1594  2
    service_2_5_5  unique_nonzero_owner_399  1
    service_2_5_5  service_visit_def_1593  1
    service_2_5_5  free_load_conservation_1594  3
    service_2_5_6  unique_nonzero_owner_400  1
    service_2_5_6  service_visit_def_1593  1
    service_2_5_6  free_load_conservation_1594  4
    service_2_5_7  unique_nonzero_owner_401  1
    service_2_5_7  service_visit_def_1593  1
    service_2_5_7  free_load_conservation_1594  5
    service_2_5_8  unique_nonzero_owner_402  1
    service_2_5_8  service_visit_def_1593  1
    service_2_5_8  free_load_conservation_1594  6
    service_2_5_9  unique_nonzero_owner_403  1
    service_2_5_9  service_visit_def_1593  1
    service_2_5_9  free_load_conservation_1594  7
    service_2_5_10  unique_nonzero_owner_404  1
    service_2_5_10  service_visit_def_1593  1
    service_2_5_10  free_load_conservation_1594  8
    service_2_5_11  unique_nonzero_owner_405  1
    service_2_5_11  service_visit_def_1593  1
    service_2_5_11  free_load_conservation_1594  9
    service_2_5_12  unique_nonzero_owner_406  1
    service_2_5_12  service_visit_def_1593  1
    service_2_5_12  free_load_conservation_1594  10
    service_2_5_13  unique_nonzero_owner_407  1
    service_2_5_13  service_visit_def_1593  1
    service_2_5_13  free_load_conservation_1594  11
    service_2_5_14  unique_nonzero_owner_408  1
    service_2_5_14  service_visit_def_1593  1
    service_2_5_14  free_load_conservation_1594  12
    service_2_5_15  unique_nonzero_owner_409  1
    service_2_5_15  service_visit_def_1593  1
    service_2_5_15  free_load_conservation_1594  13
    service_2_5_16  unique_nonzero_owner_410  1
    service_2_5_16  service_visit_def_1593  1
    service_2_5_16  free_load_conservation_1594  14
    service_0_19_1  unique_nonzero_owner_411  1
    service_0_19_1  service_visit_def_856  1
    service_0_19_1  free_load_conservation_857  1
    service_0_19_2  unique_nonzero_owner_412  1
    service_0_19_2  service_visit_def_856  1
    service_0_19_2  free_load_conservation_857  2
    service_0_19_3  unique_nonzero_owner_413  1
    service_0_19_3  service_visit_def_856  1
    service_0_19_3  free_load_conservation_857  3
    service_0_19_4  unique_nonzero_owner_414  1
    service_0_19_4  service_visit_def_856  1
    service_0_19_4  free_load_conservation_857  4
    service_0_19_5  unique_nonzero_owner_415  1
    service_0_19_5  service_visit_def_856  1
    service_0_19_5  free_load_conservation_857  5
    service_0_19_6  unique_nonzero_owner_416  1
    service_0_19_6  service_visit_def_856  1
    service_0_19_6  free_load_conservation_857  6
    service_0_19_7  unique_nonzero_owner_417  1
    service_0_19_7  service_visit_def_856  1
    service_0_19_7  free_load_conservation_857  7
    service_0_19_8  unique_nonzero_owner_418  1
    service_0_19_8  service_visit_def_856  1
    service_0_19_8  free_load_conservation_857  8
    service_1_19_1  unique_nonzero_owner_411  1
    service_1_19_1  service_visit_def_1228  1
    service_1_19_1  free_load_conservation_1229  1
    service_1_19_2  unique_nonzero_owner_412  1
    service_1_19_2  service_visit_def_1228  1
    service_1_19_2  free_load_conservation_1229  2
    service_1_19_3  unique_nonzero_owner_413  1
    service_1_19_3  service_visit_def_1228  1
    service_1_19_3  free_load_conservation_1229  3
    service_1_19_4  unique_nonzero_owner_414  1
    service_1_19_4  service_visit_def_1228  1
    service_1_19_4  free_load_conservation_1229  4
    service_1_19_5  unique_nonzero_owner_415  1
    service_1_19_5  service_visit_def_1228  1
    service_1_19_5  free_load_conservation_1229  5
    service_1_19_6  unique_nonzero_owner_416  1
    service_1_19_6  service_visit_def_1228  1
    service_1_19_6  free_load_conservation_1229  6
    service_1_19_7  unique_nonzero_owner_417  1
    service_1_19_7  service_visit_def_1228  1
    service_1_19_7  free_load_conservation_1229  7
    service_1_19_8  unique_nonzero_owner_418  1
    service_1_19_8  service_visit_def_1228  1
    service_1_19_8  free_load_conservation_1229  8
    service_2_19_1  unique_nonzero_owner_411  1
    service_2_19_1  service_visit_def_1599  1
    service_2_19_1  free_load_conservation_1600  1
    service_2_19_2  unique_nonzero_owner_412  1
    service_2_19_2  service_visit_def_1599  1
    service_2_19_2  free_load_conservation_1600  2
    service_2_19_3  unique_nonzero_owner_413  1
    service_2_19_3  service_visit_def_1599  1
    service_2_19_3  free_load_conservation_1600  3
    service_2_19_4  unique_nonzero_owner_414  1
    service_2_19_4  service_visit_def_1599  1
    service_2_19_4  free_load_conservation_1600  4
    service_2_19_5  unique_nonzero_owner_415  1
    service_2_19_5  service_visit_def_1599  1
    service_2_19_5  free_load_conservation_1600  5
    service_2_19_6  unique_nonzero_owner_416  1
    service_2_19_6  service_visit_def_1599  1
    service_2_19_6  free_load_conservation_1600  6
    service_2_19_7  unique_nonzero_owner_417  1
    service_2_19_7  service_visit_def_1599  1
    service_2_19_7  free_load_conservation_1600  7
    service_2_19_8  unique_nonzero_owner_418  1
    service_2_19_8  service_visit_def_1599  1
    service_2_19_8  free_load_conservation_1600  8
    service_0_8_0  unique_nonzero_owner_419  1
    service_0_8_0  service_visit_def_862  1
    service_0_8_0  free_load_conservation_863  -15
    service_0_8_0  original_T_including_depot_unload_868  1800
    service_0_8_1  unique_nonzero_owner_420  1
    service_0_8_1  service_visit_def_862  1
    service_0_8_1  free_load_conservation_863  -14
    service_0_8_1  original_T_including_depot_unload_868  1680
    service_0_8_2  unique_nonzero_owner_421  1
    service_0_8_2  service_visit_def_862  1
    service_0_8_2  free_load_conservation_863  -13
    service_0_8_2  original_T_including_depot_unload_868  1560
    service_0_8_3  unique_nonzero_owner_422  1
    service_0_8_3  service_visit_def_862  1
    service_0_8_3  free_load_conservation_863  -12
    service_0_8_3  original_T_including_depot_unload_868  1440
    service_0_8_4  unique_nonzero_owner_423  1
    service_0_8_4  service_visit_def_862  1
    service_0_8_4  free_load_conservation_863  -11
    service_0_8_4  original_T_including_depot_unload_868  1320
    service_0_8_5  unique_nonzero_owner_424  1
    service_0_8_5  service_visit_def_862  1
    service_0_8_5  free_load_conservation_863  -10
    service_0_8_5  original_T_including_depot_unload_868  1200
    service_0_8_6  unique_nonzero_owner_425  1
    service_0_8_6  service_visit_def_862  1
    service_0_8_6  free_load_conservation_863  -9
    service_0_8_6  original_T_including_depot_unload_868  1080
    service_0_8_7  unique_nonzero_owner_426  1
    service_0_8_7  service_visit_def_862  1
    service_0_8_7  free_load_conservation_863  -8
    service_0_8_7  original_T_including_depot_unload_868  960
    service_0_8_8  unique_nonzero_owner_427  1
    service_0_8_8  service_visit_def_862  1
    service_0_8_8  free_load_conservation_863  -7
    service_0_8_8  original_T_including_depot_unload_868  840
    service_0_8_9  unique_nonzero_owner_428  1
    service_0_8_9  service_visit_def_862  1
    service_0_8_9  free_load_conservation_863  -6
    service_0_8_9  original_T_including_depot_unload_868  720
    service_0_8_10  unique_nonzero_owner_429  1
    service_0_8_10  service_visit_def_862  1
    service_0_8_10  free_load_conservation_863  -5
    service_0_8_10  original_T_including_depot_unload_868  600
    service_0_8_11  unique_nonzero_owner_430  1
    service_0_8_11  service_visit_def_862  1
    service_0_8_11  free_load_conservation_863  -4
    service_0_8_11  original_T_including_depot_unload_868  480
    service_0_8_12  unique_nonzero_owner_431  1
    service_0_8_12  service_visit_def_862  1
    service_0_8_12  free_load_conservation_863  -3
    service_0_8_12  original_T_including_depot_unload_868  360
    service_0_8_13  unique_nonzero_owner_432  1
    service_0_8_13  service_visit_def_862  1
    service_0_8_13  free_load_conservation_863  -2
    service_0_8_13  original_T_including_depot_unload_868  240
    service_0_8_14  unique_nonzero_owner_433  1
    service_0_8_14  service_visit_def_862  1
    service_0_8_14  free_load_conservation_863  -1
    service_0_8_14  original_T_including_depot_unload_868  120
    service_0_8_16  unique_nonzero_owner_434  1
    service_0_8_16  service_visit_def_862  1
    service_0_8_16  free_load_conservation_863  1
    service_0_8_17  unique_nonzero_owner_435  1
    service_0_8_17  service_visit_def_862  1
    service_0_8_17  free_load_conservation_863  2
    service_0_8_18  unique_nonzero_owner_436  1
    service_0_8_18  service_visit_def_862  1
    service_0_8_18  free_load_conservation_863  3
    service_0_8_19  unique_nonzero_owner_437  1
    service_0_8_19  service_visit_def_862  1
    service_0_8_19  free_load_conservation_863  4
    service_0_8_20  unique_nonzero_owner_438  1
    service_0_8_20  service_visit_def_862  1
    service_0_8_20  free_load_conservation_863  5
    service_0_8_21  unique_nonzero_owner_439  1
    service_0_8_21  service_visit_def_862  1
    service_0_8_21  free_load_conservation_863  6
    service_1_8_0  unique_nonzero_owner_419  1
    service_1_8_0  service_visit_def_1234  1
    service_1_8_0  free_load_conservation_1235  -15
    service_1_8_0  original_T_including_depot_unload_1239  1800
    service_1_8_1  unique_nonzero_owner_420  1
    service_1_8_1  service_visit_def_1234  1
    service_1_8_1  free_load_conservation_1235  -14
    service_1_8_1  original_T_including_depot_unload_1239  1680
    service_1_8_2  unique_nonzero_owner_421  1
    service_1_8_2  service_visit_def_1234  1
    service_1_8_2  free_load_conservation_1235  -13
    service_1_8_2  original_T_including_depot_unload_1239  1560
    service_1_8_3  unique_nonzero_owner_422  1
    service_1_8_3  service_visit_def_1234  1
    service_1_8_3  free_load_conservation_1235  -12
    service_1_8_3  original_T_including_depot_unload_1239  1440
    service_1_8_4  unique_nonzero_owner_423  1
    service_1_8_4  service_visit_def_1234  1
    service_1_8_4  free_load_conservation_1235  -11
    service_1_8_4  original_T_including_depot_unload_1239  1320
    service_1_8_5  unique_nonzero_owner_424  1
    service_1_8_5  service_visit_def_1234  1
    service_1_8_5  free_load_conservation_1235  -10
    service_1_8_5  original_T_including_depot_unload_1239  1200
    service_1_8_6  unique_nonzero_owner_425  1
    service_1_8_6  service_visit_def_1234  1
    service_1_8_6  free_load_conservation_1235  -9
    service_1_8_6  original_T_including_depot_unload_1239  1080
    service_1_8_7  unique_nonzero_owner_426  1
    service_1_8_7  service_visit_def_1234  1
    service_1_8_7  free_load_conservation_1235  -8
    service_1_8_7  original_T_including_depot_unload_1239  960
    service_1_8_8  unique_nonzero_owner_427  1
    service_1_8_8  service_visit_def_1234  1
    service_1_8_8  free_load_conservation_1235  -7
    service_1_8_8  original_T_including_depot_unload_1239  840
    service_1_8_9  unique_nonzero_owner_428  1
    service_1_8_9  service_visit_def_1234  1
    service_1_8_9  free_load_conservation_1235  -6
    service_1_8_9  original_T_including_depot_unload_1239  720
    service_1_8_10  unique_nonzero_owner_429  1
    service_1_8_10  service_visit_def_1234  1
    service_1_8_10  free_load_conservation_1235  -5
    service_1_8_10  original_T_including_depot_unload_1239  600
    service_1_8_11  unique_nonzero_owner_430  1
    service_1_8_11  service_visit_def_1234  1
    service_1_8_11  free_load_conservation_1235  -4
    service_1_8_11  original_T_including_depot_unload_1239  480
    service_1_8_12  unique_nonzero_owner_431  1
    service_1_8_12  service_visit_def_1234  1
    service_1_8_12  free_load_conservation_1235  -3
    service_1_8_12  original_T_including_depot_unload_1239  360
    service_1_8_13  unique_nonzero_owner_432  1
    service_1_8_13  service_visit_def_1234  1
    service_1_8_13  free_load_conservation_1235  -2
    service_1_8_13  original_T_including_depot_unload_1239  240
    service_1_8_14  unique_nonzero_owner_433  1
    service_1_8_14  service_visit_def_1234  1
    service_1_8_14  free_load_conservation_1235  -1
    service_1_8_14  original_T_including_depot_unload_1239  120
    service_1_8_16  unique_nonzero_owner_434  1
    service_1_8_16  service_visit_def_1234  1
    service_1_8_16  free_load_conservation_1235  1
    service_1_8_17  unique_nonzero_owner_435  1
    service_1_8_17  service_visit_def_1234  1
    service_1_8_17  free_load_conservation_1235  2
    service_1_8_18  unique_nonzero_owner_436  1
    service_1_8_18  service_visit_def_1234  1
    service_1_8_18  free_load_conservation_1235  3
    service_1_8_19  unique_nonzero_owner_437  1
    service_1_8_19  service_visit_def_1234  1
    service_1_8_19  free_load_conservation_1235  4
    service_1_8_20  unique_nonzero_owner_438  1
    service_1_8_20  service_visit_def_1234  1
    service_1_8_20  free_load_conservation_1235  5
    service_1_8_21  unique_nonzero_owner_439  1
    service_1_8_21  service_visit_def_1234  1
    service_1_8_21  free_load_conservation_1235  6
    service_2_8_0  unique_nonzero_owner_419  1
    service_2_8_0  service_visit_def_1605  1
    service_2_8_0  free_load_conservation_1606  -15
    service_2_8_0  original_T_including_depot_unload_1610  1800
    service_2_8_1  unique_nonzero_owner_420  1
    service_2_8_1  service_visit_def_1605  1
    service_2_8_1  free_load_conservation_1606  -14
    service_2_8_1  original_T_including_depot_unload_1610  1680
    service_2_8_2  unique_nonzero_owner_421  1
    service_2_8_2  service_visit_def_1605  1
    service_2_8_2  free_load_conservation_1606  -13
    service_2_8_2  original_T_including_depot_unload_1610  1560
    service_2_8_3  unique_nonzero_owner_422  1
    service_2_8_3  service_visit_def_1605  1
    service_2_8_3  free_load_conservation_1606  -12
    service_2_8_3  original_T_including_depot_unload_1610  1440
    service_2_8_4  unique_nonzero_owner_423  1
    service_2_8_4  service_visit_def_1605  1
    service_2_8_4  free_load_conservation_1606  -11
    service_2_8_4  original_T_including_depot_unload_1610  1320
    service_2_8_5  unique_nonzero_owner_424  1
    service_2_8_5  service_visit_def_1605  1
    service_2_8_5  free_load_conservation_1606  -10
    service_2_8_5  original_T_including_depot_unload_1610  1200
    service_2_8_6  unique_nonzero_owner_425  1
    service_2_8_6  service_visit_def_1605  1
    service_2_8_6  free_load_conservation_1606  -9
    service_2_8_6  original_T_including_depot_unload_1610  1080
    service_2_8_7  unique_nonzero_owner_426  1
    service_2_8_7  service_visit_def_1605  1
    service_2_8_7  free_load_conservation_1606  -8
    service_2_8_7  original_T_including_depot_unload_1610  960
    service_2_8_8  unique_nonzero_owner_427  1
    service_2_8_8  service_visit_def_1605  1
    service_2_8_8  free_load_conservation_1606  -7
    service_2_8_8  original_T_including_depot_unload_1610  840
    service_2_8_9  unique_nonzero_owner_428  1
    service_2_8_9  service_visit_def_1605  1
    service_2_8_9  free_load_conservation_1606  -6
    service_2_8_9  original_T_including_depot_unload_1610  720
    service_2_8_10  unique_nonzero_owner_429  1
    service_2_8_10  service_visit_def_1605  1
    service_2_8_10  free_load_conservation_1606  -5
    service_2_8_10  original_T_including_depot_unload_1610  600
    service_2_8_11  unique_nonzero_owner_430  1
    service_2_8_11  service_visit_def_1605  1
    service_2_8_11  free_load_conservation_1606  -4
    service_2_8_11  original_T_including_depot_unload_1610  480
    service_2_8_12  unique_nonzero_owner_431  1
    service_2_8_12  service_visit_def_1605  1
    service_2_8_12  free_load_conservation_1606  -3
    service_2_8_12  original_T_including_depot_unload_1610  360
    service_2_8_13  unique_nonzero_owner_432  1
    service_2_8_13  service_visit_def_1605  1
    service_2_8_13  free_load_conservation_1606  -2
    service_2_8_13  original_T_including_depot_unload_1610  240
    service_2_8_14  unique_nonzero_owner_433  1
    service_2_8_14  service_visit_def_1605  1
    service_2_8_14  free_load_conservation_1606  -1
    service_2_8_14  original_T_including_depot_unload_1610  120
    service_2_8_16  unique_nonzero_owner_434  1
    service_2_8_16  service_visit_def_1605  1
    service_2_8_16  free_load_conservation_1606  1
    service_2_8_17  unique_nonzero_owner_435  1
    service_2_8_17  service_visit_def_1605  1
    service_2_8_17  free_load_conservation_1606  2
    service_2_8_18  unique_nonzero_owner_436  1
    service_2_8_18  service_visit_def_1605  1
    service_2_8_18  free_load_conservation_1606  3
    service_2_8_19  unique_nonzero_owner_437  1
    service_2_8_19  service_visit_def_1605  1
    service_2_8_19  free_load_conservation_1606  4
    service_2_8_20  unique_nonzero_owner_438  1
    service_2_8_20  service_visit_def_1605  1
    service_2_8_20  free_load_conservation_1606  5
    service_2_8_21  unique_nonzero_owner_439  1
    service_2_8_21  service_visit_def_1605  1
    service_2_8_21  free_load_conservation_1606  6
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_781  -1
    visit_0_1  in_degree_782  -1
    visit_0_1  order_active_lb_783  -1
    visit_0_1  order_active_ub_784  -13
    order_0_1  connected_order_arc_456  -1
    order_0_1  connected_order_arc_458  -1
    order_0_1  connected_order_arc_460  -1
    order_0_1  connected_order_arc_462  -1
    order_0_1  connected_order_arc_464  -1
    order_0_1  connected_order_arc_466  -1
    order_0_1  connected_order_arc_468  -1
    order_0_1  connected_order_arc_470  -1
    order_0_1  connected_order_arc_472  -1
    order_0_1  connected_order_arc_474  -1
    order_0_1  connected_order_arc_476  -1
    order_0_1  connected_order_arc_478  -1
    order_0_1  connected_order_arc_481  1
    order_0_1  connected_order_arc_506  1
    order_0_1  connected_order_arc_531  1
    order_0_1  connected_order_arc_556  1
    order_0_1  connected_order_arc_581  1
    order_0_1  connected_order_arc_606  1
    order_0_1  connected_order_arc_631  1
    order_0_1  connected_order_arc_656  1
    order_0_1  connected_order_arc_681  1
    order_0_1  connected_order_arc_706  1
    order_0_1  connected_order_arc_731  1
    order_0_1  connected_order_arc_756  1
    order_0_1  order_active_lb_783  1
    order_0_1  order_active_ub_784  1
    order_0_1  fixed_segment_relative_order_864  -1
    visit_0_2  out_degree_788  -1
    visit_0_2  in_degree_789  -1
    visit_0_2  order_active_lb_790  -1
    visit_0_2  order_active_ub_791  -13
    order_0_2  connected_order_arc_456  1
    order_0_2  connected_order_arc_481  -1
    order_0_2  connected_order_arc_483  -1
    order_0_2  connected_order_arc_485  -1
    order_0_2  connected_order_arc_487  -1
    order_0_2  connected_order_arc_489  -1
    order_0_2  connected_order_arc_491  -1
    order_0_2  connected_order_arc_493  -1
    order_0_2  connected_order_arc_495  -1
    order_0_2  connected_order_arc_497  -1
    order_0_2  connected_order_arc_499  -1
    order_0_2  connected_order_arc_501  -1
    order_0_2  connected_order_arc_503  -1
    order_0_2  connected_order_arc_508  1
    order_0_2  connected_order_arc_533  1
    order_0_2  connected_order_arc_558  1
    order_0_2  connected_order_arc_583  1
    order_0_2  connected_order_arc_608  1
    order_0_2  connected_order_arc_633  1
    order_0_2  connected_order_arc_658  1
    order_0_2  connected_order_arc_683  1
    order_0_2  connected_order_arc_708  1
    order_0_2  connected_order_arc_733  1
    order_0_2  connected_order_arc_758  1
    order_0_2  order_active_lb_790  1
    order_0_2  order_active_ub_791  1
    order_0_2  fixed_segment_relative_order_864  1
    order_0_2  fixed_segment_relative_order_865  -1
    visit_0_3  out_degree_795  -1
    visit_0_3  in_degree_796  -1
    visit_0_3  order_active_lb_797  -1
    visit_0_3  order_active_ub_798  -13
    order_0_3  connected_order_arc_458  1
    order_0_3  connected_order_arc_483  1
    order_0_3  connected_order_arc_506  -1
    order_0_3  connected_order_arc_508  -1
    order_0_3  connected_order_arc_510  -1
    order_0_3  connected_order_arc_512  -1
    order_0_3  connected_order_arc_514  -1
    order_0_3  connected_order_arc_516  -1
    order_0_3  connected_order_arc_518  -1
    order_0_3  connected_order_arc_520  -1
    order_0_3  connected_order_arc_522  -1
    order_0_3  connected_order_arc_524  -1
    order_0_3  connected_order_arc_526  -1
    order_0_3  connected_order_arc_528  -1
    order_0_3  connected_order_arc_535  1
    order_0_3  connected_order_arc_560  1
    order_0_3  connected_order_arc_585  1
    order_0_3  connected_order_arc_610  1
    order_0_3  connected_order_arc_635  1
    order_0_3  connected_order_arc_660  1
    order_0_3  connected_order_arc_685  1
    order_0_3  connected_order_arc_710  1
    order_0_3  connected_order_arc_735  1
    order_0_3  connected_order_arc_760  1
    order_0_3  order_active_lb_797  1
    order_0_3  order_active_ub_798  1
    order_0_3  fixed_segment_relative_order_865  1
    order_0_3  fixed_segment_relative_order_866  -1
    visit_0_4  out_degree_802  -1
    visit_0_4  in_degree_803  -1
    visit_0_4  order_active_lb_804  -1
    visit_0_4  order_active_ub_805  -13
    order_0_4  connected_order_arc_460  1
    order_0_4  connected_order_arc_485  1
    order_0_4  connected_order_arc_510  1
    order_0_4  connected_order_arc_531  -1
    order_0_4  connected_order_arc_533  -1
    order_0_4  connected_order_arc_535  -1
    order_0_4  connected_order_arc_537  -1
    order_0_4  connected_order_arc_539  -1
    order_0_4  connected_order_arc_541  -1
    order_0_4  connected_order_arc_543  -1
    order_0_4  connected_order_arc_545  -1
    order_0_4  connected_order_arc_547  -1
    order_0_4  connected_order_arc_549  -1
    order_0_4  connected_order_arc_551  -1
    order_0_4  connected_order_arc_553  -1
    order_0_4  connected_order_arc_562  1
    order_0_4  connected_order_arc_587  1
    order_0_4  connected_order_arc_612  1
    order_0_4  connected_order_arc_637  1
    order_0_4  connected_order_arc_662  1
    order_0_4  connected_order_arc_687  1
    order_0_4  connected_order_arc_712  1
    order_0_4  connected_order_arc_737  1
    order_0_4  connected_order_arc_762  1
    order_0_4  order_active_lb_804  1
    order_0_4  order_active_ub_805  1
    order_0_4  fixed_segment_relative_order_866  1
    order_0_4  fixed_segment_relative_order_867  -1
    visit_0_5  out_degree_809  -1
    visit_0_5  in_degree_810  -1
    visit_0_5  order_active_lb_811  -1
    visit_0_5  order_active_ub_812  -13
    order_0_5  connected_order_arc_462  1
    order_0_5  connected_order_arc_487  1
    order_0_5  connected_order_arc_512  1
    order_0_5  connected_order_arc_537  1
    order_0_5  connected_order_arc_556  -1
    order_0_5  connected_order_arc_558  -1
    order_0_5  connected_order_arc_560  -1
    order_0_5  connected_order_arc_562  -1
    order_0_5  connected_order_arc_564  -1
    order_0_5  connected_order_arc_566  -1
    order_0_5  connected_order_arc_568  -1
    order_0_5  connected_order_arc_570  -1
    order_0_5  connected_order_arc_572  -1
    order_0_5  connected_order_arc_574  -1
    order_0_5  connected_order_arc_576  -1
    order_0_5  connected_order_arc_578  -1
    order_0_5  connected_order_arc_589  1
    order_0_5  connected_order_arc_614  1
    order_0_5  connected_order_arc_639  1
    order_0_5  connected_order_arc_664  1
    order_0_5  connected_order_arc_689  1
    order_0_5  connected_order_arc_714  1
    order_0_5  connected_order_arc_739  1
    order_0_5  connected_order_arc_764  1
    order_0_5  order_active_lb_811  1
    order_0_5  order_active_ub_812  1
    order_0_5  fixed_segment_relative_order_867  1
    visit_0_14  out_degree_816  -1
    visit_0_14  in_degree_817  -1
    visit_0_14  order_active_lb_818  -1
    visit_0_14  order_active_ub_819  -13
    visit_0_14  service_visit_def_820  -1
    order_0_14  connected_order_arc_464  1
    order_0_14  connected_order_arc_489  1
    order_0_14  connected_order_arc_514  1
    order_0_14  connected_order_arc_539  1
    order_0_14  connected_order_arc_564  1
    order_0_14  connected_order_arc_581  -1
    order_0_14  connected_order_arc_583  -1
    order_0_14  connected_order_arc_585  -1
    order_0_14  connected_order_arc_587  -1
    order_0_14  connected_order_arc_589  -1
    order_0_14  connected_order_arc_591  -1
    order_0_14  connected_order_arc_593  -1
    order_0_14  connected_order_arc_595  -1
    order_0_14  connected_order_arc_597  -1
    order_0_14  connected_order_arc_599  -1
    order_0_14  connected_order_arc_601  -1
    order_0_14  connected_order_arc_603  -1
    order_0_14  connected_order_arc_616  1
    order_0_14  connected_order_arc_641  1
    order_0_14  connected_order_arc_666  1
    order_0_14  connected_order_arc_691  1
    order_0_14  connected_order_arc_716  1
    order_0_14  connected_order_arc_741  1
    order_0_14  connected_order_arc_766  1
    order_0_14  order_active_lb_818  1
    order_0_14  order_active_ub_819  1
    visit_0_15  out_degree_822  -1
    visit_0_15  in_degree_823  -1
    visit_0_15  order_active_lb_824  -1
    visit_0_15  order_active_ub_825  -13
    visit_0_15  service_visit_def_826  -1
    order_0_15  connected_order_arc_466  1
    order_0_15  connected_order_arc_491  1
    order_0_15  connected_order_arc_516  1
    order_0_15  connected_order_arc_541  1
    order_0_15  connected_order_arc_566  1
    order_0_15  connected_order_arc_591  1
    order_0_15  connected_order_arc_606  -1
    order_0_15  connected_order_arc_608  -1
    order_0_15  connected_order_arc_610  -1
    order_0_15  connected_order_arc_612  -1
    order_0_15  connected_order_arc_614  -1
    order_0_15  connected_order_arc_616  -1
    order_0_15  connected_order_arc_618  -1
    order_0_15  connected_order_arc_620  -1
    order_0_15  connected_order_arc_622  -1
    order_0_15  connected_order_arc_624  -1
    order_0_15  connected_order_arc_626  -1
    order_0_15  connected_order_arc_628  -1
    order_0_15  connected_order_arc_643  1
    order_0_15  connected_order_arc_668  1
    order_0_15  connected_order_arc_693  1
    order_0_15  connected_order_arc_718  1
    order_0_15  connected_order_arc_743  1
    order_0_15  connected_order_arc_768  1
    order_0_15  order_active_lb_824  1
    order_0_15  order_active_ub_825  1
    visit_0_16  out_degree_828  -1
    visit_0_16  in_degree_829  -1
    visit_0_16  order_active_lb_830  -1
    visit_0_16  order_active_ub_831  -13
    visit_0_16  service_visit_def_832  -1
    order_0_16  connected_order_arc_468  1
    order_0_16  connected_order_arc_493  1
    order_0_16  connected_order_arc_518  1
    order_0_16  connected_order_arc_543  1
    order_0_16  connected_order_arc_568  1
    order_0_16  connected_order_arc_593  1
    order_0_16  connected_order_arc_618  1
    order_0_16  connected_order_arc_631  -1
    order_0_16  connected_order_arc_633  -1
    order_0_16  connected_order_arc_635  -1
    order_0_16  connected_order_arc_637  -1
    order_0_16  connected_order_arc_639  -1
    order_0_16  connected_order_arc_641  -1
    order_0_16  connected_order_arc_643  -1
    order_0_16  connected_order_arc_645  -1
    order_0_16  connected_order_arc_647  -1
    order_0_16  connected_order_arc_649  -1
    order_0_16  connected_order_arc_651  -1
    order_0_16  connected_order_arc_653  -1
    order_0_16  connected_order_arc_670  1
    order_0_16  connected_order_arc_695  1
    order_0_16  connected_order_arc_720  1
    order_0_16  connected_order_arc_745  1
    order_0_16  connected_order_arc_770  1
    order_0_16  order_active_lb_830  1
    order_0_16  order_active_ub_831  1
    visit_0_17  out_degree_834  -1
    visit_0_17  in_degree_835  -1
    visit_0_17  order_active_lb_836  -1
    visit_0_17  order_active_ub_837  -13
    visit_0_17  service_visit_def_838  -1
    order_0_17  connected_order_arc_470  1
    order_0_17  connected_order_arc_495  1
    order_0_17  connected_order_arc_520  1
    order_0_17  connected_order_arc_545  1
    order_0_17  connected_order_arc_570  1
    order_0_17  connected_order_arc_595  1
    order_0_17  connected_order_arc_620  1
    order_0_17  connected_order_arc_645  1
    order_0_17  connected_order_arc_656  -1
    order_0_17  connected_order_arc_658  -1
    order_0_17  connected_order_arc_660  -1
    order_0_17  connected_order_arc_662  -1
    order_0_17  connected_order_arc_664  -1
    order_0_17  connected_order_arc_666  -1
    order_0_17  connected_order_arc_668  -1
    order_0_17  connected_order_arc_670  -1
    order_0_17  connected_order_arc_672  -1
    order_0_17  connected_order_arc_674  -1
    order_0_17  connected_order_arc_676  -1
    order_0_17  connected_order_arc_678  -1
    order_0_17  connected_order_arc_697  1
    order_0_17  connected_order_arc_722  1
    order_0_17  connected_order_arc_747  1
    order_0_17  connected_order_arc_772  1
    order_0_17  order_active_lb_836  1
    order_0_17  order_active_ub_837  1
    visit_0_18  out_degree_840  -1
    visit_0_18  in_degree_841  -1
    visit_0_18  order_active_lb_842  -1
    visit_0_18  order_active_ub_843  -13
    visit_0_18  service_visit_def_844  -1
    order_0_18  connected_order_arc_472  1
    order_0_18  connected_order_arc_497  1
    order_0_18  connected_order_arc_522  1
    order_0_18  connected_order_arc_547  1
    order_0_18  connected_order_arc_572  1
    order_0_18  connected_order_arc_597  1
    order_0_18  connected_order_arc_622  1
    order_0_18  connected_order_arc_647  1
    order_0_18  connected_order_arc_672  1
    order_0_18  connected_order_arc_681  -1
    order_0_18  connected_order_arc_683  -1
    order_0_18  connected_order_arc_685  -1
    order_0_18  connected_order_arc_687  -1
    order_0_18  connected_order_arc_689  -1
    order_0_18  connected_order_arc_691  -1
    order_0_18  connected_order_arc_693  -1
    order_0_18  connected_order_arc_695  -1
    order_0_18  connected_order_arc_697  -1
    order_0_18  connected_order_arc_699  -1
    order_0_18  connected_order_arc_701  -1
    order_0_18  connected_order_arc_703  -1
    order_0_18  connected_order_arc_724  1
    order_0_18  connected_order_arc_749  1
    order_0_18  connected_order_arc_774  1
    order_0_18  order_active_lb_842  1
    order_0_18  order_active_ub_843  1
    visit_0_19  out_degree_846  -1
    visit_0_19  in_degree_847  -1
    visit_0_19  order_active_lb_848  -1
    visit_0_19  order_active_ub_849  -13
    visit_0_19  service_visit_def_850  -1
    order_0_19  connected_order_arc_474  1
    order_0_19  connected_order_arc_499  1
    order_0_19  connected_order_arc_524  1
    order_0_19  connected_order_arc_549  1
    order_0_19  connected_order_arc_574  1
    order_0_19  connected_order_arc_599  1
    order_0_19  connected_order_arc_624  1
    order_0_19  connected_order_arc_649  1
    order_0_19  connected_order_arc_674  1
    order_0_19  connected_order_arc_699  1
    order_0_19  connected_order_arc_706  -1
    order_0_19  connected_order_arc_708  -1
    order_0_19  connected_order_arc_710  -1
    order_0_19  connected_order_arc_712  -1
    order_0_19  connected_order_arc_714  -1
    order_0_19  connected_order_arc_716  -1
    order_0_19  connected_order_arc_718  -1
    order_0_19  connected_order_arc_720  -1
    order_0_19  connected_order_arc_722  -1
    order_0_19  connected_order_arc_724  -1
    order_0_19  connected_order_arc_726  -1
    order_0_19  connected_order_arc_728  -1
    order_0_19  connected_order_arc_751  1
    order_0_19  connected_order_arc_776  1
    order_0_19  order_active_lb_848  1
    order_0_19  order_active_ub_849  1
    visit_0_20  out_degree_852  -1
    visit_0_20  in_degree_853  -1
    visit_0_20  order_active_lb_854  -1
    visit_0_20  order_active_ub_855  -13
    visit_0_20  service_visit_def_856  -1
    order_0_20  connected_order_arc_476  1
    order_0_20  connected_order_arc_501  1
    order_0_20  connected_order_arc_526  1
    order_0_20  connected_order_arc_551  1
    order_0_20  connected_order_arc_576  1
    order_0_20  connected_order_arc_601  1
    order_0_20  connected_order_arc_626  1
    order_0_20  connected_order_arc_651  1
    order_0_20  connected_order_arc_676  1
    order_0_20  connected_order_arc_701  1
    order_0_20  connected_order_arc_726  1
    order_0_20  connected_order_arc_731  -1
    order_0_20  connected_order_arc_733  -1
    order_0_20  connected_order_arc_735  -1
    order_0_20  connected_order_arc_737  -1
    order_0_20  connected_order_arc_739  -1
    order_0_20  connected_order_arc_741  -1
    order_0_20  connected_order_arc_743  -1
    order_0_20  connected_order_arc_745  -1
    order_0_20  connected_order_arc_747  -1
    order_0_20  connected_order_arc_749  -1
    order_0_20  connected_order_arc_751  -1
    order_0_20  connected_order_arc_753  -1
    order_0_20  connected_order_arc_778  1
    order_0_20  order_active_lb_854  1
    order_0_20  order_active_ub_855  1
    visit_0_21  out_degree_858  -1
    visit_0_21  in_degree_859  -1
    visit_0_21  order_active_lb_860  -1
    visit_0_21  order_active_ub_861  -13
    visit_0_21  service_visit_def_862  -1
    order_0_21  connected_order_arc_478  1
    order_0_21  connected_order_arc_503  1
    order_0_21  connected_order_arc_528  1
    order_0_21  connected_order_arc_553  1
    order_0_21  connected_order_arc_578  1
    order_0_21  connected_order_arc_603  1
    order_0_21  connected_order_arc_628  1
    order_0_21  connected_order_arc_653  1
    order_0_21  connected_order_arc_678  1
    order_0_21  connected_order_arc_703  1
    order_0_21  connected_order_arc_728  1
    order_0_21  connected_order_arc_753  1
    order_0_21  connected_order_arc_756  -1
    order_0_21  connected_order_arc_758  -1
    order_0_21  connected_order_arc_760  -1
    order_0_21  connected_order_arc_762  -1
    order_0_21  connected_order_arc_764  -1
    order_0_21  connected_order_arc_766  -1
    order_0_21  connected_order_arc_768  -1
    order_0_21  connected_order_arc_770  -1
    order_0_21  connected_order_arc_772  -1
    order_0_21  connected_order_arc_774  -1
    order_0_21  connected_order_arc_776  -1
    order_0_21  connected_order_arc_778  -1
    order_0_21  order_active_lb_860  1
    order_0_21  order_active_ub_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_440  -20
    arc_0_0_0  depot_departure_or_bypass_779  1
    arc_0_0_0  depot_return_or_bypass_780  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_440  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_441  -20
    arc_0_0_1  depot_departure_or_bypass_779  1
    arc_0_0_1  in_degree_782  1
    arc_0_0_1  original_T_including_depot_unload_868  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_441  1
    load_0_0_1  segment_load_conservation_785  -1
    load_0_0_1  segment_prefix_lb_786  1
    load_0_0_1  segment_prefix_ub_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_442  -20
    arc_0_0_2  depot_departure_or_bypass_779  1
    arc_0_0_2  in_degree_789  1
    arc_0_0_2  original_T_including_depot_unload_868  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_442  1
    load_0_0_2  segment_load_conservation_792  -1
    load_0_0_2  segment_prefix_lb_793  1
    load_0_0_2  segment_prefix_ub_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_443  -20
    arc_0_0_3  depot_departure_or_bypass_779  1
    arc_0_0_3  in_degree_796  1
    arc_0_0_3  original_T_including_depot_unload_868  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_443  1
    load_0_0_3  segment_load_conservation_799  -1
    load_0_0_3  segment_prefix_lb_800  1
    load_0_0_3  segment_prefix_ub_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_444  -20
    arc_0_0_4  depot_departure_or_bypass_779  1
    arc_0_0_4  in_degree_803  1
    arc_0_0_4  original_T_including_depot_unload_868  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_444  1
    load_0_0_4  segment_load_conservation_806  -1
    load_0_0_4  segment_prefix_lb_807  1
    load_0_0_4  segment_prefix_ub_808  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_445  -20
    arc_0_0_5  depot_departure_or_bypass_779  1
    arc_0_0_5  in_degree_810  1
    arc_0_0_5  original_T_including_depot_unload_868  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_445  1
    load_0_0_5  segment_load_conservation_813  -1
    load_0_0_5  segment_prefix_lb_814  1
    load_0_0_5  segment_prefix_ub_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_446  -20
    arc_0_0_14  depot_departure_or_bypass_779  1
    arc_0_0_14  in_degree_817  1
    arc_0_0_14  original_T_including_depot_unload_868  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_446  1
    load_0_0_14  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_447  -20
    arc_0_0_15  depot_departure_or_bypass_779  1
    arc_0_0_15  in_degree_823  1
    arc_0_0_15  original_T_including_depot_unload_868  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_447  1
    load_0_0_15  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_448  -20
    arc_0_0_16  depot_departure_or_bypass_779  1
    arc_0_0_16  in_degree_829  1
    arc_0_0_16  original_T_including_depot_unload_868  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_448  1
    load_0_0_16  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_449  -20
    arc_0_0_17  depot_departure_or_bypass_779  1
    arc_0_0_17  in_degree_835  1
    arc_0_0_17  original_T_including_depot_unload_868  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_449  1
    load_0_0_17  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_450  -20
    arc_0_0_18  depot_departure_or_bypass_779  1
    arc_0_0_18  in_degree_841  1
    arc_0_0_18  original_T_including_depot_unload_868  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_450  1
    load_0_0_18  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_451  -20
    arc_0_0_19  depot_departure_or_bypass_779  1
    arc_0_0_19  in_degree_847  1
    arc_0_0_19  original_T_including_depot_unload_868  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_451  1
    load_0_0_19  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_452  -20
    arc_0_0_20  depot_departure_or_bypass_779  1
    arc_0_0_20  in_degree_853  1
    arc_0_0_20  original_T_including_depot_unload_868  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_452  1
    load_0_0_20  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_453  -20
    arc_0_0_21  depot_departure_or_bypass_779  1
    arc_0_0_21  in_degree_859  1
    arc_0_0_21  original_T_including_depot_unload_868  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_453  1
    load_0_0_21  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_454  -20
    arc_0_1_0  depot_return_or_bypass_780  1
    arc_0_1_0  out_degree_781  1
    arc_0_1_0  original_T_including_depot_unload_868  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_454  1
    load_0_1_0  segment_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_455  -20
    arc_0_1_2  connected_order_arc_456  -14
    arc_0_1_2  out_degree_781  1
    arc_0_1_2  in_degree_789  1
    arc_0_1_2  original_T_including_depot_unload_868  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_455  1
    load_0_1_2  segment_load_conservation_785  1
    load_0_1_2  segment_load_conservation_792  -1
    load_0_1_2  segment_prefix_lb_793  1
    load_0_1_2  segment_prefix_ub_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_457  -20
    arc_0_1_3  connected_order_arc_458  -14
    arc_0_1_3  out_degree_781  1
    arc_0_1_3  in_degree_796  1
    arc_0_1_3  original_T_including_depot_unload_868  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_457  1
    load_0_1_3  segment_load_conservation_785  1
    load_0_1_3  segment_load_conservation_799  -1
    load_0_1_3  segment_prefix_lb_800  1
    load_0_1_3  segment_prefix_ub_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_459  -20
    arc_0_1_4  connected_order_arc_460  -14
    arc_0_1_4  out_degree_781  1
    arc_0_1_4  in_degree_803  1
    arc_0_1_4  original_T_including_depot_unload_868  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_459  1
    load_0_1_4  segment_load_conservation_785  1
    load_0_1_4  segment_load_conservation_806  -1
    load_0_1_4  segment_prefix_lb_807  1
    load_0_1_4  segment_prefix_ub_808  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_461  -20
    arc_0_1_5  connected_order_arc_462  -14
    arc_0_1_5  out_degree_781  1
    arc_0_1_5  in_degree_810  1
    arc_0_1_5  original_T_including_depot_unload_868  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_461  1
    load_0_1_5  segment_load_conservation_785  1
    load_0_1_5  segment_load_conservation_813  -1
    load_0_1_5  segment_prefix_lb_814  1
    load_0_1_5  segment_prefix_ub_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_463  -20
    arc_0_1_14  connected_order_arc_464  -14
    arc_0_1_14  out_degree_781  1
    arc_0_1_14  in_degree_817  1
    arc_0_1_14  original_T_including_depot_unload_868  1.0428409649002836e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_463  1
    load_0_1_14  segment_load_conservation_785  1
    load_0_1_14  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_465  -20
    arc_0_1_15  connected_order_arc_466  -14
    arc_0_1_15  out_degree_781  1
    arc_0_1_15  in_degree_823  1
    arc_0_1_15  original_T_including_depot_unload_868  8.8580487162181055e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_465  1
    load_0_1_15  segment_load_conservation_785  1
    load_0_1_15  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_467  -20
    arc_0_1_16  connected_order_arc_468  -14
    arc_0_1_16  out_degree_781  1
    arc_0_1_16  in_degree_829  1
    arc_0_1_16  original_T_including_depot_unload_868  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_467  1
    load_0_1_16  segment_load_conservation_785  1
    load_0_1_16  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_469  -20
    arc_0_1_17  connected_order_arc_470  -14
    arc_0_1_17  out_degree_781  1
    arc_0_1_17  in_degree_835  1
    arc_0_1_17  original_T_including_depot_unload_868  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_469  1
    load_0_1_17  segment_load_conservation_785  1
    load_0_1_17  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_471  -20
    arc_0_1_18  connected_order_arc_472  -14
    arc_0_1_18  out_degree_781  1
    arc_0_1_18  in_degree_841  1
    arc_0_1_18  original_T_including_depot_unload_868  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_471  1
    load_0_1_18  segment_load_conservation_785  1
    load_0_1_18  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_473  -20
    arc_0_1_19  connected_order_arc_474  -14
    arc_0_1_19  out_degree_781  1
    arc_0_1_19  in_degree_847  1
    arc_0_1_19  original_T_including_depot_unload_868  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_473  1
    load_0_1_19  segment_load_conservation_785  1
    load_0_1_19  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_475  -20
    arc_0_1_20  connected_order_arc_476  -14
    arc_0_1_20  out_degree_781  1
    arc_0_1_20  in_degree_853  1
    arc_0_1_20  original_T_including_depot_unload_868  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_475  1
    load_0_1_20  segment_load_conservation_785  1
    load_0_1_20  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_477  -20
    arc_0_1_21  connected_order_arc_478  -14
    arc_0_1_21  out_degree_781  1
    arc_0_1_21  in_degree_859  1
    arc_0_1_21  original_T_including_depot_unload_868  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_477  1
    load_0_1_21  segment_load_conservation_785  1
    load_0_1_21  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_479  -20
    arc_0_2_0  depot_return_or_bypass_780  1
    arc_0_2_0  out_degree_788  1
    arc_0_2_0  original_T_including_depot_unload_868  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_479  1
    load_0_2_0  segment_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_480  -20
    arc_0_2_1  connected_order_arc_481  -14
    arc_0_2_1  in_degree_782  1
    arc_0_2_1  out_degree_788  1
    arc_0_2_1  original_T_including_depot_unload_868  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_480  1
    load_0_2_1  segment_load_conservation_785  -1
    load_0_2_1  segment_prefix_lb_786  1
    load_0_2_1  segment_prefix_ub_787  1
    load_0_2_1  segment_load_conservation_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_482  -20
    arc_0_2_3  connected_order_arc_483  -14
    arc_0_2_3  out_degree_788  1
    arc_0_2_3  in_degree_796  1
    arc_0_2_3  original_T_including_depot_unload_868  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_482  1
    load_0_2_3  segment_load_conservation_792  1
    load_0_2_3  segment_load_conservation_799  -1
    load_0_2_3  segment_prefix_lb_800  1
    load_0_2_3  segment_prefix_ub_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_484  -20
    arc_0_2_4  connected_order_arc_485  -14
    arc_0_2_4  out_degree_788  1
    arc_0_2_4  in_degree_803  1
    arc_0_2_4  original_T_including_depot_unload_868  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_484  1
    load_0_2_4  segment_load_conservation_792  1
    load_0_2_4  segment_load_conservation_806  -1
    load_0_2_4  segment_prefix_lb_807  1
    load_0_2_4  segment_prefix_ub_808  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_486  -20
    arc_0_2_5  connected_order_arc_487  -14
    arc_0_2_5  out_degree_788  1
    arc_0_2_5  in_degree_810  1
    arc_0_2_5  original_T_including_depot_unload_868  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_486  1
    load_0_2_5  segment_load_conservation_792  1
    load_0_2_5  segment_load_conservation_813  -1
    load_0_2_5  segment_prefix_lb_814  1
    load_0_2_5  segment_prefix_ub_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_488  -20
    arc_0_2_14  connected_order_arc_489  -14
    arc_0_2_14  out_degree_788  1
    arc_0_2_14  in_degree_817  1
    arc_0_2_14  original_T_including_depot_unload_868  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_488  1
    load_0_2_14  segment_load_conservation_792  1
    load_0_2_14  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_490  -20
    arc_0_2_15  connected_order_arc_491  -14
    arc_0_2_15  out_degree_788  1
    arc_0_2_15  in_degree_823  1
    arc_0_2_15  original_T_including_depot_unload_868  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_490  1
    load_0_2_15  segment_load_conservation_792  1
    load_0_2_15  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_492  -20
    arc_0_2_16  connected_order_arc_493  -14
    arc_0_2_16  out_degree_788  1
    arc_0_2_16  in_degree_829  1
    arc_0_2_16  original_T_including_depot_unload_868  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_492  1
    load_0_2_16  segment_load_conservation_792  1
    load_0_2_16  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_494  -20
    arc_0_2_17  connected_order_arc_495  -14
    arc_0_2_17  out_degree_788  1
    arc_0_2_17  in_degree_835  1
    arc_0_2_17  original_T_including_depot_unload_868  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_494  1
    load_0_2_17  segment_load_conservation_792  1
    load_0_2_17  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_496  -20
    arc_0_2_18  connected_order_arc_497  -14
    arc_0_2_18  out_degree_788  1
    arc_0_2_18  in_degree_841  1
    arc_0_2_18  original_T_including_depot_unload_868  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_496  1
    load_0_2_18  segment_load_conservation_792  1
    load_0_2_18  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_498  -20
    arc_0_2_19  connected_order_arc_499  -14
    arc_0_2_19  out_degree_788  1
    arc_0_2_19  in_degree_847  1
    arc_0_2_19  original_T_including_depot_unload_868  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_498  1
    load_0_2_19  segment_load_conservation_792  1
    load_0_2_19  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_500  -20
    arc_0_2_20  connected_order_arc_501  -14
    arc_0_2_20  out_degree_788  1
    arc_0_2_20  in_degree_853  1
    arc_0_2_20  original_T_including_depot_unload_868  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_500  1
    load_0_2_20  segment_load_conservation_792  1
    load_0_2_20  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_502  -20
    arc_0_2_21  connected_order_arc_503  -14
    arc_0_2_21  out_degree_788  1
    arc_0_2_21  in_degree_859  1
    arc_0_2_21  original_T_including_depot_unload_868  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_502  1
    load_0_2_21  segment_load_conservation_792  1
    load_0_2_21  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_504  -20
    arc_0_3_0  depot_return_or_bypass_780  1
    arc_0_3_0  out_degree_795  1
    arc_0_3_0  original_T_including_depot_unload_868  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_504  1
    load_0_3_0  segment_load_conservation_799  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_505  -20
    arc_0_3_1  connected_order_arc_506  -14
    arc_0_3_1  in_degree_782  1
    arc_0_3_1  out_degree_795  1
    arc_0_3_1  original_T_including_depot_unload_868  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_505  1
    load_0_3_1  segment_load_conservation_785  -1
    load_0_3_1  segment_prefix_lb_786  1
    load_0_3_1  segment_prefix_ub_787  1
    load_0_3_1  segment_load_conservation_799  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_507  -20
    arc_0_3_2  connected_order_arc_508  -14
    arc_0_3_2  in_degree_789  1
    arc_0_3_2  out_degree_795  1
    arc_0_3_2  original_T_including_depot_unload_868  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_507  1
    load_0_3_2  segment_load_conservation_792  -1
    load_0_3_2  segment_prefix_lb_793  1
    load_0_3_2  segment_prefix_ub_794  1
    load_0_3_2  segment_load_conservation_799  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_509  -20
    arc_0_3_4  connected_order_arc_510  -14
    arc_0_3_4  out_degree_795  1
    arc_0_3_4  in_degree_803  1
    arc_0_3_4  original_T_including_depot_unload_868  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_509  1
    load_0_3_4  segment_load_conservation_799  1
    load_0_3_4  segment_load_conservation_806  -1
    load_0_3_4  segment_prefix_lb_807  1
    load_0_3_4  segment_prefix_ub_808  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_511  -20
    arc_0_3_5  connected_order_arc_512  -14
    arc_0_3_5  out_degree_795  1
    arc_0_3_5  in_degree_810  1
    arc_0_3_5  original_T_including_depot_unload_868  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_511  1
    load_0_3_5  segment_load_conservation_799  1
    load_0_3_5  segment_load_conservation_813  -1
    load_0_3_5  segment_prefix_lb_814  1
    load_0_3_5  segment_prefix_ub_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_513  -20
    arc_0_3_14  connected_order_arc_514  -14
    arc_0_3_14  out_degree_795  1
    arc_0_3_14  in_degree_817  1
    arc_0_3_14  original_T_including_depot_unload_868  1.1016218375294079e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_513  1
    load_0_3_14  segment_load_conservation_799  1
    load_0_3_14  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_515  -20
    arc_0_3_15  connected_order_arc_516  -14
    arc_0_3_15  out_degree_795  1
    arc_0_3_15  in_degree_823  1
    arc_0_3_15  original_T_including_depot_unload_868  1.1989066345879348e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_515  1
    load_0_3_15  segment_load_conservation_799  1
    load_0_3_15  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_517  -20
    arc_0_3_16  connected_order_arc_518  -14
    arc_0_3_16  out_degree_795  1
    arc_0_3_16  in_degree_829  1
    arc_0_3_16  original_T_including_depot_unload_868  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_517  1
    load_0_3_16  segment_load_conservation_799  1
    load_0_3_16  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_519  -20
    arc_0_3_17  connected_order_arc_520  -14
    arc_0_3_17  out_degree_795  1
    arc_0_3_17  in_degree_835  1
    arc_0_3_17  original_T_including_depot_unload_868  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_519  1
    load_0_3_17  segment_load_conservation_799  1
    load_0_3_17  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_521  -20
    arc_0_3_18  connected_order_arc_522  -14
    arc_0_3_18  out_degree_795  1
    arc_0_3_18  in_degree_841  1
    arc_0_3_18  original_T_including_depot_unload_868  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_521  1
    load_0_3_18  segment_load_conservation_799  1
    load_0_3_18  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_523  -20
    arc_0_3_19  connected_order_arc_524  -14
    arc_0_3_19  out_degree_795  1
    arc_0_3_19  in_degree_847  1
    arc_0_3_19  original_T_including_depot_unload_868  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_523  1
    load_0_3_19  segment_load_conservation_799  1
    load_0_3_19  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_525  -20
    arc_0_3_20  connected_order_arc_526  -14
    arc_0_3_20  out_degree_795  1
    arc_0_3_20  in_degree_853  1
    arc_0_3_20  original_T_including_depot_unload_868  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_525  1
    load_0_3_20  segment_load_conservation_799  1
    load_0_3_20  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_527  -20
    arc_0_3_21  connected_order_arc_528  -14
    arc_0_3_21  out_degree_795  1
    arc_0_3_21  in_degree_859  1
    arc_0_3_21  original_T_including_depot_unload_868  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_527  1
    load_0_3_21  segment_load_conservation_799  1
    load_0_3_21  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_529  -20
    arc_0_4_0  depot_return_or_bypass_780  1
    arc_0_4_0  out_degree_802  1
    arc_0_4_0  original_T_including_depot_unload_868  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_529  1
    load_0_4_0  segment_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_530  -20
    arc_0_4_1  connected_order_arc_531  -14
    arc_0_4_1  in_degree_782  1
    arc_0_4_1  out_degree_802  1
    arc_0_4_1  original_T_including_depot_unload_868  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_530  1
    load_0_4_1  segment_load_conservation_785  -1
    load_0_4_1  segment_prefix_lb_786  1
    load_0_4_1  segment_prefix_ub_787  1
    load_0_4_1  segment_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_532  -20
    arc_0_4_2  connected_order_arc_533  -14
    arc_0_4_2  in_degree_789  1
    arc_0_4_2  out_degree_802  1
    arc_0_4_2  original_T_including_depot_unload_868  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_532  1
    load_0_4_2  segment_load_conservation_792  -1
    load_0_4_2  segment_prefix_lb_793  1
    load_0_4_2  segment_prefix_ub_794  1
    load_0_4_2  segment_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_534  -20
    arc_0_4_3  connected_order_arc_535  -14
    arc_0_4_3  in_degree_796  1
    arc_0_4_3  out_degree_802  1
    arc_0_4_3  original_T_including_depot_unload_868  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_534  1
    load_0_4_3  segment_load_conservation_799  -1
    load_0_4_3  segment_prefix_lb_800  1
    load_0_4_3  segment_prefix_ub_801  1
    load_0_4_3  segment_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_536  -20
    arc_0_4_5  connected_order_arc_537  -14
    arc_0_4_5  out_degree_802  1
    arc_0_4_5  in_degree_810  1
    arc_0_4_5  original_T_including_depot_unload_868  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_536  1
    load_0_4_5  segment_load_conservation_806  1
    load_0_4_5  segment_load_conservation_813  -1
    load_0_4_5  segment_prefix_lb_814  1
    load_0_4_5  segment_prefix_ub_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_538  -20
    arc_0_4_14  connected_order_arc_539  -14
    arc_0_4_14  out_degree_802  1
    arc_0_4_14  in_degree_817  1
    arc_0_4_14  original_T_including_depot_unload_868  1.2399174881238241e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_538  1
    load_0_4_14  segment_load_conservation_806  1
    load_0_4_14  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_540  -20
    arc_0_4_15  connected_order_arc_541  -14
    arc_0_4_15  out_degree_802  1
    arc_0_4_15  in_degree_823  1
    arc_0_4_15  original_T_including_depot_unload_868  1.3889860796771311e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_540  1
    load_0_4_15  segment_load_conservation_806  1
    load_0_4_15  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_542  -20
    arc_0_4_16  connected_order_arc_543  -14
    arc_0_4_16  out_degree_802  1
    arc_0_4_16  in_degree_829  1
    arc_0_4_16  original_T_including_depot_unload_868  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_542  1
    load_0_4_16  segment_load_conservation_806  1
    load_0_4_16  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_544  -20
    arc_0_4_17  connected_order_arc_545  -14
    arc_0_4_17  out_degree_802  1
    arc_0_4_17  in_degree_835  1
    arc_0_4_17  original_T_including_depot_unload_868  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_544  1
    load_0_4_17  segment_load_conservation_806  1
    load_0_4_17  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_546  -20
    arc_0_4_18  connected_order_arc_547  -14
    arc_0_4_18  out_degree_802  1
    arc_0_4_18  in_degree_841  1
    arc_0_4_18  original_T_including_depot_unload_868  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_546  1
    load_0_4_18  segment_load_conservation_806  1
    load_0_4_18  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_548  -20
    arc_0_4_19  connected_order_arc_549  -14
    arc_0_4_19  out_degree_802  1
    arc_0_4_19  in_degree_847  1
    arc_0_4_19  original_T_including_depot_unload_868  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_548  1
    load_0_4_19  segment_load_conservation_806  1
    load_0_4_19  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_550  -20
    arc_0_4_20  connected_order_arc_551  -14
    arc_0_4_20  out_degree_802  1
    arc_0_4_20  in_degree_853  1
    arc_0_4_20  original_T_including_depot_unload_868  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_550  1
    load_0_4_20  segment_load_conservation_806  1
    load_0_4_20  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_552  -20
    arc_0_4_21  connected_order_arc_553  -14
    arc_0_4_21  out_degree_802  1
    arc_0_4_21  in_degree_859  1
    arc_0_4_21  original_T_including_depot_unload_868  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_552  1
    load_0_4_21  segment_load_conservation_806  1
    load_0_4_21  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_554  -20
    arc_0_5_0  depot_return_or_bypass_780  1
    arc_0_5_0  out_degree_809  1
    arc_0_5_0  original_T_including_depot_unload_868  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_554  1
    load_0_5_0  segment_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_555  -20
    arc_0_5_1  connected_order_arc_556  -14
    arc_0_5_1  in_degree_782  1
    arc_0_5_1  out_degree_809  1
    arc_0_5_1  original_T_including_depot_unload_868  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_555  1
    load_0_5_1  segment_load_conservation_785  -1
    load_0_5_1  segment_prefix_lb_786  1
    load_0_5_1  segment_prefix_ub_787  1
    load_0_5_1  segment_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_557  -20
    arc_0_5_2  connected_order_arc_558  -14
    arc_0_5_2  in_degree_789  1
    arc_0_5_2  out_degree_809  1
    arc_0_5_2  original_T_including_depot_unload_868  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_557  1
    load_0_5_2  segment_load_conservation_792  -1
    load_0_5_2  segment_prefix_lb_793  1
    load_0_5_2  segment_prefix_ub_794  1
    load_0_5_2  segment_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_559  -20
    arc_0_5_3  connected_order_arc_560  -14
    arc_0_5_3  in_degree_796  1
    arc_0_5_3  out_degree_809  1
    arc_0_5_3  original_T_including_depot_unload_868  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_559  1
    load_0_5_3  segment_load_conservation_799  -1
    load_0_5_3  segment_prefix_lb_800  1
    load_0_5_3  segment_prefix_ub_801  1
    load_0_5_3  segment_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_561  -20
    arc_0_5_4  connected_order_arc_562  -14
    arc_0_5_4  in_degree_803  1
    arc_0_5_4  out_degree_809  1
    arc_0_5_4  original_T_including_depot_unload_868  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_561  1
    load_0_5_4  segment_load_conservation_806  -1
    load_0_5_4  segment_prefix_lb_807  1
    load_0_5_4  segment_prefix_ub_808  1
    load_0_5_4  segment_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_563  -20
    arc_0_5_14  connected_order_arc_564  -14
    arc_0_5_14  out_degree_809  1
    arc_0_5_14  in_degree_817  1
    arc_0_5_14  original_T_including_depot_unload_868  1.3898988531263665e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_563  1
    load_0_5_14  segment_load_conservation_813  1
    load_0_5_14  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_565  -20
    arc_0_5_15  connected_order_arc_566  -14
    arc_0_5_15  out_degree_809  1
    arc_0_5_15  in_degree_823  1
    arc_0_5_15  original_T_including_depot_unload_868  1.4399299780980639e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_565  1
    load_0_5_15  segment_load_conservation_813  1
    load_0_5_15  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_567  -20
    arc_0_5_16  connected_order_arc_568  -14
    arc_0_5_16  out_degree_809  1
    arc_0_5_16  in_degree_829  1
    arc_0_5_16  original_T_including_depot_unload_868  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_567  1
    load_0_5_16  segment_load_conservation_813  1
    load_0_5_16  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_569  -20
    arc_0_5_17  connected_order_arc_570  -14
    arc_0_5_17  out_degree_809  1
    arc_0_5_17  in_degree_835  1
    arc_0_5_17  original_T_including_depot_unload_868  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_569  1
    load_0_5_17  segment_load_conservation_813  1
    load_0_5_17  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_571  -20
    arc_0_5_18  connected_order_arc_572  -14
    arc_0_5_18  out_degree_809  1
    arc_0_5_18  in_degree_841  1
    arc_0_5_18  original_T_including_depot_unload_868  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_571  1
    load_0_5_18  segment_load_conservation_813  1
    load_0_5_18  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_573  -20
    arc_0_5_19  connected_order_arc_574  -14
    arc_0_5_19  out_degree_809  1
    arc_0_5_19  in_degree_847  1
    arc_0_5_19  original_T_including_depot_unload_868  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_573  1
    load_0_5_19  segment_load_conservation_813  1
    load_0_5_19  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_575  -20
    arc_0_5_20  connected_order_arc_576  -14
    arc_0_5_20  out_degree_809  1
    arc_0_5_20  in_degree_853  1
    arc_0_5_20  original_T_including_depot_unload_868  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_575  1
    load_0_5_20  segment_load_conservation_813  1
    load_0_5_20  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_577  -20
    arc_0_5_21  connected_order_arc_578  -14
    arc_0_5_21  out_degree_809  1
    arc_0_5_21  in_degree_859  1
    arc_0_5_21  original_T_including_depot_unload_868  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_577  1
    load_0_5_21  segment_load_conservation_813  1
    load_0_5_21  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_579  -20
    arc_0_14_0  depot_return_or_bypass_780  1
    arc_0_14_0  out_degree_816  1
    arc_0_14_0  original_T_including_depot_unload_868  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_579  1
    load_0_14_0  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_580  -20
    arc_0_14_1  connected_order_arc_581  -14
    arc_0_14_1  in_degree_782  1
    arc_0_14_1  out_degree_816  1
    arc_0_14_1  original_T_including_depot_unload_868  1.3132316623300278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_580  1
    load_0_14_1  segment_load_conservation_785  -1
    load_0_14_1  segment_prefix_lb_786  1
    load_0_14_1  segment_prefix_ub_787  1
    load_0_14_1  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_582  -20
    arc_0_14_2  connected_order_arc_583  -14
    arc_0_14_2  in_degree_789  1
    arc_0_14_2  out_degree_816  1
    arc_0_14_2  original_T_including_depot_unload_868  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_582  1
    load_0_14_2  segment_load_conservation_792  -1
    load_0_14_2  segment_prefix_lb_793  1
    load_0_14_2  segment_prefix_ub_794  1
    load_0_14_2  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_584  -20
    arc_0_14_3  connected_order_arc_585  -14
    arc_0_14_3  in_degree_796  1
    arc_0_14_3  out_degree_816  1
    arc_0_14_3  original_T_including_depot_unload_868  1.1016218375294079e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_584  1
    load_0_14_3  segment_load_conservation_799  -1
    load_0_14_3  segment_prefix_lb_800  1
    load_0_14_3  segment_prefix_ub_801  1
    load_0_14_3  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_586  -20
    arc_0_14_4  connected_order_arc_587  -14
    arc_0_14_4  in_degree_803  1
    arc_0_14_4  out_degree_816  1
    arc_0_14_4  original_T_including_depot_unload_868  1.2399174881238241e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_586  1
    load_0_14_4  segment_load_conservation_806  -1
    load_0_14_4  segment_prefix_lb_807  1
    load_0_14_4  segment_prefix_ub_808  1
    load_0_14_4  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_588  -20
    arc_0_14_5  connected_order_arc_589  -14
    arc_0_14_5  in_degree_810  1
    arc_0_14_5  out_degree_816  1
    arc_0_14_5  original_T_including_depot_unload_868  1.3898988531263665e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_588  1
    load_0_14_5  segment_load_conservation_813  -1
    load_0_14_5  segment_prefix_lb_814  1
    load_0_14_5  segment_prefix_ub_815  1
    load_0_14_5  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_590  -20
    arc_0_14_15  connected_order_arc_591  -14
    arc_0_14_15  out_degree_816  1
    arc_0_14_15  in_degree_823  1
    arc_0_14_15  original_T_including_depot_unload_868  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_590  1
    load_0_14_15  free_load_conservation_821  1
    load_0_14_15  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_592  -20
    arc_0_14_16  connected_order_arc_593  -14
    arc_0_14_16  out_degree_816  1
    arc_0_14_16  in_degree_829  1
    arc_0_14_16  original_T_including_depot_unload_868  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_592  1
    load_0_14_16  free_load_conservation_821  1
    load_0_14_16  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_594  -20
    arc_0_14_17  connected_order_arc_595  -14
    arc_0_14_17  out_degree_816  1
    arc_0_14_17  in_degree_835  1
    arc_0_14_17  original_T_including_depot_unload_868  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_594  1
    load_0_14_17  free_load_conservation_821  1
    load_0_14_17  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_596  -20
    arc_0_14_18  connected_order_arc_597  -14
    arc_0_14_18  out_degree_816  1
    arc_0_14_18  in_degree_841  1
    arc_0_14_18  original_T_including_depot_unload_868  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_596  1
    load_0_14_18  free_load_conservation_821  1
    load_0_14_18  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_598  -20
    arc_0_14_19  connected_order_arc_599  -14
    arc_0_14_19  out_degree_816  1
    arc_0_14_19  in_degree_847  1
    arc_0_14_19  original_T_including_depot_unload_868  7.6789230776331749e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_598  1
    load_0_14_19  free_load_conservation_821  1
    load_0_14_19  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_600  -20
    arc_0_14_20  connected_order_arc_601  -14
    arc_0_14_20  out_degree_816  1
    arc_0_14_20  in_degree_853  1
    arc_0_14_20  original_T_including_depot_unload_868  1.4688211749637876e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_600  1
    load_0_14_20  free_load_conservation_821  1
    load_0_14_20  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_21  arc_capacity_602  -20
    arc_0_14_21  connected_order_arc_603  -14
    arc_0_14_21  out_degree_816  1
    arc_0_14_21  in_degree_859  1
    arc_0_14_21  original_T_including_depot_unload_868  8.2066682484686987e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_21  arc_capacity_602  1
    load_0_14_21  free_load_conservation_821  1
    load_0_14_21  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_604  -20
    arc_0_15_0  depot_return_or_bypass_780  1
    arc_0_15_0  out_degree_822  1
    arc_0_15_0  original_T_including_depot_unload_868  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_604  1
    load_0_15_0  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_605  -20
    arc_0_15_1  connected_order_arc_606  -14
    arc_0_15_1  in_degree_782  1
    arc_0_15_1  out_degree_822  1
    arc_0_15_1  original_T_including_depot_unload_868  1.1260666281343611e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_605  1
    load_0_15_1  segment_load_conservation_785  -1
    load_0_15_1  segment_prefix_lb_786  1
    load_0_15_1  segment_prefix_ub_787  1
    load_0_15_1  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_607  -20
    arc_0_15_2  connected_order_arc_608  -14
    arc_0_15_2  in_degree_789  1
    arc_0_15_2  out_degree_822  1
    arc_0_15_2  original_T_including_depot_unload_868  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_607  1
    load_0_15_2  segment_load_conservation_792  -1
    load_0_15_2  segment_prefix_lb_793  1
    load_0_15_2  segment_prefix_ub_794  1
    load_0_15_2  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_609  -20
    arc_0_15_3  connected_order_arc_610  -14
    arc_0_15_3  in_degree_796  1
    arc_0_15_3  out_degree_822  1
    arc_0_15_3  original_T_including_depot_unload_868  1.1989066345879348e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_609  1
    load_0_15_3  segment_load_conservation_799  -1
    load_0_15_3  segment_prefix_lb_800  1
    load_0_15_3  segment_prefix_ub_801  1
    load_0_15_3  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_611  -20
    arc_0_15_4  connected_order_arc_612  -14
    arc_0_15_4  in_degree_803  1
    arc_0_15_4  out_degree_822  1
    arc_0_15_4  original_T_including_depot_unload_868  1.3889860796771311e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_611  1
    load_0_15_4  segment_load_conservation_806  -1
    load_0_15_4  segment_prefix_lb_807  1
    load_0_15_4  segment_prefix_ub_808  1
    load_0_15_4  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_613  -20
    arc_0_15_5  connected_order_arc_614  -14
    arc_0_15_5  in_degree_810  1
    arc_0_15_5  out_degree_822  1
    arc_0_15_5  original_T_including_depot_unload_868  1.4399299780980639e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_613  1
    load_0_15_5  segment_load_conservation_813  -1
    load_0_15_5  segment_prefix_lb_814  1
    load_0_15_5  segment_prefix_ub_815  1
    load_0_15_5  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_615  -20
    arc_0_15_14  connected_order_arc_616  -14
    arc_0_15_14  in_degree_817  1
    arc_0_15_14  out_degree_822  1
    arc_0_15_14  original_T_including_depot_unload_868  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_615  1
    load_0_15_14  free_load_conservation_821  -1
    load_0_15_14  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_617  -20
    arc_0_15_16  connected_order_arc_618  -14
    arc_0_15_16  out_degree_822  1
    arc_0_15_16  in_degree_829  1
    arc_0_15_16  original_T_including_depot_unload_868  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_617  1
    load_0_15_16  free_load_conservation_827  1
    load_0_15_16  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_619  -20
    arc_0_15_17  connected_order_arc_620  -14
    arc_0_15_17  out_degree_822  1
    arc_0_15_17  in_degree_835  1
    arc_0_15_17  original_T_including_depot_unload_868  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_619  1
    load_0_15_17  free_load_conservation_827  1
    load_0_15_17  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_621  -20
    arc_0_15_18  connected_order_arc_622  -14
    arc_0_15_18  out_degree_822  1
    arc_0_15_18  in_degree_841  1
    arc_0_15_18  original_T_including_depot_unload_868  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_621  1
    load_0_15_18  free_load_conservation_827  1
    load_0_15_18  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_623  -20
    arc_0_15_19  connected_order_arc_624  -14
    arc_0_15_19  out_degree_822  1
    arc_0_15_19  in_degree_847  1
    arc_0_15_19  original_T_including_depot_unload_868  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_623  1
    load_0_15_19  free_load_conservation_827  1
    load_0_15_19  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_625  -20
    arc_0_15_20  connected_order_arc_626  -14
    arc_0_15_20  out_degree_822  1
    arc_0_15_20  in_degree_853  1
    arc_0_15_20  original_T_including_depot_unload_868  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_625  1
    load_0_15_20  free_load_conservation_827  1
    load_0_15_20  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_627  -20
    arc_0_15_21  connected_order_arc_628  -14
    arc_0_15_21  out_degree_822  1
    arc_0_15_21  in_degree_859  1
    arc_0_15_21  original_T_including_depot_unload_868  8.6958069185371107e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_627  1
    load_0_15_21  free_load_conservation_827  1
    load_0_15_21  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_629  -20
    arc_0_16_0  depot_return_or_bypass_780  1
    arc_0_16_0  out_degree_828  1
    arc_0_16_0  original_T_including_depot_unload_868  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_629  1
    load_0_16_0  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_630  -20
    arc_0_16_1  connected_order_arc_631  -14
    arc_0_16_1  in_degree_782  1
    arc_0_16_1  out_degree_828  1
    arc_0_16_1  original_T_including_depot_unload_868  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_630  1
    load_0_16_1  segment_load_conservation_785  -1
    load_0_16_1  segment_prefix_lb_786  1
    load_0_16_1  segment_prefix_ub_787  1
    load_0_16_1  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_632  -20
    arc_0_16_2  connected_order_arc_633  -14
    arc_0_16_2  in_degree_789  1
    arc_0_16_2  out_degree_828  1
    arc_0_16_2  original_T_including_depot_unload_868  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_632  1
    load_0_16_2  segment_load_conservation_792  -1
    load_0_16_2  segment_prefix_lb_793  1
    load_0_16_2  segment_prefix_ub_794  1
    load_0_16_2  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_634  -20
    arc_0_16_3  connected_order_arc_635  -14
    arc_0_16_3  in_degree_796  1
    arc_0_16_3  out_degree_828  1
    arc_0_16_3  original_T_including_depot_unload_868  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_634  1
    load_0_16_3  segment_load_conservation_799  -1
    load_0_16_3  segment_prefix_lb_800  1
    load_0_16_3  segment_prefix_ub_801  1
    load_0_16_3  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_636  -20
    arc_0_16_4  connected_order_arc_637  -14
    arc_0_16_4  in_degree_803  1
    arc_0_16_4  out_degree_828  1
    arc_0_16_4  original_T_including_depot_unload_868  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_636  1
    load_0_16_4  segment_load_conservation_806  -1
    load_0_16_4  segment_prefix_lb_807  1
    load_0_16_4  segment_prefix_ub_808  1
    load_0_16_4  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_638  -20
    arc_0_16_5  connected_order_arc_639  -14
    arc_0_16_5  in_degree_810  1
    arc_0_16_5  out_degree_828  1
    arc_0_16_5  original_T_including_depot_unload_868  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_638  1
    load_0_16_5  segment_load_conservation_813  -1
    load_0_16_5  segment_prefix_lb_814  1
    load_0_16_5  segment_prefix_ub_815  1
    load_0_16_5  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_640  -20
    arc_0_16_14  connected_order_arc_641  -14
    arc_0_16_14  in_degree_817  1
    arc_0_16_14  out_degree_828  1
    arc_0_16_14  original_T_including_depot_unload_868  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_640  1
    load_0_16_14  free_load_conservation_821  -1
    load_0_16_14  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_642  -20
    arc_0_16_15  connected_order_arc_643  -14
    arc_0_16_15  in_degree_823  1
    arc_0_16_15  out_degree_828  1
    arc_0_16_15  original_T_including_depot_unload_868  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_642  1
    load_0_16_15  free_load_conservation_827  -1
    load_0_16_15  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_644  -20
    arc_0_16_17  connected_order_arc_645  -14
    arc_0_16_17  out_degree_828  1
    arc_0_16_17  in_degree_835  1
    arc_0_16_17  original_T_including_depot_unload_868  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_644  1
    load_0_16_17  free_load_conservation_833  1
    load_0_16_17  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_646  -20
    arc_0_16_18  connected_order_arc_647  -14
    arc_0_16_18  out_degree_828  1
    arc_0_16_18  in_degree_841  1
    arc_0_16_18  original_T_including_depot_unload_868  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_646  1
    load_0_16_18  free_load_conservation_833  1
    load_0_16_18  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_648  -20
    arc_0_16_19  connected_order_arc_649  -14
    arc_0_16_19  out_degree_828  1
    arc_0_16_19  in_degree_847  1
    arc_0_16_19  original_T_including_depot_unload_868  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_648  1
    load_0_16_19  free_load_conservation_833  1
    load_0_16_19  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_650  -20
    arc_0_16_20  connected_order_arc_651  -14
    arc_0_16_20  out_degree_828  1
    arc_0_16_20  in_degree_853  1
    arc_0_16_20  original_T_including_depot_unload_868  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_650  1
    load_0_16_20  free_load_conservation_833  1
    load_0_16_20  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_652  -20
    arc_0_16_21  connected_order_arc_653  -14
    arc_0_16_21  out_degree_828  1
    arc_0_16_21  in_degree_859  1
    arc_0_16_21  original_T_including_depot_unload_868  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_652  1
    load_0_16_21  free_load_conservation_833  1
    load_0_16_21  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_654  -20
    arc_0_17_0  depot_return_or_bypass_780  1
    arc_0_17_0  out_degree_834  1
    arc_0_17_0  original_T_including_depot_unload_868  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_654  1
    load_0_17_0  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_655  -20
    arc_0_17_1  connected_order_arc_656  -14
    arc_0_17_1  in_degree_782  1
    arc_0_17_1  out_degree_834  1
    arc_0_17_1  original_T_including_depot_unload_868  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_655  1
    load_0_17_1  segment_load_conservation_785  -1
    load_0_17_1  segment_prefix_lb_786  1
    load_0_17_1  segment_prefix_ub_787  1
    load_0_17_1  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_657  -20
    arc_0_17_2  connected_order_arc_658  -14
    arc_0_17_2  in_degree_789  1
    arc_0_17_2  out_degree_834  1
    arc_0_17_2  original_T_including_depot_unload_868  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_657  1
    load_0_17_2  segment_load_conservation_792  -1
    load_0_17_2  segment_prefix_lb_793  1
    load_0_17_2  segment_prefix_ub_794  1
    load_0_17_2  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_659  -20
    arc_0_17_3  connected_order_arc_660  -14
    arc_0_17_3  in_degree_796  1
    arc_0_17_3  out_degree_834  1
    arc_0_17_3  original_T_including_depot_unload_868  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_659  1
    load_0_17_3  segment_load_conservation_799  -1
    load_0_17_3  segment_prefix_lb_800  1
    load_0_17_3  segment_prefix_ub_801  1
    load_0_17_3  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_661  -20
    arc_0_17_4  connected_order_arc_662  -14
    arc_0_17_4  in_degree_803  1
    arc_0_17_4  out_degree_834  1
    arc_0_17_4  original_T_including_depot_unload_868  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_661  1
    load_0_17_4  segment_load_conservation_806  -1
    load_0_17_4  segment_prefix_lb_807  1
    load_0_17_4  segment_prefix_ub_808  1
    load_0_17_4  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_663  -20
    arc_0_17_5  connected_order_arc_664  -14
    arc_0_17_5  in_degree_810  1
    arc_0_17_5  out_degree_834  1
    arc_0_17_5  original_T_including_depot_unload_868  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_663  1
    load_0_17_5  segment_load_conservation_813  -1
    load_0_17_5  segment_prefix_lb_814  1
    load_0_17_5  segment_prefix_ub_815  1
    load_0_17_5  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_665  -20
    arc_0_17_14  connected_order_arc_666  -14
    arc_0_17_14  in_degree_817  1
    arc_0_17_14  out_degree_834  1
    arc_0_17_14  original_T_including_depot_unload_868  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_665  1
    load_0_17_14  free_load_conservation_821  -1
    load_0_17_14  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_667  -20
    arc_0_17_15  connected_order_arc_668  -14
    arc_0_17_15  in_degree_823  1
    arc_0_17_15  out_degree_834  1
    arc_0_17_15  original_T_including_depot_unload_868  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_667  1
    load_0_17_15  free_load_conservation_827  -1
    load_0_17_15  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_669  -20
    arc_0_17_16  connected_order_arc_670  -14
    arc_0_17_16  in_degree_829  1
    arc_0_17_16  out_degree_834  1
    arc_0_17_16  original_T_including_depot_unload_868  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_669  1
    load_0_17_16  free_load_conservation_833  -1
    load_0_17_16  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_671  -20
    arc_0_17_18  connected_order_arc_672  -14
    arc_0_17_18  out_degree_834  1
    arc_0_17_18  in_degree_841  1
    arc_0_17_18  original_T_including_depot_unload_868  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_671  1
    load_0_17_18  free_load_conservation_839  1
    load_0_17_18  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_673  -20
    arc_0_17_19  connected_order_arc_674  -14
    arc_0_17_19  out_degree_834  1
    arc_0_17_19  in_degree_847  1
    arc_0_17_19  original_T_including_depot_unload_868  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_673  1
    load_0_17_19  free_load_conservation_839  1
    load_0_17_19  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_675  -20
    arc_0_17_20  connected_order_arc_676  -14
    arc_0_17_20  out_degree_834  1
    arc_0_17_20  in_degree_853  1
    arc_0_17_20  original_T_including_depot_unload_868  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_675  1
    load_0_17_20  free_load_conservation_839  1
    load_0_17_20  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_677  -20
    arc_0_17_21  connected_order_arc_678  -14
    arc_0_17_21  out_degree_834  1
    arc_0_17_21  in_degree_859  1
    arc_0_17_21  original_T_including_depot_unload_868  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_677  1
    load_0_17_21  free_load_conservation_839  1
    load_0_17_21  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_679  -20
    arc_0_18_0  depot_return_or_bypass_780  1
    arc_0_18_0  out_degree_840  1
    arc_0_18_0  original_T_including_depot_unload_868  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_679  1
    load_0_18_0  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_680  -20
    arc_0_18_1  connected_order_arc_681  -14
    arc_0_18_1  in_degree_782  1
    arc_0_18_1  out_degree_840  1
    arc_0_18_1  original_T_including_depot_unload_868  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_680  1
    load_0_18_1  segment_load_conservation_785  -1
    load_0_18_1  segment_prefix_lb_786  1
    load_0_18_1  segment_prefix_ub_787  1
    load_0_18_1  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_682  -20
    arc_0_18_2  connected_order_arc_683  -14
    arc_0_18_2  in_degree_789  1
    arc_0_18_2  out_degree_840  1
    arc_0_18_2  original_T_including_depot_unload_868  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_682  1
    load_0_18_2  segment_load_conservation_792  -1
    load_0_18_2  segment_prefix_lb_793  1
    load_0_18_2  segment_prefix_ub_794  1
    load_0_18_2  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_684  -20
    arc_0_18_3  connected_order_arc_685  -14
    arc_0_18_3  in_degree_796  1
    arc_0_18_3  out_degree_840  1
    arc_0_18_3  original_T_including_depot_unload_868  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_684  1
    load_0_18_3  segment_load_conservation_799  -1
    load_0_18_3  segment_prefix_lb_800  1
    load_0_18_3  segment_prefix_ub_801  1
    load_0_18_3  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_686  -20
    arc_0_18_4  connected_order_arc_687  -14
    arc_0_18_4  in_degree_803  1
    arc_0_18_4  out_degree_840  1
    arc_0_18_4  original_T_including_depot_unload_868  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_686  1
    load_0_18_4  segment_load_conservation_806  -1
    load_0_18_4  segment_prefix_lb_807  1
    load_0_18_4  segment_prefix_ub_808  1
    load_0_18_4  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_688  -20
    arc_0_18_5  connected_order_arc_689  -14
    arc_0_18_5  in_degree_810  1
    arc_0_18_5  out_degree_840  1
    arc_0_18_5  original_T_including_depot_unload_868  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_688  1
    load_0_18_5  segment_load_conservation_813  -1
    load_0_18_5  segment_prefix_lb_814  1
    load_0_18_5  segment_prefix_ub_815  1
    load_0_18_5  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_690  -20
    arc_0_18_14  connected_order_arc_691  -14
    arc_0_18_14  in_degree_817  1
    arc_0_18_14  out_degree_840  1
    arc_0_18_14  original_T_including_depot_unload_868  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_690  1
    load_0_18_14  free_load_conservation_821  -1
    load_0_18_14  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_692  -20
    arc_0_18_15  connected_order_arc_693  -14
    arc_0_18_15  in_degree_823  1
    arc_0_18_15  out_degree_840  1
    arc_0_18_15  original_T_including_depot_unload_868  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_692  1
    load_0_18_15  free_load_conservation_827  -1
    load_0_18_15  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_694  -20
    arc_0_18_16  connected_order_arc_695  -14
    arc_0_18_16  in_degree_829  1
    arc_0_18_16  out_degree_840  1
    arc_0_18_16  original_T_including_depot_unload_868  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_694  1
    load_0_18_16  free_load_conservation_833  -1
    load_0_18_16  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_696  -20
    arc_0_18_17  connected_order_arc_697  -14
    arc_0_18_17  in_degree_835  1
    arc_0_18_17  out_degree_840  1
    arc_0_18_17  original_T_including_depot_unload_868  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_696  1
    load_0_18_17  free_load_conservation_839  -1
    load_0_18_17  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_698  -20
    arc_0_18_19  connected_order_arc_699  -14
    arc_0_18_19  out_degree_840  1
    arc_0_18_19  in_degree_847  1
    arc_0_18_19  original_T_including_depot_unload_868  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_698  1
    load_0_18_19  free_load_conservation_845  1
    load_0_18_19  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_700  -20
    arc_0_18_20  connected_order_arc_701  -14
    arc_0_18_20  out_degree_840  1
    arc_0_18_20  in_degree_853  1
    arc_0_18_20  original_T_including_depot_unload_868  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_700  1
    load_0_18_20  free_load_conservation_845  1
    load_0_18_20  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_702  -20
    arc_0_18_21  connected_order_arc_703  -14
    arc_0_18_21  out_degree_840  1
    arc_0_18_21  in_degree_859  1
    arc_0_18_21  original_T_including_depot_unload_868  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_702  1
    load_0_18_21  free_load_conservation_845  1
    load_0_18_21  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_704  -20
    arc_0_19_0  depot_return_or_bypass_780  1
    arc_0_19_0  out_degree_846  1
    arc_0_19_0  original_T_including_depot_unload_868  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_704  1
    load_0_19_0  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_705  -20
    arc_0_19_1  connected_order_arc_706  -14
    arc_0_19_1  in_degree_782  1
    arc_0_19_1  out_degree_846  1
    arc_0_19_1  original_T_including_depot_unload_868  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_705  1
    load_0_19_1  segment_load_conservation_785  -1
    load_0_19_1  segment_prefix_lb_786  1
    load_0_19_1  segment_prefix_ub_787  1
    load_0_19_1  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_707  -20
    arc_0_19_2  connected_order_arc_708  -14
    arc_0_19_2  in_degree_789  1
    arc_0_19_2  out_degree_846  1
    arc_0_19_2  original_T_including_depot_unload_868  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_707  1
    load_0_19_2  segment_load_conservation_792  -1
    load_0_19_2  segment_prefix_lb_793  1
    load_0_19_2  segment_prefix_ub_794  1
    load_0_19_2  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_709  -20
    arc_0_19_3  connected_order_arc_710  -14
    arc_0_19_3  in_degree_796  1
    arc_0_19_3  out_degree_846  1
    arc_0_19_3  original_T_including_depot_unload_868  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_709  1
    load_0_19_3  segment_load_conservation_799  -1
    load_0_19_3  segment_prefix_lb_800  1
    load_0_19_3  segment_prefix_ub_801  1
    load_0_19_3  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_711  -20
    arc_0_19_4  connected_order_arc_712  -14
    arc_0_19_4  in_degree_803  1
    arc_0_19_4  out_degree_846  1
    arc_0_19_4  original_T_including_depot_unload_868  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_711  1
    load_0_19_4  segment_load_conservation_806  -1
    load_0_19_4  segment_prefix_lb_807  1
    load_0_19_4  segment_prefix_ub_808  1
    load_0_19_4  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_713  -20
    arc_0_19_5  connected_order_arc_714  -14
    arc_0_19_5  in_degree_810  1
    arc_0_19_5  out_degree_846  1
    arc_0_19_5  original_T_including_depot_unload_868  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_713  1
    load_0_19_5  segment_load_conservation_813  -1
    load_0_19_5  segment_prefix_lb_814  1
    load_0_19_5  segment_prefix_ub_815  1
    load_0_19_5  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_715  -20
    arc_0_19_14  connected_order_arc_716  -14
    arc_0_19_14  in_degree_817  1
    arc_0_19_14  out_degree_846  1
    arc_0_19_14  original_T_including_depot_unload_868  7.6789230776331749e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_715  1
    load_0_19_14  free_load_conservation_821  -1
    load_0_19_14  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_717  -20
    arc_0_19_15  connected_order_arc_718  -14
    arc_0_19_15  in_degree_823  1
    arc_0_19_15  out_degree_846  1
    arc_0_19_15  original_T_including_depot_unload_868  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_717  1
    load_0_19_15  free_load_conservation_827  -1
    load_0_19_15  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_719  -20
    arc_0_19_16  connected_order_arc_720  -14
    arc_0_19_16  in_degree_829  1
    arc_0_19_16  out_degree_846  1
    arc_0_19_16  original_T_including_depot_unload_868  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_719  1
    load_0_19_16  free_load_conservation_833  -1
    load_0_19_16  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_721  -20
    arc_0_19_17  connected_order_arc_722  -14
    arc_0_19_17  in_degree_835  1
    arc_0_19_17  out_degree_846  1
    arc_0_19_17  original_T_including_depot_unload_868  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_721  1
    load_0_19_17  free_load_conservation_839  -1
    load_0_19_17  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_723  -20
    arc_0_19_18  connected_order_arc_724  -14
    arc_0_19_18  in_degree_841  1
    arc_0_19_18  out_degree_846  1
    arc_0_19_18  original_T_including_depot_unload_868  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_723  1
    load_0_19_18  free_load_conservation_845  -1
    load_0_19_18  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_725  -20
    arc_0_19_20  connected_order_arc_726  -14
    arc_0_19_20  out_degree_846  1
    arc_0_19_20  in_degree_853  1
    arc_0_19_20  original_T_including_depot_unload_868  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_725  1
    load_0_19_20  free_load_conservation_851  1
    load_0_19_20  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_727  -20
    arc_0_19_21  connected_order_arc_728  -14
    arc_0_19_21  out_degree_846  1
    arc_0_19_21  in_degree_859  1
    arc_0_19_21  original_T_including_depot_unload_868  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_727  1
    load_0_19_21  free_load_conservation_851  1
    load_0_19_21  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_729  -20
    arc_0_20_0  depot_return_or_bypass_780  1
    arc_0_20_0  out_degree_852  1
    arc_0_20_0  original_T_including_depot_unload_868  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_729  1
    load_0_20_0  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_730  -20
    arc_0_20_1  connected_order_arc_731  -14
    arc_0_20_1  in_degree_782  1
    arc_0_20_1  out_degree_852  1
    arc_0_20_1  original_T_including_depot_unload_868  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_730  1
    load_0_20_1  segment_load_conservation_785  -1
    load_0_20_1  segment_prefix_lb_786  1
    load_0_20_1  segment_prefix_ub_787  1
    load_0_20_1  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_732  -20
    arc_0_20_2  connected_order_arc_733  -14
    arc_0_20_2  in_degree_789  1
    arc_0_20_2  out_degree_852  1
    arc_0_20_2  original_T_including_depot_unload_868  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_732  1
    load_0_20_2  segment_load_conservation_792  -1
    load_0_20_2  segment_prefix_lb_793  1
    load_0_20_2  segment_prefix_ub_794  1
    load_0_20_2  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_734  -20
    arc_0_20_3  connected_order_arc_735  -14
    arc_0_20_3  in_degree_796  1
    arc_0_20_3  out_degree_852  1
    arc_0_20_3  original_T_including_depot_unload_868  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_734  1
    load_0_20_3  segment_load_conservation_799  -1
    load_0_20_3  segment_prefix_lb_800  1
    load_0_20_3  segment_prefix_ub_801  1
    load_0_20_3  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_736  -20
    arc_0_20_4  connected_order_arc_737  -14
    arc_0_20_4  in_degree_803  1
    arc_0_20_4  out_degree_852  1
    arc_0_20_4  original_T_including_depot_unload_868  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_736  1
    load_0_20_4  segment_load_conservation_806  -1
    load_0_20_4  segment_prefix_lb_807  1
    load_0_20_4  segment_prefix_ub_808  1
    load_0_20_4  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_738  -20
    arc_0_20_5  connected_order_arc_739  -14
    arc_0_20_5  in_degree_810  1
    arc_0_20_5  out_degree_852  1
    arc_0_20_5  original_T_including_depot_unload_868  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_738  1
    load_0_20_5  segment_load_conservation_813  -1
    load_0_20_5  segment_prefix_lb_814  1
    load_0_20_5  segment_prefix_ub_815  1
    load_0_20_5  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_740  -20
    arc_0_20_14  connected_order_arc_741  -14
    arc_0_20_14  in_degree_817  1
    arc_0_20_14  out_degree_852  1
    arc_0_20_14  original_T_including_depot_unload_868  1.4688211749637876e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_740  1
    load_0_20_14  free_load_conservation_821  -1
    load_0_20_14  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_742  -20
    arc_0_20_15  connected_order_arc_743  -14
    arc_0_20_15  in_degree_823  1
    arc_0_20_15  out_degree_852  1
    arc_0_20_15  original_T_including_depot_unload_868  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_742  1
    load_0_20_15  free_load_conservation_827  -1
    load_0_20_15  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_744  -20
    arc_0_20_16  connected_order_arc_745  -14
    arc_0_20_16  in_degree_829  1
    arc_0_20_16  out_degree_852  1
    arc_0_20_16  original_T_including_depot_unload_868  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_744  1
    load_0_20_16  free_load_conservation_833  -1
    load_0_20_16  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_746  -20
    arc_0_20_17  connected_order_arc_747  -14
    arc_0_20_17  in_degree_835  1
    arc_0_20_17  out_degree_852  1
    arc_0_20_17  original_T_including_depot_unload_868  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_746  1
    load_0_20_17  free_load_conservation_839  -1
    load_0_20_17  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_748  -20
    arc_0_20_18  connected_order_arc_749  -14
    arc_0_20_18  in_degree_841  1
    arc_0_20_18  out_degree_852  1
    arc_0_20_18  original_T_including_depot_unload_868  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_748  1
    load_0_20_18  free_load_conservation_845  -1
    load_0_20_18  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_750  -20
    arc_0_20_19  connected_order_arc_751  -14
    arc_0_20_19  in_degree_847  1
    arc_0_20_19  out_degree_852  1
    arc_0_20_19  original_T_including_depot_unload_868  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_750  1
    load_0_20_19  free_load_conservation_851  -1
    load_0_20_19  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_752  -20
    arc_0_20_21  connected_order_arc_753  -14
    arc_0_20_21  out_degree_852  1
    arc_0_20_21  in_degree_859  1
    arc_0_20_21  original_T_including_depot_unload_868  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_752  1
    load_0_20_21  free_load_conservation_857  1
    load_0_20_21  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_754  -20
    arc_0_21_0  depot_return_or_bypass_780  1
    arc_0_21_0  out_degree_858  1
    arc_0_21_0  original_T_including_depot_unload_868  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_754  1
    load_0_21_0  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_755  -20
    arc_0_21_1  connected_order_arc_756  -14
    arc_0_21_1  in_degree_782  1
    arc_0_21_1  out_degree_858  1
    arc_0_21_1  original_T_including_depot_unload_868  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_755  1
    load_0_21_1  segment_load_conservation_785  -1
    load_0_21_1  segment_prefix_lb_786  1
    load_0_21_1  segment_prefix_ub_787  1
    load_0_21_1  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_757  -20
    arc_0_21_2  connected_order_arc_758  -14
    arc_0_21_2  in_degree_789  1
    arc_0_21_2  out_degree_858  1
    arc_0_21_2  original_T_including_depot_unload_868  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_757  1
    load_0_21_2  segment_load_conservation_792  -1
    load_0_21_2  segment_prefix_lb_793  1
    load_0_21_2  segment_prefix_ub_794  1
    load_0_21_2  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_759  -20
    arc_0_21_3  connected_order_arc_760  -14
    arc_0_21_3  in_degree_796  1
    arc_0_21_3  out_degree_858  1
    arc_0_21_3  original_T_including_depot_unload_868  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_759  1
    load_0_21_3  segment_load_conservation_799  -1
    load_0_21_3  segment_prefix_lb_800  1
    load_0_21_3  segment_prefix_ub_801  1
    load_0_21_3  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_761  -20
    arc_0_21_4  connected_order_arc_762  -14
    arc_0_21_4  in_degree_803  1
    arc_0_21_4  out_degree_858  1
    arc_0_21_4  original_T_including_depot_unload_868  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_761  1
    load_0_21_4  segment_load_conservation_806  -1
    load_0_21_4  segment_prefix_lb_807  1
    load_0_21_4  segment_prefix_ub_808  1
    load_0_21_4  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_763  -20
    arc_0_21_5  connected_order_arc_764  -14
    arc_0_21_5  in_degree_810  1
    arc_0_21_5  out_degree_858  1
    arc_0_21_5  original_T_including_depot_unload_868  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_763  1
    load_0_21_5  segment_load_conservation_813  -1
    load_0_21_5  segment_prefix_lb_814  1
    load_0_21_5  segment_prefix_ub_815  1
    load_0_21_5  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_14  arc_capacity_765  -20
    arc_0_21_14  connected_order_arc_766  -14
    arc_0_21_14  in_degree_817  1
    arc_0_21_14  out_degree_858  1
    arc_0_21_14  original_T_including_depot_unload_868  8.2066682484686987e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_14  arc_capacity_765  1
    load_0_21_14  free_load_conservation_821  -1
    load_0_21_14  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_767  -20
    arc_0_21_15  connected_order_arc_768  -14
    arc_0_21_15  in_degree_823  1
    arc_0_21_15  out_degree_858  1
    arc_0_21_15  original_T_including_depot_unload_868  8.6958069185371107e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_767  1
    load_0_21_15  free_load_conservation_827  -1
    load_0_21_15  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_769  -20
    arc_0_21_16  connected_order_arc_770  -14
    arc_0_21_16  in_degree_829  1
    arc_0_21_16  out_degree_858  1
    arc_0_21_16  original_T_including_depot_unload_868  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_769  1
    load_0_21_16  free_load_conservation_833  -1
    load_0_21_16  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_771  -20
    arc_0_21_17  connected_order_arc_772  -14
    arc_0_21_17  in_degree_835  1
    arc_0_21_17  out_degree_858  1
    arc_0_21_17  original_T_including_depot_unload_868  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_771  1
    load_0_21_17  free_load_conservation_839  -1
    load_0_21_17  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_773  -20
    arc_0_21_18  connected_order_arc_774  -14
    arc_0_21_18  in_degree_841  1
    arc_0_21_18  out_degree_858  1
    arc_0_21_18  original_T_including_depot_unload_868  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_773  1
    load_0_21_18  free_load_conservation_845  -1
    load_0_21_18  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_775  -20
    arc_0_21_19  connected_order_arc_776  -14
    arc_0_21_19  in_degree_847  1
    arc_0_21_19  out_degree_858  1
    arc_0_21_19  original_T_including_depot_unload_868  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_775  1
    load_0_21_19  free_load_conservation_851  -1
    load_0_21_19  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_777  -20
    arc_0_21_20  connected_order_arc_778  -14
    arc_0_21_20  in_degree_853  1
    arc_0_21_20  out_degree_858  1
    arc_0_21_20  original_T_including_depot_unload_868  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_777  1
    load_0_21_20  free_load_conservation_857  -1
    load_0_21_20  free_load_conservation_863  1
    visit_1_6  out_degree_1160  -1
    visit_1_6  in_degree_1161  -1
    visit_1_6  order_active_lb_1162  -1
    visit_1_6  order_active_ub_1163  -12
    order_1_6  connected_order_arc_884  -1
    order_1_6  connected_order_arc_886  -1
    order_1_6  connected_order_arc_888  -1
    order_1_6  connected_order_arc_890  -1
    order_1_6  connected_order_arc_892  -1
    order_1_6  connected_order_arc_894  -1
    order_1_6  connected_order_arc_896  -1
    order_1_6  connected_order_arc_898  -1
    order_1_6  connected_order_arc_900  -1
    order_1_6  connected_order_arc_902  -1
    order_1_6  connected_order_arc_904  -1
    order_1_6  connected_order_arc_907  1
    order_1_6  connected_order_arc_930  1
    order_1_6  connected_order_arc_953  1
    order_1_6  connected_order_arc_976  1
    order_1_6  connected_order_arc_999  1
    order_1_6  connected_order_arc_1022  1
    order_1_6  connected_order_arc_1045  1
    order_1_6  connected_order_arc_1068  1
    order_1_6  connected_order_arc_1091  1
    order_1_6  connected_order_arc_1114  1
    order_1_6  connected_order_arc_1137  1
    order_1_6  order_active_lb_1162  1
    order_1_6  order_active_ub_1163  1
    order_1_6  fixed_segment_relative_order_1236  -1
    visit_1_7  out_degree_1167  -1
    visit_1_7  in_degree_1168  -1
    visit_1_7  order_active_lb_1169  -1
    visit_1_7  order_active_ub_1170  -12
    order_1_7  connected_order_arc_884  1
    order_1_7  connected_order_arc_907  -1
    order_1_7  connected_order_arc_909  -1
    order_1_7  connected_order_arc_911  -1
    order_1_7  connected_order_arc_913  -1
    order_1_7  connected_order_arc_915  -1
    order_1_7  connected_order_arc_917  -1
    order_1_7  connected_order_arc_919  -1
    order_1_7  connected_order_arc_921  -1
    order_1_7  connected_order_arc_923  -1
    order_1_7  connected_order_arc_925  -1
    order_1_7  connected_order_arc_927  -1
    order_1_7  connected_order_arc_932  1
    order_1_7  connected_order_arc_955  1
    order_1_7  connected_order_arc_978  1
    order_1_7  connected_order_arc_1001  1
    order_1_7  connected_order_arc_1024  1
    order_1_7  connected_order_arc_1047  1
    order_1_7  connected_order_arc_1070  1
    order_1_7  connected_order_arc_1093  1
    order_1_7  connected_order_arc_1116  1
    order_1_7  connected_order_arc_1139  1
    order_1_7  order_active_lb_1169  1
    order_1_7  order_active_ub_1170  1
    order_1_7  fixed_segment_relative_order_1236  1
    order_1_7  fixed_segment_relative_order_1237  -1
    visit_1_8  out_degree_1174  -1
    visit_1_8  in_degree_1175  -1
    visit_1_8  order_active_lb_1176  -1
    visit_1_8  order_active_ub_1177  -12
    order_1_8  connected_order_arc_886  1
    order_1_8  connected_order_arc_909  1
    order_1_8  connected_order_arc_930  -1
    order_1_8  connected_order_arc_932  -1
    order_1_8  connected_order_arc_934  -1
    order_1_8  connected_order_arc_936  -1
    order_1_8  connected_order_arc_938  -1
    order_1_8  connected_order_arc_940  -1
    order_1_8  connected_order_arc_942  -1
    order_1_8  connected_order_arc_944  -1
    order_1_8  connected_order_arc_946  -1
    order_1_8  connected_order_arc_948  -1
    order_1_8  connected_order_arc_950  -1
    order_1_8  connected_order_arc_957  1
    order_1_8  connected_order_arc_980  1
    order_1_8  connected_order_arc_1003  1
    order_1_8  connected_order_arc_1026  1
    order_1_8  connected_order_arc_1049  1
    order_1_8  connected_order_arc_1072  1
    order_1_8  connected_order_arc_1095  1
    order_1_8  connected_order_arc_1118  1
    order_1_8  connected_order_arc_1141  1
    order_1_8  order_active_lb_1176  1
    order_1_8  order_active_ub_1177  1
    order_1_8  fixed_segment_relative_order_1237  1
    order_1_8  fixed_segment_relative_order_1238  -1
    visit_1_9  out_degree_1181  -1
    visit_1_9  in_degree_1182  -1
    visit_1_9  order_active_lb_1183  -1
    visit_1_9  order_active_ub_1184  -12
    order_1_9  connected_order_arc_888  1
    order_1_9  connected_order_arc_911  1
    order_1_9  connected_order_arc_934  1
    order_1_9  connected_order_arc_953  -1
    order_1_9  connected_order_arc_955  -1
    order_1_9  connected_order_arc_957  -1
    order_1_9  connected_order_arc_959  -1
    order_1_9  connected_order_arc_961  -1
    order_1_9  connected_order_arc_963  -1
    order_1_9  connected_order_arc_965  -1
    order_1_9  connected_order_arc_967  -1
    order_1_9  connected_order_arc_969  -1
    order_1_9  connected_order_arc_971  -1
    order_1_9  connected_order_arc_973  -1
    order_1_9  connected_order_arc_982  1
    order_1_9  connected_order_arc_1005  1
    order_1_9  connected_order_arc_1028  1
    order_1_9  connected_order_arc_1051  1
    order_1_9  connected_order_arc_1074  1
    order_1_9  connected_order_arc_1097  1
    order_1_9  connected_order_arc_1120  1
    order_1_9  connected_order_arc_1143  1
    order_1_9  order_active_lb_1183  1
    order_1_9  order_active_ub_1184  1
    order_1_9  fixed_segment_relative_order_1238  1
    visit_1_14  out_degree_1188  -1
    visit_1_14  in_degree_1189  -1
    visit_1_14  order_active_lb_1190  -1
    visit_1_14  order_active_ub_1191  -12
    visit_1_14  service_visit_def_1192  -1
    order_1_14  connected_order_arc_890  1
    order_1_14  connected_order_arc_913  1
    order_1_14  connected_order_arc_936  1
    order_1_14  connected_order_arc_959  1
    order_1_14  connected_order_arc_976  -1
    order_1_14  connected_order_arc_978  -1
    order_1_14  connected_order_arc_980  -1
    order_1_14  connected_order_arc_982  -1
    order_1_14  connected_order_arc_984  -1
    order_1_14  connected_order_arc_986  -1
    order_1_14  connected_order_arc_988  -1
    order_1_14  connected_order_arc_990  -1
    order_1_14  connected_order_arc_992  -1
    order_1_14  connected_order_arc_994  -1
    order_1_14  connected_order_arc_996  -1
    order_1_14  connected_order_arc_1007  1
    order_1_14  connected_order_arc_1030  1
    order_1_14  connected_order_arc_1053  1
    order_1_14  connected_order_arc_1076  1
    order_1_14  connected_order_arc_1099  1
    order_1_14  connected_order_arc_1122  1
    order_1_14  connected_order_arc_1145  1
    order_1_14  order_active_lb_1190  1
    order_1_14  order_active_ub_1191  1
    visit_1_15  out_degree_1194  -1
    visit_1_15  in_degree_1195  -1
    visit_1_15  order_active_lb_1196  -1
    visit_1_15  order_active_ub_1197  -12
    visit_1_15  service_visit_def_1198  -1
    order_1_15  connected_order_arc_892  1
    order_1_15  connected_order_arc_915  1
    order_1_15  connected_order_arc_938  1
    order_1_15  connected_order_arc_961  1
    order_1_15  connected_order_arc_984  1
    order_1_15  connected_order_arc_999  -1
    order_1_15  connected_order_arc_1001  -1
    order_1_15  connected_order_arc_1003  -1
    order_1_15  connected_order_arc_1005  -1
    order_1_15  connected_order_arc_1007  -1
    order_1_15  connected_order_arc_1009  -1
    order_1_15  connected_order_arc_1011  -1
    order_1_15  connected_order_arc_1013  -1
    order_1_15  connected_order_arc_1015  -1
    order_1_15  connected_order_arc_1017  -1
    order_1_15  connected_order_arc_1019  -1
    order_1_15  connected_order_arc_1032  1
    order_1_15  connected_order_arc_1055  1
    order_1_15  connected_order_arc_1078  1
    order_1_15  connected_order_arc_1101  1
    order_1_15  connected_order_arc_1124  1
    order_1_15  connected_order_arc_1147  1
    order_1_15  order_active_lb_1196  1
    order_1_15  order_active_ub_1197  1
    visit_1_16  out_degree_1200  -1
    visit_1_16  in_degree_1201  -1
    visit_1_16  order_active_lb_1202  -1
    visit_1_16  order_active_ub_1203  -12
    visit_1_16  service_visit_def_1204  -1
    order_1_16  connected_order_arc_894  1
    order_1_16  connected_order_arc_917  1
    order_1_16  connected_order_arc_940  1
    order_1_16  connected_order_arc_963  1
    order_1_16  connected_order_arc_986  1
    order_1_16  connected_order_arc_1009  1
    order_1_16  connected_order_arc_1022  -1
    order_1_16  connected_order_arc_1024  -1
    order_1_16  connected_order_arc_1026  -1
    order_1_16  connected_order_arc_1028  -1
    order_1_16  connected_order_arc_1030  -1
    order_1_16  connected_order_arc_1032  -1
    order_1_16  connected_order_arc_1034  -1
    order_1_16  connected_order_arc_1036  -1
    order_1_16  connected_order_arc_1038  -1
    order_1_16  connected_order_arc_1040  -1
    order_1_16  connected_order_arc_1042  -1
    order_1_16  connected_order_arc_1057  1
    order_1_16  connected_order_arc_1080  1
    order_1_16  connected_order_arc_1103  1
    order_1_16  connected_order_arc_1126  1
    order_1_16  connected_order_arc_1149  1
    order_1_16  order_active_lb_1202  1
    order_1_16  order_active_ub_1203  1
    visit_1_17  out_degree_1206  -1
    visit_1_17  in_degree_1207  -1
    visit_1_17  order_active_lb_1208  -1
    visit_1_17  order_active_ub_1209  -12
    visit_1_17  service_visit_def_1210  -1
    order_1_17  connected_order_arc_896  1
    order_1_17  connected_order_arc_919  1
    order_1_17  connected_order_arc_942  1
    order_1_17  connected_order_arc_965  1
    order_1_17  connected_order_arc_988  1
    order_1_17  connected_order_arc_1011  1
    order_1_17  connected_order_arc_1034  1
    order_1_17  connected_order_arc_1045  -1
    order_1_17  connected_order_arc_1047  -1
    order_1_17  connected_order_arc_1049  -1
    order_1_17  connected_order_arc_1051  -1
    order_1_17  connected_order_arc_1053  -1
    order_1_17  connected_order_arc_1055  -1
    order_1_17  connected_order_arc_1057  -1
    order_1_17  connected_order_arc_1059  -1
    order_1_17  connected_order_arc_1061  -1
    order_1_17  connected_order_arc_1063  -1
    order_1_17  connected_order_arc_1065  -1
    order_1_17  connected_order_arc_1082  1
    order_1_17  connected_order_arc_1105  1
    order_1_17  connected_order_arc_1128  1
    order_1_17  connected_order_arc_1151  1
    order_1_17  order_active_lb_1208  1
    order_1_17  order_active_ub_1209  1
    visit_1_18  out_degree_1212  -1
    visit_1_18  in_degree_1213  -1
    visit_1_18  order_active_lb_1214  -1
    visit_1_18  order_active_ub_1215  -12
    visit_1_18  service_visit_def_1216  -1
    order_1_18  connected_order_arc_898  1
    order_1_18  connected_order_arc_921  1
    order_1_18  connected_order_arc_944  1
    order_1_18  connected_order_arc_967  1
    order_1_18  connected_order_arc_990  1
    order_1_18  connected_order_arc_1013  1
    order_1_18  connected_order_arc_1036  1
    order_1_18  connected_order_arc_1059  1
    order_1_18  connected_order_arc_1068  -1
    order_1_18  connected_order_arc_1070  -1
    order_1_18  connected_order_arc_1072  -1
    order_1_18  connected_order_arc_1074  -1
    order_1_18  connected_order_arc_1076  -1
    order_1_18  connected_order_arc_1078  -1
    order_1_18  connected_order_arc_1080  -1
    order_1_18  connected_order_arc_1082  -1
    order_1_18  connected_order_arc_1084  -1
    order_1_18  connected_order_arc_1086  -1
    order_1_18  connected_order_arc_1088  -1
    order_1_18  connected_order_arc_1107  1
    order_1_18  connected_order_arc_1130  1
    order_1_18  connected_order_arc_1153  1
    order_1_18  order_active_lb_1214  1
    order_1_18  order_active_ub_1215  1
    visit_1_19  out_degree_1218  -1
    visit_1_19  in_degree_1219  -1
    visit_1_19  order_active_lb_1220  -1
    visit_1_19  order_active_ub_1221  -12
    visit_1_19  service_visit_def_1222  -1
    order_1_19  connected_order_arc_900  1
    order_1_19  connected_order_arc_923  1
    order_1_19  connected_order_arc_946  1
    order_1_19  connected_order_arc_969  1
    order_1_19  connected_order_arc_992  1
    order_1_19  connected_order_arc_1015  1
    order_1_19  connected_order_arc_1038  1
    order_1_19  connected_order_arc_1061  1
    order_1_19  connected_order_arc_1084  1
    order_1_19  connected_order_arc_1091  -1
    order_1_19  connected_order_arc_1093  -1
    order_1_19  connected_order_arc_1095  -1
    order_1_19  connected_order_arc_1097  -1
    order_1_19  connected_order_arc_1099  -1
    order_1_19  connected_order_arc_1101  -1
    order_1_19  connected_order_arc_1103  -1
    order_1_19  connected_order_arc_1105  -1
    order_1_19  connected_order_arc_1107  -1
    order_1_19  connected_order_arc_1109  -1
    order_1_19  connected_order_arc_1111  -1
    order_1_19  connected_order_arc_1132  1
    order_1_19  connected_order_arc_1155  1
    order_1_19  order_active_lb_1220  1
    order_1_19  order_active_ub_1221  1
    visit_1_20  out_degree_1224  -1
    visit_1_20  in_degree_1225  -1
    visit_1_20  order_active_lb_1226  -1
    visit_1_20  order_active_ub_1227  -12
    visit_1_20  service_visit_def_1228  -1
    order_1_20  connected_order_arc_902  1
    order_1_20  connected_order_arc_925  1
    order_1_20  connected_order_arc_948  1
    order_1_20  connected_order_arc_971  1
    order_1_20  connected_order_arc_994  1
    order_1_20  connected_order_arc_1017  1
    order_1_20  connected_order_arc_1040  1
    order_1_20  connected_order_arc_1063  1
    order_1_20  connected_order_arc_1086  1
    order_1_20  connected_order_arc_1109  1
    order_1_20  connected_order_arc_1114  -1
    order_1_20  connected_order_arc_1116  -1
    order_1_20  connected_order_arc_1118  -1
    order_1_20  connected_order_arc_1120  -1
    order_1_20  connected_order_arc_1122  -1
    order_1_20  connected_order_arc_1124  -1
    order_1_20  connected_order_arc_1126  -1
    order_1_20  connected_order_arc_1128  -1
    order_1_20  connected_order_arc_1130  -1
    order_1_20  connected_order_arc_1132  -1
    order_1_20  connected_order_arc_1134  -1
    order_1_20  connected_order_arc_1157  1
    order_1_20  order_active_lb_1226  1
    order_1_20  order_active_ub_1227  1
    visit_1_21  out_degree_1230  -1
    visit_1_21  in_degree_1231  -1
    visit_1_21  order_active_lb_1232  -1
    visit_1_21  order_active_ub_1233  -12
    visit_1_21  service_visit_def_1234  -1
    order_1_21  connected_order_arc_904  1
    order_1_21  connected_order_arc_927  1
    order_1_21  connected_order_arc_950  1
    order_1_21  connected_order_arc_973  1
    order_1_21  connected_order_arc_996  1
    order_1_21  connected_order_arc_1019  1
    order_1_21  connected_order_arc_1042  1
    order_1_21  connected_order_arc_1065  1
    order_1_21  connected_order_arc_1088  1
    order_1_21  connected_order_arc_1111  1
    order_1_21  connected_order_arc_1134  1
    order_1_21  connected_order_arc_1137  -1
    order_1_21  connected_order_arc_1139  -1
    order_1_21  connected_order_arc_1141  -1
    order_1_21  connected_order_arc_1143  -1
    order_1_21  connected_order_arc_1145  -1
    order_1_21  connected_order_arc_1147  -1
    order_1_21  connected_order_arc_1149  -1
    order_1_21  connected_order_arc_1151  -1
    order_1_21  connected_order_arc_1153  -1
    order_1_21  connected_order_arc_1155  -1
    order_1_21  connected_order_arc_1157  -1
    order_1_21  order_active_lb_1232  1
    order_1_21  order_active_ub_1233  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_869  -25
    arc_1_0_0  depot_departure_or_bypass_1158  1
    arc_1_0_0  depot_return_or_bypass_1159  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_870  -25
    arc_1_0_6  depot_departure_or_bypass_1158  1
    arc_1_0_6  in_degree_1161  1
    arc_1_0_6  original_T_including_depot_unload_1239  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_870  1
    load_1_0_6  segment_load_conservation_1164  -1
    load_1_0_6  segment_prefix_lb_1165  1
    load_1_0_6  segment_prefix_ub_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_871  -25
    arc_1_0_7  depot_departure_or_bypass_1158  1
    arc_1_0_7  in_degree_1168  1
    arc_1_0_7  original_T_including_depot_unload_1239  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_871  1
    load_1_0_7  segment_load_conservation_1171  -1
    load_1_0_7  segment_prefix_lb_1172  1
    load_1_0_7  segment_prefix_ub_1173  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_872  -25
    arc_1_0_8  depot_departure_or_bypass_1158  1
    arc_1_0_8  in_degree_1175  1
    arc_1_0_8  original_T_including_depot_unload_1239  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_872  1
    load_1_0_8  segment_load_conservation_1178  -1
    load_1_0_8  segment_prefix_lb_1179  1
    load_1_0_8  segment_prefix_ub_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_873  -25
    arc_1_0_9  depot_departure_or_bypass_1158  1
    arc_1_0_9  in_degree_1182  1
    arc_1_0_9  original_T_including_depot_unload_1239  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_873  1
    load_1_0_9  segment_load_conservation_1185  -1
    load_1_0_9  segment_prefix_lb_1186  1
    load_1_0_9  segment_prefix_ub_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_874  -25
    arc_1_0_14  depot_departure_or_bypass_1158  1
    arc_1_0_14  in_degree_1189  1
    arc_1_0_14  original_T_including_depot_unload_1239  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_874  1
    load_1_0_14  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_875  -25
    arc_1_0_15  depot_departure_or_bypass_1158  1
    arc_1_0_15  in_degree_1195  1
    arc_1_0_15  original_T_including_depot_unload_1239  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_875  1
    load_1_0_15  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_876  -25
    arc_1_0_16  depot_departure_or_bypass_1158  1
    arc_1_0_16  in_degree_1201  1
    arc_1_0_16  original_T_including_depot_unload_1239  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_876  1
    load_1_0_16  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_877  -25
    arc_1_0_17  depot_departure_or_bypass_1158  1
    arc_1_0_17  in_degree_1207  1
    arc_1_0_17  original_T_including_depot_unload_1239  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_877  1
    load_1_0_17  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_878  -25
    arc_1_0_18  depot_departure_or_bypass_1158  1
    arc_1_0_18  in_degree_1213  1
    arc_1_0_18  original_T_including_depot_unload_1239  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_878  1
    load_1_0_18  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_879  -25
    arc_1_0_19  depot_departure_or_bypass_1158  1
    arc_1_0_19  in_degree_1219  1
    arc_1_0_19  original_T_including_depot_unload_1239  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_879  1
    load_1_0_19  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_880  -25
    arc_1_0_20  depot_departure_or_bypass_1158  1
    arc_1_0_20  in_degree_1225  1
    arc_1_0_20  original_T_including_depot_unload_1239  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_880  1
    load_1_0_20  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_881  -25
    arc_1_0_21  depot_departure_or_bypass_1158  1
    arc_1_0_21  in_degree_1231  1
    arc_1_0_21  original_T_including_depot_unload_1239  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_881  1
    load_1_0_21  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_882  -25
    arc_1_6_0  depot_return_or_bypass_1159  1
    arc_1_6_0  out_degree_1160  1
    arc_1_6_0  original_T_including_depot_unload_1239  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_882  1
    load_1_6_0  segment_load_conservation_1164  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_883  -25
    arc_1_6_7  connected_order_arc_884  -13
    arc_1_6_7  out_degree_1160  1
    arc_1_6_7  in_degree_1168  1
    arc_1_6_7  original_T_including_depot_unload_1239  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_883  1
    load_1_6_7  segment_load_conservation_1164  1
    load_1_6_7  segment_load_conservation_1171  -1
    load_1_6_7  segment_prefix_lb_1172  1
    load_1_6_7  segment_prefix_ub_1173  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_885  -25
    arc_1_6_8  connected_order_arc_886  -13
    arc_1_6_8  out_degree_1160  1
    arc_1_6_8  in_degree_1175  1
    arc_1_6_8  original_T_including_depot_unload_1239  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_885  1
    load_1_6_8  segment_load_conservation_1164  1
    load_1_6_8  segment_load_conservation_1178  -1
    load_1_6_8  segment_prefix_lb_1179  1
    load_1_6_8  segment_prefix_ub_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_887  -25
    arc_1_6_9  connected_order_arc_888  -13
    arc_1_6_9  out_degree_1160  1
    arc_1_6_9  in_degree_1182  1
    arc_1_6_9  original_T_including_depot_unload_1239  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_887  1
    load_1_6_9  segment_load_conservation_1164  1
    load_1_6_9  segment_load_conservation_1185  -1
    load_1_6_9  segment_prefix_lb_1186  1
    load_1_6_9  segment_prefix_ub_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_889  -25
    arc_1_6_14  connected_order_arc_890  -13
    arc_1_6_14  out_degree_1160  1
    arc_1_6_14  in_degree_1189  1
    arc_1_6_14  original_T_including_depot_unload_1239  2.3158028257381197e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_889  1
    load_1_6_14  segment_load_conservation_1164  1
    load_1_6_14  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_891  -25
    arc_1_6_15  connected_order_arc_892  -13
    arc_1_6_15  out_degree_1160  1
    arc_1_6_15  in_degree_1195  1
    arc_1_6_15  original_T_including_depot_unload_1239  2.1372888672431886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_891  1
    load_1_6_15  segment_load_conservation_1164  1
    load_1_6_15  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_893  -25
    arc_1_6_16  connected_order_arc_894  -13
    arc_1_6_16  out_degree_1160  1
    arc_1_6_16  in_degree_1201  1
    arc_1_6_16  original_T_including_depot_unload_1239  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_893  1
    load_1_6_16  segment_load_conservation_1164  1
    load_1_6_16  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_895  -25
    arc_1_6_17  connected_order_arc_896  -13
    arc_1_6_17  out_degree_1160  1
    arc_1_6_17  in_degree_1207  1
    arc_1_6_17  original_T_including_depot_unload_1239  1.8269270746185791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_895  1
    load_1_6_17  segment_load_conservation_1164  1
    load_1_6_17  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_897  -25
    arc_1_6_18  connected_order_arc_898  -13
    arc_1_6_18  out_degree_1160  1
    arc_1_6_18  in_degree_1213  1
    arc_1_6_18  original_T_including_depot_unload_1239  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_897  1
    load_1_6_18  segment_load_conservation_1164  1
    load_1_6_18  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_899  -25
    arc_1_6_19  connected_order_arc_900  -13
    arc_1_6_19  out_degree_1160  1
    arc_1_6_19  in_degree_1219  1
    arc_1_6_19  original_T_including_depot_unload_1239  1.5546511874277910e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_899  1
    load_1_6_19  segment_load_conservation_1164  1
    load_1_6_19  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_901  -25
    arc_1_6_20  connected_order_arc_902  -13
    arc_1_6_20  out_degree_1160  1
    arc_1_6_20  in_degree_1225  1
    arc_1_6_20  original_T_including_depot_unload_1239  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_901  1
    load_1_6_20  segment_load_conservation_1164  1
    load_1_6_20  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_21  arc_capacity_903  -25
    arc_1_6_21  connected_order_arc_904  -13
    arc_1_6_21  out_degree_1160  1
    arc_1_6_21  in_degree_1231  1
    arc_1_6_21  original_T_including_depot_unload_1239  1.5437191441012344e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_21  arc_capacity_903  1
    load_1_6_21  segment_load_conservation_1164  1
    load_1_6_21  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_905  -25
    arc_1_7_0  depot_return_or_bypass_1159  1
    arc_1_7_0  out_degree_1167  1
    arc_1_7_0  original_T_including_depot_unload_1239  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_905  1
    load_1_7_0  segment_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_906  -25
    arc_1_7_6  connected_order_arc_907  -13
    arc_1_7_6  in_degree_1161  1
    arc_1_7_6  out_degree_1167  1
    arc_1_7_6  original_T_including_depot_unload_1239  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_906  1
    load_1_7_6  segment_load_conservation_1164  -1
    load_1_7_6  segment_prefix_lb_1165  1
    load_1_7_6  segment_prefix_ub_1166  1
    load_1_7_6  segment_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_908  -25
    arc_1_7_8  connected_order_arc_909  -13
    arc_1_7_8  out_degree_1167  1
    arc_1_7_8  in_degree_1175  1
    arc_1_7_8  original_T_including_depot_unload_1239  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_908  1
    load_1_7_8  segment_load_conservation_1171  1
    load_1_7_8  segment_load_conservation_1178  -1
    load_1_7_8  segment_prefix_lb_1179  1
    load_1_7_8  segment_prefix_ub_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_910  -25
    arc_1_7_9  connected_order_arc_911  -13
    arc_1_7_9  out_degree_1167  1
    arc_1_7_9  in_degree_1182  1
    arc_1_7_9  original_T_including_depot_unload_1239  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_910  1
    load_1_7_9  segment_load_conservation_1171  1
    load_1_7_9  segment_load_conservation_1185  -1
    load_1_7_9  segment_prefix_lb_1186  1
    load_1_7_9  segment_prefix_ub_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_912  -25
    arc_1_7_14  connected_order_arc_913  -13
    arc_1_7_14  out_degree_1167  1
    arc_1_7_14  in_degree_1189  1
    arc_1_7_14  original_T_including_depot_unload_1239  2.4977279292860885e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_912  1
    load_1_7_14  segment_load_conservation_1171  1
    load_1_7_14  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_914  -25
    arc_1_7_15  connected_order_arc_915  -13
    arc_1_7_15  out_degree_1167  1
    arc_1_7_15  in_degree_1195  1
    arc_1_7_15  original_T_including_depot_unload_1239  2.3595978160229652e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_914  1
    load_1_7_15  segment_load_conservation_1171  1
    load_1_7_15  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_916  -25
    arc_1_7_16  connected_order_arc_917  -13
    arc_1_7_16  out_degree_1167  1
    arc_1_7_16  in_degree_1201  1
    arc_1_7_16  original_T_including_depot_unload_1239  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_916  1
    load_1_7_16  segment_load_conservation_1171  1
    load_1_7_16  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_918  -25
    arc_1_7_17  connected_order_arc_919  -13
    arc_1_7_17  out_degree_1167  1
    arc_1_7_17  in_degree_1207  1
    arc_1_7_17  original_T_including_depot_unload_1239  1.9981042624472673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_918  1
    load_1_7_17  segment_load_conservation_1171  1
    load_1_7_17  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_920  -25
    arc_1_7_18  connected_order_arc_921  -13
    arc_1_7_18  out_degree_1167  1
    arc_1_7_18  in_degree_1213  1
    arc_1_7_18  original_T_including_depot_unload_1239  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_920  1
    load_1_7_18  segment_load_conservation_1171  1
    load_1_7_18  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_922  -25
    arc_1_7_19  connected_order_arc_923  -13
    arc_1_7_19  out_degree_1167  1
    arc_1_7_19  in_degree_1219  1
    arc_1_7_19  original_T_including_depot_unload_1239  1.7520337176349503e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_922  1
    load_1_7_19  segment_load_conservation_1171  1
    load_1_7_19  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_924  -25
    arc_1_7_20  connected_order_arc_925  -13
    arc_1_7_20  out_degree_1167  1
    arc_1_7_20  in_degree_1225  1
    arc_1_7_20  original_T_including_depot_unload_1239  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_924  1
    load_1_7_20  segment_load_conservation_1171  1
    load_1_7_20  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_926  -25
    arc_1_7_21  connected_order_arc_927  -13
    arc_1_7_21  out_degree_1167  1
    arc_1_7_21  in_degree_1231  1
    arc_1_7_21  original_T_including_depot_unload_1239  1.6982456083268751e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_926  1
    load_1_7_21  segment_load_conservation_1171  1
    load_1_7_21  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_928  -25
    arc_1_8_0  depot_return_or_bypass_1159  1
    arc_1_8_0  out_degree_1174  1
    arc_1_8_0  original_T_including_depot_unload_1239  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_928  1
    load_1_8_0  segment_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_929  -25
    arc_1_8_6  connected_order_arc_930  -13
    arc_1_8_6  in_degree_1161  1
    arc_1_8_6  out_degree_1174  1
    arc_1_8_6  original_T_including_depot_unload_1239  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_929  1
    load_1_8_6  segment_load_conservation_1164  -1
    load_1_8_6  segment_prefix_lb_1165  1
    load_1_8_6  segment_prefix_ub_1166  1
    load_1_8_6  segment_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_931  -25
    arc_1_8_7  connected_order_arc_932  -13
    arc_1_8_7  in_degree_1168  1
    arc_1_8_7  out_degree_1174  1
    arc_1_8_7  original_T_including_depot_unload_1239  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_931  1
    load_1_8_7  segment_load_conservation_1171  -1
    load_1_8_7  segment_prefix_lb_1172  1
    load_1_8_7  segment_prefix_ub_1173  1
    load_1_8_7  segment_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_933  -25
    arc_1_8_9  connected_order_arc_934  -13
    arc_1_8_9  out_degree_1174  1
    arc_1_8_9  in_degree_1182  1
    arc_1_8_9  original_T_including_depot_unload_1239  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_933  1
    load_1_8_9  segment_load_conservation_1178  1
    load_1_8_9  segment_load_conservation_1185  -1
    load_1_8_9  segment_prefix_lb_1186  1
    load_1_8_9  segment_prefix_ub_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_935  -25
    arc_1_8_14  connected_order_arc_936  -13
    arc_1_8_14  out_degree_1174  1
    arc_1_8_14  in_degree_1189  1
    arc_1_8_14  original_T_including_depot_unload_1239  2.3168138409467269e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_935  1
    load_1_8_14  segment_load_conservation_1178  1
    load_1_8_14  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_937  -25
    arc_1_8_15  connected_order_arc_938  -13
    arc_1_8_15  out_degree_1174  1
    arc_1_8_15  in_degree_1195  1
    arc_1_8_15  original_T_including_depot_unload_1239  2.2144644790128582e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_937  1
    load_1_8_15  segment_load_conservation_1178  1
    load_1_8_15  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_939  -25
    arc_1_8_16  connected_order_arc_940  -13
    arc_1_8_16  out_degree_1174  1
    arc_1_8_16  in_degree_1201  1
    arc_1_8_16  original_T_including_depot_unload_1239  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_939  1
    load_1_8_16  segment_load_conservation_1178  1
    load_1_8_16  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_941  -25
    arc_1_8_17  connected_order_arc_942  -13
    arc_1_8_17  out_degree_1174  1
    arc_1_8_17  in_degree_1207  1
    arc_1_8_17  original_T_including_depot_unload_1239  1.8130068061837439e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_941  1
    load_1_8_17  segment_load_conservation_1178  1
    load_1_8_17  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_943  -25
    arc_1_8_18  connected_order_arc_944  -13
    arc_1_8_18  out_degree_1174  1
    arc_1_8_18  in_degree_1213  1
    arc_1_8_18  original_T_including_depot_unload_1239  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_943  1
    load_1_8_18  segment_load_conservation_1178  1
    load_1_8_18  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_945  -25
    arc_1_8_19  connected_order_arc_946  -13
    arc_1_8_19  out_degree_1174  1
    arc_1_8_19  in_degree_1219  1
    arc_1_8_19  original_T_including_depot_unload_1239  1.5892857916507662e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_945  1
    load_1_8_19  segment_load_conservation_1178  1
    load_1_8_19  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_947  -25
    arc_1_8_20  connected_order_arc_948  -13
    arc_1_8_20  out_degree_1174  1
    arc_1_8_20  in_degree_1225  1
    arc_1_8_20  original_T_including_depot_unload_1239  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_947  1
    load_1_8_20  segment_load_conservation_1178  1
    load_1_8_20  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_949  -25
    arc_1_8_21  connected_order_arc_950  -13
    arc_1_8_21  out_degree_1174  1
    arc_1_8_21  in_degree_1231  1
    arc_1_8_21  original_T_including_depot_unload_1239  1.5053327747786273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_949  1
    load_1_8_21  segment_load_conservation_1178  1
    load_1_8_21  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_951  -25
    arc_1_9_0  depot_return_or_bypass_1159  1
    arc_1_9_0  out_degree_1181  1
    arc_1_9_0  original_T_including_depot_unload_1239  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_951  1
    load_1_9_0  segment_load_conservation_1185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_952  -25
    arc_1_9_6  connected_order_arc_953  -13
    arc_1_9_6  in_degree_1161  1
    arc_1_9_6  out_degree_1181  1
    arc_1_9_6  original_T_including_depot_unload_1239  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_952  1
    load_1_9_6  segment_load_conservation_1164  -1
    load_1_9_6  segment_prefix_lb_1165  1
    load_1_9_6  segment_prefix_ub_1166  1
    load_1_9_6  segment_load_conservation_1185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_954  -25
    arc_1_9_7  connected_order_arc_955  -13
    arc_1_9_7  in_degree_1168  1
    arc_1_9_7  out_degree_1181  1
    arc_1_9_7  original_T_including_depot_unload_1239  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_954  1
    load_1_9_7  segment_load_conservation_1171  -1
    load_1_9_7  segment_prefix_lb_1172  1
    load_1_9_7  segment_prefix_ub_1173  1
    load_1_9_7  segment_load_conservation_1185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_956  -25
    arc_1_9_8  connected_order_arc_957  -13
    arc_1_9_8  in_degree_1175  1
    arc_1_9_8  out_degree_1181  1
    arc_1_9_8  original_T_including_depot_unload_1239  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_956  1
    load_1_9_8  segment_load_conservation_1178  -1
    load_1_9_8  segment_prefix_lb_1179  1
    load_1_9_8  segment_prefix_ub_1180  1
    load_1_9_8  segment_load_conservation_1185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_958  -25
    arc_1_9_14  connected_order_arc_959  -13
    arc_1_9_14  out_degree_1181  1
    arc_1_9_14  in_degree_1189  1
    arc_1_9_14  original_T_including_depot_unload_1239  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_958  1
    load_1_9_14  segment_load_conservation_1185  1
    load_1_9_14  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_960  -25
    arc_1_9_15  connected_order_arc_961  -13
    arc_1_9_15  out_degree_1181  1
    arc_1_9_15  in_degree_1195  1
    arc_1_9_15  original_T_including_depot_unload_1239  1.4088953223409719e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_960  1
    load_1_9_15  segment_load_conservation_1185  1
    load_1_9_15  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_962  -25
    arc_1_9_16  connected_order_arc_963  -13
    arc_1_9_16  out_degree_1181  1
    arc_1_9_16  in_degree_1201  1
    arc_1_9_16  original_T_including_depot_unload_1239  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_962  1
    load_1_9_16  segment_load_conservation_1185  1
    load_1_9_16  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_964  -25
    arc_1_9_17  connected_order_arc_965  -13
    arc_1_9_17  out_degree_1181  1
    arc_1_9_17  in_degree_1207  1
    arc_1_9_17  original_T_including_depot_unload_1239  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_964  1
    load_1_9_17  segment_load_conservation_1185  1
    load_1_9_17  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_966  -25
    arc_1_9_18  connected_order_arc_967  -13
    arc_1_9_18  out_degree_1181  1
    arc_1_9_18  in_degree_1213  1
    arc_1_9_18  original_T_including_depot_unload_1239  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_966  1
    load_1_9_18  segment_load_conservation_1185  1
    load_1_9_18  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_968  -25
    arc_1_9_19  connected_order_arc_969  -13
    arc_1_9_19  out_degree_1181  1
    arc_1_9_19  in_degree_1219  1
    arc_1_9_19  original_T_including_depot_unload_1239  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_968  1
    load_1_9_19  segment_load_conservation_1185  1
    load_1_9_19  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_970  -25
    arc_1_9_20  connected_order_arc_971  -13
    arc_1_9_20  out_degree_1181  1
    arc_1_9_20  in_degree_1225  1
    arc_1_9_20  original_T_including_depot_unload_1239  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_970  1
    load_1_9_20  segment_load_conservation_1185  1
    load_1_9_20  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_972  -25
    arc_1_9_21  connected_order_arc_973  -13
    arc_1_9_21  out_degree_1181  1
    arc_1_9_21  in_degree_1231  1
    arc_1_9_21  original_T_including_depot_unload_1239  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_972  1
    load_1_9_21  segment_load_conservation_1185  1
    load_1_9_21  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_974  -25
    arc_1_14_0  depot_return_or_bypass_1159  1
    arc_1_14_0  out_degree_1188  1
    arc_1_14_0  original_T_including_depot_unload_1239  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_974  1
    load_1_14_0  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_975  -25
    arc_1_14_6  connected_order_arc_976  -13
    arc_1_14_6  in_degree_1161  1
    arc_1_14_6  out_degree_1188  1
    arc_1_14_6  original_T_including_depot_unload_1239  2.3158028257381197e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_975  1
    load_1_14_6  segment_load_conservation_1164  -1
    load_1_14_6  segment_prefix_lb_1165  1
    load_1_14_6  segment_prefix_ub_1166  1
    load_1_14_6  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_977  -25
    arc_1_14_7  connected_order_arc_978  -13
    arc_1_14_7  in_degree_1168  1
    arc_1_14_7  out_degree_1188  1
    arc_1_14_7  original_T_including_depot_unload_1239  2.4977279292860885e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_977  1
    load_1_14_7  segment_load_conservation_1171  -1
    load_1_14_7  segment_prefix_lb_1172  1
    load_1_14_7  segment_prefix_ub_1173  1
    load_1_14_7  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_979  -25
    arc_1_14_8  connected_order_arc_980  -13
    arc_1_14_8  in_degree_1175  1
    arc_1_14_8  out_degree_1188  1
    arc_1_14_8  original_T_including_depot_unload_1239  2.3168138409467269e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_979  1
    load_1_14_8  segment_load_conservation_1178  -1
    load_1_14_8  segment_prefix_lb_1179  1
    load_1_14_8  segment_prefix_ub_1180  1
    load_1_14_8  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_981  -25
    arc_1_14_9  connected_order_arc_982  -13
    arc_1_14_9  in_degree_1182  1
    arc_1_14_9  out_degree_1188  1
    arc_1_14_9  original_T_including_depot_unload_1239  2.4292147347743676e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_981  1
    load_1_14_9  segment_load_conservation_1185  -1
    load_1_14_9  segment_prefix_lb_1186  1
    load_1_14_9  segment_prefix_ub_1187  1
    load_1_14_9  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_983  -25
    arc_1_14_15  connected_order_arc_984  -13
    arc_1_14_15  out_degree_1188  1
    arc_1_14_15  in_degree_1195  1
    arc_1_14_15  original_T_including_depot_unload_1239  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_983  1
    load_1_14_15  free_load_conservation_1193  1
    load_1_14_15  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_985  -25
    arc_1_14_16  connected_order_arc_986  -13
    arc_1_14_16  out_degree_1188  1
    arc_1_14_16  in_degree_1201  1
    arc_1_14_16  original_T_including_depot_unload_1239  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_985  1
    load_1_14_16  free_load_conservation_1193  1
    load_1_14_16  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_987  -25
    arc_1_14_17  connected_order_arc_988  -13
    arc_1_14_17  out_degree_1188  1
    arc_1_14_17  in_degree_1207  1
    arc_1_14_17  original_T_including_depot_unload_1239  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_987  1
    load_1_14_17  free_load_conservation_1193  1
    load_1_14_17  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_989  -25
    arc_1_14_18  connected_order_arc_990  -13
    arc_1_14_18  out_degree_1188  1
    arc_1_14_18  in_degree_1213  1
    arc_1_14_18  original_T_including_depot_unload_1239  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_989  1
    load_1_14_18  free_load_conservation_1193  1
    load_1_14_18  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_991  -25
    arc_1_14_19  connected_order_arc_992  -13
    arc_1_14_19  out_degree_1188  1
    arc_1_14_19  in_degree_1219  1
    arc_1_14_19  original_T_including_depot_unload_1239  7.6789230776331749e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_991  1
    load_1_14_19  free_load_conservation_1193  1
    load_1_14_19  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_993  -25
    arc_1_14_20  connected_order_arc_994  -13
    arc_1_14_20  out_degree_1188  1
    arc_1_14_20  in_degree_1225  1
    arc_1_14_20  original_T_including_depot_unload_1239  1.4688211749637876e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_993  1
    load_1_14_20  free_load_conservation_1193  1
    load_1_14_20  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_21  arc_capacity_995  -25
    arc_1_14_21  connected_order_arc_996  -13
    arc_1_14_21  out_degree_1188  1
    arc_1_14_21  in_degree_1231  1
    arc_1_14_21  original_T_including_depot_unload_1239  8.2066682484686987e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_21  arc_capacity_995  1
    load_1_14_21  free_load_conservation_1193  1
    load_1_14_21  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_997  -25
    arc_1_15_0  depot_return_or_bypass_1159  1
    arc_1_15_0  out_degree_1194  1
    arc_1_15_0  original_T_including_depot_unload_1239  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_997  1
    load_1_15_0  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_998  -25
    arc_1_15_6  connected_order_arc_999  -13
    arc_1_15_6  in_degree_1161  1
    arc_1_15_6  out_degree_1194  1
    arc_1_15_6  original_T_including_depot_unload_1239  2.1372888672431886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_998  1
    load_1_15_6  segment_load_conservation_1164  -1
    load_1_15_6  segment_prefix_lb_1165  1
    load_1_15_6  segment_prefix_ub_1166  1
    load_1_15_6  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1000  -25
    arc_1_15_7  connected_order_arc_1001  -13
    arc_1_15_7  in_degree_1168  1
    arc_1_15_7  out_degree_1194  1
    arc_1_15_7  original_T_including_depot_unload_1239  2.3595978160229652e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1000  1
    load_1_15_7  segment_load_conservation_1171  -1
    load_1_15_7  segment_prefix_lb_1172  1
    load_1_15_7  segment_prefix_ub_1173  1
    load_1_15_7  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1002  -25
    arc_1_15_8  connected_order_arc_1003  -13
    arc_1_15_8  in_degree_1175  1
    arc_1_15_8  out_degree_1194  1
    arc_1_15_8  original_T_including_depot_unload_1239  2.2144644790128582e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1002  1
    load_1_15_8  segment_load_conservation_1178  -1
    load_1_15_8  segment_prefix_lb_1179  1
    load_1_15_8  segment_prefix_ub_1180  1
    load_1_15_8  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1004  -25
    arc_1_15_9  connected_order_arc_1005  -13
    arc_1_15_9  in_degree_1182  1
    arc_1_15_9  out_degree_1194  1
    arc_1_15_9  original_T_including_depot_unload_1239  2.2245628069082109e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1004  1
    load_1_15_9  segment_load_conservation_1185  -1
    load_1_15_9  segment_prefix_lb_1186  1
    load_1_15_9  segment_prefix_ub_1187  1
    load_1_15_9  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1006  -25
    arc_1_15_14  connected_order_arc_1007  -13
    arc_1_15_14  in_degree_1189  1
    arc_1_15_14  out_degree_1194  1
    arc_1_15_14  original_T_including_depot_unload_1239  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1006  1
    load_1_15_14  free_load_conservation_1193  -1
    load_1_15_14  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1008  -25
    arc_1_15_16  connected_order_arc_1009  -13
    arc_1_15_16  out_degree_1194  1
    arc_1_15_16  in_degree_1201  1
    arc_1_15_16  original_T_including_depot_unload_1239  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1008  1
    load_1_15_16  free_load_conservation_1199  1
    load_1_15_16  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1010  -25
    arc_1_15_17  connected_order_arc_1011  -13
    arc_1_15_17  out_degree_1194  1
    arc_1_15_17  in_degree_1207  1
    arc_1_15_17  original_T_including_depot_unload_1239  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1010  1
    load_1_15_17  free_load_conservation_1199  1
    load_1_15_17  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1012  -25
    arc_1_15_18  connected_order_arc_1013  -13
    arc_1_15_18  out_degree_1194  1
    arc_1_15_18  in_degree_1213  1
    arc_1_15_18  original_T_including_depot_unload_1239  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1012  1
    load_1_15_18  free_load_conservation_1199  1
    load_1_15_18  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1014  -25
    arc_1_15_19  connected_order_arc_1015  -13
    arc_1_15_19  out_degree_1194  1
    arc_1_15_19  in_degree_1219  1
    arc_1_15_19  original_T_including_depot_unload_1239  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1014  1
    load_1_15_19  free_load_conservation_1199  1
    load_1_15_19  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1016  -25
    arc_1_15_20  connected_order_arc_1017  -13
    arc_1_15_20  out_degree_1194  1
    arc_1_15_20  in_degree_1225  1
    arc_1_15_20  original_T_including_depot_unload_1239  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1016  1
    load_1_15_20  free_load_conservation_1199  1
    load_1_15_20  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_1018  -25
    arc_1_15_21  connected_order_arc_1019  -13
    arc_1_15_21  out_degree_1194  1
    arc_1_15_21  in_degree_1231  1
    arc_1_15_21  original_T_including_depot_unload_1239  8.6958069185371107e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_1018  1
    load_1_15_21  free_load_conservation_1199  1
    load_1_15_21  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1020  -25
    arc_1_16_0  depot_return_or_bypass_1159  1
    arc_1_16_0  out_degree_1200  1
    arc_1_16_0  original_T_including_depot_unload_1239  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1020  1
    load_1_16_0  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_1021  -25
    arc_1_16_6  connected_order_arc_1022  -13
    arc_1_16_6  in_degree_1161  1
    arc_1_16_6  out_degree_1200  1
    arc_1_16_6  original_T_including_depot_unload_1239  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_1021  1
    load_1_16_6  segment_load_conservation_1164  -1
    load_1_16_6  segment_prefix_lb_1165  1
    load_1_16_6  segment_prefix_ub_1166  1
    load_1_16_6  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1023  -25
    arc_1_16_7  connected_order_arc_1024  -13
    arc_1_16_7  in_degree_1168  1
    arc_1_16_7  out_degree_1200  1
    arc_1_16_7  original_T_including_depot_unload_1239  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1023  1
    load_1_16_7  segment_load_conservation_1171  -1
    load_1_16_7  segment_prefix_lb_1172  1
    load_1_16_7  segment_prefix_ub_1173  1
    load_1_16_7  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1025  -25
    arc_1_16_8  connected_order_arc_1026  -13
    arc_1_16_8  in_degree_1175  1
    arc_1_16_8  out_degree_1200  1
    arc_1_16_8  original_T_including_depot_unload_1239  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1025  1
    load_1_16_8  segment_load_conservation_1178  -1
    load_1_16_8  segment_prefix_lb_1179  1
    load_1_16_8  segment_prefix_ub_1180  1
    load_1_16_8  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1027  -25
    arc_1_16_9  connected_order_arc_1028  -13
    arc_1_16_9  in_degree_1182  1
    arc_1_16_9  out_degree_1200  1
    arc_1_16_9  original_T_including_depot_unload_1239  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1027  1
    load_1_16_9  segment_load_conservation_1185  -1
    load_1_16_9  segment_prefix_lb_1186  1
    load_1_16_9  segment_prefix_ub_1187  1
    load_1_16_9  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1029  -25
    arc_1_16_14  connected_order_arc_1030  -13
    arc_1_16_14  in_degree_1189  1
    arc_1_16_14  out_degree_1200  1
    arc_1_16_14  original_T_including_depot_unload_1239  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1029  1
    load_1_16_14  free_load_conservation_1193  -1
    load_1_16_14  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1031  -25
    arc_1_16_15  connected_order_arc_1032  -13
    arc_1_16_15  in_degree_1195  1
    arc_1_16_15  out_degree_1200  1
    arc_1_16_15  original_T_including_depot_unload_1239  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1031  1
    load_1_16_15  free_load_conservation_1199  -1
    load_1_16_15  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1033  -25
    arc_1_16_17  connected_order_arc_1034  -13
    arc_1_16_17  out_degree_1200  1
    arc_1_16_17  in_degree_1207  1
    arc_1_16_17  original_T_including_depot_unload_1239  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1033  1
    load_1_16_17  free_load_conservation_1205  1
    load_1_16_17  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1035  -25
    arc_1_16_18  connected_order_arc_1036  -13
    arc_1_16_18  out_degree_1200  1
    arc_1_16_18  in_degree_1213  1
    arc_1_16_18  original_T_including_depot_unload_1239  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1035  1
    load_1_16_18  free_load_conservation_1205  1
    load_1_16_18  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1037  -25
    arc_1_16_19  connected_order_arc_1038  -13
    arc_1_16_19  out_degree_1200  1
    arc_1_16_19  in_degree_1219  1
    arc_1_16_19  original_T_including_depot_unload_1239  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1037  1
    load_1_16_19  free_load_conservation_1205  1
    load_1_16_19  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1039  -25
    arc_1_16_20  connected_order_arc_1040  -13
    arc_1_16_20  out_degree_1200  1
    arc_1_16_20  in_degree_1225  1
    arc_1_16_20  original_T_including_depot_unload_1239  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1039  1
    load_1_16_20  free_load_conservation_1205  1
    load_1_16_20  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1041  -25
    arc_1_16_21  connected_order_arc_1042  -13
    arc_1_16_21  out_degree_1200  1
    arc_1_16_21  in_degree_1231  1
    arc_1_16_21  original_T_including_depot_unload_1239  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1041  1
    load_1_16_21  free_load_conservation_1205  1
    load_1_16_21  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1043  -25
    arc_1_17_0  depot_return_or_bypass_1159  1
    arc_1_17_0  out_degree_1206  1
    arc_1_17_0  original_T_including_depot_unload_1239  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1043  1
    load_1_17_0  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1044  -25
    arc_1_17_6  connected_order_arc_1045  -13
    arc_1_17_6  in_degree_1161  1
    arc_1_17_6  out_degree_1206  1
    arc_1_17_6  original_T_including_depot_unload_1239  1.8269270746185791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1044  1
    load_1_17_6  segment_load_conservation_1164  -1
    load_1_17_6  segment_prefix_lb_1165  1
    load_1_17_6  segment_prefix_ub_1166  1
    load_1_17_6  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1046  -25
    arc_1_17_7  connected_order_arc_1047  -13
    arc_1_17_7  in_degree_1168  1
    arc_1_17_7  out_degree_1206  1
    arc_1_17_7  original_T_including_depot_unload_1239  1.9981042624472673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1046  1
    load_1_17_7  segment_load_conservation_1171  -1
    load_1_17_7  segment_prefix_lb_1172  1
    load_1_17_7  segment_prefix_ub_1173  1
    load_1_17_7  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1048  -25
    arc_1_17_8  connected_order_arc_1049  -13
    arc_1_17_8  in_degree_1175  1
    arc_1_17_8  out_degree_1206  1
    arc_1_17_8  original_T_including_depot_unload_1239  1.8130068061837439e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1048  1
    load_1_17_8  segment_load_conservation_1178  -1
    load_1_17_8  segment_prefix_lb_1179  1
    load_1_17_8  segment_prefix_ub_1180  1
    load_1_17_8  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1050  -25
    arc_1_17_9  connected_order_arc_1051  -13
    arc_1_17_9  in_degree_1182  1
    arc_1_17_9  out_degree_1206  1
    arc_1_17_9  original_T_including_depot_unload_1239  1.9482201819157062e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1050  1
    load_1_17_9  segment_load_conservation_1185  -1
    load_1_17_9  segment_prefix_lb_1186  1
    load_1_17_9  segment_prefix_ub_1187  1
    load_1_17_9  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1052  -25
    arc_1_17_14  connected_order_arc_1053  -13
    arc_1_17_14  in_degree_1189  1
    arc_1_17_14  out_degree_1206  1
    arc_1_17_14  original_T_including_depot_unload_1239  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1052  1
    load_1_17_14  free_load_conservation_1193  -1
    load_1_17_14  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1054  -25
    arc_1_17_15  connected_order_arc_1055  -13
    arc_1_17_15  in_degree_1195  1
    arc_1_17_15  out_degree_1206  1
    arc_1_17_15  original_T_including_depot_unload_1239  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1054  1
    load_1_17_15  free_load_conservation_1199  -1
    load_1_17_15  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1056  -25
    arc_1_17_16  connected_order_arc_1057  -13
    arc_1_17_16  in_degree_1201  1
    arc_1_17_16  out_degree_1206  1
    arc_1_17_16  original_T_including_depot_unload_1239  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1056  1
    load_1_17_16  free_load_conservation_1205  -1
    load_1_17_16  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1058  -25
    arc_1_17_18  connected_order_arc_1059  -13
    arc_1_17_18  out_degree_1206  1
    arc_1_17_18  in_degree_1213  1
    arc_1_17_18  original_T_including_depot_unload_1239  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1058  1
    load_1_17_18  free_load_conservation_1211  1
    load_1_17_18  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1060  -25
    arc_1_17_19  connected_order_arc_1061  -13
    arc_1_17_19  out_degree_1206  1
    arc_1_17_19  in_degree_1219  1
    arc_1_17_19  original_T_including_depot_unload_1239  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1060  1
    load_1_17_19  free_load_conservation_1211  1
    load_1_17_19  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1062  -25
    arc_1_17_20  connected_order_arc_1063  -13
    arc_1_17_20  out_degree_1206  1
    arc_1_17_20  in_degree_1225  1
    arc_1_17_20  original_T_including_depot_unload_1239  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1062  1
    load_1_17_20  free_load_conservation_1211  1
    load_1_17_20  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1064  -25
    arc_1_17_21  connected_order_arc_1065  -13
    arc_1_17_21  out_degree_1206  1
    arc_1_17_21  in_degree_1231  1
    arc_1_17_21  original_T_including_depot_unload_1239  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1064  1
    load_1_17_21  free_load_conservation_1211  1
    load_1_17_21  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1066  -25
    arc_1_18_0  depot_return_or_bypass_1159  1
    arc_1_18_0  out_degree_1212  1
    arc_1_18_0  original_T_including_depot_unload_1239  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1066  1
    load_1_18_0  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1067  -25
    arc_1_18_6  connected_order_arc_1068  -13
    arc_1_18_6  in_degree_1161  1
    arc_1_18_6  out_degree_1212  1
    arc_1_18_6  original_T_including_depot_unload_1239  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1067  1
    load_1_18_6  segment_load_conservation_1164  -1
    load_1_18_6  segment_prefix_lb_1165  1
    load_1_18_6  segment_prefix_ub_1166  1
    load_1_18_6  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1069  -25
    arc_1_18_7  connected_order_arc_1070  -13
    arc_1_18_7  in_degree_1168  1
    arc_1_18_7  out_degree_1212  1
    arc_1_18_7  original_T_including_depot_unload_1239  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1069  1
    load_1_18_7  segment_load_conservation_1171  -1
    load_1_18_7  segment_prefix_lb_1172  1
    load_1_18_7  segment_prefix_ub_1173  1
    load_1_18_7  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1071  -25
    arc_1_18_8  connected_order_arc_1072  -13
    arc_1_18_8  in_degree_1175  1
    arc_1_18_8  out_degree_1212  1
    arc_1_18_8  original_T_including_depot_unload_1239  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1071  1
    load_1_18_8  segment_load_conservation_1178  -1
    load_1_18_8  segment_prefix_lb_1179  1
    load_1_18_8  segment_prefix_ub_1180  1
    load_1_18_8  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1073  -25
    arc_1_18_9  connected_order_arc_1074  -13
    arc_1_18_9  in_degree_1182  1
    arc_1_18_9  out_degree_1212  1
    arc_1_18_9  original_T_including_depot_unload_1239  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1073  1
    load_1_18_9  segment_load_conservation_1185  -1
    load_1_18_9  segment_prefix_lb_1186  1
    load_1_18_9  segment_prefix_ub_1187  1
    load_1_18_9  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1075  -25
    arc_1_18_14  connected_order_arc_1076  -13
    arc_1_18_14  in_degree_1189  1
    arc_1_18_14  out_degree_1212  1
    arc_1_18_14  original_T_including_depot_unload_1239  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1075  1
    load_1_18_14  free_load_conservation_1193  -1
    load_1_18_14  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1077  -25
    arc_1_18_15  connected_order_arc_1078  -13
    arc_1_18_15  in_degree_1195  1
    arc_1_18_15  out_degree_1212  1
    arc_1_18_15  original_T_including_depot_unload_1239  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1077  1
    load_1_18_15  free_load_conservation_1199  -1
    load_1_18_15  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1079  -25
    arc_1_18_16  connected_order_arc_1080  -13
    arc_1_18_16  in_degree_1201  1
    arc_1_18_16  out_degree_1212  1
    arc_1_18_16  original_T_including_depot_unload_1239  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1079  1
    load_1_18_16  free_load_conservation_1205  -1
    load_1_18_16  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1081  -25
    arc_1_18_17  connected_order_arc_1082  -13
    arc_1_18_17  in_degree_1207  1
    arc_1_18_17  out_degree_1212  1
    arc_1_18_17  original_T_including_depot_unload_1239  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1081  1
    load_1_18_17  free_load_conservation_1211  -1
    load_1_18_17  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1083  -25
    arc_1_18_19  connected_order_arc_1084  -13
    arc_1_18_19  out_degree_1212  1
    arc_1_18_19  in_degree_1219  1
    arc_1_18_19  original_T_including_depot_unload_1239  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1083  1
    load_1_18_19  free_load_conservation_1217  1
    load_1_18_19  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1085  -25
    arc_1_18_20  connected_order_arc_1086  -13
    arc_1_18_20  out_degree_1212  1
    arc_1_18_20  in_degree_1225  1
    arc_1_18_20  original_T_including_depot_unload_1239  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1085  1
    load_1_18_20  free_load_conservation_1217  1
    load_1_18_20  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1087  -25
    arc_1_18_21  connected_order_arc_1088  -13
    arc_1_18_21  out_degree_1212  1
    arc_1_18_21  in_degree_1231  1
    arc_1_18_21  original_T_including_depot_unload_1239  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1087  1
    load_1_18_21  free_load_conservation_1217  1
    load_1_18_21  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1089  -25
    arc_1_19_0  depot_return_or_bypass_1159  1
    arc_1_19_0  out_degree_1218  1
    arc_1_19_0  original_T_including_depot_unload_1239  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1089  1
    load_1_19_0  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1090  -25
    arc_1_19_6  connected_order_arc_1091  -13
    arc_1_19_6  in_degree_1161  1
    arc_1_19_6  out_degree_1218  1
    arc_1_19_6  original_T_including_depot_unload_1239  1.5546511874277910e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1090  1
    load_1_19_6  segment_load_conservation_1164  -1
    load_1_19_6  segment_prefix_lb_1165  1
    load_1_19_6  segment_prefix_ub_1166  1
    load_1_19_6  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1092  -25
    arc_1_19_7  connected_order_arc_1093  -13
    arc_1_19_7  in_degree_1168  1
    arc_1_19_7  out_degree_1218  1
    arc_1_19_7  original_T_including_depot_unload_1239  1.7520337176349503e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1092  1
    load_1_19_7  segment_load_conservation_1171  -1
    load_1_19_7  segment_prefix_lb_1172  1
    load_1_19_7  segment_prefix_ub_1173  1
    load_1_19_7  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1094  -25
    arc_1_19_8  connected_order_arc_1095  -13
    arc_1_19_8  in_degree_1175  1
    arc_1_19_8  out_degree_1218  1
    arc_1_19_8  original_T_including_depot_unload_1239  1.5892857916507662e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1094  1
    load_1_19_8  segment_load_conservation_1178  -1
    load_1_19_8  segment_prefix_lb_1179  1
    load_1_19_8  segment_prefix_ub_1180  1
    load_1_19_8  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1096  -25
    arc_1_19_9  connected_order_arc_1097  -13
    arc_1_19_9  in_degree_1182  1
    arc_1_19_9  out_degree_1218  1
    arc_1_19_9  original_T_including_depot_unload_1239  1.6631507094436240e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1096  1
    load_1_19_9  segment_load_conservation_1185  -1
    load_1_19_9  segment_prefix_lb_1186  1
    load_1_19_9  segment_prefix_ub_1187  1
    load_1_19_9  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1098  -25
    arc_1_19_14  connected_order_arc_1099  -13
    arc_1_19_14  in_degree_1189  1
    arc_1_19_14  out_degree_1218  1
    arc_1_19_14  original_T_including_depot_unload_1239  7.6789230776331749e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1098  1
    load_1_19_14  free_load_conservation_1193  -1
    load_1_19_14  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1100  -25
    arc_1_19_15  connected_order_arc_1101  -13
    arc_1_19_15  in_degree_1195  1
    arc_1_19_15  out_degree_1218  1
    arc_1_19_15  original_T_including_depot_unload_1239  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1100  1
    load_1_19_15  free_load_conservation_1199  -1
    load_1_19_15  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1102  -25
    arc_1_19_16  connected_order_arc_1103  -13
    arc_1_19_16  in_degree_1201  1
    arc_1_19_16  out_degree_1218  1
    arc_1_19_16  original_T_including_depot_unload_1239  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1102  1
    load_1_19_16  free_load_conservation_1205  -1
    load_1_19_16  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1104  -25
    arc_1_19_17  connected_order_arc_1105  -13
    arc_1_19_17  in_degree_1207  1
    arc_1_19_17  out_degree_1218  1
    arc_1_19_17  original_T_including_depot_unload_1239  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1104  1
    load_1_19_17  free_load_conservation_1211  -1
    load_1_19_17  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1106  -25
    arc_1_19_18  connected_order_arc_1107  -13
    arc_1_19_18  in_degree_1213  1
    arc_1_19_18  out_degree_1218  1
    arc_1_19_18  original_T_including_depot_unload_1239  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1106  1
    load_1_19_18  free_load_conservation_1217  -1
    load_1_19_18  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1108  -25
    arc_1_19_20  connected_order_arc_1109  -13
    arc_1_19_20  out_degree_1218  1
    arc_1_19_20  in_degree_1225  1
    arc_1_19_20  original_T_including_depot_unload_1239  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1108  1
    load_1_19_20  free_load_conservation_1223  1
    load_1_19_20  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1110  -25
    arc_1_19_21  connected_order_arc_1111  -13
    arc_1_19_21  out_degree_1218  1
    arc_1_19_21  in_degree_1231  1
    arc_1_19_21  original_T_including_depot_unload_1239  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1110  1
    load_1_19_21  free_load_conservation_1223  1
    load_1_19_21  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1112  -25
    arc_1_20_0  depot_return_or_bypass_1159  1
    arc_1_20_0  out_degree_1224  1
    arc_1_20_0  original_T_including_depot_unload_1239  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1112  1
    load_1_20_0  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1113  -25
    arc_1_20_6  connected_order_arc_1114  -13
    arc_1_20_6  in_degree_1161  1
    arc_1_20_6  out_degree_1224  1
    arc_1_20_6  original_T_including_depot_unload_1239  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1113  1
    load_1_20_6  segment_load_conservation_1164  -1
    load_1_20_6  segment_prefix_lb_1165  1
    load_1_20_6  segment_prefix_ub_1166  1
    load_1_20_6  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1115  -25
    arc_1_20_7  connected_order_arc_1116  -13
    arc_1_20_7  in_degree_1168  1
    arc_1_20_7  out_degree_1224  1
    arc_1_20_7  original_T_including_depot_unload_1239  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1115  1
    load_1_20_7  segment_load_conservation_1171  -1
    load_1_20_7  segment_prefix_lb_1172  1
    load_1_20_7  segment_prefix_ub_1173  1
    load_1_20_7  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1117  -25
    arc_1_20_8  connected_order_arc_1118  -13
    arc_1_20_8  in_degree_1175  1
    arc_1_20_8  out_degree_1224  1
    arc_1_20_8  original_T_including_depot_unload_1239  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1117  1
    load_1_20_8  segment_load_conservation_1178  -1
    load_1_20_8  segment_prefix_lb_1179  1
    load_1_20_8  segment_prefix_ub_1180  1
    load_1_20_8  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1119  -25
    arc_1_20_9  connected_order_arc_1120  -13
    arc_1_20_9  in_degree_1182  1
    arc_1_20_9  out_degree_1224  1
    arc_1_20_9  original_T_including_depot_unload_1239  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1119  1
    load_1_20_9  segment_load_conservation_1185  -1
    load_1_20_9  segment_prefix_lb_1186  1
    load_1_20_9  segment_prefix_ub_1187  1
    load_1_20_9  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1121  -25
    arc_1_20_14  connected_order_arc_1122  -13
    arc_1_20_14  in_degree_1189  1
    arc_1_20_14  out_degree_1224  1
    arc_1_20_14  original_T_including_depot_unload_1239  1.4688211749637876e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1121  1
    load_1_20_14  free_load_conservation_1193  -1
    load_1_20_14  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1123  -25
    arc_1_20_15  connected_order_arc_1124  -13
    arc_1_20_15  in_degree_1195  1
    arc_1_20_15  out_degree_1224  1
    arc_1_20_15  original_T_including_depot_unload_1239  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1123  1
    load_1_20_15  free_load_conservation_1199  -1
    load_1_20_15  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1125  -25
    arc_1_20_16  connected_order_arc_1126  -13
    arc_1_20_16  in_degree_1201  1
    arc_1_20_16  out_degree_1224  1
    arc_1_20_16  original_T_including_depot_unload_1239  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1125  1
    load_1_20_16  free_load_conservation_1205  -1
    load_1_20_16  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1127  -25
    arc_1_20_17  connected_order_arc_1128  -13
    arc_1_20_17  in_degree_1207  1
    arc_1_20_17  out_degree_1224  1
    arc_1_20_17  original_T_including_depot_unload_1239  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1127  1
    load_1_20_17  free_load_conservation_1211  -1
    load_1_20_17  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1129  -25
    arc_1_20_18  connected_order_arc_1130  -13
    arc_1_20_18  in_degree_1213  1
    arc_1_20_18  out_degree_1224  1
    arc_1_20_18  original_T_including_depot_unload_1239  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1129  1
    load_1_20_18  free_load_conservation_1217  -1
    load_1_20_18  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1131  -25
    arc_1_20_19  connected_order_arc_1132  -13
    arc_1_20_19  in_degree_1219  1
    arc_1_20_19  out_degree_1224  1
    arc_1_20_19  original_T_including_depot_unload_1239  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1131  1
    load_1_20_19  free_load_conservation_1223  -1
    load_1_20_19  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1133  -25
    arc_1_20_21  connected_order_arc_1134  -13
    arc_1_20_21  out_degree_1224  1
    arc_1_20_21  in_degree_1231  1
    arc_1_20_21  original_T_including_depot_unload_1239  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1133  1
    load_1_20_21  free_load_conservation_1229  1
    load_1_20_21  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1135  -25
    arc_1_21_0  depot_return_or_bypass_1159  1
    arc_1_21_0  out_degree_1230  1
    arc_1_21_0  original_T_including_depot_unload_1239  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1135  1
    load_1_21_0  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_6  arc_capacity_1136  -25
    arc_1_21_6  connected_order_arc_1137  -13
    arc_1_21_6  in_degree_1161  1
    arc_1_21_6  out_degree_1230  1
    arc_1_21_6  original_T_including_depot_unload_1239  1.5437191441012344e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_6  arc_capacity_1136  1
    load_1_21_6  segment_load_conservation_1164  -1
    load_1_21_6  segment_prefix_lb_1165  1
    load_1_21_6  segment_prefix_ub_1166  1
    load_1_21_6  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1138  -25
    arc_1_21_7  connected_order_arc_1139  -13
    arc_1_21_7  in_degree_1168  1
    arc_1_21_7  out_degree_1230  1
    arc_1_21_7  original_T_including_depot_unload_1239  1.6982456083268751e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1138  1
    load_1_21_7  segment_load_conservation_1171  -1
    load_1_21_7  segment_prefix_lb_1172  1
    load_1_21_7  segment_prefix_ub_1173  1
    load_1_21_7  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1140  -25
    arc_1_21_8  connected_order_arc_1141  -13
    arc_1_21_8  in_degree_1175  1
    arc_1_21_8  out_degree_1230  1
    arc_1_21_8  original_T_including_depot_unload_1239  1.5053327747786273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1140  1
    load_1_21_8  segment_load_conservation_1178  -1
    load_1_21_8  segment_prefix_lb_1179  1
    load_1_21_8  segment_prefix_ub_1180  1
    load_1_21_8  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1142  -25
    arc_1_21_9  connected_order_arc_1143  -13
    arc_1_21_9  in_degree_1182  1
    arc_1_21_9  out_degree_1230  1
    arc_1_21_9  original_T_including_depot_unload_1239  1.6744862285014353e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1142  1
    load_1_21_9  segment_load_conservation_1185  -1
    load_1_21_9  segment_prefix_lb_1186  1
    load_1_21_9  segment_prefix_ub_1187  1
    load_1_21_9  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_14  arc_capacity_1144  -25
    arc_1_21_14  connected_order_arc_1145  -13
    arc_1_21_14  in_degree_1189  1
    arc_1_21_14  out_degree_1230  1
    arc_1_21_14  original_T_including_depot_unload_1239  8.2066682484686987e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_14  arc_capacity_1144  1
    load_1_21_14  free_load_conservation_1193  -1
    load_1_21_14  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1146  -25
    arc_1_21_15  connected_order_arc_1147  -13
    arc_1_21_15  in_degree_1195  1
    arc_1_21_15  out_degree_1230  1
    arc_1_21_15  original_T_including_depot_unload_1239  8.6958069185371107e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1146  1
    load_1_21_15  free_load_conservation_1199  -1
    load_1_21_15  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1148  -25
    arc_1_21_16  connected_order_arc_1149  -13
    arc_1_21_16  in_degree_1201  1
    arc_1_21_16  out_degree_1230  1
    arc_1_21_16  original_T_including_depot_unload_1239  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1148  1
    load_1_21_16  free_load_conservation_1205  -1
    load_1_21_16  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1150  -25
    arc_1_21_17  connected_order_arc_1151  -13
    arc_1_21_17  in_degree_1207  1
    arc_1_21_17  out_degree_1230  1
    arc_1_21_17  original_T_including_depot_unload_1239  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1150  1
    load_1_21_17  free_load_conservation_1211  -1
    load_1_21_17  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1152  -25
    arc_1_21_18  connected_order_arc_1153  -13
    arc_1_21_18  in_degree_1213  1
    arc_1_21_18  out_degree_1230  1
    arc_1_21_18  original_T_including_depot_unload_1239  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1152  1
    load_1_21_18  free_load_conservation_1217  -1
    load_1_21_18  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1154  -25
    arc_1_21_19  connected_order_arc_1155  -13
    arc_1_21_19  in_degree_1219  1
    arc_1_21_19  out_degree_1230  1
    arc_1_21_19  original_T_including_depot_unload_1239  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1154  1
    load_1_21_19  free_load_conservation_1223  -1
    load_1_21_19  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1156  -25
    arc_1_21_20  connected_order_arc_1157  -13
    arc_1_21_20  in_degree_1225  1
    arc_1_21_20  out_degree_1230  1
    arc_1_21_20  original_T_including_depot_unload_1239  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1156  1
    load_1_21_20  free_load_conservation_1229  -1
    load_1_21_20  free_load_conservation_1235  1
    visit_2_10  out_degree_1531  -1
    visit_2_10  in_degree_1532  -1
    visit_2_10  order_active_lb_1533  -1
    visit_2_10  order_active_ub_1534  -12
    order_2_10  connected_order_arc_1255  -1
    order_2_10  connected_order_arc_1257  -1
    order_2_10  connected_order_arc_1259  -1
    order_2_10  connected_order_arc_1261  -1
    order_2_10  connected_order_arc_1263  -1
    order_2_10  connected_order_arc_1265  -1
    order_2_10  connected_order_arc_1267  -1
    order_2_10  connected_order_arc_1269  -1
    order_2_10  connected_order_arc_1271  -1
    order_2_10  connected_order_arc_1273  -1
    order_2_10  connected_order_arc_1275  -1
    order_2_10  connected_order_arc_1278  1
    order_2_10  connected_order_arc_1301  1
    order_2_10  connected_order_arc_1324  1
    order_2_10  connected_order_arc_1347  1
    order_2_10  connected_order_arc_1370  1
    order_2_10  connected_order_arc_1393  1
    order_2_10  connected_order_arc_1416  1
    order_2_10  connected_order_arc_1439  1
    order_2_10  connected_order_arc_1462  1
    order_2_10  connected_order_arc_1485  1
    order_2_10  connected_order_arc_1508  1
    order_2_10  order_active_lb_1533  1
    order_2_10  order_active_ub_1534  1
    order_2_10  fixed_segment_relative_order_1607  -1
    visit_2_11  out_degree_1538  -1
    visit_2_11  in_degree_1539  -1
    visit_2_11  order_active_lb_1540  -1
    visit_2_11  order_active_ub_1541  -12
    order_2_11  connected_order_arc_1255  1
    order_2_11  connected_order_arc_1278  -1
    order_2_11  connected_order_arc_1280  -1
    order_2_11  connected_order_arc_1282  -1
    order_2_11  connected_order_arc_1284  -1
    order_2_11  connected_order_arc_1286  -1
    order_2_11  connected_order_arc_1288  -1
    order_2_11  connected_order_arc_1290  -1
    order_2_11  connected_order_arc_1292  -1
    order_2_11  connected_order_arc_1294  -1
    order_2_11  connected_order_arc_1296  -1
    order_2_11  connected_order_arc_1298  -1
    order_2_11  connected_order_arc_1303  1
    order_2_11  connected_order_arc_1326  1
    order_2_11  connected_order_arc_1349  1
    order_2_11  connected_order_arc_1372  1
    order_2_11  connected_order_arc_1395  1
    order_2_11  connected_order_arc_1418  1
    order_2_11  connected_order_arc_1441  1
    order_2_11  connected_order_arc_1464  1
    order_2_11  connected_order_arc_1487  1
    order_2_11  connected_order_arc_1510  1
    order_2_11  order_active_lb_1540  1
    order_2_11  order_active_ub_1541  1
    order_2_11  fixed_segment_relative_order_1607  1
    order_2_11  fixed_segment_relative_order_1608  -1
    visit_2_12  out_degree_1545  -1
    visit_2_12  in_degree_1546  -1
    visit_2_12  order_active_lb_1547  -1
    visit_2_12  order_active_ub_1548  -12
    order_2_12  connected_order_arc_1257  1
    order_2_12  connected_order_arc_1280  1
    order_2_12  connected_order_arc_1301  -1
    order_2_12  connected_order_arc_1303  -1
    order_2_12  connected_order_arc_1305  -1
    order_2_12  connected_order_arc_1307  -1
    order_2_12  connected_order_arc_1309  -1
    order_2_12  connected_order_arc_1311  -1
    order_2_12  connected_order_arc_1313  -1
    order_2_12  connected_order_arc_1315  -1
    order_2_12  connected_order_arc_1317  -1
    order_2_12  connected_order_arc_1319  -1
    order_2_12  connected_order_arc_1321  -1
    order_2_12  connected_order_arc_1328  1
    order_2_12  connected_order_arc_1351  1
    order_2_12  connected_order_arc_1374  1
    order_2_12  connected_order_arc_1397  1
    order_2_12  connected_order_arc_1420  1
    order_2_12  connected_order_arc_1443  1
    order_2_12  connected_order_arc_1466  1
    order_2_12  connected_order_arc_1489  1
    order_2_12  connected_order_arc_1512  1
    order_2_12  order_active_lb_1547  1
    order_2_12  order_active_ub_1548  1
    order_2_12  fixed_segment_relative_order_1608  1
    order_2_12  fixed_segment_relative_order_1609  -1
    visit_2_13  out_degree_1552  -1
    visit_2_13  in_degree_1553  -1
    visit_2_13  order_active_lb_1554  -1
    visit_2_13  order_active_ub_1555  -12
    order_2_13  connected_order_arc_1259  1
    order_2_13  connected_order_arc_1282  1
    order_2_13  connected_order_arc_1305  1
    order_2_13  connected_order_arc_1324  -1
    order_2_13  connected_order_arc_1326  -1
    order_2_13  connected_order_arc_1328  -1
    order_2_13  connected_order_arc_1330  -1
    order_2_13  connected_order_arc_1332  -1
    order_2_13  connected_order_arc_1334  -1
    order_2_13  connected_order_arc_1336  -1
    order_2_13  connected_order_arc_1338  -1
    order_2_13  connected_order_arc_1340  -1
    order_2_13  connected_order_arc_1342  -1
    order_2_13  connected_order_arc_1344  -1
    order_2_13  connected_order_arc_1353  1
    order_2_13  connected_order_arc_1376  1
    order_2_13  connected_order_arc_1399  1
    order_2_13  connected_order_arc_1422  1
    order_2_13  connected_order_arc_1445  1
    order_2_13  connected_order_arc_1468  1
    order_2_13  connected_order_arc_1491  1
    order_2_13  connected_order_arc_1514  1
    order_2_13  order_active_lb_1554  1
    order_2_13  order_active_ub_1555  1
    order_2_13  fixed_segment_relative_order_1609  1
    visit_2_14  out_degree_1559  -1
    visit_2_14  in_degree_1560  -1
    visit_2_14  order_active_lb_1561  -1
    visit_2_14  order_active_ub_1562  -12
    visit_2_14  service_visit_def_1563  -1
    order_2_14  connected_order_arc_1261  1
    order_2_14  connected_order_arc_1284  1
    order_2_14  connected_order_arc_1307  1
    order_2_14  connected_order_arc_1330  1
    order_2_14  connected_order_arc_1347  -1
    order_2_14  connected_order_arc_1349  -1
    order_2_14  connected_order_arc_1351  -1
    order_2_14  connected_order_arc_1353  -1
    order_2_14  connected_order_arc_1355  -1
    order_2_14  connected_order_arc_1357  -1
    order_2_14  connected_order_arc_1359  -1
    order_2_14  connected_order_arc_1361  -1
    order_2_14  connected_order_arc_1363  -1
    order_2_14  connected_order_arc_1365  -1
    order_2_14  connected_order_arc_1367  -1
    order_2_14  connected_order_arc_1378  1
    order_2_14  connected_order_arc_1401  1
    order_2_14  connected_order_arc_1424  1
    order_2_14  connected_order_arc_1447  1
    order_2_14  connected_order_arc_1470  1
    order_2_14  connected_order_arc_1493  1
    order_2_14  connected_order_arc_1516  1
    order_2_14  order_active_lb_1561  1
    order_2_14  order_active_ub_1562  1
    visit_2_15  out_degree_1565  -1
    visit_2_15  in_degree_1566  -1
    visit_2_15  order_active_lb_1567  -1
    visit_2_15  order_active_ub_1568  -12
    visit_2_15  service_visit_def_1569  -1
    order_2_15  connected_order_arc_1263  1
    order_2_15  connected_order_arc_1286  1
    order_2_15  connected_order_arc_1309  1
    order_2_15  connected_order_arc_1332  1
    order_2_15  connected_order_arc_1355  1
    order_2_15  connected_order_arc_1370  -1
    order_2_15  connected_order_arc_1372  -1
    order_2_15  connected_order_arc_1374  -1
    order_2_15  connected_order_arc_1376  -1
    order_2_15  connected_order_arc_1378  -1
    order_2_15  connected_order_arc_1380  -1
    order_2_15  connected_order_arc_1382  -1
    order_2_15  connected_order_arc_1384  -1
    order_2_15  connected_order_arc_1386  -1
    order_2_15  connected_order_arc_1388  -1
    order_2_15  connected_order_arc_1390  -1
    order_2_15  connected_order_arc_1403  1
    order_2_15  connected_order_arc_1426  1
    order_2_15  connected_order_arc_1449  1
    order_2_15  connected_order_arc_1472  1
    order_2_15  connected_order_arc_1495  1
    order_2_15  connected_order_arc_1518  1
    order_2_15  order_active_lb_1567  1
    order_2_15  order_active_ub_1568  1
    visit_2_16  out_degree_1571  -1
    visit_2_16  in_degree_1572  -1
    visit_2_16  order_active_lb_1573  -1
    visit_2_16  order_active_ub_1574  -12
    visit_2_16  service_visit_def_1575  -1
    order_2_16  connected_order_arc_1265  1
    order_2_16  connected_order_arc_1288  1
    order_2_16  connected_order_arc_1311  1
    order_2_16  connected_order_arc_1334  1
    order_2_16  connected_order_arc_1357  1
    order_2_16  connected_order_arc_1380  1
    order_2_16  connected_order_arc_1393  -1
    order_2_16  connected_order_arc_1395  -1
    order_2_16  connected_order_arc_1397  -1
    order_2_16  connected_order_arc_1399  -1
    order_2_16  connected_order_arc_1401  -1
    order_2_16  connected_order_arc_1403  -1
    order_2_16  connected_order_arc_1405  -1
    order_2_16  connected_order_arc_1407  -1
    order_2_16  connected_order_arc_1409  -1
    order_2_16  connected_order_arc_1411  -1
    order_2_16  connected_order_arc_1413  -1
    order_2_16  connected_order_arc_1428  1
    order_2_16  connected_order_arc_1451  1
    order_2_16  connected_order_arc_1474  1
    order_2_16  connected_order_arc_1497  1
    order_2_16  connected_order_arc_1520  1
    order_2_16  order_active_lb_1573  1
    order_2_16  order_active_ub_1574  1
    visit_2_17  out_degree_1577  -1
    visit_2_17  in_degree_1578  -1
    visit_2_17  order_active_lb_1579  -1
    visit_2_17  order_active_ub_1580  -12
    visit_2_17  service_visit_def_1581  -1
    order_2_17  connected_order_arc_1267  1
    order_2_17  connected_order_arc_1290  1
    order_2_17  connected_order_arc_1313  1
    order_2_17  connected_order_arc_1336  1
    order_2_17  connected_order_arc_1359  1
    order_2_17  connected_order_arc_1382  1
    order_2_17  connected_order_arc_1405  1
    order_2_17  connected_order_arc_1416  -1
    order_2_17  connected_order_arc_1418  -1
    order_2_17  connected_order_arc_1420  -1
    order_2_17  connected_order_arc_1422  -1
    order_2_17  connected_order_arc_1424  -1
    order_2_17  connected_order_arc_1426  -1
    order_2_17  connected_order_arc_1428  -1
    order_2_17  connected_order_arc_1430  -1
    order_2_17  connected_order_arc_1432  -1
    order_2_17  connected_order_arc_1434  -1
    order_2_17  connected_order_arc_1436  -1
    order_2_17  connected_order_arc_1453  1
    order_2_17  connected_order_arc_1476  1
    order_2_17  connected_order_arc_1499  1
    order_2_17  connected_order_arc_1522  1
    order_2_17  order_active_lb_1579  1
    order_2_17  order_active_ub_1580  1
    visit_2_18  out_degree_1583  -1
    visit_2_18  in_degree_1584  -1
    visit_2_18  order_active_lb_1585  -1
    visit_2_18  order_active_ub_1586  -12
    visit_2_18  service_visit_def_1587  -1
    order_2_18  connected_order_arc_1269  1
    order_2_18  connected_order_arc_1292  1
    order_2_18  connected_order_arc_1315  1
    order_2_18  connected_order_arc_1338  1
    order_2_18  connected_order_arc_1361  1
    order_2_18  connected_order_arc_1384  1
    order_2_18  connected_order_arc_1407  1
    order_2_18  connected_order_arc_1430  1
    order_2_18  connected_order_arc_1439  -1
    order_2_18  connected_order_arc_1441  -1
    order_2_18  connected_order_arc_1443  -1
    order_2_18  connected_order_arc_1445  -1
    order_2_18  connected_order_arc_1447  -1
    order_2_18  connected_order_arc_1449  -1
    order_2_18  connected_order_arc_1451  -1
    order_2_18  connected_order_arc_1453  -1
    order_2_18  connected_order_arc_1455  -1
    order_2_18  connected_order_arc_1457  -1
    order_2_18  connected_order_arc_1459  -1
    order_2_18  connected_order_arc_1478  1
    order_2_18  connected_order_arc_1501  1
    order_2_18  connected_order_arc_1524  1
    order_2_18  order_active_lb_1585  1
    order_2_18  order_active_ub_1586  1
    visit_2_19  out_degree_1589  -1
    visit_2_19  in_degree_1590  -1
    visit_2_19  order_active_lb_1591  -1
    visit_2_19  order_active_ub_1592  -12
    visit_2_19  service_visit_def_1593  -1
    order_2_19  connected_order_arc_1271  1
    order_2_19  connected_order_arc_1294  1
    order_2_19  connected_order_arc_1317  1
    order_2_19  connected_order_arc_1340  1
    order_2_19  connected_order_arc_1363  1
    order_2_19  connected_order_arc_1386  1
    order_2_19  connected_order_arc_1409  1
    order_2_19  connected_order_arc_1432  1
    order_2_19  connected_order_arc_1455  1
    order_2_19  connected_order_arc_1462  -1
    order_2_19  connected_order_arc_1464  -1
    order_2_19  connected_order_arc_1466  -1
    order_2_19  connected_order_arc_1468  -1
    order_2_19  connected_order_arc_1470  -1
    order_2_19  connected_order_arc_1472  -1
    order_2_19  connected_order_arc_1474  -1
    order_2_19  connected_order_arc_1476  -1
    order_2_19  connected_order_arc_1478  -1
    order_2_19  connected_order_arc_1480  -1
    order_2_19  connected_order_arc_1482  -1
    order_2_19  connected_order_arc_1503  1
    order_2_19  connected_order_arc_1526  1
    order_2_19  order_active_lb_1591  1
    order_2_19  order_active_ub_1592  1
    visit_2_20  out_degree_1595  -1
    visit_2_20  in_degree_1596  -1
    visit_2_20  order_active_lb_1597  -1
    visit_2_20  order_active_ub_1598  -12
    visit_2_20  service_visit_def_1599  -1
    order_2_20  connected_order_arc_1273  1
    order_2_20  connected_order_arc_1296  1
    order_2_20  connected_order_arc_1319  1
    order_2_20  connected_order_arc_1342  1
    order_2_20  connected_order_arc_1365  1
    order_2_20  connected_order_arc_1388  1
    order_2_20  connected_order_arc_1411  1
    order_2_20  connected_order_arc_1434  1
    order_2_20  connected_order_arc_1457  1
    order_2_20  connected_order_arc_1480  1
    order_2_20  connected_order_arc_1485  -1
    order_2_20  connected_order_arc_1487  -1
    order_2_20  connected_order_arc_1489  -1
    order_2_20  connected_order_arc_1491  -1
    order_2_20  connected_order_arc_1493  -1
    order_2_20  connected_order_arc_1495  -1
    order_2_20  connected_order_arc_1497  -1
    order_2_20  connected_order_arc_1499  -1
    order_2_20  connected_order_arc_1501  -1
    order_2_20  connected_order_arc_1503  -1
    order_2_20  connected_order_arc_1505  -1
    order_2_20  connected_order_arc_1528  1
    order_2_20  order_active_lb_1597  1
    order_2_20  order_active_ub_1598  1
    visit_2_21  out_degree_1601  -1
    visit_2_21  in_degree_1602  -1
    visit_2_21  order_active_lb_1603  -1
    visit_2_21  order_active_ub_1604  -12
    visit_2_21  service_visit_def_1605  -1
    order_2_21  connected_order_arc_1275  1
    order_2_21  connected_order_arc_1298  1
    order_2_21  connected_order_arc_1321  1
    order_2_21  connected_order_arc_1344  1
    order_2_21  connected_order_arc_1367  1
    order_2_21  connected_order_arc_1390  1
    order_2_21  connected_order_arc_1413  1
    order_2_21  connected_order_arc_1436  1
    order_2_21  connected_order_arc_1459  1
    order_2_21  connected_order_arc_1482  1
    order_2_21  connected_order_arc_1505  1
    order_2_21  connected_order_arc_1508  -1
    order_2_21  connected_order_arc_1510  -1
    order_2_21  connected_order_arc_1512  -1
    order_2_21  connected_order_arc_1514  -1
    order_2_21  connected_order_arc_1516  -1
    order_2_21  connected_order_arc_1518  -1
    order_2_21  connected_order_arc_1520  -1
    order_2_21  connected_order_arc_1522  -1
    order_2_21  connected_order_arc_1524  -1
    order_2_21  connected_order_arc_1526  -1
    order_2_21  connected_order_arc_1528  -1
    order_2_21  order_active_lb_1603  1
    order_2_21  order_active_ub_1604  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1240  -30
    arc_2_0_0  depot_departure_or_bypass_1529  1
    arc_2_0_0  depot_return_or_bypass_1530  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1241  -30
    arc_2_0_10  depot_departure_or_bypass_1529  1
    arc_2_0_10  in_degree_1532  1
    arc_2_0_10  original_T_including_depot_unload_1610  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1241  1
    load_2_0_10  segment_load_conservation_1535  -1
    load_2_0_10  segment_prefix_lb_1536  1
    load_2_0_10  segment_prefix_ub_1537  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1242  -30
    arc_2_0_11  depot_departure_or_bypass_1529  1
    arc_2_0_11  in_degree_1539  1
    arc_2_0_11  original_T_including_depot_unload_1610  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1242  1
    load_2_0_11  segment_load_conservation_1542  -1
    load_2_0_11  segment_prefix_lb_1543  1
    load_2_0_11  segment_prefix_ub_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1243  -30
    arc_2_0_12  depot_departure_or_bypass_1529  1
    arc_2_0_12  in_degree_1546  1
    arc_2_0_12  original_T_including_depot_unload_1610  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1243  1
    load_2_0_12  segment_load_conservation_1549  -1
    load_2_0_12  segment_prefix_lb_1550  1
    load_2_0_12  segment_prefix_ub_1551  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1244  -30
    arc_2_0_13  depot_departure_or_bypass_1529  1
    arc_2_0_13  in_degree_1553  1
    arc_2_0_13  original_T_including_depot_unload_1610  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1244  1
    load_2_0_13  segment_load_conservation_1556  -1
    load_2_0_13  segment_prefix_lb_1557  1
    load_2_0_13  segment_prefix_ub_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1245  -30
    arc_2_0_14  depot_departure_or_bypass_1529  1
    arc_2_0_14  in_degree_1560  1
    arc_2_0_14  original_T_including_depot_unload_1610  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1245  1
    load_2_0_14  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1246  -30
    arc_2_0_15  depot_departure_or_bypass_1529  1
    arc_2_0_15  in_degree_1566  1
    arc_2_0_15  original_T_including_depot_unload_1610  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1246  1
    load_2_0_15  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1247  -30
    arc_2_0_16  depot_departure_or_bypass_1529  1
    arc_2_0_16  in_degree_1572  1
    arc_2_0_16  original_T_including_depot_unload_1610  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1247  1
    load_2_0_16  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1248  -30
    arc_2_0_17  depot_departure_or_bypass_1529  1
    arc_2_0_17  in_degree_1578  1
    arc_2_0_17  original_T_including_depot_unload_1610  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1248  1
    load_2_0_17  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1249  -30
    arc_2_0_18  depot_departure_or_bypass_1529  1
    arc_2_0_18  in_degree_1584  1
    arc_2_0_18  original_T_including_depot_unload_1610  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1249  1
    load_2_0_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1250  -30
    arc_2_0_19  depot_departure_or_bypass_1529  1
    arc_2_0_19  in_degree_1590  1
    arc_2_0_19  original_T_including_depot_unload_1610  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1250  1
    load_2_0_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1251  -30
    arc_2_0_20  depot_departure_or_bypass_1529  1
    arc_2_0_20  in_degree_1596  1
    arc_2_0_20  original_T_including_depot_unload_1610  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1251  1
    load_2_0_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1252  -30
    arc_2_0_21  depot_departure_or_bypass_1529  1
    arc_2_0_21  in_degree_1602  1
    arc_2_0_21  original_T_including_depot_unload_1610  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1252  1
    load_2_0_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1253  -30
    arc_2_10_0  depot_return_or_bypass_1530  1
    arc_2_10_0  out_degree_1531  1
    arc_2_10_0  original_T_including_depot_unload_1610  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1253  1
    load_2_10_0  segment_load_conservation_1535  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1254  -30
    arc_2_10_11  connected_order_arc_1255  -13
    arc_2_10_11  out_degree_1531  1
    arc_2_10_11  in_degree_1539  1
    arc_2_10_11  original_T_including_depot_unload_1610  1.2528205851183418e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1254  1
    load_2_10_11  segment_load_conservation_1535  1
    load_2_10_11  segment_load_conservation_1542  -1
    load_2_10_11  segment_prefix_lb_1543  1
    load_2_10_11  segment_prefix_ub_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1256  -30
    arc_2_10_12  connected_order_arc_1257  -13
    arc_2_10_12  out_degree_1531  1
    arc_2_10_12  in_degree_1546  1
    arc_2_10_12  original_T_including_depot_unload_1610  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1256  1
    load_2_10_12  segment_load_conservation_1535  1
    load_2_10_12  segment_load_conservation_1549  -1
    load_2_10_12  segment_prefix_lb_1550  1
    load_2_10_12  segment_prefix_ub_1551  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1258  -30
    arc_2_10_13  connected_order_arc_1259  -13
    arc_2_10_13  out_degree_1531  1
    arc_2_10_13  in_degree_1553  1
    arc_2_10_13  original_T_including_depot_unload_1610  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1258  1
    load_2_10_13  segment_load_conservation_1535  1
    load_2_10_13  segment_load_conservation_1556  -1
    load_2_10_13  segment_prefix_lb_1557  1
    load_2_10_13  segment_prefix_ub_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1260  -30
    arc_2_10_14  connected_order_arc_1261  -13
    arc_2_10_14  out_degree_1531  1
    arc_2_10_14  in_degree_1560  1
    arc_2_10_14  original_T_including_depot_unload_1610  1.0592524244968324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1260  1
    load_2_10_14  segment_load_conservation_1535  1
    load_2_10_14  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1262  -30
    arc_2_10_15  connected_order_arc_1263  -13
    arc_2_10_15  out_degree_1531  1
    arc_2_10_15  in_degree_1566  1
    arc_2_10_15  original_T_including_depot_unload_1610  1.0363003610648061e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1262  1
    load_2_10_15  segment_load_conservation_1535  1
    load_2_10_15  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1264  -30
    arc_2_10_16  connected_order_arc_1265  -13
    arc_2_10_16  out_degree_1531  1
    arc_2_10_16  in_degree_1572  1
    arc_2_10_16  original_T_including_depot_unload_1610  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1264  1
    load_2_10_16  segment_load_conservation_1535  1
    load_2_10_16  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1266  -30
    arc_2_10_17  connected_order_arc_1267  -13
    arc_2_10_17  out_degree_1531  1
    arc_2_10_17  in_degree_1578  1
    arc_2_10_17  original_T_including_depot_unload_1610  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1266  1
    load_2_10_17  segment_load_conservation_1535  1
    load_2_10_17  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1268  -30
    arc_2_10_18  connected_order_arc_1269  -13
    arc_2_10_18  out_degree_1531  1
    arc_2_10_18  in_degree_1584  1
    arc_2_10_18  original_T_including_depot_unload_1610  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1268  1
    load_2_10_18  segment_load_conservation_1535  1
    load_2_10_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1270  -30
    arc_2_10_19  connected_order_arc_1271  -13
    arc_2_10_19  out_degree_1531  1
    arc_2_10_19  in_degree_1590  1
    arc_2_10_19  original_T_including_depot_unload_1610  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1270  1
    load_2_10_19  segment_load_conservation_1535  1
    load_2_10_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1272  -30
    arc_2_10_20  connected_order_arc_1273  -13
    arc_2_10_20  out_degree_1531  1
    arc_2_10_20  in_degree_1596  1
    arc_2_10_20  original_T_including_depot_unload_1610  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1272  1
    load_2_10_20  segment_load_conservation_1535  1
    load_2_10_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_21  arc_capacity_1274  -30
    arc_2_10_21  connected_order_arc_1275  -13
    arc_2_10_21  out_degree_1531  1
    arc_2_10_21  in_degree_1602  1
    arc_2_10_21  original_T_including_depot_unload_1610  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_21  arc_capacity_1274  1
    load_2_10_21  segment_load_conservation_1535  1
    load_2_10_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1276  -30
    arc_2_11_0  depot_return_or_bypass_1530  1
    arc_2_11_0  out_degree_1538  1
    arc_2_11_0  original_T_including_depot_unload_1610  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1276  1
    load_2_11_0  segment_load_conservation_1542  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1277  -30
    arc_2_11_10  connected_order_arc_1278  -13
    arc_2_11_10  in_degree_1532  1
    arc_2_11_10  out_degree_1538  1
    arc_2_11_10  original_T_including_depot_unload_1610  1.1077505469776054e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1277  1
    load_2_11_10  segment_load_conservation_1535  -1
    load_2_11_10  segment_prefix_lb_1536  1
    load_2_11_10  segment_prefix_ub_1537  1
    load_2_11_10  segment_load_conservation_1542  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1279  -30
    arc_2_11_12  connected_order_arc_1280  -13
    arc_2_11_12  out_degree_1538  1
    arc_2_11_12  in_degree_1546  1
    arc_2_11_12  original_T_including_depot_unload_1610  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1279  1
    load_2_11_12  segment_load_conservation_1542  1
    load_2_11_12  segment_load_conservation_1549  -1
    load_2_11_12  segment_prefix_lb_1550  1
    load_2_11_12  segment_prefix_ub_1551  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1281  -30
    arc_2_11_13  connected_order_arc_1282  -13
    arc_2_11_13  out_degree_1538  1
    arc_2_11_13  in_degree_1553  1
    arc_2_11_13  original_T_including_depot_unload_1610  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1281  1
    load_2_11_13  segment_load_conservation_1542  1
    load_2_11_13  segment_load_conservation_1556  -1
    load_2_11_13  segment_prefix_lb_1557  1
    load_2_11_13  segment_prefix_ub_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1283  -30
    arc_2_11_14  connected_order_arc_1284  -13
    arc_2_11_14  out_degree_1538  1
    arc_2_11_14  in_degree_1560  1
    arc_2_11_14  original_T_including_depot_unload_1610  1.9853708143200565e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1283  1
    load_2_11_14  segment_load_conservation_1542  1
    load_2_11_14  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1285  -30
    arc_2_11_15  connected_order_arc_1286  -13
    arc_2_11_15  out_degree_1538  1
    arc_2_11_15  in_degree_1566  1
    arc_2_11_15  original_T_including_depot_unload_1610  2184.10509638866
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1285  1
    load_2_11_15  segment_load_conservation_1542  1
    load_2_11_15  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1287  -30
    arc_2_11_16  connected_order_arc_1288  -13
    arc_2_11_16  out_degree_1538  1
    arc_2_11_16  in_degree_1572  1
    arc_2_11_16  original_T_including_depot_unload_1610  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1287  1
    load_2_11_16  segment_load_conservation_1542  1
    load_2_11_16  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1289  -30
    arc_2_11_17  connected_order_arc_1290  -13
    arc_2_11_17  out_degree_1538  1
    arc_2_11_17  in_degree_1578  1
    arc_2_11_17  original_T_including_depot_unload_1610  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1289  1
    load_2_11_17  segment_load_conservation_1542  1
    load_2_11_17  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1291  -30
    arc_2_11_18  connected_order_arc_1292  -13
    arc_2_11_18  out_degree_1538  1
    arc_2_11_18  in_degree_1584  1
    arc_2_11_18  original_T_including_depot_unload_1610  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1291  1
    load_2_11_18  segment_load_conservation_1542  1
    load_2_11_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1293  -30
    arc_2_11_19  connected_order_arc_1294  -13
    arc_2_11_19  out_degree_1538  1
    arc_2_11_19  in_degree_1590  1
    arc_2_11_19  original_T_including_depot_unload_1610  1.6185675384860760e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1293  1
    load_2_11_19  segment_load_conservation_1542  1
    load_2_11_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1295  -30
    arc_2_11_20  connected_order_arc_1296  -13
    arc_2_11_20  out_degree_1538  1
    arc_2_11_20  in_degree_1596  1
    arc_2_11_20  original_T_including_depot_unload_1610  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1295  1
    load_2_11_20  segment_load_conservation_1542  1
    load_2_11_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1297  -30
    arc_2_11_21  connected_order_arc_1298  -13
    arc_2_11_21  out_degree_1538  1
    arc_2_11_21  in_degree_1602  1
    arc_2_11_21  original_T_including_depot_unload_1610  1.3279253844180159e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1297  1
    load_2_11_21  segment_load_conservation_1542  1
    load_2_11_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1299  -30
    arc_2_12_0  depot_return_or_bypass_1530  1
    arc_2_12_0  out_degree_1545  1
    arc_2_12_0  original_T_including_depot_unload_1610  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1299  1
    load_2_12_0  segment_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1300  -30
    arc_2_12_10  connected_order_arc_1301  -13
    arc_2_12_10  in_degree_1532  1
    arc_2_12_10  out_degree_1545  1
    arc_2_12_10  original_T_including_depot_unload_1610  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1300  1
    load_2_12_10  segment_load_conservation_1535  -1
    load_2_12_10  segment_prefix_lb_1536  1
    load_2_12_10  segment_prefix_ub_1537  1
    load_2_12_10  segment_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1302  -30
    arc_2_12_11  connected_order_arc_1303  -13
    arc_2_12_11  in_degree_1539  1
    arc_2_12_11  out_degree_1545  1
    arc_2_12_11  original_T_including_depot_unload_1610  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1302  1
    load_2_12_11  segment_load_conservation_1542  -1
    load_2_12_11  segment_prefix_lb_1543  1
    load_2_12_11  segment_prefix_ub_1544  1
    load_2_12_11  segment_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1304  -30
    arc_2_12_13  connected_order_arc_1305  -13
    arc_2_12_13  out_degree_1545  1
    arc_2_12_13  in_degree_1553  1
    arc_2_12_13  original_T_including_depot_unload_1610  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1304  1
    load_2_12_13  segment_load_conservation_1549  1
    load_2_12_13  segment_load_conservation_1556  -1
    load_2_12_13  segment_prefix_lb_1557  1
    load_2_12_13  segment_prefix_ub_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1306  -30
    arc_2_12_14  connected_order_arc_1307  -13
    arc_2_12_14  out_degree_1545  1
    arc_2_12_14  in_degree_1560  1
    arc_2_12_14  original_T_including_depot_unload_1610  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1306  1
    load_2_12_14  segment_load_conservation_1549  1
    load_2_12_14  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1308  -30
    arc_2_12_15  connected_order_arc_1309  -13
    arc_2_12_15  out_degree_1545  1
    arc_2_12_15  in_degree_1566  1
    arc_2_12_15  original_T_including_depot_unload_1610  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1308  1
    load_2_12_15  segment_load_conservation_1549  1
    load_2_12_15  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1310  -30
    arc_2_12_16  connected_order_arc_1311  -13
    arc_2_12_16  out_degree_1545  1
    arc_2_12_16  in_degree_1572  1
    arc_2_12_16  original_T_including_depot_unload_1610  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1310  1
    load_2_12_16  segment_load_conservation_1549  1
    load_2_12_16  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1312  -30
    arc_2_12_17  connected_order_arc_1313  -13
    arc_2_12_17  out_degree_1545  1
    arc_2_12_17  in_degree_1578  1
    arc_2_12_17  original_T_including_depot_unload_1610  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1312  1
    load_2_12_17  segment_load_conservation_1549  1
    load_2_12_17  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1314  -30
    arc_2_12_18  connected_order_arc_1315  -13
    arc_2_12_18  out_degree_1545  1
    arc_2_12_18  in_degree_1584  1
    arc_2_12_18  original_T_including_depot_unload_1610  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1314  1
    load_2_12_18  segment_load_conservation_1549  1
    load_2_12_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1316  -30
    arc_2_12_19  connected_order_arc_1317  -13
    arc_2_12_19  out_degree_1545  1
    arc_2_12_19  in_degree_1590  1
    arc_2_12_19  original_T_including_depot_unload_1610  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1316  1
    load_2_12_19  segment_load_conservation_1549  1
    load_2_12_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1318  -30
    arc_2_12_20  connected_order_arc_1319  -13
    arc_2_12_20  out_degree_1545  1
    arc_2_12_20  in_degree_1596  1
    arc_2_12_20  original_T_including_depot_unload_1610  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1318  1
    load_2_12_20  segment_load_conservation_1549  1
    load_2_12_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1320  -30
    arc_2_12_21  connected_order_arc_1321  -13
    arc_2_12_21  out_degree_1545  1
    arc_2_12_21  in_degree_1602  1
    arc_2_12_21  original_T_including_depot_unload_1610  1.5086201853425566e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1320  1
    load_2_12_21  segment_load_conservation_1549  1
    load_2_12_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1322  -30
    arc_2_13_0  depot_return_or_bypass_1530  1
    arc_2_13_0  out_degree_1552  1
    arc_2_13_0  original_T_including_depot_unload_1610  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1322  1
    load_2_13_0  segment_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1323  -30
    arc_2_13_10  connected_order_arc_1324  -13
    arc_2_13_10  in_degree_1532  1
    arc_2_13_10  out_degree_1552  1
    arc_2_13_10  original_T_including_depot_unload_1610  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1323  1
    load_2_13_10  segment_load_conservation_1535  -1
    load_2_13_10  segment_prefix_lb_1536  1
    load_2_13_10  segment_prefix_ub_1537  1
    load_2_13_10  segment_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1325  -30
    arc_2_13_11  connected_order_arc_1326  -13
    arc_2_13_11  in_degree_1539  1
    arc_2_13_11  out_degree_1552  1
    arc_2_13_11  original_T_including_depot_unload_1610  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1325  1
    load_2_13_11  segment_load_conservation_1542  -1
    load_2_13_11  segment_prefix_lb_1543  1
    load_2_13_11  segment_prefix_ub_1544  1
    load_2_13_11  segment_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1327  -30
    arc_2_13_12  connected_order_arc_1328  -13
    arc_2_13_12  in_degree_1546  1
    arc_2_13_12  out_degree_1552  1
    arc_2_13_12  original_T_including_depot_unload_1610  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1327  1
    load_2_13_12  segment_load_conservation_1549  -1
    load_2_13_12  segment_prefix_lb_1550  1
    load_2_13_12  segment_prefix_ub_1551  1
    load_2_13_12  segment_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1329  -30
    arc_2_13_14  connected_order_arc_1330  -13
    arc_2_13_14  out_degree_1552  1
    arc_2_13_14  in_degree_1560  1
    arc_2_13_14  original_T_including_depot_unload_1610  1.5757088859257728e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1329  1
    load_2_13_14  segment_load_conservation_1556  1
    load_2_13_14  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1331  -30
    arc_2_13_15  connected_order_arc_1332  -13
    arc_2_13_15  out_degree_1552  1
    arc_2_13_15  in_degree_1566  1
    arc_2_13_15  original_T_including_depot_unload_1610  1.4593103211867947e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1331  1
    load_2_13_15  segment_load_conservation_1556  1
    load_2_13_15  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1333  -30
    arc_2_13_16  connected_order_arc_1334  -13
    arc_2_13_16  out_degree_1552  1
    arc_2_13_16  in_degree_1572  1
    arc_2_13_16  original_T_including_depot_unload_1610  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1333  1
    load_2_13_16  segment_load_conservation_1556  1
    load_2_13_16  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1335  -30
    arc_2_13_17  connected_order_arc_1336  -13
    arc_2_13_17  out_degree_1552  1
    arc_2_13_17  in_degree_1578  1
    arc_2_13_17  original_T_including_depot_unload_1610  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1335  1
    load_2_13_17  segment_load_conservation_1556  1
    load_2_13_17  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1337  -30
    arc_2_13_18  connected_order_arc_1338  -13
    arc_2_13_18  out_degree_1552  1
    arc_2_13_18  in_degree_1584  1
    arc_2_13_18  original_T_including_depot_unload_1610  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1337  1
    load_2_13_18  segment_load_conservation_1556  1
    load_2_13_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1339  -30
    arc_2_13_19  connected_order_arc_1340  -13
    arc_2_13_19  out_degree_1552  1
    arc_2_13_19  in_degree_1590  1
    arc_2_13_19  original_T_including_depot_unload_1610  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1339  1
    load_2_13_19  segment_load_conservation_1556  1
    load_2_13_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1341  -30
    arc_2_13_20  connected_order_arc_1342  -13
    arc_2_13_20  out_degree_1552  1
    arc_2_13_20  in_degree_1596  1
    arc_2_13_20  original_T_including_depot_unload_1610  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1341  1
    load_2_13_20  segment_load_conservation_1556  1
    load_2_13_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1343  -30
    arc_2_13_21  connected_order_arc_1344  -13
    arc_2_13_21  out_degree_1552  1
    arc_2_13_21  in_degree_1602  1
    arc_2_13_21  original_T_including_depot_unload_1610  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1343  1
    load_2_13_21  segment_load_conservation_1556  1
    load_2_13_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1345  -30
    arc_2_14_0  depot_return_or_bypass_1530  1
    arc_2_14_0  out_degree_1559  1
    arc_2_14_0  original_T_including_depot_unload_1610  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1345  1
    load_2_14_0  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1346  -30
    arc_2_14_10  connected_order_arc_1347  -13
    arc_2_14_10  in_degree_1532  1
    arc_2_14_10  out_degree_1559  1
    arc_2_14_10  original_T_including_depot_unload_1610  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1346  1
    load_2_14_10  segment_load_conservation_1535  -1
    load_2_14_10  segment_prefix_lb_1536  1
    load_2_14_10  segment_prefix_ub_1537  1
    load_2_14_10  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1348  -30
    arc_2_14_11  connected_order_arc_1349  -13
    arc_2_14_11  in_degree_1539  1
    arc_2_14_11  out_degree_1559  1
    arc_2_14_11  original_T_including_depot_unload_1610  1.9853708143200565e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1348  1
    load_2_14_11  segment_load_conservation_1542  -1
    load_2_14_11  segment_prefix_lb_1543  1
    load_2_14_11  segment_prefix_ub_1544  1
    load_2_14_11  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1350  -30
    arc_2_14_12  connected_order_arc_1351  -13
    arc_2_14_12  in_degree_1546  1
    arc_2_14_12  out_degree_1559  1
    arc_2_14_12  original_T_including_depot_unload_1610  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1350  1
    load_2_14_12  segment_load_conservation_1549  -1
    load_2_14_12  segment_prefix_lb_1550  1
    load_2_14_12  segment_prefix_ub_1551  1
    load_2_14_12  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1352  -30
    arc_2_14_13  connected_order_arc_1353  -13
    arc_2_14_13  in_degree_1553  1
    arc_2_14_13  out_degree_1559  1
    arc_2_14_13  original_T_including_depot_unload_1610  1.5757088859257728e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1352  1
    load_2_14_13  segment_load_conservation_1556  -1
    load_2_14_13  segment_prefix_lb_1557  1
    load_2_14_13  segment_prefix_ub_1558  1
    load_2_14_13  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1354  -30
    arc_2_14_15  connected_order_arc_1355  -13
    arc_2_14_15  out_degree_1559  1
    arc_2_14_15  in_degree_1566  1
    arc_2_14_15  original_T_including_depot_unload_1610  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1354  1
    load_2_14_15  free_load_conservation_1564  1
    load_2_14_15  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1356  -30
    arc_2_14_16  connected_order_arc_1357  -13
    arc_2_14_16  out_degree_1559  1
    arc_2_14_16  in_degree_1572  1
    arc_2_14_16  original_T_including_depot_unload_1610  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1356  1
    load_2_14_16  free_load_conservation_1564  1
    load_2_14_16  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1358  -30
    arc_2_14_17  connected_order_arc_1359  -13
    arc_2_14_17  out_degree_1559  1
    arc_2_14_17  in_degree_1578  1
    arc_2_14_17  original_T_including_depot_unload_1610  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1358  1
    load_2_14_17  free_load_conservation_1564  1
    load_2_14_17  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1360  -30
    arc_2_14_18  connected_order_arc_1361  -13
    arc_2_14_18  out_degree_1559  1
    arc_2_14_18  in_degree_1584  1
    arc_2_14_18  original_T_including_depot_unload_1610  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1360  1
    load_2_14_18  free_load_conservation_1564  1
    load_2_14_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1362  -30
    arc_2_14_19  connected_order_arc_1363  -13
    arc_2_14_19  out_degree_1559  1
    arc_2_14_19  in_degree_1590  1
    arc_2_14_19  original_T_including_depot_unload_1610  7.6789230776331749e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1362  1
    load_2_14_19  free_load_conservation_1564  1
    load_2_14_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1364  -30
    arc_2_14_20  connected_order_arc_1365  -13
    arc_2_14_20  out_degree_1559  1
    arc_2_14_20  in_degree_1596  1
    arc_2_14_20  original_T_including_depot_unload_1610  1.4688211749637876e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1364  1
    load_2_14_20  free_load_conservation_1564  1
    load_2_14_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1366  -30
    arc_2_14_21  connected_order_arc_1367  -13
    arc_2_14_21  out_degree_1559  1
    arc_2_14_21  in_degree_1602  1
    arc_2_14_21  original_T_including_depot_unload_1610  8.2066682484686987e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1366  1
    load_2_14_21  free_load_conservation_1564  1
    load_2_14_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1368  -30
    arc_2_15_0  depot_return_or_bypass_1530  1
    arc_2_15_0  out_degree_1565  1
    arc_2_15_0  original_T_including_depot_unload_1610  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1368  1
    load_2_15_0  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1369  -30
    arc_2_15_10  connected_order_arc_1370  -13
    arc_2_15_10  in_degree_1532  1
    arc_2_15_10  out_degree_1565  1
    arc_2_15_10  original_T_including_depot_unload_1610  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1369  1
    load_2_15_10  segment_load_conservation_1535  -1
    load_2_15_10  segment_prefix_lb_1536  1
    load_2_15_10  segment_prefix_ub_1537  1
    load_2_15_10  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1371  -30
    arc_2_15_11  connected_order_arc_1372  -13
    arc_2_15_11  in_degree_1539  1
    arc_2_15_11  out_degree_1565  1
    arc_2_15_11  original_T_including_depot_unload_1610  2184.10509638866
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1371  1
    load_2_15_11  segment_load_conservation_1542  -1
    load_2_15_11  segment_prefix_lb_1543  1
    load_2_15_11  segment_prefix_ub_1544  1
    load_2_15_11  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1373  -30
    arc_2_15_12  connected_order_arc_1374  -13
    arc_2_15_12  in_degree_1546  1
    arc_2_15_12  out_degree_1565  1
    arc_2_15_12  original_T_including_depot_unload_1610  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1373  1
    load_2_15_12  segment_load_conservation_1549  -1
    load_2_15_12  segment_prefix_lb_1550  1
    load_2_15_12  segment_prefix_ub_1551  1
    load_2_15_12  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1375  -30
    arc_2_15_13  connected_order_arc_1376  -13
    arc_2_15_13  in_degree_1553  1
    arc_2_15_13  out_degree_1565  1
    arc_2_15_13  original_T_including_depot_unload_1610  1.4593103211867947e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1375  1
    load_2_15_13  segment_load_conservation_1556  -1
    load_2_15_13  segment_prefix_lb_1557  1
    load_2_15_13  segment_prefix_ub_1558  1
    load_2_15_13  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1377  -30
    arc_2_15_14  connected_order_arc_1378  -13
    arc_2_15_14  in_degree_1560  1
    arc_2_15_14  out_degree_1565  1
    arc_2_15_14  original_T_including_depot_unload_1610  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1377  1
    load_2_15_14  free_load_conservation_1564  -1
    load_2_15_14  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1379  -30
    arc_2_15_16  connected_order_arc_1380  -13
    arc_2_15_16  out_degree_1565  1
    arc_2_15_16  in_degree_1572  1
    arc_2_15_16  original_T_including_depot_unload_1610  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1379  1
    load_2_15_16  free_load_conservation_1570  1
    load_2_15_16  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1381  -30
    arc_2_15_17  connected_order_arc_1382  -13
    arc_2_15_17  out_degree_1565  1
    arc_2_15_17  in_degree_1578  1
    arc_2_15_17  original_T_including_depot_unload_1610  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1381  1
    load_2_15_17  free_load_conservation_1570  1
    load_2_15_17  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1383  -30
    arc_2_15_18  connected_order_arc_1384  -13
    arc_2_15_18  out_degree_1565  1
    arc_2_15_18  in_degree_1584  1
    arc_2_15_18  original_T_including_depot_unload_1610  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1383  1
    load_2_15_18  free_load_conservation_1570  1
    load_2_15_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1385  -30
    arc_2_15_19  connected_order_arc_1386  -13
    arc_2_15_19  out_degree_1565  1
    arc_2_15_19  in_degree_1590  1
    arc_2_15_19  original_T_including_depot_unload_1610  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1385  1
    load_2_15_19  free_load_conservation_1570  1
    load_2_15_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1387  -30
    arc_2_15_20  connected_order_arc_1388  -13
    arc_2_15_20  out_degree_1565  1
    arc_2_15_20  in_degree_1596  1
    arc_2_15_20  original_T_including_depot_unload_1610  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1387  1
    load_2_15_20  free_load_conservation_1570  1
    load_2_15_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1389  -30
    arc_2_15_21  connected_order_arc_1390  -13
    arc_2_15_21  out_degree_1565  1
    arc_2_15_21  in_degree_1602  1
    arc_2_15_21  original_T_including_depot_unload_1610  8.6958069185371107e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1389  1
    load_2_15_21  free_load_conservation_1570  1
    load_2_15_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1391  -30
    arc_2_16_0  depot_return_or_bypass_1530  1
    arc_2_16_0  out_degree_1571  1
    arc_2_16_0  original_T_including_depot_unload_1610  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1391  1
    load_2_16_0  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1392  -30
    arc_2_16_10  connected_order_arc_1393  -13
    arc_2_16_10  in_degree_1532  1
    arc_2_16_10  out_degree_1571  1
    arc_2_16_10  original_T_including_depot_unload_1610  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1392  1
    load_2_16_10  segment_load_conservation_1535  -1
    load_2_16_10  segment_prefix_lb_1536  1
    load_2_16_10  segment_prefix_ub_1537  1
    load_2_16_10  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1394  -30
    arc_2_16_11  connected_order_arc_1395  -13
    arc_2_16_11  in_degree_1539  1
    arc_2_16_11  out_degree_1571  1
    arc_2_16_11  original_T_including_depot_unload_1610  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1394  1
    load_2_16_11  segment_load_conservation_1542  -1
    load_2_16_11  segment_prefix_lb_1543  1
    load_2_16_11  segment_prefix_ub_1544  1
    load_2_16_11  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1396  -30
    arc_2_16_12  connected_order_arc_1397  -13
    arc_2_16_12  in_degree_1546  1
    arc_2_16_12  out_degree_1571  1
    arc_2_16_12  original_T_including_depot_unload_1610  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1396  1
    load_2_16_12  segment_load_conservation_1549  -1
    load_2_16_12  segment_prefix_lb_1550  1
    load_2_16_12  segment_prefix_ub_1551  1
    load_2_16_12  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1398  -30
    arc_2_16_13  connected_order_arc_1399  -13
    arc_2_16_13  in_degree_1553  1
    arc_2_16_13  out_degree_1571  1
    arc_2_16_13  original_T_including_depot_unload_1610  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1398  1
    load_2_16_13  segment_load_conservation_1556  -1
    load_2_16_13  segment_prefix_lb_1557  1
    load_2_16_13  segment_prefix_ub_1558  1
    load_2_16_13  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1400  -30
    arc_2_16_14  connected_order_arc_1401  -13
    arc_2_16_14  in_degree_1560  1
    arc_2_16_14  out_degree_1571  1
    arc_2_16_14  original_T_including_depot_unload_1610  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1400  1
    load_2_16_14  free_load_conservation_1564  -1
    load_2_16_14  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1402  -30
    arc_2_16_15  connected_order_arc_1403  -13
    arc_2_16_15  in_degree_1566  1
    arc_2_16_15  out_degree_1571  1
    arc_2_16_15  original_T_including_depot_unload_1610  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1402  1
    load_2_16_15  free_load_conservation_1570  -1
    load_2_16_15  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1404  -30
    arc_2_16_17  connected_order_arc_1405  -13
    arc_2_16_17  out_degree_1571  1
    arc_2_16_17  in_degree_1578  1
    arc_2_16_17  original_T_including_depot_unload_1610  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1404  1
    load_2_16_17  free_load_conservation_1576  1
    load_2_16_17  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1406  -30
    arc_2_16_18  connected_order_arc_1407  -13
    arc_2_16_18  out_degree_1571  1
    arc_2_16_18  in_degree_1584  1
    arc_2_16_18  original_T_including_depot_unload_1610  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1406  1
    load_2_16_18  free_load_conservation_1576  1
    load_2_16_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1408  -30
    arc_2_16_19  connected_order_arc_1409  -13
    arc_2_16_19  out_degree_1571  1
    arc_2_16_19  in_degree_1590  1
    arc_2_16_19  original_T_including_depot_unload_1610  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1408  1
    load_2_16_19  free_load_conservation_1576  1
    load_2_16_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1410  -30
    arc_2_16_20  connected_order_arc_1411  -13
    arc_2_16_20  out_degree_1571  1
    arc_2_16_20  in_degree_1596  1
    arc_2_16_20  original_T_including_depot_unload_1610  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1410  1
    load_2_16_20  free_load_conservation_1576  1
    load_2_16_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1412  -30
    arc_2_16_21  connected_order_arc_1413  -13
    arc_2_16_21  out_degree_1571  1
    arc_2_16_21  in_degree_1602  1
    arc_2_16_21  original_T_including_depot_unload_1610  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1412  1
    load_2_16_21  free_load_conservation_1576  1
    load_2_16_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1414  -30
    arc_2_17_0  depot_return_or_bypass_1530  1
    arc_2_17_0  out_degree_1577  1
    arc_2_17_0  original_T_including_depot_unload_1610  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1414  1
    load_2_17_0  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1415  -30
    arc_2_17_10  connected_order_arc_1416  -13
    arc_2_17_10  in_degree_1532  1
    arc_2_17_10  out_degree_1577  1
    arc_2_17_10  original_T_including_depot_unload_1610  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1415  1
    load_2_17_10  segment_load_conservation_1535  -1
    load_2_17_10  segment_prefix_lb_1536  1
    load_2_17_10  segment_prefix_ub_1537  1
    load_2_17_10  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1417  -30
    arc_2_17_11  connected_order_arc_1418  -13
    arc_2_17_11  in_degree_1539  1
    arc_2_17_11  out_degree_1577  1
    arc_2_17_11  original_T_including_depot_unload_1610  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1417  1
    load_2_17_11  segment_load_conservation_1542  -1
    load_2_17_11  segment_prefix_lb_1543  1
    load_2_17_11  segment_prefix_ub_1544  1
    load_2_17_11  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1419  -30
    arc_2_17_12  connected_order_arc_1420  -13
    arc_2_17_12  in_degree_1546  1
    arc_2_17_12  out_degree_1577  1
    arc_2_17_12  original_T_including_depot_unload_1610  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1419  1
    load_2_17_12  segment_load_conservation_1549  -1
    load_2_17_12  segment_prefix_lb_1550  1
    load_2_17_12  segment_prefix_ub_1551  1
    load_2_17_12  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1421  -30
    arc_2_17_13  connected_order_arc_1422  -13
    arc_2_17_13  in_degree_1553  1
    arc_2_17_13  out_degree_1577  1
    arc_2_17_13  original_T_including_depot_unload_1610  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1421  1
    load_2_17_13  segment_load_conservation_1556  -1
    load_2_17_13  segment_prefix_lb_1557  1
    load_2_17_13  segment_prefix_ub_1558  1
    load_2_17_13  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1423  -30
    arc_2_17_14  connected_order_arc_1424  -13
    arc_2_17_14  in_degree_1560  1
    arc_2_17_14  out_degree_1577  1
    arc_2_17_14  original_T_including_depot_unload_1610  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1423  1
    load_2_17_14  free_load_conservation_1564  -1
    load_2_17_14  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1425  -30
    arc_2_17_15  connected_order_arc_1426  -13
    arc_2_17_15  in_degree_1566  1
    arc_2_17_15  out_degree_1577  1
    arc_2_17_15  original_T_including_depot_unload_1610  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1425  1
    load_2_17_15  free_load_conservation_1570  -1
    load_2_17_15  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1427  -30
    arc_2_17_16  connected_order_arc_1428  -13
    arc_2_17_16  in_degree_1572  1
    arc_2_17_16  out_degree_1577  1
    arc_2_17_16  original_T_including_depot_unload_1610  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1427  1
    load_2_17_16  free_load_conservation_1576  -1
    load_2_17_16  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1429  -30
    arc_2_17_18  connected_order_arc_1430  -13
    arc_2_17_18  out_degree_1577  1
    arc_2_17_18  in_degree_1584  1
    arc_2_17_18  original_T_including_depot_unload_1610  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1429  1
    load_2_17_18  free_load_conservation_1582  1
    load_2_17_18  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1431  -30
    arc_2_17_19  connected_order_arc_1432  -13
    arc_2_17_19  out_degree_1577  1
    arc_2_17_19  in_degree_1590  1
    arc_2_17_19  original_T_including_depot_unload_1610  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1431  1
    load_2_17_19  free_load_conservation_1582  1
    load_2_17_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1433  -30
    arc_2_17_20  connected_order_arc_1434  -13
    arc_2_17_20  out_degree_1577  1
    arc_2_17_20  in_degree_1596  1
    arc_2_17_20  original_T_including_depot_unload_1610  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1433  1
    load_2_17_20  free_load_conservation_1582  1
    load_2_17_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1435  -30
    arc_2_17_21  connected_order_arc_1436  -13
    arc_2_17_21  out_degree_1577  1
    arc_2_17_21  in_degree_1602  1
    arc_2_17_21  original_T_including_depot_unload_1610  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1435  1
    load_2_17_21  free_load_conservation_1582  1
    load_2_17_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1437  -30
    arc_2_18_0  depot_return_or_bypass_1530  1
    arc_2_18_0  out_degree_1583  1
    arc_2_18_0  original_T_including_depot_unload_1610  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1437  1
    load_2_18_0  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1438  -30
    arc_2_18_10  connected_order_arc_1439  -13
    arc_2_18_10  in_degree_1532  1
    arc_2_18_10  out_degree_1583  1
    arc_2_18_10  original_T_including_depot_unload_1610  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1438  1
    load_2_18_10  segment_load_conservation_1535  -1
    load_2_18_10  segment_prefix_lb_1536  1
    load_2_18_10  segment_prefix_ub_1537  1
    load_2_18_10  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1440  -30
    arc_2_18_11  connected_order_arc_1441  -13
    arc_2_18_11  in_degree_1539  1
    arc_2_18_11  out_degree_1583  1
    arc_2_18_11  original_T_including_depot_unload_1610  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1440  1
    load_2_18_11  segment_load_conservation_1542  -1
    load_2_18_11  segment_prefix_lb_1543  1
    load_2_18_11  segment_prefix_ub_1544  1
    load_2_18_11  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1442  -30
    arc_2_18_12  connected_order_arc_1443  -13
    arc_2_18_12  in_degree_1546  1
    arc_2_18_12  out_degree_1583  1
    arc_2_18_12  original_T_including_depot_unload_1610  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1442  1
    load_2_18_12  segment_load_conservation_1549  -1
    load_2_18_12  segment_prefix_lb_1550  1
    load_2_18_12  segment_prefix_ub_1551  1
    load_2_18_12  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1444  -30
    arc_2_18_13  connected_order_arc_1445  -13
    arc_2_18_13  in_degree_1553  1
    arc_2_18_13  out_degree_1583  1
    arc_2_18_13  original_T_including_depot_unload_1610  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1444  1
    load_2_18_13  segment_load_conservation_1556  -1
    load_2_18_13  segment_prefix_lb_1557  1
    load_2_18_13  segment_prefix_ub_1558  1
    load_2_18_13  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1446  -30
    arc_2_18_14  connected_order_arc_1447  -13
    arc_2_18_14  in_degree_1560  1
    arc_2_18_14  out_degree_1583  1
    arc_2_18_14  original_T_including_depot_unload_1610  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1446  1
    load_2_18_14  free_load_conservation_1564  -1
    load_2_18_14  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1448  -30
    arc_2_18_15  connected_order_arc_1449  -13
    arc_2_18_15  in_degree_1566  1
    arc_2_18_15  out_degree_1583  1
    arc_2_18_15  original_T_including_depot_unload_1610  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1448  1
    load_2_18_15  free_load_conservation_1570  -1
    load_2_18_15  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1450  -30
    arc_2_18_16  connected_order_arc_1451  -13
    arc_2_18_16  in_degree_1572  1
    arc_2_18_16  out_degree_1583  1
    arc_2_18_16  original_T_including_depot_unload_1610  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1450  1
    load_2_18_16  free_load_conservation_1576  -1
    load_2_18_16  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1452  -30
    arc_2_18_17  connected_order_arc_1453  -13
    arc_2_18_17  in_degree_1578  1
    arc_2_18_17  out_degree_1583  1
    arc_2_18_17  original_T_including_depot_unload_1610  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1452  1
    load_2_18_17  free_load_conservation_1582  -1
    load_2_18_17  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1454  -30
    arc_2_18_19  connected_order_arc_1455  -13
    arc_2_18_19  out_degree_1583  1
    arc_2_18_19  in_degree_1590  1
    arc_2_18_19  original_T_including_depot_unload_1610  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1454  1
    load_2_18_19  free_load_conservation_1588  1
    load_2_18_19  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1456  -30
    arc_2_18_20  connected_order_arc_1457  -13
    arc_2_18_20  out_degree_1583  1
    arc_2_18_20  in_degree_1596  1
    arc_2_18_20  original_T_including_depot_unload_1610  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1456  1
    load_2_18_20  free_load_conservation_1588  1
    load_2_18_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1458  -30
    arc_2_18_21  connected_order_arc_1459  -13
    arc_2_18_21  out_degree_1583  1
    arc_2_18_21  in_degree_1602  1
    arc_2_18_21  original_T_including_depot_unload_1610  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1458  1
    load_2_18_21  free_load_conservation_1588  1
    load_2_18_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1460  -30
    arc_2_19_0  depot_return_or_bypass_1530  1
    arc_2_19_0  out_degree_1589  1
    arc_2_19_0  original_T_including_depot_unload_1610  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1460  1
    load_2_19_0  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1461  -30
    arc_2_19_10  connected_order_arc_1462  -13
    arc_2_19_10  in_degree_1532  1
    arc_2_19_10  out_degree_1589  1
    arc_2_19_10  original_T_including_depot_unload_1610  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1461  1
    load_2_19_10  segment_load_conservation_1535  -1
    load_2_19_10  segment_prefix_lb_1536  1
    load_2_19_10  segment_prefix_ub_1537  1
    load_2_19_10  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1463  -30
    arc_2_19_11  connected_order_arc_1464  -13
    arc_2_19_11  in_degree_1539  1
    arc_2_19_11  out_degree_1589  1
    arc_2_19_11  original_T_including_depot_unload_1610  1.6185675384860760e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1463  1
    load_2_19_11  segment_load_conservation_1542  -1
    load_2_19_11  segment_prefix_lb_1543  1
    load_2_19_11  segment_prefix_ub_1544  1
    load_2_19_11  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1465  -30
    arc_2_19_12  connected_order_arc_1466  -13
    arc_2_19_12  in_degree_1546  1
    arc_2_19_12  out_degree_1589  1
    arc_2_19_12  original_T_including_depot_unload_1610  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1465  1
    load_2_19_12  segment_load_conservation_1549  -1
    load_2_19_12  segment_prefix_lb_1550  1
    load_2_19_12  segment_prefix_ub_1551  1
    load_2_19_12  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1467  -30
    arc_2_19_13  connected_order_arc_1468  -13
    arc_2_19_13  in_degree_1553  1
    arc_2_19_13  out_degree_1589  1
    arc_2_19_13  original_T_including_depot_unload_1610  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1467  1
    load_2_19_13  segment_load_conservation_1556  -1
    load_2_19_13  segment_prefix_lb_1557  1
    load_2_19_13  segment_prefix_ub_1558  1
    load_2_19_13  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1469  -30
    arc_2_19_14  connected_order_arc_1470  -13
    arc_2_19_14  in_degree_1560  1
    arc_2_19_14  out_degree_1589  1
    arc_2_19_14  original_T_including_depot_unload_1610  7.6789230776331749e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1469  1
    load_2_19_14  free_load_conservation_1564  -1
    load_2_19_14  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1471  -30
    arc_2_19_15  connected_order_arc_1472  -13
    arc_2_19_15  in_degree_1566  1
    arc_2_19_15  out_degree_1589  1
    arc_2_19_15  original_T_including_depot_unload_1610  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1471  1
    load_2_19_15  free_load_conservation_1570  -1
    load_2_19_15  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1473  -30
    arc_2_19_16  connected_order_arc_1474  -13
    arc_2_19_16  in_degree_1572  1
    arc_2_19_16  out_degree_1589  1
    arc_2_19_16  original_T_including_depot_unload_1610  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1473  1
    load_2_19_16  free_load_conservation_1576  -1
    load_2_19_16  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1475  -30
    arc_2_19_17  connected_order_arc_1476  -13
    arc_2_19_17  in_degree_1578  1
    arc_2_19_17  out_degree_1589  1
    arc_2_19_17  original_T_including_depot_unload_1610  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1475  1
    load_2_19_17  free_load_conservation_1582  -1
    load_2_19_17  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1477  -30
    arc_2_19_18  connected_order_arc_1478  -13
    arc_2_19_18  in_degree_1584  1
    arc_2_19_18  out_degree_1589  1
    arc_2_19_18  original_T_including_depot_unload_1610  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1477  1
    load_2_19_18  free_load_conservation_1588  -1
    load_2_19_18  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1479  -30
    arc_2_19_20  connected_order_arc_1480  -13
    arc_2_19_20  out_degree_1589  1
    arc_2_19_20  in_degree_1596  1
    arc_2_19_20  original_T_including_depot_unload_1610  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1479  1
    load_2_19_20  free_load_conservation_1594  1
    load_2_19_20  free_load_conservation_1600  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1481  -30
    arc_2_19_21  connected_order_arc_1482  -13
    arc_2_19_21  out_degree_1589  1
    arc_2_19_21  in_degree_1602  1
    arc_2_19_21  original_T_including_depot_unload_1610  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1481  1
    load_2_19_21  free_load_conservation_1594  1
    load_2_19_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1483  -30
    arc_2_20_0  depot_return_or_bypass_1530  1
    arc_2_20_0  out_degree_1595  1
    arc_2_20_0  original_T_including_depot_unload_1610  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1483  1
    load_2_20_0  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1484  -30
    arc_2_20_10  connected_order_arc_1485  -13
    arc_2_20_10  in_degree_1532  1
    arc_2_20_10  out_degree_1595  1
    arc_2_20_10  original_T_including_depot_unload_1610  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1484  1
    load_2_20_10  segment_load_conservation_1535  -1
    load_2_20_10  segment_prefix_lb_1536  1
    load_2_20_10  segment_prefix_ub_1537  1
    load_2_20_10  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1486  -30
    arc_2_20_11  connected_order_arc_1487  -13
    arc_2_20_11  in_degree_1539  1
    arc_2_20_11  out_degree_1595  1
    arc_2_20_11  original_T_including_depot_unload_1610  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1486  1
    load_2_20_11  segment_load_conservation_1542  -1
    load_2_20_11  segment_prefix_lb_1543  1
    load_2_20_11  segment_prefix_ub_1544  1
    load_2_20_11  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1488  -30
    arc_2_20_12  connected_order_arc_1489  -13
    arc_2_20_12  in_degree_1546  1
    arc_2_20_12  out_degree_1595  1
    arc_2_20_12  original_T_including_depot_unload_1610  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1488  1
    load_2_20_12  segment_load_conservation_1549  -1
    load_2_20_12  segment_prefix_lb_1550  1
    load_2_20_12  segment_prefix_ub_1551  1
    load_2_20_12  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1490  -30
    arc_2_20_13  connected_order_arc_1491  -13
    arc_2_20_13  in_degree_1553  1
    arc_2_20_13  out_degree_1595  1
    arc_2_20_13  original_T_including_depot_unload_1610  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1490  1
    load_2_20_13  segment_load_conservation_1556  -1
    load_2_20_13  segment_prefix_lb_1557  1
    load_2_20_13  segment_prefix_ub_1558  1
    load_2_20_13  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1492  -30
    arc_2_20_14  connected_order_arc_1493  -13
    arc_2_20_14  in_degree_1560  1
    arc_2_20_14  out_degree_1595  1
    arc_2_20_14  original_T_including_depot_unload_1610  1.4688211749637876e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1492  1
    load_2_20_14  free_load_conservation_1564  -1
    load_2_20_14  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1494  -30
    arc_2_20_15  connected_order_arc_1495  -13
    arc_2_20_15  in_degree_1566  1
    arc_2_20_15  out_degree_1595  1
    arc_2_20_15  original_T_including_depot_unload_1610  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1494  1
    load_2_20_15  free_load_conservation_1570  -1
    load_2_20_15  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1496  -30
    arc_2_20_16  connected_order_arc_1497  -13
    arc_2_20_16  in_degree_1572  1
    arc_2_20_16  out_degree_1595  1
    arc_2_20_16  original_T_including_depot_unload_1610  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1496  1
    load_2_20_16  free_load_conservation_1576  -1
    load_2_20_16  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1498  -30
    arc_2_20_17  connected_order_arc_1499  -13
    arc_2_20_17  in_degree_1578  1
    arc_2_20_17  out_degree_1595  1
    arc_2_20_17  original_T_including_depot_unload_1610  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1498  1
    load_2_20_17  free_load_conservation_1582  -1
    load_2_20_17  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1500  -30
    arc_2_20_18  connected_order_arc_1501  -13
    arc_2_20_18  in_degree_1584  1
    arc_2_20_18  out_degree_1595  1
    arc_2_20_18  original_T_including_depot_unload_1610  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1500  1
    load_2_20_18  free_load_conservation_1588  -1
    load_2_20_18  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1502  -30
    arc_2_20_19  connected_order_arc_1503  -13
    arc_2_20_19  in_degree_1590  1
    arc_2_20_19  out_degree_1595  1
    arc_2_20_19  original_T_including_depot_unload_1610  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1502  1
    load_2_20_19  free_load_conservation_1594  -1
    load_2_20_19  free_load_conservation_1600  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1504  -30
    arc_2_20_21  connected_order_arc_1505  -13
    arc_2_20_21  out_degree_1595  1
    arc_2_20_21  in_degree_1602  1
    arc_2_20_21  original_T_including_depot_unload_1610  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1504  1
    load_2_20_21  free_load_conservation_1600  1
    load_2_20_21  free_load_conservation_1606  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1506  -30
    arc_2_21_0  depot_return_or_bypass_1530  1
    arc_2_21_0  out_degree_1601  1
    arc_2_21_0  original_T_including_depot_unload_1610  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1506  1
    load_2_21_0  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_10  arc_capacity_1507  -30
    arc_2_21_10  connected_order_arc_1508  -13
    arc_2_21_10  in_degree_1532  1
    arc_2_21_10  out_degree_1601  1
    arc_2_21_10  original_T_including_depot_unload_1610  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_10  arc_capacity_1507  1
    load_2_21_10  segment_load_conservation_1535  -1
    load_2_21_10  segment_prefix_lb_1536  1
    load_2_21_10  segment_prefix_ub_1537  1
    load_2_21_10  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1509  -30
    arc_2_21_11  connected_order_arc_1510  -13
    arc_2_21_11  in_degree_1539  1
    arc_2_21_11  out_degree_1601  1
    arc_2_21_11  original_T_including_depot_unload_1610  1.3279253844180159e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1509  1
    load_2_21_11  segment_load_conservation_1542  -1
    load_2_21_11  segment_prefix_lb_1543  1
    load_2_21_11  segment_prefix_ub_1544  1
    load_2_21_11  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1511  -30
    arc_2_21_12  connected_order_arc_1512  -13
    arc_2_21_12  in_degree_1546  1
    arc_2_21_12  out_degree_1601  1
    arc_2_21_12  original_T_including_depot_unload_1610  1.5086201853425566e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1511  1
    load_2_21_12  segment_load_conservation_1549  -1
    load_2_21_12  segment_prefix_lb_1550  1
    load_2_21_12  segment_prefix_ub_1551  1
    load_2_21_12  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1513  -30
    arc_2_21_13  connected_order_arc_1514  -13
    arc_2_21_13  in_degree_1553  1
    arc_2_21_13  out_degree_1601  1
    arc_2_21_13  original_T_including_depot_unload_1610  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1513  1
    load_2_21_13  segment_load_conservation_1556  -1
    load_2_21_13  segment_prefix_lb_1557  1
    load_2_21_13  segment_prefix_ub_1558  1
    load_2_21_13  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1515  -30
    arc_2_21_14  connected_order_arc_1516  -13
    arc_2_21_14  in_degree_1560  1
    arc_2_21_14  out_degree_1601  1
    arc_2_21_14  original_T_including_depot_unload_1610  8.2066682484686987e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1515  1
    load_2_21_14  free_load_conservation_1564  -1
    load_2_21_14  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1517  -30
    arc_2_21_15  connected_order_arc_1518  -13
    arc_2_21_15  in_degree_1566  1
    arc_2_21_15  out_degree_1601  1
    arc_2_21_15  original_T_including_depot_unload_1610  8.6958069185371107e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1517  1
    load_2_21_15  free_load_conservation_1570  -1
    load_2_21_15  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1519  -30
    arc_2_21_16  connected_order_arc_1520  -13
    arc_2_21_16  in_degree_1572  1
    arc_2_21_16  out_degree_1601  1
    arc_2_21_16  original_T_including_depot_unload_1610  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1519  1
    load_2_21_16  free_load_conservation_1576  -1
    load_2_21_16  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1521  -30
    arc_2_21_17  connected_order_arc_1522  -13
    arc_2_21_17  in_degree_1578  1
    arc_2_21_17  out_degree_1601  1
    arc_2_21_17  original_T_including_depot_unload_1610  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1521  1
    load_2_21_17  free_load_conservation_1582  -1
    load_2_21_17  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1523  -30
    arc_2_21_18  connected_order_arc_1524  -13
    arc_2_21_18  in_degree_1584  1
    arc_2_21_18  out_degree_1601  1
    arc_2_21_18  original_T_including_depot_unload_1610  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1523  1
    load_2_21_18  free_load_conservation_1588  -1
    load_2_21_18  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1525  -30
    arc_2_21_19  connected_order_arc_1526  -13
    arc_2_21_19  in_degree_1590  1
    arc_2_21_19  out_degree_1601  1
    arc_2_21_19  original_T_including_depot_unload_1610  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1525  1
    load_2_21_19  free_load_conservation_1594  -1
    load_2_21_19  free_load_conservation_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1527  -30
    arc_2_21_20  connected_order_arc_1528  -13
    arc_2_21_20  in_degree_1596  1
    arc_2_21_20  out_degree_1601  1
    arc_2_21_20  original_T_including_depot_unload_1610  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1527  1
    load_2_21_20  free_load_conservation_1600  -1
    load_2_21_20  free_load_conservation_1606  1
RHS
    RHS1      OBJ       -0.52125
    RHS1      onehot_22_26  1
    RHS1      onehot_18_65  1
    RHS1      onehot_31_94  1
    RHS1      onehot_14_129  1
    RHS1      onehot_32_158  1
    RHS1      onehot_5_195  1
    RHS1      onehot_19_216  1
    RHS1      onehot_8_263  1
    RHS1      stock_ub_267  41
    RHS1      parent_nonstrict_scope_268  3.1634040918067935e-01
    RHS1      normalization_325  1
    RHS1      connected_order_arc_456  -13
    RHS1      connected_order_arc_458  -13
    RHS1      connected_order_arc_460  -13
    RHS1      connected_order_arc_462  -13
    RHS1      connected_order_arc_464  -13
    RHS1      connected_order_arc_466  -13
    RHS1      connected_order_arc_468  -13
    RHS1      connected_order_arc_470  -13
    RHS1      connected_order_arc_472  -13
    RHS1      connected_order_arc_474  -13
    RHS1      connected_order_arc_476  -13
    RHS1      connected_order_arc_478  -13
    RHS1      connected_order_arc_481  -13
    RHS1      connected_order_arc_483  -13
    RHS1      connected_order_arc_485  -13
    RHS1      connected_order_arc_487  -13
    RHS1      connected_order_arc_489  -13
    RHS1      connected_order_arc_491  -13
    RHS1      connected_order_arc_493  -13
    RHS1      connected_order_arc_495  -13
    RHS1      connected_order_arc_497  -13
    RHS1      connected_order_arc_499  -13
    RHS1      connected_order_arc_501  -13
    RHS1      connected_order_arc_503  -13
    RHS1      connected_order_arc_506  -13
    RHS1      connected_order_arc_508  -13
    RHS1      connected_order_arc_510  -13
    RHS1      connected_order_arc_512  -13
    RHS1      connected_order_arc_514  -13
    RHS1      connected_order_arc_516  -13
    RHS1      connected_order_arc_518  -13
    RHS1      connected_order_arc_520  -13
    RHS1      connected_order_arc_522  -13
    RHS1      connected_order_arc_524  -13
    RHS1      connected_order_arc_526  -13
    RHS1      connected_order_arc_528  -13
    RHS1      connected_order_arc_531  -13
    RHS1      connected_order_arc_533  -13
    RHS1      connected_order_arc_535  -13
    RHS1      connected_order_arc_537  -13
    RHS1      connected_order_arc_539  -13
    RHS1      connected_order_arc_541  -13
    RHS1      connected_order_arc_543  -13
    RHS1      connected_order_arc_545  -13
    RHS1      connected_order_arc_547  -13
    RHS1      connected_order_arc_549  -13
    RHS1      connected_order_arc_551  -13
    RHS1      connected_order_arc_553  -13
    RHS1      connected_order_arc_556  -13
    RHS1      connected_order_arc_558  -13
    RHS1      connected_order_arc_560  -13
    RHS1      connected_order_arc_562  -13
    RHS1      connected_order_arc_564  -13
    RHS1      connected_order_arc_566  -13
    RHS1      connected_order_arc_568  -13
    RHS1      connected_order_arc_570  -13
    RHS1      connected_order_arc_572  -13
    RHS1      connected_order_arc_574  -13
    RHS1      connected_order_arc_576  -13
    RHS1      connected_order_arc_578  -13
    RHS1      connected_order_arc_581  -13
    RHS1      connected_order_arc_583  -13
    RHS1      connected_order_arc_585  -13
    RHS1      connected_order_arc_587  -13
    RHS1      connected_order_arc_589  -13
    RHS1      connected_order_arc_591  -13
    RHS1      connected_order_arc_593  -13
    RHS1      connected_order_arc_595  -13
    RHS1      connected_order_arc_597  -13
    RHS1      connected_order_arc_599  -13
    RHS1      connected_order_arc_601  -13
    RHS1      connected_order_arc_603  -13
    RHS1      connected_order_arc_606  -13
    RHS1      connected_order_arc_608  -13
    RHS1      connected_order_arc_610  -13
    RHS1      connected_order_arc_612  -13
    RHS1      connected_order_arc_614  -13
    RHS1      connected_order_arc_616  -13
    RHS1      connected_order_arc_618  -13
    RHS1      connected_order_arc_620  -13
    RHS1      connected_order_arc_622  -13
    RHS1      connected_order_arc_624  -13
    RHS1      connected_order_arc_626  -13
    RHS1      connected_order_arc_628  -13
    RHS1      connected_order_arc_631  -13
    RHS1      connected_order_arc_633  -13
    RHS1      connected_order_arc_635  -13
    RHS1      connected_order_arc_637  -13
    RHS1      connected_order_arc_639  -13
    RHS1      connected_order_arc_641  -13
    RHS1      connected_order_arc_643  -13
    RHS1      connected_order_arc_645  -13
    RHS1      connected_order_arc_647  -13
    RHS1      connected_order_arc_649  -13
    RHS1      connected_order_arc_651  -13
    RHS1      connected_order_arc_653  -13
    RHS1      connected_order_arc_656  -13
    RHS1      connected_order_arc_658  -13
    RHS1      connected_order_arc_660  -13
    RHS1      connected_order_arc_662  -13
    RHS1      connected_order_arc_664  -13
    RHS1      connected_order_arc_666  -13
    RHS1      connected_order_arc_668  -13
    RHS1      connected_order_arc_670  -13
    RHS1      connected_order_arc_672  -13
    RHS1      connected_order_arc_674  -13
    RHS1      connected_order_arc_676  -13
    RHS1      connected_order_arc_678  -13
    RHS1      connected_order_arc_681  -13
    RHS1      connected_order_arc_683  -13
    RHS1      connected_order_arc_685  -13
    RHS1      connected_order_arc_687  -13
    RHS1      connected_order_arc_689  -13
    RHS1      connected_order_arc_691  -13
    RHS1      connected_order_arc_693  -13
    RHS1      connected_order_arc_695  -13
    RHS1      connected_order_arc_697  -13
    RHS1      connected_order_arc_699  -13
    RHS1      connected_order_arc_701  -13
    RHS1      connected_order_arc_703  -13
    RHS1      connected_order_arc_706  -13
    RHS1      connected_order_arc_708  -13
    RHS1      connected_order_arc_710  -13
    RHS1      connected_order_arc_712  -13
    RHS1      connected_order_arc_714  -13
    RHS1      connected_order_arc_716  -13
    RHS1      connected_order_arc_718  -13
    RHS1      connected_order_arc_720  -13
    RHS1      connected_order_arc_722  -13
    RHS1      connected_order_arc_724  -13
    RHS1      connected_order_arc_726  -13
    RHS1      connected_order_arc_728  -13
    RHS1      connected_order_arc_731  -13
    RHS1      connected_order_arc_733  -13
    RHS1      connected_order_arc_735  -13
    RHS1      connected_order_arc_737  -13
    RHS1      connected_order_arc_739  -13
    RHS1      connected_order_arc_741  -13
    RHS1      connected_order_arc_743  -13
    RHS1      connected_order_arc_745  -13
    RHS1      connected_order_arc_747  -13
    RHS1      connected_order_arc_749  -13
    RHS1      connected_order_arc_751  -13
    RHS1      connected_order_arc_753  -13
    RHS1      connected_order_arc_756  -13
    RHS1      connected_order_arc_758  -13
    RHS1      connected_order_arc_760  -13
    RHS1      connected_order_arc_762  -13
    RHS1      connected_order_arc_764  -13
    RHS1      connected_order_arc_766  -13
    RHS1      connected_order_arc_768  -13
    RHS1      connected_order_arc_770  -13
    RHS1      connected_order_arc_772  -13
    RHS1      connected_order_arc_774  -13
    RHS1      connected_order_arc_776  -13
    RHS1      connected_order_arc_778  -13
    RHS1      depot_departure_or_bypass_779  1
    RHS1      depot_return_or_bypass_780  1
    RHS1      segment_load_conservation_785  11
    RHS1      segment_prefix_ub_787  1
    RHS1      segment_load_conservation_792  -5
    RHS1      segment_prefix_lb_793  5
    RHS1      segment_prefix_ub_794  20
    RHS1      segment_load_conservation_799  6
    RHS1      segment_prefix_ub_801  14
    RHS1      segment_load_conservation_806  -6
    RHS1      segment_prefix_lb_807  6
    RHS1      segment_prefix_ub_808  20
    RHS1      segment_load_conservation_813  -6
    RHS1      segment_prefix_lb_814  6
    RHS1      segment_prefix_ub_815  20
    RHS1      fixed_segment_relative_order_864  1
    RHS1      fixed_segment_relative_order_865  1
    RHS1      fixed_segment_relative_order_866  1
    RHS1      fixed_segment_relative_order_867  1
    RHS1      original_T_including_depot_unload_868  2.9609165200617390e+03
    RHS1      connected_order_arc_884  -12
    RHS1      connected_order_arc_886  -12
    RHS1      connected_order_arc_888  -12
    RHS1      connected_order_arc_890  -12
    RHS1      connected_order_arc_892  -12
    RHS1      connected_order_arc_894  -12
    RHS1      connected_order_arc_896  -12
    RHS1      connected_order_arc_898  -12
    RHS1      connected_order_arc_900  -12
    RHS1      connected_order_arc_902  -12
    RHS1      connected_order_arc_904  -12
    RHS1      connected_order_arc_907  -12
    RHS1      connected_order_arc_909  -12
    RHS1      connected_order_arc_911  -12
    RHS1      connected_order_arc_913  -12
    RHS1      connected_order_arc_915  -12
    RHS1      connected_order_arc_917  -12
    RHS1      connected_order_arc_919  -12
    RHS1      connected_order_arc_921  -12
    RHS1      connected_order_arc_923  -12
    RHS1      connected_order_arc_925  -12
    RHS1      connected_order_arc_927  -12
    RHS1      connected_order_arc_930  -12
    RHS1      connected_order_arc_932  -12
    RHS1      connected_order_arc_934  -12
    RHS1      connected_order_arc_936  -12
    RHS1      connected_order_arc_938  -12
    RHS1      connected_order_arc_940  -12
    RHS1      connected_order_arc_942  -12
    RHS1      connected_order_arc_944  -12
    RHS1      connected_order_arc_946  -12
    RHS1      connected_order_arc_948  -12
    RHS1      connected_order_arc_950  -12
    RHS1      connected_order_arc_953  -12
    RHS1      connected_order_arc_955  -12
    RHS1      connected_order_arc_957  -12
    RHS1      connected_order_arc_959  -12
    RHS1      connected_order_arc_961  -12
    RHS1      connected_order_arc_963  -12
    RHS1      connected_order_arc_965  -12
    RHS1      connected_order_arc_967  -12
    RHS1      connected_order_arc_969  -12
    RHS1      connected_order_arc_971  -12
    RHS1      connected_order_arc_973  -12
    RHS1      connected_order_arc_976  -12
    RHS1      connected_order_arc_978  -12
    RHS1      connected_order_arc_980  -12
    RHS1      connected_order_arc_982  -12
    RHS1      connected_order_arc_984  -12
    RHS1      connected_order_arc_986  -12
    RHS1      connected_order_arc_988  -12
    RHS1      connected_order_arc_990  -12
    RHS1      connected_order_arc_992  -12
    RHS1      connected_order_arc_994  -12
    RHS1      connected_order_arc_996  -12
    RHS1      connected_order_arc_999  -12
    RHS1      connected_order_arc_1001  -12
    RHS1      connected_order_arc_1003  -12
    RHS1      connected_order_arc_1005  -12
    RHS1      connected_order_arc_1007  -12
    RHS1      connected_order_arc_1009  -12
    RHS1      connected_order_arc_1011  -12
    RHS1      connected_order_arc_1013  -12
    RHS1      connected_order_arc_1015  -12
    RHS1      connected_order_arc_1017  -12
    RHS1      connected_order_arc_1019  -12
    RHS1      connected_order_arc_1022  -12
    RHS1      connected_order_arc_1024  -12
    RHS1      connected_order_arc_1026  -12
    RHS1      connected_order_arc_1028  -12
    RHS1      connected_order_arc_1030  -12
    RHS1      connected_order_arc_1032  -12
    RHS1      connected_order_arc_1034  -12
    RHS1      connected_order_arc_1036  -12
    RHS1      connected_order_arc_1038  -12
    RHS1      connected_order_arc_1040  -12
    RHS1      connected_order_arc_1042  -12
    RHS1      connected_order_arc_1045  -12
    RHS1      connected_order_arc_1047  -12
    RHS1      connected_order_arc_1049  -12
    RHS1      connected_order_arc_1051  -12
    RHS1      connected_order_arc_1053  -12
    RHS1      connected_order_arc_1055  -12
    RHS1      connected_order_arc_1057  -12
    RHS1      connected_order_arc_1059  -12
    RHS1      connected_order_arc_1061  -12
    RHS1      connected_order_arc_1063  -12
    RHS1      connected_order_arc_1065  -12
    RHS1      connected_order_arc_1068  -12
    RHS1      connected_order_arc_1070  -12
    RHS1      connected_order_arc_1072  -12
    RHS1      connected_order_arc_1074  -12
    RHS1      connected_order_arc_1076  -12
    RHS1      connected_order_arc_1078  -12
    RHS1      connected_order_arc_1080  -12
    RHS1      connected_order_arc_1082  -12
    RHS1      connected_order_arc_1084  -12
    RHS1      connected_order_arc_1086  -12
    RHS1      connected_order_arc_1088  -12
    RHS1      connected_order_arc_1091  -12
    RHS1      connected_order_arc_1093  -12
    RHS1      connected_order_arc_1095  -12
    RHS1      connected_order_arc_1097  -12
    RHS1      connected_order_arc_1099  -12
    RHS1      connected_order_arc_1101  -12
    RHS1      connected_order_arc_1103  -12
    RHS1      connected_order_arc_1105  -12
    RHS1      connected_order_arc_1107  -12
    RHS1      connected_order_arc_1109  -12
    RHS1      connected_order_arc_1111  -12
    RHS1      connected_order_arc_1114  -12
    RHS1      connected_order_arc_1116  -12
    RHS1      connected_order_arc_1118  -12
    RHS1      connected_order_arc_1120  -12
    RHS1      connected_order_arc_1122  -12
    RHS1      connected_order_arc_1124  -12
    RHS1      connected_order_arc_1126  -12
    RHS1      connected_order_arc_1128  -12
    RHS1      connected_order_arc_1130  -12
    RHS1      connected_order_arc_1132  -12
    RHS1      connected_order_arc_1134  -12
    RHS1      connected_order_arc_1137  -12
    RHS1      connected_order_arc_1139  -12
    RHS1      connected_order_arc_1141  -12
    RHS1      connected_order_arc_1143  -12
    RHS1      connected_order_arc_1145  -12
    RHS1      connected_order_arc_1147  -12
    RHS1      connected_order_arc_1149  -12
    RHS1      connected_order_arc_1151  -12
    RHS1      connected_order_arc_1153  -12
    RHS1      connected_order_arc_1155  -12
    RHS1      connected_order_arc_1157  -12
    RHS1      depot_departure_or_bypass_1158  1
    RHS1      depot_return_or_bypass_1159  1
    RHS1      segment_load_conservation_1164  4
    RHS1      segment_prefix_ub_1166  21
    RHS1      segment_load_conservation_1171  3
    RHS1      segment_prefix_ub_1173  22
    RHS1      segment_load_conservation_1178  -5
    RHS1      segment_prefix_lb_1179  5
    RHS1      segment_prefix_ub_1180  25
    RHS1      segment_load_conservation_1185  -2
    RHS1      segment_prefix_lb_1186  2
    RHS1      segment_prefix_ub_1187  16
    RHS1      fixed_segment_relative_order_1236  1
    RHS1      fixed_segment_relative_order_1237  1
    RHS1      fixed_segment_relative_order_1238  1
    RHS1      original_T_including_depot_unload_1239  2.5466013138995804e+03
    RHS1      connected_order_arc_1255  -12
    RHS1      connected_order_arc_1257  -12
    RHS1      connected_order_arc_1259  -12
    RHS1      connected_order_arc_1261  -12
    RHS1      connected_order_arc_1263  -12
    RHS1      connected_order_arc_1265  -12
    RHS1      connected_order_arc_1267  -12
    RHS1      connected_order_arc_1269  -12
    RHS1      connected_order_arc_1271  -12
    RHS1      connected_order_arc_1273  -12
    RHS1      connected_order_arc_1275  -12
    RHS1      connected_order_arc_1278  -12
    RHS1      connected_order_arc_1280  -12
    RHS1      connected_order_arc_1282  -12
    RHS1      connected_order_arc_1284  -12
    RHS1      connected_order_arc_1286  -12
    RHS1      connected_order_arc_1288  -12
    RHS1      connected_order_arc_1290  -12
    RHS1      connected_order_arc_1292  -12
    RHS1      connected_order_arc_1294  -12
    RHS1      connected_order_arc_1296  -12
    RHS1      connected_order_arc_1298  -12
    RHS1      connected_order_arc_1301  -12
    RHS1      connected_order_arc_1303  -12
    RHS1      connected_order_arc_1305  -12
    RHS1      connected_order_arc_1307  -12
    RHS1      connected_order_arc_1309  -12
    RHS1      connected_order_arc_1311  -12
    RHS1      connected_order_arc_1313  -12
    RHS1      connected_order_arc_1315  -12
    RHS1      connected_order_arc_1317  -12
    RHS1      connected_order_arc_1319  -12
    RHS1      connected_order_arc_1321  -12
    RHS1      connected_order_arc_1324  -12
    RHS1      connected_order_arc_1326  -12
    RHS1      connected_order_arc_1328  -12
    RHS1      connected_order_arc_1330  -12
    RHS1      connected_order_arc_1332  -12
    RHS1      connected_order_arc_1334  -12
    RHS1      connected_order_arc_1336  -12
    RHS1      connected_order_arc_1338  -12
    RHS1      connected_order_arc_1340  -12
    RHS1      connected_order_arc_1342  -12
    RHS1      connected_order_arc_1344  -12
    RHS1      connected_order_arc_1347  -12
    RHS1      connected_order_arc_1349  -12
    RHS1      connected_order_arc_1351  -12
    RHS1      connected_order_arc_1353  -12
    RHS1      connected_order_arc_1355  -12
    RHS1      connected_order_arc_1357  -12
    RHS1      connected_order_arc_1359  -12
    RHS1      connected_order_arc_1361  -12
    RHS1      connected_order_arc_1363  -12
    RHS1      connected_order_arc_1365  -12
    RHS1      connected_order_arc_1367  -12
    RHS1      connected_order_arc_1370  -12
    RHS1      connected_order_arc_1372  -12
    RHS1      connected_order_arc_1374  -12
    RHS1      connected_order_arc_1376  -12
    RHS1      connected_order_arc_1378  -12
    RHS1      connected_order_arc_1380  -12
    RHS1      connected_order_arc_1382  -12
    RHS1      connected_order_arc_1384  -12
    RHS1      connected_order_arc_1386  -12
    RHS1      connected_order_arc_1388  -12
    RHS1      connected_order_arc_1390  -12
    RHS1      connected_order_arc_1393  -12
    RHS1      connected_order_arc_1395  -12
    RHS1      connected_order_arc_1397  -12
    RHS1      connected_order_arc_1399  -12
    RHS1      connected_order_arc_1401  -12
    RHS1      connected_order_arc_1403  -12
    RHS1      connected_order_arc_1405  -12
    RHS1      connected_order_arc_1407  -12
    RHS1      connected_order_arc_1409  -12
    RHS1      connected_order_arc_1411  -12
    RHS1      connected_order_arc_1413  -12
    RHS1      connected_order_arc_1416  -12
    RHS1      connected_order_arc_1418  -12
    RHS1      connected_order_arc_1420  -12
    RHS1      connected_order_arc_1422  -12
    RHS1      connected_order_arc_1424  -12
    RHS1      connected_order_arc_1426  -12
    RHS1      connected_order_arc_1428  -12
    RHS1      connected_order_arc_1430  -12
    RHS1      connected_order_arc_1432  -12
    RHS1      connected_order_arc_1434  -12
    RHS1      connected_order_arc_1436  -12
    RHS1      connected_order_arc_1439  -12
    RHS1      connected_order_arc_1441  -12
    RHS1      connected_order_arc_1443  -12
    RHS1      connected_order_arc_1445  -12
    RHS1      connected_order_arc_1447  -12
    RHS1      connected_order_arc_1449  -12
    RHS1      connected_order_arc_1451  -12
    RHS1      connected_order_arc_1453  -12
    RHS1      connected_order_arc_1455  -12
    RHS1      connected_order_arc_1457  -12
    RHS1      connected_order_arc_1459  -12
    RHS1      connected_order_arc_1462  -12
    RHS1      connected_order_arc_1464  -12
    RHS1      connected_order_arc_1466  -12
    RHS1      connected_order_arc_1468  -12
    RHS1      connected_order_arc_1470  -12
    RHS1      connected_order_arc_1472  -12
    RHS1      connected_order_arc_1474  -12
    RHS1      connected_order_arc_1476  -12
    RHS1      connected_order_arc_1478  -12
    RHS1      connected_order_arc_1480  -12
    RHS1      connected_order_arc_1482  -12
    RHS1      connected_order_arc_1485  -12
    RHS1      connected_order_arc_1487  -12
    RHS1      connected_order_arc_1489  -12
    RHS1      connected_order_arc_1491  -12
    RHS1      connected_order_arc_1493  -12
    RHS1      connected_order_arc_1495  -12
    RHS1      connected_order_arc_1497  -12
    RHS1      connected_order_arc_1499  -12
    RHS1      connected_order_arc_1501  -12
    RHS1      connected_order_arc_1503  -12
    RHS1      connected_order_arc_1505  -12
    RHS1      connected_order_arc_1508  -12
    RHS1      connected_order_arc_1510  -12
    RHS1      connected_order_arc_1512  -12
    RHS1      connected_order_arc_1514  -12
    RHS1      connected_order_arc_1516  -12
    RHS1      connected_order_arc_1518  -12
    RHS1      connected_order_arc_1520  -12
    RHS1      connected_order_arc_1522  -12
    RHS1      connected_order_arc_1524  -12
    RHS1      connected_order_arc_1526  -12
    RHS1      connected_order_arc_1528  -12
    RHS1      depot_departure_or_bypass_1529  1
    RHS1      depot_return_or_bypass_1530  1
    RHS1      segment_load_conservation_1535  1
    RHS1      segment_prefix_ub_1537  28
    RHS1      segment_load_conservation_1542  1
    RHS1      segment_prefix_ub_1544  29
    RHS1      segment_load_conservation_1549  3
    RHS1      segment_prefix_ub_1551  27
    RHS1      segment_load_conservation_1556  -5
    RHS1      segment_prefix_lb_1557  5
    RHS1      segment_prefix_ub_1558  30
    RHS1      fixed_segment_relative_order_1607  1
    RHS1      fixed_segment_relative_order_1608  1
    RHS1      fixed_segment_relative_order_1609  1
    RHS1      original_T_including_depot_unload_1610  6.2391625356202467e+03
BOUNDS
 LO BND1      t         0.0253136583258579
 UP BND1      t         4.2505819249106368e-02
 UP BND1      q         4.9634040918067934e-01
 BV BND1      x_22_0  
 UP BND1      w_22_0    4.2505819249106368e-02
 BV BND1      x_22_1  
 UP BND1      w_22_1    4.2505819249106368e-02
 BV BND1      x_22_2  
 UP BND1      w_22_2    4.2505819249106368e-02
 BV BND1      x_22_3  
 UP BND1      w_22_3    4.2505819249106368e-02
 BV BND1      x_22_4  
 UP BND1      w_22_4    4.2505819249106368e-02
 BV BND1      x_22_5  
 UP BND1      w_22_5    4.2505819249106368e-02
 BV BND1      x_22_6  
 UP BND1      w_22_6    4.2505819249106368e-02
 BV BND1      x_22_7  
 UP BND1      w_22_7    4.2505819249106368e-02
 BV BND1      x_22_8  
 UP BND1      w_22_8    4.2505819249106368e-02
 BV BND1      x_22_9  
 UP BND1      w_22_9    4.2505819249106368e-02
 BV BND1      x_22_10 
 UP BND1      w_22_10   4.2505819249106368e-02
 BV BND1      x_22_11 
 UP BND1      w_22_11   4.2505819249106368e-02
 BV BND1      x_22_12 
 UP BND1      w_22_12   4.2505819249106368e-02
 UP BND1      rho_22    1
 BV BND1      x_18_0  
 UP BND1      w_18_0    4.2505819249106368e-02
 BV BND1      x_18_1  
 UP BND1      w_18_1    4.2505819249106368e-02
 BV BND1      x_18_2  
 UP BND1      w_18_2    4.2505819249106368e-02
 BV BND1      x_18_3  
 UP BND1      w_18_3    4.2505819249106368e-02
 BV BND1      x_18_4  
 UP BND1      w_18_4    4.2505819249106368e-02
 BV BND1      x_18_5  
 UP BND1      w_18_5    4.2505819249106368e-02
 BV BND1      x_18_6  
 UP BND1      w_18_6    4.2505819249106368e-02
 BV BND1      x_18_7  
 UP BND1      w_18_7    4.2505819249106368e-02
 BV BND1      x_18_8  
 UP BND1      w_18_8    4.2505819249106368e-02
 BV BND1      x_18_9  
 UP BND1      w_18_9    4.2505819249106368e-02
 BV BND1      x_18_10 
 UP BND1      w_18_10   4.2505819249106368e-02
 BV BND1      x_18_11 
 UP BND1      w_18_11   4.2505819249106368e-02
 BV BND1      x_18_12 
 UP BND1      w_18_12   4.2505819249106368e-02
 BV BND1      x_18_13 
 UP BND1      w_18_13   4.2505819249106368e-02
 BV BND1      x_18_14 
 UP BND1      w_18_14   4.2505819249106368e-02
 BV BND1      x_18_15 
 UP BND1      w_18_15   4.2505819249106368e-02
 BV BND1      x_18_16 
 UP BND1      w_18_16   4.2505819249106368e-02
 BV BND1      x_18_17 
 UP BND1      w_18_17   4.2505819249106368e-02
 UP BND1      rho_18    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.2505819249106368e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.2505819249106368e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.2505819249106368e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.2505819249106368e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.2505819249106368e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.2505819249106368e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.2505819249106368e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.2505819249106368e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.2505819249106368e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.2505819249106368e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.2505819249106368e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.2505819249106368e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.2505819249106368e-02
 UP BND1      rho_31    1
 BV BND1      x_14_0  
 UP BND1      w_14_0    4.2505819249106368e-02
 BV BND1      x_14_1  
 UP BND1      w_14_1    4.2505819249106368e-02
 BV BND1      x_14_2  
 UP BND1      w_14_2    4.2505819249106368e-02
 BV BND1      x_14_3  
 UP BND1      w_14_3    4.2505819249106368e-02
 BV BND1      x_14_4  
 UP BND1      w_14_4    4.2505819249106368e-02
 BV BND1      x_14_5  
 UP BND1      w_14_5    4.2505819249106368e-02
 BV BND1      x_14_6  
 UP BND1      w_14_6    4.2505819249106368e-02
 BV BND1      x_14_7  
 UP BND1      w_14_7    4.2505819249106368e-02
 BV BND1      x_14_8  
 UP BND1      w_14_8    4.2505819249106368e-02
 BV BND1      x_14_9  
 UP BND1      w_14_9    4.2505819249106368e-02
 BV BND1      x_14_10 
 UP BND1      w_14_10   4.2505819249106368e-02
 BV BND1      x_14_11 
 UP BND1      w_14_11   4.2505819249106368e-02
 BV BND1      x_14_12 
 UP BND1      w_14_12   4.2505819249106368e-02
 BV BND1      x_14_13 
 UP BND1      w_14_13   4.2505819249106368e-02
 BV BND1      x_14_14 
 UP BND1      w_14_14   4.2505819249106368e-02
 BV BND1      x_14_15 
 UP BND1      w_14_15   4.2505819249106368e-02
 UP BND1      rho_14    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.2505819249106368e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.2505819249106368e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.2505819249106368e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.2505819249106368e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.2505819249106368e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.2505819249106368e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.2505819249106368e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.2505819249106368e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.2505819249106368e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.2505819249106368e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.2505819249106368e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.2505819249106368e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.2505819249106368e-02
 UP BND1      rho_32    1
 BV BND1      x_5_0   
 UP BND1      w_5_0     4.2505819249106368e-02
 BV BND1      x_5_1   
 UP BND1      w_5_1     4.2505819249106368e-02
 BV BND1      x_5_2   
 UP BND1      w_5_2     4.2505819249106368e-02
 BV BND1      x_5_3   
 UP BND1      w_5_3     4.2505819249106368e-02
 BV BND1      x_5_4   
 UP BND1      w_5_4     4.2505819249106368e-02
 BV BND1      x_5_5   
 UP BND1      w_5_5     4.2505819249106368e-02
 BV BND1      x_5_6   
 UP BND1      w_5_6     4.2505819249106368e-02
 BV BND1      x_5_7   
 UP BND1      w_5_7     4.2505819249106368e-02
 BV BND1      x_5_8   
 UP BND1      w_5_8     4.2505819249106368e-02
 BV BND1      x_5_9   
 UP BND1      w_5_9     4.2505819249106368e-02
 BV BND1      x_5_10  
 UP BND1      w_5_10    4.2505819249106368e-02
 BV BND1      x_5_11  
 UP BND1      w_5_11    4.2505819249106368e-02
 BV BND1      x_5_12  
 UP BND1      w_5_12    4.2505819249106368e-02
 BV BND1      x_5_13  
 UP BND1      w_5_13    4.2505819249106368e-02
 BV BND1      x_5_14  
 UP BND1      w_5_14    4.2505819249106368e-02
 BV BND1      x_5_15  
 UP BND1      w_5_15    4.2505819249106368e-02
 BV BND1      x_5_16  
 UP BND1      w_5_16    4.2505819249106368e-02
 UP BND1      rho_5     1
 BV BND1      x_19_0  
 UP BND1      w_19_0    4.2505819249106368e-02
 BV BND1      x_19_1  
 UP BND1      w_19_1    4.2505819249106368e-02
 BV BND1      x_19_2  
 UP BND1      w_19_2    4.2505819249106368e-02
 BV BND1      x_19_3  
 UP BND1      w_19_3    4.2505819249106368e-02
 BV BND1      x_19_4  
 UP BND1      w_19_4    4.2505819249106368e-02
 BV BND1      x_19_5  
 UP BND1      w_19_5    4.2505819249106368e-02
 BV BND1      x_19_6  
 UP BND1      w_19_6    4.2505819249106368e-02
 BV BND1      x_19_7  
 UP BND1      w_19_7    4.2505819249106368e-02
 BV BND1      x_19_8  
 UP BND1      w_19_8    4.2505819249106368e-02
 UP BND1      rho_19    1
 BV BND1      x_8_0   
 UP BND1      w_8_0     4.2505819249106368e-02
 BV BND1      x_8_1   
 UP BND1      w_8_1     4.2505819249106368e-02
 BV BND1      x_8_2   
 UP BND1      w_8_2     4.2505819249106368e-02
 BV BND1      x_8_3   
 UP BND1      w_8_3     4.2505819249106368e-02
 BV BND1      x_8_4   
 UP BND1      w_8_4     4.2505819249106368e-02
 BV BND1      x_8_5   
 UP BND1      w_8_5     4.2505819249106368e-02
 BV BND1      x_8_6   
 UP BND1      w_8_6     4.2505819249106368e-02
 BV BND1      x_8_7   
 UP BND1      w_8_7     4.2505819249106368e-02
 BV BND1      x_8_8   
 UP BND1      w_8_8     4.2505819249106368e-02
 BV BND1      x_8_9   
 UP BND1      w_8_9     4.2505819249106368e-02
 BV BND1      x_8_10  
 UP BND1      w_8_10    4.2505819249106368e-02
 BV BND1      x_8_11  
 UP BND1      w_8_11    4.2505819249106368e-02
 BV BND1      x_8_12  
 UP BND1      w_8_12    4.2505819249106368e-02
 BV BND1      x_8_13  
 UP BND1      w_8_13    4.2505819249106368e-02
 BV BND1      x_8_14  
 UP BND1      w_8_14    4.2505819249106368e-02
 BV BND1      x_8_15  
 UP BND1      w_8_15    4.2505819249106368e-02
 BV BND1      x_8_16  
 UP BND1      w_8_16    4.2505819249106368e-02
 BV BND1      x_8_17  
 UP BND1      w_8_17    4.2505819249106368e-02
 BV BND1      x_8_18  
 UP BND1      w_8_18    4.2505819249106368e-02
 BV BND1      x_8_19  
 UP BND1      w_8_19    4.2505819249106368e-02
 BV BND1      x_8_20  
 UP BND1      w_8_20    4.2505819249106368e-02
 BV BND1      x_8_21  
 UP BND1      w_8_21    4.2505819249106368e-02
 UP BND1      rho_8     1
 UP BND1      a_22_18   1
 UP BND1      a_22_31   1
 UP BND1      a_22_14   1
 UP BND1      a_22_32   1
 UP BND1      a_22_5    1
 UP BND1      a_22_19   1
 UP BND1      a_22_8    1
 UP BND1      a_18_31   1
 UP BND1      a_18_14   1
 UP BND1      a_18_32   1
 UP BND1      a_18_5    1
 UP BND1      a_18_19   1
 UP BND1      a_18_8    1
 UP BND1      a_31_14   1
 UP BND1      a_31_32   1
 UP BND1      a_31_5    1
 UP BND1      a_31_19   1
 UP BND1      a_31_8    1
 UP BND1      a_14_32   1
 UP BND1      a_14_5    1
 UP BND1      a_14_19   1
 UP BND1      a_14_8    1
 UP BND1      a_32_5    1
 UP BND1      a_32_19   1
 UP BND1      a_32_8    1
 UP BND1      a_5_19    1
 UP BND1      a_5_8     1
 UP BND1      a_19_8    1
 BV BND1      service_0_22_0
 BV BND1      service_0_22_1
 BV BND1      service_0_22_2
 BV BND1      service_0_22_3
 BV BND1      service_0_22_4
 BV BND1      service_0_22_5
 BV BND1      service_0_22_6
 BV BND1      service_0_22_7
 BV BND1      service_0_22_9
 BV BND1      service_0_22_10
 BV BND1      service_0_22_11
 BV BND1      service_0_22_12
 BV BND1      service_1_22_0
 BV BND1      service_1_22_1
 BV BND1      service_1_22_2
 BV BND1      service_1_22_3
 BV BND1      service_1_22_4
 BV BND1      service_1_22_5
 BV BND1      service_1_22_6
 BV BND1      service_1_22_7
 BV BND1      service_1_22_9
 BV BND1      service_1_22_10
 BV BND1      service_1_22_11
 BV BND1      service_1_22_12
 BV BND1      service_2_22_0
 BV BND1      service_2_22_1
 BV BND1      service_2_22_2
 BV BND1      service_2_22_3
 BV BND1      service_2_22_4
 BV BND1      service_2_22_5
 BV BND1      service_2_22_6
 BV BND1      service_2_22_7
 BV BND1      service_2_22_9
 BV BND1      service_2_22_10
 BV BND1      service_2_22_11
 BV BND1      service_2_22_12
 BV BND1      service_0_18_0
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_8
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_0_18_11
 BV BND1      service_0_18_13
 BV BND1      service_0_18_14
 BV BND1      service_0_18_15
 BV BND1      service_0_18_16
 BV BND1      service_0_18_17
 BV BND1      service_1_18_0
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_8
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_1_18_11
 BV BND1      service_1_18_13
 BV BND1      service_1_18_14
 BV BND1      service_1_18_15
 BV BND1      service_1_18_16
 BV BND1      service_1_18_17
 BV BND1      service_2_18_0
 BV BND1      service_2_18_1
 BV BND1      service_2_18_2
 BV BND1      service_2_18_3
 BV BND1      service_2_18_4
 BV BND1      service_2_18_5
 BV BND1      service_2_18_6
 BV BND1      service_2_18_7
 BV BND1      service_2_18_8
 BV BND1      service_2_18_9
 BV BND1      service_2_18_10
 BV BND1      service_2_18_11
 BV BND1      service_2_18_13
 BV BND1      service_2_18_14
 BV BND1      service_2_18_15
 BV BND1      service_2_18_16
 BV BND1      service_2_18_17
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_14_0
 BV BND1      service_0_14_1
 BV BND1      service_0_14_3
 BV BND1      service_0_14_4
 BV BND1      service_0_14_5
 BV BND1      service_0_14_6
 BV BND1      service_0_14_7
 BV BND1      service_0_14_8
 BV BND1      service_0_14_9
 BV BND1      service_0_14_10
 BV BND1      service_0_14_11
 BV BND1      service_0_14_12
 BV BND1      service_0_14_13
 BV BND1      service_0_14_14
 BV BND1      service_0_14_15
 BV BND1      service_1_14_0
 BV BND1      service_1_14_1
 BV BND1      service_1_14_3
 BV BND1      service_1_14_4
 BV BND1      service_1_14_5
 BV BND1      service_1_14_6
 BV BND1      service_1_14_7
 BV BND1      service_1_14_8
 BV BND1      service_1_14_9
 BV BND1      service_1_14_10
 BV BND1      service_1_14_11
 BV BND1      service_1_14_12
 BV BND1      service_1_14_13
 BV BND1      service_1_14_14
 BV BND1      service_1_14_15
 BV BND1      service_2_14_0
 BV BND1      service_2_14_1
 BV BND1      service_2_14_3
 BV BND1      service_2_14_4
 BV BND1      service_2_14_5
 BV BND1      service_2_14_6
 BV BND1      service_2_14_7
 BV BND1      service_2_14_8
 BV BND1      service_2_14_9
 BV BND1      service_2_14_10
 BV BND1      service_2_14_11
 BV BND1      service_2_14_12
 BV BND1      service_2_14_13
 BV BND1      service_2_14_14
 BV BND1      service_2_14_15
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_5_0
 BV BND1      service_0_5_1
 BV BND1      service_0_5_3
 BV BND1      service_0_5_4
 BV BND1      service_0_5_5
 BV BND1      service_0_5_6
 BV BND1      service_0_5_7
 BV BND1      service_0_5_8
 BV BND1      service_0_5_9
 BV BND1      service_0_5_10
 BV BND1      service_0_5_11
 BV BND1      service_0_5_12
 BV BND1      service_0_5_13
 BV BND1      service_0_5_14
 BV BND1      service_0_5_15
 BV BND1      service_0_5_16
 BV BND1      service_1_5_0
 BV BND1      service_1_5_1
 BV BND1      service_1_5_3
 BV BND1      service_1_5_4
 BV BND1      service_1_5_5
 BV BND1      service_1_5_6
 BV BND1      service_1_5_7
 BV BND1      service_1_5_8
 BV BND1      service_1_5_9
 BV BND1      service_1_5_10
 BV BND1      service_1_5_11
 BV BND1      service_1_5_12
 BV BND1      service_1_5_13
 BV BND1      service_1_5_14
 BV BND1      service_1_5_15
 BV BND1      service_1_5_16
 BV BND1      service_2_5_0
 BV BND1      service_2_5_1
 BV BND1      service_2_5_3
 BV BND1      service_2_5_4
 BV BND1      service_2_5_5
 BV BND1      service_2_5_6
 BV BND1      service_2_5_7
 BV BND1      service_2_5_8
 BV BND1      service_2_5_9
 BV BND1      service_2_5_10
 BV BND1      service_2_5_11
 BV BND1      service_2_5_12
 BV BND1      service_2_5_13
 BV BND1      service_2_5_14
 BV BND1      service_2_5_15
 BV BND1      service_2_5_16
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_2_19_1
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 BV BND1      service_0_8_0
 BV BND1      service_0_8_1
 BV BND1      service_0_8_2
 BV BND1      service_0_8_3
 BV BND1      service_0_8_4
 BV BND1      service_0_8_5
 BV BND1      service_0_8_6
 BV BND1      service_0_8_7
 BV BND1      service_0_8_8
 BV BND1      service_0_8_9
 BV BND1      service_0_8_10
 BV BND1      service_0_8_11
 BV BND1      service_0_8_12
 BV BND1      service_0_8_13
 BV BND1      service_0_8_14
 BV BND1      service_0_8_16
 BV BND1      service_0_8_17
 BV BND1      service_0_8_18
 BV BND1      service_0_8_19
 BV BND1      service_0_8_20
 BV BND1      service_0_8_21
 BV BND1      service_1_8_0
 BV BND1      service_1_8_1
 BV BND1      service_1_8_2
 BV BND1      service_1_8_3
 BV BND1      service_1_8_4
 BV BND1      service_1_8_5
 BV BND1      service_1_8_6
 BV BND1      service_1_8_7
 BV BND1      service_1_8_8
 BV BND1      service_1_8_9
 BV BND1      service_1_8_10
 BV BND1      service_1_8_11
 BV BND1      service_1_8_12
 BV BND1      service_1_8_13
 BV BND1      service_1_8_14
 BV BND1      service_1_8_16
 BV BND1      service_1_8_17
 BV BND1      service_1_8_18
 BV BND1      service_1_8_19
 BV BND1      service_1_8_20
 BV BND1      service_1_8_21
 BV BND1      service_2_8_0
 BV BND1      service_2_8_1
 BV BND1      service_2_8_2
 BV BND1      service_2_8_3
 BV BND1      service_2_8_4
 BV BND1      service_2_8_5
 BV BND1      service_2_8_6
 BV BND1      service_2_8_7
 BV BND1      service_2_8_8
 BV BND1      service_2_8_9
 BV BND1      service_2_8_10
 BV BND1      service_2_8_11
 BV BND1      service_2_8_12
 BV BND1      service_2_8_13
 BV BND1      service_2_8_14
 BV BND1      service_2_8_16
 BV BND1      service_2_8_17
 BV BND1      service_2_8_18
 BV BND1      service_2_8_19
 BV BND1      service_2_8_20
 BV BND1      service_2_8_21
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_14_21
 UP BND1      load_0_14_21  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_14
 UP BND1      load_0_21_14  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_6_21
 UP BND1      load_1_6_21  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_14_21
 UP BND1      load_1_14_21  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_6
 UP BND1      load_1_21_6  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_14
 UP BND1      load_1_21_14  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  12
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  12
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  12
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  12
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  12
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  12
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  12
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  12
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  12
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  12
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  12
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  12
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_10_21
 UP BND1      load_2_10_21  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_10
 UP BND1      load_2_21_10  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
ENDATA
