* Signature: 0xd12efac4f8677f91
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 G  product_lb_32
 L  product_ub_33
 G  product_lb_34
 L  product_ub_35
 E  onehot_3_36
 E  normalized_mass_3_37
 E  normalized_ratio_3_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 G  product_lb_67
 L  product_ub_68
 G  product_lb_69
 L  product_ub_70
 G  product_lb_71
 L  product_ub_72
 G  product_lb_73
 L  product_ub_74
 G  product_lb_75
 L  product_ub_76
 G  product_lb_77
 L  product_ub_78
 E  onehot_1_79
 E  normalized_mass_1_80
 E  normalized_ratio_1_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 E  onehot_31_108
 E  normalized_mass_31_109
 E  normalized_ratio_31_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 G  product_lb_143
 L  product_ub_144
 G  product_lb_145
 L  product_ub_146
 E  onehot_7_147
 E  normalized_mass_7_148
 E  normalized_ratio_7_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 G  product_lb_178
 L  product_ub_179
 G  product_lb_180
 L  product_ub_181
 E  onehot_2_182
 E  normalized_mass_2_183
 E  normalized_ratio_2_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 G  product_lb_211
 L  product_ub_212
 G  product_lb_213
 L  product_ub_214
 G  product_lb_215
 L  product_ub_216
 E  onehot_4_217
 E  normalized_mass_4_218
 E  normalized_ratio_4_219
 G  product_lb_220
 L  product_ub_221
 G  product_lb_222
 L  product_ub_223
 G  product_lb_224
 L  product_ub_225
 G  product_lb_226
 L  product_ub_227
 G  product_lb_228
 L  product_ub_229
 G  product_lb_230
 L  product_ub_231
 G  product_lb_232
 L  product_ub_233
 G  product_lb_234
 L  product_ub_235
 G  product_lb_236
 L  product_ub_237
 G  product_lb_238
 L  product_ub_239
 G  product_lb_240
 L  product_ub_241
 G  product_lb_242
 L  product_ub_243
 G  product_lb_244
 L  product_ub_245
 E  onehot_16_246
 E  normalized_mass_16_247
 E  normalized_ratio_16_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 G  product_lb_255
 L  product_ub_256
 G  product_lb_257
 L  product_ub_258
 G  product_lb_259
 L  product_ub_260
 G  product_lb_261
 L  product_ub_262
 G  product_lb_263
 L  product_ub_264
 G  product_lb_265
 L  product_ub_266
 G  product_lb_267
 L  product_ub_268
 G  product_lb_269
 L  product_ub_270
 G  product_lb_271
 L  product_ub_272
 G  product_lb_273
 L  product_ub_274
 G  product_lb_275
 L  product_ub_276
 G  product_lb_277
 L  product_ub_278
 G  product_lb_279
 L  product_ub_280
 G  product_lb_281
 L  product_ub_282
 G  product_lb_283
 L  product_ub_284
 G  product_lb_285
 L  product_ub_286
 G  product_lb_287
 L  product_ub_288
 E  onehot_10_289
 E  normalized_mass_10_290
 E  normalized_ratio_10_291
 G  stock_lb_292
 L  stock_ub_293
 L  parent_nonstrict_scope_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 G  block_pair_pos_317
 G  block_pair_neg_318
 G  block_pair_pos_319
 G  block_pair_neg_320
 G  block_pair_pos_321
 G  block_pair_neg_322
 G  block_pair_pos_323
 G  block_pair_neg_324
 G  block_pair_pos_325
 G  block_pair_neg_326
 G  block_pair_pos_327
 G  block_pair_neg_328
 G  block_pair_pos_329
 G  block_pair_neg_330
 G  block_pair_pos_331
 G  block_pair_neg_332
 G  block_pair_pos_333
 G  block_pair_neg_334
 G  block_pair_pos_335
 G  block_pair_neg_336
 G  block_pair_pos_337
 G  block_pair_neg_338
 G  block_pair_pos_339
 G  block_pair_neg_340
 G  block_pair_pos_341
 G  block_pair_neg_342
 G  block_pair_pos_343
 G  block_pair_neg_344
 G  block_pair_pos_345
 G  block_pair_neg_346
 G  block_pair_pos_347
 G  block_pair_neg_348
 G  block_pair_pos_349
 G  block_pair_neg_350
 E  normalization_351
 G  full_original_Gini_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 E  unique_nonzero_owner_428
 E  unique_nonzero_owner_429
 E  unique_nonzero_owner_430
 E  unique_nonzero_owner_431
 E  unique_nonzero_owner_432
 E  unique_nonzero_owner_433
 E  unique_nonzero_owner_434
 E  unique_nonzero_owner_435
 E  unique_nonzero_owner_436
 E  unique_nonzero_owner_437
 E  unique_nonzero_owner_438
 E  unique_nonzero_owner_439
 E  unique_nonzero_owner_440
 E  unique_nonzero_owner_441
 E  unique_nonzero_owner_442
 E  unique_nonzero_owner_443
 E  unique_nonzero_owner_444
 E  unique_nonzero_owner_445
 E  unique_nonzero_owner_446
 E  unique_nonzero_owner_447
 E  unique_nonzero_owner_448
 E  unique_nonzero_owner_449
 E  unique_nonzero_owner_450
 E  unique_nonzero_owner_451
 E  unique_nonzero_owner_452
 E  unique_nonzero_owner_453
 E  unique_nonzero_owner_454
 E  unique_nonzero_owner_455
 E  unique_nonzero_owner_456
 E  unique_nonzero_owner_457
 E  unique_nonzero_owner_458
 E  unique_nonzero_owner_459
 E  unique_nonzero_owner_460
 E  unique_nonzero_owner_461
 E  unique_nonzero_owner_462
 E  unique_nonzero_owner_463
 E  unique_nonzero_owner_464
 E  unique_nonzero_owner_465
 E  unique_nonzero_owner_466
 E  unique_nonzero_owner_467
 E  unique_nonzero_owner_468
 E  unique_nonzero_owner_469
 E  unique_nonzero_owner_470
 E  unique_nonzero_owner_471
 E  unique_nonzero_owner_472
 E  unique_nonzero_owner_473
 E  unique_nonzero_owner_474
 E  unique_nonzero_owner_475
 E  unique_nonzero_owner_476
 E  unique_nonzero_owner_477
 E  unique_nonzero_owner_478
 L  arc_capacity_479
 L  arc_capacity_480
 L  arc_capacity_481
 L  arc_capacity_482
 L  arc_capacity_483
 L  arc_capacity_484
 L  arc_capacity_485
 L  arc_capacity_486
 L  arc_capacity_487
 L  arc_capacity_488
 L  arc_capacity_489
 L  arc_capacity_490
 L  arc_capacity_491
 L  arc_capacity_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 G  connected_order_arc_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 G  connected_order_arc_732
 L  arc_capacity_733
 G  connected_order_arc_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 G  connected_order_arc_755
 L  arc_capacity_756
 G  connected_order_arc_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 E  depot_departure_or_bypass_768
 E  depot_return_or_bypass_769
 E  out_degree_770
 E  in_degree_771
 G  order_active_lb_772
 L  order_active_ub_773
 E  segment_load_conservation_774
 G  segment_prefix_lb_775
 L  segment_prefix_ub_776
 E  out_degree_777
 E  in_degree_778
 G  order_active_lb_779
 L  order_active_ub_780
 E  segment_load_conservation_781
 G  segment_prefix_lb_782
 L  segment_prefix_ub_783
 E  out_degree_784
 E  in_degree_785
 G  order_active_lb_786
 L  order_active_ub_787
 E  segment_load_conservation_788
 G  segment_prefix_lb_789
 L  segment_prefix_ub_790
 E  out_degree_791
 E  in_degree_792
 G  order_active_lb_793
 L  order_active_ub_794
 E  segment_load_conservation_795
 G  segment_prefix_lb_796
 L  segment_prefix_ub_797
 E  out_degree_798
 E  in_degree_799
 G  order_active_lb_800
 L  order_active_ub_801
 E  service_visit_def_802
 E  free_load_conservation_803
 E  out_degree_804
 E  in_degree_805
 G  order_active_lb_806
 L  order_active_ub_807
 E  service_visit_def_808
 E  free_load_conservation_809
 E  out_degree_810
 E  in_degree_811
 G  order_active_lb_812
 L  order_active_ub_813
 E  service_visit_def_814
 E  free_load_conservation_815
 E  out_degree_816
 E  in_degree_817
 G  order_active_lb_818
 L  order_active_ub_819
 E  service_visit_def_820
 E  free_load_conservation_821
 E  out_degree_822
 E  in_degree_823
 G  order_active_lb_824
 L  order_active_ub_825
 E  service_visit_def_826
 E  free_load_conservation_827
 E  out_degree_828
 E  in_degree_829
 G  order_active_lb_830
 L  order_active_ub_831
 E  service_visit_def_832
 E  free_load_conservation_833
 E  out_degree_834
 E  in_degree_835
 G  order_active_lb_836
 L  order_active_ub_837
 E  service_visit_def_838
 E  free_load_conservation_839
 E  out_degree_840
 E  in_degree_841
 G  order_active_lb_842
 L  order_active_ub_843
 E  service_visit_def_844
 E  free_load_conservation_845
 G  fixed_segment_relative_order_846
 G  fixed_segment_relative_order_847
 G  fixed_segment_relative_order_848
 L  original_T_including_depot_unload_849
 L  arc_capacity_850
 L  arc_capacity_851
 L  arc_capacity_852
 L  arc_capacity_853
 L  arc_capacity_854
 L  arc_capacity_855
 L  arc_capacity_856
 L  arc_capacity_857
 L  arc_capacity_858
 L  arc_capacity_859
 L  arc_capacity_860
 L  arc_capacity_861
 L  arc_capacity_862
 L  arc_capacity_863
 L  arc_capacity_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 G  connected_order_arc_880
 L  arc_capacity_881
 G  connected_order_arc_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 L  arc_capacity_1139
 L  arc_capacity_1140
 G  connected_order_arc_1141
 L  arc_capacity_1142
 G  connected_order_arc_1143
 L  arc_capacity_1144
 G  connected_order_arc_1145
 L  arc_capacity_1146
 G  connected_order_arc_1147
 L  arc_capacity_1148
 G  connected_order_arc_1149
 L  arc_capacity_1150
 G  connected_order_arc_1151
 L  arc_capacity_1152
 G  connected_order_arc_1153
 L  arc_capacity_1154
 G  connected_order_arc_1155
 L  arc_capacity_1156
 G  connected_order_arc_1157
 L  arc_capacity_1158
 G  connected_order_arc_1159
 L  arc_capacity_1160
 G  connected_order_arc_1161
 L  arc_capacity_1162
 G  connected_order_arc_1163
 L  arc_capacity_1164
 L  arc_capacity_1165
 G  connected_order_arc_1166
 L  arc_capacity_1167
 G  connected_order_arc_1168
 L  arc_capacity_1169
 G  connected_order_arc_1170
 L  arc_capacity_1171
 G  connected_order_arc_1172
 L  arc_capacity_1173
 G  connected_order_arc_1174
 L  arc_capacity_1175
 G  connected_order_arc_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 G  connected_order_arc_1180
 L  arc_capacity_1181
 G  connected_order_arc_1182
 L  arc_capacity_1183
 G  connected_order_arc_1184
 L  arc_capacity_1185
 G  connected_order_arc_1186
 L  arc_capacity_1187
 G  connected_order_arc_1188
 E  depot_departure_or_bypass_1189
 E  depot_return_or_bypass_1190
 E  out_degree_1191
 E  in_degree_1192
 G  order_active_lb_1193
 L  order_active_ub_1194
 E  segment_load_conservation_1195
 G  segment_prefix_lb_1196
 L  segment_prefix_ub_1197
 E  out_degree_1198
 E  in_degree_1199
 G  order_active_lb_1200
 L  order_active_ub_1201
 E  segment_load_conservation_1202
 G  segment_prefix_lb_1203
 L  segment_prefix_ub_1204
 E  out_degree_1205
 E  in_degree_1206
 G  order_active_lb_1207
 L  order_active_ub_1208
 E  segment_load_conservation_1209
 G  segment_prefix_lb_1210
 L  segment_prefix_ub_1211
 E  out_degree_1212
 E  in_degree_1213
 G  order_active_lb_1214
 L  order_active_ub_1215
 E  segment_load_conservation_1216
 G  segment_prefix_lb_1217
 L  segment_prefix_ub_1218
 E  out_degree_1219
 E  in_degree_1220
 G  order_active_lb_1221
 L  order_active_ub_1222
 E  segment_load_conservation_1223
 G  segment_prefix_lb_1224
 L  segment_prefix_ub_1225
 E  out_degree_1226
 E  in_degree_1227
 G  order_active_lb_1228
 L  order_active_ub_1229
 E  service_visit_def_1230
 E  free_load_conservation_1231
 E  out_degree_1232
 E  in_degree_1233
 G  order_active_lb_1234
 L  order_active_ub_1235
 E  service_visit_def_1236
 E  free_load_conservation_1237
 E  out_degree_1238
 E  in_degree_1239
 G  order_active_lb_1240
 L  order_active_ub_1241
 E  service_visit_def_1242
 E  free_load_conservation_1243
 E  out_degree_1244
 E  in_degree_1245
 G  order_active_lb_1246
 L  order_active_ub_1247
 E  service_visit_def_1248
 E  free_load_conservation_1249
 E  out_degree_1250
 E  in_degree_1251
 G  order_active_lb_1252
 L  order_active_ub_1253
 E  service_visit_def_1254
 E  free_load_conservation_1255
 E  out_degree_1256
 E  in_degree_1257
 G  order_active_lb_1258
 L  order_active_ub_1259
 E  service_visit_def_1260
 E  free_load_conservation_1261
 E  out_degree_1262
 E  in_degree_1263
 G  order_active_lb_1264
 L  order_active_ub_1265
 E  service_visit_def_1266
 E  free_load_conservation_1267
 E  out_degree_1268
 E  in_degree_1269
 G  order_active_lb_1270
 L  order_active_ub_1271
 E  service_visit_def_1272
 E  free_load_conservation_1273
 G  fixed_segment_relative_order_1274
 G  fixed_segment_relative_order_1275
 G  fixed_segment_relative_order_1276
 G  fixed_segment_relative_order_1277
 L  original_T_including_depot_unload_1278
 L  arc_capacity_1279
 L  arc_capacity_1280
 L  arc_capacity_1281
 L  arc_capacity_1282
 L  arc_capacity_1283
 L  arc_capacity_1284
 L  arc_capacity_1285
 L  arc_capacity_1286
 L  arc_capacity_1287
 L  arc_capacity_1288
 L  arc_capacity_1289
 L  arc_capacity_1290
 L  arc_capacity_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 G  connected_order_arc_1305
 L  arc_capacity_1306
 G  connected_order_arc_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 G  connected_order_arc_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 G  connected_order_arc_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 G  connected_order_arc_1364
 L  arc_capacity_1365
 G  connected_order_arc_1366
 L  arc_capacity_1367
 G  connected_order_arc_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 G  connected_order_arc_1385
 L  arc_capacity_1386
 G  connected_order_arc_1387
 L  arc_capacity_1388
 G  connected_order_arc_1389
 L  arc_capacity_1390
 G  connected_order_arc_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 G  connected_order_arc_1402
 L  arc_capacity_1403
 G  connected_order_arc_1404
 L  arc_capacity_1405
 G  connected_order_arc_1406
 L  arc_capacity_1407
 G  connected_order_arc_1408
 L  arc_capacity_1409
 G  connected_order_arc_1410
 L  arc_capacity_1411
 G  connected_order_arc_1412
 L  arc_capacity_1413
 G  connected_order_arc_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 G  connected_order_arc_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 L  arc_capacity_1426
 G  connected_order_arc_1427
 L  arc_capacity_1428
 G  connected_order_arc_1429
 L  arc_capacity_1430
 G  connected_order_arc_1431
 L  arc_capacity_1432
 G  connected_order_arc_1433
 L  arc_capacity_1434
 G  connected_order_arc_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 L  arc_capacity_1438
 L  arc_capacity_1439
 G  connected_order_arc_1440
 L  arc_capacity_1441
 G  connected_order_arc_1442
 L  arc_capacity_1443
 G  connected_order_arc_1444
 L  arc_capacity_1445
 G  connected_order_arc_1446
 L  arc_capacity_1447
 G  connected_order_arc_1448
 L  arc_capacity_1449
 G  connected_order_arc_1450
 L  arc_capacity_1451
 G  connected_order_arc_1452
 L  arc_capacity_1453
 G  connected_order_arc_1454
 L  arc_capacity_1455
 G  connected_order_arc_1456
 L  arc_capacity_1457
 G  connected_order_arc_1458
 L  arc_capacity_1459
 L  arc_capacity_1460
 G  connected_order_arc_1461
 L  arc_capacity_1462
 G  connected_order_arc_1463
 L  arc_capacity_1464
 G  connected_order_arc_1465
 L  arc_capacity_1466
 G  connected_order_arc_1467
 L  arc_capacity_1468
 G  connected_order_arc_1469
 L  arc_capacity_1470
 G  connected_order_arc_1471
 L  arc_capacity_1472
 G  connected_order_arc_1473
 L  arc_capacity_1474
 G  connected_order_arc_1475
 L  arc_capacity_1476
 G  connected_order_arc_1477
 L  arc_capacity_1478
 G  connected_order_arc_1479
 L  arc_capacity_1480
 L  arc_capacity_1481
 G  connected_order_arc_1482
 L  arc_capacity_1483
 G  connected_order_arc_1484
 L  arc_capacity_1485
 G  connected_order_arc_1486
 L  arc_capacity_1487
 G  connected_order_arc_1488
 L  arc_capacity_1489
 G  connected_order_arc_1490
 L  arc_capacity_1491
 G  connected_order_arc_1492
 L  arc_capacity_1493
 G  connected_order_arc_1494
 L  arc_capacity_1495
 G  connected_order_arc_1496
 L  arc_capacity_1497
 G  connected_order_arc_1498
 L  arc_capacity_1499
 G  connected_order_arc_1500
 L  arc_capacity_1501
 L  arc_capacity_1502
 G  connected_order_arc_1503
 L  arc_capacity_1504
 G  connected_order_arc_1505
 L  arc_capacity_1506
 G  connected_order_arc_1507
 L  arc_capacity_1508
 G  connected_order_arc_1509
 L  arc_capacity_1510
 G  connected_order_arc_1511
 L  arc_capacity_1512
 G  connected_order_arc_1513
 L  arc_capacity_1514
 G  connected_order_arc_1515
 L  arc_capacity_1516
 G  connected_order_arc_1517
 L  arc_capacity_1518
 G  connected_order_arc_1519
 L  arc_capacity_1520
 G  connected_order_arc_1521
 E  depot_departure_or_bypass_1522
 E  depot_return_or_bypass_1523
 E  out_degree_1524
 E  in_degree_1525
 G  order_active_lb_1526
 L  order_active_ub_1527
 E  segment_load_conservation_1528
 G  segment_prefix_lb_1529
 L  segment_prefix_ub_1530
 E  out_degree_1531
 E  in_degree_1532
 G  order_active_lb_1533
 L  order_active_ub_1534
 E  segment_load_conservation_1535
 G  segment_prefix_lb_1536
 L  segment_prefix_ub_1537
 E  out_degree_1538
 E  in_degree_1539
 G  order_active_lb_1540
 L  order_active_ub_1541
 E  segment_load_conservation_1542
 G  segment_prefix_lb_1543
 L  segment_prefix_ub_1544
 E  out_degree_1545
 E  in_degree_1546
 G  order_active_lb_1547
 L  order_active_ub_1548
 E  service_visit_def_1549
 E  free_load_conservation_1550
 E  out_degree_1551
 E  in_degree_1552
 G  order_active_lb_1553
 L  order_active_ub_1554
 E  service_visit_def_1555
 E  free_load_conservation_1556
 E  out_degree_1557
 E  in_degree_1558
 G  order_active_lb_1559
 L  order_active_ub_1560
 E  service_visit_def_1561
 E  free_load_conservation_1562
 E  out_degree_1563
 E  in_degree_1564
 G  order_active_lb_1565
 L  order_active_ub_1566
 E  service_visit_def_1567
 E  free_load_conservation_1568
 E  out_degree_1569
 E  in_degree_1570
 G  order_active_lb_1571
 L  order_active_ub_1572
 E  service_visit_def_1573
 E  free_load_conservation_1574
 E  out_degree_1575
 E  in_degree_1576
 G  order_active_lb_1577
 L  order_active_ub_1578
 E  service_visit_def_1579
 E  free_load_conservation_1580
 E  out_degree_1581
 E  in_degree_1582
 G  order_active_lb_1583
 L  order_active_ub_1584
 E  service_visit_def_1585
 E  free_load_conservation_1586
 E  out_degree_1587
 E  in_degree_1588
 G  order_active_lb_1589
 L  order_active_ub_1590
 E  service_visit_def_1591
 E  free_load_conservation_1592
 G  fixed_segment_relative_order_1593
 G  fixed_segment_relative_order_1594
 L  original_T_including_depot_unload_1595
COLUMNS
    t         normalized_mass_3_37  -1
    t         normalized_mass_1_80  -1
    t         normalized_mass_31_109  -1
    t         normalized_mass_7_148  -1
    t         normalized_mass_2_183  -1
    t         normalized_mass_4_218  -1
    t         normalized_mass_16_247  -1
    t         normalized_mass_10_290  -1
    t         normalization_351  2.3026190476190479e+01
    t         full_original_Gini_352  -9.4933333333333422e+01
    q         OBJ       1
    q         parent_nonstrict_scope_294  1
    q         full_original_Gini_352  35
    MARKER    'MARKER'                 'INTORG'
    x_3_0     OBJ       0.042
    x_3_0     product_lb_0  -2.5591030952935655e-02
    x_3_0     product_ub_1  -4.3428807775868064e-02
    x_3_0     onehot_3_36  1
    x_3_0     parent_nonstrict_scope_294  0.096
    x_3_0     unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_0  1
    w_3_0     product_ub_1  1
    w_3_0     normalized_mass_3_37  1
    w_3_0     full_original_Gini_352  -2.3026190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       3.0000000000000006e-02
    x_3_1     product_lb_2  -2.5591030952935655e-02
    x_3_1     product_ub_3  -4.3428807775868064e-02
    x_3_1     onehot_3_36  1
    x_3_1     stock_lb_292  1
    x_3_1     stock_ub_293  1
    x_3_1     parent_nonstrict_scope_294  0.084
    x_3_1     unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_2  1
    w_3_1     product_ub_3  1
    w_3_1     normalized_mass_3_37  1
    w_3_1     normalized_ratio_3_38  -0.125
    w_3_1     full_original_Gini_352  -1.9651190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_2     OBJ       1.8000000000000009e-02
    x_3_2     product_lb_4  -2.5591030952935655e-02
    x_3_2     product_ub_5  -4.3428807775868064e-02
    x_3_2     onehot_3_36  1
    x_3_2     stock_lb_292  2
    x_3_2     stock_ub_293  2
    x_3_2     parent_nonstrict_scope_294  7.2000000000000008e-02
    x_3_2     unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_4  1
    w_3_2     product_ub_5  1
    w_3_2     normalized_mass_3_37  1
    w_3_2     normalized_ratio_3_38  -0.25
    w_3_2     full_original_Gini_352  -1.6276190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_3     OBJ       5.9999999999999984e-03
    x_3_3     product_lb_6  -2.5591030952935655e-02
    x_3_3     product_ub_7  -4.3428807775868064e-02
    x_3_3     onehot_3_36  1
    x_3_3     stock_lb_292  3
    x_3_3     stock_ub_293  3
    x_3_3     parent_nonstrict_scope_294  0.06
    x_3_3     unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_6  1
    w_3_3     product_ub_7  1
    w_3_3     normalized_mass_3_37  1
    w_3_3     normalized_ratio_3_38  -0.375
    w_3_3     full_original_Gini_352  -1.3151190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_4     OBJ       -5.9999999999999984e-03
    x_3_4     product_lb_8  -2.5591030952935655e-02
    x_3_4     product_ub_9  -4.3428807775868064e-02
    x_3_4     onehot_3_36  1
    x_3_4     stock_lb_292  4
    x_3_4     stock_ub_293  4
    x_3_4     parent_nonstrict_scope_294  0.048
    x_3_4     unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_4     product_lb_8  1
    w_3_4     product_ub_9  1
    w_3_4     normalized_mass_3_37  1
    w_3_4     normalized_ratio_3_38  -0.5
    w_3_4     full_original_Gini_352  -1.0226190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_5     OBJ       -1.7999999999999995e-02
    x_3_5     product_lb_10  -2.5591030952935655e-02
    x_3_5     product_ub_11  -4.3428807775868064e-02
    x_3_5     onehot_3_36  1
    x_3_5     stock_lb_292  5
    x_3_5     stock_ub_293  5
    x_3_5     parent_nonstrict_scope_294  3.6000000000000004e-02
    x_3_5     unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_5     product_lb_10  1
    w_3_5     product_ub_11  1
    w_3_5     normalized_mass_3_37  1
    w_3_5     normalized_ratio_3_38  -0.625
    w_3_5     full_original_Gini_352  -7.7011904761904759e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_6     OBJ       -0.03
    x_3_6     product_lb_12  -2.5591030952935655e-02
    x_3_6     product_ub_13  -4.3428807775868064e-02
    x_3_6     onehot_3_36  1
    x_3_6     stock_lb_292  6
    x_3_6     stock_ub_293  6
    x_3_6     parent_nonstrict_scope_294  0.024
    x_3_6     unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_6     product_lb_12  1
    w_3_6     product_ub_13  1
    w_3_6     normalized_mass_3_37  1
    w_3_6     normalized_ratio_3_38  -0.75
    w_3_6     full_original_Gini_352  -5.7904761904761894e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_7     OBJ       -4.1999999999999996e-02
    x_3_7     product_lb_14  -2.5591030952935655e-02
    x_3_7     product_ub_15  -4.3428807775868064e-02
    x_3_7     onehot_3_36  1
    x_3_7     stock_lb_292  7
    x_3_7     stock_ub_293  7
    x_3_7     parent_nonstrict_scope_294  0.012
    x_3_7     unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_7     product_lb_14  1
    w_3_7     product_ub_15  1
    w_3_7     normalized_mass_3_37  1
    w_3_7     normalized_ratio_3_38  -0.875
    w_3_7     full_original_Gini_352  -5.3988095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_8     OBJ       -0.054
    x_3_8     product_lb_16  -2.5591030952935655e-02
    x_3_8     product_ub_17  -4.3428807775868064e-02
    x_3_8     onehot_3_36  1
    x_3_8     stock_lb_292  8
    x_3_8     stock_ub_293  8
    x_3_8     unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_8     product_lb_16  1
    w_3_8     product_ub_17  1
    w_3_8     normalized_mass_3_37  1
    w_3_8     normalized_ratio_3_38  -1
    w_3_8     full_original_Gini_352  -5.2738095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_9     OBJ       -4.1999999999999996e-02
    x_3_9     product_lb_18  -2.5591030952935655e-02
    x_3_9     product_ub_19  -4.3428807775868064e-02
    x_3_9     onehot_3_36  1
    x_3_9     stock_lb_292  9
    x_3_9     stock_ub_293  9
    x_3_9     parent_nonstrict_scope_294  0.012
    x_3_9     unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_9     product_lb_18  1
    w_3_9     product_ub_19  1
    w_3_9     normalized_mass_3_37  1
    w_3_9     normalized_ratio_3_38  -1.125
    w_3_9     full_original_Gini_352  -7.8988095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_10    OBJ       -0.03
    x_3_10    product_lb_20  -2.5591030952935655e-02
    x_3_10    product_ub_21  -4.3428807775868064e-02
    x_3_10    onehot_3_36  1
    x_3_10    stock_lb_292  10
    x_3_10    stock_ub_293  10
    x_3_10    parent_nonstrict_scope_294  0.024
    x_3_10    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_10    product_lb_20  1
    w_3_10    product_ub_21  1
    w_3_10    normalized_mass_3_37  1
    w_3_10    normalized_ratio_3_38  -1.25
    w_3_10    full_original_Gini_352  -1.0723809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_11    OBJ       -1.7999999999999995e-02
    x_3_11    product_lb_22  -2.5591030952935655e-02
    x_3_11    product_ub_23  -4.3428807775868064e-02
    x_3_11    onehot_3_36  1
    x_3_11    stock_lb_292  11
    x_3_11    stock_ub_293  11
    x_3_11    parent_nonstrict_scope_294  3.6000000000000004e-02
    x_3_11    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_11    product_lb_22  1
    w_3_11    product_ub_23  1
    w_3_11    normalized_mass_3_37  1
    w_3_11    normalized_ratio_3_38  -1.375
    w_3_11    full_original_Gini_352  -1.4098809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_12    OBJ       -5.9999999999999984e-03
    x_3_12    product_lb_24  -2.5591030952935655e-02
    x_3_12    product_ub_25  -4.3428807775868064e-02
    x_3_12    onehot_3_36  1
    x_3_12    stock_lb_292  12
    x_3_12    stock_ub_293  12
    x_3_12    parent_nonstrict_scope_294  0.048
    MARKER    'MARKER'                 'INTEND'
    w_3_12    product_lb_24  1
    w_3_12    product_ub_25  1
    w_3_12    normalized_mass_3_37  1
    w_3_12    normalized_ratio_3_38  -1.5
    w_3_12    full_original_Gini_352  -1.7473809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_13    OBJ       5.9999999999999984e-03
    x_3_13    product_lb_26  -2.5591030952935655e-02
    x_3_13    product_ub_27  -4.3428807775868064e-02
    x_3_13    onehot_3_36  1
    x_3_13    stock_lb_292  13
    x_3_13    stock_ub_293  13
    x_3_13    parent_nonstrict_scope_294  0.06
    x_3_13    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_13    product_lb_26  1
    w_3_13    product_ub_27  1
    w_3_13    normalized_mass_3_37  1
    w_3_13    normalized_ratio_3_38  -1.625
    w_3_13    full_original_Gini_352  -2.0848809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_14    OBJ       1.8000000000000009e-02
    x_3_14    product_lb_28  -2.5591030952935655e-02
    x_3_14    product_ub_29  -4.3428807775868064e-02
    x_3_14    onehot_3_36  1
    x_3_14    stock_lb_292  14
    x_3_14    stock_ub_293  14
    x_3_14    parent_nonstrict_scope_294  7.2000000000000008e-02
    x_3_14    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_14    product_lb_28  1
    w_3_14    product_ub_29  1
    w_3_14    normalized_mass_3_37  1
    w_3_14    normalized_ratio_3_38  -1.75
    w_3_14    full_original_Gini_352  -2.4223809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_15    OBJ       3.0000000000000006e-02
    x_3_15    product_lb_30  -2.5591030952935655e-02
    x_3_15    product_ub_31  -4.3428807775868064e-02
    x_3_15    onehot_3_36  1
    x_3_15    stock_lb_292  15
    x_3_15    stock_ub_293  15
    x_3_15    parent_nonstrict_scope_294  0.084
    x_3_15    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_15    product_lb_30  1
    w_3_15    product_ub_31  1
    w_3_15    normalized_mass_3_37  1
    w_3_15    normalized_ratio_3_38  -1.875
    w_3_15    full_original_Gini_352  -2.7598809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_16    OBJ       0.042
    x_3_16    product_lb_32  -2.5591030952935655e-02
    x_3_16    product_ub_33  -4.3428807775868064e-02
    x_3_16    onehot_3_36  1
    x_3_16    stock_lb_292  16
    x_3_16    stock_ub_293  16
    x_3_16    parent_nonstrict_scope_294  0.096
    x_3_16    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_16    product_lb_32  1
    w_3_16    product_ub_33  1
    w_3_16    normalized_mass_3_37  1
    w_3_16    normalized_ratio_3_38  -2
    w_3_16    full_original_Gini_352  -3.0973809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_17    OBJ       0.054
    x_3_17    product_lb_34  -2.5591030952935655e-02
    x_3_17    product_ub_35  -4.3428807775868064e-02
    x_3_17    onehot_3_36  1
    x_3_17    stock_lb_292  17
    x_3_17    stock_ub_293  17
    x_3_17    parent_nonstrict_scope_294  0.108
    x_3_17    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_17    product_lb_34  1
    w_3_17    product_ub_35  1
    w_3_17    normalized_mass_3_37  1
    w_3_17    normalized_ratio_3_38  -2.125
    w_3_17    full_original_Gini_352  -3.4348809523809528e+01
    rho_3     normalized_ratio_3_38  1
    rho_3     block_pair_pos_313  -1
    rho_3     block_pair_neg_314  1
    rho_3     block_pair_pos_315  -1
    rho_3     block_pair_neg_316  1
    rho_3     block_pair_pos_317  -1
    rho_3     block_pair_neg_318  1
    rho_3     block_pair_pos_319  -1
    rho_3     block_pair_neg_320  1
    rho_3     block_pair_pos_321  -1
    rho_3     block_pair_neg_322  1
    rho_3     block_pair_pos_323  -1
    rho_3     block_pair_neg_324  1
    rho_3     block_pair_pos_325  -1
    rho_3     block_pair_neg_326  1
    rho_3     normalization_351  1
    MARKER    'MARKER'                 'INTORG'
    x_1_0     OBJ       0.075
    x_1_0     product_lb_39  -2.5591030952935655e-02
    x_1_0     product_ub_40  -4.3428807775868064e-02
    x_1_0     onehot_1_79  1
    x_1_0     parent_nonstrict_scope_294  0.15
    x_1_0     unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_0     product_lb_39  1
    w_1_0     product_ub_40  1
    w_1_0     normalized_mass_1_80  1
    w_1_0     full_original_Gini_352  -2.3026190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_1     OBJ       6.0000000000000012e-02
    x_1_1     product_lb_41  -2.5591030952935655e-02
    x_1_1     product_ub_42  -4.3428807775868064e-02
    x_1_1     onehot_1_79  1
    x_1_1     stock_lb_292  1
    x_1_1     stock_ub_293  1
    x_1_1     parent_nonstrict_scope_294  0.135
    x_1_1     unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_1     product_lb_41  1
    w_1_1     product_ub_42  1
    w_1_1     normalized_mass_1_80  1
    w_1_1     normalized_ratio_1_81  -0.1
    w_1_1     full_original_Gini_352  -2.0326190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_2     OBJ       0.045
    x_1_2     product_lb_43  -2.5591030952935655e-02
    x_1_2     product_ub_44  -4.3428807775868064e-02
    x_1_2     onehot_1_79  1
    x_1_2     stock_lb_292  2
    x_1_2     stock_ub_293  2
    x_1_2     parent_nonstrict_scope_294  0.12
    MARKER    'MARKER'                 'INTEND'
    w_1_2     product_lb_43  1
    w_1_2     product_ub_44  1
    w_1_2     normalized_mass_1_80  1
    w_1_2     normalized_ratio_1_81  -0.2
    w_1_2     full_original_Gini_352  -1.7626190476190477e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_3     OBJ       0.03
    x_1_3     product_lb_45  -2.5591030952935655e-02
    x_1_3     product_ub_46  -4.3428807775868064e-02
    x_1_3     onehot_1_79  1
    x_1_3     stock_lb_292  3
    x_1_3     stock_ub_293  3
    x_1_3     parent_nonstrict_scope_294  0.105
    x_1_3     unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_3     product_lb_45  1
    w_1_3     product_ub_46  1
    w_1_3     normalized_mass_1_80  1
    w_1_3     normalized_ratio_1_81  -3.0000000000000004e-01
    w_1_3     full_original_Gini_352  -1.5026190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_4     OBJ       0.015
    x_1_4     product_lb_47  -2.5591030952935655e-02
    x_1_4     product_ub_48  -4.3428807775868064e-02
    x_1_4     onehot_1_79  1
    x_1_4     stock_lb_292  4
    x_1_4     stock_ub_293  4
    x_1_4     parent_nonstrict_scope_294  0.09
    x_1_4     unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_4     product_lb_47  1
    w_1_4     product_ub_48  1
    w_1_4     normalized_mass_1_80  1
    w_1_4     normalized_ratio_1_81  -0.4
    w_1_4     full_original_Gini_352  -1.2526190476190473e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_5     product_lb_49  -2.5591030952935655e-02
    x_1_5     product_ub_50  -4.3428807775868064e-02
    x_1_5     onehot_1_79  1
    x_1_5     stock_lb_292  5
    x_1_5     stock_ub_293  5
    x_1_5     parent_nonstrict_scope_294  0.075
    x_1_5     unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_5     product_lb_49  1
    w_1_5     product_ub_50  1
    w_1_5     normalized_mass_1_80  1
    w_1_5     normalized_ratio_1_81  -0.5
    w_1_5     full_original_Gini_352  -1.0226190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_6     OBJ       -1.5000000000000013e-02
    x_1_6     product_lb_51  -2.5591030952935655e-02
    x_1_6     product_ub_52  -4.3428807775868064e-02
    x_1_6     onehot_1_79  1
    x_1_6     stock_lb_292  6
    x_1_6     stock_ub_293  6
    x_1_6     parent_nonstrict_scope_294  5.9999999999999984e-02
    x_1_6     unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_6     product_lb_51  1
    w_1_6     product_ub_52  1
    w_1_6     normalized_mass_1_80  1
    w_1_6     normalized_ratio_1_81  -6.0000000000000009e-01
    w_1_6     full_original_Gini_352  -8.1261904761904749e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_7     OBJ       -3.0000000000000006e-02
    x_1_7     product_lb_53  -2.5591030952935655e-02
    x_1_7     product_ub_54  -4.3428807775868064e-02
    x_1_7     onehot_1_79  1
    x_1_7     stock_lb_292  7
    x_1_7     stock_ub_293  7
    x_1_7     parent_nonstrict_scope_294  4.4999999999999991e-02
    x_1_7     unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_7     product_lb_53  1
    w_1_7     product_ub_54  1
    w_1_7     normalized_mass_1_80  1
    w_1_7     normalized_ratio_1_81  -7.0000000000000007e-01
    w_1_7     full_original_Gini_352  -6.4261904761904729e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_8     OBJ       -4.5000000000000005e-02
    x_1_8     product_lb_55  -2.5591030952935655e-02
    x_1_8     product_ub_56  -4.3428807775868064e-02
    x_1_8     onehot_1_79  1
    x_1_8     stock_lb_292  8
    x_1_8     stock_ub_293  8
    x_1_8     parent_nonstrict_scope_294  2.9999999999999992e-02
    x_1_8     unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_8     product_lb_55  1
    w_1_8     product_ub_56  1
    w_1_8     normalized_mass_1_80  1
    w_1_8     normalized_ratio_1_81  -0.8
    w_1_8     full_original_Gini_352  -5.5404761904761930e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_9     OBJ       -0.06
    x_1_9     product_lb_57  -2.5591030952935655e-02
    x_1_9     product_ub_58  -4.3428807775868064e-02
    x_1_9     onehot_1_79  1
    x_1_9     stock_lb_292  9
    x_1_9     stock_ub_293  9
    x_1_9     parent_nonstrict_scope_294  1.4999999999999996e-02
    x_1_9     unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_9     product_lb_57  1
    w_1_9     product_ub_58  1
    w_1_9     normalized_mass_1_80  1
    w_1_9     normalized_ratio_1_81  -0.9
    w_1_9     full_original_Gini_352  -5.3738095238095243e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_10    OBJ       -0.075
    x_1_10    product_lb_59  -2.5591030952935655e-02
    x_1_10    product_ub_60  -4.3428807775868064e-02
    x_1_10    onehot_1_79  1
    x_1_10    stock_lb_292  10
    x_1_10    stock_ub_293  10
    x_1_10    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_10    product_lb_59  1
    w_1_10    product_ub_60  1
    w_1_10    normalized_mass_1_80  1
    w_1_10    normalized_ratio_1_81  -1
    w_1_10    full_original_Gini_352  -5.2738095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_11    OBJ       -5.9999999999999984e-02
    x_1_11    product_lb_61  -2.5591030952935655e-02
    x_1_11    product_ub_62  -4.3428807775868064e-02
    x_1_11    onehot_1_79  1
    x_1_11    stock_lb_292  11
    x_1_11    stock_ub_293  11
    x_1_11    parent_nonstrict_scope_294  1.5000000000000013e-02
    x_1_11    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_11    product_lb_61  1
    w_1_11    product_ub_62  1
    w_1_11    normalized_mass_1_80  1
    w_1_11    normalized_ratio_1_81  -1.1
    w_1_11    full_original_Gini_352  -7.3738095238095269e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_12    OBJ       -4.4999999999999971e-02
    x_1_12    product_lb_63  -2.5591030952935655e-02
    x_1_12    product_ub_64  -4.3428807775868064e-02
    x_1_12    onehot_1_79  1
    x_1_12    stock_lb_292  12
    x_1_12    stock_ub_293  12
    x_1_12    parent_nonstrict_scope_294  3.0000000000000027e-02
    x_1_12    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_12    product_lb_63  1
    w_1_12    product_ub_64  1
    w_1_12    normalized_mass_1_80  1
    w_1_12    normalized_ratio_1_81  -1.2000000000000002e+00
    w_1_12    full_original_Gini_352  -9.4738095238095283e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_13    OBJ       -2.9999999999999992e-02
    x_1_13    product_lb_65  -2.5591030952935655e-02
    x_1_13    product_ub_66  -4.3428807775868064e-02
    x_1_13    onehot_1_79  1
    x_1_13    stock_lb_292  13
    x_1_13    stock_ub_293  13
    x_1_13    parent_nonstrict_scope_294  4.5000000000000005e-02
    x_1_13    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_13    product_lb_65  1
    w_1_13    product_ub_66  1
    w_1_13    normalized_mass_1_80  1
    w_1_13    normalized_ratio_1_81  -1.3
    w_1_13    full_original_Gini_352  -1.2073809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_14    OBJ       -1.4999999999999979e-02
    x_1_14    product_lb_67  -2.5591030952935655e-02
    x_1_14    product_ub_68  -4.3428807775868064e-02
    x_1_14    onehot_1_79  1
    x_1_14    stock_lb_292  14
    x_1_14    stock_ub_293  14
    x_1_14    parent_nonstrict_scope_294  6.0000000000000019e-02
    x_1_14    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_14    product_lb_67  1
    w_1_14    product_ub_68  1
    w_1_14    normalized_mass_1_80  1
    w_1_14    normalized_ratio_1_81  -1.4000000000000001e+00
    w_1_14    full_original_Gini_352  -1.4773809523809531e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_15    product_lb_69  -2.5591030952935655e-02
    x_1_15    product_ub_70  -4.3428807775868064e-02
    x_1_15    onehot_1_79  1
    x_1_15    stock_lb_292  15
    x_1_15    stock_ub_293  15
    x_1_15    parent_nonstrict_scope_294  0.075
    x_1_15    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_15    product_lb_69  1
    w_1_15    product_ub_70  1
    w_1_15    normalized_mass_1_80  1
    w_1_15    normalized_ratio_1_81  -1.5
    w_1_15    full_original_Gini_352  -1.7473809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_16    OBJ       1.5000000000000013e-02
    x_1_16    product_lb_71  -2.5591030952935655e-02
    x_1_16    product_ub_72  -4.3428807775868064e-02
    x_1_16    onehot_1_79  1
    x_1_16    stock_lb_292  16
    x_1_16    stock_ub_293  16
    x_1_16    parent_nonstrict_scope_294  9.0000000000000011e-02
    x_1_16    unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_16    product_lb_71  1
    w_1_16    product_ub_72  1
    w_1_16    normalized_mass_1_80  1
    w_1_16    normalized_ratio_1_81  -1.6
    w_1_16    full_original_Gini_352  -2.0173809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_17    OBJ       3.0000000000000027e-02
    x_1_17    product_lb_73  -2.5591030952935655e-02
    x_1_17    product_ub_74  -4.3428807775868064e-02
    x_1_17    onehot_1_79  1
    x_1_17    stock_lb_292  17
    x_1_17    stock_ub_293  17
    x_1_17    parent_nonstrict_scope_294  1.0500000000000002e-01
    x_1_17    unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_17    product_lb_73  1
    w_1_17    product_ub_74  1
    w_1_17    normalized_mass_1_80  1
    w_1_17    normalized_ratio_1_81  -1.7000000000000002e+00
    w_1_17    full_original_Gini_352  -2.2873809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_18    OBJ       0.045
    x_1_18    product_lb_75  -2.5591030952935655e-02
    x_1_18    product_ub_76  -4.3428807775868064e-02
    x_1_18    onehot_1_79  1
    x_1_18    stock_lb_292  18
    x_1_18    stock_ub_293  18
    x_1_18    parent_nonstrict_scope_294  0.12
    x_1_18    unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_18    product_lb_75  1
    w_1_18    product_ub_76  1
    w_1_18    normalized_mass_1_80  1
    w_1_18    normalized_ratio_1_81  -1.8
    w_1_18    full_original_Gini_352  -2.5573809523809530e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_19    OBJ       6.0000000000000012e-02
    x_1_19    product_lb_77  -2.5591030952935655e-02
    x_1_19    product_ub_78  -4.3428807775868064e-02
    x_1_19    onehot_1_79  1
    x_1_19    stock_lb_292  19
    x_1_19    stock_ub_293  19
    x_1_19    parent_nonstrict_scope_294  0.135
    x_1_19    unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_19    product_lb_77  1
    w_1_19    product_ub_78  1
    w_1_19    normalized_mass_1_80  1
    w_1_19    normalized_ratio_1_81  -1.9000000000000001e+00
    w_1_19    full_original_Gini_352  -2.8273809523809518e+01
    rho_1     normalized_ratio_1_81  1
    rho_1     block_pair_pos_295  -1
    rho_1     block_pair_neg_296  1
    rho_1     block_pair_pos_297  -1
    rho_1     block_pair_neg_298  1
    rho_1     block_pair_pos_299  -1
    rho_1     block_pair_neg_300  1
    rho_1     block_pair_pos_301  -1
    rho_1     block_pair_neg_302  1
    rho_1     block_pair_pos_303  -1
    rho_1     block_pair_neg_304  1
    rho_1     block_pair_pos_305  -1
    rho_1     block_pair_neg_306  1
    rho_1     block_pair_pos_313  1
    rho_1     block_pair_neg_314  -1
    rho_1     normalization_351  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_82  -2.5591030952935655e-02
    x_31_0    product_ub_83  -4.3428807775868064e-02
    x_31_0    onehot_31_108  1
    x_31_0    parent_nonstrict_scope_294  0.0735
    x_31_0    unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_82  1
    w_31_0    product_ub_83  1
    w_31_0    normalized_mass_31_109  1
    w_31_0    full_original_Gini_352  -2.3026190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_84  -2.5591030952935655e-02
    x_31_1    product_ub_85  -4.3428807775868064e-02
    x_31_1    onehot_31_108  1
    x_31_1    stock_lb_292  1
    x_31_1    stock_ub_293  1
    x_31_1    parent_nonstrict_scope_294  0.063
    x_31_1    unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_84  1
    w_31_1    product_ub_85  1
    w_31_1    normalized_mass_31_109  1
    w_31_1    normalized_ratio_31_110  -1.4285714285714285e-01
    w_31_1    full_original_Gini_352  -1.9169047619047625e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_86  -2.5591030952935655e-02
    x_31_2    product_ub_87  -4.3428807775868064e-02
    x_31_2    onehot_31_108  1
    x_31_2    stock_lb_292  2
    x_31_2    stock_ub_293  2
    x_31_2    parent_nonstrict_scope_294  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_86  1
    w_31_2    product_ub_87  1
    w_31_2    normalized_mass_31_109  1
    w_31_2    normalized_ratio_31_110  -2.8571428571428570e-01
    w_31_2    full_original_Gini_352  -1.5383333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_88  -2.5591030952935655e-02
    x_31_3    product_ub_89  -4.3428807775868064e-02
    x_31_3    onehot_31_108  1
    x_31_3    stock_lb_292  3
    x_31_3    stock_ub_293  3
    x_31_3    parent_nonstrict_scope_294  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_88  1
    w_31_3    product_ub_89  1
    w_31_3    normalized_mass_31_109  1
    w_31_3    normalized_ratio_31_110  -4.2857142857142855e-01
    w_31_3    full_original_Gini_352  -1.1869047619047619e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_90  -2.5591030952935655e-02
    x_31_4    product_ub_91  -4.3428807775868064e-02
    x_31_4    onehot_31_108  1
    x_31_4    stock_lb_292  4
    x_31_4    stock_ub_293  4
    x_31_4    parent_nonstrict_scope_294  0.0315
    x_31_4    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_90  1
    w_31_4    product_ub_91  1
    w_31_4    normalized_mass_31_109  1
    w_31_4    normalized_ratio_31_110  -5.7142857142857140e-01
    w_31_4    full_original_Gini_352  -8.7261904761904781e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_92  -2.5591030952935655e-02
    x_31_5    product_ub_93  -4.3428807775868064e-02
    x_31_5    onehot_31_108  1
    x_31_5    stock_lb_292  5
    x_31_5    stock_ub_293  5
    x_31_5    parent_nonstrict_scope_294  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_92  1
    w_31_5    product_ub_93  1
    w_31_5    normalized_mass_31_109  1
    w_31_5    normalized_ratio_31_110  -7.1428571428571419e-01
    w_31_5    full_original_Gini_352  -6.1833333333333336e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_94  -2.5591030952935655e-02
    x_31_6    product_ub_95  -4.3428807775868064e-02
    x_31_6    onehot_31_108  1
    x_31_6    stock_lb_292  6
    x_31_6    stock_ub_293  6
    x_31_6    parent_nonstrict_scope_294  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_94  1
    w_31_6    product_ub_95  1
    w_31_6    normalized_mass_31_109  1
    w_31_6    normalized_ratio_31_110  -8.5714285714285710e-01
    w_31_6    full_original_Gini_352  -5.4166666666666679e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_96  -2.5591030952935655e-02
    x_31_7    product_ub_97  -4.3428807775868064e-02
    x_31_7    onehot_31_108  1
    x_31_7    stock_lb_292  7
    x_31_7    stock_ub_293  7
    x_31_7    unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_96  1
    w_31_7    product_ub_97  1
    w_31_7    normalized_mass_31_109  1
    w_31_7    normalized_ratio_31_110  -1
    w_31_7    full_original_Gini_352  -5.2738095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_98  -2.5591030952935655e-02
    x_31_8    product_ub_99  -4.3428807775868064e-02
    x_31_8    onehot_31_108  1
    x_31_8    stock_lb_292  8
    x_31_8    stock_ub_293  8
    x_31_8    parent_nonstrict_scope_294  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_98  1
    w_31_8    product_ub_99  1
    w_31_8    normalized_mass_31_109  1
    w_31_8    normalized_ratio_31_110  -1.1428571428571428e+00
    w_31_8    full_original_Gini_352  -8.2738095238095219e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_100  -2.5591030952935655e-02
    x_31_9    product_ub_101  -4.3428807775868064e-02
    x_31_9    onehot_31_108  1
    x_31_9    stock_lb_292  9
    x_31_9    stock_ub_293  9
    x_31_9    parent_nonstrict_scope_294  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_100  1
    w_31_9    product_ub_101  1
    w_31_9    normalized_mass_31_109  1
    w_31_9    normalized_ratio_31_110  -1.2857142857142856e+00
    w_31_9    full_original_Gini_352  -1.1688095238095229e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_102  -2.5591030952935655e-02
    x_31_10   product_ub_103  -4.3428807775868064e-02
    x_31_10   onehot_31_108  1
    x_31_10   stock_lb_292  10
    x_31_10   stock_ub_293  10
    x_31_10   parent_nonstrict_scope_294  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_102  1
    w_31_10   product_ub_103  1
    w_31_10   normalized_mass_31_109  1
    w_31_10   normalized_ratio_31_110  -1.4285714285714284e+00
    w_31_10   full_original_Gini_352  -1.5545238095238092e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_104  -2.5591030952935655e-02
    x_31_11   product_ub_105  -4.3428807775868064e-02
    x_31_11   onehot_31_108  1
    x_31_11   stock_lb_292  11
    x_31_11   stock_ub_293  11
    x_31_11   parent_nonstrict_scope_294  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_104  1
    w_31_11   product_ub_105  1
    w_31_11   normalized_mass_31_109  1
    w_31_11   normalized_ratio_31_110  -1.5714285714285714e+00
    w_31_11   full_original_Gini_352  -1.9402380952380952e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_106  -2.5591030952935655e-02
    x_31_12   product_ub_107  -4.3428807775868064e-02
    x_31_12   onehot_31_108  1
    x_31_12   stock_lb_292  12
    x_31_12   stock_ub_293  12
    x_31_12   parent_nonstrict_scope_294  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_106  1
    w_31_12   product_ub_107  1
    w_31_12   normalized_mass_31_109  1
    w_31_12   normalized_ratio_31_110  -1.7142857142857142e+00
    w_31_12   full_original_Gini_352  -2.3259523809523809e+01
    rho_31    normalized_ratio_31_110  1
    rho_31    block_pair_pos_305  1
    rho_31    block_pair_neg_306  -1
    rho_31    block_pair_pos_325  1
    rho_31    block_pair_neg_326  -1
    rho_31    block_pair_pos_341  -1
    rho_31    block_pair_neg_342  1
    rho_31    block_pair_pos_343  -1
    rho_31    block_pair_neg_344  1
    rho_31    block_pair_pos_345  -1
    rho_31    block_pair_neg_346  1
    rho_31    block_pair_pos_347  -1
    rho_31    block_pair_neg_348  1
    rho_31    block_pair_pos_349  -1
    rho_31    block_pair_neg_350  1
    rho_31    normalization_351  1
    MARKER    'MARKER'                 'INTORG'
    x_7_0     OBJ       0.042
    x_7_0     product_lb_111  -2.5591030952935655e-02
    x_7_0     product_ub_112  -4.3428807775868064e-02
    x_7_0     onehot_7_147  1
    x_7_0     parent_nonstrict_scope_294  0.096
    x_7_0     unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_0     product_lb_111  1
    w_7_0     product_ub_112  1
    w_7_0     normalized_mass_7_148  1
    w_7_0     full_original_Gini_352  -2.3026190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_1     OBJ       3.0000000000000006e-02
    x_7_1     product_lb_113  -2.5591030952935655e-02
    x_7_1     product_ub_114  -4.3428807775868064e-02
    x_7_1     onehot_7_147  1
    x_7_1     stock_lb_292  1
    x_7_1     stock_ub_293  1
    x_7_1     parent_nonstrict_scope_294  0.084
    x_7_1     unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_1     product_lb_113  1
    w_7_1     product_ub_114  1
    w_7_1     normalized_mass_7_148  1
    w_7_1     normalized_ratio_7_149  -0.125
    w_7_1     full_original_Gini_352  -1.9651190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_2     OBJ       1.8000000000000009e-02
    x_7_2     product_lb_115  -2.5591030952935655e-02
    x_7_2     product_ub_116  -4.3428807775868064e-02
    x_7_2     onehot_7_147  1
    x_7_2     stock_lb_292  2
    x_7_2     stock_ub_293  2
    x_7_2     parent_nonstrict_scope_294  7.2000000000000008e-02
    x_7_2     unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_2     product_lb_115  1
    w_7_2     product_ub_116  1
    w_7_2     normalized_mass_7_148  1
    w_7_2     normalized_ratio_7_149  -0.25
    w_7_2     full_original_Gini_352  -1.6276190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_3     OBJ       5.9999999999999984e-03
    x_7_3     product_lb_117  -2.5591030952935655e-02
    x_7_3     product_ub_118  -4.3428807775868064e-02
    x_7_3     onehot_7_147  1
    x_7_3     stock_lb_292  3
    x_7_3     stock_ub_293  3
    x_7_3     parent_nonstrict_scope_294  0.06
    x_7_3     unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_3     product_lb_117  1
    w_7_3     product_ub_118  1
    w_7_3     normalized_mass_7_148  1
    w_7_3     normalized_ratio_7_149  -0.375
    w_7_3     full_original_Gini_352  -1.3151190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_4     OBJ       -5.9999999999999984e-03
    x_7_4     product_lb_119  -2.5591030952935655e-02
    x_7_4     product_ub_120  -4.3428807775868064e-02
    x_7_4     onehot_7_147  1
    x_7_4     stock_lb_292  4
    x_7_4     stock_ub_293  4
    x_7_4     parent_nonstrict_scope_294  0.048
    x_7_4     unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_4     product_lb_119  1
    w_7_4     product_ub_120  1
    w_7_4     normalized_mass_7_148  1
    w_7_4     normalized_ratio_7_149  -0.5
    w_7_4     full_original_Gini_352  -1.0226190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_5     OBJ       -1.7999999999999995e-02
    x_7_5     product_lb_121  -2.5591030952935655e-02
    x_7_5     product_ub_122  -4.3428807775868064e-02
    x_7_5     onehot_7_147  1
    x_7_5     stock_lb_292  5
    x_7_5     stock_ub_293  5
    x_7_5     parent_nonstrict_scope_294  3.6000000000000004e-02
    x_7_5     unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_5     product_lb_121  1
    w_7_5     product_ub_122  1
    w_7_5     normalized_mass_7_148  1
    w_7_5     normalized_ratio_7_149  -0.625
    w_7_5     full_original_Gini_352  -7.7011904761904759e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_6     OBJ       -0.03
    x_7_6     product_lb_123  -2.5591030952935655e-02
    x_7_6     product_ub_124  -4.3428807775868064e-02
    x_7_6     onehot_7_147  1
    x_7_6     stock_lb_292  6
    x_7_6     stock_ub_293  6
    x_7_6     parent_nonstrict_scope_294  0.024
    x_7_6     unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_6     product_lb_123  1
    w_7_6     product_ub_124  1
    w_7_6     normalized_mass_7_148  1
    w_7_6     normalized_ratio_7_149  -0.75
    w_7_6     full_original_Gini_352  -5.7904761904761894e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_7     OBJ       -4.1999999999999996e-02
    x_7_7     product_lb_125  -2.5591030952935655e-02
    x_7_7     product_ub_126  -4.3428807775868064e-02
    x_7_7     onehot_7_147  1
    x_7_7     stock_lb_292  7
    x_7_7     stock_ub_293  7
    x_7_7     parent_nonstrict_scope_294  0.012
    x_7_7     unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_7     product_lb_125  1
    w_7_7     product_ub_126  1
    w_7_7     normalized_mass_7_148  1
    w_7_7     normalized_ratio_7_149  -0.875
    w_7_7     full_original_Gini_352  -5.3988095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_8     OBJ       -0.054
    x_7_8     product_lb_127  -2.5591030952935655e-02
    x_7_8     product_ub_128  -4.3428807775868064e-02
    x_7_8     onehot_7_147  1
    x_7_8     stock_lb_292  8
    x_7_8     stock_ub_293  8
    x_7_8     unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_8     product_lb_127  1
    w_7_8     product_ub_128  1
    w_7_8     normalized_mass_7_148  1
    w_7_8     normalized_ratio_7_149  -1
    w_7_8     full_original_Gini_352  -5.2738095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_9     OBJ       -4.1999999999999996e-02
    x_7_9     product_lb_129  -2.5591030952935655e-02
    x_7_9     product_ub_130  -4.3428807775868064e-02
    x_7_9     onehot_7_147  1
    x_7_9     stock_lb_292  9
    x_7_9     stock_ub_293  9
    x_7_9     parent_nonstrict_scope_294  0.012
    x_7_9     unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_9     product_lb_129  1
    w_7_9     product_ub_130  1
    w_7_9     normalized_mass_7_148  1
    w_7_9     normalized_ratio_7_149  -1.125
    w_7_9     full_original_Gini_352  -7.8988095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_10    OBJ       -0.03
    x_7_10    product_lb_131  -2.5591030952935655e-02
    x_7_10    product_ub_132  -4.3428807775868064e-02
    x_7_10    onehot_7_147  1
    x_7_10    stock_lb_292  10
    x_7_10    stock_ub_293  10
    x_7_10    parent_nonstrict_scope_294  0.024
    x_7_10    unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_10    product_lb_131  1
    w_7_10    product_ub_132  1
    w_7_10    normalized_mass_7_148  1
    w_7_10    normalized_ratio_7_149  -1.25
    w_7_10    full_original_Gini_352  -1.0723809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_11    OBJ       -1.7999999999999995e-02
    x_7_11    product_lb_133  -2.5591030952935655e-02
    x_7_11    product_ub_134  -4.3428807775868064e-02
    x_7_11    onehot_7_147  1
    x_7_11    stock_lb_292  11
    x_7_11    stock_ub_293  11
    x_7_11    parent_nonstrict_scope_294  3.6000000000000004e-02
    x_7_11    unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_11    product_lb_133  1
    w_7_11    product_ub_134  1
    w_7_11    normalized_mass_7_148  1
    w_7_11    normalized_ratio_7_149  -1.375
    w_7_11    full_original_Gini_352  -1.4098809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_12    OBJ       -5.9999999999999984e-03
    x_7_12    product_lb_135  -2.5591030952935655e-02
    x_7_12    product_ub_136  -4.3428807775868064e-02
    x_7_12    onehot_7_147  1
    x_7_12    stock_lb_292  12
    x_7_12    stock_ub_293  12
    x_7_12    parent_nonstrict_scope_294  0.048
    MARKER    'MARKER'                 'INTEND'
    w_7_12    product_lb_135  1
    w_7_12    product_ub_136  1
    w_7_12    normalized_mass_7_148  1
    w_7_12    normalized_ratio_7_149  -1.5
    w_7_12    full_original_Gini_352  -1.7473809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_13    OBJ       5.9999999999999984e-03
    x_7_13    product_lb_137  -2.5591030952935655e-02
    x_7_13    product_ub_138  -4.3428807775868064e-02
    x_7_13    onehot_7_147  1
    x_7_13    stock_lb_292  13
    x_7_13    stock_ub_293  13
    x_7_13    parent_nonstrict_scope_294  0.06
    x_7_13    unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_13    product_lb_137  1
    w_7_13    product_ub_138  1
    w_7_13    normalized_mass_7_148  1
    w_7_13    normalized_ratio_7_149  -1.625
    w_7_13    full_original_Gini_352  -2.0848809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_14    OBJ       1.8000000000000009e-02
    x_7_14    product_lb_139  -2.5591030952935655e-02
    x_7_14    product_ub_140  -4.3428807775868064e-02
    x_7_14    onehot_7_147  1
    x_7_14    stock_lb_292  14
    x_7_14    stock_ub_293  14
    x_7_14    parent_nonstrict_scope_294  7.2000000000000008e-02
    x_7_14    unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_14    product_lb_139  1
    w_7_14    product_ub_140  1
    w_7_14    normalized_mass_7_148  1
    w_7_14    normalized_ratio_7_149  -1.75
    w_7_14    full_original_Gini_352  -2.4223809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_15    OBJ       3.0000000000000006e-02
    x_7_15    product_lb_141  -2.5591030952935655e-02
    x_7_15    product_ub_142  -4.3428807775868064e-02
    x_7_15    onehot_7_147  1
    x_7_15    stock_lb_292  15
    x_7_15    stock_ub_293  15
    x_7_15    parent_nonstrict_scope_294  0.084
    x_7_15    unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_15    product_lb_141  1
    w_7_15    product_ub_142  1
    w_7_15    normalized_mass_7_148  1
    w_7_15    normalized_ratio_7_149  -1.875
    w_7_15    full_original_Gini_352  -2.7598809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_16    OBJ       0.042
    x_7_16    product_lb_143  -2.5591030952935655e-02
    x_7_16    product_ub_144  -4.3428807775868064e-02
    x_7_16    onehot_7_147  1
    x_7_16    stock_lb_292  16
    x_7_16    stock_ub_293  16
    x_7_16    parent_nonstrict_scope_294  0.096
    x_7_16    unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_16    product_lb_143  1
    w_7_16    product_ub_144  1
    w_7_16    normalized_mass_7_148  1
    w_7_16    normalized_ratio_7_149  -2
    w_7_16    full_original_Gini_352  -3.0973809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_17    OBJ       0.054
    x_7_17    product_lb_145  -2.5591030952935655e-02
    x_7_17    product_ub_146  -4.3428807775868064e-02
    x_7_17    onehot_7_147  1
    x_7_17    stock_lb_292  17
    x_7_17    stock_ub_293  17
    x_7_17    parent_nonstrict_scope_294  0.108
    x_7_17    unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_17    product_lb_145  1
    w_7_17    product_ub_146  1
    w_7_17    normalized_mass_7_148  1
    w_7_17    normalized_ratio_7_149  -2.125
    w_7_17    full_original_Gini_352  -3.4348809523809528e+01
    rho_7     normalized_ratio_7_149  1
    rho_7     block_pair_pos_299  1
    rho_7     block_pair_neg_300  -1
    rho_7     block_pair_pos_319  1
    rho_7     block_pair_neg_320  -1
    rho_7     block_pair_pos_331  -1
    rho_7     block_pair_neg_332  1
    rho_7     block_pair_pos_333  -1
    rho_7     block_pair_neg_334  1
    rho_7     block_pair_pos_335  -1
    rho_7     block_pair_neg_336  1
    rho_7     block_pair_pos_337  -1
    rho_7     block_pair_neg_338  1
    rho_7     block_pair_pos_345  1
    rho_7     block_pair_neg_346  -1
    rho_7     normalization_351  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_150  -2.5591030952935655e-02
    x_2_0     product_ub_151  -4.3428807775868064e-02
    x_2_0     onehot_2_182  1
    x_2_0     parent_nonstrict_scope_294  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_150  1
    w_2_0     product_ub_151  1
    w_2_0     normalized_mass_2_183  1
    w_2_0     full_original_Gini_352  -2.3026190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_152  -2.5591030952935655e-02
    x_2_1     product_ub_153  -4.3428807775868064e-02
    x_2_1     onehot_2_182  1
    x_2_1     stock_lb_292  1
    x_2_1     stock_ub_293  1
    x_2_1     parent_nonstrict_scope_294  0.063
    x_2_1     unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_152  1
    w_2_1     product_ub_153  1
    w_2_1     normalized_mass_2_183  1
    w_2_1     normalized_ratio_2_184  -1.4285714285714285e-01
    w_2_1     full_original_Gini_352  -1.9169047619047625e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_154  -2.5591030952935655e-02
    x_2_2     product_ub_155  -4.3428807775868064e-02
    x_2_2     onehot_2_182  1
    x_2_2     stock_lb_292  2
    x_2_2     stock_ub_293  2
    x_2_2     parent_nonstrict_scope_294  0.0525
    x_2_2     unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_154  1
    w_2_2     product_ub_155  1
    w_2_2     normalized_mass_2_183  1
    w_2_2     normalized_ratio_2_184  -2.8571428571428570e-01
    w_2_2     full_original_Gini_352  -1.5383333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_156  -2.5591030952935655e-02
    x_2_3     product_ub_157  -4.3428807775868064e-02
    x_2_3     onehot_2_182  1
    x_2_3     stock_lb_292  3
    x_2_3     stock_ub_293  3
    x_2_3     parent_nonstrict_scope_294  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_156  1
    w_2_3     product_ub_157  1
    w_2_3     normalized_mass_2_183  1
    w_2_3     normalized_ratio_2_184  -4.2857142857142855e-01
    w_2_3     full_original_Gini_352  -1.1869047619047619e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_158  -2.5591030952935655e-02
    x_2_4     product_ub_159  -4.3428807775868064e-02
    x_2_4     onehot_2_182  1
    x_2_4     stock_lb_292  4
    x_2_4     stock_ub_293  4
    x_2_4     parent_nonstrict_scope_294  0.0315
    x_2_4     unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_158  1
    w_2_4     product_ub_159  1
    w_2_4     normalized_mass_2_183  1
    w_2_4     normalized_ratio_2_184  -5.7142857142857140e-01
    w_2_4     full_original_Gini_352  -8.7261904761904781e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_160  -2.5591030952935655e-02
    x_2_5     product_ub_161  -4.3428807775868064e-02
    x_2_5     onehot_2_182  1
    x_2_5     stock_lb_292  5
    x_2_5     stock_ub_293  5
    x_2_5     parent_nonstrict_scope_294  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_160  1
    w_2_5     product_ub_161  1
    w_2_5     normalized_mass_2_183  1
    w_2_5     normalized_ratio_2_184  -7.1428571428571419e-01
    w_2_5     full_original_Gini_352  -6.1833333333333336e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_162  -2.5591030952935655e-02
    x_2_6     product_ub_163  -4.3428807775868064e-02
    x_2_6     onehot_2_182  1
    x_2_6     stock_lb_292  6
    x_2_6     stock_ub_293  6
    x_2_6     parent_nonstrict_scope_294  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_162  1
    w_2_6     product_ub_163  1
    w_2_6     normalized_mass_2_183  1
    w_2_6     normalized_ratio_2_184  -8.5714285714285710e-01
    w_2_6     full_original_Gini_352  -5.4166666666666679e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_164  -2.5591030952935655e-02
    x_2_7     product_ub_165  -4.3428807775868064e-02
    x_2_7     onehot_2_182  1
    x_2_7     stock_lb_292  7
    x_2_7     stock_ub_293  7
    x_2_7     unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_164  1
    w_2_7     product_ub_165  1
    w_2_7     normalized_mass_2_183  1
    w_2_7     normalized_ratio_2_184  -1
    w_2_7     full_original_Gini_352  -5.2738095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_166  -2.5591030952935655e-02
    x_2_8     product_ub_167  -4.3428807775868064e-02
    x_2_8     onehot_2_182  1
    x_2_8     stock_lb_292  8
    x_2_8     stock_ub_293  8
    x_2_8     parent_nonstrict_scope_294  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_166  1
    w_2_8     product_ub_167  1
    w_2_8     normalized_mass_2_183  1
    w_2_8     normalized_ratio_2_184  -1.1428571428571428e+00
    w_2_8     full_original_Gini_352  -8.2738095238095219e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_168  -2.5591030952935655e-02
    x_2_9     product_ub_169  -4.3428807775868064e-02
    x_2_9     onehot_2_182  1
    x_2_9     stock_lb_292  9
    x_2_9     stock_ub_293  9
    x_2_9     parent_nonstrict_scope_294  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_168  1
    w_2_9     product_ub_169  1
    w_2_9     normalized_mass_2_183  1
    w_2_9     normalized_ratio_2_184  -1.2857142857142856e+00
    w_2_9     full_original_Gini_352  -1.1688095238095229e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_170  -2.5591030952935655e-02
    x_2_10    product_ub_171  -4.3428807775868064e-02
    x_2_10    onehot_2_182  1
    x_2_10    stock_lb_292  10
    x_2_10    stock_ub_293  10
    x_2_10    parent_nonstrict_scope_294  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_170  1
    w_2_10    product_ub_171  1
    w_2_10    normalized_mass_2_183  1
    w_2_10    normalized_ratio_2_184  -1.4285714285714284e+00
    w_2_10    full_original_Gini_352  -1.5545238095238092e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_172  -2.5591030952935655e-02
    x_2_11    product_ub_173  -4.3428807775868064e-02
    x_2_11    onehot_2_182  1
    x_2_11    stock_lb_292  11
    x_2_11    stock_ub_293  11
    x_2_11    parent_nonstrict_scope_294  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_428  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_172  1
    w_2_11    product_ub_173  1
    w_2_11    normalized_mass_2_183  1
    w_2_11    normalized_ratio_2_184  -1.5714285714285714e+00
    w_2_11    full_original_Gini_352  -1.9402380952380952e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_174  -2.5591030952935655e-02
    x_2_12    product_ub_175  -4.3428807775868064e-02
    x_2_12    onehot_2_182  1
    x_2_12    stock_lb_292  12
    x_2_12    stock_ub_293  12
    x_2_12    parent_nonstrict_scope_294  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_429  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_174  1
    w_2_12    product_ub_175  1
    w_2_12    normalized_mass_2_183  1
    w_2_12    normalized_ratio_2_184  -1.7142857142857142e+00
    w_2_12    full_original_Gini_352  -2.3259523809523809e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_176  -2.5591030952935655e-02
    x_2_13    product_ub_177  -4.3428807775868064e-02
    x_2_13    onehot_2_182  1
    x_2_13    stock_lb_292  13
    x_2_13    stock_ub_293  13
    x_2_13    parent_nonstrict_scope_294  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_430  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_176  1
    w_2_13    product_ub_177  1
    w_2_13    normalized_mass_2_183  1
    w_2_13    normalized_ratio_2_184  -1.8571428571428570e+00
    w_2_13    full_original_Gini_352  -2.7116666666666667e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_178  -2.5591030952935655e-02
    x_2_14    product_ub_179  -4.3428807775868064e-02
    x_2_14    onehot_2_182  1
    x_2_14    stock_lb_292  14
    x_2_14    stock_ub_293  14
    x_2_14    parent_nonstrict_scope_294  0.0735
    x_2_14    unique_nonzero_owner_431  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_178  1
    w_2_14    product_ub_179  1
    w_2_14    normalized_mass_2_183  1
    w_2_14    normalized_ratio_2_184  -2
    w_2_14    full_original_Gini_352  -3.0973809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_180  -2.5591030952935655e-02
    x_2_15    product_ub_181  -4.3428807775868064e-02
    x_2_15    onehot_2_182  1
    x_2_15    stock_lb_292  15
    x_2_15    stock_ub_293  15
    x_2_15    parent_nonstrict_scope_294  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_432  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_180  1
    w_2_15    product_ub_181  1
    w_2_15    normalized_mass_2_183  1
    w_2_15    normalized_ratio_2_184  -2.1428571428571428e+00
    w_2_15    full_original_Gini_352  -3.4830952380952382e+01
    rho_2     normalized_ratio_2_184  1
    rho_2     block_pair_pos_295  1
    rho_2     block_pair_neg_296  -1
    rho_2     block_pair_pos_307  -1
    rho_2     block_pair_neg_308  1
    rho_2     block_pair_pos_309  -1
    rho_2     block_pair_neg_310  1
    rho_2     block_pair_pos_311  -1
    rho_2     block_pair_neg_312  1
    rho_2     block_pair_pos_315  1
    rho_2     block_pair_neg_316  -1
    rho_2     block_pair_pos_331  1
    rho_2     block_pair_neg_332  -1
    rho_2     block_pair_pos_341  1
    rho_2     block_pair_neg_342  -1
    rho_2     normalization_351  1
    MARKER    'MARKER'                 'INTORG'
    x_4_0     OBJ       0.0315
    x_4_0     product_lb_185  -2.5591030952935655e-02
    x_4_0     product_ub_186  -4.3428807775868064e-02
    x_4_0     onehot_4_217  1
    x_4_0     parent_nonstrict_scope_294  0.0735
    x_4_0     unique_nonzero_owner_433  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_0     product_lb_185  1
    w_4_0     product_ub_186  1
    w_4_0     normalized_mass_4_218  1
    w_4_0     full_original_Gini_352  -2.3026190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_1     OBJ       2.1000000000000005e-02
    x_4_1     product_lb_187  -2.5591030952935655e-02
    x_4_1     product_ub_188  -4.3428807775868064e-02
    x_4_1     onehot_4_217  1
    x_4_1     stock_lb_292  1
    x_4_1     stock_ub_293  1
    x_4_1     parent_nonstrict_scope_294  0.063
    x_4_1     unique_nonzero_owner_434  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_1     product_lb_187  1
    w_4_1     product_ub_188  1
    w_4_1     normalized_mass_4_218  1
    w_4_1     normalized_ratio_4_219  -1.4285714285714285e-01
    w_4_1     full_original_Gini_352  -1.9169047619047625e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_2     OBJ       1.0500000000000002e-02
    x_4_2     product_lb_189  -2.5591030952935655e-02
    x_4_2     product_ub_190  -4.3428807775868064e-02
    x_4_2     onehot_4_217  1
    x_4_2     stock_lb_292  2
    x_4_2     stock_ub_293  2
    x_4_2     parent_nonstrict_scope_294  0.0525
    x_4_2     unique_nonzero_owner_435  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_2     product_lb_189  1
    w_4_2     product_ub_190  1
    w_4_2     normalized_mass_4_218  1
    w_4_2     normalized_ratio_4_219  -2.8571428571428570e-01
    w_4_2     full_original_Gini_352  -1.5383333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_3     product_lb_191  -2.5591030952935655e-02
    x_4_3     product_ub_192  -4.3428807775868064e-02
    x_4_3     onehot_4_217  1
    x_4_3     stock_lb_292  3
    x_4_3     stock_ub_293  3
    x_4_3     parent_nonstrict_scope_294  4.1999999999999996e-02
    x_4_3     unique_nonzero_owner_436  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_3     product_lb_191  1
    w_4_3     product_ub_192  1
    w_4_3     normalized_mass_4_218  1
    w_4_3     normalized_ratio_4_219  -4.2857142857142855e-01
    w_4_3     full_original_Gini_352  -1.1869047619047619e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_4     OBJ       -1.0499999999999995e-02
    x_4_4     product_lb_193  -2.5591030952935655e-02
    x_4_4     product_ub_194  -4.3428807775868064e-02
    x_4_4     onehot_4_217  1
    x_4_4     stock_lb_292  4
    x_4_4     stock_ub_293  4
    x_4_4     parent_nonstrict_scope_294  0.0315
    x_4_4     unique_nonzero_owner_437  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_4     product_lb_193  1
    w_4_4     product_ub_194  1
    w_4_4     normalized_mass_4_218  1
    w_4_4     normalized_ratio_4_219  -5.7142857142857140e-01
    w_4_4     full_original_Gini_352  -8.7261904761904781e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_5     OBJ       -2.0999999999999991e-02
    x_4_5     product_lb_195  -2.5591030952935655e-02
    x_4_5     product_ub_196  -4.3428807775868064e-02
    x_4_5     onehot_4_217  1
    x_4_5     stock_lb_292  5
    x_4_5     stock_ub_293  5
    x_4_5     parent_nonstrict_scope_294  2.1000000000000005e-02
    x_4_5     unique_nonzero_owner_438  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_5     product_lb_195  1
    w_4_5     product_ub_196  1
    w_4_5     normalized_mass_4_218  1
    w_4_5     normalized_ratio_4_219  -7.1428571428571419e-01
    w_4_5     full_original_Gini_352  -6.1833333333333336e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_6     OBJ       -3.1499999999999993e-02
    x_4_6     product_lb_197  -2.5591030952935655e-02
    x_4_6     product_ub_198  -4.3428807775868064e-02
    x_4_6     onehot_4_217  1
    x_4_6     stock_lb_292  6
    x_4_6     stock_ub_293  6
    x_4_6     parent_nonstrict_scope_294  1.0500000000000002e-02
    x_4_6     unique_nonzero_owner_439  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_6     product_lb_197  1
    w_4_6     product_ub_198  1
    w_4_6     normalized_mass_4_218  1
    w_4_6     normalized_ratio_4_219  -8.5714285714285710e-01
    w_4_6     full_original_Gini_352  -5.4166666666666679e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_7     OBJ       -4.1999999999999996e-02
    x_4_7     product_lb_199  -2.5591030952935655e-02
    x_4_7     product_ub_200  -4.3428807775868064e-02
    x_4_7     onehot_4_217  1
    x_4_7     stock_lb_292  7
    x_4_7     stock_ub_293  7
    x_4_7     unique_nonzero_owner_440  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_7     product_lb_199  1
    w_4_7     product_ub_200  1
    w_4_7     normalized_mass_4_218  1
    w_4_7     normalized_ratio_4_219  -1
    w_4_7     full_original_Gini_352  -5.2738095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_8     OBJ       -0.0315
    x_4_8     product_lb_201  -2.5591030952935655e-02
    x_4_8     product_ub_202  -4.3428807775868064e-02
    x_4_8     onehot_4_217  1
    x_4_8     stock_lb_292  8
    x_4_8     stock_ub_293  8
    x_4_8     parent_nonstrict_scope_294  1.0499999999999995e-02
    x_4_8     unique_nonzero_owner_441  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_8     product_lb_201  1
    w_4_8     product_ub_202  1
    w_4_8     normalized_mass_4_218  1
    w_4_8     normalized_ratio_4_219  -1.1428571428571428e+00
    w_4_8     full_original_Gini_352  -8.2738095238095219e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_9     OBJ       -2.1000000000000005e-02
    x_4_9     product_lb_203  -2.5591030952935655e-02
    x_4_9     product_ub_204  -4.3428807775868064e-02
    x_4_9     onehot_4_217  1
    x_4_9     stock_lb_292  9
    x_4_9     stock_ub_293  9
    x_4_9     parent_nonstrict_scope_294  2.0999999999999991e-02
    x_4_9     unique_nonzero_owner_442  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_9     product_lb_203  1
    w_4_9     product_ub_204  1
    w_4_9     normalized_mass_4_218  1
    w_4_9     normalized_ratio_4_219  -1.2857142857142856e+00
    w_4_9     full_original_Gini_352  -1.1688095238095229e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_10    OBJ       -1.0500000000000009e-02
    x_4_10    product_lb_205  -2.5591030952935655e-02
    x_4_10    product_ub_206  -4.3428807775868064e-02
    x_4_10    onehot_4_217  1
    x_4_10    stock_lb_292  10
    x_4_10    stock_ub_293  10
    x_4_10    parent_nonstrict_scope_294  3.1499999999999986e-02
    x_4_10    unique_nonzero_owner_443  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_10    product_lb_205  1
    w_4_10    product_ub_206  1
    w_4_10    normalized_mass_4_218  1
    w_4_10    normalized_ratio_4_219  -1.4285714285714284e+00
    w_4_10    full_original_Gini_352  -1.5545238095238092e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_11    product_lb_207  -2.5591030952935655e-02
    x_4_11    product_ub_208  -4.3428807775868064e-02
    x_4_11    onehot_4_217  1
    x_4_11    stock_lb_292  11
    x_4_11    stock_ub_293  11
    x_4_11    parent_nonstrict_scope_294  4.1999999999999996e-02
    MARKER    'MARKER'                 'INTEND'
    w_4_11    product_lb_207  1
    w_4_11    product_ub_208  1
    w_4_11    normalized_mass_4_218  1
    w_4_11    normalized_ratio_4_219  -1.5714285714285714e+00
    w_4_11    full_original_Gini_352  -1.9402380952380952e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_12    OBJ       1.0499999999999995e-02
    x_4_12    product_lb_209  -2.5591030952935655e-02
    x_4_12    product_ub_210  -4.3428807775868064e-02
    x_4_12    onehot_4_217  1
    x_4_12    stock_lb_292  12
    x_4_12    stock_ub_293  12
    x_4_12    parent_nonstrict_scope_294  5.2499999999999991e-02
    x_4_12    unique_nonzero_owner_444  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_12    product_lb_209  1
    w_4_12    product_ub_210  1
    w_4_12    normalized_mass_4_218  1
    w_4_12    normalized_ratio_4_219  -1.7142857142857142e+00
    w_4_12    full_original_Gini_352  -2.3259523809523809e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_13    OBJ       2.0999999999999991e-02
    x_4_13    product_lb_211  -2.5591030952935655e-02
    x_4_13    product_ub_212  -4.3428807775868064e-02
    x_4_13    onehot_4_217  1
    x_4_13    stock_lb_292  13
    x_4_13    stock_ub_293  13
    x_4_13    parent_nonstrict_scope_294  6.2999999999999987e-02
    x_4_13    unique_nonzero_owner_445  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_13    product_lb_211  1
    w_4_13    product_ub_212  1
    w_4_13    normalized_mass_4_218  1
    w_4_13    normalized_ratio_4_219  -1.8571428571428570e+00
    w_4_13    full_original_Gini_352  -2.7116666666666667e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_14    OBJ       0.0315
    x_4_14    product_lb_213  -2.5591030952935655e-02
    x_4_14    product_ub_214  -4.3428807775868064e-02
    x_4_14    onehot_4_217  1
    x_4_14    stock_lb_292  14
    x_4_14    stock_ub_293  14
    x_4_14    parent_nonstrict_scope_294  0.0735
    x_4_14    unique_nonzero_owner_446  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_14    product_lb_213  1
    w_4_14    product_ub_214  1
    w_4_14    normalized_mass_4_218  1
    w_4_14    normalized_ratio_4_219  -2
    w_4_14    full_original_Gini_352  -3.0973809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_15    OBJ       4.1999999999999996e-02
    x_4_15    product_lb_215  -2.5591030952935655e-02
    x_4_15    product_ub_216  -4.3428807775868064e-02
    x_4_15    onehot_4_217  1
    x_4_15    stock_lb_292  15
    x_4_15    stock_ub_293  15
    x_4_15    parent_nonstrict_scope_294  8.3999999999999991e-02
    x_4_15    unique_nonzero_owner_447  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_15    product_lb_215  1
    w_4_15    product_ub_216  1
    w_4_15    normalized_mass_4_218  1
    w_4_15    normalized_ratio_4_219  -2.1428571428571428e+00
    w_4_15    full_original_Gini_352  -3.4830952380952382e+01
    rho_4     normalized_ratio_4_219  1
    rho_4     block_pair_pos_297  1
    rho_4     block_pair_neg_298  -1
    rho_4     block_pair_pos_307  1
    rho_4     block_pair_neg_308  -1
    rho_4     block_pair_pos_317  1
    rho_4     block_pair_neg_318  -1
    rho_4     block_pair_pos_327  -1
    rho_4     block_pair_neg_328  1
    rho_4     block_pair_pos_329  -1
    rho_4     block_pair_neg_330  1
    rho_4     block_pair_pos_333  1
    rho_4     block_pair_neg_334  -1
    rho_4     block_pair_pos_343  1
    rho_4     block_pair_neg_344  -1
    rho_4     normalization_351  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       0.027
    x_16_0    product_lb_220  -2.5591030952935655e-02
    x_16_0    product_ub_221  -4.3428807775868064e-02
    x_16_0    onehot_16_246  1
    x_16_0    parent_nonstrict_scope_294  0.054
    x_16_0    unique_nonzero_owner_448  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_220  1
    w_16_0    product_ub_221  1
    w_16_0    normalized_mass_16_247  1
    w_16_0    full_original_Gini_352  -2.3026190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       0.018
    x_16_1    product_lb_222  -2.5591030952935655e-02
    x_16_1    product_ub_223  -4.3428807775868064e-02
    x_16_1    onehot_16_246  1
    x_16_1    stock_lb_292  1
    x_16_1    stock_ub_293  1
    x_16_1    parent_nonstrict_scope_294  0.045
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_222  1
    w_16_1    product_ub_223  1
    w_16_1    normalized_mass_16_247  1
    w_16_1    normalized_ratio_16_248  -1.6666666666666666e-01
    w_16_1    full_original_Gini_352  -1.8526190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       9.0000000000000045e-03
    x_16_2    product_lb_224  -2.5591030952935655e-02
    x_16_2    product_ub_225  -4.3428807775868064e-02
    x_16_2    onehot_16_246  1
    x_16_2    stock_lb_292  2
    x_16_2    stock_ub_293  2
    x_16_2    parent_nonstrict_scope_294  3.6000000000000004e-02
    x_16_2    unique_nonzero_owner_449  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_224  1
    w_16_2    product_ub_225  1
    w_16_2    normalized_mass_16_247  1
    w_16_2    normalized_ratio_16_248  -3.3333333333333331e-01
    w_16_2    full_original_Gini_352  -1.4192857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    product_lb_226  -2.5591030952935655e-02
    x_16_3    product_ub_227  -4.3428807775868064e-02
    x_16_3    onehot_16_246  1
    x_16_3    stock_lb_292  3
    x_16_3    stock_ub_293  3
    x_16_3    parent_nonstrict_scope_294  0.027
    x_16_3    unique_nonzero_owner_450  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_226  1
    w_16_3    product_ub_227  1
    w_16_3    normalized_mass_16_247  1
    w_16_3    normalized_ratio_16_248  -0.5
    w_16_3    full_original_Gini_352  -1.0226190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    OBJ       -8.9999999999999976e-03
    x_16_4    product_lb_228  -2.5591030952935655e-02
    x_16_4    product_ub_229  -4.3428807775868064e-02
    x_16_4    onehot_16_246  1
    x_16_4    stock_lb_292  4
    x_16_4    stock_ub_293  4
    x_16_4    parent_nonstrict_scope_294  1.8000000000000002e-02
    x_16_4    unique_nonzero_owner_451  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_228  1
    w_16_4    product_ub_229  1
    w_16_4    normalized_mass_16_247  1
    w_16_4    normalized_ratio_16_248  -6.6666666666666663e-01
    w_16_4    full_original_Gini_352  -6.9928571428571420e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -1.7999999999999995e-02
    x_16_5    product_lb_230  -2.5591030952935655e-02
    x_16_5    product_ub_231  -4.3428807775868064e-02
    x_16_5    onehot_16_246  1
    x_16_5    stock_lb_292  5
    x_16_5    stock_ub_293  5
    x_16_5    parent_nonstrict_scope_294  9.0000000000000045e-03
    x_16_5    unique_nonzero_owner_452  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_230  1
    w_16_5    product_ub_231  1
    w_16_5    normalized_mass_16_247  1
    w_16_5    normalized_ratio_16_248  -8.3333333333333326e-01
    w_16_5    full_original_Gini_352  -5.4404761904761934e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -0.027
    x_16_6    product_lb_232  -2.5591030952935655e-02
    x_16_6    product_ub_233  -4.3428807775868064e-02
    x_16_6    onehot_16_246  1
    x_16_6    stock_lb_292  6
    x_16_6    stock_ub_293  6
    x_16_6    unique_nonzero_owner_453  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_232  1
    w_16_6    product_ub_233  1
    w_16_6    normalized_mass_16_247  1
    w_16_6    normalized_ratio_16_248  -1
    w_16_6    full_original_Gini_352  -5.2738095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -1.8000000000000009e-02
    x_16_7    product_lb_234  -2.5591030952935655e-02
    x_16_7    product_ub_235  -4.3428807775868064e-02
    x_16_7    onehot_16_246  1
    x_16_7    stock_lb_292  7
    x_16_7    stock_ub_293  7
    x_16_7    parent_nonstrict_scope_294  8.9999999999999924e-03
    x_16_7    unique_nonzero_owner_454  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_234  1
    w_16_7    product_ub_235  1
    w_16_7    normalized_mass_16_247  1
    w_16_7    normalized_ratio_16_248  -1.1666666666666665e+00
    w_16_7    full_original_Gini_352  -8.7738095238095184e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -9.0000000000000045e-03
    x_16_8    product_lb_236  -2.5591030952935655e-02
    x_16_8    product_ub_237  -4.3428807775868064e-02
    x_16_8    onehot_16_246  1
    x_16_8    stock_lb_292  8
    x_16_8    stock_ub_293  8
    x_16_8    parent_nonstrict_scope_294  1.7999999999999995e-02
    x_16_8    unique_nonzero_owner_455  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_236  1
    w_16_8    product_ub_237  1
    w_16_8    normalized_mass_16_247  1
    w_16_8    normalized_ratio_16_248  -1.3333333333333333e+00
    w_16_8    full_original_Gini_352  -1.2973809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_9    product_lb_238  -2.5591030952935655e-02
    x_16_9    product_ub_239  -4.3428807775868064e-02
    x_16_9    onehot_16_246  1
    x_16_9    stock_lb_292  9
    x_16_9    stock_ub_293  9
    x_16_9    parent_nonstrict_scope_294  0.027
    x_16_9    unique_nonzero_owner_456  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_238  1
    w_16_9    product_ub_239  1
    w_16_9    normalized_mass_16_247  1
    w_16_9    normalized_ratio_16_248  -1.5
    w_16_9    full_original_Gini_352  -1.7473809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       0.00899999999999999
    x_16_10   product_lb_240  -2.5591030952935655e-02
    x_16_10   product_ub_241  -4.3428807775868064e-02
    x_16_10   onehot_16_246  1
    x_16_10   stock_lb_292  10
    x_16_10   stock_ub_293  10
    x_16_10   parent_nonstrict_scope_294  3.5999999999999990e-02
    x_16_10   unique_nonzero_owner_457  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_240  1
    w_16_10   product_ub_241  1
    w_16_10   normalized_mass_16_247  1
    w_16_10   normalized_ratio_16_248  -1.6666666666666665e+00
    w_16_10   full_original_Gini_352  -2.1973809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       0.018
    x_16_11   product_lb_242  -2.5591030952935655e-02
    x_16_11   product_ub_243  -4.3428807775868064e-02
    x_16_11   onehot_16_246  1
    x_16_11   stock_lb_292  11
    x_16_11   stock_ub_293  11
    x_16_11   parent_nonstrict_scope_294  0.045
    x_16_11   unique_nonzero_owner_458  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_242  1
    w_16_11   product_ub_243  1
    w_16_11   normalized_mass_16_247  1
    w_16_11   normalized_ratio_16_248  -1.8333333333333333e+00
    w_16_11   full_original_Gini_352  -2.6473809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   OBJ       0.027
    x_16_12   product_lb_244  -2.5591030952935655e-02
    x_16_12   product_ub_245  -4.3428807775868064e-02
    x_16_12   onehot_16_246  1
    x_16_12   stock_lb_292  12
    x_16_12   stock_ub_293  12
    x_16_12   parent_nonstrict_scope_294  0.054
    x_16_12   unique_nonzero_owner_459  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_244  1
    w_16_12   product_ub_245  1
    w_16_12   normalized_mass_16_247  1
    w_16_12   normalized_ratio_16_248  -2
    w_16_12   full_original_Gini_352  -3.0973809523809521e+01
    rho_16    normalized_ratio_16_248  1
    rho_16    block_pair_pos_303  1
    rho_16    block_pair_neg_304  -1
    rho_16    block_pair_pos_311  1
    rho_16    block_pair_neg_312  -1
    rho_16    block_pair_pos_323  1
    rho_16    block_pair_neg_324  -1
    rho_16    block_pair_pos_329  1
    rho_16    block_pair_neg_330  -1
    rho_16    block_pair_pos_337  1
    rho_16    block_pair_neg_338  -1
    rho_16    block_pair_pos_339  -1
    rho_16    block_pair_neg_340  1
    rho_16    block_pair_pos_349  1
    rho_16    block_pair_neg_350  -1
    rho_16    normalization_351  1
    MARKER    'MARKER'                 'INTORG'
    x_10_0    OBJ       0.075
    x_10_0    product_lb_249  -2.5591030952935655e-02
    x_10_0    product_ub_250  -4.3428807775868064e-02
    x_10_0    onehot_10_289  1
    x_10_0    parent_nonstrict_scope_294  0.15
    x_10_0    unique_nonzero_owner_460  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_0    product_lb_249  1
    w_10_0    product_ub_250  1
    w_10_0    normalized_mass_10_290  1
    w_10_0    full_original_Gini_352  -2.3026190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_1    OBJ       6.0000000000000012e-02
    x_10_1    product_lb_251  -2.5591030952935655e-02
    x_10_1    product_ub_252  -4.3428807775868064e-02
    x_10_1    onehot_10_289  1
    x_10_1    stock_lb_292  1
    x_10_1    stock_ub_293  1
    x_10_1    parent_nonstrict_scope_294  0.135
    x_10_1    unique_nonzero_owner_461  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_1    product_lb_251  1
    w_10_1    product_ub_252  1
    w_10_1    normalized_mass_10_290  1
    w_10_1    normalized_ratio_10_291  -0.1
    w_10_1    full_original_Gini_352  -2.0326190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_2    OBJ       0.045
    x_10_2    product_lb_253  -2.5591030952935655e-02
    x_10_2    product_ub_254  -4.3428807775868064e-02
    x_10_2    onehot_10_289  1
    x_10_2    stock_lb_292  2
    x_10_2    stock_ub_293  2
    x_10_2    parent_nonstrict_scope_294  0.12
    x_10_2    unique_nonzero_owner_462  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_2    product_lb_253  1
    w_10_2    product_ub_254  1
    w_10_2    normalized_mass_10_290  1
    w_10_2    normalized_ratio_10_291  -0.2
    w_10_2    full_original_Gini_352  -1.7626190476190477e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_3    OBJ       0.03
    x_10_3    product_lb_255  -2.5591030952935655e-02
    x_10_3    product_ub_256  -4.3428807775868064e-02
    x_10_3    onehot_10_289  1
    x_10_3    stock_lb_292  3
    x_10_3    stock_ub_293  3
    x_10_3    parent_nonstrict_scope_294  0.105
    x_10_3    unique_nonzero_owner_463  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_3    product_lb_255  1
    w_10_3    product_ub_256  1
    w_10_3    normalized_mass_10_290  1
    w_10_3    normalized_ratio_10_291  -3.0000000000000004e-01
    w_10_3    full_original_Gini_352  -1.5026190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_4    OBJ       0.015
    x_10_4    product_lb_257  -2.5591030952935655e-02
    x_10_4    product_ub_258  -4.3428807775868064e-02
    x_10_4    onehot_10_289  1
    x_10_4    stock_lb_292  4
    x_10_4    stock_ub_293  4
    x_10_4    parent_nonstrict_scope_294  0.09
    x_10_4    unique_nonzero_owner_464  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_4    product_lb_257  1
    w_10_4    product_ub_258  1
    w_10_4    normalized_mass_10_290  1
    w_10_4    normalized_ratio_10_291  -0.4
    w_10_4    full_original_Gini_352  -1.2526190476190473e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_5    product_lb_259  -2.5591030952935655e-02
    x_10_5    product_ub_260  -4.3428807775868064e-02
    x_10_5    onehot_10_289  1
    x_10_5    stock_lb_292  5
    x_10_5    stock_ub_293  5
    x_10_5    parent_nonstrict_scope_294  0.075
    x_10_5    unique_nonzero_owner_465  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_5    product_lb_259  1
    w_10_5    product_ub_260  1
    w_10_5    normalized_mass_10_290  1
    w_10_5    normalized_ratio_10_291  -0.5
    w_10_5    full_original_Gini_352  -1.0226190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_6    OBJ       -1.5000000000000013e-02
    x_10_6    product_lb_261  -2.5591030952935655e-02
    x_10_6    product_ub_262  -4.3428807775868064e-02
    x_10_6    onehot_10_289  1
    x_10_6    stock_lb_292  6
    x_10_6    stock_ub_293  6
    x_10_6    parent_nonstrict_scope_294  5.9999999999999984e-02
    x_10_6    unique_nonzero_owner_466  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_6    product_lb_261  1
    w_10_6    product_ub_262  1
    w_10_6    normalized_mass_10_290  1
    w_10_6    normalized_ratio_10_291  -6.0000000000000009e-01
    w_10_6    full_original_Gini_352  -8.1261904761904749e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_7    OBJ       -3.0000000000000006e-02
    x_10_7    product_lb_263  -2.5591030952935655e-02
    x_10_7    product_ub_264  -4.3428807775868064e-02
    x_10_7    onehot_10_289  1
    x_10_7    stock_lb_292  7
    x_10_7    stock_ub_293  7
    x_10_7    parent_nonstrict_scope_294  4.4999999999999991e-02
    x_10_7    unique_nonzero_owner_467  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_7    product_lb_263  1
    w_10_7    product_ub_264  1
    w_10_7    normalized_mass_10_290  1
    w_10_7    normalized_ratio_10_291  -7.0000000000000007e-01
    w_10_7    full_original_Gini_352  -6.4261904761904729e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_8    OBJ       -4.5000000000000005e-02
    x_10_8    product_lb_265  -2.5591030952935655e-02
    x_10_8    product_ub_266  -4.3428807775868064e-02
    x_10_8    onehot_10_289  1
    x_10_8    stock_lb_292  8
    x_10_8    stock_ub_293  8
    x_10_8    parent_nonstrict_scope_294  2.9999999999999992e-02
    x_10_8    unique_nonzero_owner_468  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_8    product_lb_265  1
    w_10_8    product_ub_266  1
    w_10_8    normalized_mass_10_290  1
    w_10_8    normalized_ratio_10_291  -0.8
    w_10_8    full_original_Gini_352  -5.5404761904761930e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_9    OBJ       -0.06
    x_10_9    product_lb_267  -2.5591030952935655e-02
    x_10_9    product_ub_268  -4.3428807775868064e-02
    x_10_9    onehot_10_289  1
    x_10_9    stock_lb_292  9
    x_10_9    stock_ub_293  9
    x_10_9    parent_nonstrict_scope_294  1.4999999999999996e-02
    x_10_9    unique_nonzero_owner_469  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_9    product_lb_267  1
    w_10_9    product_ub_268  1
    w_10_9    normalized_mass_10_290  1
    w_10_9    normalized_ratio_10_291  -0.9
    w_10_9    full_original_Gini_352  -5.3738095238095243e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_10   OBJ       -0.075
    x_10_10   product_lb_269  -2.5591030952935655e-02
    x_10_10   product_ub_270  -4.3428807775868064e-02
    x_10_10   onehot_10_289  1
    x_10_10   stock_lb_292  10
    x_10_10   stock_ub_293  10
    x_10_10   unique_nonzero_owner_470  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_10   product_lb_269  1
    w_10_10   product_ub_270  1
    w_10_10   normalized_mass_10_290  1
    w_10_10   normalized_ratio_10_291  -1
    w_10_10   full_original_Gini_352  -5.2738095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_11   OBJ       -5.9999999999999984e-02
    x_10_11   product_lb_271  -2.5591030952935655e-02
    x_10_11   product_ub_272  -4.3428807775868064e-02
    x_10_11   onehot_10_289  1
    x_10_11   stock_lb_292  11
    x_10_11   stock_ub_293  11
    x_10_11   parent_nonstrict_scope_294  1.5000000000000013e-02
    x_10_11   unique_nonzero_owner_471  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_11   product_lb_271  1
    w_10_11   product_ub_272  1
    w_10_11   normalized_mass_10_290  1
    w_10_11   normalized_ratio_10_291  -1.1
    w_10_11   full_original_Gini_352  -7.3738095238095269e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_12   OBJ       -4.4999999999999971e-02
    x_10_12   product_lb_273  -2.5591030952935655e-02
    x_10_12   product_ub_274  -4.3428807775868064e-02
    x_10_12   onehot_10_289  1
    x_10_12   stock_lb_292  12
    x_10_12   stock_ub_293  12
    x_10_12   parent_nonstrict_scope_294  3.0000000000000027e-02
    x_10_12   unique_nonzero_owner_472  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_12   product_lb_273  1
    w_10_12   product_ub_274  1
    w_10_12   normalized_mass_10_290  1
    w_10_12   normalized_ratio_10_291  -1.2000000000000002e+00
    w_10_12   full_original_Gini_352  -9.4738095238095283e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_13   OBJ       -2.9999999999999992e-02
    x_10_13   product_lb_275  -2.5591030952935655e-02
    x_10_13   product_ub_276  -4.3428807775868064e-02
    x_10_13   onehot_10_289  1
    x_10_13   stock_lb_292  13
    x_10_13   stock_ub_293  13
    x_10_13   parent_nonstrict_scope_294  4.5000000000000005e-02
    x_10_13   unique_nonzero_owner_473  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_13   product_lb_275  1
    w_10_13   product_ub_276  1
    w_10_13   normalized_mass_10_290  1
    w_10_13   normalized_ratio_10_291  -1.3
    w_10_13   full_original_Gini_352  -1.2073809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_14   OBJ       -1.4999999999999979e-02
    x_10_14   product_lb_277  -2.5591030952935655e-02
    x_10_14   product_ub_278  -4.3428807775868064e-02
    x_10_14   onehot_10_289  1
    x_10_14   stock_lb_292  14
    x_10_14   stock_ub_293  14
    x_10_14   parent_nonstrict_scope_294  6.0000000000000019e-02
    x_10_14   unique_nonzero_owner_474  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_14   product_lb_277  1
    w_10_14   product_ub_278  1
    w_10_14   normalized_mass_10_290  1
    w_10_14   normalized_ratio_10_291  -1.4000000000000001e+00
    w_10_14   full_original_Gini_352  -1.4773809523809531e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_15   product_lb_279  -2.5591030952935655e-02
    x_10_15   product_ub_280  -4.3428807775868064e-02
    x_10_15   onehot_10_289  1
    x_10_15   stock_lb_292  15
    x_10_15   stock_ub_293  15
    x_10_15   parent_nonstrict_scope_294  0.075
    MARKER    'MARKER'                 'INTEND'
    w_10_15   product_lb_279  1
    w_10_15   product_ub_280  1
    w_10_15   normalized_mass_10_290  1
    w_10_15   normalized_ratio_10_291  -1.5
    w_10_15   full_original_Gini_352  -1.7473809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_16   OBJ       1.5000000000000013e-02
    x_10_16   product_lb_281  -2.5591030952935655e-02
    x_10_16   product_ub_282  -4.3428807775868064e-02
    x_10_16   onehot_10_289  1
    x_10_16   stock_lb_292  16
    x_10_16   stock_ub_293  16
    x_10_16   parent_nonstrict_scope_294  9.0000000000000011e-02
    x_10_16   unique_nonzero_owner_475  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_16   product_lb_281  1
    w_10_16   product_ub_282  1
    w_10_16   normalized_mass_10_290  1
    w_10_16   normalized_ratio_10_291  -1.6
    w_10_16   full_original_Gini_352  -2.0173809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_17   OBJ       3.0000000000000027e-02
    x_10_17   product_lb_283  -2.5591030952935655e-02
    x_10_17   product_ub_284  -4.3428807775868064e-02
    x_10_17   onehot_10_289  1
    x_10_17   stock_lb_292  17
    x_10_17   stock_ub_293  17
    x_10_17   parent_nonstrict_scope_294  1.0500000000000002e-01
    x_10_17   unique_nonzero_owner_476  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_17   product_lb_283  1
    w_10_17   product_ub_284  1
    w_10_17   normalized_mass_10_290  1
    w_10_17   normalized_ratio_10_291  -1.7000000000000002e+00
    w_10_17   full_original_Gini_352  -2.2873809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_18   OBJ       0.045
    x_10_18   product_lb_285  -2.5591030952935655e-02
    x_10_18   product_ub_286  -4.3428807775868064e-02
    x_10_18   onehot_10_289  1
    x_10_18   stock_lb_292  18
    x_10_18   stock_ub_293  18
    x_10_18   parent_nonstrict_scope_294  0.12
    x_10_18   unique_nonzero_owner_477  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_18   product_lb_285  1
    w_10_18   product_ub_286  1
    w_10_18   normalized_mass_10_290  1
    w_10_18   normalized_ratio_10_291  -1.8
    w_10_18   full_original_Gini_352  -2.5573809523809530e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_19   OBJ       6.0000000000000012e-02
    x_10_19   product_lb_287  -2.5591030952935655e-02
    x_10_19   product_ub_288  -4.3428807775868064e-02
    x_10_19   onehot_10_289  1
    x_10_19   stock_lb_292  19
    x_10_19   stock_ub_293  19
    x_10_19   parent_nonstrict_scope_294  0.135
    x_10_19   unique_nonzero_owner_478  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_19   product_lb_287  1
    w_10_19   product_ub_288  1
    w_10_19   normalized_mass_10_290  1
    w_10_19   normalized_ratio_10_291  -1.9000000000000001e+00
    w_10_19   full_original_Gini_352  -2.8273809523809518e+01
    rho_10    normalized_ratio_10_291  1
    rho_10    block_pair_pos_301  1
    rho_10    block_pair_neg_302  -1
    rho_10    block_pair_pos_309  1
    rho_10    block_pair_neg_310  -1
    rho_10    block_pair_pos_321  1
    rho_10    block_pair_neg_322  -1
    rho_10    block_pair_pos_327  1
    rho_10    block_pair_neg_328  -1
    rho_10    block_pair_pos_335  1
    rho_10    block_pair_neg_336  -1
    rho_10    block_pair_pos_339  1
    rho_10    block_pair_neg_340  -1
    rho_10    block_pair_pos_347  1
    rho_10    block_pair_neg_348  -1
    rho_10    normalization_351  1
    a_3_1     block_pair_pos_313  1
    a_3_1     block_pair_neg_314  1
    a_3_1     full_original_Gini_352  -1
    a_3_31    block_pair_pos_325  1
    a_3_31    block_pair_neg_326  1
    a_3_31    full_original_Gini_352  -1
    a_3_7     block_pair_pos_319  1
    a_3_7     block_pair_neg_320  1
    a_3_7     full_original_Gini_352  -1
    a_3_2     block_pair_pos_315  1
    a_3_2     block_pair_neg_316  1
    a_3_2     full_original_Gini_352  -1
    a_3_4     block_pair_pos_317  1
    a_3_4     block_pair_neg_318  1
    a_3_4     full_original_Gini_352  -1
    a_3_16    block_pair_pos_323  1
    a_3_16    block_pair_neg_324  1
    a_3_16    full_original_Gini_352  -1
    a_3_10    block_pair_pos_321  1
    a_3_10    block_pair_neg_322  1
    a_3_10    full_original_Gini_352  -1
    a_1_31    block_pair_pos_305  1
    a_1_31    block_pair_neg_306  1
    a_1_31    full_original_Gini_352  -1
    a_1_7     block_pair_pos_299  1
    a_1_7     block_pair_neg_300  1
    a_1_7     full_original_Gini_352  -1
    a_1_2     block_pair_pos_295  1
    a_1_2     block_pair_neg_296  1
    a_1_2     full_original_Gini_352  -1
    a_1_4     block_pair_pos_297  1
    a_1_4     block_pair_neg_298  1
    a_1_4     full_original_Gini_352  -1
    a_1_16    block_pair_pos_303  1
    a_1_16    block_pair_neg_304  1
    a_1_16    full_original_Gini_352  -1
    a_1_10    block_pair_pos_301  1
    a_1_10    block_pair_neg_302  1
    a_1_10    full_original_Gini_352  -1
    a_31_7    block_pair_pos_345  1
    a_31_7    block_pair_neg_346  1
    a_31_7    full_original_Gini_352  -1
    a_31_2    block_pair_pos_341  1
    a_31_2    block_pair_neg_342  1
    a_31_2    full_original_Gini_352  -1
    a_31_4    block_pair_pos_343  1
    a_31_4    block_pair_neg_344  1
    a_31_4    full_original_Gini_352  -1
    a_31_16   block_pair_pos_349  1
    a_31_16   block_pair_neg_350  1
    a_31_16   full_original_Gini_352  -1
    a_31_10   block_pair_pos_347  1
    a_31_10   block_pair_neg_348  1
    a_31_10   full_original_Gini_352  -1
    a_7_2     block_pair_pos_331  1
    a_7_2     block_pair_neg_332  1
    a_7_2     full_original_Gini_352  -1
    a_7_4     block_pair_pos_333  1
    a_7_4     block_pair_neg_334  1
    a_7_4     full_original_Gini_352  -1
    a_7_16    block_pair_pos_337  1
    a_7_16    block_pair_neg_338  1
    a_7_16    full_original_Gini_352  -1
    a_7_10    block_pair_pos_335  1
    a_7_10    block_pair_neg_336  1
    a_7_10    full_original_Gini_352  -1
    a_2_4     block_pair_pos_307  1
    a_2_4     block_pair_neg_308  1
    a_2_4     full_original_Gini_352  -1
    a_2_16    block_pair_pos_311  1
    a_2_16    block_pair_neg_312  1
    a_2_16    full_original_Gini_352  -1
    a_2_10    block_pair_pos_309  1
    a_2_10    block_pair_neg_310  1
    a_2_10    full_original_Gini_352  -1
    a_4_16    block_pair_pos_329  1
    a_4_16    block_pair_neg_330  1
    a_4_16    full_original_Gini_352  -1
    a_4_10    block_pair_pos_327  1
    a_4_10    block_pair_neg_328  1
    a_4_10    full_original_Gini_352  -1
    a_16_10   block_pair_pos_339  1
    a_16_10   block_pair_neg_340  1
    a_16_10   full_original_Gini_352  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_3_0  unique_nonzero_owner_353  1
    service_0_3_0  service_visit_def_802  1
    service_0_3_0  free_load_conservation_803  -12
    service_0_3_0  original_T_including_depot_unload_849  1440
    service_0_3_1  unique_nonzero_owner_354  1
    service_0_3_1  service_visit_def_802  1
    service_0_3_1  free_load_conservation_803  -11
    service_0_3_1  original_T_including_depot_unload_849  1320
    service_0_3_2  unique_nonzero_owner_355  1
    service_0_3_2  service_visit_def_802  1
    service_0_3_2  free_load_conservation_803  -10
    service_0_3_2  original_T_including_depot_unload_849  1200
    service_0_3_3  unique_nonzero_owner_356  1
    service_0_3_3  service_visit_def_802  1
    service_0_3_3  free_load_conservation_803  -9
    service_0_3_3  original_T_including_depot_unload_849  1080
    service_0_3_4  unique_nonzero_owner_357  1
    service_0_3_4  service_visit_def_802  1
    service_0_3_4  free_load_conservation_803  -8
    service_0_3_4  original_T_including_depot_unload_849  960
    service_0_3_5  unique_nonzero_owner_358  1
    service_0_3_5  service_visit_def_802  1
    service_0_3_5  free_load_conservation_803  -7
    service_0_3_5  original_T_including_depot_unload_849  840
    service_0_3_6  unique_nonzero_owner_359  1
    service_0_3_6  service_visit_def_802  1
    service_0_3_6  free_load_conservation_803  -6
    service_0_3_6  original_T_including_depot_unload_849  720
    service_0_3_7  unique_nonzero_owner_360  1
    service_0_3_7  service_visit_def_802  1
    service_0_3_7  free_load_conservation_803  -5
    service_0_3_7  original_T_including_depot_unload_849  600
    service_0_3_8  unique_nonzero_owner_361  1
    service_0_3_8  service_visit_def_802  1
    service_0_3_8  free_load_conservation_803  -4
    service_0_3_8  original_T_including_depot_unload_849  480
    service_0_3_9  unique_nonzero_owner_362  1
    service_0_3_9  service_visit_def_802  1
    service_0_3_9  free_load_conservation_803  -3
    service_0_3_9  original_T_including_depot_unload_849  360
    service_0_3_10  unique_nonzero_owner_363  1
    service_0_3_10  service_visit_def_802  1
    service_0_3_10  free_load_conservation_803  -2
    service_0_3_10  original_T_including_depot_unload_849  240
    service_0_3_11  unique_nonzero_owner_364  1
    service_0_3_11  service_visit_def_802  1
    service_0_3_11  free_load_conservation_803  -1
    service_0_3_11  original_T_including_depot_unload_849  120
    service_0_3_13  unique_nonzero_owner_365  1
    service_0_3_13  service_visit_def_802  1
    service_0_3_13  free_load_conservation_803  1
    service_0_3_14  unique_nonzero_owner_366  1
    service_0_3_14  service_visit_def_802  1
    service_0_3_14  free_load_conservation_803  2
    service_0_3_15  unique_nonzero_owner_367  1
    service_0_3_15  service_visit_def_802  1
    service_0_3_15  free_load_conservation_803  3
    service_0_3_16  unique_nonzero_owner_368  1
    service_0_3_16  service_visit_def_802  1
    service_0_3_16  free_load_conservation_803  4
    service_0_3_17  unique_nonzero_owner_369  1
    service_0_3_17  service_visit_def_802  1
    service_0_3_17  free_load_conservation_803  5
    service_1_3_0  unique_nonzero_owner_353  1
    service_1_3_0  service_visit_def_1230  1
    service_1_3_0  free_load_conservation_1231  -12
    service_1_3_0  original_T_including_depot_unload_1278  1440
    service_1_3_1  unique_nonzero_owner_354  1
    service_1_3_1  service_visit_def_1230  1
    service_1_3_1  free_load_conservation_1231  -11
    service_1_3_1  original_T_including_depot_unload_1278  1320
    service_1_3_2  unique_nonzero_owner_355  1
    service_1_3_2  service_visit_def_1230  1
    service_1_3_2  free_load_conservation_1231  -10
    service_1_3_2  original_T_including_depot_unload_1278  1200
    service_1_3_3  unique_nonzero_owner_356  1
    service_1_3_3  service_visit_def_1230  1
    service_1_3_3  free_load_conservation_1231  -9
    service_1_3_3  original_T_including_depot_unload_1278  1080
    service_1_3_4  unique_nonzero_owner_357  1
    service_1_3_4  service_visit_def_1230  1
    service_1_3_4  free_load_conservation_1231  -8
    service_1_3_4  original_T_including_depot_unload_1278  960
    service_1_3_5  unique_nonzero_owner_358  1
    service_1_3_5  service_visit_def_1230  1
    service_1_3_5  free_load_conservation_1231  -7
    service_1_3_5  original_T_including_depot_unload_1278  840
    service_1_3_6  unique_nonzero_owner_359  1
    service_1_3_6  service_visit_def_1230  1
    service_1_3_6  free_load_conservation_1231  -6
    service_1_3_6  original_T_including_depot_unload_1278  720
    service_1_3_7  unique_nonzero_owner_360  1
    service_1_3_7  service_visit_def_1230  1
    service_1_3_7  free_load_conservation_1231  -5
    service_1_3_7  original_T_including_depot_unload_1278  600
    service_1_3_8  unique_nonzero_owner_361  1
    service_1_3_8  service_visit_def_1230  1
    service_1_3_8  free_load_conservation_1231  -4
    service_1_3_8  original_T_including_depot_unload_1278  480
    service_1_3_9  unique_nonzero_owner_362  1
    service_1_3_9  service_visit_def_1230  1
    service_1_3_9  free_load_conservation_1231  -3
    service_1_3_9  original_T_including_depot_unload_1278  360
    service_1_3_10  unique_nonzero_owner_363  1
    service_1_3_10  service_visit_def_1230  1
    service_1_3_10  free_load_conservation_1231  -2
    service_1_3_10  original_T_including_depot_unload_1278  240
    service_1_3_11  unique_nonzero_owner_364  1
    service_1_3_11  service_visit_def_1230  1
    service_1_3_11  free_load_conservation_1231  -1
    service_1_3_11  original_T_including_depot_unload_1278  120
    service_1_3_13  unique_nonzero_owner_365  1
    service_1_3_13  service_visit_def_1230  1
    service_1_3_13  free_load_conservation_1231  1
    service_1_3_14  unique_nonzero_owner_366  1
    service_1_3_14  service_visit_def_1230  1
    service_1_3_14  free_load_conservation_1231  2
    service_1_3_15  unique_nonzero_owner_367  1
    service_1_3_15  service_visit_def_1230  1
    service_1_3_15  free_load_conservation_1231  3
    service_1_3_16  unique_nonzero_owner_368  1
    service_1_3_16  service_visit_def_1230  1
    service_1_3_16  free_load_conservation_1231  4
    service_1_3_17  unique_nonzero_owner_369  1
    service_1_3_17  service_visit_def_1230  1
    service_1_3_17  free_load_conservation_1231  5
    service_2_3_0  unique_nonzero_owner_353  1
    service_2_3_0  service_visit_def_1549  1
    service_2_3_0  free_load_conservation_1550  -12
    service_2_3_0  original_T_including_depot_unload_1595  1440
    service_2_3_1  unique_nonzero_owner_354  1
    service_2_3_1  service_visit_def_1549  1
    service_2_3_1  free_load_conservation_1550  -11
    service_2_3_1  original_T_including_depot_unload_1595  1320
    service_2_3_2  unique_nonzero_owner_355  1
    service_2_3_2  service_visit_def_1549  1
    service_2_3_2  free_load_conservation_1550  -10
    service_2_3_2  original_T_including_depot_unload_1595  1200
    service_2_3_3  unique_nonzero_owner_356  1
    service_2_3_3  service_visit_def_1549  1
    service_2_3_3  free_load_conservation_1550  -9
    service_2_3_3  original_T_including_depot_unload_1595  1080
    service_2_3_4  unique_nonzero_owner_357  1
    service_2_3_4  service_visit_def_1549  1
    service_2_3_4  free_load_conservation_1550  -8
    service_2_3_4  original_T_including_depot_unload_1595  960
    service_2_3_5  unique_nonzero_owner_358  1
    service_2_3_5  service_visit_def_1549  1
    service_2_3_5  free_load_conservation_1550  -7
    service_2_3_5  original_T_including_depot_unload_1595  840
    service_2_3_6  unique_nonzero_owner_359  1
    service_2_3_6  service_visit_def_1549  1
    service_2_3_6  free_load_conservation_1550  -6
    service_2_3_6  original_T_including_depot_unload_1595  720
    service_2_3_7  unique_nonzero_owner_360  1
    service_2_3_7  service_visit_def_1549  1
    service_2_3_7  free_load_conservation_1550  -5
    service_2_3_7  original_T_including_depot_unload_1595  600
    service_2_3_8  unique_nonzero_owner_361  1
    service_2_3_8  service_visit_def_1549  1
    service_2_3_8  free_load_conservation_1550  -4
    service_2_3_8  original_T_including_depot_unload_1595  480
    service_2_3_9  unique_nonzero_owner_362  1
    service_2_3_9  service_visit_def_1549  1
    service_2_3_9  free_load_conservation_1550  -3
    service_2_3_9  original_T_including_depot_unload_1595  360
    service_2_3_10  unique_nonzero_owner_363  1
    service_2_3_10  service_visit_def_1549  1
    service_2_3_10  free_load_conservation_1550  -2
    service_2_3_10  original_T_including_depot_unload_1595  240
    service_2_3_11  unique_nonzero_owner_364  1
    service_2_3_11  service_visit_def_1549  1
    service_2_3_11  free_load_conservation_1550  -1
    service_2_3_11  original_T_including_depot_unload_1595  120
    service_2_3_13  unique_nonzero_owner_365  1
    service_2_3_13  service_visit_def_1549  1
    service_2_3_13  free_load_conservation_1550  1
    service_2_3_14  unique_nonzero_owner_366  1
    service_2_3_14  service_visit_def_1549  1
    service_2_3_14  free_load_conservation_1550  2
    service_2_3_15  unique_nonzero_owner_367  1
    service_2_3_15  service_visit_def_1549  1
    service_2_3_15  free_load_conservation_1550  3
    service_2_3_16  unique_nonzero_owner_368  1
    service_2_3_16  service_visit_def_1549  1
    service_2_3_16  free_load_conservation_1550  4
    service_2_3_17  unique_nonzero_owner_369  1
    service_2_3_17  service_visit_def_1549  1
    service_2_3_17  free_load_conservation_1550  5
    service_0_1_0  unique_nonzero_owner_370  1
    service_0_1_0  service_visit_def_808  1
    service_0_1_0  free_load_conservation_809  -2
    service_0_1_0  original_T_including_depot_unload_849  240
    service_0_1_1  unique_nonzero_owner_371  1
    service_0_1_1  service_visit_def_808  1
    service_0_1_1  free_load_conservation_809  -1
    service_0_1_1  original_T_including_depot_unload_849  120
    service_0_1_3  unique_nonzero_owner_372  1
    service_0_1_3  service_visit_def_808  1
    service_0_1_3  free_load_conservation_809  1
    service_0_1_4  unique_nonzero_owner_373  1
    service_0_1_4  service_visit_def_808  1
    service_0_1_4  free_load_conservation_809  2
    service_0_1_5  unique_nonzero_owner_374  1
    service_0_1_5  service_visit_def_808  1
    service_0_1_5  free_load_conservation_809  3
    service_0_1_6  unique_nonzero_owner_375  1
    service_0_1_6  service_visit_def_808  1
    service_0_1_6  free_load_conservation_809  4
    service_0_1_7  unique_nonzero_owner_376  1
    service_0_1_7  service_visit_def_808  1
    service_0_1_7  free_load_conservation_809  5
    service_0_1_8  unique_nonzero_owner_377  1
    service_0_1_8  service_visit_def_808  1
    service_0_1_8  free_load_conservation_809  6
    service_0_1_9  unique_nonzero_owner_378  1
    service_0_1_9  service_visit_def_808  1
    service_0_1_9  free_load_conservation_809  7
    service_0_1_10  unique_nonzero_owner_379  1
    service_0_1_10  service_visit_def_808  1
    service_0_1_10  free_load_conservation_809  8
    service_0_1_11  unique_nonzero_owner_380  1
    service_0_1_11  service_visit_def_808  1
    service_0_1_11  free_load_conservation_809  9
    service_0_1_12  unique_nonzero_owner_381  1
    service_0_1_12  service_visit_def_808  1
    service_0_1_12  free_load_conservation_809  10
    service_0_1_13  unique_nonzero_owner_382  1
    service_0_1_13  service_visit_def_808  1
    service_0_1_13  free_load_conservation_809  11
    service_0_1_14  unique_nonzero_owner_383  1
    service_0_1_14  service_visit_def_808  1
    service_0_1_14  free_load_conservation_809  12
    service_0_1_15  unique_nonzero_owner_384  1
    service_0_1_15  service_visit_def_808  1
    service_0_1_15  free_load_conservation_809  13
    service_0_1_16  unique_nonzero_owner_385  1
    service_0_1_16  service_visit_def_808  1
    service_0_1_16  free_load_conservation_809  14
    service_0_1_17  unique_nonzero_owner_386  1
    service_0_1_17  service_visit_def_808  1
    service_0_1_17  free_load_conservation_809  15
    service_0_1_18  unique_nonzero_owner_387  1
    service_0_1_18  service_visit_def_808  1
    service_0_1_18  free_load_conservation_809  16
    service_0_1_19  unique_nonzero_owner_388  1
    service_0_1_19  service_visit_def_808  1
    service_0_1_19  free_load_conservation_809  17
    service_1_1_0  unique_nonzero_owner_370  1
    service_1_1_0  service_visit_def_1236  1
    service_1_1_0  free_load_conservation_1237  -2
    service_1_1_0  original_T_including_depot_unload_1278  240
    service_1_1_1  unique_nonzero_owner_371  1
    service_1_1_1  service_visit_def_1236  1
    service_1_1_1  free_load_conservation_1237  -1
    service_1_1_1  original_T_including_depot_unload_1278  120
    service_1_1_3  unique_nonzero_owner_372  1
    service_1_1_3  service_visit_def_1236  1
    service_1_1_3  free_load_conservation_1237  1
    service_1_1_4  unique_nonzero_owner_373  1
    service_1_1_4  service_visit_def_1236  1
    service_1_1_4  free_load_conservation_1237  2
    service_1_1_5  unique_nonzero_owner_374  1
    service_1_1_5  service_visit_def_1236  1
    service_1_1_5  free_load_conservation_1237  3
    service_1_1_6  unique_nonzero_owner_375  1
    service_1_1_6  service_visit_def_1236  1
    service_1_1_6  free_load_conservation_1237  4
    service_1_1_7  unique_nonzero_owner_376  1
    service_1_1_7  service_visit_def_1236  1
    service_1_1_7  free_load_conservation_1237  5
    service_1_1_8  unique_nonzero_owner_377  1
    service_1_1_8  service_visit_def_1236  1
    service_1_1_8  free_load_conservation_1237  6
    service_1_1_9  unique_nonzero_owner_378  1
    service_1_1_9  service_visit_def_1236  1
    service_1_1_9  free_load_conservation_1237  7
    service_1_1_10  unique_nonzero_owner_379  1
    service_1_1_10  service_visit_def_1236  1
    service_1_1_10  free_load_conservation_1237  8
    service_1_1_11  unique_nonzero_owner_380  1
    service_1_1_11  service_visit_def_1236  1
    service_1_1_11  free_load_conservation_1237  9
    service_1_1_12  unique_nonzero_owner_381  1
    service_1_1_12  service_visit_def_1236  1
    service_1_1_12  free_load_conservation_1237  10
    service_1_1_13  unique_nonzero_owner_382  1
    service_1_1_13  service_visit_def_1236  1
    service_1_1_13  free_load_conservation_1237  11
    service_1_1_14  unique_nonzero_owner_383  1
    service_1_1_14  service_visit_def_1236  1
    service_1_1_14  free_load_conservation_1237  12
    service_1_1_15  unique_nonzero_owner_384  1
    service_1_1_15  service_visit_def_1236  1
    service_1_1_15  free_load_conservation_1237  13
    service_1_1_16  unique_nonzero_owner_385  1
    service_1_1_16  service_visit_def_1236  1
    service_1_1_16  free_load_conservation_1237  14
    service_1_1_17  unique_nonzero_owner_386  1
    service_1_1_17  service_visit_def_1236  1
    service_1_1_17  free_load_conservation_1237  15
    service_1_1_18  unique_nonzero_owner_387  1
    service_1_1_18  service_visit_def_1236  1
    service_1_1_18  free_load_conservation_1237  16
    service_1_1_19  unique_nonzero_owner_388  1
    service_1_1_19  service_visit_def_1236  1
    service_1_1_19  free_load_conservation_1237  17
    service_2_1_0  unique_nonzero_owner_370  1
    service_2_1_0  service_visit_def_1555  1
    service_2_1_0  free_load_conservation_1556  -2
    service_2_1_0  original_T_including_depot_unload_1595  240
    service_2_1_1  unique_nonzero_owner_371  1
    service_2_1_1  service_visit_def_1555  1
    service_2_1_1  free_load_conservation_1556  -1
    service_2_1_1  original_T_including_depot_unload_1595  120
    service_2_1_3  unique_nonzero_owner_372  1
    service_2_1_3  service_visit_def_1555  1
    service_2_1_3  free_load_conservation_1556  1
    service_2_1_4  unique_nonzero_owner_373  1
    service_2_1_4  service_visit_def_1555  1
    service_2_1_4  free_load_conservation_1556  2
    service_2_1_5  unique_nonzero_owner_374  1
    service_2_1_5  service_visit_def_1555  1
    service_2_1_5  free_load_conservation_1556  3
    service_2_1_6  unique_nonzero_owner_375  1
    service_2_1_6  service_visit_def_1555  1
    service_2_1_6  free_load_conservation_1556  4
    service_2_1_7  unique_nonzero_owner_376  1
    service_2_1_7  service_visit_def_1555  1
    service_2_1_7  free_load_conservation_1556  5
    service_2_1_8  unique_nonzero_owner_377  1
    service_2_1_8  service_visit_def_1555  1
    service_2_1_8  free_load_conservation_1556  6
    service_2_1_9  unique_nonzero_owner_378  1
    service_2_1_9  service_visit_def_1555  1
    service_2_1_9  free_load_conservation_1556  7
    service_2_1_10  unique_nonzero_owner_379  1
    service_2_1_10  service_visit_def_1555  1
    service_2_1_10  free_load_conservation_1556  8
    service_2_1_11  unique_nonzero_owner_380  1
    service_2_1_11  service_visit_def_1555  1
    service_2_1_11  free_load_conservation_1556  9
    service_2_1_12  unique_nonzero_owner_381  1
    service_2_1_12  service_visit_def_1555  1
    service_2_1_12  free_load_conservation_1556  10
    service_2_1_13  unique_nonzero_owner_382  1
    service_2_1_13  service_visit_def_1555  1
    service_2_1_13  free_load_conservation_1556  11
    service_2_1_14  unique_nonzero_owner_383  1
    service_2_1_14  service_visit_def_1555  1
    service_2_1_14  free_load_conservation_1556  12
    service_2_1_15  unique_nonzero_owner_384  1
    service_2_1_15  service_visit_def_1555  1
    service_2_1_15  free_load_conservation_1556  13
    service_2_1_16  unique_nonzero_owner_385  1
    service_2_1_16  service_visit_def_1555  1
    service_2_1_16  free_load_conservation_1556  14
    service_2_1_17  unique_nonzero_owner_386  1
    service_2_1_17  service_visit_def_1555  1
    service_2_1_17  free_load_conservation_1556  15
    service_2_1_18  unique_nonzero_owner_387  1
    service_2_1_18  service_visit_def_1555  1
    service_2_1_18  free_load_conservation_1556  16
    service_2_1_19  unique_nonzero_owner_388  1
    service_2_1_19  service_visit_def_1555  1
    service_2_1_19  free_load_conservation_1556  17
    service_0_31_0  unique_nonzero_owner_389  1
    service_0_31_0  service_visit_def_814  1
    service_0_31_0  free_load_conservation_815  -2
    service_0_31_0  original_T_including_depot_unload_849  240
    service_0_31_1  unique_nonzero_owner_390  1
    service_0_31_1  service_visit_def_814  1
    service_0_31_1  free_load_conservation_815  -1
    service_0_31_1  original_T_including_depot_unload_849  120
    service_0_31_3  unique_nonzero_owner_391  1
    service_0_31_3  service_visit_def_814  1
    service_0_31_3  free_load_conservation_815  1
    service_0_31_4  unique_nonzero_owner_392  1
    service_0_31_4  service_visit_def_814  1
    service_0_31_4  free_load_conservation_815  2
    service_0_31_5  unique_nonzero_owner_393  1
    service_0_31_5  service_visit_def_814  1
    service_0_31_5  free_load_conservation_815  3
    service_0_31_6  unique_nonzero_owner_394  1
    service_0_31_6  service_visit_def_814  1
    service_0_31_6  free_load_conservation_815  4
    service_0_31_7  unique_nonzero_owner_395  1
    service_0_31_7  service_visit_def_814  1
    service_0_31_7  free_load_conservation_815  5
    service_0_31_8  unique_nonzero_owner_396  1
    service_0_31_8  service_visit_def_814  1
    service_0_31_8  free_load_conservation_815  6
    service_0_31_9  unique_nonzero_owner_397  1
    service_0_31_9  service_visit_def_814  1
    service_0_31_9  free_load_conservation_815  7
    service_0_31_10  unique_nonzero_owner_398  1
    service_0_31_10  service_visit_def_814  1
    service_0_31_10  free_load_conservation_815  8
    service_0_31_11  unique_nonzero_owner_399  1
    service_0_31_11  service_visit_def_814  1
    service_0_31_11  free_load_conservation_815  9
    service_0_31_12  unique_nonzero_owner_400  1
    service_0_31_12  service_visit_def_814  1
    service_0_31_12  free_load_conservation_815  10
    service_1_31_0  unique_nonzero_owner_389  1
    service_1_31_0  service_visit_def_1242  1
    service_1_31_0  free_load_conservation_1243  -2
    service_1_31_0  original_T_including_depot_unload_1278  240
    service_1_31_1  unique_nonzero_owner_390  1
    service_1_31_1  service_visit_def_1242  1
    service_1_31_1  free_load_conservation_1243  -1
    service_1_31_1  original_T_including_depot_unload_1278  120
    service_1_31_3  unique_nonzero_owner_391  1
    service_1_31_3  service_visit_def_1242  1
    service_1_31_3  free_load_conservation_1243  1
    service_1_31_4  unique_nonzero_owner_392  1
    service_1_31_4  service_visit_def_1242  1
    service_1_31_4  free_load_conservation_1243  2
    service_1_31_5  unique_nonzero_owner_393  1
    service_1_31_5  service_visit_def_1242  1
    service_1_31_5  free_load_conservation_1243  3
    service_1_31_6  unique_nonzero_owner_394  1
    service_1_31_6  service_visit_def_1242  1
    service_1_31_6  free_load_conservation_1243  4
    service_1_31_7  unique_nonzero_owner_395  1
    service_1_31_7  service_visit_def_1242  1
    service_1_31_7  free_load_conservation_1243  5
    service_1_31_8  unique_nonzero_owner_396  1
    service_1_31_8  service_visit_def_1242  1
    service_1_31_8  free_load_conservation_1243  6
    service_1_31_9  unique_nonzero_owner_397  1
    service_1_31_9  service_visit_def_1242  1
    service_1_31_9  free_load_conservation_1243  7
    service_1_31_10  unique_nonzero_owner_398  1
    service_1_31_10  service_visit_def_1242  1
    service_1_31_10  free_load_conservation_1243  8
    service_1_31_11  unique_nonzero_owner_399  1
    service_1_31_11  service_visit_def_1242  1
    service_1_31_11  free_load_conservation_1243  9
    service_1_31_12  unique_nonzero_owner_400  1
    service_1_31_12  service_visit_def_1242  1
    service_1_31_12  free_load_conservation_1243  10
    service_2_31_0  unique_nonzero_owner_389  1
    service_2_31_0  service_visit_def_1561  1
    service_2_31_0  free_load_conservation_1562  -2
    service_2_31_0  original_T_including_depot_unload_1595  240
    service_2_31_1  unique_nonzero_owner_390  1
    service_2_31_1  service_visit_def_1561  1
    service_2_31_1  free_load_conservation_1562  -1
    service_2_31_1  original_T_including_depot_unload_1595  120
    service_2_31_3  unique_nonzero_owner_391  1
    service_2_31_3  service_visit_def_1561  1
    service_2_31_3  free_load_conservation_1562  1
    service_2_31_4  unique_nonzero_owner_392  1
    service_2_31_4  service_visit_def_1561  1
    service_2_31_4  free_load_conservation_1562  2
    service_2_31_5  unique_nonzero_owner_393  1
    service_2_31_5  service_visit_def_1561  1
    service_2_31_5  free_load_conservation_1562  3
    service_2_31_6  unique_nonzero_owner_394  1
    service_2_31_6  service_visit_def_1561  1
    service_2_31_6  free_load_conservation_1562  4
    service_2_31_7  unique_nonzero_owner_395  1
    service_2_31_7  service_visit_def_1561  1
    service_2_31_7  free_load_conservation_1562  5
    service_2_31_8  unique_nonzero_owner_396  1
    service_2_31_8  service_visit_def_1561  1
    service_2_31_8  free_load_conservation_1562  6
    service_2_31_9  unique_nonzero_owner_397  1
    service_2_31_9  service_visit_def_1561  1
    service_2_31_9  free_load_conservation_1562  7
    service_2_31_10  unique_nonzero_owner_398  1
    service_2_31_10  service_visit_def_1561  1
    service_2_31_10  free_load_conservation_1562  8
    service_2_31_11  unique_nonzero_owner_399  1
    service_2_31_11  service_visit_def_1561  1
    service_2_31_11  free_load_conservation_1562  9
    service_2_31_12  unique_nonzero_owner_400  1
    service_2_31_12  service_visit_def_1561  1
    service_2_31_12  free_load_conservation_1562  10
    service_0_7_0  unique_nonzero_owner_401  1
    service_0_7_0  service_visit_def_820  1
    service_0_7_0  free_load_conservation_821  -12
    service_0_7_0  original_T_including_depot_unload_849  1440
    service_0_7_1  unique_nonzero_owner_402  1
    service_0_7_1  service_visit_def_820  1
    service_0_7_1  free_load_conservation_821  -11
    service_0_7_1  original_T_including_depot_unload_849  1320
    service_0_7_2  unique_nonzero_owner_403  1
    service_0_7_2  service_visit_def_820  1
    service_0_7_2  free_load_conservation_821  -10
    service_0_7_2  original_T_including_depot_unload_849  1200
    service_0_7_3  unique_nonzero_owner_404  1
    service_0_7_3  service_visit_def_820  1
    service_0_7_3  free_load_conservation_821  -9
    service_0_7_3  original_T_including_depot_unload_849  1080
    service_0_7_4  unique_nonzero_owner_405  1
    service_0_7_4  service_visit_def_820  1
    service_0_7_4  free_load_conservation_821  -8
    service_0_7_4  original_T_including_depot_unload_849  960
    service_0_7_5  unique_nonzero_owner_406  1
    service_0_7_5  service_visit_def_820  1
    service_0_7_5  free_load_conservation_821  -7
    service_0_7_5  original_T_including_depot_unload_849  840
    service_0_7_6  unique_nonzero_owner_407  1
    service_0_7_6  service_visit_def_820  1
    service_0_7_6  free_load_conservation_821  -6
    service_0_7_6  original_T_including_depot_unload_849  720
    service_0_7_7  unique_nonzero_owner_408  1
    service_0_7_7  service_visit_def_820  1
    service_0_7_7  free_load_conservation_821  -5
    service_0_7_7  original_T_including_depot_unload_849  600
    service_0_7_8  unique_nonzero_owner_409  1
    service_0_7_8  service_visit_def_820  1
    service_0_7_8  free_load_conservation_821  -4
    service_0_7_8  original_T_including_depot_unload_849  480
    service_0_7_9  unique_nonzero_owner_410  1
    service_0_7_9  service_visit_def_820  1
    service_0_7_9  free_load_conservation_821  -3
    service_0_7_9  original_T_including_depot_unload_849  360
    service_0_7_10  unique_nonzero_owner_411  1
    service_0_7_10  service_visit_def_820  1
    service_0_7_10  free_load_conservation_821  -2
    service_0_7_10  original_T_including_depot_unload_849  240
    service_0_7_11  unique_nonzero_owner_412  1
    service_0_7_11  service_visit_def_820  1
    service_0_7_11  free_load_conservation_821  -1
    service_0_7_11  original_T_including_depot_unload_849  120
    service_0_7_13  unique_nonzero_owner_413  1
    service_0_7_13  service_visit_def_820  1
    service_0_7_13  free_load_conservation_821  1
    service_0_7_14  unique_nonzero_owner_414  1
    service_0_7_14  service_visit_def_820  1
    service_0_7_14  free_load_conservation_821  2
    service_0_7_15  unique_nonzero_owner_415  1
    service_0_7_15  service_visit_def_820  1
    service_0_7_15  free_load_conservation_821  3
    service_0_7_16  unique_nonzero_owner_416  1
    service_0_7_16  service_visit_def_820  1
    service_0_7_16  free_load_conservation_821  4
    service_0_7_17  unique_nonzero_owner_417  1
    service_0_7_17  service_visit_def_820  1
    service_0_7_17  free_load_conservation_821  5
    service_1_7_0  unique_nonzero_owner_401  1
    service_1_7_0  service_visit_def_1248  1
    service_1_7_0  free_load_conservation_1249  -12
    service_1_7_0  original_T_including_depot_unload_1278  1440
    service_1_7_1  unique_nonzero_owner_402  1
    service_1_7_1  service_visit_def_1248  1
    service_1_7_1  free_load_conservation_1249  -11
    service_1_7_1  original_T_including_depot_unload_1278  1320
    service_1_7_2  unique_nonzero_owner_403  1
    service_1_7_2  service_visit_def_1248  1
    service_1_7_2  free_load_conservation_1249  -10
    service_1_7_2  original_T_including_depot_unload_1278  1200
    service_1_7_3  unique_nonzero_owner_404  1
    service_1_7_3  service_visit_def_1248  1
    service_1_7_3  free_load_conservation_1249  -9
    service_1_7_3  original_T_including_depot_unload_1278  1080
    service_1_7_4  unique_nonzero_owner_405  1
    service_1_7_4  service_visit_def_1248  1
    service_1_7_4  free_load_conservation_1249  -8
    service_1_7_4  original_T_including_depot_unload_1278  960
    service_1_7_5  unique_nonzero_owner_406  1
    service_1_7_5  service_visit_def_1248  1
    service_1_7_5  free_load_conservation_1249  -7
    service_1_7_5  original_T_including_depot_unload_1278  840
    service_1_7_6  unique_nonzero_owner_407  1
    service_1_7_6  service_visit_def_1248  1
    service_1_7_6  free_load_conservation_1249  -6
    service_1_7_6  original_T_including_depot_unload_1278  720
    service_1_7_7  unique_nonzero_owner_408  1
    service_1_7_7  service_visit_def_1248  1
    service_1_7_7  free_load_conservation_1249  -5
    service_1_7_7  original_T_including_depot_unload_1278  600
    service_1_7_8  unique_nonzero_owner_409  1
    service_1_7_8  service_visit_def_1248  1
    service_1_7_8  free_load_conservation_1249  -4
    service_1_7_8  original_T_including_depot_unload_1278  480
    service_1_7_9  unique_nonzero_owner_410  1
    service_1_7_9  service_visit_def_1248  1
    service_1_7_9  free_load_conservation_1249  -3
    service_1_7_9  original_T_including_depot_unload_1278  360
    service_1_7_10  unique_nonzero_owner_411  1
    service_1_7_10  service_visit_def_1248  1
    service_1_7_10  free_load_conservation_1249  -2
    service_1_7_10  original_T_including_depot_unload_1278  240
    service_1_7_11  unique_nonzero_owner_412  1
    service_1_7_11  service_visit_def_1248  1
    service_1_7_11  free_load_conservation_1249  -1
    service_1_7_11  original_T_including_depot_unload_1278  120
    service_1_7_13  unique_nonzero_owner_413  1
    service_1_7_13  service_visit_def_1248  1
    service_1_7_13  free_load_conservation_1249  1
    service_1_7_14  unique_nonzero_owner_414  1
    service_1_7_14  service_visit_def_1248  1
    service_1_7_14  free_load_conservation_1249  2
    service_1_7_15  unique_nonzero_owner_415  1
    service_1_7_15  service_visit_def_1248  1
    service_1_7_15  free_load_conservation_1249  3
    service_1_7_16  unique_nonzero_owner_416  1
    service_1_7_16  service_visit_def_1248  1
    service_1_7_16  free_load_conservation_1249  4
    service_1_7_17  unique_nonzero_owner_417  1
    service_1_7_17  service_visit_def_1248  1
    service_1_7_17  free_load_conservation_1249  5
    service_2_7_0  unique_nonzero_owner_401  1
    service_2_7_0  service_visit_def_1567  1
    service_2_7_0  free_load_conservation_1568  -12
    service_2_7_0  original_T_including_depot_unload_1595  1440
    service_2_7_1  unique_nonzero_owner_402  1
    service_2_7_1  service_visit_def_1567  1
    service_2_7_1  free_load_conservation_1568  -11
    service_2_7_1  original_T_including_depot_unload_1595  1320
    service_2_7_2  unique_nonzero_owner_403  1
    service_2_7_2  service_visit_def_1567  1
    service_2_7_2  free_load_conservation_1568  -10
    service_2_7_2  original_T_including_depot_unload_1595  1200
    service_2_7_3  unique_nonzero_owner_404  1
    service_2_7_3  service_visit_def_1567  1
    service_2_7_3  free_load_conservation_1568  -9
    service_2_7_3  original_T_including_depot_unload_1595  1080
    service_2_7_4  unique_nonzero_owner_405  1
    service_2_7_4  service_visit_def_1567  1
    service_2_7_4  free_load_conservation_1568  -8
    service_2_7_4  original_T_including_depot_unload_1595  960
    service_2_7_5  unique_nonzero_owner_406  1
    service_2_7_5  service_visit_def_1567  1
    service_2_7_5  free_load_conservation_1568  -7
    service_2_7_5  original_T_including_depot_unload_1595  840
    service_2_7_6  unique_nonzero_owner_407  1
    service_2_7_6  service_visit_def_1567  1
    service_2_7_6  free_load_conservation_1568  -6
    service_2_7_6  original_T_including_depot_unload_1595  720
    service_2_7_7  unique_nonzero_owner_408  1
    service_2_7_7  service_visit_def_1567  1
    service_2_7_7  free_load_conservation_1568  -5
    service_2_7_7  original_T_including_depot_unload_1595  600
    service_2_7_8  unique_nonzero_owner_409  1
    service_2_7_8  service_visit_def_1567  1
    service_2_7_8  free_load_conservation_1568  -4
    service_2_7_8  original_T_including_depot_unload_1595  480
    service_2_7_9  unique_nonzero_owner_410  1
    service_2_7_9  service_visit_def_1567  1
    service_2_7_9  free_load_conservation_1568  -3
    service_2_7_9  original_T_including_depot_unload_1595  360
    service_2_7_10  unique_nonzero_owner_411  1
    service_2_7_10  service_visit_def_1567  1
    service_2_7_10  free_load_conservation_1568  -2
    service_2_7_10  original_T_including_depot_unload_1595  240
    service_2_7_11  unique_nonzero_owner_412  1
    service_2_7_11  service_visit_def_1567  1
    service_2_7_11  free_load_conservation_1568  -1
    service_2_7_11  original_T_including_depot_unload_1595  120
    service_2_7_13  unique_nonzero_owner_413  1
    service_2_7_13  service_visit_def_1567  1
    service_2_7_13  free_load_conservation_1568  1
    service_2_7_14  unique_nonzero_owner_414  1
    service_2_7_14  service_visit_def_1567  1
    service_2_7_14  free_load_conservation_1568  2
    service_2_7_15  unique_nonzero_owner_415  1
    service_2_7_15  service_visit_def_1567  1
    service_2_7_15  free_load_conservation_1568  3
    service_2_7_16  unique_nonzero_owner_416  1
    service_2_7_16  service_visit_def_1567  1
    service_2_7_16  free_load_conservation_1568  4
    service_2_7_17  unique_nonzero_owner_417  1
    service_2_7_17  service_visit_def_1567  1
    service_2_7_17  free_load_conservation_1568  5
    service_0_2_1  unique_nonzero_owner_418  1
    service_0_2_1  service_visit_def_826  1
    service_0_2_1  free_load_conservation_827  1
    service_0_2_2  unique_nonzero_owner_419  1
    service_0_2_2  service_visit_def_826  1
    service_0_2_2  free_load_conservation_827  2
    service_0_2_3  unique_nonzero_owner_420  1
    service_0_2_3  service_visit_def_826  1
    service_0_2_3  free_load_conservation_827  3
    service_0_2_4  unique_nonzero_owner_421  1
    service_0_2_4  service_visit_def_826  1
    service_0_2_4  free_load_conservation_827  4
    service_0_2_5  unique_nonzero_owner_422  1
    service_0_2_5  service_visit_def_826  1
    service_0_2_5  free_load_conservation_827  5
    service_0_2_6  unique_nonzero_owner_423  1
    service_0_2_6  service_visit_def_826  1
    service_0_2_6  free_load_conservation_827  6
    service_0_2_7  unique_nonzero_owner_424  1
    service_0_2_7  service_visit_def_826  1
    service_0_2_7  free_load_conservation_827  7
    service_0_2_8  unique_nonzero_owner_425  1
    service_0_2_8  service_visit_def_826  1
    service_0_2_8  free_load_conservation_827  8
    service_0_2_9  unique_nonzero_owner_426  1
    service_0_2_9  service_visit_def_826  1
    service_0_2_9  free_load_conservation_827  9
    service_0_2_10  unique_nonzero_owner_427  1
    service_0_2_10  service_visit_def_826  1
    service_0_2_10  free_load_conservation_827  10
    service_0_2_11  unique_nonzero_owner_428  1
    service_0_2_11  service_visit_def_826  1
    service_0_2_11  free_load_conservation_827  11
    service_0_2_12  unique_nonzero_owner_429  1
    service_0_2_12  service_visit_def_826  1
    service_0_2_12  free_load_conservation_827  12
    service_0_2_13  unique_nonzero_owner_430  1
    service_0_2_13  service_visit_def_826  1
    service_0_2_13  free_load_conservation_827  13
    service_0_2_14  unique_nonzero_owner_431  1
    service_0_2_14  service_visit_def_826  1
    service_0_2_14  free_load_conservation_827  14
    service_0_2_15  unique_nonzero_owner_432  1
    service_0_2_15  service_visit_def_826  1
    service_0_2_15  free_load_conservation_827  15
    service_1_2_1  unique_nonzero_owner_418  1
    service_1_2_1  service_visit_def_1254  1
    service_1_2_1  free_load_conservation_1255  1
    service_1_2_2  unique_nonzero_owner_419  1
    service_1_2_2  service_visit_def_1254  1
    service_1_2_2  free_load_conservation_1255  2
    service_1_2_3  unique_nonzero_owner_420  1
    service_1_2_3  service_visit_def_1254  1
    service_1_2_3  free_load_conservation_1255  3
    service_1_2_4  unique_nonzero_owner_421  1
    service_1_2_4  service_visit_def_1254  1
    service_1_2_4  free_load_conservation_1255  4
    service_1_2_5  unique_nonzero_owner_422  1
    service_1_2_5  service_visit_def_1254  1
    service_1_2_5  free_load_conservation_1255  5
    service_1_2_6  unique_nonzero_owner_423  1
    service_1_2_6  service_visit_def_1254  1
    service_1_2_6  free_load_conservation_1255  6
    service_1_2_7  unique_nonzero_owner_424  1
    service_1_2_7  service_visit_def_1254  1
    service_1_2_7  free_load_conservation_1255  7
    service_1_2_8  unique_nonzero_owner_425  1
    service_1_2_8  service_visit_def_1254  1
    service_1_2_8  free_load_conservation_1255  8
    service_1_2_9  unique_nonzero_owner_426  1
    service_1_2_9  service_visit_def_1254  1
    service_1_2_9  free_load_conservation_1255  9
    service_1_2_10  unique_nonzero_owner_427  1
    service_1_2_10  service_visit_def_1254  1
    service_1_2_10  free_load_conservation_1255  10
    service_1_2_11  unique_nonzero_owner_428  1
    service_1_2_11  service_visit_def_1254  1
    service_1_2_11  free_load_conservation_1255  11
    service_1_2_12  unique_nonzero_owner_429  1
    service_1_2_12  service_visit_def_1254  1
    service_1_2_12  free_load_conservation_1255  12
    service_1_2_13  unique_nonzero_owner_430  1
    service_1_2_13  service_visit_def_1254  1
    service_1_2_13  free_load_conservation_1255  13
    service_1_2_14  unique_nonzero_owner_431  1
    service_1_2_14  service_visit_def_1254  1
    service_1_2_14  free_load_conservation_1255  14
    service_1_2_15  unique_nonzero_owner_432  1
    service_1_2_15  service_visit_def_1254  1
    service_1_2_15  free_load_conservation_1255  15
    service_2_2_1  unique_nonzero_owner_418  1
    service_2_2_1  service_visit_def_1573  1
    service_2_2_1  free_load_conservation_1574  1
    service_2_2_2  unique_nonzero_owner_419  1
    service_2_2_2  service_visit_def_1573  1
    service_2_2_2  free_load_conservation_1574  2
    service_2_2_3  unique_nonzero_owner_420  1
    service_2_2_3  service_visit_def_1573  1
    service_2_2_3  free_load_conservation_1574  3
    service_2_2_4  unique_nonzero_owner_421  1
    service_2_2_4  service_visit_def_1573  1
    service_2_2_4  free_load_conservation_1574  4
    service_2_2_5  unique_nonzero_owner_422  1
    service_2_2_5  service_visit_def_1573  1
    service_2_2_5  free_load_conservation_1574  5
    service_2_2_6  unique_nonzero_owner_423  1
    service_2_2_6  service_visit_def_1573  1
    service_2_2_6  free_load_conservation_1574  6
    service_2_2_7  unique_nonzero_owner_424  1
    service_2_2_7  service_visit_def_1573  1
    service_2_2_7  free_load_conservation_1574  7
    service_2_2_8  unique_nonzero_owner_425  1
    service_2_2_8  service_visit_def_1573  1
    service_2_2_8  free_load_conservation_1574  8
    service_2_2_9  unique_nonzero_owner_426  1
    service_2_2_9  service_visit_def_1573  1
    service_2_2_9  free_load_conservation_1574  9
    service_2_2_10  unique_nonzero_owner_427  1
    service_2_2_10  service_visit_def_1573  1
    service_2_2_10  free_load_conservation_1574  10
    service_2_2_11  unique_nonzero_owner_428  1
    service_2_2_11  service_visit_def_1573  1
    service_2_2_11  free_load_conservation_1574  11
    service_2_2_12  unique_nonzero_owner_429  1
    service_2_2_12  service_visit_def_1573  1
    service_2_2_12  free_load_conservation_1574  12
    service_2_2_13  unique_nonzero_owner_430  1
    service_2_2_13  service_visit_def_1573  1
    service_2_2_13  free_load_conservation_1574  13
    service_2_2_14  unique_nonzero_owner_431  1
    service_2_2_14  service_visit_def_1573  1
    service_2_2_14  free_load_conservation_1574  14
    service_2_2_15  unique_nonzero_owner_432  1
    service_2_2_15  service_visit_def_1573  1
    service_2_2_15  free_load_conservation_1574  15
    service_0_4_0  unique_nonzero_owner_433  1
    service_0_4_0  service_visit_def_832  1
    service_0_4_0  free_load_conservation_833  -11
    service_0_4_0  original_T_including_depot_unload_849  1320
    service_0_4_1  unique_nonzero_owner_434  1
    service_0_4_1  service_visit_def_832  1
    service_0_4_1  free_load_conservation_833  -10
    service_0_4_1  original_T_including_depot_unload_849  1200
    service_0_4_2  unique_nonzero_owner_435  1
    service_0_4_2  service_visit_def_832  1
    service_0_4_2  free_load_conservation_833  -9
    service_0_4_2  original_T_including_depot_unload_849  1080
    service_0_4_3  unique_nonzero_owner_436  1
    service_0_4_3  service_visit_def_832  1
    service_0_4_3  free_load_conservation_833  -8
    service_0_4_3  original_T_including_depot_unload_849  960
    service_0_4_4  unique_nonzero_owner_437  1
    service_0_4_4  service_visit_def_832  1
    service_0_4_4  free_load_conservation_833  -7
    service_0_4_4  original_T_including_depot_unload_849  840
    service_0_4_5  unique_nonzero_owner_438  1
    service_0_4_5  service_visit_def_832  1
    service_0_4_5  free_load_conservation_833  -6
    service_0_4_5  original_T_including_depot_unload_849  720
    service_0_4_6  unique_nonzero_owner_439  1
    service_0_4_6  service_visit_def_832  1
    service_0_4_6  free_load_conservation_833  -5
    service_0_4_6  original_T_including_depot_unload_849  600
    service_0_4_7  unique_nonzero_owner_440  1
    service_0_4_7  service_visit_def_832  1
    service_0_4_7  free_load_conservation_833  -4
    service_0_4_7  original_T_including_depot_unload_849  480
    service_0_4_8  unique_nonzero_owner_441  1
    service_0_4_8  service_visit_def_832  1
    service_0_4_8  free_load_conservation_833  -3
    service_0_4_8  original_T_including_depot_unload_849  360
    service_0_4_9  unique_nonzero_owner_442  1
    service_0_4_9  service_visit_def_832  1
    service_0_4_9  free_load_conservation_833  -2
    service_0_4_9  original_T_including_depot_unload_849  240
    service_0_4_10  unique_nonzero_owner_443  1
    service_0_4_10  service_visit_def_832  1
    service_0_4_10  free_load_conservation_833  -1
    service_0_4_10  original_T_including_depot_unload_849  120
    service_0_4_12  unique_nonzero_owner_444  1
    service_0_4_12  service_visit_def_832  1
    service_0_4_12  free_load_conservation_833  1
    service_0_4_13  unique_nonzero_owner_445  1
    service_0_4_13  service_visit_def_832  1
    service_0_4_13  free_load_conservation_833  2
    service_0_4_14  unique_nonzero_owner_446  1
    service_0_4_14  service_visit_def_832  1
    service_0_4_14  free_load_conservation_833  3
    service_0_4_15  unique_nonzero_owner_447  1
    service_0_4_15  service_visit_def_832  1
    service_0_4_15  free_load_conservation_833  4
    service_1_4_0  unique_nonzero_owner_433  1
    service_1_4_0  service_visit_def_1260  1
    service_1_4_0  free_load_conservation_1261  -11
    service_1_4_0  original_T_including_depot_unload_1278  1320
    service_1_4_1  unique_nonzero_owner_434  1
    service_1_4_1  service_visit_def_1260  1
    service_1_4_1  free_load_conservation_1261  -10
    service_1_4_1  original_T_including_depot_unload_1278  1200
    service_1_4_2  unique_nonzero_owner_435  1
    service_1_4_2  service_visit_def_1260  1
    service_1_4_2  free_load_conservation_1261  -9
    service_1_4_2  original_T_including_depot_unload_1278  1080
    service_1_4_3  unique_nonzero_owner_436  1
    service_1_4_3  service_visit_def_1260  1
    service_1_4_3  free_load_conservation_1261  -8
    service_1_4_3  original_T_including_depot_unload_1278  960
    service_1_4_4  unique_nonzero_owner_437  1
    service_1_4_4  service_visit_def_1260  1
    service_1_4_4  free_load_conservation_1261  -7
    service_1_4_4  original_T_including_depot_unload_1278  840
    service_1_4_5  unique_nonzero_owner_438  1
    service_1_4_5  service_visit_def_1260  1
    service_1_4_5  free_load_conservation_1261  -6
    service_1_4_5  original_T_including_depot_unload_1278  720
    service_1_4_6  unique_nonzero_owner_439  1
    service_1_4_6  service_visit_def_1260  1
    service_1_4_6  free_load_conservation_1261  -5
    service_1_4_6  original_T_including_depot_unload_1278  600
    service_1_4_7  unique_nonzero_owner_440  1
    service_1_4_7  service_visit_def_1260  1
    service_1_4_7  free_load_conservation_1261  -4
    service_1_4_7  original_T_including_depot_unload_1278  480
    service_1_4_8  unique_nonzero_owner_441  1
    service_1_4_8  service_visit_def_1260  1
    service_1_4_8  free_load_conservation_1261  -3
    service_1_4_8  original_T_including_depot_unload_1278  360
    service_1_4_9  unique_nonzero_owner_442  1
    service_1_4_9  service_visit_def_1260  1
    service_1_4_9  free_load_conservation_1261  -2
    service_1_4_9  original_T_including_depot_unload_1278  240
    service_1_4_10  unique_nonzero_owner_443  1
    service_1_4_10  service_visit_def_1260  1
    service_1_4_10  free_load_conservation_1261  -1
    service_1_4_10  original_T_including_depot_unload_1278  120
    service_1_4_12  unique_nonzero_owner_444  1
    service_1_4_12  service_visit_def_1260  1
    service_1_4_12  free_load_conservation_1261  1
    service_1_4_13  unique_nonzero_owner_445  1
    service_1_4_13  service_visit_def_1260  1
    service_1_4_13  free_load_conservation_1261  2
    service_1_4_14  unique_nonzero_owner_446  1
    service_1_4_14  service_visit_def_1260  1
    service_1_4_14  free_load_conservation_1261  3
    service_1_4_15  unique_nonzero_owner_447  1
    service_1_4_15  service_visit_def_1260  1
    service_1_4_15  free_load_conservation_1261  4
    service_2_4_0  unique_nonzero_owner_433  1
    service_2_4_0  service_visit_def_1579  1
    service_2_4_0  free_load_conservation_1580  -11
    service_2_4_0  original_T_including_depot_unload_1595  1320
    service_2_4_1  unique_nonzero_owner_434  1
    service_2_4_1  service_visit_def_1579  1
    service_2_4_1  free_load_conservation_1580  -10
    service_2_4_1  original_T_including_depot_unload_1595  1200
    service_2_4_2  unique_nonzero_owner_435  1
    service_2_4_2  service_visit_def_1579  1
    service_2_4_2  free_load_conservation_1580  -9
    service_2_4_2  original_T_including_depot_unload_1595  1080
    service_2_4_3  unique_nonzero_owner_436  1
    service_2_4_3  service_visit_def_1579  1
    service_2_4_3  free_load_conservation_1580  -8
    service_2_4_3  original_T_including_depot_unload_1595  960
    service_2_4_4  unique_nonzero_owner_437  1
    service_2_4_4  service_visit_def_1579  1
    service_2_4_4  free_load_conservation_1580  -7
    service_2_4_4  original_T_including_depot_unload_1595  840
    service_2_4_5  unique_nonzero_owner_438  1
    service_2_4_5  service_visit_def_1579  1
    service_2_4_5  free_load_conservation_1580  -6
    service_2_4_5  original_T_including_depot_unload_1595  720
    service_2_4_6  unique_nonzero_owner_439  1
    service_2_4_6  service_visit_def_1579  1
    service_2_4_6  free_load_conservation_1580  -5
    service_2_4_6  original_T_including_depot_unload_1595  600
    service_2_4_7  unique_nonzero_owner_440  1
    service_2_4_7  service_visit_def_1579  1
    service_2_4_7  free_load_conservation_1580  -4
    service_2_4_7  original_T_including_depot_unload_1595  480
    service_2_4_8  unique_nonzero_owner_441  1
    service_2_4_8  service_visit_def_1579  1
    service_2_4_8  free_load_conservation_1580  -3
    service_2_4_8  original_T_including_depot_unload_1595  360
    service_2_4_9  unique_nonzero_owner_442  1
    service_2_4_9  service_visit_def_1579  1
    service_2_4_9  free_load_conservation_1580  -2
    service_2_4_9  original_T_including_depot_unload_1595  240
    service_2_4_10  unique_nonzero_owner_443  1
    service_2_4_10  service_visit_def_1579  1
    service_2_4_10  free_load_conservation_1580  -1
    service_2_4_10  original_T_including_depot_unload_1595  120
    service_2_4_12  unique_nonzero_owner_444  1
    service_2_4_12  service_visit_def_1579  1
    service_2_4_12  free_load_conservation_1580  1
    service_2_4_13  unique_nonzero_owner_445  1
    service_2_4_13  service_visit_def_1579  1
    service_2_4_13  free_load_conservation_1580  2
    service_2_4_14  unique_nonzero_owner_446  1
    service_2_4_14  service_visit_def_1579  1
    service_2_4_14  free_load_conservation_1580  3
    service_2_4_15  unique_nonzero_owner_447  1
    service_2_4_15  service_visit_def_1579  1
    service_2_4_15  free_load_conservation_1580  4
    service_0_16_0  unique_nonzero_owner_448  1
    service_0_16_0  service_visit_def_838  1
    service_0_16_0  free_load_conservation_839  -1
    service_0_16_0  original_T_including_depot_unload_849  120
    service_0_16_2  unique_nonzero_owner_449  1
    service_0_16_2  service_visit_def_838  1
    service_0_16_2  free_load_conservation_839  1
    service_0_16_3  unique_nonzero_owner_450  1
    service_0_16_3  service_visit_def_838  1
    service_0_16_3  free_load_conservation_839  2
    service_0_16_4  unique_nonzero_owner_451  1
    service_0_16_4  service_visit_def_838  1
    service_0_16_4  free_load_conservation_839  3
    service_0_16_5  unique_nonzero_owner_452  1
    service_0_16_5  service_visit_def_838  1
    service_0_16_5  free_load_conservation_839  4
    service_0_16_6  unique_nonzero_owner_453  1
    service_0_16_6  service_visit_def_838  1
    service_0_16_6  free_load_conservation_839  5
    service_0_16_7  unique_nonzero_owner_454  1
    service_0_16_7  service_visit_def_838  1
    service_0_16_7  free_load_conservation_839  6
    service_0_16_8  unique_nonzero_owner_455  1
    service_0_16_8  service_visit_def_838  1
    service_0_16_8  free_load_conservation_839  7
    service_0_16_9  unique_nonzero_owner_456  1
    service_0_16_9  service_visit_def_838  1
    service_0_16_9  free_load_conservation_839  8
    service_0_16_10  unique_nonzero_owner_457  1
    service_0_16_10  service_visit_def_838  1
    service_0_16_10  free_load_conservation_839  9
    service_0_16_11  unique_nonzero_owner_458  1
    service_0_16_11  service_visit_def_838  1
    service_0_16_11  free_load_conservation_839  10
    service_0_16_12  unique_nonzero_owner_459  1
    service_0_16_12  service_visit_def_838  1
    service_0_16_12  free_load_conservation_839  11
    service_1_16_0  unique_nonzero_owner_448  1
    service_1_16_0  service_visit_def_1266  1
    service_1_16_0  free_load_conservation_1267  -1
    service_1_16_0  original_T_including_depot_unload_1278  120
    service_1_16_2  unique_nonzero_owner_449  1
    service_1_16_2  service_visit_def_1266  1
    service_1_16_2  free_load_conservation_1267  1
    service_1_16_3  unique_nonzero_owner_450  1
    service_1_16_3  service_visit_def_1266  1
    service_1_16_3  free_load_conservation_1267  2
    service_1_16_4  unique_nonzero_owner_451  1
    service_1_16_4  service_visit_def_1266  1
    service_1_16_4  free_load_conservation_1267  3
    service_1_16_5  unique_nonzero_owner_452  1
    service_1_16_5  service_visit_def_1266  1
    service_1_16_5  free_load_conservation_1267  4
    service_1_16_6  unique_nonzero_owner_453  1
    service_1_16_6  service_visit_def_1266  1
    service_1_16_6  free_load_conservation_1267  5
    service_1_16_7  unique_nonzero_owner_454  1
    service_1_16_7  service_visit_def_1266  1
    service_1_16_7  free_load_conservation_1267  6
    service_1_16_8  unique_nonzero_owner_455  1
    service_1_16_8  service_visit_def_1266  1
    service_1_16_8  free_load_conservation_1267  7
    service_1_16_9  unique_nonzero_owner_456  1
    service_1_16_9  service_visit_def_1266  1
    service_1_16_9  free_load_conservation_1267  8
    service_1_16_10  unique_nonzero_owner_457  1
    service_1_16_10  service_visit_def_1266  1
    service_1_16_10  free_load_conservation_1267  9
    service_1_16_11  unique_nonzero_owner_458  1
    service_1_16_11  service_visit_def_1266  1
    service_1_16_11  free_load_conservation_1267  10
    service_1_16_12  unique_nonzero_owner_459  1
    service_1_16_12  service_visit_def_1266  1
    service_1_16_12  free_load_conservation_1267  11
    service_2_16_0  unique_nonzero_owner_448  1
    service_2_16_0  service_visit_def_1585  1
    service_2_16_0  free_load_conservation_1586  -1
    service_2_16_0  original_T_including_depot_unload_1595  120
    service_2_16_2  unique_nonzero_owner_449  1
    service_2_16_2  service_visit_def_1585  1
    service_2_16_2  free_load_conservation_1586  1
    service_2_16_3  unique_nonzero_owner_450  1
    service_2_16_3  service_visit_def_1585  1
    service_2_16_3  free_load_conservation_1586  2
    service_2_16_4  unique_nonzero_owner_451  1
    service_2_16_4  service_visit_def_1585  1
    service_2_16_4  free_load_conservation_1586  3
    service_2_16_5  unique_nonzero_owner_452  1
    service_2_16_5  service_visit_def_1585  1
    service_2_16_5  free_load_conservation_1586  4
    service_2_16_6  unique_nonzero_owner_453  1
    service_2_16_6  service_visit_def_1585  1
    service_2_16_6  free_load_conservation_1586  5
    service_2_16_7  unique_nonzero_owner_454  1
    service_2_16_7  service_visit_def_1585  1
    service_2_16_7  free_load_conservation_1586  6
    service_2_16_8  unique_nonzero_owner_455  1
    service_2_16_8  service_visit_def_1585  1
    service_2_16_8  free_load_conservation_1586  7
    service_2_16_9  unique_nonzero_owner_456  1
    service_2_16_9  service_visit_def_1585  1
    service_2_16_9  free_load_conservation_1586  8
    service_2_16_10  unique_nonzero_owner_457  1
    service_2_16_10  service_visit_def_1585  1
    service_2_16_10  free_load_conservation_1586  9
    service_2_16_11  unique_nonzero_owner_458  1
    service_2_16_11  service_visit_def_1585  1
    service_2_16_11  free_load_conservation_1586  10
    service_2_16_12  unique_nonzero_owner_459  1
    service_2_16_12  service_visit_def_1585  1
    service_2_16_12  free_load_conservation_1586  11
    service_0_10_0  unique_nonzero_owner_460  1
    service_0_10_0  service_visit_def_844  1
    service_0_10_0  free_load_conservation_845  -15
    service_0_10_0  original_T_including_depot_unload_849  1800
    service_0_10_1  unique_nonzero_owner_461  1
    service_0_10_1  service_visit_def_844  1
    service_0_10_1  free_load_conservation_845  -14
    service_0_10_1  original_T_including_depot_unload_849  1680
    service_0_10_2  unique_nonzero_owner_462  1
    service_0_10_2  service_visit_def_844  1
    service_0_10_2  free_load_conservation_845  -13
    service_0_10_2  original_T_including_depot_unload_849  1560
    service_0_10_3  unique_nonzero_owner_463  1
    service_0_10_3  service_visit_def_844  1
    service_0_10_3  free_load_conservation_845  -12
    service_0_10_3  original_T_including_depot_unload_849  1440
    service_0_10_4  unique_nonzero_owner_464  1
    service_0_10_4  service_visit_def_844  1
    service_0_10_4  free_load_conservation_845  -11
    service_0_10_4  original_T_including_depot_unload_849  1320
    service_0_10_5  unique_nonzero_owner_465  1
    service_0_10_5  service_visit_def_844  1
    service_0_10_5  free_load_conservation_845  -10
    service_0_10_5  original_T_including_depot_unload_849  1200
    service_0_10_6  unique_nonzero_owner_466  1
    service_0_10_6  service_visit_def_844  1
    service_0_10_6  free_load_conservation_845  -9
    service_0_10_6  original_T_including_depot_unload_849  1080
    service_0_10_7  unique_nonzero_owner_467  1
    service_0_10_7  service_visit_def_844  1
    service_0_10_7  free_load_conservation_845  -8
    service_0_10_7  original_T_including_depot_unload_849  960
    service_0_10_8  unique_nonzero_owner_468  1
    service_0_10_8  service_visit_def_844  1
    service_0_10_8  free_load_conservation_845  -7
    service_0_10_8  original_T_including_depot_unload_849  840
    service_0_10_9  unique_nonzero_owner_469  1
    service_0_10_9  service_visit_def_844  1
    service_0_10_9  free_load_conservation_845  -6
    service_0_10_9  original_T_including_depot_unload_849  720
    service_0_10_10  unique_nonzero_owner_470  1
    service_0_10_10  service_visit_def_844  1
    service_0_10_10  free_load_conservation_845  -5
    service_0_10_10  original_T_including_depot_unload_849  600
    service_0_10_11  unique_nonzero_owner_471  1
    service_0_10_11  service_visit_def_844  1
    service_0_10_11  free_load_conservation_845  -4
    service_0_10_11  original_T_including_depot_unload_849  480
    service_0_10_12  unique_nonzero_owner_472  1
    service_0_10_12  service_visit_def_844  1
    service_0_10_12  free_load_conservation_845  -3
    service_0_10_12  original_T_including_depot_unload_849  360
    service_0_10_13  unique_nonzero_owner_473  1
    service_0_10_13  service_visit_def_844  1
    service_0_10_13  free_load_conservation_845  -2
    service_0_10_13  original_T_including_depot_unload_849  240
    service_0_10_14  unique_nonzero_owner_474  1
    service_0_10_14  service_visit_def_844  1
    service_0_10_14  free_load_conservation_845  -1
    service_0_10_14  original_T_including_depot_unload_849  120
    service_0_10_16  unique_nonzero_owner_475  1
    service_0_10_16  service_visit_def_844  1
    service_0_10_16  free_load_conservation_845  1
    service_0_10_17  unique_nonzero_owner_476  1
    service_0_10_17  service_visit_def_844  1
    service_0_10_17  free_load_conservation_845  2
    service_0_10_18  unique_nonzero_owner_477  1
    service_0_10_18  service_visit_def_844  1
    service_0_10_18  free_load_conservation_845  3
    service_0_10_19  unique_nonzero_owner_478  1
    service_0_10_19  service_visit_def_844  1
    service_0_10_19  free_load_conservation_845  4
    service_1_10_0  unique_nonzero_owner_460  1
    service_1_10_0  service_visit_def_1272  1
    service_1_10_0  free_load_conservation_1273  -15
    service_1_10_0  original_T_including_depot_unload_1278  1800
    service_1_10_1  unique_nonzero_owner_461  1
    service_1_10_1  service_visit_def_1272  1
    service_1_10_1  free_load_conservation_1273  -14
    service_1_10_1  original_T_including_depot_unload_1278  1680
    service_1_10_2  unique_nonzero_owner_462  1
    service_1_10_2  service_visit_def_1272  1
    service_1_10_2  free_load_conservation_1273  -13
    service_1_10_2  original_T_including_depot_unload_1278  1560
    service_1_10_3  unique_nonzero_owner_463  1
    service_1_10_3  service_visit_def_1272  1
    service_1_10_3  free_load_conservation_1273  -12
    service_1_10_3  original_T_including_depot_unload_1278  1440
    service_1_10_4  unique_nonzero_owner_464  1
    service_1_10_4  service_visit_def_1272  1
    service_1_10_4  free_load_conservation_1273  -11
    service_1_10_4  original_T_including_depot_unload_1278  1320
    service_1_10_5  unique_nonzero_owner_465  1
    service_1_10_5  service_visit_def_1272  1
    service_1_10_5  free_load_conservation_1273  -10
    service_1_10_5  original_T_including_depot_unload_1278  1200
    service_1_10_6  unique_nonzero_owner_466  1
    service_1_10_6  service_visit_def_1272  1
    service_1_10_6  free_load_conservation_1273  -9
    service_1_10_6  original_T_including_depot_unload_1278  1080
    service_1_10_7  unique_nonzero_owner_467  1
    service_1_10_7  service_visit_def_1272  1
    service_1_10_7  free_load_conservation_1273  -8
    service_1_10_7  original_T_including_depot_unload_1278  960
    service_1_10_8  unique_nonzero_owner_468  1
    service_1_10_8  service_visit_def_1272  1
    service_1_10_8  free_load_conservation_1273  -7
    service_1_10_8  original_T_including_depot_unload_1278  840
    service_1_10_9  unique_nonzero_owner_469  1
    service_1_10_9  service_visit_def_1272  1
    service_1_10_9  free_load_conservation_1273  -6
    service_1_10_9  original_T_including_depot_unload_1278  720
    service_1_10_10  unique_nonzero_owner_470  1
    service_1_10_10  service_visit_def_1272  1
    service_1_10_10  free_load_conservation_1273  -5
    service_1_10_10  original_T_including_depot_unload_1278  600
    service_1_10_11  unique_nonzero_owner_471  1
    service_1_10_11  service_visit_def_1272  1
    service_1_10_11  free_load_conservation_1273  -4
    service_1_10_11  original_T_including_depot_unload_1278  480
    service_1_10_12  unique_nonzero_owner_472  1
    service_1_10_12  service_visit_def_1272  1
    service_1_10_12  free_load_conservation_1273  -3
    service_1_10_12  original_T_including_depot_unload_1278  360
    service_1_10_13  unique_nonzero_owner_473  1
    service_1_10_13  service_visit_def_1272  1
    service_1_10_13  free_load_conservation_1273  -2
    service_1_10_13  original_T_including_depot_unload_1278  240
    service_1_10_14  unique_nonzero_owner_474  1
    service_1_10_14  service_visit_def_1272  1
    service_1_10_14  free_load_conservation_1273  -1
    service_1_10_14  original_T_including_depot_unload_1278  120
    service_1_10_16  unique_nonzero_owner_475  1
    service_1_10_16  service_visit_def_1272  1
    service_1_10_16  free_load_conservation_1273  1
    service_1_10_17  unique_nonzero_owner_476  1
    service_1_10_17  service_visit_def_1272  1
    service_1_10_17  free_load_conservation_1273  2
    service_1_10_18  unique_nonzero_owner_477  1
    service_1_10_18  service_visit_def_1272  1
    service_1_10_18  free_load_conservation_1273  3
    service_1_10_19  unique_nonzero_owner_478  1
    service_1_10_19  service_visit_def_1272  1
    service_1_10_19  free_load_conservation_1273  4
    service_2_10_0  unique_nonzero_owner_460  1
    service_2_10_0  service_visit_def_1591  1
    service_2_10_0  free_load_conservation_1592  -15
    service_2_10_0  original_T_including_depot_unload_1595  1800
    service_2_10_1  unique_nonzero_owner_461  1
    service_2_10_1  service_visit_def_1591  1
    service_2_10_1  free_load_conservation_1592  -14
    service_2_10_1  original_T_including_depot_unload_1595  1680
    service_2_10_2  unique_nonzero_owner_462  1
    service_2_10_2  service_visit_def_1591  1
    service_2_10_2  free_load_conservation_1592  -13
    service_2_10_2  original_T_including_depot_unload_1595  1560
    service_2_10_3  unique_nonzero_owner_463  1
    service_2_10_3  service_visit_def_1591  1
    service_2_10_3  free_load_conservation_1592  -12
    service_2_10_3  original_T_including_depot_unload_1595  1440
    service_2_10_4  unique_nonzero_owner_464  1
    service_2_10_4  service_visit_def_1591  1
    service_2_10_4  free_load_conservation_1592  -11
    service_2_10_4  original_T_including_depot_unload_1595  1320
    service_2_10_5  unique_nonzero_owner_465  1
    service_2_10_5  service_visit_def_1591  1
    service_2_10_5  free_load_conservation_1592  -10
    service_2_10_5  original_T_including_depot_unload_1595  1200
    service_2_10_6  unique_nonzero_owner_466  1
    service_2_10_6  service_visit_def_1591  1
    service_2_10_6  free_load_conservation_1592  -9
    service_2_10_6  original_T_including_depot_unload_1595  1080
    service_2_10_7  unique_nonzero_owner_467  1
    service_2_10_7  service_visit_def_1591  1
    service_2_10_7  free_load_conservation_1592  -8
    service_2_10_7  original_T_including_depot_unload_1595  960
    service_2_10_8  unique_nonzero_owner_468  1
    service_2_10_8  service_visit_def_1591  1
    service_2_10_8  free_load_conservation_1592  -7
    service_2_10_8  original_T_including_depot_unload_1595  840
    service_2_10_9  unique_nonzero_owner_469  1
    service_2_10_9  service_visit_def_1591  1
    service_2_10_9  free_load_conservation_1592  -6
    service_2_10_9  original_T_including_depot_unload_1595  720
    service_2_10_10  unique_nonzero_owner_470  1
    service_2_10_10  service_visit_def_1591  1
    service_2_10_10  free_load_conservation_1592  -5
    service_2_10_10  original_T_including_depot_unload_1595  600
    service_2_10_11  unique_nonzero_owner_471  1
    service_2_10_11  service_visit_def_1591  1
    service_2_10_11  free_load_conservation_1592  -4
    service_2_10_11  original_T_including_depot_unload_1595  480
    service_2_10_12  unique_nonzero_owner_472  1
    service_2_10_12  service_visit_def_1591  1
    service_2_10_12  free_load_conservation_1592  -3
    service_2_10_12  original_T_including_depot_unload_1595  360
    service_2_10_13  unique_nonzero_owner_473  1
    service_2_10_13  service_visit_def_1591  1
    service_2_10_13  free_load_conservation_1592  -2
    service_2_10_13  original_T_including_depot_unload_1595  240
    service_2_10_14  unique_nonzero_owner_474  1
    service_2_10_14  service_visit_def_1591  1
    service_2_10_14  free_load_conservation_1592  -1
    service_2_10_14  original_T_including_depot_unload_1595  120
    service_2_10_16  unique_nonzero_owner_475  1
    service_2_10_16  service_visit_def_1591  1
    service_2_10_16  free_load_conservation_1592  1
    service_2_10_17  unique_nonzero_owner_476  1
    service_2_10_17  service_visit_def_1591  1
    service_2_10_17  free_load_conservation_1592  2
    service_2_10_18  unique_nonzero_owner_477  1
    service_2_10_18  service_visit_def_1591  1
    service_2_10_18  free_load_conservation_1592  3
    service_2_10_19  unique_nonzero_owner_478  1
    service_2_10_19  service_visit_def_1591  1
    service_2_10_19  free_load_conservation_1592  4
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_770  -1
    visit_0_1  in_degree_771  -1
    visit_0_1  order_active_lb_772  -1
    visit_0_1  order_active_ub_773  -12
    order_0_1  connected_order_arc_494  -1
    order_0_1  connected_order_arc_496  -1
    order_0_1  connected_order_arc_498  -1
    order_0_1  connected_order_arc_500  -1
    order_0_1  connected_order_arc_502  -1
    order_0_1  connected_order_arc_504  -1
    order_0_1  connected_order_arc_506  -1
    order_0_1  connected_order_arc_508  -1
    order_0_1  connected_order_arc_510  -1
    order_0_1  connected_order_arc_512  -1
    order_0_1  connected_order_arc_514  -1
    order_0_1  connected_order_arc_517  1
    order_0_1  connected_order_arc_540  1
    order_0_1  connected_order_arc_563  1
    order_0_1  connected_order_arc_586  1
    order_0_1  connected_order_arc_609  1
    order_0_1  connected_order_arc_632  1
    order_0_1  connected_order_arc_655  1
    order_0_1  connected_order_arc_678  1
    order_0_1  connected_order_arc_701  1
    order_0_1  connected_order_arc_724  1
    order_0_1  connected_order_arc_747  1
    order_0_1  order_active_lb_772  1
    order_0_1  order_active_ub_773  1
    order_0_1  fixed_segment_relative_order_846  -1
    visit_0_2  out_degree_777  -1
    visit_0_2  in_degree_778  -1
    visit_0_2  order_active_lb_779  -1
    visit_0_2  order_active_ub_780  -12
    order_0_2  connected_order_arc_494  1
    order_0_2  connected_order_arc_517  -1
    order_0_2  connected_order_arc_519  -1
    order_0_2  connected_order_arc_521  -1
    order_0_2  connected_order_arc_523  -1
    order_0_2  connected_order_arc_525  -1
    order_0_2  connected_order_arc_527  -1
    order_0_2  connected_order_arc_529  -1
    order_0_2  connected_order_arc_531  -1
    order_0_2  connected_order_arc_533  -1
    order_0_2  connected_order_arc_535  -1
    order_0_2  connected_order_arc_537  -1
    order_0_2  connected_order_arc_542  1
    order_0_2  connected_order_arc_565  1
    order_0_2  connected_order_arc_588  1
    order_0_2  connected_order_arc_611  1
    order_0_2  connected_order_arc_634  1
    order_0_2  connected_order_arc_657  1
    order_0_2  connected_order_arc_680  1
    order_0_2  connected_order_arc_703  1
    order_0_2  connected_order_arc_726  1
    order_0_2  connected_order_arc_749  1
    order_0_2  order_active_lb_779  1
    order_0_2  order_active_ub_780  1
    order_0_2  fixed_segment_relative_order_846  1
    order_0_2  fixed_segment_relative_order_847  -1
    visit_0_3  out_degree_784  -1
    visit_0_3  in_degree_785  -1
    visit_0_3  order_active_lb_786  -1
    visit_0_3  order_active_ub_787  -12
    order_0_3  connected_order_arc_496  1
    order_0_3  connected_order_arc_519  1
    order_0_3  connected_order_arc_540  -1
    order_0_3  connected_order_arc_542  -1
    order_0_3  connected_order_arc_544  -1
    order_0_3  connected_order_arc_546  -1
    order_0_3  connected_order_arc_548  -1
    order_0_3  connected_order_arc_550  -1
    order_0_3  connected_order_arc_552  -1
    order_0_3  connected_order_arc_554  -1
    order_0_3  connected_order_arc_556  -1
    order_0_3  connected_order_arc_558  -1
    order_0_3  connected_order_arc_560  -1
    order_0_3  connected_order_arc_567  1
    order_0_3  connected_order_arc_590  1
    order_0_3  connected_order_arc_613  1
    order_0_3  connected_order_arc_636  1
    order_0_3  connected_order_arc_659  1
    order_0_3  connected_order_arc_682  1
    order_0_3  connected_order_arc_705  1
    order_0_3  connected_order_arc_728  1
    order_0_3  connected_order_arc_751  1
    order_0_3  order_active_lb_786  1
    order_0_3  order_active_ub_787  1
    order_0_3  fixed_segment_relative_order_847  1
    order_0_3  fixed_segment_relative_order_848  -1
    visit_0_4  out_degree_791  -1
    visit_0_4  in_degree_792  -1
    visit_0_4  order_active_lb_793  -1
    visit_0_4  order_active_ub_794  -12
    order_0_4  connected_order_arc_498  1
    order_0_4  connected_order_arc_521  1
    order_0_4  connected_order_arc_544  1
    order_0_4  connected_order_arc_563  -1
    order_0_4  connected_order_arc_565  -1
    order_0_4  connected_order_arc_567  -1
    order_0_4  connected_order_arc_569  -1
    order_0_4  connected_order_arc_571  -1
    order_0_4  connected_order_arc_573  -1
    order_0_4  connected_order_arc_575  -1
    order_0_4  connected_order_arc_577  -1
    order_0_4  connected_order_arc_579  -1
    order_0_4  connected_order_arc_581  -1
    order_0_4  connected_order_arc_583  -1
    order_0_4  connected_order_arc_592  1
    order_0_4  connected_order_arc_615  1
    order_0_4  connected_order_arc_638  1
    order_0_4  connected_order_arc_661  1
    order_0_4  connected_order_arc_684  1
    order_0_4  connected_order_arc_707  1
    order_0_4  connected_order_arc_730  1
    order_0_4  connected_order_arc_753  1
    order_0_4  order_active_lb_793  1
    order_0_4  order_active_ub_794  1
    order_0_4  fixed_segment_relative_order_848  1
    visit_0_13  out_degree_798  -1
    visit_0_13  in_degree_799  -1
    visit_0_13  order_active_lb_800  -1
    visit_0_13  order_active_ub_801  -12
    visit_0_13  service_visit_def_802  -1
    order_0_13  connected_order_arc_500  1
    order_0_13  connected_order_arc_523  1
    order_0_13  connected_order_arc_546  1
    order_0_13  connected_order_arc_569  1
    order_0_13  connected_order_arc_586  -1
    order_0_13  connected_order_arc_588  -1
    order_0_13  connected_order_arc_590  -1
    order_0_13  connected_order_arc_592  -1
    order_0_13  connected_order_arc_594  -1
    order_0_13  connected_order_arc_596  -1
    order_0_13  connected_order_arc_598  -1
    order_0_13  connected_order_arc_600  -1
    order_0_13  connected_order_arc_602  -1
    order_0_13  connected_order_arc_604  -1
    order_0_13  connected_order_arc_606  -1
    order_0_13  connected_order_arc_617  1
    order_0_13  connected_order_arc_640  1
    order_0_13  connected_order_arc_663  1
    order_0_13  connected_order_arc_686  1
    order_0_13  connected_order_arc_709  1
    order_0_13  connected_order_arc_732  1
    order_0_13  connected_order_arc_755  1
    order_0_13  order_active_lb_800  1
    order_0_13  order_active_ub_801  1
    visit_0_14  out_degree_804  -1
    visit_0_14  in_degree_805  -1
    visit_0_14  order_active_lb_806  -1
    visit_0_14  order_active_ub_807  -12
    visit_0_14  service_visit_def_808  -1
    order_0_14  connected_order_arc_502  1
    order_0_14  connected_order_arc_525  1
    order_0_14  connected_order_arc_548  1
    order_0_14  connected_order_arc_571  1
    order_0_14  connected_order_arc_594  1
    order_0_14  connected_order_arc_609  -1
    order_0_14  connected_order_arc_611  -1
    order_0_14  connected_order_arc_613  -1
    order_0_14  connected_order_arc_615  -1
    order_0_14  connected_order_arc_617  -1
    order_0_14  connected_order_arc_619  -1
    order_0_14  connected_order_arc_621  -1
    order_0_14  connected_order_arc_623  -1
    order_0_14  connected_order_arc_625  -1
    order_0_14  connected_order_arc_627  -1
    order_0_14  connected_order_arc_629  -1
    order_0_14  connected_order_arc_642  1
    order_0_14  connected_order_arc_665  1
    order_0_14  connected_order_arc_688  1
    order_0_14  connected_order_arc_711  1
    order_0_14  connected_order_arc_734  1
    order_0_14  connected_order_arc_757  1
    order_0_14  order_active_lb_806  1
    order_0_14  order_active_ub_807  1
    visit_0_15  out_degree_810  -1
    visit_0_15  in_degree_811  -1
    visit_0_15  order_active_lb_812  -1
    visit_0_15  order_active_ub_813  -12
    visit_0_15  service_visit_def_814  -1
    order_0_15  connected_order_arc_504  1
    order_0_15  connected_order_arc_527  1
    order_0_15  connected_order_arc_550  1
    order_0_15  connected_order_arc_573  1
    order_0_15  connected_order_arc_596  1
    order_0_15  connected_order_arc_619  1
    order_0_15  connected_order_arc_632  -1
    order_0_15  connected_order_arc_634  -1
    order_0_15  connected_order_arc_636  -1
    order_0_15  connected_order_arc_638  -1
    order_0_15  connected_order_arc_640  -1
    order_0_15  connected_order_arc_642  -1
    order_0_15  connected_order_arc_644  -1
    order_0_15  connected_order_arc_646  -1
    order_0_15  connected_order_arc_648  -1
    order_0_15  connected_order_arc_650  -1
    order_0_15  connected_order_arc_652  -1
    order_0_15  connected_order_arc_667  1
    order_0_15  connected_order_arc_690  1
    order_0_15  connected_order_arc_713  1
    order_0_15  connected_order_arc_736  1
    order_0_15  connected_order_arc_759  1
    order_0_15  order_active_lb_812  1
    order_0_15  order_active_ub_813  1
    visit_0_16  out_degree_816  -1
    visit_0_16  in_degree_817  -1
    visit_0_16  order_active_lb_818  -1
    visit_0_16  order_active_ub_819  -12
    visit_0_16  service_visit_def_820  -1
    order_0_16  connected_order_arc_506  1
    order_0_16  connected_order_arc_529  1
    order_0_16  connected_order_arc_552  1
    order_0_16  connected_order_arc_575  1
    order_0_16  connected_order_arc_598  1
    order_0_16  connected_order_arc_621  1
    order_0_16  connected_order_arc_644  1
    order_0_16  connected_order_arc_655  -1
    order_0_16  connected_order_arc_657  -1
    order_0_16  connected_order_arc_659  -1
    order_0_16  connected_order_arc_661  -1
    order_0_16  connected_order_arc_663  -1
    order_0_16  connected_order_arc_665  -1
    order_0_16  connected_order_arc_667  -1
    order_0_16  connected_order_arc_669  -1
    order_0_16  connected_order_arc_671  -1
    order_0_16  connected_order_arc_673  -1
    order_0_16  connected_order_arc_675  -1
    order_0_16  connected_order_arc_692  1
    order_0_16  connected_order_arc_715  1
    order_0_16  connected_order_arc_738  1
    order_0_16  connected_order_arc_761  1
    order_0_16  order_active_lb_818  1
    order_0_16  order_active_ub_819  1
    visit_0_17  out_degree_822  -1
    visit_0_17  in_degree_823  -1
    visit_0_17  order_active_lb_824  -1
    visit_0_17  order_active_ub_825  -12
    visit_0_17  service_visit_def_826  -1
    order_0_17  connected_order_arc_508  1
    order_0_17  connected_order_arc_531  1
    order_0_17  connected_order_arc_554  1
    order_0_17  connected_order_arc_577  1
    order_0_17  connected_order_arc_600  1
    order_0_17  connected_order_arc_623  1
    order_0_17  connected_order_arc_646  1
    order_0_17  connected_order_arc_669  1
    order_0_17  connected_order_arc_678  -1
    order_0_17  connected_order_arc_680  -1
    order_0_17  connected_order_arc_682  -1
    order_0_17  connected_order_arc_684  -1
    order_0_17  connected_order_arc_686  -1
    order_0_17  connected_order_arc_688  -1
    order_0_17  connected_order_arc_690  -1
    order_0_17  connected_order_arc_692  -1
    order_0_17  connected_order_arc_694  -1
    order_0_17  connected_order_arc_696  -1
    order_0_17  connected_order_arc_698  -1
    order_0_17  connected_order_arc_717  1
    order_0_17  connected_order_arc_740  1
    order_0_17  connected_order_arc_763  1
    order_0_17  order_active_lb_824  1
    order_0_17  order_active_ub_825  1
    visit_0_18  out_degree_828  -1
    visit_0_18  in_degree_829  -1
    visit_0_18  order_active_lb_830  -1
    visit_0_18  order_active_ub_831  -12
    visit_0_18  service_visit_def_832  -1
    order_0_18  connected_order_arc_510  1
    order_0_18  connected_order_arc_533  1
    order_0_18  connected_order_arc_556  1
    order_0_18  connected_order_arc_579  1
    order_0_18  connected_order_arc_602  1
    order_0_18  connected_order_arc_625  1
    order_0_18  connected_order_arc_648  1
    order_0_18  connected_order_arc_671  1
    order_0_18  connected_order_arc_694  1
    order_0_18  connected_order_arc_701  -1
    order_0_18  connected_order_arc_703  -1
    order_0_18  connected_order_arc_705  -1
    order_0_18  connected_order_arc_707  -1
    order_0_18  connected_order_arc_709  -1
    order_0_18  connected_order_arc_711  -1
    order_0_18  connected_order_arc_713  -1
    order_0_18  connected_order_arc_715  -1
    order_0_18  connected_order_arc_717  -1
    order_0_18  connected_order_arc_719  -1
    order_0_18  connected_order_arc_721  -1
    order_0_18  connected_order_arc_742  1
    order_0_18  connected_order_arc_765  1
    order_0_18  order_active_lb_830  1
    order_0_18  order_active_ub_831  1
    visit_0_19  out_degree_834  -1
    visit_0_19  in_degree_835  -1
    visit_0_19  order_active_lb_836  -1
    visit_0_19  order_active_ub_837  -12
    visit_0_19  service_visit_def_838  -1
    order_0_19  connected_order_arc_512  1
    order_0_19  connected_order_arc_535  1
    order_0_19  connected_order_arc_558  1
    order_0_19  connected_order_arc_581  1
    order_0_19  connected_order_arc_604  1
    order_0_19  connected_order_arc_627  1
    order_0_19  connected_order_arc_650  1
    order_0_19  connected_order_arc_673  1
    order_0_19  connected_order_arc_696  1
    order_0_19  connected_order_arc_719  1
    order_0_19  connected_order_arc_724  -1
    order_0_19  connected_order_arc_726  -1
    order_0_19  connected_order_arc_728  -1
    order_0_19  connected_order_arc_730  -1
    order_0_19  connected_order_arc_732  -1
    order_0_19  connected_order_arc_734  -1
    order_0_19  connected_order_arc_736  -1
    order_0_19  connected_order_arc_738  -1
    order_0_19  connected_order_arc_740  -1
    order_0_19  connected_order_arc_742  -1
    order_0_19  connected_order_arc_744  -1
    order_0_19  connected_order_arc_767  1
    order_0_19  order_active_lb_836  1
    order_0_19  order_active_ub_837  1
    visit_0_20  out_degree_840  -1
    visit_0_20  in_degree_841  -1
    visit_0_20  order_active_lb_842  -1
    visit_0_20  order_active_ub_843  -12
    visit_0_20  service_visit_def_844  -1
    order_0_20  connected_order_arc_514  1
    order_0_20  connected_order_arc_537  1
    order_0_20  connected_order_arc_560  1
    order_0_20  connected_order_arc_583  1
    order_0_20  connected_order_arc_606  1
    order_0_20  connected_order_arc_629  1
    order_0_20  connected_order_arc_652  1
    order_0_20  connected_order_arc_675  1
    order_0_20  connected_order_arc_698  1
    order_0_20  connected_order_arc_721  1
    order_0_20  connected_order_arc_744  1
    order_0_20  connected_order_arc_747  -1
    order_0_20  connected_order_arc_749  -1
    order_0_20  connected_order_arc_751  -1
    order_0_20  connected_order_arc_753  -1
    order_0_20  connected_order_arc_755  -1
    order_0_20  connected_order_arc_757  -1
    order_0_20  connected_order_arc_759  -1
    order_0_20  connected_order_arc_761  -1
    order_0_20  connected_order_arc_763  -1
    order_0_20  connected_order_arc_765  -1
    order_0_20  connected_order_arc_767  -1
    order_0_20  order_active_lb_842  1
    order_0_20  order_active_ub_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_479  -20
    arc_0_0_0  depot_departure_or_bypass_768  1
    arc_0_0_0  depot_return_or_bypass_769  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_479  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_480  -20
    arc_0_0_1  depot_departure_or_bypass_768  1
    arc_0_0_1  in_degree_771  1
    arc_0_0_1  original_T_including_depot_unload_849  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_480  1
    load_0_0_1  segment_load_conservation_774  -1
    load_0_0_1  segment_prefix_lb_775  1
    load_0_0_1  segment_prefix_ub_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_481  -20
    arc_0_0_2  depot_departure_or_bypass_768  1
    arc_0_0_2  in_degree_778  1
    arc_0_0_2  original_T_including_depot_unload_849  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_481  1
    load_0_0_2  segment_load_conservation_781  -1
    load_0_0_2  segment_prefix_lb_782  1
    load_0_0_2  segment_prefix_ub_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_482  -20
    arc_0_0_3  depot_departure_or_bypass_768  1
    arc_0_0_3  in_degree_785  1
    arc_0_0_3  original_T_including_depot_unload_849  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_482  1
    load_0_0_3  segment_load_conservation_788  -1
    load_0_0_3  segment_prefix_lb_789  1
    load_0_0_3  segment_prefix_ub_790  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_483  -20
    arc_0_0_4  depot_departure_or_bypass_768  1
    arc_0_0_4  in_degree_792  1
    arc_0_0_4  original_T_including_depot_unload_849  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_483  1
    load_0_0_4  segment_load_conservation_795  -1
    load_0_0_4  segment_prefix_lb_796  1
    load_0_0_4  segment_prefix_ub_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_484  -20
    arc_0_0_13  depot_departure_or_bypass_768  1
    arc_0_0_13  in_degree_799  1
    arc_0_0_13  original_T_including_depot_unload_849  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_484  1
    load_0_0_13  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_485  -20
    arc_0_0_14  depot_departure_or_bypass_768  1
    arc_0_0_14  in_degree_805  1
    arc_0_0_14  original_T_including_depot_unload_849  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_485  1
    load_0_0_14  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_486  -20
    arc_0_0_15  depot_departure_or_bypass_768  1
    arc_0_0_15  in_degree_811  1
    arc_0_0_15  original_T_including_depot_unload_849  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_486  1
    load_0_0_15  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_487  -20
    arc_0_0_16  depot_departure_or_bypass_768  1
    arc_0_0_16  in_degree_817  1
    arc_0_0_16  original_T_including_depot_unload_849  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_487  1
    load_0_0_16  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_488  -20
    arc_0_0_17  depot_departure_or_bypass_768  1
    arc_0_0_17  in_degree_823  1
    arc_0_0_17  original_T_including_depot_unload_849  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_488  1
    load_0_0_17  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_489  -20
    arc_0_0_18  depot_departure_or_bypass_768  1
    arc_0_0_18  in_degree_829  1
    arc_0_0_18  original_T_including_depot_unload_849  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_489  1
    load_0_0_18  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_490  -20
    arc_0_0_19  depot_departure_or_bypass_768  1
    arc_0_0_19  in_degree_835  1
    arc_0_0_19  original_T_including_depot_unload_849  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_490  1
    load_0_0_19  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_491  -20
    arc_0_0_20  depot_departure_or_bypass_768  1
    arc_0_0_20  in_degree_841  1
    arc_0_0_20  original_T_including_depot_unload_849  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_491  1
    load_0_0_20  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_492  -20
    arc_0_1_0  depot_return_or_bypass_769  1
    arc_0_1_0  out_degree_770  1
    arc_0_1_0  original_T_including_depot_unload_849  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_492  1
    load_0_1_0  segment_load_conservation_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_493  -20
    arc_0_1_2  connected_order_arc_494  -13
    arc_0_1_2  out_degree_770  1
    arc_0_1_2  in_degree_778  1
    arc_0_1_2  original_T_including_depot_unload_849  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_493  1
    load_0_1_2  segment_load_conservation_774  1
    load_0_1_2  segment_load_conservation_781  -1
    load_0_1_2  segment_prefix_lb_782  1
    load_0_1_2  segment_prefix_ub_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_495  -20
    arc_0_1_3  connected_order_arc_496  -13
    arc_0_1_3  out_degree_770  1
    arc_0_1_3  in_degree_785  1
    arc_0_1_3  original_T_including_depot_unload_849  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_495  1
    load_0_1_3  segment_load_conservation_774  1
    load_0_1_3  segment_load_conservation_788  -1
    load_0_1_3  segment_prefix_lb_789  1
    load_0_1_3  segment_prefix_ub_790  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_497  -20
    arc_0_1_4  connected_order_arc_498  -13
    arc_0_1_4  out_degree_770  1
    arc_0_1_4  in_degree_792  1
    arc_0_1_4  original_T_including_depot_unload_849  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_497  1
    load_0_1_4  segment_load_conservation_774  1
    load_0_1_4  segment_load_conservation_795  -1
    load_0_1_4  segment_prefix_lb_796  1
    load_0_1_4  segment_prefix_ub_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_499  -20
    arc_0_1_13  connected_order_arc_500  -13
    arc_0_1_13  out_degree_770  1
    arc_0_1_13  in_degree_799  1
    arc_0_1_13  original_T_including_depot_unload_849  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_499  1
    load_0_1_13  segment_load_conservation_774  1
    load_0_1_13  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_501  -20
    arc_0_1_14  connected_order_arc_502  -13
    arc_0_1_14  out_degree_770  1
    arc_0_1_14  in_degree_805  1
    arc_0_1_14  original_T_including_depot_unload_849  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_501  1
    load_0_1_14  segment_load_conservation_774  1
    load_0_1_14  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_503  -20
    arc_0_1_15  connected_order_arc_504  -13
    arc_0_1_15  out_degree_770  1
    arc_0_1_15  in_degree_811  1
    arc_0_1_15  original_T_including_depot_unload_849  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_503  1
    load_0_1_15  segment_load_conservation_774  1
    load_0_1_15  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_505  -20
    arc_0_1_16  connected_order_arc_506  -13
    arc_0_1_16  out_degree_770  1
    arc_0_1_16  in_degree_817  1
    arc_0_1_16  original_T_including_depot_unload_849  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_505  1
    load_0_1_16  segment_load_conservation_774  1
    load_0_1_16  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_507  -20
    arc_0_1_17  connected_order_arc_508  -13
    arc_0_1_17  out_degree_770  1
    arc_0_1_17  in_degree_823  1
    arc_0_1_17  original_T_including_depot_unload_849  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_507  1
    load_0_1_17  segment_load_conservation_774  1
    load_0_1_17  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_509  -20
    arc_0_1_18  connected_order_arc_510  -13
    arc_0_1_18  out_degree_770  1
    arc_0_1_18  in_degree_829  1
    arc_0_1_18  original_T_including_depot_unload_849  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_509  1
    load_0_1_18  segment_load_conservation_774  1
    load_0_1_18  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_511  -20
    arc_0_1_19  connected_order_arc_512  -13
    arc_0_1_19  out_degree_770  1
    arc_0_1_19  in_degree_835  1
    arc_0_1_19  original_T_including_depot_unload_849  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_511  1
    load_0_1_19  segment_load_conservation_774  1
    load_0_1_19  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_513  -20
    arc_0_1_20  connected_order_arc_514  -13
    arc_0_1_20  out_degree_770  1
    arc_0_1_20  in_degree_841  1
    arc_0_1_20  original_T_including_depot_unload_849  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_513  1
    load_0_1_20  segment_load_conservation_774  1
    load_0_1_20  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_515  -20
    arc_0_2_0  depot_return_or_bypass_769  1
    arc_0_2_0  out_degree_777  1
    arc_0_2_0  original_T_including_depot_unload_849  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_515  1
    load_0_2_0  segment_load_conservation_781  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_516  -20
    arc_0_2_1  connected_order_arc_517  -13
    arc_0_2_1  in_degree_771  1
    arc_0_2_1  out_degree_777  1
    arc_0_2_1  original_T_including_depot_unload_849  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_516  1
    load_0_2_1  segment_load_conservation_774  -1
    load_0_2_1  segment_prefix_lb_775  1
    load_0_2_1  segment_prefix_ub_776  1
    load_0_2_1  segment_load_conservation_781  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_518  -20
    arc_0_2_3  connected_order_arc_519  -13
    arc_0_2_3  out_degree_777  1
    arc_0_2_3  in_degree_785  1
    arc_0_2_3  original_T_including_depot_unload_849  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_518  1
    load_0_2_3  segment_load_conservation_781  1
    load_0_2_3  segment_load_conservation_788  -1
    load_0_2_3  segment_prefix_lb_789  1
    load_0_2_3  segment_prefix_ub_790  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_520  -20
    arc_0_2_4  connected_order_arc_521  -13
    arc_0_2_4  out_degree_777  1
    arc_0_2_4  in_degree_792  1
    arc_0_2_4  original_T_including_depot_unload_849  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_520  1
    load_0_2_4  segment_load_conservation_781  1
    load_0_2_4  segment_load_conservation_795  -1
    load_0_2_4  segment_prefix_lb_796  1
    load_0_2_4  segment_prefix_ub_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_522  -20
    arc_0_2_13  connected_order_arc_523  -13
    arc_0_2_13  out_degree_777  1
    arc_0_2_13  in_degree_799  1
    arc_0_2_13  original_T_including_depot_unload_849  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_522  1
    load_0_2_13  segment_load_conservation_781  1
    load_0_2_13  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_524  -20
    arc_0_2_14  connected_order_arc_525  -13
    arc_0_2_14  out_degree_777  1
    arc_0_2_14  in_degree_805  1
    arc_0_2_14  original_T_including_depot_unload_849  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_524  1
    load_0_2_14  segment_load_conservation_781  1
    load_0_2_14  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_526  -20
    arc_0_2_15  connected_order_arc_527  -13
    arc_0_2_15  out_degree_777  1
    arc_0_2_15  in_degree_811  1
    arc_0_2_15  original_T_including_depot_unload_849  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_526  1
    load_0_2_15  segment_load_conservation_781  1
    load_0_2_15  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_528  -20
    arc_0_2_16  connected_order_arc_529  -13
    arc_0_2_16  out_degree_777  1
    arc_0_2_16  in_degree_817  1
    arc_0_2_16  original_T_including_depot_unload_849  5.9934197761098949e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_528  1
    load_0_2_16  segment_load_conservation_781  1
    load_0_2_16  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_530  -20
    arc_0_2_17  connected_order_arc_531  -13
    arc_0_2_17  out_degree_777  1
    arc_0_2_17  in_degree_823  1
    arc_0_2_17  original_T_including_depot_unload_849  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_530  1
    load_0_2_17  segment_load_conservation_781  1
    load_0_2_17  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_532  -20
    arc_0_2_18  connected_order_arc_533  -13
    arc_0_2_18  out_degree_777  1
    arc_0_2_18  in_degree_829  1
    arc_0_2_18  original_T_including_depot_unload_849  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_532  1
    load_0_2_18  segment_load_conservation_781  1
    load_0_2_18  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_534  -20
    arc_0_2_19  connected_order_arc_535  -13
    arc_0_2_19  out_degree_777  1
    arc_0_2_19  in_degree_835  1
    arc_0_2_19  original_T_including_depot_unload_849  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_534  1
    load_0_2_19  segment_load_conservation_781  1
    load_0_2_19  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_536  -20
    arc_0_2_20  connected_order_arc_537  -13
    arc_0_2_20  out_degree_777  1
    arc_0_2_20  in_degree_841  1
    arc_0_2_20  original_T_including_depot_unload_849  7.7772825846942942e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_536  1
    load_0_2_20  segment_load_conservation_781  1
    load_0_2_20  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_538  -20
    arc_0_3_0  depot_return_or_bypass_769  1
    arc_0_3_0  out_degree_784  1
    arc_0_3_0  original_T_including_depot_unload_849  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_538  1
    load_0_3_0  segment_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_539  -20
    arc_0_3_1  connected_order_arc_540  -13
    arc_0_3_1  in_degree_771  1
    arc_0_3_1  out_degree_784  1
    arc_0_3_1  original_T_including_depot_unload_849  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_539  1
    load_0_3_1  segment_load_conservation_774  -1
    load_0_3_1  segment_prefix_lb_775  1
    load_0_3_1  segment_prefix_ub_776  1
    load_0_3_1  segment_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_541  -20
    arc_0_3_2  connected_order_arc_542  -13
    arc_0_3_2  in_degree_778  1
    arc_0_3_2  out_degree_784  1
    arc_0_3_2  original_T_including_depot_unload_849  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_541  1
    load_0_3_2  segment_load_conservation_781  -1
    load_0_3_2  segment_prefix_lb_782  1
    load_0_3_2  segment_prefix_ub_783  1
    load_0_3_2  segment_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_543  -20
    arc_0_3_4  connected_order_arc_544  -13
    arc_0_3_4  out_degree_784  1
    arc_0_3_4  in_degree_792  1
    arc_0_3_4  original_T_including_depot_unload_849  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_543  1
    load_0_3_4  segment_load_conservation_788  1
    load_0_3_4  segment_load_conservation_795  -1
    load_0_3_4  segment_prefix_lb_796  1
    load_0_3_4  segment_prefix_ub_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_545  -20
    arc_0_3_13  connected_order_arc_546  -13
    arc_0_3_13  out_degree_784  1
    arc_0_3_13  in_degree_799  1
    arc_0_3_13  original_T_including_depot_unload_849  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_545  1
    load_0_3_13  segment_load_conservation_788  1
    load_0_3_13  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_547  -20
    arc_0_3_14  connected_order_arc_548  -13
    arc_0_3_14  out_degree_784  1
    arc_0_3_14  in_degree_805  1
    arc_0_3_14  original_T_including_depot_unload_849  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_547  1
    load_0_3_14  segment_load_conservation_788  1
    load_0_3_14  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_549  -20
    arc_0_3_15  connected_order_arc_550  -13
    arc_0_3_15  out_degree_784  1
    arc_0_3_15  in_degree_811  1
    arc_0_3_15  original_T_including_depot_unload_849  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_549  1
    load_0_3_15  segment_load_conservation_788  1
    load_0_3_15  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_551  -20
    arc_0_3_16  connected_order_arc_552  -13
    arc_0_3_16  out_degree_784  1
    arc_0_3_16  in_degree_817  1
    arc_0_3_16  original_T_including_depot_unload_849  750.067997850428
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_551  1
    load_0_3_16  segment_load_conservation_788  1
    load_0_3_16  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_553  -20
    arc_0_3_17  connected_order_arc_554  -13
    arc_0_3_17  out_degree_784  1
    arc_0_3_17  in_degree_823  1
    arc_0_3_17  original_T_including_depot_unload_849  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_553  1
    load_0_3_17  segment_load_conservation_788  1
    load_0_3_17  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_555  -20
    arc_0_3_18  connected_order_arc_556  -13
    arc_0_3_18  out_degree_784  1
    arc_0_3_18  in_degree_829  1
    arc_0_3_18  original_T_including_depot_unload_849  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_555  1
    load_0_3_18  segment_load_conservation_788  1
    load_0_3_18  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_557  -20
    arc_0_3_19  connected_order_arc_558  -13
    arc_0_3_19  out_degree_784  1
    arc_0_3_19  in_degree_835  1
    arc_0_3_19  original_T_including_depot_unload_849  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_557  1
    load_0_3_19  segment_load_conservation_788  1
    load_0_3_19  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_559  -20
    arc_0_3_20  connected_order_arc_560  -13
    arc_0_3_20  out_degree_784  1
    arc_0_3_20  in_degree_841  1
    arc_0_3_20  original_T_including_depot_unload_849  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_559  1
    load_0_3_20  segment_load_conservation_788  1
    load_0_3_20  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_561  -20
    arc_0_4_0  depot_return_or_bypass_769  1
    arc_0_4_0  out_degree_791  1
    arc_0_4_0  original_T_including_depot_unload_849  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_561  1
    load_0_4_0  segment_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_562  -20
    arc_0_4_1  connected_order_arc_563  -13
    arc_0_4_1  in_degree_771  1
    arc_0_4_1  out_degree_791  1
    arc_0_4_1  original_T_including_depot_unload_849  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_562  1
    load_0_4_1  segment_load_conservation_774  -1
    load_0_4_1  segment_prefix_lb_775  1
    load_0_4_1  segment_prefix_ub_776  1
    load_0_4_1  segment_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_564  -20
    arc_0_4_2  connected_order_arc_565  -13
    arc_0_4_2  in_degree_778  1
    arc_0_4_2  out_degree_791  1
    arc_0_4_2  original_T_including_depot_unload_849  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_564  1
    load_0_4_2  segment_load_conservation_781  -1
    load_0_4_2  segment_prefix_lb_782  1
    load_0_4_2  segment_prefix_ub_783  1
    load_0_4_2  segment_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_566  -20
    arc_0_4_3  connected_order_arc_567  -13
    arc_0_4_3  in_degree_785  1
    arc_0_4_3  out_degree_791  1
    arc_0_4_3  original_T_including_depot_unload_849  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_566  1
    load_0_4_3  segment_load_conservation_788  -1
    load_0_4_3  segment_prefix_lb_789  1
    load_0_4_3  segment_prefix_ub_790  1
    load_0_4_3  segment_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_568  -20
    arc_0_4_13  connected_order_arc_569  -13
    arc_0_4_13  out_degree_791  1
    arc_0_4_13  in_degree_799  1
    arc_0_4_13  original_T_including_depot_unload_849  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_568  1
    load_0_4_13  segment_load_conservation_795  1
    load_0_4_13  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_570  -20
    arc_0_4_14  connected_order_arc_571  -13
    arc_0_4_14  out_degree_791  1
    arc_0_4_14  in_degree_805  1
    arc_0_4_14  original_T_including_depot_unload_849  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_570  1
    load_0_4_14  segment_load_conservation_795  1
    load_0_4_14  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_572  -20
    arc_0_4_15  connected_order_arc_573  -13
    arc_0_4_15  out_degree_791  1
    arc_0_4_15  in_degree_811  1
    arc_0_4_15  original_T_including_depot_unload_849  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_572  1
    load_0_4_15  segment_load_conservation_795  1
    load_0_4_15  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_574  -20
    arc_0_4_16  connected_order_arc_575  -13
    arc_0_4_16  out_degree_791  1
    arc_0_4_16  in_degree_817  1
    arc_0_4_16  original_T_including_depot_unload_849  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_574  1
    load_0_4_16  segment_load_conservation_795  1
    load_0_4_16  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_576  -20
    arc_0_4_17  connected_order_arc_577  -13
    arc_0_4_17  out_degree_791  1
    arc_0_4_17  in_degree_823  1
    arc_0_4_17  original_T_including_depot_unload_849  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_576  1
    load_0_4_17  segment_load_conservation_795  1
    load_0_4_17  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_578  -20
    arc_0_4_18  connected_order_arc_579  -13
    arc_0_4_18  out_degree_791  1
    arc_0_4_18  in_degree_829  1
    arc_0_4_18  original_T_including_depot_unload_849  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_578  1
    load_0_4_18  segment_load_conservation_795  1
    load_0_4_18  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_580  -20
    arc_0_4_19  connected_order_arc_581  -13
    arc_0_4_19  out_degree_791  1
    arc_0_4_19  in_degree_835  1
    arc_0_4_19  original_T_including_depot_unload_849  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_580  1
    load_0_4_19  segment_load_conservation_795  1
    load_0_4_19  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_582  -20
    arc_0_4_20  connected_order_arc_583  -13
    arc_0_4_20  out_degree_791  1
    arc_0_4_20  in_degree_841  1
    arc_0_4_20  original_T_including_depot_unload_849  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_582  1
    load_0_4_20  segment_load_conservation_795  1
    load_0_4_20  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_584  -20
    arc_0_13_0  depot_return_or_bypass_769  1
    arc_0_13_0  out_degree_798  1
    arc_0_13_0  original_T_including_depot_unload_849  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_584  1
    load_0_13_0  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_585  -20
    arc_0_13_1  connected_order_arc_586  -13
    arc_0_13_1  in_degree_771  1
    arc_0_13_1  out_degree_798  1
    arc_0_13_1  original_T_including_depot_unload_849  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_585  1
    load_0_13_1  segment_load_conservation_774  -1
    load_0_13_1  segment_prefix_lb_775  1
    load_0_13_1  segment_prefix_ub_776  1
    load_0_13_1  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_587  -20
    arc_0_13_2  connected_order_arc_588  -13
    arc_0_13_2  in_degree_778  1
    arc_0_13_2  out_degree_798  1
    arc_0_13_2  original_T_including_depot_unload_849  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_587  1
    load_0_13_2  segment_load_conservation_781  -1
    load_0_13_2  segment_prefix_lb_782  1
    load_0_13_2  segment_prefix_ub_783  1
    load_0_13_2  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_589  -20
    arc_0_13_3  connected_order_arc_590  -13
    arc_0_13_3  in_degree_785  1
    arc_0_13_3  out_degree_798  1
    arc_0_13_3  original_T_including_depot_unload_849  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_589  1
    load_0_13_3  segment_load_conservation_788  -1
    load_0_13_3  segment_prefix_lb_789  1
    load_0_13_3  segment_prefix_ub_790  1
    load_0_13_3  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_591  -20
    arc_0_13_4  connected_order_arc_592  -13
    arc_0_13_4  in_degree_792  1
    arc_0_13_4  out_degree_798  1
    arc_0_13_4  original_T_including_depot_unload_849  7.5688558078083690e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_591  1
    load_0_13_4  segment_load_conservation_795  -1
    load_0_13_4  segment_prefix_lb_796  1
    load_0_13_4  segment_prefix_ub_797  1
    load_0_13_4  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_593  -20
    arc_0_13_14  connected_order_arc_594  -13
    arc_0_13_14  out_degree_798  1
    arc_0_13_14  in_degree_805  1
    arc_0_13_14  original_T_including_depot_unload_849  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_593  1
    load_0_13_14  free_load_conservation_803  1
    load_0_13_14  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_595  -20
    arc_0_13_15  connected_order_arc_596  -13
    arc_0_13_15  out_degree_798  1
    arc_0_13_15  in_degree_811  1
    arc_0_13_15  original_T_including_depot_unload_849  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_595  1
    load_0_13_15  free_load_conservation_803  1
    load_0_13_15  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_597  -20
    arc_0_13_16  connected_order_arc_598  -13
    arc_0_13_16  out_degree_798  1
    arc_0_13_16  in_degree_817  1
    arc_0_13_16  original_T_including_depot_unload_849  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_597  1
    load_0_13_16  free_load_conservation_803  1
    load_0_13_16  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_599  -20
    arc_0_13_17  connected_order_arc_600  -13
    arc_0_13_17  out_degree_798  1
    arc_0_13_17  in_degree_823  1
    arc_0_13_17  original_T_including_depot_unload_849  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_599  1
    load_0_13_17  free_load_conservation_803  1
    load_0_13_17  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_601  -20
    arc_0_13_18  connected_order_arc_602  -13
    arc_0_13_18  out_degree_798  1
    arc_0_13_18  in_degree_829  1
    arc_0_13_18  original_T_including_depot_unload_849  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_601  1
    load_0_13_18  free_load_conservation_803  1
    load_0_13_18  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_603  -20
    arc_0_13_19  connected_order_arc_604  -13
    arc_0_13_19  out_degree_798  1
    arc_0_13_19  in_degree_835  1
    arc_0_13_19  original_T_including_depot_unload_849  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_603  1
    load_0_13_19  free_load_conservation_803  1
    load_0_13_19  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_20  arc_capacity_605  -20
    arc_0_13_20  connected_order_arc_606  -13
    arc_0_13_20  out_degree_798  1
    arc_0_13_20  in_degree_841  1
    arc_0_13_20  original_T_including_depot_unload_849  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_20  arc_capacity_605  1
    load_0_13_20  free_load_conservation_803  1
    load_0_13_20  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_607  -20
    arc_0_14_0  depot_return_or_bypass_769  1
    arc_0_14_0  out_degree_804  1
    arc_0_14_0  original_T_including_depot_unload_849  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_607  1
    load_0_14_0  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_608  -20
    arc_0_14_1  connected_order_arc_609  -13
    arc_0_14_1  in_degree_771  1
    arc_0_14_1  out_degree_804  1
    arc_0_14_1  original_T_including_depot_unload_849  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_608  1
    load_0_14_1  segment_load_conservation_774  -1
    load_0_14_1  segment_prefix_lb_775  1
    load_0_14_1  segment_prefix_ub_776  1
    load_0_14_1  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_610  -20
    arc_0_14_2  connected_order_arc_611  -13
    arc_0_14_2  in_degree_778  1
    arc_0_14_2  out_degree_804  1
    arc_0_14_2  original_T_including_depot_unload_849  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_610  1
    load_0_14_2  segment_load_conservation_781  -1
    load_0_14_2  segment_prefix_lb_782  1
    load_0_14_2  segment_prefix_ub_783  1
    load_0_14_2  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_612  -20
    arc_0_14_3  connected_order_arc_613  -13
    arc_0_14_3  in_degree_785  1
    arc_0_14_3  out_degree_804  1
    arc_0_14_3  original_T_including_depot_unload_849  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_612  1
    load_0_14_3  segment_load_conservation_788  -1
    load_0_14_3  segment_prefix_lb_789  1
    load_0_14_3  segment_prefix_ub_790  1
    load_0_14_3  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_614  -20
    arc_0_14_4  connected_order_arc_615  -13
    arc_0_14_4  in_degree_792  1
    arc_0_14_4  out_degree_804  1
    arc_0_14_4  original_T_including_depot_unload_849  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_614  1
    load_0_14_4  segment_load_conservation_795  -1
    load_0_14_4  segment_prefix_lb_796  1
    load_0_14_4  segment_prefix_ub_797  1
    load_0_14_4  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_616  -20
    arc_0_14_13  connected_order_arc_617  -13
    arc_0_14_13  in_degree_799  1
    arc_0_14_13  out_degree_804  1
    arc_0_14_13  original_T_including_depot_unload_849  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_616  1
    load_0_14_13  free_load_conservation_803  -1
    load_0_14_13  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_618  -20
    arc_0_14_15  connected_order_arc_619  -13
    arc_0_14_15  out_degree_804  1
    arc_0_14_15  in_degree_811  1
    arc_0_14_15  original_T_including_depot_unload_849  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_618  1
    load_0_14_15  free_load_conservation_809  1
    load_0_14_15  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_620  -20
    arc_0_14_16  connected_order_arc_621  -13
    arc_0_14_16  out_degree_804  1
    arc_0_14_16  in_degree_817  1
    arc_0_14_16  original_T_including_depot_unload_849  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_620  1
    load_0_14_16  free_load_conservation_809  1
    load_0_14_16  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_622  -20
    arc_0_14_17  connected_order_arc_623  -13
    arc_0_14_17  out_degree_804  1
    arc_0_14_17  in_degree_823  1
    arc_0_14_17  original_T_including_depot_unload_849  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_622  1
    load_0_14_17  free_load_conservation_809  1
    load_0_14_17  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_624  -20
    arc_0_14_18  connected_order_arc_625  -13
    arc_0_14_18  out_degree_804  1
    arc_0_14_18  in_degree_829  1
    arc_0_14_18  original_T_including_depot_unload_849  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_624  1
    load_0_14_18  free_load_conservation_809  1
    load_0_14_18  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_626  -20
    arc_0_14_19  connected_order_arc_627  -13
    arc_0_14_19  out_degree_804  1
    arc_0_14_19  in_degree_835  1
    arc_0_14_19  original_T_including_depot_unload_849  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_626  1
    load_0_14_19  free_load_conservation_809  1
    load_0_14_19  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_628  -20
    arc_0_14_20  connected_order_arc_629  -13
    arc_0_14_20  out_degree_804  1
    arc_0_14_20  in_degree_841  1
    arc_0_14_20  original_T_including_depot_unload_849  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_628  1
    load_0_14_20  free_load_conservation_809  1
    load_0_14_20  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_630  -20
    arc_0_15_0  depot_return_or_bypass_769  1
    arc_0_15_0  out_degree_810  1
    arc_0_15_0  original_T_including_depot_unload_849  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_630  1
    load_0_15_0  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_631  -20
    arc_0_15_1  connected_order_arc_632  -13
    arc_0_15_1  in_degree_771  1
    arc_0_15_1  out_degree_810  1
    arc_0_15_1  original_T_including_depot_unload_849  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_631  1
    load_0_15_1  segment_load_conservation_774  -1
    load_0_15_1  segment_prefix_lb_775  1
    load_0_15_1  segment_prefix_ub_776  1
    load_0_15_1  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_633  -20
    arc_0_15_2  connected_order_arc_634  -13
    arc_0_15_2  in_degree_778  1
    arc_0_15_2  out_degree_810  1
    arc_0_15_2  original_T_including_depot_unload_849  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_633  1
    load_0_15_2  segment_load_conservation_781  -1
    load_0_15_2  segment_prefix_lb_782  1
    load_0_15_2  segment_prefix_ub_783  1
    load_0_15_2  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_635  -20
    arc_0_15_3  connected_order_arc_636  -13
    arc_0_15_3  in_degree_785  1
    arc_0_15_3  out_degree_810  1
    arc_0_15_3  original_T_including_depot_unload_849  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_635  1
    load_0_15_3  segment_load_conservation_788  -1
    load_0_15_3  segment_prefix_lb_789  1
    load_0_15_3  segment_prefix_ub_790  1
    load_0_15_3  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_637  -20
    arc_0_15_4  connected_order_arc_638  -13
    arc_0_15_4  in_degree_792  1
    arc_0_15_4  out_degree_810  1
    arc_0_15_4  original_T_including_depot_unload_849  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_637  1
    load_0_15_4  segment_load_conservation_795  -1
    load_0_15_4  segment_prefix_lb_796  1
    load_0_15_4  segment_prefix_ub_797  1
    load_0_15_4  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_639  -20
    arc_0_15_13  connected_order_arc_640  -13
    arc_0_15_13  in_degree_799  1
    arc_0_15_13  out_degree_810  1
    arc_0_15_13  original_T_including_depot_unload_849  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_639  1
    load_0_15_13  free_load_conservation_803  -1
    load_0_15_13  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_641  -20
    arc_0_15_14  connected_order_arc_642  -13
    arc_0_15_14  in_degree_805  1
    arc_0_15_14  out_degree_810  1
    arc_0_15_14  original_T_including_depot_unload_849  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_641  1
    load_0_15_14  free_load_conservation_809  -1
    load_0_15_14  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_643  -20
    arc_0_15_16  connected_order_arc_644  -13
    arc_0_15_16  out_degree_810  1
    arc_0_15_16  in_degree_817  1
    arc_0_15_16  original_T_including_depot_unload_849  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_643  1
    load_0_15_16  free_load_conservation_815  1
    load_0_15_16  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_645  -20
    arc_0_15_17  connected_order_arc_646  -13
    arc_0_15_17  out_degree_810  1
    arc_0_15_17  in_degree_823  1
    arc_0_15_17  original_T_including_depot_unload_849  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_645  1
    load_0_15_17  free_load_conservation_815  1
    load_0_15_17  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_647  -20
    arc_0_15_18  connected_order_arc_648  -13
    arc_0_15_18  out_degree_810  1
    arc_0_15_18  in_degree_829  1
    arc_0_15_18  original_T_including_depot_unload_849  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_647  1
    load_0_15_18  free_load_conservation_815  1
    load_0_15_18  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_649  -20
    arc_0_15_19  connected_order_arc_650  -13
    arc_0_15_19  out_degree_810  1
    arc_0_15_19  in_degree_835  1
    arc_0_15_19  original_T_including_depot_unload_849  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_649  1
    load_0_15_19  free_load_conservation_815  1
    load_0_15_19  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_651  -20
    arc_0_15_20  connected_order_arc_652  -13
    arc_0_15_20  out_degree_810  1
    arc_0_15_20  in_degree_841  1
    arc_0_15_20  original_T_including_depot_unload_849  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_651  1
    load_0_15_20  free_load_conservation_815  1
    load_0_15_20  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_653  -20
    arc_0_16_0  depot_return_or_bypass_769  1
    arc_0_16_0  out_degree_816  1
    arc_0_16_0  original_T_including_depot_unload_849  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_653  1
    load_0_16_0  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_654  -20
    arc_0_16_1  connected_order_arc_655  -13
    arc_0_16_1  in_degree_771  1
    arc_0_16_1  out_degree_816  1
    arc_0_16_1  original_T_including_depot_unload_849  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_654  1
    load_0_16_1  segment_load_conservation_774  -1
    load_0_16_1  segment_prefix_lb_775  1
    load_0_16_1  segment_prefix_ub_776  1
    load_0_16_1  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_656  -20
    arc_0_16_2  connected_order_arc_657  -13
    arc_0_16_2  in_degree_778  1
    arc_0_16_2  out_degree_816  1
    arc_0_16_2  original_T_including_depot_unload_849  5.9934197761098949e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_656  1
    load_0_16_2  segment_load_conservation_781  -1
    load_0_16_2  segment_prefix_lb_782  1
    load_0_16_2  segment_prefix_ub_783  1
    load_0_16_2  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_658  -20
    arc_0_16_3  connected_order_arc_659  -13
    arc_0_16_3  in_degree_785  1
    arc_0_16_3  out_degree_816  1
    arc_0_16_3  original_T_including_depot_unload_849  750.067997850428
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_658  1
    load_0_16_3  segment_load_conservation_788  -1
    load_0_16_3  segment_prefix_lb_789  1
    load_0_16_3  segment_prefix_ub_790  1
    load_0_16_3  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_660  -20
    arc_0_16_4  connected_order_arc_661  -13
    arc_0_16_4  in_degree_792  1
    arc_0_16_4  out_degree_816  1
    arc_0_16_4  original_T_including_depot_unload_849  8.8588784481112123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_660  1
    load_0_16_4  segment_load_conservation_795  -1
    load_0_16_4  segment_prefix_lb_796  1
    load_0_16_4  segment_prefix_ub_797  1
    load_0_16_4  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_662  -20
    arc_0_16_13  connected_order_arc_663  -13
    arc_0_16_13  in_degree_799  1
    arc_0_16_13  out_degree_816  1
    arc_0_16_13  original_T_including_depot_unload_849  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_662  1
    load_0_16_13  free_load_conservation_803  -1
    load_0_16_13  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_664  -20
    arc_0_16_14  connected_order_arc_665  -13
    arc_0_16_14  in_degree_805  1
    arc_0_16_14  out_degree_816  1
    arc_0_16_14  original_T_including_depot_unload_849  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_664  1
    load_0_16_14  free_load_conservation_809  -1
    load_0_16_14  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_666  -20
    arc_0_16_15  connected_order_arc_667  -13
    arc_0_16_15  in_degree_811  1
    arc_0_16_15  out_degree_816  1
    arc_0_16_15  original_T_including_depot_unload_849  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_666  1
    load_0_16_15  free_load_conservation_815  -1
    load_0_16_15  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_668  -20
    arc_0_16_17  connected_order_arc_669  -13
    arc_0_16_17  out_degree_816  1
    arc_0_16_17  in_degree_823  1
    arc_0_16_17  original_T_including_depot_unload_849  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_668  1
    load_0_16_17  free_load_conservation_821  1
    load_0_16_17  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_670  -20
    arc_0_16_18  connected_order_arc_671  -13
    arc_0_16_18  out_degree_816  1
    arc_0_16_18  in_degree_829  1
    arc_0_16_18  original_T_including_depot_unload_849  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_670  1
    load_0_16_18  free_load_conservation_821  1
    load_0_16_18  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_672  -20
    arc_0_16_19  connected_order_arc_673  -13
    arc_0_16_19  out_degree_816  1
    arc_0_16_19  in_degree_835  1
    arc_0_16_19  original_T_including_depot_unload_849  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_672  1
    load_0_16_19  free_load_conservation_821  1
    load_0_16_19  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_674  -20
    arc_0_16_20  connected_order_arc_675  -13
    arc_0_16_20  out_degree_816  1
    arc_0_16_20  in_degree_841  1
    arc_0_16_20  original_T_including_depot_unload_849  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_674  1
    load_0_16_20  free_load_conservation_821  1
    load_0_16_20  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_676  -20
    arc_0_17_0  depot_return_or_bypass_769  1
    arc_0_17_0  out_degree_822  1
    arc_0_17_0  original_T_including_depot_unload_849  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_676  1
    load_0_17_0  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_677  -20
    arc_0_17_1  connected_order_arc_678  -13
    arc_0_17_1  in_degree_771  1
    arc_0_17_1  out_degree_822  1
    arc_0_17_1  original_T_including_depot_unload_849  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_677  1
    load_0_17_1  segment_load_conservation_774  -1
    load_0_17_1  segment_prefix_lb_775  1
    load_0_17_1  segment_prefix_ub_776  1
    load_0_17_1  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_679  -20
    arc_0_17_2  connected_order_arc_680  -13
    arc_0_17_2  in_degree_778  1
    arc_0_17_2  out_degree_822  1
    arc_0_17_2  original_T_including_depot_unload_849  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_679  1
    load_0_17_2  segment_load_conservation_781  -1
    load_0_17_2  segment_prefix_lb_782  1
    load_0_17_2  segment_prefix_ub_783  1
    load_0_17_2  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_681  -20
    arc_0_17_3  connected_order_arc_682  -13
    arc_0_17_3  in_degree_785  1
    arc_0_17_3  out_degree_822  1
    arc_0_17_3  original_T_including_depot_unload_849  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_681  1
    load_0_17_3  segment_load_conservation_788  -1
    load_0_17_3  segment_prefix_lb_789  1
    load_0_17_3  segment_prefix_ub_790  1
    load_0_17_3  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_683  -20
    arc_0_17_4  connected_order_arc_684  -13
    arc_0_17_4  in_degree_792  1
    arc_0_17_4  out_degree_822  1
    arc_0_17_4  original_T_including_depot_unload_849  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_683  1
    load_0_17_4  segment_load_conservation_795  -1
    load_0_17_4  segment_prefix_lb_796  1
    load_0_17_4  segment_prefix_ub_797  1
    load_0_17_4  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_685  -20
    arc_0_17_13  connected_order_arc_686  -13
    arc_0_17_13  in_degree_799  1
    arc_0_17_13  out_degree_822  1
    arc_0_17_13  original_T_including_depot_unload_849  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_685  1
    load_0_17_13  free_load_conservation_803  -1
    load_0_17_13  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_687  -20
    arc_0_17_14  connected_order_arc_688  -13
    arc_0_17_14  in_degree_805  1
    arc_0_17_14  out_degree_822  1
    arc_0_17_14  original_T_including_depot_unload_849  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_687  1
    load_0_17_14  free_load_conservation_809  -1
    load_0_17_14  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_689  -20
    arc_0_17_15  connected_order_arc_690  -13
    arc_0_17_15  in_degree_811  1
    arc_0_17_15  out_degree_822  1
    arc_0_17_15  original_T_including_depot_unload_849  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_689  1
    load_0_17_15  free_load_conservation_815  -1
    load_0_17_15  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_691  -20
    arc_0_17_16  connected_order_arc_692  -13
    arc_0_17_16  in_degree_817  1
    arc_0_17_16  out_degree_822  1
    arc_0_17_16  original_T_including_depot_unload_849  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_691  1
    load_0_17_16  free_load_conservation_821  -1
    load_0_17_16  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_693  -20
    arc_0_17_18  connected_order_arc_694  -13
    arc_0_17_18  out_degree_822  1
    arc_0_17_18  in_degree_829  1
    arc_0_17_18  original_T_including_depot_unload_849  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_693  1
    load_0_17_18  free_load_conservation_827  1
    load_0_17_18  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_695  -20
    arc_0_17_19  connected_order_arc_696  -13
    arc_0_17_19  out_degree_822  1
    arc_0_17_19  in_degree_835  1
    arc_0_17_19  original_T_including_depot_unload_849  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_695  1
    load_0_17_19  free_load_conservation_827  1
    load_0_17_19  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_697  -20
    arc_0_17_20  connected_order_arc_698  -13
    arc_0_17_20  out_degree_822  1
    arc_0_17_20  in_degree_841  1
    arc_0_17_20  original_T_including_depot_unload_849  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_697  1
    load_0_17_20  free_load_conservation_827  1
    load_0_17_20  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_699  -20
    arc_0_18_0  depot_return_or_bypass_769  1
    arc_0_18_0  out_degree_828  1
    arc_0_18_0  original_T_including_depot_unload_849  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_699  1
    load_0_18_0  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_700  -20
    arc_0_18_1  connected_order_arc_701  -13
    arc_0_18_1  in_degree_771  1
    arc_0_18_1  out_degree_828  1
    arc_0_18_1  original_T_including_depot_unload_849  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_700  1
    load_0_18_1  segment_load_conservation_774  -1
    load_0_18_1  segment_prefix_lb_775  1
    load_0_18_1  segment_prefix_ub_776  1
    load_0_18_1  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_702  -20
    arc_0_18_2  connected_order_arc_703  -13
    arc_0_18_2  in_degree_778  1
    arc_0_18_2  out_degree_828  1
    arc_0_18_2  original_T_including_depot_unload_849  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_702  1
    load_0_18_2  segment_load_conservation_781  -1
    load_0_18_2  segment_prefix_lb_782  1
    load_0_18_2  segment_prefix_ub_783  1
    load_0_18_2  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_704  -20
    arc_0_18_3  connected_order_arc_705  -13
    arc_0_18_3  in_degree_785  1
    arc_0_18_3  out_degree_828  1
    arc_0_18_3  original_T_including_depot_unload_849  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_704  1
    load_0_18_3  segment_load_conservation_788  -1
    load_0_18_3  segment_prefix_lb_789  1
    load_0_18_3  segment_prefix_ub_790  1
    load_0_18_3  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_706  -20
    arc_0_18_4  connected_order_arc_707  -13
    arc_0_18_4  in_degree_792  1
    arc_0_18_4  out_degree_828  1
    arc_0_18_4  original_T_including_depot_unload_849  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_706  1
    load_0_18_4  segment_load_conservation_795  -1
    load_0_18_4  segment_prefix_lb_796  1
    load_0_18_4  segment_prefix_ub_797  1
    load_0_18_4  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_708  -20
    arc_0_18_13  connected_order_arc_709  -13
    arc_0_18_13  in_degree_799  1
    arc_0_18_13  out_degree_828  1
    arc_0_18_13  original_T_including_depot_unload_849  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_708  1
    load_0_18_13  free_load_conservation_803  -1
    load_0_18_13  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_710  -20
    arc_0_18_14  connected_order_arc_711  -13
    arc_0_18_14  in_degree_805  1
    arc_0_18_14  out_degree_828  1
    arc_0_18_14  original_T_including_depot_unload_849  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_710  1
    load_0_18_14  free_load_conservation_809  -1
    load_0_18_14  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_712  -20
    arc_0_18_15  connected_order_arc_713  -13
    arc_0_18_15  in_degree_811  1
    arc_0_18_15  out_degree_828  1
    arc_0_18_15  original_T_including_depot_unload_849  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_712  1
    load_0_18_15  free_load_conservation_815  -1
    load_0_18_15  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_714  -20
    arc_0_18_16  connected_order_arc_715  -13
    arc_0_18_16  in_degree_817  1
    arc_0_18_16  out_degree_828  1
    arc_0_18_16  original_T_including_depot_unload_849  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_714  1
    load_0_18_16  free_load_conservation_821  -1
    load_0_18_16  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_716  -20
    arc_0_18_17  connected_order_arc_717  -13
    arc_0_18_17  in_degree_823  1
    arc_0_18_17  out_degree_828  1
    arc_0_18_17  original_T_including_depot_unload_849  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_716  1
    load_0_18_17  free_load_conservation_827  -1
    load_0_18_17  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_718  -20
    arc_0_18_19  connected_order_arc_719  -13
    arc_0_18_19  out_degree_828  1
    arc_0_18_19  in_degree_835  1
    arc_0_18_19  original_T_including_depot_unload_849  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_718  1
    load_0_18_19  free_load_conservation_833  1
    load_0_18_19  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_720  -20
    arc_0_18_20  connected_order_arc_721  -13
    arc_0_18_20  out_degree_828  1
    arc_0_18_20  in_degree_841  1
    arc_0_18_20  original_T_including_depot_unload_849  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_720  1
    load_0_18_20  free_load_conservation_833  1
    load_0_18_20  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_722  -20
    arc_0_19_0  depot_return_or_bypass_769  1
    arc_0_19_0  out_degree_834  1
    arc_0_19_0  original_T_including_depot_unload_849  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_722  1
    load_0_19_0  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_723  -20
    arc_0_19_1  connected_order_arc_724  -13
    arc_0_19_1  in_degree_771  1
    arc_0_19_1  out_degree_834  1
    arc_0_19_1  original_T_including_depot_unload_849  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_723  1
    load_0_19_1  segment_load_conservation_774  -1
    load_0_19_1  segment_prefix_lb_775  1
    load_0_19_1  segment_prefix_ub_776  1
    load_0_19_1  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_725  -20
    arc_0_19_2  connected_order_arc_726  -13
    arc_0_19_2  in_degree_778  1
    arc_0_19_2  out_degree_834  1
    arc_0_19_2  original_T_including_depot_unload_849  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_725  1
    load_0_19_2  segment_load_conservation_781  -1
    load_0_19_2  segment_prefix_lb_782  1
    load_0_19_2  segment_prefix_ub_783  1
    load_0_19_2  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_727  -20
    arc_0_19_3  connected_order_arc_728  -13
    arc_0_19_3  in_degree_785  1
    arc_0_19_3  out_degree_834  1
    arc_0_19_3  original_T_including_depot_unload_849  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_727  1
    load_0_19_3  segment_load_conservation_788  -1
    load_0_19_3  segment_prefix_lb_789  1
    load_0_19_3  segment_prefix_ub_790  1
    load_0_19_3  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_729  -20
    arc_0_19_4  connected_order_arc_730  -13
    arc_0_19_4  in_degree_792  1
    arc_0_19_4  out_degree_834  1
    arc_0_19_4  original_T_including_depot_unload_849  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_729  1
    load_0_19_4  segment_load_conservation_795  -1
    load_0_19_4  segment_prefix_lb_796  1
    load_0_19_4  segment_prefix_ub_797  1
    load_0_19_4  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_731  -20
    arc_0_19_13  connected_order_arc_732  -13
    arc_0_19_13  in_degree_799  1
    arc_0_19_13  out_degree_834  1
    arc_0_19_13  original_T_including_depot_unload_849  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_731  1
    load_0_19_13  free_load_conservation_803  -1
    load_0_19_13  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_733  -20
    arc_0_19_14  connected_order_arc_734  -13
    arc_0_19_14  in_degree_805  1
    arc_0_19_14  out_degree_834  1
    arc_0_19_14  original_T_including_depot_unload_849  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_733  1
    load_0_19_14  free_load_conservation_809  -1
    load_0_19_14  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_735  -20
    arc_0_19_15  connected_order_arc_736  -13
    arc_0_19_15  in_degree_811  1
    arc_0_19_15  out_degree_834  1
    arc_0_19_15  original_T_including_depot_unload_849  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_735  1
    load_0_19_15  free_load_conservation_815  -1
    load_0_19_15  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_737  -20
    arc_0_19_16  connected_order_arc_738  -13
    arc_0_19_16  in_degree_817  1
    arc_0_19_16  out_degree_834  1
    arc_0_19_16  original_T_including_depot_unload_849  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_737  1
    load_0_19_16  free_load_conservation_821  -1
    load_0_19_16  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_739  -20
    arc_0_19_17  connected_order_arc_740  -13
    arc_0_19_17  in_degree_823  1
    arc_0_19_17  out_degree_834  1
    arc_0_19_17  original_T_including_depot_unload_849  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_739  1
    load_0_19_17  free_load_conservation_827  -1
    load_0_19_17  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_741  -20
    arc_0_19_18  connected_order_arc_742  -13
    arc_0_19_18  in_degree_829  1
    arc_0_19_18  out_degree_834  1
    arc_0_19_18  original_T_including_depot_unload_849  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_741  1
    load_0_19_18  free_load_conservation_833  -1
    load_0_19_18  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_743  -20
    arc_0_19_20  connected_order_arc_744  -13
    arc_0_19_20  out_degree_834  1
    arc_0_19_20  in_degree_841  1
    arc_0_19_20  original_T_including_depot_unload_849  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_743  1
    load_0_19_20  free_load_conservation_839  1
    load_0_19_20  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_745  -20
    arc_0_20_0  depot_return_or_bypass_769  1
    arc_0_20_0  out_degree_840  1
    arc_0_20_0  original_T_including_depot_unload_849  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_745  1
    load_0_20_0  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_746  -20
    arc_0_20_1  connected_order_arc_747  -13
    arc_0_20_1  in_degree_771  1
    arc_0_20_1  out_degree_840  1
    arc_0_20_1  original_T_including_depot_unload_849  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_746  1
    load_0_20_1  segment_load_conservation_774  -1
    load_0_20_1  segment_prefix_lb_775  1
    load_0_20_1  segment_prefix_ub_776  1
    load_0_20_1  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_748  -20
    arc_0_20_2  connected_order_arc_749  -13
    arc_0_20_2  in_degree_778  1
    arc_0_20_2  out_degree_840  1
    arc_0_20_2  original_T_including_depot_unload_849  7.7772825846942942e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_748  1
    load_0_20_2  segment_load_conservation_781  -1
    load_0_20_2  segment_prefix_lb_782  1
    load_0_20_2  segment_prefix_ub_783  1
    load_0_20_2  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_750  -20
    arc_0_20_3  connected_order_arc_751  -13
    arc_0_20_3  in_degree_785  1
    arc_0_20_3  out_degree_840  1
    arc_0_20_3  original_T_including_depot_unload_849  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_750  1
    load_0_20_3  segment_load_conservation_788  -1
    load_0_20_3  segment_prefix_lb_789  1
    load_0_20_3  segment_prefix_ub_790  1
    load_0_20_3  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_752  -20
    arc_0_20_4  connected_order_arc_753  -13
    arc_0_20_4  in_degree_792  1
    arc_0_20_4  out_degree_840  1
    arc_0_20_4  original_T_including_depot_unload_849  1.0687086794720833e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_752  1
    load_0_20_4  segment_load_conservation_795  -1
    load_0_20_4  segment_prefix_lb_796  1
    load_0_20_4  segment_prefix_ub_797  1
    load_0_20_4  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_13  arc_capacity_754  -20
    arc_0_20_13  connected_order_arc_755  -13
    arc_0_20_13  in_degree_799  1
    arc_0_20_13  out_degree_840  1
    arc_0_20_13  original_T_including_depot_unload_849  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_13  arc_capacity_754  1
    load_0_20_13  free_load_conservation_803  -1
    load_0_20_13  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_756  -20
    arc_0_20_14  connected_order_arc_757  -13
    arc_0_20_14  in_degree_805  1
    arc_0_20_14  out_degree_840  1
    arc_0_20_14  original_T_including_depot_unload_849  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_756  1
    load_0_20_14  free_load_conservation_809  -1
    load_0_20_14  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_758  -20
    arc_0_20_15  connected_order_arc_759  -13
    arc_0_20_15  in_degree_811  1
    arc_0_20_15  out_degree_840  1
    arc_0_20_15  original_T_including_depot_unload_849  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_758  1
    load_0_20_15  free_load_conservation_815  -1
    load_0_20_15  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_760  -20
    arc_0_20_16  connected_order_arc_761  -13
    arc_0_20_16  in_degree_817  1
    arc_0_20_16  out_degree_840  1
    arc_0_20_16  original_T_including_depot_unload_849  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_760  1
    load_0_20_16  free_load_conservation_821  -1
    load_0_20_16  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_762  -20
    arc_0_20_17  connected_order_arc_763  -13
    arc_0_20_17  in_degree_823  1
    arc_0_20_17  out_degree_840  1
    arc_0_20_17  original_T_including_depot_unload_849  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_762  1
    load_0_20_17  free_load_conservation_827  -1
    load_0_20_17  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_764  -20
    arc_0_20_18  connected_order_arc_765  -13
    arc_0_20_18  in_degree_829  1
    arc_0_20_18  out_degree_840  1
    arc_0_20_18  original_T_including_depot_unload_849  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_764  1
    load_0_20_18  free_load_conservation_833  -1
    load_0_20_18  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_766  -20
    arc_0_20_19  connected_order_arc_767  -13
    arc_0_20_19  in_degree_835  1
    arc_0_20_19  out_degree_840  1
    arc_0_20_19  original_T_including_depot_unload_849  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_766  1
    load_0_20_19  free_load_conservation_839  -1
    load_0_20_19  free_load_conservation_845  1
    visit_1_5  out_degree_1191  -1
    visit_1_5  in_degree_1192  -1
    visit_1_5  order_active_lb_1193  -1
    visit_1_5  order_active_ub_1194  -13
    order_1_5  connected_order_arc_866  -1
    order_1_5  connected_order_arc_868  -1
    order_1_5  connected_order_arc_870  -1
    order_1_5  connected_order_arc_872  -1
    order_1_5  connected_order_arc_874  -1
    order_1_5  connected_order_arc_876  -1
    order_1_5  connected_order_arc_878  -1
    order_1_5  connected_order_arc_880  -1
    order_1_5  connected_order_arc_882  -1
    order_1_5  connected_order_arc_884  -1
    order_1_5  connected_order_arc_886  -1
    order_1_5  connected_order_arc_888  -1
    order_1_5  connected_order_arc_891  1
    order_1_5  connected_order_arc_916  1
    order_1_5  connected_order_arc_941  1
    order_1_5  connected_order_arc_966  1
    order_1_5  connected_order_arc_991  1
    order_1_5  connected_order_arc_1016  1
    order_1_5  connected_order_arc_1041  1
    order_1_5  connected_order_arc_1066  1
    order_1_5  connected_order_arc_1091  1
    order_1_5  connected_order_arc_1116  1
    order_1_5  connected_order_arc_1141  1
    order_1_5  connected_order_arc_1166  1
    order_1_5  order_active_lb_1193  1
    order_1_5  order_active_ub_1194  1
    order_1_5  fixed_segment_relative_order_1274  -1
    visit_1_6  out_degree_1198  -1
    visit_1_6  in_degree_1199  -1
    visit_1_6  order_active_lb_1200  -1
    visit_1_6  order_active_ub_1201  -13
    order_1_6  connected_order_arc_866  1
    order_1_6  connected_order_arc_891  -1
    order_1_6  connected_order_arc_893  -1
    order_1_6  connected_order_arc_895  -1
    order_1_6  connected_order_arc_897  -1
    order_1_6  connected_order_arc_899  -1
    order_1_6  connected_order_arc_901  -1
    order_1_6  connected_order_arc_903  -1
    order_1_6  connected_order_arc_905  -1
    order_1_6  connected_order_arc_907  -1
    order_1_6  connected_order_arc_909  -1
    order_1_6  connected_order_arc_911  -1
    order_1_6  connected_order_arc_913  -1
    order_1_6  connected_order_arc_918  1
    order_1_6  connected_order_arc_943  1
    order_1_6  connected_order_arc_968  1
    order_1_6  connected_order_arc_993  1
    order_1_6  connected_order_arc_1018  1
    order_1_6  connected_order_arc_1043  1
    order_1_6  connected_order_arc_1068  1
    order_1_6  connected_order_arc_1093  1
    order_1_6  connected_order_arc_1118  1
    order_1_6  connected_order_arc_1143  1
    order_1_6  connected_order_arc_1168  1
    order_1_6  order_active_lb_1200  1
    order_1_6  order_active_ub_1201  1
    order_1_6  fixed_segment_relative_order_1274  1
    order_1_6  fixed_segment_relative_order_1275  -1
    visit_1_7  out_degree_1205  -1
    visit_1_7  in_degree_1206  -1
    visit_1_7  order_active_lb_1207  -1
    visit_1_7  order_active_ub_1208  -13
    order_1_7  connected_order_arc_868  1
    order_1_7  connected_order_arc_893  1
    order_1_7  connected_order_arc_916  -1
    order_1_7  connected_order_arc_918  -1
    order_1_7  connected_order_arc_920  -1
    order_1_7  connected_order_arc_922  -1
    order_1_7  connected_order_arc_924  -1
    order_1_7  connected_order_arc_926  -1
    order_1_7  connected_order_arc_928  -1
    order_1_7  connected_order_arc_930  -1
    order_1_7  connected_order_arc_932  -1
    order_1_7  connected_order_arc_934  -1
    order_1_7  connected_order_arc_936  -1
    order_1_7  connected_order_arc_938  -1
    order_1_7  connected_order_arc_945  1
    order_1_7  connected_order_arc_970  1
    order_1_7  connected_order_arc_995  1
    order_1_7  connected_order_arc_1020  1
    order_1_7  connected_order_arc_1045  1
    order_1_7  connected_order_arc_1070  1
    order_1_7  connected_order_arc_1095  1
    order_1_7  connected_order_arc_1120  1
    order_1_7  connected_order_arc_1145  1
    order_1_7  connected_order_arc_1170  1
    order_1_7  order_active_lb_1207  1
    order_1_7  order_active_ub_1208  1
    order_1_7  fixed_segment_relative_order_1275  1
    order_1_7  fixed_segment_relative_order_1276  -1
    visit_1_8  out_degree_1212  -1
    visit_1_8  in_degree_1213  -1
    visit_1_8  order_active_lb_1214  -1
    visit_1_8  order_active_ub_1215  -13
    order_1_8  connected_order_arc_870  1
    order_1_8  connected_order_arc_895  1
    order_1_8  connected_order_arc_920  1
    order_1_8  connected_order_arc_941  -1
    order_1_8  connected_order_arc_943  -1
    order_1_8  connected_order_arc_945  -1
    order_1_8  connected_order_arc_947  -1
    order_1_8  connected_order_arc_949  -1
    order_1_8  connected_order_arc_951  -1
    order_1_8  connected_order_arc_953  -1
    order_1_8  connected_order_arc_955  -1
    order_1_8  connected_order_arc_957  -1
    order_1_8  connected_order_arc_959  -1
    order_1_8  connected_order_arc_961  -1
    order_1_8  connected_order_arc_963  -1
    order_1_8  connected_order_arc_972  1
    order_1_8  connected_order_arc_997  1
    order_1_8  connected_order_arc_1022  1
    order_1_8  connected_order_arc_1047  1
    order_1_8  connected_order_arc_1072  1
    order_1_8  connected_order_arc_1097  1
    order_1_8  connected_order_arc_1122  1
    order_1_8  connected_order_arc_1147  1
    order_1_8  connected_order_arc_1172  1
    order_1_8  order_active_lb_1214  1
    order_1_8  order_active_ub_1215  1
    order_1_8  fixed_segment_relative_order_1276  1
    order_1_8  fixed_segment_relative_order_1277  -1
    visit_1_9  out_degree_1219  -1
    visit_1_9  in_degree_1220  -1
    visit_1_9  order_active_lb_1221  -1
    visit_1_9  order_active_ub_1222  -13
    order_1_9  connected_order_arc_872  1
    order_1_9  connected_order_arc_897  1
    order_1_9  connected_order_arc_922  1
    order_1_9  connected_order_arc_947  1
    order_1_9  connected_order_arc_966  -1
    order_1_9  connected_order_arc_968  -1
    order_1_9  connected_order_arc_970  -1
    order_1_9  connected_order_arc_972  -1
    order_1_9  connected_order_arc_974  -1
    order_1_9  connected_order_arc_976  -1
    order_1_9  connected_order_arc_978  -1
    order_1_9  connected_order_arc_980  -1
    order_1_9  connected_order_arc_982  -1
    order_1_9  connected_order_arc_984  -1
    order_1_9  connected_order_arc_986  -1
    order_1_9  connected_order_arc_988  -1
    order_1_9  connected_order_arc_999  1
    order_1_9  connected_order_arc_1024  1
    order_1_9  connected_order_arc_1049  1
    order_1_9  connected_order_arc_1074  1
    order_1_9  connected_order_arc_1099  1
    order_1_9  connected_order_arc_1124  1
    order_1_9  connected_order_arc_1149  1
    order_1_9  connected_order_arc_1174  1
    order_1_9  order_active_lb_1221  1
    order_1_9  order_active_ub_1222  1
    order_1_9  fixed_segment_relative_order_1277  1
    visit_1_13  out_degree_1226  -1
    visit_1_13  in_degree_1227  -1
    visit_1_13  order_active_lb_1228  -1
    visit_1_13  order_active_ub_1229  -13
    visit_1_13  service_visit_def_1230  -1
    order_1_13  connected_order_arc_874  1
    order_1_13  connected_order_arc_899  1
    order_1_13  connected_order_arc_924  1
    order_1_13  connected_order_arc_949  1
    order_1_13  connected_order_arc_974  1
    order_1_13  connected_order_arc_991  -1
    order_1_13  connected_order_arc_993  -1
    order_1_13  connected_order_arc_995  -1
    order_1_13  connected_order_arc_997  -1
    order_1_13  connected_order_arc_999  -1
    order_1_13  connected_order_arc_1001  -1
    order_1_13  connected_order_arc_1003  -1
    order_1_13  connected_order_arc_1005  -1
    order_1_13  connected_order_arc_1007  -1
    order_1_13  connected_order_arc_1009  -1
    order_1_13  connected_order_arc_1011  -1
    order_1_13  connected_order_arc_1013  -1
    order_1_13  connected_order_arc_1026  1
    order_1_13  connected_order_arc_1051  1
    order_1_13  connected_order_arc_1076  1
    order_1_13  connected_order_arc_1101  1
    order_1_13  connected_order_arc_1126  1
    order_1_13  connected_order_arc_1151  1
    order_1_13  connected_order_arc_1176  1
    order_1_13  order_active_lb_1228  1
    order_1_13  order_active_ub_1229  1
    visit_1_14  out_degree_1232  -1
    visit_1_14  in_degree_1233  -1
    visit_1_14  order_active_lb_1234  -1
    visit_1_14  order_active_ub_1235  -13
    visit_1_14  service_visit_def_1236  -1
    order_1_14  connected_order_arc_876  1
    order_1_14  connected_order_arc_901  1
    order_1_14  connected_order_arc_926  1
    order_1_14  connected_order_arc_951  1
    order_1_14  connected_order_arc_976  1
    order_1_14  connected_order_arc_1001  1
    order_1_14  connected_order_arc_1016  -1
    order_1_14  connected_order_arc_1018  -1
    order_1_14  connected_order_arc_1020  -1
    order_1_14  connected_order_arc_1022  -1
    order_1_14  connected_order_arc_1024  -1
    order_1_14  connected_order_arc_1026  -1
    order_1_14  connected_order_arc_1028  -1
    order_1_14  connected_order_arc_1030  -1
    order_1_14  connected_order_arc_1032  -1
    order_1_14  connected_order_arc_1034  -1
    order_1_14  connected_order_arc_1036  -1
    order_1_14  connected_order_arc_1038  -1
    order_1_14  connected_order_arc_1053  1
    order_1_14  connected_order_arc_1078  1
    order_1_14  connected_order_arc_1103  1
    order_1_14  connected_order_arc_1128  1
    order_1_14  connected_order_arc_1153  1
    order_1_14  connected_order_arc_1178  1
    order_1_14  order_active_lb_1234  1
    order_1_14  order_active_ub_1235  1
    visit_1_15  out_degree_1238  -1
    visit_1_15  in_degree_1239  -1
    visit_1_15  order_active_lb_1240  -1
    visit_1_15  order_active_ub_1241  -13
    visit_1_15  service_visit_def_1242  -1
    order_1_15  connected_order_arc_878  1
    order_1_15  connected_order_arc_903  1
    order_1_15  connected_order_arc_928  1
    order_1_15  connected_order_arc_953  1
    order_1_15  connected_order_arc_978  1
    order_1_15  connected_order_arc_1003  1
    order_1_15  connected_order_arc_1028  1
    order_1_15  connected_order_arc_1041  -1
    order_1_15  connected_order_arc_1043  -1
    order_1_15  connected_order_arc_1045  -1
    order_1_15  connected_order_arc_1047  -1
    order_1_15  connected_order_arc_1049  -1
    order_1_15  connected_order_arc_1051  -1
    order_1_15  connected_order_arc_1053  -1
    order_1_15  connected_order_arc_1055  -1
    order_1_15  connected_order_arc_1057  -1
    order_1_15  connected_order_arc_1059  -1
    order_1_15  connected_order_arc_1061  -1
    order_1_15  connected_order_arc_1063  -1
    order_1_15  connected_order_arc_1080  1
    order_1_15  connected_order_arc_1105  1
    order_1_15  connected_order_arc_1130  1
    order_1_15  connected_order_arc_1155  1
    order_1_15  connected_order_arc_1180  1
    order_1_15  order_active_lb_1240  1
    order_1_15  order_active_ub_1241  1
    visit_1_16  out_degree_1244  -1
    visit_1_16  in_degree_1245  -1
    visit_1_16  order_active_lb_1246  -1
    visit_1_16  order_active_ub_1247  -13
    visit_1_16  service_visit_def_1248  -1
    order_1_16  connected_order_arc_880  1
    order_1_16  connected_order_arc_905  1
    order_1_16  connected_order_arc_930  1
    order_1_16  connected_order_arc_955  1
    order_1_16  connected_order_arc_980  1
    order_1_16  connected_order_arc_1005  1
    order_1_16  connected_order_arc_1030  1
    order_1_16  connected_order_arc_1055  1
    order_1_16  connected_order_arc_1066  -1
    order_1_16  connected_order_arc_1068  -1
    order_1_16  connected_order_arc_1070  -1
    order_1_16  connected_order_arc_1072  -1
    order_1_16  connected_order_arc_1074  -1
    order_1_16  connected_order_arc_1076  -1
    order_1_16  connected_order_arc_1078  -1
    order_1_16  connected_order_arc_1080  -1
    order_1_16  connected_order_arc_1082  -1
    order_1_16  connected_order_arc_1084  -1
    order_1_16  connected_order_arc_1086  -1
    order_1_16  connected_order_arc_1088  -1
    order_1_16  connected_order_arc_1107  1
    order_1_16  connected_order_arc_1132  1
    order_1_16  connected_order_arc_1157  1
    order_1_16  connected_order_arc_1182  1
    order_1_16  order_active_lb_1246  1
    order_1_16  order_active_ub_1247  1
    visit_1_17  out_degree_1250  -1
    visit_1_17  in_degree_1251  -1
    visit_1_17  order_active_lb_1252  -1
    visit_1_17  order_active_ub_1253  -13
    visit_1_17  service_visit_def_1254  -1
    order_1_17  connected_order_arc_882  1
    order_1_17  connected_order_arc_907  1
    order_1_17  connected_order_arc_932  1
    order_1_17  connected_order_arc_957  1
    order_1_17  connected_order_arc_982  1
    order_1_17  connected_order_arc_1007  1
    order_1_17  connected_order_arc_1032  1
    order_1_17  connected_order_arc_1057  1
    order_1_17  connected_order_arc_1082  1
    order_1_17  connected_order_arc_1091  -1
    order_1_17  connected_order_arc_1093  -1
    order_1_17  connected_order_arc_1095  -1
    order_1_17  connected_order_arc_1097  -1
    order_1_17  connected_order_arc_1099  -1
    order_1_17  connected_order_arc_1101  -1
    order_1_17  connected_order_arc_1103  -1
    order_1_17  connected_order_arc_1105  -1
    order_1_17  connected_order_arc_1107  -1
    order_1_17  connected_order_arc_1109  -1
    order_1_17  connected_order_arc_1111  -1
    order_1_17  connected_order_arc_1113  -1
    order_1_17  connected_order_arc_1134  1
    order_1_17  connected_order_arc_1159  1
    order_1_17  connected_order_arc_1184  1
    order_1_17  order_active_lb_1252  1
    order_1_17  order_active_ub_1253  1
    visit_1_18  out_degree_1256  -1
    visit_1_18  in_degree_1257  -1
    visit_1_18  order_active_lb_1258  -1
    visit_1_18  order_active_ub_1259  -13
    visit_1_18  service_visit_def_1260  -1
    order_1_18  connected_order_arc_884  1
    order_1_18  connected_order_arc_909  1
    order_1_18  connected_order_arc_934  1
    order_1_18  connected_order_arc_959  1
    order_1_18  connected_order_arc_984  1
    order_1_18  connected_order_arc_1009  1
    order_1_18  connected_order_arc_1034  1
    order_1_18  connected_order_arc_1059  1
    order_1_18  connected_order_arc_1084  1
    order_1_18  connected_order_arc_1109  1
    order_1_18  connected_order_arc_1116  -1
    order_1_18  connected_order_arc_1118  -1
    order_1_18  connected_order_arc_1120  -1
    order_1_18  connected_order_arc_1122  -1
    order_1_18  connected_order_arc_1124  -1
    order_1_18  connected_order_arc_1126  -1
    order_1_18  connected_order_arc_1128  -1
    order_1_18  connected_order_arc_1130  -1
    order_1_18  connected_order_arc_1132  -1
    order_1_18  connected_order_arc_1134  -1
    order_1_18  connected_order_arc_1136  -1
    order_1_18  connected_order_arc_1138  -1
    order_1_18  connected_order_arc_1161  1
    order_1_18  connected_order_arc_1186  1
    order_1_18  order_active_lb_1258  1
    order_1_18  order_active_ub_1259  1
    visit_1_19  out_degree_1262  -1
    visit_1_19  in_degree_1263  -1
    visit_1_19  order_active_lb_1264  -1
    visit_1_19  order_active_ub_1265  -13
    visit_1_19  service_visit_def_1266  -1
    order_1_19  connected_order_arc_886  1
    order_1_19  connected_order_arc_911  1
    order_1_19  connected_order_arc_936  1
    order_1_19  connected_order_arc_961  1
    order_1_19  connected_order_arc_986  1
    order_1_19  connected_order_arc_1011  1
    order_1_19  connected_order_arc_1036  1
    order_1_19  connected_order_arc_1061  1
    order_1_19  connected_order_arc_1086  1
    order_1_19  connected_order_arc_1111  1
    order_1_19  connected_order_arc_1136  1
    order_1_19  connected_order_arc_1141  -1
    order_1_19  connected_order_arc_1143  -1
    order_1_19  connected_order_arc_1145  -1
    order_1_19  connected_order_arc_1147  -1
    order_1_19  connected_order_arc_1149  -1
    order_1_19  connected_order_arc_1151  -1
    order_1_19  connected_order_arc_1153  -1
    order_1_19  connected_order_arc_1155  -1
    order_1_19  connected_order_arc_1157  -1
    order_1_19  connected_order_arc_1159  -1
    order_1_19  connected_order_arc_1161  -1
    order_1_19  connected_order_arc_1163  -1
    order_1_19  connected_order_arc_1188  1
    order_1_19  order_active_lb_1264  1
    order_1_19  order_active_ub_1265  1
    visit_1_20  out_degree_1268  -1
    visit_1_20  in_degree_1269  -1
    visit_1_20  order_active_lb_1270  -1
    visit_1_20  order_active_ub_1271  -13
    visit_1_20  service_visit_def_1272  -1
    order_1_20  connected_order_arc_888  1
    order_1_20  connected_order_arc_913  1
    order_1_20  connected_order_arc_938  1
    order_1_20  connected_order_arc_963  1
    order_1_20  connected_order_arc_988  1
    order_1_20  connected_order_arc_1013  1
    order_1_20  connected_order_arc_1038  1
    order_1_20  connected_order_arc_1063  1
    order_1_20  connected_order_arc_1088  1
    order_1_20  connected_order_arc_1113  1
    order_1_20  connected_order_arc_1138  1
    order_1_20  connected_order_arc_1163  1
    order_1_20  connected_order_arc_1166  -1
    order_1_20  connected_order_arc_1168  -1
    order_1_20  connected_order_arc_1170  -1
    order_1_20  connected_order_arc_1172  -1
    order_1_20  connected_order_arc_1174  -1
    order_1_20  connected_order_arc_1176  -1
    order_1_20  connected_order_arc_1178  -1
    order_1_20  connected_order_arc_1180  -1
    order_1_20  connected_order_arc_1182  -1
    order_1_20  connected_order_arc_1184  -1
    order_1_20  connected_order_arc_1186  -1
    order_1_20  connected_order_arc_1188  -1
    order_1_20  order_active_lb_1270  1
    order_1_20  order_active_ub_1271  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_850  -25
    arc_1_0_0  depot_departure_or_bypass_1189  1
    arc_1_0_0  depot_return_or_bypass_1190  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_850  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_5  arc_capacity_851  -25
    arc_1_0_5  depot_departure_or_bypass_1189  1
    arc_1_0_5  in_degree_1192  1
    arc_1_0_5  original_T_including_depot_unload_1278  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_5  arc_capacity_851  1
    load_1_0_5  segment_load_conservation_1195  -1
    load_1_0_5  segment_prefix_lb_1196  1
    load_1_0_5  segment_prefix_ub_1197  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_852  -25
    arc_1_0_6  depot_departure_or_bypass_1189  1
    arc_1_0_6  in_degree_1199  1
    arc_1_0_6  original_T_including_depot_unload_1278  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_852  1
    load_1_0_6  segment_load_conservation_1202  -1
    load_1_0_6  segment_prefix_lb_1203  1
    load_1_0_6  segment_prefix_ub_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_853  -25
    arc_1_0_7  depot_departure_or_bypass_1189  1
    arc_1_0_7  in_degree_1206  1
    arc_1_0_7  original_T_including_depot_unload_1278  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_853  1
    load_1_0_7  segment_load_conservation_1209  -1
    load_1_0_7  segment_prefix_lb_1210  1
    load_1_0_7  segment_prefix_ub_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_854  -25
    arc_1_0_8  depot_departure_or_bypass_1189  1
    arc_1_0_8  in_degree_1213  1
    arc_1_0_8  original_T_including_depot_unload_1278  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_854  1
    load_1_0_8  segment_load_conservation_1216  -1
    load_1_0_8  segment_prefix_lb_1217  1
    load_1_0_8  segment_prefix_ub_1218  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_855  -25
    arc_1_0_9  depot_departure_or_bypass_1189  1
    arc_1_0_9  in_degree_1220  1
    arc_1_0_9  original_T_including_depot_unload_1278  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_855  1
    load_1_0_9  segment_load_conservation_1223  -1
    load_1_0_9  segment_prefix_lb_1224  1
    load_1_0_9  segment_prefix_ub_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_856  -25
    arc_1_0_13  depot_departure_or_bypass_1189  1
    arc_1_0_13  in_degree_1227  1
    arc_1_0_13  original_T_including_depot_unload_1278  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_856  1
    load_1_0_13  free_load_conservation_1231  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_857  -25
    arc_1_0_14  depot_departure_or_bypass_1189  1
    arc_1_0_14  in_degree_1233  1
    arc_1_0_14  original_T_including_depot_unload_1278  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_857  1
    load_1_0_14  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_858  -25
    arc_1_0_15  depot_departure_or_bypass_1189  1
    arc_1_0_15  in_degree_1239  1
    arc_1_0_15  original_T_including_depot_unload_1278  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_858  1
    load_1_0_15  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_859  -25
    arc_1_0_16  depot_departure_or_bypass_1189  1
    arc_1_0_16  in_degree_1245  1
    arc_1_0_16  original_T_including_depot_unload_1278  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_859  1
    load_1_0_16  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_860  -25
    arc_1_0_17  depot_departure_or_bypass_1189  1
    arc_1_0_17  in_degree_1251  1
    arc_1_0_17  original_T_including_depot_unload_1278  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_860  1
    load_1_0_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_861  -25
    arc_1_0_18  depot_departure_or_bypass_1189  1
    arc_1_0_18  in_degree_1257  1
    arc_1_0_18  original_T_including_depot_unload_1278  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_861  1
    load_1_0_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_862  -25
    arc_1_0_19  depot_departure_or_bypass_1189  1
    arc_1_0_19  in_degree_1263  1
    arc_1_0_19  original_T_including_depot_unload_1278  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_862  1
    load_1_0_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_863  -25
    arc_1_0_20  depot_departure_or_bypass_1189  1
    arc_1_0_20  in_degree_1269  1
    arc_1_0_20  original_T_including_depot_unload_1278  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_863  1
    load_1_0_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_0  arc_capacity_864  -25
    arc_1_5_0  depot_return_or_bypass_1190  1
    arc_1_5_0  out_degree_1191  1
    arc_1_5_0  original_T_including_depot_unload_1278  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_0  arc_capacity_864  1
    load_1_5_0  segment_load_conservation_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_6  arc_capacity_865  -25
    arc_1_5_6  connected_order_arc_866  -14
    arc_1_5_6  out_degree_1191  1
    arc_1_5_6  in_degree_1199  1
    arc_1_5_6  original_T_including_depot_unload_1278  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_6  arc_capacity_865  1
    load_1_5_6  segment_load_conservation_1195  1
    load_1_5_6  segment_load_conservation_1202  -1
    load_1_5_6  segment_prefix_lb_1203  1
    load_1_5_6  segment_prefix_ub_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_7  arc_capacity_867  -25
    arc_1_5_7  connected_order_arc_868  -14
    arc_1_5_7  out_degree_1191  1
    arc_1_5_7  in_degree_1206  1
    arc_1_5_7  original_T_including_depot_unload_1278  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_7  arc_capacity_867  1
    load_1_5_7  segment_load_conservation_1195  1
    load_1_5_7  segment_load_conservation_1209  -1
    load_1_5_7  segment_prefix_lb_1210  1
    load_1_5_7  segment_prefix_ub_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_8  arc_capacity_869  -25
    arc_1_5_8  connected_order_arc_870  -14
    arc_1_5_8  out_degree_1191  1
    arc_1_5_8  in_degree_1213  1
    arc_1_5_8  original_T_including_depot_unload_1278  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_8  arc_capacity_869  1
    load_1_5_8  segment_load_conservation_1195  1
    load_1_5_8  segment_load_conservation_1216  -1
    load_1_5_8  segment_prefix_lb_1217  1
    load_1_5_8  segment_prefix_ub_1218  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_9  arc_capacity_871  -25
    arc_1_5_9  connected_order_arc_872  -14
    arc_1_5_9  out_degree_1191  1
    arc_1_5_9  in_degree_1220  1
    arc_1_5_9  original_T_including_depot_unload_1278  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_9  arc_capacity_871  1
    load_1_5_9  segment_load_conservation_1195  1
    load_1_5_9  segment_load_conservation_1223  -1
    load_1_5_9  segment_prefix_lb_1224  1
    load_1_5_9  segment_prefix_ub_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_13  arc_capacity_873  -25
    arc_1_5_13  connected_order_arc_874  -14
    arc_1_5_13  out_degree_1191  1
    arc_1_5_13  in_degree_1227  1
    arc_1_5_13  original_T_including_depot_unload_1278  1.5145600125783847e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_13  arc_capacity_873  1
    load_1_5_13  segment_load_conservation_1195  1
    load_1_5_13  free_load_conservation_1231  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_14  arc_capacity_875  -25
    arc_1_5_14  connected_order_arc_876  -14
    arc_1_5_14  out_degree_1191  1
    arc_1_5_14  in_degree_1233  1
    arc_1_5_14  original_T_including_depot_unload_1278  1.4829753176244692e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_14  arc_capacity_875  1
    load_1_5_14  segment_load_conservation_1195  1
    load_1_5_14  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_15  arc_capacity_877  -25
    arc_1_5_15  connected_order_arc_878  -14
    arc_1_5_15  out_degree_1191  1
    arc_1_5_15  in_degree_1239  1
    arc_1_5_15  original_T_including_depot_unload_1278  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_15  arc_capacity_877  1
    load_1_5_15  segment_load_conservation_1195  1
    load_1_5_15  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_16  arc_capacity_879  -25
    arc_1_5_16  connected_order_arc_880  -14
    arc_1_5_16  out_degree_1191  1
    arc_1_5_16  in_degree_1245  1
    arc_1_5_16  original_T_including_depot_unload_1278  1.3473071485321755e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_16  arc_capacity_879  1
    load_1_5_16  segment_load_conservation_1195  1
    load_1_5_16  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_17  arc_capacity_881  -25
    arc_1_5_17  connected_order_arc_882  -14
    arc_1_5_17  out_degree_1191  1
    arc_1_5_17  in_degree_1251  1
    arc_1_5_17  original_T_including_depot_unload_1278  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_17  arc_capacity_881  1
    load_1_5_17  segment_load_conservation_1195  1
    load_1_5_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_18  arc_capacity_883  -25
    arc_1_5_18  connected_order_arc_884  -14
    arc_1_5_18  out_degree_1191  1
    arc_1_5_18  in_degree_1257  1
    arc_1_5_18  original_T_including_depot_unload_1278  1.2336637947519732e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_18  arc_capacity_883  1
    load_1_5_18  segment_load_conservation_1195  1
    load_1_5_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_19  arc_capacity_885  -25
    arc_1_5_19  connected_order_arc_886  -14
    arc_1_5_19  out_degree_1191  1
    arc_1_5_19  in_degree_1263  1
    arc_1_5_19  original_T_including_depot_unload_1278  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_19  arc_capacity_885  1
    load_1_5_19  segment_load_conservation_1195  1
    load_1_5_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_20  arc_capacity_887  -25
    arc_1_5_20  connected_order_arc_888  -14
    arc_1_5_20  out_degree_1191  1
    arc_1_5_20  in_degree_1269  1
    arc_1_5_20  original_T_including_depot_unload_1278  1.5223381412470410e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_20  arc_capacity_887  1
    load_1_5_20  segment_load_conservation_1195  1
    load_1_5_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_889  -25
    arc_1_6_0  depot_return_or_bypass_1190  1
    arc_1_6_0  out_degree_1198  1
    arc_1_6_0  original_T_including_depot_unload_1278  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_889  1
    load_1_6_0  segment_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_5  arc_capacity_890  -25
    arc_1_6_5  connected_order_arc_891  -14
    arc_1_6_5  in_degree_1192  1
    arc_1_6_5  out_degree_1198  1
    arc_1_6_5  original_T_including_depot_unload_1278  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_5  arc_capacity_890  1
    load_1_6_5  segment_load_conservation_1195  -1
    load_1_6_5  segment_prefix_lb_1196  1
    load_1_6_5  segment_prefix_ub_1197  1
    load_1_6_5  segment_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_892  -25
    arc_1_6_7  connected_order_arc_893  -14
    arc_1_6_7  out_degree_1198  1
    arc_1_6_7  in_degree_1206  1
    arc_1_6_7  original_T_including_depot_unload_1278  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_892  1
    load_1_6_7  segment_load_conservation_1202  1
    load_1_6_7  segment_load_conservation_1209  -1
    load_1_6_7  segment_prefix_lb_1210  1
    load_1_6_7  segment_prefix_ub_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_894  -25
    arc_1_6_8  connected_order_arc_895  -14
    arc_1_6_8  out_degree_1198  1
    arc_1_6_8  in_degree_1213  1
    arc_1_6_8  original_T_including_depot_unload_1278  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_894  1
    load_1_6_8  segment_load_conservation_1202  1
    load_1_6_8  segment_load_conservation_1216  -1
    load_1_6_8  segment_prefix_lb_1217  1
    load_1_6_8  segment_prefix_ub_1218  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_896  -25
    arc_1_6_9  connected_order_arc_897  -14
    arc_1_6_9  out_degree_1198  1
    arc_1_6_9  in_degree_1220  1
    arc_1_6_9  original_T_including_depot_unload_1278  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_896  1
    load_1_6_9  segment_load_conservation_1202  1
    load_1_6_9  segment_load_conservation_1223  -1
    load_1_6_9  segment_prefix_lb_1224  1
    load_1_6_9  segment_prefix_ub_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_898  -25
    arc_1_6_13  connected_order_arc_899  -14
    arc_1_6_13  out_degree_1198  1
    arc_1_6_13  in_degree_1227  1
    arc_1_6_13  original_T_including_depot_unload_1278  9.2153450304618127e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_898  1
    load_1_6_13  segment_load_conservation_1202  1
    load_1_6_13  free_load_conservation_1231  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_900  -25
    arc_1_6_14  connected_order_arc_901  -14
    arc_1_6_14  out_degree_1198  1
    arc_1_6_14  in_degree_1233  1
    arc_1_6_14  original_T_including_depot_unload_1278  1.0213043329444467e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_900  1
    load_1_6_14  segment_load_conservation_1202  1
    load_1_6_14  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_902  -25
    arc_1_6_15  connected_order_arc_903  -14
    arc_1_6_15  out_degree_1198  1
    arc_1_6_15  in_degree_1239  1
    arc_1_6_15  original_T_including_depot_unload_1278  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_902  1
    load_1_6_15  segment_load_conservation_1202  1
    load_1_6_15  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_904  -25
    arc_1_6_16  connected_order_arc_905  -14
    arc_1_6_16  out_degree_1198  1
    arc_1_6_16  in_degree_1245  1
    arc_1_6_16  original_T_including_depot_unload_1278  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_904  1
    load_1_6_16  segment_load_conservation_1202  1
    load_1_6_16  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_906  -25
    arc_1_6_17  connected_order_arc_907  -14
    arc_1_6_17  out_degree_1198  1
    arc_1_6_17  in_degree_1251  1
    arc_1_6_17  original_T_including_depot_unload_1278  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_906  1
    load_1_6_17  segment_load_conservation_1202  1
    load_1_6_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_908  -25
    arc_1_6_18  connected_order_arc_909  -14
    arc_1_6_18  out_degree_1198  1
    arc_1_6_18  in_degree_1257  1
    arc_1_6_18  original_T_including_depot_unload_1278  7.8495921746600118e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_908  1
    load_1_6_18  segment_load_conservation_1202  1
    load_1_6_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_910  -25
    arc_1_6_19  connected_order_arc_911  -14
    arc_1_6_19  out_degree_1198  1
    arc_1_6_19  in_degree_1263  1
    arc_1_6_19  original_T_including_depot_unload_1278  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_910  1
    load_1_6_19  segment_load_conservation_1202  1
    load_1_6_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_912  -25
    arc_1_6_20  connected_order_arc_913  -14
    arc_1_6_20  out_degree_1198  1
    arc_1_6_20  in_degree_1269  1
    arc_1_6_20  original_T_including_depot_unload_1278  7.1006591329511764e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_912  1
    load_1_6_20  segment_load_conservation_1202  1
    load_1_6_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_914  -25
    arc_1_7_0  depot_return_or_bypass_1190  1
    arc_1_7_0  out_degree_1205  1
    arc_1_7_0  original_T_including_depot_unload_1278  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_914  1
    load_1_7_0  segment_load_conservation_1209  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_5  arc_capacity_915  -25
    arc_1_7_5  connected_order_arc_916  -14
    arc_1_7_5  in_degree_1192  1
    arc_1_7_5  out_degree_1205  1
    arc_1_7_5  original_T_including_depot_unload_1278  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_5  arc_capacity_915  1
    load_1_7_5  segment_load_conservation_1195  -1
    load_1_7_5  segment_prefix_lb_1196  1
    load_1_7_5  segment_prefix_ub_1197  1
    load_1_7_5  segment_load_conservation_1209  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_917  -25
    arc_1_7_6  connected_order_arc_918  -14
    arc_1_7_6  in_degree_1199  1
    arc_1_7_6  out_degree_1205  1
    arc_1_7_6  original_T_including_depot_unload_1278  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_917  1
    load_1_7_6  segment_load_conservation_1202  -1
    load_1_7_6  segment_prefix_lb_1203  1
    load_1_7_6  segment_prefix_ub_1204  1
    load_1_7_6  segment_load_conservation_1209  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_919  -25
    arc_1_7_8  connected_order_arc_920  -14
    arc_1_7_8  out_degree_1205  1
    arc_1_7_8  in_degree_1213  1
    arc_1_7_8  original_T_including_depot_unload_1278  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_919  1
    load_1_7_8  segment_load_conservation_1209  1
    load_1_7_8  segment_load_conservation_1216  -1
    load_1_7_8  segment_prefix_lb_1217  1
    load_1_7_8  segment_prefix_ub_1218  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_921  -25
    arc_1_7_9  connected_order_arc_922  -14
    arc_1_7_9  out_degree_1205  1
    arc_1_7_9  in_degree_1220  1
    arc_1_7_9  original_T_including_depot_unload_1278  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_921  1
    load_1_7_9  segment_load_conservation_1209  1
    load_1_7_9  segment_load_conservation_1223  -1
    load_1_7_9  segment_prefix_lb_1224  1
    load_1_7_9  segment_prefix_ub_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_923  -25
    arc_1_7_13  connected_order_arc_924  -14
    arc_1_7_13  out_degree_1205  1
    arc_1_7_13  in_degree_1227  1
    arc_1_7_13  original_T_including_depot_unload_1278  8.5807018379884664e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_923  1
    load_1_7_13  segment_load_conservation_1209  1
    load_1_7_13  free_load_conservation_1231  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_925  -25
    arc_1_7_14  connected_order_arc_926  -14
    arc_1_7_14  out_degree_1205  1
    arc_1_7_14  in_degree_1233  1
    arc_1_7_14  original_T_including_depot_unload_1278  9.4424191477021122e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_925  1
    load_1_7_14  segment_load_conservation_1209  1
    load_1_7_14  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_927  -25
    arc_1_7_15  connected_order_arc_928  -14
    arc_1_7_15  out_degree_1205  1
    arc_1_7_15  in_degree_1239  1
    arc_1_7_15  original_T_including_depot_unload_1278  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_927  1
    load_1_7_15  segment_load_conservation_1209  1
    load_1_7_15  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_929  -25
    arc_1_7_16  connected_order_arc_930  -14
    arc_1_7_16  out_degree_1205  1
    arc_1_7_16  in_degree_1245  1
    arc_1_7_16  original_T_including_depot_unload_1278  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_929  1
    load_1_7_16  segment_load_conservation_1209  1
    load_1_7_16  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_931  -25
    arc_1_7_17  connected_order_arc_932  -14
    arc_1_7_17  out_degree_1205  1
    arc_1_7_17  in_degree_1251  1
    arc_1_7_17  original_T_including_depot_unload_1278  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_931  1
    load_1_7_17  segment_load_conservation_1209  1
    load_1_7_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_933  -25
    arc_1_7_18  connected_order_arc_934  -14
    arc_1_7_18  out_degree_1205  1
    arc_1_7_18  in_degree_1257  1
    arc_1_7_18  original_T_including_depot_unload_1278  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_933  1
    load_1_7_18  segment_load_conservation_1209  1
    load_1_7_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_935  -25
    arc_1_7_19  connected_order_arc_936  -14
    arc_1_7_19  out_degree_1205  1
    arc_1_7_19  in_degree_1263  1
    arc_1_7_19  original_T_including_depot_unload_1278  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_935  1
    load_1_7_19  segment_load_conservation_1209  1
    load_1_7_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_937  -25
    arc_1_7_20  connected_order_arc_938  -14
    arc_1_7_20  out_degree_1205  1
    arc_1_7_20  in_degree_1269  1
    arc_1_7_20  original_T_including_depot_unload_1278  6.7959844792905335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_937  1
    load_1_7_20  segment_load_conservation_1209  1
    load_1_7_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_939  -25
    arc_1_8_0  depot_return_or_bypass_1190  1
    arc_1_8_0  out_degree_1212  1
    arc_1_8_0  original_T_including_depot_unload_1278  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_939  1
    load_1_8_0  segment_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_5  arc_capacity_940  -25
    arc_1_8_5  connected_order_arc_941  -14
    arc_1_8_5  in_degree_1192  1
    arc_1_8_5  out_degree_1212  1
    arc_1_8_5  original_T_including_depot_unload_1278  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_5  arc_capacity_940  1
    load_1_8_5  segment_load_conservation_1195  -1
    load_1_8_5  segment_prefix_lb_1196  1
    load_1_8_5  segment_prefix_ub_1197  1
    load_1_8_5  segment_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_942  -25
    arc_1_8_6  connected_order_arc_943  -14
    arc_1_8_6  in_degree_1199  1
    arc_1_8_6  out_degree_1212  1
    arc_1_8_6  original_T_including_depot_unload_1278  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_942  1
    load_1_8_6  segment_load_conservation_1202  -1
    load_1_8_6  segment_prefix_lb_1203  1
    load_1_8_6  segment_prefix_ub_1204  1
    load_1_8_6  segment_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_944  -25
    arc_1_8_7  connected_order_arc_945  -14
    arc_1_8_7  in_degree_1206  1
    arc_1_8_7  out_degree_1212  1
    arc_1_8_7  original_T_including_depot_unload_1278  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_944  1
    load_1_8_7  segment_load_conservation_1209  -1
    load_1_8_7  segment_prefix_lb_1210  1
    load_1_8_7  segment_prefix_ub_1211  1
    load_1_8_7  segment_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_946  -25
    arc_1_8_9  connected_order_arc_947  -14
    arc_1_8_9  out_degree_1212  1
    arc_1_8_9  in_degree_1220  1
    arc_1_8_9  original_T_including_depot_unload_1278  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_946  1
    load_1_8_9  segment_load_conservation_1216  1
    load_1_8_9  segment_load_conservation_1223  -1
    load_1_8_9  segment_prefix_lb_1224  1
    load_1_8_9  segment_prefix_ub_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_948  -25
    arc_1_8_13  connected_order_arc_949  -14
    arc_1_8_13  out_degree_1212  1
    arc_1_8_13  in_degree_1227  1
    arc_1_8_13  original_T_including_depot_unload_1278  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_948  1
    load_1_8_13  segment_load_conservation_1216  1
    load_1_8_13  free_load_conservation_1231  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_950  -25
    arc_1_8_14  connected_order_arc_951  -14
    arc_1_8_14  out_degree_1212  1
    arc_1_8_14  in_degree_1233  1
    arc_1_8_14  original_T_including_depot_unload_1278  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_950  1
    load_1_8_14  segment_load_conservation_1216  1
    load_1_8_14  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_952  -25
    arc_1_8_15  connected_order_arc_953  -14
    arc_1_8_15  out_degree_1212  1
    arc_1_8_15  in_degree_1239  1
    arc_1_8_15  original_T_including_depot_unload_1278  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_952  1
    load_1_8_15  segment_load_conservation_1216  1
    load_1_8_15  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_954  -25
    arc_1_8_16  connected_order_arc_955  -14
    arc_1_8_16  out_degree_1212  1
    arc_1_8_16  in_degree_1245  1
    arc_1_8_16  original_T_including_depot_unload_1278  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_954  1
    load_1_8_16  segment_load_conservation_1216  1
    load_1_8_16  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_956  -25
    arc_1_8_17  connected_order_arc_957  -14
    arc_1_8_17  out_degree_1212  1
    arc_1_8_17  in_degree_1251  1
    arc_1_8_17  original_T_including_depot_unload_1278  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_956  1
    load_1_8_17  segment_load_conservation_1216  1
    load_1_8_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_958  -25
    arc_1_8_18  connected_order_arc_959  -14
    arc_1_8_18  out_degree_1212  1
    arc_1_8_18  in_degree_1257  1
    arc_1_8_18  original_T_including_depot_unload_1278  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_958  1
    load_1_8_18  segment_load_conservation_1216  1
    load_1_8_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_960  -25
    arc_1_8_19  connected_order_arc_961  -14
    arc_1_8_19  out_degree_1212  1
    arc_1_8_19  in_degree_1263  1
    arc_1_8_19  original_T_including_depot_unload_1278  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_960  1
    load_1_8_19  segment_load_conservation_1216  1
    load_1_8_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_962  -25
    arc_1_8_20  connected_order_arc_963  -14
    arc_1_8_20  out_degree_1212  1
    arc_1_8_20  in_degree_1269  1
    arc_1_8_20  original_T_including_depot_unload_1278  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_962  1
    load_1_8_20  segment_load_conservation_1216  1
    load_1_8_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_964  -25
    arc_1_9_0  depot_return_or_bypass_1190  1
    arc_1_9_0  out_degree_1219  1
    arc_1_9_0  original_T_including_depot_unload_1278  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_964  1
    load_1_9_0  segment_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_5  arc_capacity_965  -25
    arc_1_9_5  connected_order_arc_966  -14
    arc_1_9_5  in_degree_1192  1
    arc_1_9_5  out_degree_1219  1
    arc_1_9_5  original_T_including_depot_unload_1278  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_5  arc_capacity_965  1
    load_1_9_5  segment_load_conservation_1195  -1
    load_1_9_5  segment_prefix_lb_1196  1
    load_1_9_5  segment_prefix_ub_1197  1
    load_1_9_5  segment_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_967  -25
    arc_1_9_6  connected_order_arc_968  -14
    arc_1_9_6  in_degree_1199  1
    arc_1_9_6  out_degree_1219  1
    arc_1_9_6  original_T_including_depot_unload_1278  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_967  1
    load_1_9_6  segment_load_conservation_1202  -1
    load_1_9_6  segment_prefix_lb_1203  1
    load_1_9_6  segment_prefix_ub_1204  1
    load_1_9_6  segment_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_969  -25
    arc_1_9_7  connected_order_arc_970  -14
    arc_1_9_7  in_degree_1206  1
    arc_1_9_7  out_degree_1219  1
    arc_1_9_7  original_T_including_depot_unload_1278  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_969  1
    load_1_9_7  segment_load_conservation_1209  -1
    load_1_9_7  segment_prefix_lb_1210  1
    load_1_9_7  segment_prefix_ub_1211  1
    load_1_9_7  segment_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_971  -25
    arc_1_9_8  connected_order_arc_972  -14
    arc_1_9_8  in_degree_1213  1
    arc_1_9_8  out_degree_1219  1
    arc_1_9_8  original_T_including_depot_unload_1278  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_971  1
    load_1_9_8  segment_load_conservation_1216  -1
    load_1_9_8  segment_prefix_lb_1217  1
    load_1_9_8  segment_prefix_ub_1218  1
    load_1_9_8  segment_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_973  -25
    arc_1_9_13  connected_order_arc_974  -14
    arc_1_9_13  out_degree_1219  1
    arc_1_9_13  in_degree_1227  1
    arc_1_9_13  original_T_including_depot_unload_1278  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_973  1
    load_1_9_13  segment_load_conservation_1223  1
    load_1_9_13  free_load_conservation_1231  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_975  -25
    arc_1_9_14  connected_order_arc_976  -14
    arc_1_9_14  out_degree_1219  1
    arc_1_9_14  in_degree_1233  1
    arc_1_9_14  original_T_including_depot_unload_1278  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_975  1
    load_1_9_14  segment_load_conservation_1223  1
    load_1_9_14  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_977  -25
    arc_1_9_15  connected_order_arc_978  -14
    arc_1_9_15  out_degree_1219  1
    arc_1_9_15  in_degree_1239  1
    arc_1_9_15  original_T_including_depot_unload_1278  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_977  1
    load_1_9_15  segment_load_conservation_1223  1
    load_1_9_15  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_979  -25
    arc_1_9_16  connected_order_arc_980  -14
    arc_1_9_16  out_degree_1219  1
    arc_1_9_16  in_degree_1245  1
    arc_1_9_16  original_T_including_depot_unload_1278  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_979  1
    load_1_9_16  segment_load_conservation_1223  1
    load_1_9_16  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_981  -25
    arc_1_9_17  connected_order_arc_982  -14
    arc_1_9_17  out_degree_1219  1
    arc_1_9_17  in_degree_1251  1
    arc_1_9_17  original_T_including_depot_unload_1278  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_981  1
    load_1_9_17  segment_load_conservation_1223  1
    load_1_9_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_983  -25
    arc_1_9_18  connected_order_arc_984  -14
    arc_1_9_18  out_degree_1219  1
    arc_1_9_18  in_degree_1257  1
    arc_1_9_18  original_T_including_depot_unload_1278  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_983  1
    load_1_9_18  segment_load_conservation_1223  1
    load_1_9_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_985  -25
    arc_1_9_19  connected_order_arc_986  -14
    arc_1_9_19  out_degree_1219  1
    arc_1_9_19  in_degree_1263  1
    arc_1_9_19  original_T_including_depot_unload_1278  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_985  1
    load_1_9_19  segment_load_conservation_1223  1
    load_1_9_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_987  -25
    arc_1_9_20  connected_order_arc_988  -14
    arc_1_9_20  out_degree_1219  1
    arc_1_9_20  in_degree_1269  1
    arc_1_9_20  original_T_including_depot_unload_1278  7.8590541298812059e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_987  1
    load_1_9_20  segment_load_conservation_1223  1
    load_1_9_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_989  -25
    arc_1_13_0  depot_return_or_bypass_1190  1
    arc_1_13_0  out_degree_1226  1
    arc_1_13_0  original_T_including_depot_unload_1278  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_989  1
    load_1_13_0  free_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_5  arc_capacity_990  -25
    arc_1_13_5  connected_order_arc_991  -14
    arc_1_13_5  in_degree_1192  1
    arc_1_13_5  out_degree_1226  1
    arc_1_13_5  original_T_including_depot_unload_1278  1.2876689365561549e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_5  arc_capacity_990  1
    load_1_13_5  segment_load_conservation_1195  -1
    load_1_13_5  segment_prefix_lb_1196  1
    load_1_13_5  segment_prefix_ub_1197  1
    load_1_13_5  free_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_992  -25
    arc_1_13_6  connected_order_arc_993  -14
    arc_1_13_6  in_degree_1199  1
    arc_1_13_6  out_degree_1226  1
    arc_1_13_6  original_T_including_depot_unload_1278  1.3840439316159188e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_992  1
    load_1_13_6  segment_load_conservation_1202  -1
    load_1_13_6  segment_prefix_lb_1203  1
    load_1_13_6  segment_prefix_ub_1204  1
    load_1_13_6  free_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_994  -25
    arc_1_13_7  connected_order_arc_995  -14
    arc_1_13_7  in_degree_1206  1
    arc_1_13_7  out_degree_1226  1
    arc_1_13_7  original_T_including_depot_unload_1278  8.5807018379884664e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_994  1
    load_1_13_7  segment_load_conservation_1209  -1
    load_1_13_7  segment_prefix_lb_1210  1
    load_1_13_7  segment_prefix_ub_1211  1
    load_1_13_7  free_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_996  -25
    arc_1_13_8  connected_order_arc_997  -14
    arc_1_13_8  in_degree_1213  1
    arc_1_13_8  out_degree_1226  1
    arc_1_13_8  original_T_including_depot_unload_1278  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_996  1
    load_1_13_8  segment_load_conservation_1216  -1
    load_1_13_8  segment_prefix_lb_1217  1
    load_1_13_8  segment_prefix_ub_1218  1
    load_1_13_8  free_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_998  -25
    arc_1_13_9  connected_order_arc_999  -14
    arc_1_13_9  in_degree_1220  1
    arc_1_13_9  out_degree_1226  1
    arc_1_13_9  original_T_including_depot_unload_1278  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_998  1
    load_1_13_9  segment_load_conservation_1223  -1
    load_1_13_9  segment_prefix_lb_1224  1
    load_1_13_9  segment_prefix_ub_1225  1
    load_1_13_9  free_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_1000  -25
    arc_1_13_14  connected_order_arc_1001  -14
    arc_1_13_14  out_degree_1226  1
    arc_1_13_14  in_degree_1233  1
    arc_1_13_14  original_T_including_depot_unload_1278  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_1000  1
    load_1_13_14  free_load_conservation_1231  1
    load_1_13_14  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_1002  -25
    arc_1_13_15  connected_order_arc_1003  -14
    arc_1_13_15  out_degree_1226  1
    arc_1_13_15  in_degree_1239  1
    arc_1_13_15  original_T_including_depot_unload_1278  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_1002  1
    load_1_13_15  free_load_conservation_1231  1
    load_1_13_15  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_1004  -25
    arc_1_13_16  connected_order_arc_1005  -14
    arc_1_13_16  out_degree_1226  1
    arc_1_13_16  in_degree_1245  1
    arc_1_13_16  original_T_including_depot_unload_1278  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_1004  1
    load_1_13_16  free_load_conservation_1231  1
    load_1_13_16  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_1006  -25
    arc_1_13_17  connected_order_arc_1007  -14
    arc_1_13_17  out_degree_1226  1
    arc_1_13_17  in_degree_1251  1
    arc_1_13_17  original_T_including_depot_unload_1278  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_1006  1
    load_1_13_17  free_load_conservation_1231  1
    load_1_13_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_1008  -25
    arc_1_13_18  connected_order_arc_1009  -14
    arc_1_13_18  out_degree_1226  1
    arc_1_13_18  in_degree_1257  1
    arc_1_13_18  original_T_including_depot_unload_1278  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_1008  1
    load_1_13_18  free_load_conservation_1231  1
    load_1_13_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_1010  -25
    arc_1_13_19  connected_order_arc_1011  -14
    arc_1_13_19  out_degree_1226  1
    arc_1_13_19  in_degree_1263  1
    arc_1_13_19  original_T_including_depot_unload_1278  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_1010  1
    load_1_13_19  free_load_conservation_1231  1
    load_1_13_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_20  arc_capacity_1012  -25
    arc_1_13_20  connected_order_arc_1013  -14
    arc_1_13_20  out_degree_1226  1
    arc_1_13_20  in_degree_1269  1
    arc_1_13_20  original_T_including_depot_unload_1278  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_20  arc_capacity_1012  1
    load_1_13_20  free_load_conservation_1231  1
    load_1_13_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1014  -25
    arc_1_14_0  depot_return_or_bypass_1190  1
    arc_1_14_0  out_degree_1232  1
    arc_1_14_0  original_T_including_depot_unload_1278  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1014  1
    load_1_14_0  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_5  arc_capacity_1015  -25
    arc_1_14_5  connected_order_arc_1016  -14
    arc_1_14_5  in_degree_1192  1
    arc_1_14_5  out_degree_1232  1
    arc_1_14_5  original_T_including_depot_unload_1278  1.2798962893775918e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_5  arc_capacity_1015  1
    load_1_14_5  segment_load_conservation_1195  -1
    load_1_14_5  segment_prefix_lb_1196  1
    load_1_14_5  segment_prefix_ub_1197  1
    load_1_14_5  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_1017  -25
    arc_1_14_6  connected_order_arc_1018  -14
    arc_1_14_6  in_degree_1199  1
    arc_1_14_6  out_degree_1232  1
    arc_1_14_6  original_T_including_depot_unload_1278  1.3293032990949939e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_1017  1
    load_1_14_6  segment_load_conservation_1202  -1
    load_1_14_6  segment_prefix_lb_1203  1
    load_1_14_6  segment_prefix_ub_1204  1
    load_1_14_6  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_1019  -25
    arc_1_14_7  connected_order_arc_1020  -14
    arc_1_14_7  in_degree_1206  1
    arc_1_14_7  out_degree_1232  1
    arc_1_14_7  original_T_including_depot_unload_1278  9.4424191477021122e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_1019  1
    load_1_14_7  segment_load_conservation_1209  -1
    load_1_14_7  segment_prefix_lb_1210  1
    load_1_14_7  segment_prefix_ub_1211  1
    load_1_14_7  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_1021  -25
    arc_1_14_8  connected_order_arc_1022  -14
    arc_1_14_8  in_degree_1213  1
    arc_1_14_8  out_degree_1232  1
    arc_1_14_8  original_T_including_depot_unload_1278  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_1021  1
    load_1_14_8  segment_load_conservation_1216  -1
    load_1_14_8  segment_prefix_lb_1217  1
    load_1_14_8  segment_prefix_ub_1218  1
    load_1_14_8  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1023  -25
    arc_1_14_9  connected_order_arc_1024  -14
    arc_1_14_9  in_degree_1220  1
    arc_1_14_9  out_degree_1232  1
    arc_1_14_9  original_T_including_depot_unload_1278  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1023  1
    load_1_14_9  segment_load_conservation_1223  -1
    load_1_14_9  segment_prefix_lb_1224  1
    load_1_14_9  segment_prefix_ub_1225  1
    load_1_14_9  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_1025  -25
    arc_1_14_13  connected_order_arc_1026  -14
    arc_1_14_13  in_degree_1227  1
    arc_1_14_13  out_degree_1232  1
    arc_1_14_13  original_T_including_depot_unload_1278  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_1025  1
    load_1_14_13  free_load_conservation_1231  -1
    load_1_14_13  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1027  -25
    arc_1_14_15  connected_order_arc_1028  -14
    arc_1_14_15  out_degree_1232  1
    arc_1_14_15  in_degree_1239  1
    arc_1_14_15  original_T_including_depot_unload_1278  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1027  1
    load_1_14_15  free_load_conservation_1237  1
    load_1_14_15  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1029  -25
    arc_1_14_16  connected_order_arc_1030  -14
    arc_1_14_16  out_degree_1232  1
    arc_1_14_16  in_degree_1245  1
    arc_1_14_16  original_T_including_depot_unload_1278  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1029  1
    load_1_14_16  free_load_conservation_1237  1
    load_1_14_16  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_1031  -25
    arc_1_14_17  connected_order_arc_1032  -14
    arc_1_14_17  out_degree_1232  1
    arc_1_14_17  in_degree_1251  1
    arc_1_14_17  original_T_including_depot_unload_1278  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_1031  1
    load_1_14_17  free_load_conservation_1237  1
    load_1_14_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_1033  -25
    arc_1_14_18  connected_order_arc_1034  -14
    arc_1_14_18  out_degree_1232  1
    arc_1_14_18  in_degree_1257  1
    arc_1_14_18  original_T_including_depot_unload_1278  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_1033  1
    load_1_14_18  free_load_conservation_1237  1
    load_1_14_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_1035  -25
    arc_1_14_19  connected_order_arc_1036  -14
    arc_1_14_19  out_degree_1232  1
    arc_1_14_19  in_degree_1263  1
    arc_1_14_19  original_T_including_depot_unload_1278  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_1035  1
    load_1_14_19  free_load_conservation_1237  1
    load_1_14_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_1037  -25
    arc_1_14_20  connected_order_arc_1038  -14
    arc_1_14_20  out_degree_1232  1
    arc_1_14_20  in_degree_1269  1
    arc_1_14_20  original_T_including_depot_unload_1278  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_1037  1
    load_1_14_20  free_load_conservation_1237  1
    load_1_14_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1039  -25
    arc_1_15_0  depot_return_or_bypass_1190  1
    arc_1_15_0  out_degree_1238  1
    arc_1_15_0  original_T_including_depot_unload_1278  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1039  1
    load_1_15_0  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_5  arc_capacity_1040  -25
    arc_1_15_5  connected_order_arc_1041  -14
    arc_1_15_5  in_degree_1192  1
    arc_1_15_5  out_degree_1238  1
    arc_1_15_5  original_T_including_depot_unload_1278  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_5  arc_capacity_1040  1
    load_1_15_5  segment_load_conservation_1195  -1
    load_1_15_5  segment_prefix_lb_1196  1
    load_1_15_5  segment_prefix_ub_1197  1
    load_1_15_5  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_1042  -25
    arc_1_15_6  connected_order_arc_1043  -14
    arc_1_15_6  in_degree_1199  1
    arc_1_15_6  out_degree_1238  1
    arc_1_15_6  original_T_including_depot_unload_1278  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_1042  1
    load_1_15_6  segment_load_conservation_1202  -1
    load_1_15_6  segment_prefix_lb_1203  1
    load_1_15_6  segment_prefix_ub_1204  1
    load_1_15_6  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1044  -25
    arc_1_15_7  connected_order_arc_1045  -14
    arc_1_15_7  in_degree_1206  1
    arc_1_15_7  out_degree_1238  1
    arc_1_15_7  original_T_including_depot_unload_1278  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1044  1
    load_1_15_7  segment_load_conservation_1209  -1
    load_1_15_7  segment_prefix_lb_1210  1
    load_1_15_7  segment_prefix_ub_1211  1
    load_1_15_7  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1046  -25
    arc_1_15_8  connected_order_arc_1047  -14
    arc_1_15_8  in_degree_1213  1
    arc_1_15_8  out_degree_1238  1
    arc_1_15_8  original_T_including_depot_unload_1278  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1046  1
    load_1_15_8  segment_load_conservation_1216  -1
    load_1_15_8  segment_prefix_lb_1217  1
    load_1_15_8  segment_prefix_ub_1218  1
    load_1_15_8  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1048  -25
    arc_1_15_9  connected_order_arc_1049  -14
    arc_1_15_9  in_degree_1220  1
    arc_1_15_9  out_degree_1238  1
    arc_1_15_9  original_T_including_depot_unload_1278  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1048  1
    load_1_15_9  segment_load_conservation_1223  -1
    load_1_15_9  segment_prefix_lb_1224  1
    load_1_15_9  segment_prefix_ub_1225  1
    load_1_15_9  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_1050  -25
    arc_1_15_13  connected_order_arc_1051  -14
    arc_1_15_13  in_degree_1227  1
    arc_1_15_13  out_degree_1238  1
    arc_1_15_13  original_T_including_depot_unload_1278  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_1050  1
    load_1_15_13  free_load_conservation_1231  -1
    load_1_15_13  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1052  -25
    arc_1_15_14  connected_order_arc_1053  -14
    arc_1_15_14  in_degree_1233  1
    arc_1_15_14  out_degree_1238  1
    arc_1_15_14  original_T_including_depot_unload_1278  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1052  1
    load_1_15_14  free_load_conservation_1237  -1
    load_1_15_14  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1054  -25
    arc_1_15_16  connected_order_arc_1055  -14
    arc_1_15_16  out_degree_1238  1
    arc_1_15_16  in_degree_1245  1
    arc_1_15_16  original_T_including_depot_unload_1278  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1054  1
    load_1_15_16  free_load_conservation_1243  1
    load_1_15_16  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1056  -25
    arc_1_15_17  connected_order_arc_1057  -14
    arc_1_15_17  out_degree_1238  1
    arc_1_15_17  in_degree_1251  1
    arc_1_15_17  original_T_including_depot_unload_1278  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1056  1
    load_1_15_17  free_load_conservation_1243  1
    load_1_15_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1058  -25
    arc_1_15_18  connected_order_arc_1059  -14
    arc_1_15_18  out_degree_1238  1
    arc_1_15_18  in_degree_1257  1
    arc_1_15_18  original_T_including_depot_unload_1278  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1058  1
    load_1_15_18  free_load_conservation_1243  1
    load_1_15_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1060  -25
    arc_1_15_19  connected_order_arc_1061  -14
    arc_1_15_19  out_degree_1238  1
    arc_1_15_19  in_degree_1263  1
    arc_1_15_19  original_T_including_depot_unload_1278  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1060  1
    load_1_15_19  free_load_conservation_1243  1
    load_1_15_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1062  -25
    arc_1_15_20  connected_order_arc_1063  -14
    arc_1_15_20  out_degree_1238  1
    arc_1_15_20  in_degree_1269  1
    arc_1_15_20  original_T_including_depot_unload_1278  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1062  1
    load_1_15_20  free_load_conservation_1243  1
    load_1_15_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1064  -25
    arc_1_16_0  depot_return_or_bypass_1190  1
    arc_1_16_0  out_degree_1244  1
    arc_1_16_0  original_T_including_depot_unload_1278  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1064  1
    load_1_16_0  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_5  arc_capacity_1065  -25
    arc_1_16_5  connected_order_arc_1066  -14
    arc_1_16_5  in_degree_1192  1
    arc_1_16_5  out_degree_1244  1
    arc_1_16_5  original_T_including_depot_unload_1278  1.1017171222416982e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_5  arc_capacity_1065  1
    load_1_16_5  segment_load_conservation_1195  -1
    load_1_16_5  segment_prefix_lb_1196  1
    load_1_16_5  segment_prefix_ub_1197  1
    load_1_16_5  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_1067  -25
    arc_1_16_6  connected_order_arc_1068  -14
    arc_1_16_6  in_degree_1199  1
    arc_1_16_6  out_degree_1244  1
    arc_1_16_6  original_T_including_depot_unload_1278  1.2434091529834902e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_1067  1
    load_1_16_6  segment_load_conservation_1202  -1
    load_1_16_6  segment_prefix_lb_1203  1
    load_1_16_6  segment_prefix_ub_1204  1
    load_1_16_6  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1069  -25
    arc_1_16_7  connected_order_arc_1070  -14
    arc_1_16_7  in_degree_1206  1
    arc_1_16_7  out_degree_1244  1
    arc_1_16_7  original_T_including_depot_unload_1278  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1069  1
    load_1_16_7  segment_load_conservation_1209  -1
    load_1_16_7  segment_prefix_lb_1210  1
    load_1_16_7  segment_prefix_ub_1211  1
    load_1_16_7  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1071  -25
    arc_1_16_8  connected_order_arc_1072  -14
    arc_1_16_8  in_degree_1213  1
    arc_1_16_8  out_degree_1244  1
    arc_1_16_8  original_T_including_depot_unload_1278  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1071  1
    load_1_16_8  segment_load_conservation_1216  -1
    load_1_16_8  segment_prefix_lb_1217  1
    load_1_16_8  segment_prefix_ub_1218  1
    load_1_16_8  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1073  -25
    arc_1_16_9  connected_order_arc_1074  -14
    arc_1_16_9  in_degree_1220  1
    arc_1_16_9  out_degree_1244  1
    arc_1_16_9  original_T_including_depot_unload_1278  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1073  1
    load_1_16_9  segment_load_conservation_1223  -1
    load_1_16_9  segment_prefix_lb_1224  1
    load_1_16_9  segment_prefix_ub_1225  1
    load_1_16_9  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1075  -25
    arc_1_16_13  connected_order_arc_1076  -14
    arc_1_16_13  in_degree_1227  1
    arc_1_16_13  out_degree_1244  1
    arc_1_16_13  original_T_including_depot_unload_1278  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1075  1
    load_1_16_13  free_load_conservation_1231  -1
    load_1_16_13  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1077  -25
    arc_1_16_14  connected_order_arc_1078  -14
    arc_1_16_14  in_degree_1233  1
    arc_1_16_14  out_degree_1244  1
    arc_1_16_14  original_T_including_depot_unload_1278  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1077  1
    load_1_16_14  free_load_conservation_1237  -1
    load_1_16_14  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1079  -25
    arc_1_16_15  connected_order_arc_1080  -14
    arc_1_16_15  in_degree_1239  1
    arc_1_16_15  out_degree_1244  1
    arc_1_16_15  original_T_including_depot_unload_1278  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1079  1
    load_1_16_15  free_load_conservation_1243  -1
    load_1_16_15  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1081  -25
    arc_1_16_17  connected_order_arc_1082  -14
    arc_1_16_17  out_degree_1244  1
    arc_1_16_17  in_degree_1251  1
    arc_1_16_17  original_T_including_depot_unload_1278  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1081  1
    load_1_16_17  free_load_conservation_1249  1
    load_1_16_17  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1083  -25
    arc_1_16_18  connected_order_arc_1084  -14
    arc_1_16_18  out_degree_1244  1
    arc_1_16_18  in_degree_1257  1
    arc_1_16_18  original_T_including_depot_unload_1278  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1083  1
    load_1_16_18  free_load_conservation_1249  1
    load_1_16_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1085  -25
    arc_1_16_19  connected_order_arc_1086  -14
    arc_1_16_19  out_degree_1244  1
    arc_1_16_19  in_degree_1263  1
    arc_1_16_19  original_T_including_depot_unload_1278  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1085  1
    load_1_16_19  free_load_conservation_1249  1
    load_1_16_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1087  -25
    arc_1_16_20  connected_order_arc_1088  -14
    arc_1_16_20  out_degree_1244  1
    arc_1_16_20  in_degree_1269  1
    arc_1_16_20  original_T_including_depot_unload_1278  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1087  1
    load_1_16_20  free_load_conservation_1249  1
    load_1_16_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1089  -25
    arc_1_17_0  depot_return_or_bypass_1190  1
    arc_1_17_0  out_degree_1250  1
    arc_1_17_0  original_T_including_depot_unload_1278  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1089  1
    load_1_17_0  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_5  arc_capacity_1090  -25
    arc_1_17_5  connected_order_arc_1091  -14
    arc_1_17_5  in_degree_1192  1
    arc_1_17_5  out_degree_1250  1
    arc_1_17_5  original_T_including_depot_unload_1278  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_5  arc_capacity_1090  1
    load_1_17_5  segment_load_conservation_1195  -1
    load_1_17_5  segment_prefix_lb_1196  1
    load_1_17_5  segment_prefix_ub_1197  1
    load_1_17_5  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1092  -25
    arc_1_17_6  connected_order_arc_1093  -14
    arc_1_17_6  in_degree_1199  1
    arc_1_17_6  out_degree_1250  1
    arc_1_17_6  original_T_including_depot_unload_1278  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1092  1
    load_1_17_6  segment_load_conservation_1202  -1
    load_1_17_6  segment_prefix_lb_1203  1
    load_1_17_6  segment_prefix_ub_1204  1
    load_1_17_6  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1094  -25
    arc_1_17_7  connected_order_arc_1095  -14
    arc_1_17_7  in_degree_1206  1
    arc_1_17_7  out_degree_1250  1
    arc_1_17_7  original_T_including_depot_unload_1278  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1094  1
    load_1_17_7  segment_load_conservation_1209  -1
    load_1_17_7  segment_prefix_lb_1210  1
    load_1_17_7  segment_prefix_ub_1211  1
    load_1_17_7  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1096  -25
    arc_1_17_8  connected_order_arc_1097  -14
    arc_1_17_8  in_degree_1213  1
    arc_1_17_8  out_degree_1250  1
    arc_1_17_8  original_T_including_depot_unload_1278  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1096  1
    load_1_17_8  segment_load_conservation_1216  -1
    load_1_17_8  segment_prefix_lb_1217  1
    load_1_17_8  segment_prefix_ub_1218  1
    load_1_17_8  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1098  -25
    arc_1_17_9  connected_order_arc_1099  -14
    arc_1_17_9  in_degree_1220  1
    arc_1_17_9  out_degree_1250  1
    arc_1_17_9  original_T_including_depot_unload_1278  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1098  1
    load_1_17_9  segment_load_conservation_1223  -1
    load_1_17_9  segment_prefix_lb_1224  1
    load_1_17_9  segment_prefix_ub_1225  1
    load_1_17_9  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_1100  -25
    arc_1_17_13  connected_order_arc_1101  -14
    arc_1_17_13  in_degree_1227  1
    arc_1_17_13  out_degree_1250  1
    arc_1_17_13  original_T_including_depot_unload_1278  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_1100  1
    load_1_17_13  free_load_conservation_1231  -1
    load_1_17_13  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1102  -25
    arc_1_17_14  connected_order_arc_1103  -14
    arc_1_17_14  in_degree_1233  1
    arc_1_17_14  out_degree_1250  1
    arc_1_17_14  original_T_including_depot_unload_1278  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1102  1
    load_1_17_14  free_load_conservation_1237  -1
    load_1_17_14  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1104  -25
    arc_1_17_15  connected_order_arc_1105  -14
    arc_1_17_15  in_degree_1239  1
    arc_1_17_15  out_degree_1250  1
    arc_1_17_15  original_T_including_depot_unload_1278  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1104  1
    load_1_17_15  free_load_conservation_1243  -1
    load_1_17_15  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1106  -25
    arc_1_17_16  connected_order_arc_1107  -14
    arc_1_17_16  in_degree_1245  1
    arc_1_17_16  out_degree_1250  1
    arc_1_17_16  original_T_including_depot_unload_1278  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1106  1
    load_1_17_16  free_load_conservation_1249  -1
    load_1_17_16  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1108  -25
    arc_1_17_18  connected_order_arc_1109  -14
    arc_1_17_18  out_degree_1250  1
    arc_1_17_18  in_degree_1257  1
    arc_1_17_18  original_T_including_depot_unload_1278  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1108  1
    load_1_17_18  free_load_conservation_1255  1
    load_1_17_18  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1110  -25
    arc_1_17_19  connected_order_arc_1111  -14
    arc_1_17_19  out_degree_1250  1
    arc_1_17_19  in_degree_1263  1
    arc_1_17_19  original_T_including_depot_unload_1278  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1110  1
    load_1_17_19  free_load_conservation_1255  1
    load_1_17_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1112  -25
    arc_1_17_20  connected_order_arc_1113  -14
    arc_1_17_20  out_degree_1250  1
    arc_1_17_20  in_degree_1269  1
    arc_1_17_20  original_T_including_depot_unload_1278  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1112  1
    load_1_17_20  free_load_conservation_1255  1
    load_1_17_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1114  -25
    arc_1_18_0  depot_return_or_bypass_1190  1
    arc_1_18_0  out_degree_1256  1
    arc_1_18_0  original_T_including_depot_unload_1278  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1114  1
    load_1_18_0  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_5  arc_capacity_1115  -25
    arc_1_18_5  connected_order_arc_1116  -14
    arc_1_18_5  in_degree_1192  1
    arc_1_18_5  out_degree_1256  1
    arc_1_18_5  original_T_including_depot_unload_1278  1.0170488276971105e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_5  arc_capacity_1115  1
    load_1_18_5  segment_load_conservation_1195  -1
    load_1_18_5  segment_prefix_lb_1196  1
    load_1_18_5  segment_prefix_ub_1197  1
    load_1_18_5  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1117  -25
    arc_1_18_6  connected_order_arc_1118  -14
    arc_1_18_6  in_degree_1199  1
    arc_1_18_6  out_degree_1256  1
    arc_1_18_6  original_T_including_depot_unload_1278  1.0988088346747072e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1117  1
    load_1_18_6  segment_load_conservation_1202  -1
    load_1_18_6  segment_prefix_lb_1203  1
    load_1_18_6  segment_prefix_ub_1204  1
    load_1_18_6  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1119  -25
    arc_1_18_7  connected_order_arc_1120  -14
    arc_1_18_7  in_degree_1206  1
    arc_1_18_7  out_degree_1256  1
    arc_1_18_7  original_T_including_depot_unload_1278  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1119  1
    load_1_18_7  segment_load_conservation_1209  -1
    load_1_18_7  segment_prefix_lb_1210  1
    load_1_18_7  segment_prefix_ub_1211  1
    load_1_18_7  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1121  -25
    arc_1_18_8  connected_order_arc_1122  -14
    arc_1_18_8  in_degree_1213  1
    arc_1_18_8  out_degree_1256  1
    arc_1_18_8  original_T_including_depot_unload_1278  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1121  1
    load_1_18_8  segment_load_conservation_1216  -1
    load_1_18_8  segment_prefix_lb_1217  1
    load_1_18_8  segment_prefix_ub_1218  1
    load_1_18_8  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1123  -25
    arc_1_18_9  connected_order_arc_1124  -14
    arc_1_18_9  in_degree_1220  1
    arc_1_18_9  out_degree_1256  1
    arc_1_18_9  original_T_including_depot_unload_1278  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1123  1
    load_1_18_9  segment_load_conservation_1223  -1
    load_1_18_9  segment_prefix_lb_1224  1
    load_1_18_9  segment_prefix_ub_1225  1
    load_1_18_9  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1125  -25
    arc_1_18_13  connected_order_arc_1126  -14
    arc_1_18_13  in_degree_1227  1
    arc_1_18_13  out_degree_1256  1
    arc_1_18_13  original_T_including_depot_unload_1278  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1125  1
    load_1_18_13  free_load_conservation_1231  -1
    load_1_18_13  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1127  -25
    arc_1_18_14  connected_order_arc_1128  -14
    arc_1_18_14  in_degree_1233  1
    arc_1_18_14  out_degree_1256  1
    arc_1_18_14  original_T_including_depot_unload_1278  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1127  1
    load_1_18_14  free_load_conservation_1237  -1
    load_1_18_14  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1129  -25
    arc_1_18_15  connected_order_arc_1130  -14
    arc_1_18_15  in_degree_1239  1
    arc_1_18_15  out_degree_1256  1
    arc_1_18_15  original_T_including_depot_unload_1278  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1129  1
    load_1_18_15  free_load_conservation_1243  -1
    load_1_18_15  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1131  -25
    arc_1_18_16  connected_order_arc_1132  -14
    arc_1_18_16  in_degree_1245  1
    arc_1_18_16  out_degree_1256  1
    arc_1_18_16  original_T_including_depot_unload_1278  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1131  1
    load_1_18_16  free_load_conservation_1249  -1
    load_1_18_16  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1133  -25
    arc_1_18_17  connected_order_arc_1134  -14
    arc_1_18_17  in_degree_1251  1
    arc_1_18_17  out_degree_1256  1
    arc_1_18_17  original_T_including_depot_unload_1278  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1133  1
    load_1_18_17  free_load_conservation_1255  -1
    load_1_18_17  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1135  -25
    arc_1_18_19  connected_order_arc_1136  -14
    arc_1_18_19  out_degree_1256  1
    arc_1_18_19  in_degree_1263  1
    arc_1_18_19  original_T_including_depot_unload_1278  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1135  1
    load_1_18_19  free_load_conservation_1261  1
    load_1_18_19  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1137  -25
    arc_1_18_20  connected_order_arc_1138  -14
    arc_1_18_20  out_degree_1256  1
    arc_1_18_20  in_degree_1269  1
    arc_1_18_20  original_T_including_depot_unload_1278  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1137  1
    load_1_18_20  free_load_conservation_1261  1
    load_1_18_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1139  -25
    arc_1_19_0  depot_return_or_bypass_1190  1
    arc_1_19_0  out_degree_1262  1
    arc_1_19_0  original_T_including_depot_unload_1278  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1139  1
    load_1_19_0  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_5  arc_capacity_1140  -25
    arc_1_19_5  connected_order_arc_1141  -14
    arc_1_19_5  in_degree_1192  1
    arc_1_19_5  out_degree_1262  1
    arc_1_19_5  original_T_including_depot_unload_1278  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_5  arc_capacity_1140  1
    load_1_19_5  segment_load_conservation_1195  -1
    load_1_19_5  segment_prefix_lb_1196  1
    load_1_19_5  segment_prefix_ub_1197  1
    load_1_19_5  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1142  -25
    arc_1_19_6  connected_order_arc_1143  -14
    arc_1_19_6  in_degree_1199  1
    arc_1_19_6  out_degree_1262  1
    arc_1_19_6  original_T_including_depot_unload_1278  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1142  1
    load_1_19_6  segment_load_conservation_1202  -1
    load_1_19_6  segment_prefix_lb_1203  1
    load_1_19_6  segment_prefix_ub_1204  1
    load_1_19_6  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1144  -25
    arc_1_19_7  connected_order_arc_1145  -14
    arc_1_19_7  in_degree_1206  1
    arc_1_19_7  out_degree_1262  1
    arc_1_19_7  original_T_including_depot_unload_1278  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1144  1
    load_1_19_7  segment_load_conservation_1209  -1
    load_1_19_7  segment_prefix_lb_1210  1
    load_1_19_7  segment_prefix_ub_1211  1
    load_1_19_7  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1146  -25
    arc_1_19_8  connected_order_arc_1147  -14
    arc_1_19_8  in_degree_1213  1
    arc_1_19_8  out_degree_1262  1
    arc_1_19_8  original_T_including_depot_unload_1278  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1146  1
    load_1_19_8  segment_load_conservation_1216  -1
    load_1_19_8  segment_prefix_lb_1217  1
    load_1_19_8  segment_prefix_ub_1218  1
    load_1_19_8  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1148  -25
    arc_1_19_9  connected_order_arc_1149  -14
    arc_1_19_9  in_degree_1220  1
    arc_1_19_9  out_degree_1262  1
    arc_1_19_9  original_T_including_depot_unload_1278  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1148  1
    load_1_19_9  segment_load_conservation_1223  -1
    load_1_19_9  segment_prefix_lb_1224  1
    load_1_19_9  segment_prefix_ub_1225  1
    load_1_19_9  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_1150  -25
    arc_1_19_13  connected_order_arc_1151  -14
    arc_1_19_13  in_degree_1227  1
    arc_1_19_13  out_degree_1262  1
    arc_1_19_13  original_T_including_depot_unload_1278  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_1150  1
    load_1_19_13  free_load_conservation_1231  -1
    load_1_19_13  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1152  -25
    arc_1_19_14  connected_order_arc_1153  -14
    arc_1_19_14  in_degree_1233  1
    arc_1_19_14  out_degree_1262  1
    arc_1_19_14  original_T_including_depot_unload_1278  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1152  1
    load_1_19_14  free_load_conservation_1237  -1
    load_1_19_14  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1154  -25
    arc_1_19_15  connected_order_arc_1155  -14
    arc_1_19_15  in_degree_1239  1
    arc_1_19_15  out_degree_1262  1
    arc_1_19_15  original_T_including_depot_unload_1278  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1154  1
    load_1_19_15  free_load_conservation_1243  -1
    load_1_19_15  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1156  -25
    arc_1_19_16  connected_order_arc_1157  -14
    arc_1_19_16  in_degree_1245  1
    arc_1_19_16  out_degree_1262  1
    arc_1_19_16  original_T_including_depot_unload_1278  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1156  1
    load_1_19_16  free_load_conservation_1249  -1
    load_1_19_16  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1158  -25
    arc_1_19_17  connected_order_arc_1159  -14
    arc_1_19_17  in_degree_1251  1
    arc_1_19_17  out_degree_1262  1
    arc_1_19_17  original_T_including_depot_unload_1278  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1158  1
    load_1_19_17  free_load_conservation_1255  -1
    load_1_19_17  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1160  -25
    arc_1_19_18  connected_order_arc_1161  -14
    arc_1_19_18  in_degree_1257  1
    arc_1_19_18  out_degree_1262  1
    arc_1_19_18  original_T_including_depot_unload_1278  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1160  1
    load_1_19_18  free_load_conservation_1261  -1
    load_1_19_18  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1162  -25
    arc_1_19_20  connected_order_arc_1163  -14
    arc_1_19_20  out_degree_1262  1
    arc_1_19_20  in_degree_1269  1
    arc_1_19_20  original_T_including_depot_unload_1278  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1162  1
    load_1_19_20  free_load_conservation_1267  1
    load_1_19_20  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1164  -25
    arc_1_20_0  depot_return_or_bypass_1190  1
    arc_1_20_0  out_degree_1268  1
    arc_1_20_0  original_T_including_depot_unload_1278  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1164  1
    load_1_20_0  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_5  arc_capacity_1165  -25
    arc_1_20_5  connected_order_arc_1166  -14
    arc_1_20_5  in_degree_1192  1
    arc_1_20_5  out_degree_1268  1
    arc_1_20_5  original_T_including_depot_unload_1278  1.2608023164150941e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_5  arc_capacity_1165  1
    load_1_20_5  segment_load_conservation_1195  -1
    load_1_20_5  segment_prefix_lb_1196  1
    load_1_20_5  segment_prefix_ub_1197  1
    load_1_20_5  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1167  -25
    arc_1_20_6  connected_order_arc_1168  -14
    arc_1_20_6  in_degree_1199  1
    arc_1_20_6  out_degree_1268  1
    arc_1_20_6  original_T_including_depot_unload_1278  1.4394323281782954e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1167  1
    load_1_20_6  segment_load_conservation_1202  -1
    load_1_20_6  segment_prefix_lb_1203  1
    load_1_20_6  segment_prefix_ub_1204  1
    load_1_20_6  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1169  -25
    arc_1_20_7  connected_order_arc_1170  -14
    arc_1_20_7  in_degree_1206  1
    arc_1_20_7  out_degree_1268  1
    arc_1_20_7  original_T_including_depot_unload_1278  6.7959844792905335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1169  1
    load_1_20_7  segment_load_conservation_1209  -1
    load_1_20_7  segment_prefix_lb_1210  1
    load_1_20_7  segment_prefix_ub_1211  1
    load_1_20_7  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1171  -25
    arc_1_20_8  connected_order_arc_1172  -14
    arc_1_20_8  in_degree_1213  1
    arc_1_20_8  out_degree_1268  1
    arc_1_20_8  original_T_including_depot_unload_1278  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1171  1
    load_1_20_8  segment_load_conservation_1216  -1
    load_1_20_8  segment_prefix_lb_1217  1
    load_1_20_8  segment_prefix_ub_1218  1
    load_1_20_8  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1173  -25
    arc_1_20_9  connected_order_arc_1174  -14
    arc_1_20_9  in_degree_1220  1
    arc_1_20_9  out_degree_1268  1
    arc_1_20_9  original_T_including_depot_unload_1278  7.8590541298812059e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1173  1
    load_1_20_9  segment_load_conservation_1223  -1
    load_1_20_9  segment_prefix_lb_1224  1
    load_1_20_9  segment_prefix_ub_1225  1
    load_1_20_9  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_13  arc_capacity_1175  -25
    arc_1_20_13  connected_order_arc_1176  -14
    arc_1_20_13  in_degree_1227  1
    arc_1_20_13  out_degree_1268  1
    arc_1_20_13  original_T_including_depot_unload_1278  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_13  arc_capacity_1175  1
    load_1_20_13  free_load_conservation_1231  -1
    load_1_20_13  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1177  -25
    arc_1_20_14  connected_order_arc_1178  -14
    arc_1_20_14  in_degree_1233  1
    arc_1_20_14  out_degree_1268  1
    arc_1_20_14  original_T_including_depot_unload_1278  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1177  1
    load_1_20_14  free_load_conservation_1237  -1
    load_1_20_14  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1179  -25
    arc_1_20_15  connected_order_arc_1180  -14
    arc_1_20_15  in_degree_1239  1
    arc_1_20_15  out_degree_1268  1
    arc_1_20_15  original_T_including_depot_unload_1278  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1179  1
    load_1_20_15  free_load_conservation_1243  -1
    load_1_20_15  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1181  -25
    arc_1_20_16  connected_order_arc_1182  -14
    arc_1_20_16  in_degree_1245  1
    arc_1_20_16  out_degree_1268  1
    arc_1_20_16  original_T_including_depot_unload_1278  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1181  1
    load_1_20_16  free_load_conservation_1249  -1
    load_1_20_16  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1183  -25
    arc_1_20_17  connected_order_arc_1184  -14
    arc_1_20_17  in_degree_1251  1
    arc_1_20_17  out_degree_1268  1
    arc_1_20_17  original_T_including_depot_unload_1278  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1183  1
    load_1_20_17  free_load_conservation_1255  -1
    load_1_20_17  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1185  -25
    arc_1_20_18  connected_order_arc_1186  -14
    arc_1_20_18  in_degree_1257  1
    arc_1_20_18  out_degree_1268  1
    arc_1_20_18  original_T_including_depot_unload_1278  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1185  1
    load_1_20_18  free_load_conservation_1261  -1
    load_1_20_18  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1187  -25
    arc_1_20_19  connected_order_arc_1188  -14
    arc_1_20_19  in_degree_1263  1
    arc_1_20_19  out_degree_1268  1
    arc_1_20_19  original_T_including_depot_unload_1278  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1187  1
    load_1_20_19  free_load_conservation_1267  -1
    load_1_20_19  free_load_conservation_1273  1
    visit_2_10  out_degree_1524  -1
    visit_2_10  in_degree_1525  -1
    visit_2_10  order_active_lb_1526  -1
    visit_2_10  order_active_ub_1527  -11
    order_2_10  connected_order_arc_1293  -1
    order_2_10  connected_order_arc_1295  -1
    order_2_10  connected_order_arc_1297  -1
    order_2_10  connected_order_arc_1299  -1
    order_2_10  connected_order_arc_1301  -1
    order_2_10  connected_order_arc_1303  -1
    order_2_10  connected_order_arc_1305  -1
    order_2_10  connected_order_arc_1307  -1
    order_2_10  connected_order_arc_1309  -1
    order_2_10  connected_order_arc_1311  -1
    order_2_10  connected_order_arc_1314  1
    order_2_10  connected_order_arc_1335  1
    order_2_10  connected_order_arc_1356  1
    order_2_10  connected_order_arc_1377  1
    order_2_10  connected_order_arc_1398  1
    order_2_10  connected_order_arc_1419  1
    order_2_10  connected_order_arc_1440  1
    order_2_10  connected_order_arc_1461  1
    order_2_10  connected_order_arc_1482  1
    order_2_10  connected_order_arc_1503  1
    order_2_10  order_active_lb_1526  1
    order_2_10  order_active_ub_1527  1
    order_2_10  fixed_segment_relative_order_1593  -1
    visit_2_11  out_degree_1531  -1
    visit_2_11  in_degree_1532  -1
    visit_2_11  order_active_lb_1533  -1
    visit_2_11  order_active_ub_1534  -11
    order_2_11  connected_order_arc_1293  1
    order_2_11  connected_order_arc_1314  -1
    order_2_11  connected_order_arc_1316  -1
    order_2_11  connected_order_arc_1318  -1
    order_2_11  connected_order_arc_1320  -1
    order_2_11  connected_order_arc_1322  -1
    order_2_11  connected_order_arc_1324  -1
    order_2_11  connected_order_arc_1326  -1
    order_2_11  connected_order_arc_1328  -1
    order_2_11  connected_order_arc_1330  -1
    order_2_11  connected_order_arc_1332  -1
    order_2_11  connected_order_arc_1337  1
    order_2_11  connected_order_arc_1358  1
    order_2_11  connected_order_arc_1379  1
    order_2_11  connected_order_arc_1400  1
    order_2_11  connected_order_arc_1421  1
    order_2_11  connected_order_arc_1442  1
    order_2_11  connected_order_arc_1463  1
    order_2_11  connected_order_arc_1484  1
    order_2_11  connected_order_arc_1505  1
    order_2_11  order_active_lb_1533  1
    order_2_11  order_active_ub_1534  1
    order_2_11  fixed_segment_relative_order_1593  1
    order_2_11  fixed_segment_relative_order_1594  -1
    visit_2_12  out_degree_1538  -1
    visit_2_12  in_degree_1539  -1
    visit_2_12  order_active_lb_1540  -1
    visit_2_12  order_active_ub_1541  -11
    order_2_12  connected_order_arc_1295  1
    order_2_12  connected_order_arc_1316  1
    order_2_12  connected_order_arc_1335  -1
    order_2_12  connected_order_arc_1337  -1
    order_2_12  connected_order_arc_1339  -1
    order_2_12  connected_order_arc_1341  -1
    order_2_12  connected_order_arc_1343  -1
    order_2_12  connected_order_arc_1345  -1
    order_2_12  connected_order_arc_1347  -1
    order_2_12  connected_order_arc_1349  -1
    order_2_12  connected_order_arc_1351  -1
    order_2_12  connected_order_arc_1353  -1
    order_2_12  connected_order_arc_1360  1
    order_2_12  connected_order_arc_1381  1
    order_2_12  connected_order_arc_1402  1
    order_2_12  connected_order_arc_1423  1
    order_2_12  connected_order_arc_1444  1
    order_2_12  connected_order_arc_1465  1
    order_2_12  connected_order_arc_1486  1
    order_2_12  connected_order_arc_1507  1
    order_2_12  order_active_lb_1540  1
    order_2_12  order_active_ub_1541  1
    order_2_12  fixed_segment_relative_order_1594  1
    visit_2_13  out_degree_1545  -1
    visit_2_13  in_degree_1546  -1
    visit_2_13  order_active_lb_1547  -1
    visit_2_13  order_active_ub_1548  -11
    visit_2_13  service_visit_def_1549  -1
    order_2_13  connected_order_arc_1297  1
    order_2_13  connected_order_arc_1318  1
    order_2_13  connected_order_arc_1339  1
    order_2_13  connected_order_arc_1356  -1
    order_2_13  connected_order_arc_1358  -1
    order_2_13  connected_order_arc_1360  -1
    order_2_13  connected_order_arc_1362  -1
    order_2_13  connected_order_arc_1364  -1
    order_2_13  connected_order_arc_1366  -1
    order_2_13  connected_order_arc_1368  -1
    order_2_13  connected_order_arc_1370  -1
    order_2_13  connected_order_arc_1372  -1
    order_2_13  connected_order_arc_1374  -1
    order_2_13  connected_order_arc_1383  1
    order_2_13  connected_order_arc_1404  1
    order_2_13  connected_order_arc_1425  1
    order_2_13  connected_order_arc_1446  1
    order_2_13  connected_order_arc_1467  1
    order_2_13  connected_order_arc_1488  1
    order_2_13  connected_order_arc_1509  1
    order_2_13  order_active_lb_1547  1
    order_2_13  order_active_ub_1548  1
    visit_2_14  out_degree_1551  -1
    visit_2_14  in_degree_1552  -1
    visit_2_14  order_active_lb_1553  -1
    visit_2_14  order_active_ub_1554  -11
    visit_2_14  service_visit_def_1555  -1
    order_2_14  connected_order_arc_1299  1
    order_2_14  connected_order_arc_1320  1
    order_2_14  connected_order_arc_1341  1
    order_2_14  connected_order_arc_1362  1
    order_2_14  connected_order_arc_1377  -1
    order_2_14  connected_order_arc_1379  -1
    order_2_14  connected_order_arc_1381  -1
    order_2_14  connected_order_arc_1383  -1
    order_2_14  connected_order_arc_1385  -1
    order_2_14  connected_order_arc_1387  -1
    order_2_14  connected_order_arc_1389  -1
    order_2_14  connected_order_arc_1391  -1
    order_2_14  connected_order_arc_1393  -1
    order_2_14  connected_order_arc_1395  -1
    order_2_14  connected_order_arc_1406  1
    order_2_14  connected_order_arc_1427  1
    order_2_14  connected_order_arc_1448  1
    order_2_14  connected_order_arc_1469  1
    order_2_14  connected_order_arc_1490  1
    order_2_14  connected_order_arc_1511  1
    order_2_14  order_active_lb_1553  1
    order_2_14  order_active_ub_1554  1
    visit_2_15  out_degree_1557  -1
    visit_2_15  in_degree_1558  -1
    visit_2_15  order_active_lb_1559  -1
    visit_2_15  order_active_ub_1560  -11
    visit_2_15  service_visit_def_1561  -1
    order_2_15  connected_order_arc_1301  1
    order_2_15  connected_order_arc_1322  1
    order_2_15  connected_order_arc_1343  1
    order_2_15  connected_order_arc_1364  1
    order_2_15  connected_order_arc_1385  1
    order_2_15  connected_order_arc_1398  -1
    order_2_15  connected_order_arc_1400  -1
    order_2_15  connected_order_arc_1402  -1
    order_2_15  connected_order_arc_1404  -1
    order_2_15  connected_order_arc_1406  -1
    order_2_15  connected_order_arc_1408  -1
    order_2_15  connected_order_arc_1410  -1
    order_2_15  connected_order_arc_1412  -1
    order_2_15  connected_order_arc_1414  -1
    order_2_15  connected_order_arc_1416  -1
    order_2_15  connected_order_arc_1429  1
    order_2_15  connected_order_arc_1450  1
    order_2_15  connected_order_arc_1471  1
    order_2_15  connected_order_arc_1492  1
    order_2_15  connected_order_arc_1513  1
    order_2_15  order_active_lb_1559  1
    order_2_15  order_active_ub_1560  1
    visit_2_16  out_degree_1563  -1
    visit_2_16  in_degree_1564  -1
    visit_2_16  order_active_lb_1565  -1
    visit_2_16  order_active_ub_1566  -11
    visit_2_16  service_visit_def_1567  -1
    order_2_16  connected_order_arc_1303  1
    order_2_16  connected_order_arc_1324  1
    order_2_16  connected_order_arc_1345  1
    order_2_16  connected_order_arc_1366  1
    order_2_16  connected_order_arc_1387  1
    order_2_16  connected_order_arc_1408  1
    order_2_16  connected_order_arc_1419  -1
    order_2_16  connected_order_arc_1421  -1
    order_2_16  connected_order_arc_1423  -1
    order_2_16  connected_order_arc_1425  -1
    order_2_16  connected_order_arc_1427  -1
    order_2_16  connected_order_arc_1429  -1
    order_2_16  connected_order_arc_1431  -1
    order_2_16  connected_order_arc_1433  -1
    order_2_16  connected_order_arc_1435  -1
    order_2_16  connected_order_arc_1437  -1
    order_2_16  connected_order_arc_1452  1
    order_2_16  connected_order_arc_1473  1
    order_2_16  connected_order_arc_1494  1
    order_2_16  connected_order_arc_1515  1
    order_2_16  order_active_lb_1565  1
    order_2_16  order_active_ub_1566  1
    visit_2_17  out_degree_1569  -1
    visit_2_17  in_degree_1570  -1
    visit_2_17  order_active_lb_1571  -1
    visit_2_17  order_active_ub_1572  -11
    visit_2_17  service_visit_def_1573  -1
    order_2_17  connected_order_arc_1305  1
    order_2_17  connected_order_arc_1326  1
    order_2_17  connected_order_arc_1347  1
    order_2_17  connected_order_arc_1368  1
    order_2_17  connected_order_arc_1389  1
    order_2_17  connected_order_arc_1410  1
    order_2_17  connected_order_arc_1431  1
    order_2_17  connected_order_arc_1440  -1
    order_2_17  connected_order_arc_1442  -1
    order_2_17  connected_order_arc_1444  -1
    order_2_17  connected_order_arc_1446  -1
    order_2_17  connected_order_arc_1448  -1
    order_2_17  connected_order_arc_1450  -1
    order_2_17  connected_order_arc_1452  -1
    order_2_17  connected_order_arc_1454  -1
    order_2_17  connected_order_arc_1456  -1
    order_2_17  connected_order_arc_1458  -1
    order_2_17  connected_order_arc_1475  1
    order_2_17  connected_order_arc_1496  1
    order_2_17  connected_order_arc_1517  1
    order_2_17  order_active_lb_1571  1
    order_2_17  order_active_ub_1572  1
    visit_2_18  out_degree_1575  -1
    visit_2_18  in_degree_1576  -1
    visit_2_18  order_active_lb_1577  -1
    visit_2_18  order_active_ub_1578  -11
    visit_2_18  service_visit_def_1579  -1
    order_2_18  connected_order_arc_1307  1
    order_2_18  connected_order_arc_1328  1
    order_2_18  connected_order_arc_1349  1
    order_2_18  connected_order_arc_1370  1
    order_2_18  connected_order_arc_1391  1
    order_2_18  connected_order_arc_1412  1
    order_2_18  connected_order_arc_1433  1
    order_2_18  connected_order_arc_1454  1
    order_2_18  connected_order_arc_1461  -1
    order_2_18  connected_order_arc_1463  -1
    order_2_18  connected_order_arc_1465  -1
    order_2_18  connected_order_arc_1467  -1
    order_2_18  connected_order_arc_1469  -1
    order_2_18  connected_order_arc_1471  -1
    order_2_18  connected_order_arc_1473  -1
    order_2_18  connected_order_arc_1475  -1
    order_2_18  connected_order_arc_1477  -1
    order_2_18  connected_order_arc_1479  -1
    order_2_18  connected_order_arc_1498  1
    order_2_18  connected_order_arc_1519  1
    order_2_18  order_active_lb_1577  1
    order_2_18  order_active_ub_1578  1
    visit_2_19  out_degree_1581  -1
    visit_2_19  in_degree_1582  -1
    visit_2_19  order_active_lb_1583  -1
    visit_2_19  order_active_ub_1584  -11
    visit_2_19  service_visit_def_1585  -1
    order_2_19  connected_order_arc_1309  1
    order_2_19  connected_order_arc_1330  1
    order_2_19  connected_order_arc_1351  1
    order_2_19  connected_order_arc_1372  1
    order_2_19  connected_order_arc_1393  1
    order_2_19  connected_order_arc_1414  1
    order_2_19  connected_order_arc_1435  1
    order_2_19  connected_order_arc_1456  1
    order_2_19  connected_order_arc_1477  1
    order_2_19  connected_order_arc_1482  -1
    order_2_19  connected_order_arc_1484  -1
    order_2_19  connected_order_arc_1486  -1
    order_2_19  connected_order_arc_1488  -1
    order_2_19  connected_order_arc_1490  -1
    order_2_19  connected_order_arc_1492  -1
    order_2_19  connected_order_arc_1494  -1
    order_2_19  connected_order_arc_1496  -1
    order_2_19  connected_order_arc_1498  -1
    order_2_19  connected_order_arc_1500  -1
    order_2_19  connected_order_arc_1521  1
    order_2_19  order_active_lb_1583  1
    order_2_19  order_active_ub_1584  1
    visit_2_20  out_degree_1587  -1
    visit_2_20  in_degree_1588  -1
    visit_2_20  order_active_lb_1589  -1
    visit_2_20  order_active_ub_1590  -11
    visit_2_20  service_visit_def_1591  -1
    order_2_20  connected_order_arc_1311  1
    order_2_20  connected_order_arc_1332  1
    order_2_20  connected_order_arc_1353  1
    order_2_20  connected_order_arc_1374  1
    order_2_20  connected_order_arc_1395  1
    order_2_20  connected_order_arc_1416  1
    order_2_20  connected_order_arc_1437  1
    order_2_20  connected_order_arc_1458  1
    order_2_20  connected_order_arc_1479  1
    order_2_20  connected_order_arc_1500  1
    order_2_20  connected_order_arc_1503  -1
    order_2_20  connected_order_arc_1505  -1
    order_2_20  connected_order_arc_1507  -1
    order_2_20  connected_order_arc_1509  -1
    order_2_20  connected_order_arc_1511  -1
    order_2_20  connected_order_arc_1513  -1
    order_2_20  connected_order_arc_1515  -1
    order_2_20  connected_order_arc_1517  -1
    order_2_20  connected_order_arc_1519  -1
    order_2_20  connected_order_arc_1521  -1
    order_2_20  order_active_lb_1589  1
    order_2_20  order_active_ub_1590  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1279  -30
    arc_2_0_0  depot_departure_or_bypass_1522  1
    arc_2_0_0  depot_return_or_bypass_1523  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1280  -30
    arc_2_0_10  depot_departure_or_bypass_1522  1
    arc_2_0_10  in_degree_1525  1
    arc_2_0_10  original_T_including_depot_unload_1595  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1280  1
    load_2_0_10  segment_load_conservation_1528  -1
    load_2_0_10  segment_prefix_lb_1529  1
    load_2_0_10  segment_prefix_ub_1530  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1281  -30
    arc_2_0_11  depot_departure_or_bypass_1522  1
    arc_2_0_11  in_degree_1532  1
    arc_2_0_11  original_T_including_depot_unload_1595  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1281  1
    load_2_0_11  segment_load_conservation_1535  -1
    load_2_0_11  segment_prefix_lb_1536  1
    load_2_0_11  segment_prefix_ub_1537  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1282  -30
    arc_2_0_12  depot_departure_or_bypass_1522  1
    arc_2_0_12  in_degree_1539  1
    arc_2_0_12  original_T_including_depot_unload_1595  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1282  1
    load_2_0_12  segment_load_conservation_1542  -1
    load_2_0_12  segment_prefix_lb_1543  1
    load_2_0_12  segment_prefix_ub_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1283  -30
    arc_2_0_13  depot_departure_or_bypass_1522  1
    arc_2_0_13  in_degree_1546  1
    arc_2_0_13  original_T_including_depot_unload_1595  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1283  1
    load_2_0_13  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1284  -30
    arc_2_0_14  depot_departure_or_bypass_1522  1
    arc_2_0_14  in_degree_1552  1
    arc_2_0_14  original_T_including_depot_unload_1595  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1284  1
    load_2_0_14  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1285  -30
    arc_2_0_15  depot_departure_or_bypass_1522  1
    arc_2_0_15  in_degree_1558  1
    arc_2_0_15  original_T_including_depot_unload_1595  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1285  1
    load_2_0_15  free_load_conservation_1562  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1286  -30
    arc_2_0_16  depot_departure_or_bypass_1522  1
    arc_2_0_16  in_degree_1564  1
    arc_2_0_16  original_T_including_depot_unload_1595  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1286  1
    load_2_0_16  free_load_conservation_1568  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1287  -30
    arc_2_0_17  depot_departure_or_bypass_1522  1
    arc_2_0_17  in_degree_1570  1
    arc_2_0_17  original_T_including_depot_unload_1595  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1287  1
    load_2_0_17  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1288  -30
    arc_2_0_18  depot_departure_or_bypass_1522  1
    arc_2_0_18  in_degree_1576  1
    arc_2_0_18  original_T_including_depot_unload_1595  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1288  1
    load_2_0_18  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1289  -30
    arc_2_0_19  depot_departure_or_bypass_1522  1
    arc_2_0_19  in_degree_1582  1
    arc_2_0_19  original_T_including_depot_unload_1595  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1289  1
    load_2_0_19  free_load_conservation_1586  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1290  -30
    arc_2_0_20  depot_departure_or_bypass_1522  1
    arc_2_0_20  in_degree_1588  1
    arc_2_0_20  original_T_including_depot_unload_1595  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1290  1
    load_2_0_20  free_load_conservation_1592  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1291  -30
    arc_2_10_0  depot_return_or_bypass_1523  1
    arc_2_10_0  out_degree_1524  1
    arc_2_10_0  original_T_including_depot_unload_1595  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1291  1
    load_2_10_0  segment_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1292  -30
    arc_2_10_11  connected_order_arc_1293  -12
    arc_2_10_11  out_degree_1524  1
    arc_2_10_11  in_degree_1532  1
    arc_2_10_11  original_T_including_depot_unload_1595  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1292  1
    load_2_10_11  segment_load_conservation_1528  1
    load_2_10_11  segment_load_conservation_1535  -1
    load_2_10_11  segment_prefix_lb_1536  1
    load_2_10_11  segment_prefix_ub_1537  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1294  -30
    arc_2_10_12  connected_order_arc_1295  -12
    arc_2_10_12  out_degree_1524  1
    arc_2_10_12  in_degree_1539  1
    arc_2_10_12  original_T_including_depot_unload_1595  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1294  1
    load_2_10_12  segment_load_conservation_1528  1
    load_2_10_12  segment_load_conservation_1542  -1
    load_2_10_12  segment_prefix_lb_1543  1
    load_2_10_12  segment_prefix_ub_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1296  -30
    arc_2_10_13  connected_order_arc_1297  -12
    arc_2_10_13  out_degree_1524  1
    arc_2_10_13  in_degree_1546  1
    arc_2_10_13  original_T_including_depot_unload_1595  6.0309764600105484e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1296  1
    load_2_10_13  segment_load_conservation_1528  1
    load_2_10_13  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1298  -30
    arc_2_10_14  connected_order_arc_1299  -12
    arc_2_10_14  out_degree_1524  1
    arc_2_10_14  in_degree_1552  1
    arc_2_10_14  original_T_including_depot_unload_1595  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1298  1
    load_2_10_14  segment_load_conservation_1528  1
    load_2_10_14  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1300  -30
    arc_2_10_15  connected_order_arc_1301  -12
    arc_2_10_15  out_degree_1524  1
    arc_2_10_15  in_degree_1558  1
    arc_2_10_15  original_T_including_depot_unload_1595  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1300  1
    load_2_10_15  segment_load_conservation_1528  1
    load_2_10_15  free_load_conservation_1562  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1302  -30
    arc_2_10_16  connected_order_arc_1303  -12
    arc_2_10_16  out_degree_1524  1
    arc_2_10_16  in_degree_1564  1
    arc_2_10_16  original_T_including_depot_unload_1595  6.5332321619697848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1302  1
    load_2_10_16  segment_load_conservation_1528  1
    load_2_10_16  free_load_conservation_1568  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1304  -30
    arc_2_10_17  connected_order_arc_1305  -12
    arc_2_10_17  out_degree_1524  1
    arc_2_10_17  in_degree_1570  1
    arc_2_10_17  original_T_including_depot_unload_1595  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1304  1
    load_2_10_17  segment_load_conservation_1528  1
    load_2_10_17  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1306  -30
    arc_2_10_18  connected_order_arc_1307  -12
    arc_2_10_18  out_degree_1524  1
    arc_2_10_18  in_degree_1576  1
    arc_2_10_18  original_T_including_depot_unload_1595  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1306  1
    load_2_10_18  segment_load_conservation_1528  1
    load_2_10_18  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1308  -30
    arc_2_10_19  connected_order_arc_1309  -12
    arc_2_10_19  out_degree_1524  1
    arc_2_10_19  in_degree_1582  1
    arc_2_10_19  original_T_including_depot_unload_1595  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1308  1
    load_2_10_19  segment_load_conservation_1528  1
    load_2_10_19  free_load_conservation_1586  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1310  -30
    arc_2_10_20  connected_order_arc_1311  -12
    arc_2_10_20  out_degree_1524  1
    arc_2_10_20  in_degree_1588  1
    arc_2_10_20  original_T_including_depot_unload_1595  8.6713096341893186e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1310  1
    load_2_10_20  segment_load_conservation_1528  1
    load_2_10_20  free_load_conservation_1592  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1312  -30
    arc_2_11_0  depot_return_or_bypass_1523  1
    arc_2_11_0  out_degree_1531  1
    arc_2_11_0  original_T_including_depot_unload_1595  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1312  1
    load_2_11_0  segment_load_conservation_1535  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1313  -30
    arc_2_11_10  connected_order_arc_1314  -12
    arc_2_11_10  in_degree_1525  1
    arc_2_11_10  out_degree_1531  1
    arc_2_11_10  original_T_including_depot_unload_1595  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1313  1
    load_2_11_10  segment_load_conservation_1528  -1
    load_2_11_10  segment_prefix_lb_1529  1
    load_2_11_10  segment_prefix_ub_1530  1
    load_2_11_10  segment_load_conservation_1535  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1315  -30
    arc_2_11_12  connected_order_arc_1316  -12
    arc_2_11_12  out_degree_1531  1
    arc_2_11_12  in_degree_1539  1
    arc_2_11_12  original_T_including_depot_unload_1595  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1315  1
    load_2_11_12  segment_load_conservation_1535  1
    load_2_11_12  segment_load_conservation_1542  -1
    load_2_11_12  segment_prefix_lb_1543  1
    load_2_11_12  segment_prefix_ub_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1317  -30
    arc_2_11_13  connected_order_arc_1318  -12
    arc_2_11_13  out_degree_1531  1
    arc_2_11_13  in_degree_1546  1
    arc_2_11_13  original_T_including_depot_unload_1595  1.5552905028977075e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1317  1
    load_2_11_13  segment_load_conservation_1535  1
    load_2_11_13  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1319  -30
    arc_2_11_14  connected_order_arc_1320  -12
    arc_2_11_14  out_degree_1531  1
    arc_2_11_14  in_degree_1552  1
    arc_2_11_14  original_T_including_depot_unload_1595  1.3812305438169078e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1319  1
    load_2_11_14  segment_load_conservation_1535  1
    load_2_11_14  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1321  -30
    arc_2_11_15  connected_order_arc_1322  -12
    arc_2_11_15  out_degree_1531  1
    arc_2_11_15  in_degree_1558  1
    arc_2_11_15  original_T_including_depot_unload_1595  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1321  1
    load_2_11_15  segment_load_conservation_1535  1
    load_2_11_15  free_load_conservation_1562  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1323  -30
    arc_2_11_16  connected_order_arc_1324  -12
    arc_2_11_16  out_degree_1531  1
    arc_2_11_16  in_degree_1564  1
    arc_2_11_16  original_T_including_depot_unload_1595  1.6583475127728254e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1323  1
    load_2_11_16  segment_load_conservation_1535  1
    load_2_11_16  free_load_conservation_1568  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1325  -30
    arc_2_11_17  connected_order_arc_1326  -12
    arc_2_11_17  out_degree_1531  1
    arc_2_11_17  in_degree_1570  1
    arc_2_11_17  original_T_including_depot_unload_1595  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1325  1
    load_2_11_17  segment_load_conservation_1535  1
    load_2_11_17  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1327  -30
    arc_2_11_18  connected_order_arc_1328  -12
    arc_2_11_18  out_degree_1531  1
    arc_2_11_18  in_degree_1576  1
    arc_2_11_18  original_T_including_depot_unload_1595  1.4479451378803963e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1327  1
    load_2_11_18  segment_load_conservation_1535  1
    load_2_11_18  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1329  -30
    arc_2_11_19  connected_order_arc_1330  -12
    arc_2_11_19  out_degree_1531  1
    arc_2_11_19  in_degree_1582  1
    arc_2_11_19  original_T_including_depot_unload_1595  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1329  1
    load_2_11_19  segment_load_conservation_1535  1
    load_2_11_19  free_load_conservation_1586  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1331  -30
    arc_2_11_20  connected_order_arc_1332  -12
    arc_2_11_20  out_degree_1531  1
    arc_2_11_20  in_degree_1588  1
    arc_2_11_20  original_T_including_depot_unload_1595  1.8580343290482886e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1331  1
    load_2_11_20  segment_load_conservation_1535  1
    load_2_11_20  free_load_conservation_1592  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1333  -30
    arc_2_12_0  depot_return_or_bypass_1523  1
    arc_2_12_0  out_degree_1538  1
    arc_2_12_0  original_T_including_depot_unload_1595  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1333  1
    load_2_12_0  segment_load_conservation_1542  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1334  -30
    arc_2_12_10  connected_order_arc_1335  -12
    arc_2_12_10  in_degree_1525  1
    arc_2_12_10  out_degree_1538  1
    arc_2_12_10  original_T_including_depot_unload_1595  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1334  1
    load_2_12_10  segment_load_conservation_1528  -1
    load_2_12_10  segment_prefix_lb_1529  1
    load_2_12_10  segment_prefix_ub_1530  1
    load_2_12_10  segment_load_conservation_1542  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1336  -30
    arc_2_12_11  connected_order_arc_1337  -12
    arc_2_12_11  in_degree_1532  1
    arc_2_12_11  out_degree_1538  1
    arc_2_12_11  original_T_including_depot_unload_1595  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1336  1
    load_2_12_11  segment_load_conservation_1535  -1
    load_2_12_11  segment_prefix_lb_1536  1
    load_2_12_11  segment_prefix_ub_1537  1
    load_2_12_11  segment_load_conservation_1542  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1338  -30
    arc_2_12_13  connected_order_arc_1339  -12
    arc_2_12_13  out_degree_1538  1
    arc_2_12_13  in_degree_1546  1
    arc_2_12_13  original_T_including_depot_unload_1595  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1338  1
    load_2_12_13  segment_load_conservation_1542  1
    load_2_12_13  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1340  -30
    arc_2_12_14  connected_order_arc_1341  -12
    arc_2_12_14  out_degree_1538  1
    arc_2_12_14  in_degree_1552  1
    arc_2_12_14  original_T_including_depot_unload_1595  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1340  1
    load_2_12_14  segment_load_conservation_1542  1
    load_2_12_14  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1342  -30
    arc_2_12_15  connected_order_arc_1343  -12
    arc_2_12_15  out_degree_1538  1
    arc_2_12_15  in_degree_1558  1
    arc_2_12_15  original_T_including_depot_unload_1595  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1342  1
    load_2_12_15  segment_load_conservation_1542  1
    load_2_12_15  free_load_conservation_1562  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1344  -30
    arc_2_12_16  connected_order_arc_1345  -12
    arc_2_12_16  out_degree_1538  1
    arc_2_12_16  in_degree_1564  1
    arc_2_12_16  original_T_including_depot_unload_1595  904.837890445026
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1344  1
    load_2_12_16  segment_load_conservation_1542  1
    load_2_12_16  free_load_conservation_1568  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1346  -30
    arc_2_12_17  connected_order_arc_1347  -12
    arc_2_12_17  out_degree_1538  1
    arc_2_12_17  in_degree_1570  1
    arc_2_12_17  original_T_including_depot_unload_1595  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1346  1
    load_2_12_17  segment_load_conservation_1542  1
    load_2_12_17  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1348  -30
    arc_2_12_18  connected_order_arc_1349  -12
    arc_2_12_18  out_degree_1538  1
    arc_2_12_18  in_degree_1576  1
    arc_2_12_18  original_T_including_depot_unload_1595  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1348  1
    load_2_12_18  segment_load_conservation_1542  1
    load_2_12_18  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1350  -30
    arc_2_12_19  connected_order_arc_1351  -12
    arc_2_12_19  out_degree_1538  1
    arc_2_12_19  in_degree_1582  1
    arc_2_12_19  original_T_including_depot_unload_1595  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1350  1
    load_2_12_19  segment_load_conservation_1542  1
    load_2_12_19  free_load_conservation_1586  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1352  -30
    arc_2_12_20  connected_order_arc_1353  -12
    arc_2_12_20  out_degree_1538  1
    arc_2_12_20  in_degree_1588  1
    arc_2_12_20  original_T_including_depot_unload_1595  9.6598937061987863e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1352  1
    load_2_12_20  segment_load_conservation_1542  1
    load_2_12_20  free_load_conservation_1592  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1354  -30
    arc_2_13_0  depot_return_or_bypass_1523  1
    arc_2_13_0  out_degree_1545  1
    arc_2_13_0  original_T_including_depot_unload_1595  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1354  1
    load_2_13_0  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1355  -30
    arc_2_13_10  connected_order_arc_1356  -12
    arc_2_13_10  in_degree_1525  1
    arc_2_13_10  out_degree_1545  1
    arc_2_13_10  original_T_including_depot_unload_1595  6.0309764600105484e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1355  1
    load_2_13_10  segment_load_conservation_1528  -1
    load_2_13_10  segment_prefix_lb_1529  1
    load_2_13_10  segment_prefix_ub_1530  1
    load_2_13_10  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1357  -30
    arc_2_13_11  connected_order_arc_1358  -12
    arc_2_13_11  in_degree_1532  1
    arc_2_13_11  out_degree_1545  1
    arc_2_13_11  original_T_including_depot_unload_1595  1.8805180645589260e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1357  1
    load_2_13_11  segment_load_conservation_1535  -1
    load_2_13_11  segment_prefix_lb_1536  1
    load_2_13_11  segment_prefix_ub_1537  1
    load_2_13_11  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1359  -30
    arc_2_13_12  connected_order_arc_1360  -12
    arc_2_13_12  in_degree_1539  1
    arc_2_13_12  out_degree_1545  1
    arc_2_13_12  original_T_including_depot_unload_1595  1.0875821153726588e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1359  1
    load_2_13_12  segment_load_conservation_1542  -1
    load_2_13_12  segment_prefix_lb_1543  1
    load_2_13_12  segment_prefix_ub_1544  1
    load_2_13_12  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1361  -30
    arc_2_13_14  connected_order_arc_1362  -12
    arc_2_13_14  out_degree_1545  1
    arc_2_13_14  in_degree_1552  1
    arc_2_13_14  original_T_including_depot_unload_1595  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1361  1
    load_2_13_14  free_load_conservation_1550  1
    load_2_13_14  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1363  -30
    arc_2_13_15  connected_order_arc_1364  -12
    arc_2_13_15  out_degree_1545  1
    arc_2_13_15  in_degree_1558  1
    arc_2_13_15  original_T_including_depot_unload_1595  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1363  1
    load_2_13_15  free_load_conservation_1550  1
    load_2_13_15  free_load_conservation_1562  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1365  -30
    arc_2_13_16  connected_order_arc_1366  -12
    arc_2_13_16  out_degree_1545  1
    arc_2_13_16  in_degree_1564  1
    arc_2_13_16  original_T_including_depot_unload_1595  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1365  1
    load_2_13_16  free_load_conservation_1550  1
    load_2_13_16  free_load_conservation_1568  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1367  -30
    arc_2_13_17  connected_order_arc_1368  -12
    arc_2_13_17  out_degree_1545  1
    arc_2_13_17  in_degree_1570  1
    arc_2_13_17  original_T_including_depot_unload_1595  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1367  1
    load_2_13_17  free_load_conservation_1550  1
    load_2_13_17  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1369  -30
    arc_2_13_18  connected_order_arc_1370  -12
    arc_2_13_18  out_degree_1545  1
    arc_2_13_18  in_degree_1576  1
    arc_2_13_18  original_T_including_depot_unload_1595  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1369  1
    load_2_13_18  free_load_conservation_1550  1
    load_2_13_18  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1371  -30
    arc_2_13_19  connected_order_arc_1372  -12
    arc_2_13_19  out_degree_1545  1
    arc_2_13_19  in_degree_1582  1
    arc_2_13_19  original_T_including_depot_unload_1595  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1371  1
    load_2_13_19  free_load_conservation_1550  1
    load_2_13_19  free_load_conservation_1586  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1373  -30
    arc_2_13_20  connected_order_arc_1374  -12
    arc_2_13_20  out_degree_1545  1
    arc_2_13_20  in_degree_1588  1
    arc_2_13_20  original_T_including_depot_unload_1595  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1373  1
    load_2_13_20  free_load_conservation_1550  1
    load_2_13_20  free_load_conservation_1592  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1375  -30
    arc_2_14_0  depot_return_or_bypass_1523  1
    arc_2_14_0  out_degree_1551  1
    arc_2_14_0  original_T_including_depot_unload_1595  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1375  1
    load_2_14_0  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1376  -30
    arc_2_14_10  connected_order_arc_1377  -12
    arc_2_14_10  in_degree_1525  1
    arc_2_14_10  out_degree_1551  1
    arc_2_14_10  original_T_including_depot_unload_1595  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1376  1
    load_2_14_10  segment_load_conservation_1528  -1
    load_2_14_10  segment_prefix_lb_1529  1
    load_2_14_10  segment_prefix_ub_1530  1
    load_2_14_10  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1378  -30
    arc_2_14_11  connected_order_arc_1379  -12
    arc_2_14_11  in_degree_1532  1
    arc_2_14_11  out_degree_1551  1
    arc_2_14_11  original_T_including_depot_unload_1595  1.7155529120526971e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1378  1
    load_2_14_11  segment_load_conservation_1535  -1
    load_2_14_11  segment_prefix_lb_1536  1
    load_2_14_11  segment_prefix_ub_1537  1
    load_2_14_11  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1380  -30
    arc_2_14_12  connected_order_arc_1381  -12
    arc_2_14_12  in_degree_1539  1
    arc_2_14_12  out_degree_1551  1
    arc_2_14_12  original_T_including_depot_unload_1595  1.0428409649002836e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1380  1
    load_2_14_12  segment_load_conservation_1542  -1
    load_2_14_12  segment_prefix_lb_1543  1
    load_2_14_12  segment_prefix_ub_1544  1
    load_2_14_12  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1382  -30
    arc_2_14_13  connected_order_arc_1383  -12
    arc_2_14_13  in_degree_1546  1
    arc_2_14_13  out_degree_1551  1
    arc_2_14_13  original_T_including_depot_unload_1595  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1382  1
    load_2_14_13  free_load_conservation_1550  -1
    load_2_14_13  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1384  -30
    arc_2_14_15  connected_order_arc_1385  -12
    arc_2_14_15  out_degree_1551  1
    arc_2_14_15  in_degree_1558  1
    arc_2_14_15  original_T_including_depot_unload_1595  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1384  1
    load_2_14_15  free_load_conservation_1556  1
    load_2_14_15  free_load_conservation_1562  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1386  -30
    arc_2_14_16  connected_order_arc_1387  -12
    arc_2_14_16  out_degree_1551  1
    arc_2_14_16  in_degree_1564  1
    arc_2_14_16  original_T_including_depot_unload_1595  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1386  1
    load_2_14_16  free_load_conservation_1556  1
    load_2_14_16  free_load_conservation_1568  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1388  -30
    arc_2_14_17  connected_order_arc_1389  -12
    arc_2_14_17  out_degree_1551  1
    arc_2_14_17  in_degree_1570  1
    arc_2_14_17  original_T_including_depot_unload_1595  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1388  1
    load_2_14_17  free_load_conservation_1556  1
    load_2_14_17  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1390  -30
    arc_2_14_18  connected_order_arc_1391  -12
    arc_2_14_18  out_degree_1551  1
    arc_2_14_18  in_degree_1576  1
    arc_2_14_18  original_T_including_depot_unload_1595  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1390  1
    load_2_14_18  free_load_conservation_1556  1
    load_2_14_18  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1392  -30
    arc_2_14_19  connected_order_arc_1393  -12
    arc_2_14_19  out_degree_1551  1
    arc_2_14_19  in_degree_1582  1
    arc_2_14_19  original_T_including_depot_unload_1595  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1392  1
    load_2_14_19  free_load_conservation_1556  1
    load_2_14_19  free_load_conservation_1586  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1394  -30
    arc_2_14_20  connected_order_arc_1395  -12
    arc_2_14_20  out_degree_1551  1
    arc_2_14_20  in_degree_1588  1
    arc_2_14_20  original_T_including_depot_unload_1595  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1394  1
    load_2_14_20  free_load_conservation_1556  1
    load_2_14_20  free_load_conservation_1592  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1396  -30
    arc_2_15_0  depot_return_or_bypass_1523  1
    arc_2_15_0  out_degree_1557  1
    arc_2_15_0  original_T_including_depot_unload_1595  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1396  1
    load_2_15_0  free_load_conservation_1562  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1397  -30
    arc_2_15_10  connected_order_arc_1398  -12
    arc_2_15_10  in_degree_1525  1
    arc_2_15_10  out_degree_1557  1
    arc_2_15_10  original_T_including_depot_unload_1595  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1397  1
    load_2_15_10  segment_load_conservation_1528  -1
    load_2_15_10  segment_prefix_lb_1529  1
    load_2_15_10  segment_prefix_ub_1530  1
    load_2_15_10  free_load_conservation_1562  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1399  -30
    arc_2_15_11  connected_order_arc_1400  -12
    arc_2_15_11  in_degree_1532  1
    arc_2_15_11  out_degree_1557  1
    arc_2_15_11  original_T_including_depot_unload_1595  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1399  1
    load_2_15_11  segment_load_conservation_1535  -1
    load_2_15_11  segment_prefix_lb_1536  1
    load_2_15_11  segment_prefix_ub_1537  1
    load_2_15_11  free_load_conservation_1562  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1401  -30
    arc_2_15_12  connected_order_arc_1402  -12
    arc_2_15_12  in_degree_1539  1
    arc_2_15_12  out_degree_1557  1
    arc_2_15_12  original_T_including_depot_unload_1595  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1401  1
    load_2_15_12  segment_load_conservation_1542  -1
    load_2_15_12  segment_prefix_lb_1543  1
    load_2_15_12  segment_prefix_ub_1544  1
    load_2_15_12  free_load_conservation_1562  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1403  -30
    arc_2_15_13  connected_order_arc_1404  -12
    arc_2_15_13  in_degree_1546  1
    arc_2_15_13  out_degree_1557  1
    arc_2_15_13  original_T_including_depot_unload_1595  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1403  1
    load_2_15_13  free_load_conservation_1550  -1
    load_2_15_13  free_load_conservation_1562  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1405  -30
    arc_2_15_14  connected_order_arc_1406  -12
    arc_2_15_14  in_degree_1552  1
    arc_2_15_14  out_degree_1557  1
    arc_2_15_14  original_T_including_depot_unload_1595  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1405  1
    load_2_15_14  free_load_conservation_1556  -1
    load_2_15_14  free_load_conservation_1562  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1407  -30
    arc_2_15_16  connected_order_arc_1408  -12
    arc_2_15_16  out_degree_1557  1
    arc_2_15_16  in_degree_1564  1
    arc_2_15_16  original_T_including_depot_unload_1595  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1407  1
    load_2_15_16  free_load_conservation_1562  1
    load_2_15_16  free_load_conservation_1568  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1409  -30
    arc_2_15_17  connected_order_arc_1410  -12
    arc_2_15_17  out_degree_1557  1
    arc_2_15_17  in_degree_1570  1
    arc_2_15_17  original_T_including_depot_unload_1595  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1409  1
    load_2_15_17  free_load_conservation_1562  1
    load_2_15_17  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1411  -30
    arc_2_15_18  connected_order_arc_1412  -12
    arc_2_15_18  out_degree_1557  1
    arc_2_15_18  in_degree_1576  1
    arc_2_15_18  original_T_including_depot_unload_1595  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1411  1
    load_2_15_18  free_load_conservation_1562  1
    load_2_15_18  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1413  -30
    arc_2_15_19  connected_order_arc_1414  -12
    arc_2_15_19  out_degree_1557  1
    arc_2_15_19  in_degree_1582  1
    arc_2_15_19  original_T_including_depot_unload_1595  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1413  1
    load_2_15_19  free_load_conservation_1562  1
    load_2_15_19  free_load_conservation_1586  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1415  -30
    arc_2_15_20  connected_order_arc_1416  -12
    arc_2_15_20  out_degree_1557  1
    arc_2_15_20  in_degree_1588  1
    arc_2_15_20  original_T_including_depot_unload_1595  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1415  1
    load_2_15_20  free_load_conservation_1562  1
    load_2_15_20  free_load_conservation_1592  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1417  -30
    arc_2_16_0  depot_return_or_bypass_1523  1
    arc_2_16_0  out_degree_1563  1
    arc_2_16_0  original_T_including_depot_unload_1595  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1417  1
    load_2_16_0  free_load_conservation_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1418  -30
    arc_2_16_10  connected_order_arc_1419  -12
    arc_2_16_10  in_degree_1525  1
    arc_2_16_10  out_degree_1563  1
    arc_2_16_10  original_T_including_depot_unload_1595  6.5332321619697848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1418  1
    load_2_16_10  segment_load_conservation_1528  -1
    load_2_16_10  segment_prefix_lb_1529  1
    load_2_16_10  segment_prefix_ub_1530  1
    load_2_16_10  free_load_conservation_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1420  -30
    arc_2_16_11  connected_order_arc_1421  -12
    arc_2_16_11  in_degree_1532  1
    arc_2_16_11  out_degree_1563  1
    arc_2_16_11  original_T_including_depot_unload_1595  1.9292357601859349e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1420  1
    load_2_16_11  segment_load_conservation_1535  -1
    load_2_16_11  segment_prefix_lb_1536  1
    load_2_16_11  segment_prefix_ub_1537  1
    load_2_16_11  free_load_conservation_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1422  -30
    arc_2_16_12  connected_order_arc_1423  -12
    arc_2_16_12  in_degree_1539  1
    arc_2_16_12  out_degree_1563  1
    arc_2_16_12  original_T_including_depot_unload_1595  1.3174943724568802e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1422  1
    load_2_16_12  segment_load_conservation_1542  -1
    load_2_16_12  segment_prefix_lb_1543  1
    load_2_16_12  segment_prefix_ub_1544  1
    load_2_16_12  free_load_conservation_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1424  -30
    arc_2_16_13  connected_order_arc_1425  -12
    arc_2_16_13  in_degree_1546  1
    arc_2_16_13  out_degree_1563  1
    arc_2_16_13  original_T_including_depot_unload_1595  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1424  1
    load_2_16_13  free_load_conservation_1550  -1
    load_2_16_13  free_load_conservation_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1426  -30
    arc_2_16_14  connected_order_arc_1427  -12
    arc_2_16_14  in_degree_1552  1
    arc_2_16_14  out_degree_1563  1
    arc_2_16_14  original_T_including_depot_unload_1595  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1426  1
    load_2_16_14  free_load_conservation_1556  -1
    load_2_16_14  free_load_conservation_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1428  -30
    arc_2_16_15  connected_order_arc_1429  -12
    arc_2_16_15  in_degree_1558  1
    arc_2_16_15  out_degree_1563  1
    arc_2_16_15  original_T_including_depot_unload_1595  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1428  1
    load_2_16_15  free_load_conservation_1562  -1
    load_2_16_15  free_load_conservation_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1430  -30
    arc_2_16_17  connected_order_arc_1431  -12
    arc_2_16_17  out_degree_1563  1
    arc_2_16_17  in_degree_1570  1
    arc_2_16_17  original_T_including_depot_unload_1595  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1430  1
    load_2_16_17  free_load_conservation_1568  1
    load_2_16_17  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1432  -30
    arc_2_16_18  connected_order_arc_1433  -12
    arc_2_16_18  out_degree_1563  1
    arc_2_16_18  in_degree_1576  1
    arc_2_16_18  original_T_including_depot_unload_1595  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1432  1
    load_2_16_18  free_load_conservation_1568  1
    load_2_16_18  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1434  -30
    arc_2_16_19  connected_order_arc_1435  -12
    arc_2_16_19  out_degree_1563  1
    arc_2_16_19  in_degree_1582  1
    arc_2_16_19  original_T_including_depot_unload_1595  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1434  1
    load_2_16_19  free_load_conservation_1568  1
    load_2_16_19  free_load_conservation_1586  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1436  -30
    arc_2_16_20  connected_order_arc_1437  -12
    arc_2_16_20  out_degree_1563  1
    arc_2_16_20  in_degree_1588  1
    arc_2_16_20  original_T_including_depot_unload_1595  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1436  1
    load_2_16_20  free_load_conservation_1568  1
    load_2_16_20  free_load_conservation_1592  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1438  -30
    arc_2_17_0  depot_return_or_bypass_1523  1
    arc_2_17_0  out_degree_1569  1
    arc_2_17_0  original_T_including_depot_unload_1595  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1438  1
    load_2_17_0  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1439  -30
    arc_2_17_10  connected_order_arc_1440  -12
    arc_2_17_10  in_degree_1525  1
    arc_2_17_10  out_degree_1569  1
    arc_2_17_10  original_T_including_depot_unload_1595  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1439  1
    load_2_17_10  segment_load_conservation_1528  -1
    load_2_17_10  segment_prefix_lb_1529  1
    load_2_17_10  segment_prefix_ub_1530  1
    load_2_17_10  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1441  -30
    arc_2_17_11  connected_order_arc_1442  -12
    arc_2_17_11  in_degree_1532  1
    arc_2_17_11  out_degree_1569  1
    arc_2_17_11  original_T_including_depot_unload_1595  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1441  1
    load_2_17_11  segment_load_conservation_1535  -1
    load_2_17_11  segment_prefix_lb_1536  1
    load_2_17_11  segment_prefix_ub_1537  1
    load_2_17_11  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1443  -30
    arc_2_17_12  connected_order_arc_1444  -12
    arc_2_17_12  in_degree_1539  1
    arc_2_17_12  out_degree_1569  1
    arc_2_17_12  original_T_including_depot_unload_1595  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1443  1
    load_2_17_12  segment_load_conservation_1542  -1
    load_2_17_12  segment_prefix_lb_1543  1
    load_2_17_12  segment_prefix_ub_1544  1
    load_2_17_12  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1445  -30
    arc_2_17_13  connected_order_arc_1446  -12
    arc_2_17_13  in_degree_1546  1
    arc_2_17_13  out_degree_1569  1
    arc_2_17_13  original_T_including_depot_unload_1595  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1445  1
    load_2_17_13  free_load_conservation_1550  -1
    load_2_17_13  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1447  -30
    arc_2_17_14  connected_order_arc_1448  -12
    arc_2_17_14  in_degree_1552  1
    arc_2_17_14  out_degree_1569  1
    arc_2_17_14  original_T_including_depot_unload_1595  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1447  1
    load_2_17_14  free_load_conservation_1556  -1
    load_2_17_14  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1449  -30
    arc_2_17_15  connected_order_arc_1450  -12
    arc_2_17_15  in_degree_1558  1
    arc_2_17_15  out_degree_1569  1
    arc_2_17_15  original_T_including_depot_unload_1595  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1449  1
    load_2_17_15  free_load_conservation_1562  -1
    load_2_17_15  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1451  -30
    arc_2_17_16  connected_order_arc_1452  -12
    arc_2_17_16  in_degree_1564  1
    arc_2_17_16  out_degree_1569  1
    arc_2_17_16  original_T_including_depot_unload_1595  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1451  1
    load_2_17_16  free_load_conservation_1568  -1
    load_2_17_16  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1453  -30
    arc_2_17_18  connected_order_arc_1454  -12
    arc_2_17_18  out_degree_1569  1
    arc_2_17_18  in_degree_1576  1
    arc_2_17_18  original_T_including_depot_unload_1595  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1453  1
    load_2_17_18  free_load_conservation_1574  1
    load_2_17_18  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1455  -30
    arc_2_17_19  connected_order_arc_1456  -12
    arc_2_17_19  out_degree_1569  1
    arc_2_17_19  in_degree_1582  1
    arc_2_17_19  original_T_including_depot_unload_1595  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1455  1
    load_2_17_19  free_load_conservation_1574  1
    load_2_17_19  free_load_conservation_1586  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1457  -30
    arc_2_17_20  connected_order_arc_1458  -12
    arc_2_17_20  out_degree_1569  1
    arc_2_17_20  in_degree_1588  1
    arc_2_17_20  original_T_including_depot_unload_1595  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1457  1
    load_2_17_20  free_load_conservation_1574  1
    load_2_17_20  free_load_conservation_1592  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1459  -30
    arc_2_18_0  depot_return_or_bypass_1523  1
    arc_2_18_0  out_degree_1575  1
    arc_2_18_0  original_T_including_depot_unload_1595  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1459  1
    load_2_18_0  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1460  -30
    arc_2_18_10  connected_order_arc_1461  -12
    arc_2_18_10  in_degree_1525  1
    arc_2_18_10  out_degree_1575  1
    arc_2_18_10  original_T_including_depot_unload_1595  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1460  1
    load_2_18_10  segment_load_conservation_1528  -1
    load_2_18_10  segment_prefix_lb_1529  1
    load_2_18_10  segment_prefix_ub_1530  1
    load_2_18_10  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1462  -30
    arc_2_18_11  connected_order_arc_1463  -12
    arc_2_18_11  in_degree_1532  1
    arc_2_18_11  out_degree_1575  1
    arc_2_18_11  original_T_including_depot_unload_1595  1.7069358358556344e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1462  1
    load_2_18_11  segment_load_conservation_1535  -1
    load_2_18_11  segment_prefix_lb_1536  1
    load_2_18_11  segment_prefix_ub_1537  1
    load_2_18_11  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1464  -30
    arc_2_18_12  connected_order_arc_1465  -12
    arc_2_18_12  in_degree_1539  1
    arc_2_18_12  out_degree_1575  1
    arc_2_18_12  original_T_including_depot_unload_1595  1.3132316623300278e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1464  1
    load_2_18_12  segment_load_conservation_1542  -1
    load_2_18_12  segment_prefix_lb_1543  1
    load_2_18_12  segment_prefix_ub_1544  1
    load_2_18_12  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1466  -30
    arc_2_18_13  connected_order_arc_1467  -12
    arc_2_18_13  in_degree_1546  1
    arc_2_18_13  out_degree_1575  1
    arc_2_18_13  original_T_including_depot_unload_1595  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1466  1
    load_2_18_13  free_load_conservation_1550  -1
    load_2_18_13  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1468  -30
    arc_2_18_14  connected_order_arc_1469  -12
    arc_2_18_14  in_degree_1552  1
    arc_2_18_14  out_degree_1575  1
    arc_2_18_14  original_T_including_depot_unload_1595  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1468  1
    load_2_18_14  free_load_conservation_1556  -1
    load_2_18_14  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1470  -30
    arc_2_18_15  connected_order_arc_1471  -12
    arc_2_18_15  in_degree_1558  1
    arc_2_18_15  out_degree_1575  1
    arc_2_18_15  original_T_including_depot_unload_1595  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1470  1
    load_2_18_15  free_load_conservation_1562  -1
    load_2_18_15  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1472  -30
    arc_2_18_16  connected_order_arc_1473  -12
    arc_2_18_16  in_degree_1564  1
    arc_2_18_16  out_degree_1575  1
    arc_2_18_16  original_T_including_depot_unload_1595  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1472  1
    load_2_18_16  free_load_conservation_1568  -1
    load_2_18_16  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1474  -30
    arc_2_18_17  connected_order_arc_1475  -12
    arc_2_18_17  in_degree_1570  1
    arc_2_18_17  out_degree_1575  1
    arc_2_18_17  original_T_including_depot_unload_1595  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1474  1
    load_2_18_17  free_load_conservation_1574  -1
    load_2_18_17  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1476  -30
    arc_2_18_19  connected_order_arc_1477  -12
    arc_2_18_19  out_degree_1575  1
    arc_2_18_19  in_degree_1582  1
    arc_2_18_19  original_T_including_depot_unload_1595  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1476  1
    load_2_18_19  free_load_conservation_1580  1
    load_2_18_19  free_load_conservation_1586  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1478  -30
    arc_2_18_20  connected_order_arc_1479  -12
    arc_2_18_20  out_degree_1575  1
    arc_2_18_20  in_degree_1588  1
    arc_2_18_20  original_T_including_depot_unload_1595  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1478  1
    load_2_18_20  free_load_conservation_1580  1
    load_2_18_20  free_load_conservation_1592  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1480  -30
    arc_2_19_0  depot_return_or_bypass_1523  1
    arc_2_19_0  out_degree_1581  1
    arc_2_19_0  original_T_including_depot_unload_1595  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1480  1
    load_2_19_0  free_load_conservation_1586  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1481  -30
    arc_2_19_10  connected_order_arc_1482  -12
    arc_2_19_10  in_degree_1525  1
    arc_2_19_10  out_degree_1581  1
    arc_2_19_10  original_T_including_depot_unload_1595  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1481  1
    load_2_19_10  segment_load_conservation_1528  -1
    load_2_19_10  segment_prefix_lb_1529  1
    load_2_19_10  segment_prefix_ub_1530  1
    load_2_19_10  free_load_conservation_1586  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1483  -30
    arc_2_19_11  connected_order_arc_1484  -12
    arc_2_19_11  in_degree_1532  1
    arc_2_19_11  out_degree_1581  1
    arc_2_19_11  original_T_including_depot_unload_1595  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1483  1
    load_2_19_11  segment_load_conservation_1535  -1
    load_2_19_11  segment_prefix_lb_1536  1
    load_2_19_11  segment_prefix_ub_1537  1
    load_2_19_11  free_load_conservation_1586  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1485  -30
    arc_2_19_12  connected_order_arc_1486  -12
    arc_2_19_12  in_degree_1539  1
    arc_2_19_12  out_degree_1581  1
    arc_2_19_12  original_T_including_depot_unload_1595  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1485  1
    load_2_19_12  segment_load_conservation_1542  -1
    load_2_19_12  segment_prefix_lb_1543  1
    load_2_19_12  segment_prefix_ub_1544  1
    load_2_19_12  free_load_conservation_1586  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1487  -30
    arc_2_19_13  connected_order_arc_1488  -12
    arc_2_19_13  in_degree_1546  1
    arc_2_19_13  out_degree_1581  1
    arc_2_19_13  original_T_including_depot_unload_1595  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1487  1
    load_2_19_13  free_load_conservation_1550  -1
    load_2_19_13  free_load_conservation_1586  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1489  -30
    arc_2_19_14  connected_order_arc_1490  -12
    arc_2_19_14  in_degree_1552  1
    arc_2_19_14  out_degree_1581  1
    arc_2_19_14  original_T_including_depot_unload_1595  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1489  1
    load_2_19_14  free_load_conservation_1556  -1
    load_2_19_14  free_load_conservation_1586  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1491  -30
    arc_2_19_15  connected_order_arc_1492  -12
    arc_2_19_15  in_degree_1558  1
    arc_2_19_15  out_degree_1581  1
    arc_2_19_15  original_T_including_depot_unload_1595  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1491  1
    load_2_19_15  free_load_conservation_1562  -1
    load_2_19_15  free_load_conservation_1586  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1493  -30
    arc_2_19_16  connected_order_arc_1494  -12
    arc_2_19_16  in_degree_1564  1
    arc_2_19_16  out_degree_1581  1
    arc_2_19_16  original_T_including_depot_unload_1595  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1493  1
    load_2_19_16  free_load_conservation_1568  -1
    load_2_19_16  free_load_conservation_1586  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1495  -30
    arc_2_19_17  connected_order_arc_1496  -12
    arc_2_19_17  in_degree_1570  1
    arc_2_19_17  out_degree_1581  1
    arc_2_19_17  original_T_including_depot_unload_1595  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1495  1
    load_2_19_17  free_load_conservation_1574  -1
    load_2_19_17  free_load_conservation_1586  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1497  -30
    arc_2_19_18  connected_order_arc_1498  -12
    arc_2_19_18  in_degree_1576  1
    arc_2_19_18  out_degree_1581  1
    arc_2_19_18  original_T_including_depot_unload_1595  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1497  1
    load_2_19_18  free_load_conservation_1580  -1
    load_2_19_18  free_load_conservation_1586  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1499  -30
    arc_2_19_20  connected_order_arc_1500  -12
    arc_2_19_20  out_degree_1581  1
    arc_2_19_20  in_degree_1588  1
    arc_2_19_20  original_T_including_depot_unload_1595  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1499  1
    load_2_19_20  free_load_conservation_1586  1
    load_2_19_20  free_load_conservation_1592  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1501  -30
    arc_2_20_0  depot_return_or_bypass_1523  1
    arc_2_20_0  out_degree_1587  1
    arc_2_20_0  original_T_including_depot_unload_1595  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1501  1
    load_2_20_0  free_load_conservation_1592  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1502  -30
    arc_2_20_10  connected_order_arc_1503  -12
    arc_2_20_10  in_degree_1525  1
    arc_2_20_10  out_degree_1587  1
    arc_2_20_10  original_T_including_depot_unload_1595  8.6713096341893186e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1502  1
    load_2_20_10  segment_load_conservation_1528  -1
    load_2_20_10  segment_prefix_lb_1529  1
    load_2_20_10  segment_prefix_ub_1530  1
    load_2_20_10  free_load_conservation_1592  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1504  -30
    arc_2_20_11  connected_order_arc_1505  -12
    arc_2_20_11  in_degree_1532  1
    arc_2_20_11  out_degree_1587  1
    arc_2_20_11  original_T_including_depot_unload_1595  2.1488172932724365e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1504  1
    load_2_20_11  segment_load_conservation_1535  -1
    load_2_20_11  segment_prefix_lb_1536  1
    load_2_20_11  segment_prefix_ub_1537  1
    load_2_20_11  free_load_conservation_1592  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1506  -30
    arc_2_20_12  connected_order_arc_1507  -12
    arc_2_20_12  in_degree_1539  1
    arc_2_20_12  out_degree_1587  1
    arc_2_20_12  original_T_including_depot_unload_1595  1.3110718450902477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1506  1
    load_2_20_12  segment_load_conservation_1542  -1
    load_2_20_12  segment_prefix_lb_1543  1
    load_2_20_12  segment_prefix_ub_1544  1
    load_2_20_12  free_load_conservation_1592  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1508  -30
    arc_2_20_13  connected_order_arc_1509  -12
    arc_2_20_13  in_degree_1546  1
    arc_2_20_13  out_degree_1587  1
    arc_2_20_13  original_T_including_depot_unload_1595  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1508  1
    load_2_20_13  free_load_conservation_1550  -1
    load_2_20_13  free_load_conservation_1592  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1510  -30
    arc_2_20_14  connected_order_arc_1511  -12
    arc_2_20_14  in_degree_1552  1
    arc_2_20_14  out_degree_1587  1
    arc_2_20_14  original_T_including_depot_unload_1595  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1510  1
    load_2_20_14  free_load_conservation_1556  -1
    load_2_20_14  free_load_conservation_1592  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1512  -30
    arc_2_20_15  connected_order_arc_1513  -12
    arc_2_20_15  in_degree_1558  1
    arc_2_20_15  out_degree_1587  1
    arc_2_20_15  original_T_including_depot_unload_1595  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1512  1
    load_2_20_15  free_load_conservation_1562  -1
    load_2_20_15  free_load_conservation_1592  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1514  -30
    arc_2_20_16  connected_order_arc_1515  -12
    arc_2_20_16  in_degree_1564  1
    arc_2_20_16  out_degree_1587  1
    arc_2_20_16  original_T_including_depot_unload_1595  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1514  1
    load_2_20_16  free_load_conservation_1568  -1
    load_2_20_16  free_load_conservation_1592  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1516  -30
    arc_2_20_17  connected_order_arc_1517  -12
    arc_2_20_17  in_degree_1570  1
    arc_2_20_17  out_degree_1587  1
    arc_2_20_17  original_T_including_depot_unload_1595  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1516  1
    load_2_20_17  free_load_conservation_1574  -1
    load_2_20_17  free_load_conservation_1592  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1518  -30
    arc_2_20_18  connected_order_arc_1519  -12
    arc_2_20_18  in_degree_1576  1
    arc_2_20_18  out_degree_1587  1
    arc_2_20_18  original_T_including_depot_unload_1595  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1518  1
    load_2_20_18  free_load_conservation_1580  -1
    load_2_20_18  free_load_conservation_1592  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1520  -30
    arc_2_20_19  connected_order_arc_1521  -12
    arc_2_20_19  in_degree_1582  1
    arc_2_20_19  out_degree_1587  1
    arc_2_20_19  original_T_including_depot_unload_1595  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1520  1
    load_2_20_19  free_load_conservation_1586  -1
    load_2_20_19  free_load_conservation_1592  1
RHS
    RHS1      OBJ       -6.6075000000000006e-01
    RHS1      onehot_3_36  1
    RHS1      onehot_1_79  1
    RHS1      onehot_31_108  1
    RHS1      onehot_7_147  1
    RHS1      onehot_2_182  1
    RHS1      onehot_4_217  1
    RHS1      onehot_16_246  1
    RHS1      onehot_10_289  1
    RHS1      stock_ub_293  51
    RHS1      parent_nonstrict_scope_294  2.8244083613095733e-01
    RHS1      normalization_351  1
    RHS1      connected_order_arc_494  -12
    RHS1      connected_order_arc_496  -12
    RHS1      connected_order_arc_498  -12
    RHS1      connected_order_arc_500  -12
    RHS1      connected_order_arc_502  -12
    RHS1      connected_order_arc_504  -12
    RHS1      connected_order_arc_506  -12
    RHS1      connected_order_arc_508  -12
    RHS1      connected_order_arc_510  -12
    RHS1      connected_order_arc_512  -12
    RHS1      connected_order_arc_514  -12
    RHS1      connected_order_arc_517  -12
    RHS1      connected_order_arc_519  -12
    RHS1      connected_order_arc_521  -12
    RHS1      connected_order_arc_523  -12
    RHS1      connected_order_arc_525  -12
    RHS1      connected_order_arc_527  -12
    RHS1      connected_order_arc_529  -12
    RHS1      connected_order_arc_531  -12
    RHS1      connected_order_arc_533  -12
    RHS1      connected_order_arc_535  -12
    RHS1      connected_order_arc_537  -12
    RHS1      connected_order_arc_540  -12
    RHS1      connected_order_arc_542  -12
    RHS1      connected_order_arc_544  -12
    RHS1      connected_order_arc_546  -12
    RHS1      connected_order_arc_548  -12
    RHS1      connected_order_arc_550  -12
    RHS1      connected_order_arc_552  -12
    RHS1      connected_order_arc_554  -12
    RHS1      connected_order_arc_556  -12
    RHS1      connected_order_arc_558  -12
    RHS1      connected_order_arc_560  -12
    RHS1      connected_order_arc_563  -12
    RHS1      connected_order_arc_565  -12
    RHS1      connected_order_arc_567  -12
    RHS1      connected_order_arc_569  -12
    RHS1      connected_order_arc_571  -12
    RHS1      connected_order_arc_573  -12
    RHS1      connected_order_arc_575  -12
    RHS1      connected_order_arc_577  -12
    RHS1      connected_order_arc_579  -12
    RHS1      connected_order_arc_581  -12
    RHS1      connected_order_arc_583  -12
    RHS1      connected_order_arc_586  -12
    RHS1      connected_order_arc_588  -12
    RHS1      connected_order_arc_590  -12
    RHS1      connected_order_arc_592  -12
    RHS1      connected_order_arc_594  -12
    RHS1      connected_order_arc_596  -12
    RHS1      connected_order_arc_598  -12
    RHS1      connected_order_arc_600  -12
    RHS1      connected_order_arc_602  -12
    RHS1      connected_order_arc_604  -12
    RHS1      connected_order_arc_606  -12
    RHS1      connected_order_arc_609  -12
    RHS1      connected_order_arc_611  -12
    RHS1      connected_order_arc_613  -12
    RHS1      connected_order_arc_615  -12
    RHS1      connected_order_arc_617  -12
    RHS1      connected_order_arc_619  -12
    RHS1      connected_order_arc_621  -12
    RHS1      connected_order_arc_623  -12
    RHS1      connected_order_arc_625  -12
    RHS1      connected_order_arc_627  -12
    RHS1      connected_order_arc_629  -12
    RHS1      connected_order_arc_632  -12
    RHS1      connected_order_arc_634  -12
    RHS1      connected_order_arc_636  -12
    RHS1      connected_order_arc_638  -12
    RHS1      connected_order_arc_640  -12
    RHS1      connected_order_arc_642  -12
    RHS1      connected_order_arc_644  -12
    RHS1      connected_order_arc_646  -12
    RHS1      connected_order_arc_648  -12
    RHS1      connected_order_arc_650  -12
    RHS1      connected_order_arc_652  -12
    RHS1      connected_order_arc_655  -12
    RHS1      connected_order_arc_657  -12
    RHS1      connected_order_arc_659  -12
    RHS1      connected_order_arc_661  -12
    RHS1      connected_order_arc_663  -12
    RHS1      connected_order_arc_665  -12
    RHS1      connected_order_arc_667  -12
    RHS1      connected_order_arc_669  -12
    RHS1      connected_order_arc_671  -12
    RHS1      connected_order_arc_673  -12
    RHS1      connected_order_arc_675  -12
    RHS1      connected_order_arc_678  -12
    RHS1      connected_order_arc_680  -12
    RHS1      connected_order_arc_682  -12
    RHS1      connected_order_arc_684  -12
    RHS1      connected_order_arc_686  -12
    RHS1      connected_order_arc_688  -12
    RHS1      connected_order_arc_690  -12
    RHS1      connected_order_arc_692  -12
    RHS1      connected_order_arc_694  -12
    RHS1      connected_order_arc_696  -12
    RHS1      connected_order_arc_698  -12
    RHS1      connected_order_arc_701  -12
    RHS1      connected_order_arc_703  -12
    RHS1      connected_order_arc_705  -12
    RHS1      connected_order_arc_707  -12
    RHS1      connected_order_arc_709  -12
    RHS1      connected_order_arc_711  -12
    RHS1      connected_order_arc_713  -12
    RHS1      connected_order_arc_715  -12
    RHS1      connected_order_arc_717  -12
    RHS1      connected_order_arc_719  -12
    RHS1      connected_order_arc_721  -12
    RHS1      connected_order_arc_724  -12
    RHS1      connected_order_arc_726  -12
    RHS1      connected_order_arc_728  -12
    RHS1      connected_order_arc_730  -12
    RHS1      connected_order_arc_732  -12
    RHS1      connected_order_arc_734  -12
    RHS1      connected_order_arc_736  -12
    RHS1      connected_order_arc_738  -12
    RHS1      connected_order_arc_740  -12
    RHS1      connected_order_arc_742  -12
    RHS1      connected_order_arc_744  -12
    RHS1      connected_order_arc_747  -12
    RHS1      connected_order_arc_749  -12
    RHS1      connected_order_arc_751  -12
    RHS1      connected_order_arc_753  -12
    RHS1      connected_order_arc_755  -12
    RHS1      connected_order_arc_757  -12
    RHS1      connected_order_arc_759  -12
    RHS1      connected_order_arc_761  -12
    RHS1      connected_order_arc_763  -12
    RHS1      connected_order_arc_765  -12
    RHS1      connected_order_arc_767  -12
    RHS1      depot_departure_or_bypass_768  1
    RHS1      depot_return_or_bypass_769  1
    RHS1      segment_load_conservation_774  -4
    RHS1      segment_prefix_lb_775  4
    RHS1      segment_prefix_ub_776  20
    RHS1      segment_load_conservation_781  -2
    RHS1      segment_prefix_lb_782  2
    RHS1      segment_prefix_ub_783  20
    RHS1      segment_load_conservation_788  5
    RHS1      segment_prefix_ub_790  15
    RHS1      segment_load_conservation_795  -9
    RHS1      segment_prefix_lb_796  9
    RHS1      segment_prefix_ub_797  15
    RHS1      fixed_segment_relative_order_846  1
    RHS1      fixed_segment_relative_order_847  1
    RHS1      fixed_segment_relative_order_848  1
    RHS1      original_T_including_depot_unload_849  5.2885578181927040e+03
    RHS1      connected_order_arc_866  -13
    RHS1      connected_order_arc_868  -13
    RHS1      connected_order_arc_870  -13
    RHS1      connected_order_arc_872  -13
    RHS1      connected_order_arc_874  -13
    RHS1      connected_order_arc_876  -13
    RHS1      connected_order_arc_878  -13
    RHS1      connected_order_arc_880  -13
    RHS1      connected_order_arc_882  -13
    RHS1      connected_order_arc_884  -13
    RHS1      connected_order_arc_886  -13
    RHS1      connected_order_arc_888  -13
    RHS1      connected_order_arc_891  -13
    RHS1      connected_order_arc_893  -13
    RHS1      connected_order_arc_895  -13
    RHS1      connected_order_arc_897  -13
    RHS1      connected_order_arc_899  -13
    RHS1      connected_order_arc_901  -13
    RHS1      connected_order_arc_903  -13
    RHS1      connected_order_arc_905  -13
    RHS1      connected_order_arc_907  -13
    RHS1      connected_order_arc_909  -13
    RHS1      connected_order_arc_911  -13
    RHS1      connected_order_arc_913  -13
    RHS1      connected_order_arc_916  -13
    RHS1      connected_order_arc_918  -13
    RHS1      connected_order_arc_920  -13
    RHS1      connected_order_arc_922  -13
    RHS1      connected_order_arc_924  -13
    RHS1      connected_order_arc_926  -13
    RHS1      connected_order_arc_928  -13
    RHS1      connected_order_arc_930  -13
    RHS1      connected_order_arc_932  -13
    RHS1      connected_order_arc_934  -13
    RHS1      connected_order_arc_936  -13
    RHS1      connected_order_arc_938  -13
    RHS1      connected_order_arc_941  -13
    RHS1      connected_order_arc_943  -13
    RHS1      connected_order_arc_945  -13
    RHS1      connected_order_arc_947  -13
    RHS1      connected_order_arc_949  -13
    RHS1      connected_order_arc_951  -13
    RHS1      connected_order_arc_953  -13
    RHS1      connected_order_arc_955  -13
    RHS1      connected_order_arc_957  -13
    RHS1      connected_order_arc_959  -13
    RHS1      connected_order_arc_961  -13
    RHS1      connected_order_arc_963  -13
    RHS1      connected_order_arc_966  -13
    RHS1      connected_order_arc_968  -13
    RHS1      connected_order_arc_970  -13
    RHS1      connected_order_arc_972  -13
    RHS1      connected_order_arc_974  -13
    RHS1      connected_order_arc_976  -13
    RHS1      connected_order_arc_978  -13
    RHS1      connected_order_arc_980  -13
    RHS1      connected_order_arc_982  -13
    RHS1      connected_order_arc_984  -13
    RHS1      connected_order_arc_986  -13
    RHS1      connected_order_arc_988  -13
    RHS1      connected_order_arc_991  -13
    RHS1      connected_order_arc_993  -13
    RHS1      connected_order_arc_995  -13
    RHS1      connected_order_arc_997  -13
    RHS1      connected_order_arc_999  -13
    RHS1      connected_order_arc_1001  -13
    RHS1      connected_order_arc_1003  -13
    RHS1      connected_order_arc_1005  -13
    RHS1      connected_order_arc_1007  -13
    RHS1      connected_order_arc_1009  -13
    RHS1      connected_order_arc_1011  -13
    RHS1      connected_order_arc_1013  -13
    RHS1      connected_order_arc_1016  -13
    RHS1      connected_order_arc_1018  -13
    RHS1      connected_order_arc_1020  -13
    RHS1      connected_order_arc_1022  -13
    RHS1      connected_order_arc_1024  -13
    RHS1      connected_order_arc_1026  -13
    RHS1      connected_order_arc_1028  -13
    RHS1      connected_order_arc_1030  -13
    RHS1      connected_order_arc_1032  -13
    RHS1      connected_order_arc_1034  -13
    RHS1      connected_order_arc_1036  -13
    RHS1      connected_order_arc_1038  -13
    RHS1      connected_order_arc_1041  -13
    RHS1      connected_order_arc_1043  -13
    RHS1      connected_order_arc_1045  -13
    RHS1      connected_order_arc_1047  -13
    RHS1      connected_order_arc_1049  -13
    RHS1      connected_order_arc_1051  -13
    RHS1      connected_order_arc_1053  -13
    RHS1      connected_order_arc_1055  -13
    RHS1      connected_order_arc_1057  -13
    RHS1      connected_order_arc_1059  -13
    RHS1      connected_order_arc_1061  -13
    RHS1      connected_order_arc_1063  -13
    RHS1      connected_order_arc_1066  -13
    RHS1      connected_order_arc_1068  -13
    RHS1      connected_order_arc_1070  -13
    RHS1      connected_order_arc_1072  -13
    RHS1      connected_order_arc_1074  -13
    RHS1      connected_order_arc_1076  -13
    RHS1      connected_order_arc_1078  -13
    RHS1      connected_order_arc_1080  -13
    RHS1      connected_order_arc_1082  -13
    RHS1      connected_order_arc_1084  -13
    RHS1      connected_order_arc_1086  -13
    RHS1      connected_order_arc_1088  -13
    RHS1      connected_order_arc_1091  -13
    RHS1      connected_order_arc_1093  -13
    RHS1      connected_order_arc_1095  -13
    RHS1      connected_order_arc_1097  -13
    RHS1      connected_order_arc_1099  -13
    RHS1      connected_order_arc_1101  -13
    RHS1      connected_order_arc_1103  -13
    RHS1      connected_order_arc_1105  -13
    RHS1      connected_order_arc_1107  -13
    RHS1      connected_order_arc_1109  -13
    RHS1      connected_order_arc_1111  -13
    RHS1      connected_order_arc_1113  -13
    RHS1      connected_order_arc_1116  -13
    RHS1      connected_order_arc_1118  -13
    RHS1      connected_order_arc_1120  -13
    RHS1      connected_order_arc_1122  -13
    RHS1      connected_order_arc_1124  -13
    RHS1      connected_order_arc_1126  -13
    RHS1      connected_order_arc_1128  -13
    RHS1      connected_order_arc_1130  -13
    RHS1      connected_order_arc_1132  -13
    RHS1      connected_order_arc_1134  -13
    RHS1      connected_order_arc_1136  -13
    RHS1      connected_order_arc_1138  -13
    RHS1      connected_order_arc_1141  -13
    RHS1      connected_order_arc_1143  -13
    RHS1      connected_order_arc_1145  -13
    RHS1      connected_order_arc_1147  -13
    RHS1      connected_order_arc_1149  -13
    RHS1      connected_order_arc_1151  -13
    RHS1      connected_order_arc_1153  -13
    RHS1      connected_order_arc_1155  -13
    RHS1      connected_order_arc_1157  -13
    RHS1      connected_order_arc_1159  -13
    RHS1      connected_order_arc_1161  -13
    RHS1      connected_order_arc_1163  -13
    RHS1      connected_order_arc_1166  -13
    RHS1      connected_order_arc_1168  -13
    RHS1      connected_order_arc_1170  -13
    RHS1      connected_order_arc_1172  -13
    RHS1      connected_order_arc_1174  -13
    RHS1      connected_order_arc_1176  -13
    RHS1      connected_order_arc_1178  -13
    RHS1      connected_order_arc_1180  -13
    RHS1      connected_order_arc_1182  -13
    RHS1      connected_order_arc_1184  -13
    RHS1      connected_order_arc_1186  -13
    RHS1      connected_order_arc_1188  -13
    RHS1      depot_departure_or_bypass_1189  1
    RHS1      depot_return_or_bypass_1190  1
    RHS1      segment_load_conservation_1195  6
    RHS1      segment_prefix_ub_1197  19
    RHS1      segment_load_conservation_1202  -5
    RHS1      segment_prefix_lb_1203  6
    RHS1      segment_prefix_ub_1204  25
    RHS1      segment_load_conservation_1209  3
    RHS1      segment_prefix_ub_1211  22
    RHS1      segment_load_conservation_1216  3
    RHS1      segment_prefix_ub_1218  22
    RHS1      segment_load_conservation_1223  -5
    RHS1      segment_prefix_lb_1224  5
    RHS1      segment_prefix_ub_1225  25
    RHS1      fixed_segment_relative_order_1274  1
    RHS1      fixed_segment_relative_order_1275  1
    RHS1      fixed_segment_relative_order_1276  1
    RHS1      fixed_segment_relative_order_1277  1
    RHS1      original_T_including_depot_unload_1278  2.2933958320926176e+03
    RHS1      connected_order_arc_1293  -11
    RHS1      connected_order_arc_1295  -11
    RHS1      connected_order_arc_1297  -11
    RHS1      connected_order_arc_1299  -11
    RHS1      connected_order_arc_1301  -11
    RHS1      connected_order_arc_1303  -11
    RHS1      connected_order_arc_1305  -11
    RHS1      connected_order_arc_1307  -11
    RHS1      connected_order_arc_1309  -11
    RHS1      connected_order_arc_1311  -11
    RHS1      connected_order_arc_1314  -11
    RHS1      connected_order_arc_1316  -11
    RHS1      connected_order_arc_1318  -11
    RHS1      connected_order_arc_1320  -11
    RHS1      connected_order_arc_1322  -11
    RHS1      connected_order_arc_1324  -11
    RHS1      connected_order_arc_1326  -11
    RHS1      connected_order_arc_1328  -11
    RHS1      connected_order_arc_1330  -11
    RHS1      connected_order_arc_1332  -11
    RHS1      connected_order_arc_1335  -11
    RHS1      connected_order_arc_1337  -11
    RHS1      connected_order_arc_1339  -11
    RHS1      connected_order_arc_1341  -11
    RHS1      connected_order_arc_1343  -11
    RHS1      connected_order_arc_1345  -11
    RHS1      connected_order_arc_1347  -11
    RHS1      connected_order_arc_1349  -11
    RHS1      connected_order_arc_1351  -11
    RHS1      connected_order_arc_1353  -11
    RHS1      connected_order_arc_1356  -11
    RHS1      connected_order_arc_1358  -11
    RHS1      connected_order_arc_1360  -11
    RHS1      connected_order_arc_1362  -11
    RHS1      connected_order_arc_1364  -11
    RHS1      connected_order_arc_1366  -11
    RHS1      connected_order_arc_1368  -11
    RHS1      connected_order_arc_1370  -11
    RHS1      connected_order_arc_1372  -11
    RHS1      connected_order_arc_1374  -11
    RHS1      connected_order_arc_1377  -11
    RHS1      connected_order_arc_1379  -11
    RHS1      connected_order_arc_1381  -11
    RHS1      connected_order_arc_1383  -11
    RHS1      connected_order_arc_1385  -11
    RHS1      connected_order_arc_1387  -11
    RHS1      connected_order_arc_1389  -11
    RHS1      connected_order_arc_1391  -11
    RHS1      connected_order_arc_1393  -11
    RHS1      connected_order_arc_1395  -11
    RHS1      connected_order_arc_1398  -11
    RHS1      connected_order_arc_1400  -11
    RHS1      connected_order_arc_1402  -11
    RHS1      connected_order_arc_1404  -11
    RHS1      connected_order_arc_1406  -11
    RHS1      connected_order_arc_1408  -11
    RHS1      connected_order_arc_1410  -11
    RHS1      connected_order_arc_1412  -11
    RHS1      connected_order_arc_1414  -11
    RHS1      connected_order_arc_1416  -11
    RHS1      connected_order_arc_1419  -11
    RHS1      connected_order_arc_1421  -11
    RHS1      connected_order_arc_1423  -11
    RHS1      connected_order_arc_1425  -11
    RHS1      connected_order_arc_1427  -11
    RHS1      connected_order_arc_1429  -11
    RHS1      connected_order_arc_1431  -11
    RHS1      connected_order_arc_1433  -11
    RHS1      connected_order_arc_1435  -11
    RHS1      connected_order_arc_1437  -11
    RHS1      connected_order_arc_1440  -11
    RHS1      connected_order_arc_1442  -11
    RHS1      connected_order_arc_1444  -11
    RHS1      connected_order_arc_1446  -11
    RHS1      connected_order_arc_1448  -11
    RHS1      connected_order_arc_1450  -11
    RHS1      connected_order_arc_1452  -11
    RHS1      connected_order_arc_1454  -11
    RHS1      connected_order_arc_1456  -11
    RHS1      connected_order_arc_1458  -11
    RHS1      connected_order_arc_1461  -11
    RHS1      connected_order_arc_1463  -11
    RHS1      connected_order_arc_1465  -11
    RHS1      connected_order_arc_1467  -11
    RHS1      connected_order_arc_1469  -11
    RHS1      connected_order_arc_1471  -11
    RHS1      connected_order_arc_1473  -11
    RHS1      connected_order_arc_1475  -11
    RHS1      connected_order_arc_1477  -11
    RHS1      connected_order_arc_1479  -11
    RHS1      connected_order_arc_1482  -11
    RHS1      connected_order_arc_1484  -11
    RHS1      connected_order_arc_1486  -11
    RHS1      connected_order_arc_1488  -11
    RHS1      connected_order_arc_1490  -11
    RHS1      connected_order_arc_1492  -11
    RHS1      connected_order_arc_1494  -11
    RHS1      connected_order_arc_1496  -11
    RHS1      connected_order_arc_1498  -11
    RHS1      connected_order_arc_1500  -11
    RHS1      connected_order_arc_1503  -11
    RHS1      connected_order_arc_1505  -11
    RHS1      connected_order_arc_1507  -11
    RHS1      connected_order_arc_1509  -11
    RHS1      connected_order_arc_1511  -11
    RHS1      connected_order_arc_1513  -11
    RHS1      connected_order_arc_1515  -11
    RHS1      connected_order_arc_1517  -11
    RHS1      connected_order_arc_1519  -11
    RHS1      connected_order_arc_1521  -11
    RHS1      depot_departure_or_bypass_1522  1
    RHS1      depot_return_or_bypass_1523  1
    RHS1      segment_load_conservation_1528  2
    RHS1      segment_prefix_ub_1530  28
    RHS1      segment_prefix_ub_1537  27
    RHS1      segment_load_conservation_1542  2
    RHS1      segment_prefix_ub_1544  24
    RHS1      fixed_segment_relative_order_1593  1
    RHS1      fixed_segment_relative_order_1594  1
    RHS1      original_T_including_depot_unload_1595  4.2424928979880842e+03
BOUNDS
 LO BND1      t         2.5591030952935655e-02
 UP BND1      t         4.3428807775868064e-02
 UP BND1      q         5.3744083613095739e-01
 BV BND1      x_3_0   
 UP BND1      w_3_0     4.3428807775868064e-02
 BV BND1      x_3_1   
 UP BND1      w_3_1     4.3428807775868064e-02
 BV BND1      x_3_2   
 UP BND1      w_3_2     4.3428807775868064e-02
 BV BND1      x_3_3   
 UP BND1      w_3_3     4.3428807775868064e-02
 BV BND1      x_3_4   
 UP BND1      w_3_4     4.3428807775868064e-02
 BV BND1      x_3_5   
 UP BND1      w_3_5     4.3428807775868064e-02
 BV BND1      x_3_6   
 UP BND1      w_3_6     4.3428807775868064e-02
 BV BND1      x_3_7   
 UP BND1      w_3_7     4.3428807775868064e-02
 BV BND1      x_3_8   
 UP BND1      w_3_8     4.3428807775868064e-02
 BV BND1      x_3_9   
 UP BND1      w_3_9     4.3428807775868064e-02
 BV BND1      x_3_10  
 UP BND1      w_3_10    4.3428807775868064e-02
 BV BND1      x_3_11  
 UP BND1      w_3_11    4.3428807775868064e-02
 BV BND1      x_3_12  
 UP BND1      w_3_12    4.3428807775868064e-02
 BV BND1      x_3_13  
 UP BND1      w_3_13    4.3428807775868064e-02
 BV BND1      x_3_14  
 UP BND1      w_3_14    4.3428807775868064e-02
 BV BND1      x_3_15  
 UP BND1      w_3_15    4.3428807775868064e-02
 BV BND1      x_3_16  
 UP BND1      w_3_16    4.3428807775868064e-02
 BV BND1      x_3_17  
 UP BND1      w_3_17    4.3428807775868064e-02
 UP BND1      rho_3     1
 BV BND1      x_1_0   
 UP BND1      w_1_0     4.3428807775868064e-02
 BV BND1      x_1_1   
 UP BND1      w_1_1     4.3428807775868064e-02
 BV BND1      x_1_2   
 UP BND1      w_1_2     4.3428807775868064e-02
 BV BND1      x_1_3   
 UP BND1      w_1_3     4.3428807775868064e-02
 BV BND1      x_1_4   
 UP BND1      w_1_4     4.3428807775868064e-02
 BV BND1      x_1_5   
 UP BND1      w_1_5     4.3428807775868064e-02
 BV BND1      x_1_6   
 UP BND1      w_1_6     4.3428807775868064e-02
 BV BND1      x_1_7   
 UP BND1      w_1_7     4.3428807775868064e-02
 BV BND1      x_1_8   
 UP BND1      w_1_8     4.3428807775868064e-02
 BV BND1      x_1_9   
 UP BND1      w_1_9     4.3428807775868064e-02
 BV BND1      x_1_10  
 UP BND1      w_1_10    4.3428807775868064e-02
 BV BND1      x_1_11  
 UP BND1      w_1_11    4.3428807775868064e-02
 BV BND1      x_1_12  
 UP BND1      w_1_12    4.3428807775868064e-02
 BV BND1      x_1_13  
 UP BND1      w_1_13    4.3428807775868064e-02
 BV BND1      x_1_14  
 UP BND1      w_1_14    4.3428807775868064e-02
 BV BND1      x_1_15  
 UP BND1      w_1_15    4.3428807775868064e-02
 BV BND1      x_1_16  
 UP BND1      w_1_16    4.3428807775868064e-02
 BV BND1      x_1_17  
 UP BND1      w_1_17    4.3428807775868064e-02
 BV BND1      x_1_18  
 UP BND1      w_1_18    4.3428807775868064e-02
 BV BND1      x_1_19  
 UP BND1      w_1_19    4.3428807775868064e-02
 UP BND1      rho_1     1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.3428807775868064e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.3428807775868064e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.3428807775868064e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.3428807775868064e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.3428807775868064e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.3428807775868064e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.3428807775868064e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.3428807775868064e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.3428807775868064e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.3428807775868064e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.3428807775868064e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.3428807775868064e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.3428807775868064e-02
 UP BND1      rho_31    1
 BV BND1      x_7_0   
 UP BND1      w_7_0     4.3428807775868064e-02
 BV BND1      x_7_1   
 UP BND1      w_7_1     4.3428807775868064e-02
 BV BND1      x_7_2   
 UP BND1      w_7_2     4.3428807775868064e-02
 BV BND1      x_7_3   
 UP BND1      w_7_3     4.3428807775868064e-02
 BV BND1      x_7_4   
 UP BND1      w_7_4     4.3428807775868064e-02
 BV BND1      x_7_5   
 UP BND1      w_7_5     4.3428807775868064e-02
 BV BND1      x_7_6   
 UP BND1      w_7_6     4.3428807775868064e-02
 BV BND1      x_7_7   
 UP BND1      w_7_7     4.3428807775868064e-02
 BV BND1      x_7_8   
 UP BND1      w_7_8     4.3428807775868064e-02
 BV BND1      x_7_9   
 UP BND1      w_7_9     4.3428807775868064e-02
 BV BND1      x_7_10  
 UP BND1      w_7_10    4.3428807775868064e-02
 BV BND1      x_7_11  
 UP BND1      w_7_11    4.3428807775868064e-02
 BV BND1      x_7_12  
 UP BND1      w_7_12    4.3428807775868064e-02
 BV BND1      x_7_13  
 UP BND1      w_7_13    4.3428807775868064e-02
 BV BND1      x_7_14  
 UP BND1      w_7_14    4.3428807775868064e-02
 BV BND1      x_7_15  
 UP BND1      w_7_15    4.3428807775868064e-02
 BV BND1      x_7_16  
 UP BND1      w_7_16    4.3428807775868064e-02
 BV BND1      x_7_17  
 UP BND1      w_7_17    4.3428807775868064e-02
 UP BND1      rho_7     1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.3428807775868064e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.3428807775868064e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.3428807775868064e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.3428807775868064e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.3428807775868064e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.3428807775868064e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.3428807775868064e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.3428807775868064e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.3428807775868064e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.3428807775868064e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.3428807775868064e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.3428807775868064e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.3428807775868064e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.3428807775868064e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.3428807775868064e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.3428807775868064e-02
 UP BND1      rho_2     1
 BV BND1      x_4_0   
 UP BND1      w_4_0     4.3428807775868064e-02
 BV BND1      x_4_1   
 UP BND1      w_4_1     4.3428807775868064e-02
 BV BND1      x_4_2   
 UP BND1      w_4_2     4.3428807775868064e-02
 BV BND1      x_4_3   
 UP BND1      w_4_3     4.3428807775868064e-02
 BV BND1      x_4_4   
 UP BND1      w_4_4     4.3428807775868064e-02
 BV BND1      x_4_5   
 UP BND1      w_4_5     4.3428807775868064e-02
 BV BND1      x_4_6   
 UP BND1      w_4_6     4.3428807775868064e-02
 BV BND1      x_4_7   
 UP BND1      w_4_7     4.3428807775868064e-02
 BV BND1      x_4_8   
 UP BND1      w_4_8     4.3428807775868064e-02
 BV BND1      x_4_9   
 UP BND1      w_4_9     4.3428807775868064e-02
 BV BND1      x_4_10  
 UP BND1      w_4_10    4.3428807775868064e-02
 BV BND1      x_4_11  
 UP BND1      w_4_11    4.3428807775868064e-02
 BV BND1      x_4_12  
 UP BND1      w_4_12    4.3428807775868064e-02
 BV BND1      x_4_13  
 UP BND1      w_4_13    4.3428807775868064e-02
 BV BND1      x_4_14  
 UP BND1      w_4_14    4.3428807775868064e-02
 BV BND1      x_4_15  
 UP BND1      w_4_15    4.3428807775868064e-02
 UP BND1      rho_4     1
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.3428807775868064e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.3428807775868064e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.3428807775868064e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.3428807775868064e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.3428807775868064e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.3428807775868064e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.3428807775868064e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.3428807775868064e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.3428807775868064e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.3428807775868064e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.3428807775868064e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.3428807775868064e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.3428807775868064e-02
 UP BND1      rho_16    1
 BV BND1      x_10_0  
 UP BND1      w_10_0    4.3428807775868064e-02
 BV BND1      x_10_1  
 UP BND1      w_10_1    4.3428807775868064e-02
 BV BND1      x_10_2  
 UP BND1      w_10_2    4.3428807775868064e-02
 BV BND1      x_10_3  
 UP BND1      w_10_3    4.3428807775868064e-02
 BV BND1      x_10_4  
 UP BND1      w_10_4    4.3428807775868064e-02
 BV BND1      x_10_5  
 UP BND1      w_10_5    4.3428807775868064e-02
 BV BND1      x_10_6  
 UP BND1      w_10_6    4.3428807775868064e-02
 BV BND1      x_10_7  
 UP BND1      w_10_7    4.3428807775868064e-02
 BV BND1      x_10_8  
 UP BND1      w_10_8    4.3428807775868064e-02
 BV BND1      x_10_9  
 UP BND1      w_10_9    4.3428807775868064e-02
 BV BND1      x_10_10 
 UP BND1      w_10_10   4.3428807775868064e-02
 BV BND1      x_10_11 
 UP BND1      w_10_11   4.3428807775868064e-02
 BV BND1      x_10_12 
 UP BND1      w_10_12   4.3428807775868064e-02
 BV BND1      x_10_13 
 UP BND1      w_10_13   4.3428807775868064e-02
 BV BND1      x_10_14 
 UP BND1      w_10_14   4.3428807775868064e-02
 BV BND1      x_10_15 
 UP BND1      w_10_15   4.3428807775868064e-02
 BV BND1      x_10_16 
 UP BND1      w_10_16   4.3428807775868064e-02
 BV BND1      x_10_17 
 UP BND1      w_10_17   4.3428807775868064e-02
 BV BND1      x_10_18 
 UP BND1      w_10_18   4.3428807775868064e-02
 BV BND1      x_10_19 
 UP BND1      w_10_19   4.3428807775868064e-02
 UP BND1      rho_10    1
 UP BND1      a_3_1     1
 UP BND1      a_3_31    1
 UP BND1      a_3_7     1
 UP BND1      a_3_2     1
 UP BND1      a_3_4     1
 UP BND1      a_3_16    1
 UP BND1      a_3_10    1
 UP BND1      a_1_31    1
 UP BND1      a_1_7     1
 UP BND1      a_1_2     1
 UP BND1      a_1_4     1
 UP BND1      a_1_16    1
 UP BND1      a_1_10    1
 UP BND1      a_31_7    1
 UP BND1      a_31_2    1
 UP BND1      a_31_4    1
 UP BND1      a_31_16   1
 UP BND1      a_31_10   1
 UP BND1      a_7_2     1
 UP BND1      a_7_4     1
 UP BND1      a_7_16    1
 UP BND1      a_7_10    1
 UP BND1      a_2_4     1
 UP BND1      a_2_16    1
 UP BND1      a_2_10    1
 UP BND1      a_4_16    1
 UP BND1      a_4_10    1
 UP BND1      a_16_10   1
 BV BND1      service_0_3_0
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_0_3_4
 BV BND1      service_0_3_5
 BV BND1      service_0_3_6
 BV BND1      service_0_3_7
 BV BND1      service_0_3_8
 BV BND1      service_0_3_9
 BV BND1      service_0_3_10
 BV BND1      service_0_3_11
 BV BND1      service_0_3_13
 BV BND1      service_0_3_14
 BV BND1      service_0_3_15
 BV BND1      service_0_3_16
 BV BND1      service_0_3_17
 BV BND1      service_1_3_0
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_1_3_4
 BV BND1      service_1_3_5
 BV BND1      service_1_3_6
 BV BND1      service_1_3_7
 BV BND1      service_1_3_8
 BV BND1      service_1_3_9
 BV BND1      service_1_3_10
 BV BND1      service_1_3_11
 BV BND1      service_1_3_13
 BV BND1      service_1_3_14
 BV BND1      service_1_3_15
 BV BND1      service_1_3_16
 BV BND1      service_1_3_17
 BV BND1      service_2_3_0
 BV BND1      service_2_3_1
 BV BND1      service_2_3_2
 BV BND1      service_2_3_3
 BV BND1      service_2_3_4
 BV BND1      service_2_3_5
 BV BND1      service_2_3_6
 BV BND1      service_2_3_7
 BV BND1      service_2_3_8
 BV BND1      service_2_3_9
 BV BND1      service_2_3_10
 BV BND1      service_2_3_11
 BV BND1      service_2_3_13
 BV BND1      service_2_3_14
 BV BND1      service_2_3_15
 BV BND1      service_2_3_16
 BV BND1      service_2_3_17
 BV BND1      service_0_1_0
 BV BND1      service_0_1_1
 BV BND1      service_0_1_3
 BV BND1      service_0_1_4
 BV BND1      service_0_1_5
 BV BND1      service_0_1_6
 BV BND1      service_0_1_7
 BV BND1      service_0_1_8
 BV BND1      service_0_1_9
 BV BND1      service_0_1_10
 BV BND1      service_0_1_11
 BV BND1      service_0_1_12
 BV BND1      service_0_1_13
 BV BND1      service_0_1_14
 BV BND1      service_0_1_15
 BV BND1      service_0_1_16
 BV BND1      service_0_1_17
 BV BND1      service_0_1_18
 BV BND1      service_0_1_19
 BV BND1      service_1_1_0
 BV BND1      service_1_1_1
 BV BND1      service_1_1_3
 BV BND1      service_1_1_4
 BV BND1      service_1_1_5
 BV BND1      service_1_1_6
 BV BND1      service_1_1_7
 BV BND1      service_1_1_8
 BV BND1      service_1_1_9
 BV BND1      service_1_1_10
 BV BND1      service_1_1_11
 BV BND1      service_1_1_12
 BV BND1      service_1_1_13
 BV BND1      service_1_1_14
 BV BND1      service_1_1_15
 BV BND1      service_1_1_16
 BV BND1      service_1_1_17
 BV BND1      service_1_1_18
 BV BND1      service_1_1_19
 BV BND1      service_2_1_0
 BV BND1      service_2_1_1
 BV BND1      service_2_1_3
 BV BND1      service_2_1_4
 BV BND1      service_2_1_5
 BV BND1      service_2_1_6
 BV BND1      service_2_1_7
 BV BND1      service_2_1_8
 BV BND1      service_2_1_9
 BV BND1      service_2_1_10
 BV BND1      service_2_1_11
 BV BND1      service_2_1_12
 BV BND1      service_2_1_13
 BV BND1      service_2_1_14
 BV BND1      service_2_1_15
 BV BND1      service_2_1_16
 BV BND1      service_2_1_17
 BV BND1      service_2_1_18
 BV BND1      service_2_1_19
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_7_0
 BV BND1      service_0_7_1
 BV BND1      service_0_7_2
 BV BND1      service_0_7_3
 BV BND1      service_0_7_4
 BV BND1      service_0_7_5
 BV BND1      service_0_7_6
 BV BND1      service_0_7_7
 BV BND1      service_0_7_8
 BV BND1      service_0_7_9
 BV BND1      service_0_7_10
 BV BND1      service_0_7_11
 BV BND1      service_0_7_13
 BV BND1      service_0_7_14
 BV BND1      service_0_7_15
 BV BND1      service_0_7_16
 BV BND1      service_0_7_17
 BV BND1      service_1_7_0
 BV BND1      service_1_7_1
 BV BND1      service_1_7_2
 BV BND1      service_1_7_3
 BV BND1      service_1_7_4
 BV BND1      service_1_7_5
 BV BND1      service_1_7_6
 BV BND1      service_1_7_7
 BV BND1      service_1_7_8
 BV BND1      service_1_7_9
 BV BND1      service_1_7_10
 BV BND1      service_1_7_11
 BV BND1      service_1_7_13
 BV BND1      service_1_7_14
 BV BND1      service_1_7_15
 BV BND1      service_1_7_16
 BV BND1      service_1_7_17
 BV BND1      service_2_7_0
 BV BND1      service_2_7_1
 BV BND1      service_2_7_2
 BV BND1      service_2_7_3
 BV BND1      service_2_7_4
 BV BND1      service_2_7_5
 BV BND1      service_2_7_6
 BV BND1      service_2_7_7
 BV BND1      service_2_7_8
 BV BND1      service_2_7_9
 BV BND1      service_2_7_10
 BV BND1      service_2_7_11
 BV BND1      service_2_7_13
 BV BND1      service_2_7_14
 BV BND1      service_2_7_15
 BV BND1      service_2_7_16
 BV BND1      service_2_7_17
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_4_0
 BV BND1      service_0_4_1
 BV BND1      service_0_4_2
 BV BND1      service_0_4_3
 BV BND1      service_0_4_4
 BV BND1      service_0_4_5
 BV BND1      service_0_4_6
 BV BND1      service_0_4_7
 BV BND1      service_0_4_8
 BV BND1      service_0_4_9
 BV BND1      service_0_4_10
 BV BND1      service_0_4_12
 BV BND1      service_0_4_13
 BV BND1      service_0_4_14
 BV BND1      service_0_4_15
 BV BND1      service_1_4_0
 BV BND1      service_1_4_1
 BV BND1      service_1_4_2
 BV BND1      service_1_4_3
 BV BND1      service_1_4_4
 BV BND1      service_1_4_5
 BV BND1      service_1_4_6
 BV BND1      service_1_4_7
 BV BND1      service_1_4_8
 BV BND1      service_1_4_9
 BV BND1      service_1_4_10
 BV BND1      service_1_4_12
 BV BND1      service_1_4_13
 BV BND1      service_1_4_14
 BV BND1      service_1_4_15
 BV BND1      service_2_4_0
 BV BND1      service_2_4_1
 BV BND1      service_2_4_2
 BV BND1      service_2_4_3
 BV BND1      service_2_4_4
 BV BND1      service_2_4_5
 BV BND1      service_2_4_6
 BV BND1      service_2_4_7
 BV BND1      service_2_4_8
 BV BND1      service_2_4_9
 BV BND1      service_2_4_10
 BV BND1      service_2_4_12
 BV BND1      service_2_4_13
 BV BND1      service_2_4_14
 BV BND1      service_2_4_15
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_2_16_0
 BV BND1      service_2_16_2
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_0_10_0
 BV BND1      service_0_10_1
 BV BND1      service_0_10_2
 BV BND1      service_0_10_3
 BV BND1      service_0_10_4
 BV BND1      service_0_10_5
 BV BND1      service_0_10_6
 BV BND1      service_0_10_7
 BV BND1      service_0_10_8
 BV BND1      service_0_10_9
 BV BND1      service_0_10_10
 BV BND1      service_0_10_11
 BV BND1      service_0_10_12
 BV BND1      service_0_10_13
 BV BND1      service_0_10_14
 BV BND1      service_0_10_16
 BV BND1      service_0_10_17
 BV BND1      service_0_10_18
 BV BND1      service_0_10_19
 BV BND1      service_1_10_0
 BV BND1      service_1_10_1
 BV BND1      service_1_10_2
 BV BND1      service_1_10_3
 BV BND1      service_1_10_4
 BV BND1      service_1_10_5
 BV BND1      service_1_10_6
 BV BND1      service_1_10_7
 BV BND1      service_1_10_8
 BV BND1      service_1_10_9
 BV BND1      service_1_10_10
 BV BND1      service_1_10_11
 BV BND1      service_1_10_12
 BV BND1      service_1_10_13
 BV BND1      service_1_10_14
 BV BND1      service_1_10_16
 BV BND1      service_1_10_17
 BV BND1      service_1_10_18
 BV BND1      service_1_10_19
 BV BND1      service_2_10_0
 BV BND1      service_2_10_1
 BV BND1      service_2_10_2
 BV BND1      service_2_10_3
 BV BND1      service_2_10_4
 BV BND1      service_2_10_5
 BV BND1      service_2_10_6
 BV BND1      service_2_10_7
 BV BND1      service_2_10_8
 BV BND1      service_2_10_9
 BV BND1      service_2_10_10
 BV BND1      service_2_10_11
 BV BND1      service_2_10_12
 BV BND1      service_2_10_13
 BV BND1      service_2_10_14
 BV BND1      service_2_10_16
 BV BND1      service_2_10_17
 BV BND1      service_2_10_18
 BV BND1      service_2_10_19
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  12
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  12
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  12
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  12
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  12
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  12
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  12
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  12
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  12
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  12
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  12
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  12
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_13_20
 UP BND1      load_0_13_20  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_13
 UP BND1      load_0_20_13  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 FX BND1      visit_1_5  1
 UP BND1      order_1_5  13
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  13
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  13
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  13
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  13
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  13
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  13
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  13
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  13
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  13
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  13
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  13
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  13
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_5
 FX BND1      load_1_0_5  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_5_0
 UP BND1      load_1_5_0  25
 BV BND1      arc_1_5_6
 UP BND1      load_1_5_6  25
 BV BND1      arc_1_5_7
 UP BND1      load_1_5_7  25
 BV BND1      arc_1_5_8
 UP BND1      load_1_5_8  25
 BV BND1      arc_1_5_9
 UP BND1      load_1_5_9  25
 BV BND1      arc_1_5_13
 UP BND1      load_1_5_13  25
 BV BND1      arc_1_5_14
 UP BND1      load_1_5_14  25
 BV BND1      arc_1_5_15
 UP BND1      load_1_5_15  25
 BV BND1      arc_1_5_16
 UP BND1      load_1_5_16  25
 BV BND1      arc_1_5_17
 UP BND1      load_1_5_17  25
 BV BND1      arc_1_5_18
 UP BND1      load_1_5_18  25
 BV BND1      arc_1_5_19
 UP BND1      load_1_5_19  25
 BV BND1      arc_1_5_20
 UP BND1      load_1_5_20  25
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_5
 UP BND1      load_1_6_5  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_5
 UP BND1      load_1_7_5  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_5
 UP BND1      load_1_8_5  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_5
 UP BND1      load_1_9_5  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_5
 UP BND1      load_1_13_5  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_13_20
 UP BND1      load_1_13_20  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_5
 UP BND1      load_1_14_5  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_5
 UP BND1      load_1_15_5  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_5
 UP BND1      load_1_16_5  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_5
 UP BND1      load_1_17_5  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_5
 UP BND1      load_1_18_5  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_5
 UP BND1      load_1_19_5  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_5
 UP BND1      load_1_20_5  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_13
 UP BND1      load_1_20_13  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
ENDATA
