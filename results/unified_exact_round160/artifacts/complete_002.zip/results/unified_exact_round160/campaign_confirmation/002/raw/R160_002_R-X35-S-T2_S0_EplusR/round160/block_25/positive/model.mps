* Signature: 0x88d0724fc277e038
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_16_32
 E  normalized_mass_16_33
 E  normalized_ratio_16_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 E  onehot_12_61
 E  normalized_mass_12_62
 E  normalized_ratio_12_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 E  onehot_34_96
 E  normalized_mass_34_97
 E  normalized_ratio_34_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 E  onehot_14_117
 E  normalized_mass_14_118
 E  normalized_ratio_14_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 E  onehot_29_142
 E  normalized_mass_29_143
 E  normalized_ratio_29_144
 G  product_lb_145
 L  product_ub_146
 G  product_lb_147
 L  product_ub_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 E  onehot_13_163
 E  normalized_mass_13_164
 E  normalized_ratio_13_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 G  product_lb_178
 L  product_ub_179
 E  onehot_27_180
 E  normalized_mass_27_181
 E  normalized_ratio_27_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 E  onehot_15_201
 E  normalized_mass_15_202
 E  normalized_ratio_15_203
 G  stock_lb_204
 L  stock_ub_205
 L  parent_nonstrict_scope_206
 G  block_pair_pos_207
 G  block_pair_neg_208
 G  block_pair_pos_209
 G  block_pair_neg_210
 G  block_pair_pos_211
 G  block_pair_neg_212
 G  block_pair_pos_213
 G  block_pair_neg_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 E  normalization_263
 G  full_original_Gini_264
 E  unique_nonzero_owner_265
 E  unique_nonzero_owner_266
 E  unique_nonzero_owner_267
 E  unique_nonzero_owner_268
 E  unique_nonzero_owner_269
 E  unique_nonzero_owner_270
 E  unique_nonzero_owner_271
 E  unique_nonzero_owner_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 L  arc_capacity_347
 L  arc_capacity_348
 L  arc_capacity_349
 L  arc_capacity_350
 L  arc_capacity_351
 L  arc_capacity_352
 L  arc_capacity_353
 L  arc_capacity_354
 L  arc_capacity_355
 L  arc_capacity_356
 L  arc_capacity_357
 L  arc_capacity_358
 L  arc_capacity_359
 L  arc_capacity_360
 L  arc_capacity_361
 L  arc_capacity_362
 G  connected_order_arc_363
 L  arc_capacity_364
 G  connected_order_arc_365
 L  arc_capacity_366
 G  connected_order_arc_367
 L  arc_capacity_368
 G  connected_order_arc_369
 L  arc_capacity_370
 G  connected_order_arc_371
 L  arc_capacity_372
 G  connected_order_arc_373
 L  arc_capacity_374
 G  connected_order_arc_375
 L  arc_capacity_376
 G  connected_order_arc_377
 L  arc_capacity_378
 G  connected_order_arc_379
 L  arc_capacity_380
 G  connected_order_arc_381
 L  arc_capacity_382
 G  connected_order_arc_383
 L  arc_capacity_384
 G  connected_order_arc_385
 L  arc_capacity_386
 L  arc_capacity_387
 G  connected_order_arc_388
 L  arc_capacity_389
 G  connected_order_arc_390
 L  arc_capacity_391
 G  connected_order_arc_392
 L  arc_capacity_393
 G  connected_order_arc_394
 L  arc_capacity_395
 G  connected_order_arc_396
 L  arc_capacity_397
 G  connected_order_arc_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 G  connected_order_arc_402
 L  arc_capacity_403
 G  connected_order_arc_404
 L  arc_capacity_405
 G  connected_order_arc_406
 L  arc_capacity_407
 G  connected_order_arc_408
 L  arc_capacity_409
 G  connected_order_arc_410
 L  arc_capacity_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 G  connected_order_arc_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 G  connected_order_arc_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 G  connected_order_arc_435
 L  arc_capacity_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 E  depot_departure_or_bypass_686
 E  depot_return_or_bypass_687
 E  out_degree_688
 E  in_degree_689
 G  order_active_lb_690
 L  order_active_ub_691
 E  segment_load_conservation_692
 G  segment_prefix_lb_693
 L  segment_prefix_ub_694
 E  out_degree_695
 E  in_degree_696
 G  order_active_lb_697
 L  order_active_ub_698
 E  segment_load_conservation_699
 G  segment_prefix_lb_700
 L  segment_prefix_ub_701
 E  out_degree_702
 E  in_degree_703
 G  order_active_lb_704
 L  order_active_ub_705
 E  segment_load_conservation_706
 G  segment_prefix_lb_707
 L  segment_prefix_ub_708
 E  out_degree_709
 E  in_degree_710
 G  order_active_lb_711
 L  order_active_ub_712
 E  segment_load_conservation_713
 G  segment_prefix_lb_714
 L  segment_prefix_ub_715
 E  out_degree_716
 E  in_degree_717
 G  order_active_lb_718
 L  order_active_ub_719
 E  segment_load_conservation_720
 G  segment_prefix_lb_721
 L  segment_prefix_ub_722
 E  out_degree_723
 E  in_degree_724
 G  order_active_lb_725
 L  order_active_ub_726
 E  service_visit_def_727
 E  free_load_conservation_728
 E  out_degree_729
 E  in_degree_730
 G  order_active_lb_731
 L  order_active_ub_732
 E  service_visit_def_733
 E  free_load_conservation_734
 E  out_degree_735
 E  in_degree_736
 G  order_active_lb_737
 L  order_active_ub_738
 E  service_visit_def_739
 E  free_load_conservation_740
 E  out_degree_741
 E  in_degree_742
 G  order_active_lb_743
 L  order_active_ub_744
 E  service_visit_def_745
 E  free_load_conservation_746
 E  out_degree_747
 E  in_degree_748
 G  order_active_lb_749
 L  order_active_ub_750
 E  service_visit_def_751
 E  free_load_conservation_752
 E  out_degree_753
 E  in_degree_754
 G  order_active_lb_755
 L  order_active_ub_756
 E  service_visit_def_757
 E  free_load_conservation_758
 E  out_degree_759
 E  in_degree_760
 G  order_active_lb_761
 L  order_active_ub_762
 E  service_visit_def_763
 E  free_load_conservation_764
 E  out_degree_765
 E  in_degree_766
 G  order_active_lb_767
 L  order_active_ub_768
 E  service_visit_def_769
 E  free_load_conservation_770
 G  fixed_segment_relative_order_771
 G  fixed_segment_relative_order_772
 G  fixed_segment_relative_order_773
 G  fixed_segment_relative_order_774
 L  original_T_including_depot_unload_775
 L  arc_capacity_776
 L  arc_capacity_777
 L  arc_capacity_778
 L  arc_capacity_779
 L  arc_capacity_780
 L  arc_capacity_781
 L  arc_capacity_782
 L  arc_capacity_783
 L  arc_capacity_784
 L  arc_capacity_785
 L  arc_capacity_786
 L  arc_capacity_787
 L  arc_capacity_788
 G  connected_order_arc_789
 L  arc_capacity_790
 G  connected_order_arc_791
 L  arc_capacity_792
 G  connected_order_arc_793
 L  arc_capacity_794
 G  connected_order_arc_795
 L  arc_capacity_796
 G  connected_order_arc_797
 L  arc_capacity_798
 G  connected_order_arc_799
 L  arc_capacity_800
 G  connected_order_arc_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 L  arc_capacity_807
 G  connected_order_arc_808
 L  arc_capacity_809
 G  connected_order_arc_810
 L  arc_capacity_811
 G  connected_order_arc_812
 L  arc_capacity_813
 G  connected_order_arc_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 G  connected_order_arc_818
 L  arc_capacity_819
 G  connected_order_arc_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 L  arc_capacity_826
 G  connected_order_arc_827
 L  arc_capacity_828
 G  connected_order_arc_829
 L  arc_capacity_830
 G  connected_order_arc_831
 L  arc_capacity_832
 G  connected_order_arc_833
 L  arc_capacity_834
 G  connected_order_arc_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 G  connected_order_arc_839
 L  arc_capacity_840
 G  connected_order_arc_841
 L  arc_capacity_842
 G  connected_order_arc_843
 L  arc_capacity_844
 L  arc_capacity_845
 G  connected_order_arc_846
 L  arc_capacity_847
 G  connected_order_arc_848
 L  arc_capacity_849
 G  connected_order_arc_850
 L  arc_capacity_851
 G  connected_order_arc_852
 L  arc_capacity_853
 G  connected_order_arc_854
 L  arc_capacity_855
 G  connected_order_arc_856
 L  arc_capacity_857
 G  connected_order_arc_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 L  arc_capacity_864
 G  connected_order_arc_865
 L  arc_capacity_866
 G  connected_order_arc_867
 L  arc_capacity_868
 G  connected_order_arc_869
 L  arc_capacity_870
 G  connected_order_arc_871
 L  arc_capacity_872
 G  connected_order_arc_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 G  connected_order_arc_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 E  depot_departure_or_bypass_977
 E  depot_return_or_bypass_978
 E  out_degree_979
 E  in_degree_980
 G  order_active_lb_981
 L  order_active_ub_982
 E  segment_load_conservation_983
 G  segment_prefix_lb_984
 L  segment_prefix_ub_985
 E  out_degree_986
 E  in_degree_987
 G  order_active_lb_988
 L  order_active_ub_989
 E  segment_load_conservation_990
 G  segment_prefix_lb_991
 L  segment_prefix_ub_992
 E  out_degree_993
 E  in_degree_994
 G  order_active_lb_995
 L  order_active_ub_996
 E  service_visit_def_997
 E  free_load_conservation_998
 E  out_degree_999
 E  in_degree_1000
 G  order_active_lb_1001
 L  order_active_ub_1002
 E  service_visit_def_1003
 E  free_load_conservation_1004
 E  out_degree_1005
 E  in_degree_1006
 G  order_active_lb_1007
 L  order_active_ub_1008
 E  service_visit_def_1009
 E  free_load_conservation_1010
 E  out_degree_1011
 E  in_degree_1012
 G  order_active_lb_1013
 L  order_active_ub_1014
 E  service_visit_def_1015
 E  free_load_conservation_1016
 E  out_degree_1017
 E  in_degree_1018
 G  order_active_lb_1019
 L  order_active_ub_1020
 E  service_visit_def_1021
 E  free_load_conservation_1022
 E  out_degree_1023
 E  in_degree_1024
 G  order_active_lb_1025
 L  order_active_ub_1026
 E  service_visit_def_1027
 E  free_load_conservation_1028
 E  out_degree_1029
 E  in_degree_1030
 G  order_active_lb_1031
 L  order_active_ub_1032
 E  service_visit_def_1033
 E  free_load_conservation_1034
 E  out_degree_1035
 E  in_degree_1036
 G  order_active_lb_1037
 L  order_active_ub_1038
 E  service_visit_def_1039
 E  free_load_conservation_1040
 G  fixed_segment_relative_order_1041
 L  original_T_including_depot_unload_1042
 L  arc_capacity_1043
 L  arc_capacity_1044
 L  arc_capacity_1045
 L  arc_capacity_1046
 L  arc_capacity_1047
 L  arc_capacity_1048
 L  arc_capacity_1049
 L  arc_capacity_1050
 L  arc_capacity_1051
 L  arc_capacity_1052
 L  arc_capacity_1053
 L  arc_capacity_1054
 L  arc_capacity_1055
 L  arc_capacity_1056
 L  arc_capacity_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 L  arc_capacity_1128
 G  connected_order_arc_1129
 L  arc_capacity_1130
 G  connected_order_arc_1131
 L  arc_capacity_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 L  arc_capacity_1139
 G  connected_order_arc_1140
 L  arc_capacity_1141
 G  connected_order_arc_1142
 L  arc_capacity_1143
 G  connected_order_arc_1144
 L  arc_capacity_1145
 G  connected_order_arc_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 L  arc_capacity_1149
 G  connected_order_arc_1150
 L  arc_capacity_1151
 G  connected_order_arc_1152
 L  arc_capacity_1153
 G  connected_order_arc_1154
 L  arc_capacity_1155
 G  connected_order_arc_1156
 L  arc_capacity_1157
 L  arc_capacity_1158
 G  connected_order_arc_1159
 L  arc_capacity_1160
 G  connected_order_arc_1161
 L  arc_capacity_1162
 G  connected_order_arc_1163
 L  arc_capacity_1164
 G  connected_order_arc_1165
 L  arc_capacity_1166
 G  connected_order_arc_1167
 L  arc_capacity_1168
 G  connected_order_arc_1169
 L  arc_capacity_1170
 G  connected_order_arc_1171
 L  arc_capacity_1172
 G  connected_order_arc_1173
 L  arc_capacity_1174
 G  connected_order_arc_1175
 L  arc_capacity_1176
 G  connected_order_arc_1177
 L  arc_capacity_1178
 G  connected_order_arc_1179
 L  arc_capacity_1180
 G  connected_order_arc_1181
 L  arc_capacity_1182
 L  arc_capacity_1183
 G  connected_order_arc_1184
 L  arc_capacity_1185
 G  connected_order_arc_1186
 L  arc_capacity_1187
 G  connected_order_arc_1188
 L  arc_capacity_1189
 G  connected_order_arc_1190
 L  arc_capacity_1191
 G  connected_order_arc_1192
 L  arc_capacity_1193
 G  connected_order_arc_1194
 L  arc_capacity_1195
 G  connected_order_arc_1196
 L  arc_capacity_1197
 G  connected_order_arc_1198
 L  arc_capacity_1199
 G  connected_order_arc_1200
 L  arc_capacity_1201
 G  connected_order_arc_1202
 L  arc_capacity_1203
 G  connected_order_arc_1204
 L  arc_capacity_1205
 G  connected_order_arc_1206
 L  arc_capacity_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 G  connected_order_arc_1213
 L  arc_capacity_1214
 G  connected_order_arc_1215
 L  arc_capacity_1216
 G  connected_order_arc_1217
 L  arc_capacity_1218
 G  connected_order_arc_1219
 L  arc_capacity_1220
 G  connected_order_arc_1221
 L  arc_capacity_1222
 G  connected_order_arc_1223
 L  arc_capacity_1224
 G  connected_order_arc_1225
 L  arc_capacity_1226
 G  connected_order_arc_1227
 L  arc_capacity_1228
 G  connected_order_arc_1229
 L  arc_capacity_1230
 G  connected_order_arc_1231
 L  arc_capacity_1232
 L  arc_capacity_1233
 G  connected_order_arc_1234
 L  arc_capacity_1235
 G  connected_order_arc_1236
 L  arc_capacity_1237
 G  connected_order_arc_1238
 L  arc_capacity_1239
 G  connected_order_arc_1240
 L  arc_capacity_1241
 G  connected_order_arc_1242
 L  arc_capacity_1243
 G  connected_order_arc_1244
 L  arc_capacity_1245
 G  connected_order_arc_1246
 L  arc_capacity_1247
 G  connected_order_arc_1248
 L  arc_capacity_1249
 G  connected_order_arc_1250
 L  arc_capacity_1251
 G  connected_order_arc_1252
 L  arc_capacity_1253
 G  connected_order_arc_1254
 L  arc_capacity_1255
 G  connected_order_arc_1256
 L  arc_capacity_1257
 L  arc_capacity_1258
 G  connected_order_arc_1259
 L  arc_capacity_1260
 G  connected_order_arc_1261
 L  arc_capacity_1262
 G  connected_order_arc_1263
 L  arc_capacity_1264
 G  connected_order_arc_1265
 L  arc_capacity_1266
 G  connected_order_arc_1267
 L  arc_capacity_1268
 G  connected_order_arc_1269
 L  arc_capacity_1270
 G  connected_order_arc_1271
 L  arc_capacity_1272
 G  connected_order_arc_1273
 L  arc_capacity_1274
 G  connected_order_arc_1275
 L  arc_capacity_1276
 G  connected_order_arc_1277
 L  arc_capacity_1278
 G  connected_order_arc_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 L  arc_capacity_1283
 G  connected_order_arc_1284
 L  arc_capacity_1285
 G  connected_order_arc_1286
 L  arc_capacity_1287
 G  connected_order_arc_1288
 L  arc_capacity_1289
 G  connected_order_arc_1290
 L  arc_capacity_1291
 G  connected_order_arc_1292
 L  arc_capacity_1293
 G  connected_order_arc_1294
 L  arc_capacity_1295
 G  connected_order_arc_1296
 L  arc_capacity_1297
 G  connected_order_arc_1298
 L  arc_capacity_1299
 G  connected_order_arc_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 E  depot_departure_or_bypass_1382
 E  depot_return_or_bypass_1383
 E  out_degree_1384
 E  in_degree_1385
 G  order_active_lb_1386
 L  order_active_ub_1387
 E  segment_load_conservation_1388
 G  segment_prefix_lb_1389
 L  segment_prefix_ub_1390
 E  out_degree_1391
 E  in_degree_1392
 G  order_active_lb_1393
 L  order_active_ub_1394
 E  segment_load_conservation_1395
 G  segment_prefix_lb_1396
 L  segment_prefix_ub_1397
 E  out_degree_1398
 E  in_degree_1399
 G  order_active_lb_1400
 L  order_active_ub_1401
 E  segment_load_conservation_1402
 G  segment_prefix_lb_1403
 L  segment_prefix_ub_1404
 E  out_degree_1405
 E  in_degree_1406
 G  order_active_lb_1407
 L  order_active_ub_1408
 E  segment_load_conservation_1409
 G  segment_prefix_lb_1410
 L  segment_prefix_ub_1411
 E  out_degree_1412
 E  in_degree_1413
 G  order_active_lb_1414
 L  order_active_ub_1415
 E  segment_load_conservation_1416
 G  segment_prefix_lb_1417
 L  segment_prefix_ub_1418
 E  out_degree_1419
 E  in_degree_1420
 G  order_active_lb_1421
 L  order_active_ub_1422
 E  service_visit_def_1423
 E  free_load_conservation_1424
 E  out_degree_1425
 E  in_degree_1426
 G  order_active_lb_1427
 L  order_active_ub_1428
 E  service_visit_def_1429
 E  free_load_conservation_1430
 E  out_degree_1431
 E  in_degree_1432
 G  order_active_lb_1433
 L  order_active_ub_1434
 E  service_visit_def_1435
 E  free_load_conservation_1436
 E  out_degree_1437
 E  in_degree_1438
 G  order_active_lb_1439
 L  order_active_ub_1440
 E  service_visit_def_1441
 E  free_load_conservation_1442
 E  out_degree_1443
 E  in_degree_1444
 G  order_active_lb_1445
 L  order_active_ub_1446
 E  service_visit_def_1447
 E  free_load_conservation_1448
 E  out_degree_1449
 E  in_degree_1450
 G  order_active_lb_1451
 L  order_active_ub_1452
 E  service_visit_def_1453
 E  free_load_conservation_1454
 E  out_degree_1455
 E  in_degree_1456
 G  order_active_lb_1457
 L  order_active_ub_1458
 E  service_visit_def_1459
 E  free_load_conservation_1460
 E  out_degree_1461
 E  in_degree_1462
 G  order_active_lb_1463
 L  order_active_ub_1464
 E  service_visit_def_1465
 E  free_load_conservation_1466
 G  fixed_segment_relative_order_1467
 G  fixed_segment_relative_order_1468
 G  fixed_segment_relative_order_1469
 G  fixed_segment_relative_order_1470
 L  original_T_including_depot_unload_1471
COLUMNS
    t         normalized_mass_16_33  -1
    t         normalized_mass_12_62  -1
    t         normalized_mass_34_97  -1
    t         normalized_mass_14_118  -1
    t         normalized_mass_29_143  -1
    t         normalized_mass_13_164  -1
    t         normalized_mass_27_181  -1
    t         normalized_mass_15_202  -1
    t         normalization_263  2.3076190476190476e+01
    t         full_original_Gini_264  -8.8219047619047714e+01
    q         OBJ       1
    q         parent_nonstrict_scope_206  1
    q         full_original_Gini_264  35
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       2.9789603523644435e-02
    x_16_0    product_lb_0  -0.0257558103881511
    x_16_0    product_ub_1  -4.3334709038425519e-02
    x_16_0    onehot_16_32  1
    x_16_0    parent_nonstrict_scope_206  5.9579207047288869e-02
    x_16_0    unique_nonzero_owner_265  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_0  1
    w_16_0    product_ub_1  1
    w_16_0    normalized_mass_16_33  1
    w_16_0    full_original_Gini_264  -2.3076190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       2.2342202642733327e-02
    x_16_1    product_lb_2  -0.0257558103881511
    x_16_1    product_ub_3  -4.3334709038425519e-02
    x_16_1    onehot_16_32  1
    x_16_1    stock_lb_204  1
    x_16_1    stock_ub_205  1
    x_16_1    parent_nonstrict_scope_206  5.2131806166377762e-02
    x_16_1    unique_nonzero_owner_266  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_2  1
    w_16_1    product_ub_3  1
    w_16_1    normalized_mass_16_33  1
    w_16_1    normalized_ratio_16_34  -0.125
    w_16_1    full_original_Gini_264  -1.9951190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       1.4894801761822219e-02
    x_16_2    product_lb_4  -0.0257558103881511
    x_16_2    product_ub_5  -4.3334709038425519e-02
    x_16_2    onehot_16_32  1
    x_16_2    stock_lb_204  2
    x_16_2    stock_ub_205  2
    x_16_2    parent_nonstrict_scope_206  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_4  1
    w_16_2    product_ub_5  1
    w_16_2    normalized_mass_16_33  1
    w_16_2    normalized_ratio_16_34  -0.25
    w_16_2    full_original_Gini_264  -1.6826190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    OBJ       7.4474008809111113e-03
    x_16_3    product_lb_6  -0.0257558103881511
    x_16_3    product_ub_7  -4.3334709038425519e-02
    x_16_3    onehot_16_32  1
    x_16_3    stock_lb_204  3
    x_16_3    stock_ub_205  3
    x_16_3    parent_nonstrict_scope_206  3.7237004404555546e-02
    x_16_3    unique_nonzero_owner_267  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_6  1
    w_16_3    product_ub_7  1
    w_16_3    normalized_mass_16_33  1
    w_16_3    normalized_ratio_16_34  -0.375
    w_16_3    full_original_Gini_264  -1.3784523809523810e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    product_lb_8  -0.0257558103881511
    x_16_4    product_ub_9  -4.3334709038425519e-02
    x_16_4    onehot_16_32  1
    x_16_4    stock_lb_204  4
    x_16_4    stock_ub_205  4
    x_16_4    parent_nonstrict_scope_206  2.9789603523644435e-02
    x_16_4    unique_nonzero_owner_268  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_8  1
    w_16_4    product_ub_9  1
    w_16_4    normalized_mass_16_33  1
    w_16_4    normalized_ratio_16_34  -0.5
    w_16_4    full_original_Gini_264  -1.0909523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -7.4474008809111078e-03
    x_16_5    product_lb_10  -0.0257558103881511
    x_16_5    product_ub_11  -4.3334709038425519e-02
    x_16_5    onehot_16_32  1
    x_16_5    stock_lb_204  5
    x_16_5    stock_ub_205  5
    x_16_5    parent_nonstrict_scope_206  2.2342202642733327e-02
    x_16_5    unique_nonzero_owner_269  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_10  1
    w_16_5    product_ub_11  1
    w_16_5    normalized_mass_16_33  1
    w_16_5    normalized_ratio_16_34  -0.625
    w_16_5    full_original_Gini_264  -8.03452380952381
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -1.4894801761822217e-02
    x_16_6    product_lb_12  -0.0257558103881511
    x_16_6    product_ub_13  -4.3334709038425519e-02
    x_16_6    onehot_16_32  1
    x_16_6    stock_lb_204  6
    x_16_6    stock_ub_205  6
    x_16_6    parent_nonstrict_scope_206  1.4894801761822217e-02
    x_16_6    unique_nonzero_owner_270  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_12  1
    w_16_6    product_ub_13  1
    w_16_6    normalized_mass_16_33  1
    w_16_6    normalized_ratio_16_34  -0.75
    w_16_6    full_original_Gini_264  -5.3976190476190471e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -2.2342202642733327e-02
    x_16_7    product_lb_14  -0.0257558103881511
    x_16_7    product_ub_15  -4.3334709038425519e-02
    x_16_7    onehot_16_32  1
    x_16_7    stock_lb_204  7
    x_16_7    stock_ub_205  7
    x_16_7    parent_nonstrict_scope_206  7.4474008809111087e-03
    x_16_7    unique_nonzero_owner_271  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_14  1
    w_16_7    product_ub_15  1
    w_16_7    normalized_mass_16_33  1
    w_16_7    normalized_ratio_16_34  -0.875
    w_16_7    full_original_Gini_264  -4.5488095238095241e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -2.9789603523644435e-02
    x_16_8    product_lb_16  -0.0257558103881511
    x_16_8    product_ub_17  -4.3334709038425519e-02
    x_16_8    onehot_16_32  1
    x_16_8    stock_lb_204  8
    x_16_8    stock_ub_205  8
    x_16_8    unique_nonzero_owner_272  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_16  1
    w_16_8    product_ub_17  1
    w_16_8    normalized_mass_16_33  1
    w_16_8    normalized_ratio_16_34  -1
    w_16_8    full_original_Gini_264  -4.9238095238095241e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_9    OBJ       -2.2342202642733327e-02
    x_16_9    product_lb_18  -0.0257558103881511
    x_16_9    product_ub_19  -4.3334709038425519e-02
    x_16_9    onehot_16_32  1
    x_16_9    stock_lb_204  9
    x_16_9    stock_ub_205  9
    x_16_9    parent_nonstrict_scope_206  7.4474008809111087e-03
    x_16_9    unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_18  1
    w_16_9    product_ub_19  1
    w_16_9    normalized_mass_16_33  1
    w_16_9    normalized_ratio_16_34  -1.125
    w_16_9    full_original_Gini_264  -8.0488095238095241e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       -1.4894801761822217e-02
    x_16_10   product_lb_20  -0.0257558103881511
    x_16_10   product_ub_21  -4.3334709038425519e-02
    x_16_10   onehot_16_32  1
    x_16_10   stock_lb_204  10
    x_16_10   stock_ub_205  10
    x_16_10   parent_nonstrict_scope_206  1.4894801761822217e-02
    x_16_10   unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_20  1
    w_16_10   product_ub_21  1
    w_16_10   normalized_mass_16_33  1
    w_16_10   normalized_ratio_16_34  -1.25
    w_16_10   full_original_Gini_264  -1.1173809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       -7.4474008809111078e-03
    x_16_11   product_lb_22  -0.0257558103881511
    x_16_11   product_ub_23  -4.3334709038425519e-02
    x_16_11   onehot_16_32  1
    x_16_11   stock_lb_204  11
    x_16_11   stock_ub_205  11
    x_16_11   parent_nonstrict_scope_206  2.2342202642733327e-02
    x_16_11   unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_22  1
    w_16_11   product_ub_23  1
    w_16_11   normalized_mass_16_33  1
    w_16_11   normalized_ratio_16_34  -1.375
    w_16_11   full_original_Gini_264  -1.4298809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   product_lb_24  -0.0257558103881511
    x_16_12   product_ub_25  -4.3334709038425519e-02
    x_16_12   onehot_16_32  1
    x_16_12   stock_lb_204  12
    x_16_12   stock_ub_205  12
    x_16_12   parent_nonstrict_scope_206  2.9789603523644435e-02
    x_16_12   unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_24  1
    w_16_12   product_ub_25  1
    w_16_12   normalized_mass_16_33  1
    w_16_12   normalized_ratio_16_34  -1.5
    w_16_12   full_original_Gini_264  -1.7423809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_13   OBJ       7.4474008809111113e-03
    x_16_13   product_lb_26  -0.0257558103881511
    x_16_13   product_ub_27  -4.3334709038425519e-02
    x_16_13   onehot_16_32  1
    x_16_13   stock_lb_204  13
    x_16_13   stock_ub_205  13
    x_16_13   parent_nonstrict_scope_206  3.7237004404555546e-02
    x_16_13   unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_13   product_lb_26  1
    w_16_13   product_ub_27  1
    w_16_13   normalized_mass_16_33  1
    w_16_13   normalized_ratio_16_34  -1.625
    w_16_13   full_original_Gini_264  -2.0798809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_14   OBJ       1.4894801761822219e-02
    x_16_14   product_lb_28  -0.0257558103881511
    x_16_14   product_ub_29  -4.3334709038425519e-02
    x_16_14   onehot_16_32  1
    x_16_14   stock_lb_204  14
    x_16_14   stock_ub_205  14
    x_16_14   parent_nonstrict_scope_206  4.4684405285466654e-02
    x_16_14   unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_14   product_lb_28  1
    w_16_14   product_ub_29  1
    w_16_14   normalized_mass_16_33  1
    w_16_14   normalized_ratio_16_34  -1.75
    w_16_14   full_original_Gini_264  -2.4173809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_15   OBJ       2.2342202642733327e-02
    x_16_15   product_lb_30  -0.0257558103881511
    x_16_15   product_ub_31  -4.3334709038425519e-02
    x_16_15   onehot_16_32  1
    x_16_15   stock_lb_204  15
    x_16_15   stock_ub_205  15
    x_16_15   parent_nonstrict_scope_206  5.2131806166377762e-02
    x_16_15   unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_15   product_lb_30  1
    w_16_15   product_ub_31  1
    w_16_15   normalized_mass_16_33  1
    w_16_15   normalized_ratio_16_34  -1.875
    w_16_15   full_original_Gini_264  -2.7548809523809521e+01
    rho_16    normalized_ratio_16_34  1
    rho_16    block_pair_pos_231  -1
    rho_16    block_pair_neg_232  1
    rho_16    block_pair_pos_233  -1
    rho_16    block_pair_neg_234  1
    rho_16    block_pair_pos_235  -1
    rho_16    block_pair_neg_236  1
    rho_16    block_pair_pos_237  -1
    rho_16    block_pair_neg_238  1
    rho_16    block_pair_pos_239  -1
    rho_16    block_pair_neg_240  1
    rho_16    block_pair_pos_241  -1
    rho_16    block_pair_neg_242  1
    rho_16    block_pair_pos_243  -1
    rho_16    block_pair_neg_244  1
    rho_16    normalization_263  1
    MARKER    'MARKER'                 'INTORG'
    x_12_0    OBJ       1.6756644912833352e-02
    x_12_0    product_lb_35  -0.0257558103881511
    x_12_0    product_ub_36  -4.3334709038425519e-02
    x_12_0    onehot_12_61  1
    x_12_0    parent_nonstrict_scope_206  0.0335132898256667
    x_12_0    unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_0    product_lb_35  1
    w_12_0    product_ub_36  1
    w_12_0    normalized_mass_12_62  1
    w_12_0    full_original_Gini_264  -2.3076190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_1    OBJ       1.1171096608555569e-02
    x_12_1    product_lb_37  -0.0257558103881511
    x_12_1    product_ub_38  -4.3334709038425519e-02
    x_12_1    onehot_12_61  1
    x_12_1    stock_lb_204  1
    x_12_1    stock_ub_205  1
    x_12_1    parent_nonstrict_scope_206  2.7927741521388921e-02
    MARKER    'MARKER'                 'INTEND'
    w_12_1    product_lb_37  1
    w_12_1    product_ub_38  1
    w_12_1    normalized_mass_12_62  1
    w_12_1    normalized_ratio_12_63  -1.6666666666666666e-01
    w_12_1    full_original_Gini_264  -1.8909523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_2    OBJ       5.5855483042777862e-03
    x_12_2    product_lb_39  -0.0257558103881511
    x_12_2    product_ub_40  -4.3334709038425519e-02
    x_12_2    onehot_12_61  1
    x_12_2    stock_lb_204  2
    x_12_2    stock_ub_205  2
    x_12_2    parent_nonstrict_scope_206  2.2342193217111138e-02
    x_12_2    unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_2    product_lb_39  1
    w_12_2    product_ub_40  1
    w_12_2    normalized_mass_12_62  1
    w_12_2    normalized_ratio_12_63  -3.3333333333333331e-01
    w_12_2    full_original_Gini_264  -1.4742857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_3    product_lb_41  -0.0257558103881511
    x_12_3    product_ub_42  -4.3334709038425519e-02
    x_12_3    onehot_12_61  1
    x_12_3    stock_lb_204  3
    x_12_3    stock_ub_205  3
    x_12_3    parent_nonstrict_scope_206  1.6756644912833352e-02
    x_12_3    unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_3    product_lb_41  1
    w_12_3    product_ub_42  1
    w_12_3    normalized_mass_12_62  1
    w_12_3    normalized_ratio_12_63  -0.5
    w_12_3    full_original_Gini_264  -1.0909523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_4    OBJ       -5.5855483042777827e-03
    x_12_4    product_lb_43  -0.0257558103881511
    x_12_4    product_ub_44  -4.3334709038425519e-02
    x_12_4    onehot_12_61  1
    x_12_4    stock_lb_204  4
    x_12_4    stock_ub_205  4
    x_12_4    parent_nonstrict_scope_206  1.1171096608555569e-02
    x_12_4    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_4    product_lb_43  1
    w_12_4    product_ub_44  1
    w_12_4    normalized_mass_12_62  1
    w_12_4    normalized_ratio_12_63  -6.6666666666666663e-01
    w_12_4    full_original_Gini_264  -7.0761904761904750e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_5    OBJ       -1.1171096608555565e-02
    x_12_5    product_lb_45  -0.0257558103881511
    x_12_5    product_ub_46  -4.3334709038425519e-02
    x_12_5    onehot_12_61  1
    x_12_5    stock_lb_204  5
    x_12_5    stock_ub_205  5
    x_12_5    parent_nonstrict_scope_206  5.5855483042777862e-03
    x_12_5    unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_5    product_lb_45  1
    w_12_5    product_ub_46  1
    w_12_5    normalized_mass_12_62  1
    w_12_5    normalized_ratio_12_63  -8.3333333333333326e-01
    w_12_5    full_original_Gini_264  -4.6142857142857148e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_6    OBJ       -1.6756644912833352e-02
    x_12_6    product_lb_47  -0.0257558103881511
    x_12_6    product_ub_48  -4.3334709038425519e-02
    x_12_6    onehot_12_61  1
    x_12_6    stock_lb_204  6
    x_12_6    stock_ub_205  6
    x_12_6    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_6    product_lb_47  1
    w_12_6    product_ub_48  1
    w_12_6    normalized_mass_12_62  1
    w_12_6    normalized_ratio_12_63  -1
    w_12_6    full_original_Gini_264  -4.9238095238095241e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_7    OBJ       -1.1171096608555572e-02
    x_12_7    product_lb_49  -0.0257558103881511
    x_12_7    product_ub_50  -4.3334709038425519e-02
    x_12_7    onehot_12_61  1
    x_12_7    stock_lb_204  7
    x_12_7    stock_ub_205  7
    x_12_7    parent_nonstrict_scope_206  5.5855483042777793e-03
    x_12_7    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_7    product_lb_49  1
    w_12_7    product_ub_50  1
    w_12_7    normalized_mass_12_62  1
    w_12_7    normalized_ratio_12_63  -1.1666666666666665e+00
    w_12_7    full_original_Gini_264  -9.0904761904761848e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_8    OBJ       -5.5855483042777862e-03
    x_12_8    product_lb_51  -0.0257558103881511
    x_12_8    product_ub_52  -4.3334709038425519e-02
    x_12_8    onehot_12_61  1
    x_12_8    stock_lb_204  8
    x_12_8    stock_ub_205  8
    x_12_8    parent_nonstrict_scope_206  1.1171096608555565e-02
    x_12_8    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_8    product_lb_51  1
    w_12_8    product_ub_52  1
    w_12_8    normalized_mass_12_62  1
    w_12_8    normalized_ratio_12_63  -1.3333333333333333e+00
    w_12_8    full_original_Gini_264  -1.3257142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_9    product_lb_53  -0.0257558103881511
    x_12_9    product_ub_54  -4.3334709038425519e-02
    x_12_9    onehot_12_61  1
    x_12_9    stock_lb_204  9
    x_12_9    stock_ub_205  9
    x_12_9    parent_nonstrict_scope_206  1.6756644912833352e-02
    x_12_9    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_9    product_lb_53  1
    w_12_9    product_ub_54  1
    w_12_9    normalized_mass_12_62  1
    w_12_9    normalized_ratio_12_63  -1.5
    w_12_9    full_original_Gini_264  -1.7423809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_10   OBJ       5.5855483042777793e-03
    x_12_10   product_lb_55  -0.0257558103881511
    x_12_10   product_ub_56  -4.3334709038425519e-02
    x_12_10   onehot_12_61  1
    x_12_10   stock_lb_204  10
    x_12_10   stock_ub_205  10
    x_12_10   parent_nonstrict_scope_206  2.2342193217111131e-02
    x_12_10   unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_10   product_lb_55  1
    w_12_10   product_ub_56  1
    w_12_10   normalized_mass_12_62  1
    w_12_10   normalized_ratio_12_63  -1.6666666666666665e+00
    w_12_10   full_original_Gini_264  -2.1923809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_11   OBJ       1.1171096608555565e-02
    x_12_11   product_lb_57  -0.0257558103881511
    x_12_11   product_ub_58  -4.3334709038425519e-02
    x_12_11   onehot_12_61  1
    x_12_11   stock_lb_204  11
    x_12_11   stock_ub_205  11
    x_12_11   parent_nonstrict_scope_206  2.7927741521388917e-02
    x_12_11   unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_11   product_lb_57  1
    w_12_11   product_ub_58  1
    w_12_11   normalized_mass_12_62  1
    w_12_11   normalized_ratio_12_63  -1.8333333333333333e+00
    w_12_11   full_original_Gini_264  -2.6423809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_12   OBJ       1.6756644912833352e-02
    x_12_12   product_lb_59  -0.0257558103881511
    x_12_12   product_ub_60  -4.3334709038425519e-02
    x_12_12   onehot_12_61  1
    x_12_12   stock_lb_204  12
    x_12_12   stock_ub_205  12
    x_12_12   parent_nonstrict_scope_206  0.0335132898256667
    x_12_12   unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_12   product_lb_59  1
    w_12_12   product_ub_60  1
    w_12_12   normalized_mass_12_62  1
    w_12_12   normalized_ratio_12_63  -2
    w_12_12   full_original_Gini_264  -3.0923809523809521e+01
    rho_12    normalized_ratio_12_63  1
    rho_12    block_pair_pos_207  -1
    rho_12    block_pair_neg_208  1
    rho_12    block_pair_pos_209  -1
    rho_12    block_pair_neg_210  1
    rho_12    block_pair_pos_211  -1
    rho_12    block_pair_neg_212  1
    rho_12    block_pair_pos_213  -1
    rho_12    block_pair_neg_214  1
    rho_12    block_pair_pos_215  -1
    rho_12    block_pair_neg_216  1
    rho_12    block_pair_pos_217  -1
    rho_12    block_pair_neg_218  1
    rho_12    block_pair_pos_231  1
    rho_12    block_pair_neg_232  -1
    rho_12    normalization_263  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_64  -0.0257558103881511
    x_34_0    product_ub_65  -4.3334709038425519e-02
    x_34_0    onehot_34_96  1
    x_34_0    parent_nonstrict_scope_206  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_64  1
    w_34_0    product_ub_65  1
    w_34_0    normalized_mass_34_97  1
    w_34_0    full_original_Gini_264  -2.3076190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_66  -0.0257558103881511
    x_34_1    product_ub_67  -4.3334709038425519e-02
    x_34_1    onehot_34_96  1
    x_34_1    stock_lb_204  1
    x_34_1    stock_ub_205  1
    x_34_1    parent_nonstrict_scope_206  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_66  1
    w_34_1    product_ub_67  1
    w_34_1    normalized_mass_34_97  1
    w_34_1    normalized_ratio_34_98  -0.125
    w_34_1    full_original_Gini_264  -1.9951190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_68  -0.0257558103881511
    x_34_2    product_ub_69  -4.3334709038425519e-02
    x_34_2    onehot_34_96  1
    x_34_2    stock_lb_204  2
    x_34_2    stock_ub_205  2
    x_34_2    parent_nonstrict_scope_206  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_68  1
    w_34_2    product_ub_69  1
    w_34_2    normalized_mass_34_97  1
    w_34_2    normalized_ratio_34_98  -0.25
    w_34_2    full_original_Gini_264  -1.6826190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_70  -0.0257558103881511
    x_34_3    product_ub_71  -4.3334709038425519e-02
    x_34_3    onehot_34_96  1
    x_34_3    stock_lb_204  3
    x_34_3    stock_ub_205  3
    x_34_3    parent_nonstrict_scope_206  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_70  1
    w_34_3    product_ub_71  1
    w_34_3    normalized_mass_34_97  1
    w_34_3    normalized_ratio_34_98  -0.375
    w_34_3    full_original_Gini_264  -1.3784523809523810e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_72  -0.0257558103881511
    x_34_4    product_ub_73  -4.3334709038425519e-02
    x_34_4    onehot_34_96  1
    x_34_4    stock_lb_204  4
    x_34_4    stock_ub_205  4
    x_34_4    parent_nonstrict_scope_206  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_72  1
    w_34_4    product_ub_73  1
    w_34_4    normalized_mass_34_97  1
    w_34_4    normalized_ratio_34_98  -0.5
    w_34_4    full_original_Gini_264  -1.0909523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_74  -0.0257558103881511
    x_34_5    product_ub_75  -4.3334709038425519e-02
    x_34_5    onehot_34_96  1
    x_34_5    stock_lb_204  5
    x_34_5    stock_ub_205  5
    x_34_5    parent_nonstrict_scope_206  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_74  1
    w_34_5    product_ub_75  1
    w_34_5    normalized_mass_34_97  1
    w_34_5    normalized_ratio_34_98  -0.625
    w_34_5    full_original_Gini_264  -8.03452380952381
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_76  -0.0257558103881511
    x_34_6    product_ub_77  -4.3334709038425519e-02
    x_34_6    onehot_34_96  1
    x_34_6    stock_lb_204  6
    x_34_6    stock_ub_205  6
    x_34_6    parent_nonstrict_scope_206  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_76  1
    w_34_6    product_ub_77  1
    w_34_6    normalized_mass_34_97  1
    w_34_6    normalized_ratio_34_98  -0.75
    w_34_6    full_original_Gini_264  -5.3976190476190471e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_78  -0.0257558103881511
    x_34_7    product_ub_79  -4.3334709038425519e-02
    x_34_7    onehot_34_96  1
    x_34_7    stock_lb_204  7
    x_34_7    stock_ub_205  7
    x_34_7    parent_nonstrict_scope_206  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_78  1
    w_34_7    product_ub_79  1
    w_34_7    normalized_mass_34_97  1
    w_34_7    normalized_ratio_34_98  -0.875
    w_34_7    full_original_Gini_264  -4.5488095238095241e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_80  -0.0257558103881511
    x_34_8    product_ub_81  -4.3334709038425519e-02
    x_34_8    onehot_34_96  1
    x_34_8    stock_lb_204  8
    x_34_8    stock_ub_205  8
    x_34_8    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_80  1
    w_34_8    product_ub_81  1
    w_34_8    normalized_mass_34_97  1
    w_34_8    normalized_ratio_34_98  -1
    w_34_8    full_original_Gini_264  -4.9238095238095241e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_82  -0.0257558103881511
    x_34_9    product_ub_83  -4.3334709038425519e-02
    x_34_9    onehot_34_96  1
    x_34_9    stock_lb_204  9
    x_34_9    stock_ub_205  9
    x_34_9    parent_nonstrict_scope_206  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_82  1
    w_34_9    product_ub_83  1
    w_34_9    normalized_mass_34_97  1
    w_34_9    normalized_ratio_34_98  -1.125
    w_34_9    full_original_Gini_264  -8.0488095238095241e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_84  -0.0257558103881511
    x_34_10   product_ub_85  -4.3334709038425519e-02
    x_34_10   onehot_34_96  1
    x_34_10   stock_lb_204  10
    x_34_10   stock_ub_205  10
    x_34_10   parent_nonstrict_scope_206  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_84  1
    w_34_10   product_ub_85  1
    w_34_10   normalized_mass_34_97  1
    w_34_10   normalized_ratio_34_98  -1.25
    w_34_10   full_original_Gini_264  -1.1173809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_86  -0.0257558103881511
    x_34_11   product_ub_87  -4.3334709038425519e-02
    x_34_11   onehot_34_96  1
    x_34_11   stock_lb_204  11
    x_34_11   stock_ub_205  11
    x_34_11   parent_nonstrict_scope_206  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_86  1
    w_34_11   product_ub_87  1
    w_34_11   normalized_mass_34_97  1
    w_34_11   normalized_ratio_34_98  -1.375
    w_34_11   full_original_Gini_264  -1.4298809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_88  -0.0257558103881511
    x_34_12   product_ub_89  -4.3334709038425519e-02
    x_34_12   onehot_34_96  1
    x_34_12   stock_lb_204  12
    x_34_12   stock_ub_205  12
    x_34_12   parent_nonstrict_scope_206  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_88  1
    w_34_12   product_ub_89  1
    w_34_12   normalized_mass_34_97  1
    w_34_12   normalized_ratio_34_98  -1.5
    w_34_12   full_original_Gini_264  -1.7423809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_90  -0.0257558103881511
    x_34_13   product_ub_91  -4.3334709038425519e-02
    x_34_13   onehot_34_96  1
    x_34_13   stock_lb_204  13
    x_34_13   stock_ub_205  13
    x_34_13   parent_nonstrict_scope_206  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_90  1
    w_34_13   product_ub_91  1
    w_34_13   normalized_mass_34_97  1
    w_34_13   normalized_ratio_34_98  -1.625
    w_34_13   full_original_Gini_264  -2.0798809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_92  -0.0257558103881511
    x_34_14   product_ub_93  -4.3334709038425519e-02
    x_34_14   onehot_34_96  1
    x_34_14   stock_lb_204  14
    x_34_14   stock_ub_205  14
    x_34_14   parent_nonstrict_scope_206  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_92  1
    w_34_14   product_ub_93  1
    w_34_14   normalized_mass_34_97  1
    w_34_14   normalized_ratio_34_98  -1.75
    w_34_14   full_original_Gini_264  -2.4173809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_94  -0.0257558103881511
    x_34_15   product_ub_95  -4.3334709038425519e-02
    x_34_15   onehot_34_96  1
    x_34_15   stock_lb_204  15
    x_34_15   stock_ub_205  15
    x_34_15   parent_nonstrict_scope_206  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_94  1
    w_34_15   product_ub_95  1
    w_34_15   normalized_mass_34_97  1
    w_34_15   normalized_ratio_34_98  -1.875
    w_34_15   full_original_Gini_264  -2.7548809523809521e+01
    rho_34    normalized_ratio_34_98  1
    rho_34    block_pair_pos_217  1
    rho_34    block_pair_neg_218  -1
    rho_34    block_pair_pos_243  1
    rho_34    block_pair_neg_244  -1
    rho_34    block_pair_pos_253  -1
    rho_34    block_pair_neg_254  1
    rho_34    block_pair_pos_255  -1
    rho_34    block_pair_neg_256  1
    rho_34    block_pair_pos_257  -1
    rho_34    block_pair_neg_258  1
    rho_34    block_pair_pos_259  -1
    rho_34    block_pair_neg_260  1
    rho_34    block_pair_pos_261  -1
    rho_34    block_pair_neg_262  1
    rho_34    normalization_263  1
    MARKER    'MARKER'                 'INTORG'
    x_14_0    OBJ       7.4474103065332977e-03
    x_14_0    product_lb_99  -0.0257558103881511
    x_14_0    product_ub_100  -4.3334709038425519e-02
    x_14_0    onehot_14_117  1
    x_14_0    parent_nonstrict_scope_206  1.4894820613066595e-02
    x_14_0    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_0    product_lb_99  1
    w_14_0    product_ub_100  1
    w_14_0    normalized_mass_14_118  1
    w_14_0    full_original_Gini_264  -2.3076190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_1    OBJ       3.7237051532666493e-03
    x_14_1    product_lb_101  -0.0257558103881511
    x_14_1    product_ub_102  -4.3334709038425519e-02
    x_14_1    onehot_14_117  1
    x_14_1    stock_lb_204  1
    x_14_1    stock_ub_205  1
    x_14_1    parent_nonstrict_scope_206  1.1171115459799947e-02
    x_14_1    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_1    product_lb_101  1
    w_14_1    product_ub_102  1
    w_14_1    normalized_mass_14_118  1
    w_14_1    normalized_ratio_14_119  -0.25
    w_14_1    full_original_Gini_264  -1.6826190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_2    product_lb_103  -0.0257558103881511
    x_14_2    product_ub_104  -4.3334709038425519e-02
    x_14_2    onehot_14_117  1
    x_14_2    stock_lb_204  2
    x_14_2    stock_ub_205  2
    x_14_2    parent_nonstrict_scope_206  7.4474103065332977e-03
    MARKER    'MARKER'                 'INTEND'
    w_14_2    product_lb_103  1
    w_14_2    product_ub_104  1
    w_14_2    normalized_mass_14_118  1
    w_14_2    normalized_ratio_14_119  -0.5
    w_14_2    full_original_Gini_264  -1.0909523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_3    OBJ       -3.7237051532666488e-03
    x_14_3    product_lb_105  -0.0257558103881511
    x_14_3    product_ub_106  -4.3334709038425519e-02
    x_14_3    onehot_14_117  1
    x_14_3    stock_lb_204  3
    x_14_3    stock_ub_205  3
    x_14_3    parent_nonstrict_scope_206  3.7237051532666488e-03
    x_14_3    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_3    product_lb_105  1
    w_14_3    product_ub_106  1
    w_14_3    normalized_mass_14_118  1
    w_14_3    normalized_ratio_14_119  -0.75
    w_14_3    full_original_Gini_264  -5.3976190476190471e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_4    OBJ       -7.4474103065332977e-03
    x_14_4    product_lb_107  -0.0257558103881511
    x_14_4    product_ub_108  -4.3334709038425519e-02
    x_14_4    onehot_14_117  1
    x_14_4    stock_lb_204  4
    x_14_4    stock_ub_205  4
    x_14_4    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_4    product_lb_107  1
    w_14_4    product_ub_108  1
    w_14_4    normalized_mass_14_118  1
    w_14_4    normalized_ratio_14_119  -1
    w_14_4    full_original_Gini_264  -4.9238095238095241e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_5    OBJ       -3.7237051532666488e-03
    x_14_5    product_lb_109  -0.0257558103881511
    x_14_5    product_ub_110  -4.3334709038425519e-02
    x_14_5    onehot_14_117  1
    x_14_5    stock_lb_204  5
    x_14_5    stock_ub_205  5
    x_14_5    parent_nonstrict_scope_206  3.7237051532666488e-03
    x_14_5    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_5    product_lb_109  1
    w_14_5    product_ub_110  1
    w_14_5    normalized_mass_14_118  1
    w_14_5    normalized_ratio_14_119  -1.25
    w_14_5    full_original_Gini_264  -1.1173809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_6    product_lb_111  -0.0257558103881511
    x_14_6    product_ub_112  -4.3334709038425519e-02
    x_14_6    onehot_14_117  1
    x_14_6    stock_lb_204  6
    x_14_6    stock_ub_205  6
    x_14_6    parent_nonstrict_scope_206  7.4474103065332977e-03
    x_14_6    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_6    product_lb_111  1
    w_14_6    product_ub_112  1
    w_14_6    normalized_mass_14_118  1
    w_14_6    normalized_ratio_14_119  -1.5
    w_14_6    full_original_Gini_264  -1.7423809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_7    OBJ       3.7237051532666493e-03
    x_14_7    product_lb_113  -0.0257558103881511
    x_14_7    product_ub_114  -4.3334709038425519e-02
    x_14_7    onehot_14_117  1
    x_14_7    stock_lb_204  7
    x_14_7    stock_ub_205  7
    x_14_7    parent_nonstrict_scope_206  1.1171115459799947e-02
    x_14_7    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_7    product_lb_113  1
    w_14_7    product_ub_114  1
    w_14_7    normalized_mass_14_118  1
    w_14_7    normalized_ratio_14_119  -1.75
    w_14_7    full_original_Gini_264  -2.4173809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_8    OBJ       7.4474103065332977e-03
    x_14_8    product_lb_115  -0.0257558103881511
    x_14_8    product_ub_116  -4.3334709038425519e-02
    x_14_8    onehot_14_117  1
    x_14_8    stock_lb_204  8
    x_14_8    stock_ub_205  8
    x_14_8    parent_nonstrict_scope_206  1.4894820613066595e-02
    x_14_8    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_8    product_lb_115  1
    w_14_8    product_ub_116  1
    w_14_8    normalized_mass_14_118  1
    w_14_8    normalized_ratio_14_119  -2
    w_14_8    full_original_Gini_264  -3.0923809523809521e+01
    rho_14    normalized_ratio_14_119  1
    rho_14    block_pair_pos_209  1
    rho_14    block_pair_neg_210  -1
    rho_14    block_pair_pos_223  -1
    rho_14    block_pair_neg_224  1
    rho_14    block_pair_pos_225  -1
    rho_14    block_pair_neg_226  1
    rho_14    block_pair_pos_227  -1
    rho_14    block_pair_neg_228  1
    rho_14    block_pair_pos_229  -1
    rho_14    block_pair_neg_230  1
    rho_14    block_pair_pos_235  1
    rho_14    block_pair_neg_236  -1
    rho_14    block_pair_pos_255  1
    rho_14    block_pair_neg_256  -1
    rho_14    normalization_263  1
    MARKER    'MARKER'                 'INTORG'
    x_29_0    OBJ       1.1636571534741636e-02
    x_29_0    product_lb_120  -0.0257558103881511
    x_29_0    product_ub_121  -4.3334709038425519e-02
    x_29_0    onehot_29_142  1
    x_29_0    parent_nonstrict_scope_206  2.3273143069483273e-02
    x_29_0    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_0    product_lb_120  1
    w_29_0    product_ub_121  1
    w_29_0    normalized_mass_29_143  1
    w_29_0    full_original_Gini_264  -2.3076190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_1    OBJ       6.9819429208449833e-03
    x_29_1    product_lb_122  -0.0257558103881511
    x_29_1    product_ub_123  -4.3334709038425519e-02
    x_29_1    onehot_29_142  1
    x_29_1    stock_lb_204  1
    x_29_1    stock_ub_205  1
    x_29_1    parent_nonstrict_scope_206  1.8618514455586620e-02
    MARKER    'MARKER'                 'INTEND'
    w_29_1    product_lb_122  1
    w_29_1    product_ub_123  1
    w_29_1    normalized_mass_29_143  1
    w_29_1    normalized_ratio_29_144  -0.2
    w_29_1    full_original_Gini_264  -1.8076190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_2    OBJ       2.3273143069483266e-03
    x_29_2    product_lb_124  -0.0257558103881511
    x_29_2    product_ub_125  -4.3334709038425519e-02
    x_29_2    onehot_29_142  1
    x_29_2    stock_lb_204  2
    x_29_2    stock_ub_205  2
    x_29_2    parent_nonstrict_scope_206  1.3963885841689963e-02
    x_29_2    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_2    product_lb_124  1
    w_29_2    product_ub_125  1
    w_29_2    normalized_mass_29_143  1
    w_29_2    normalized_ratio_29_144  -0.4
    w_29_2    full_original_Gini_264  -1.3209523809523805e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_3    OBJ       -0.00232731430694833
    x_29_3    product_lb_126  -0.0257558103881511
    x_29_3    product_ub_127  -4.3334709038425519e-02
    x_29_3    onehot_29_142  1
    x_29_3    stock_lb_204  3
    x_29_3    stock_ub_205  3
    x_29_3    parent_nonstrict_scope_206  9.3092572277933064e-03
    x_29_3    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_3    product_lb_126  1
    w_29_3    product_ub_127  1
    w_29_3    normalized_mass_29_143  1
    w_29_3    normalized_ratio_29_144  -6.0000000000000009e-01
    w_29_3    full_original_Gini_264  -8.60952380952381
    MARKER    'MARKER'                 'INTORG'
    x_29_4    OBJ       -6.9819429208449833e-03
    x_29_4    product_lb_128  -0.0257558103881511
    x_29_4    product_ub_129  -4.3334709038425519e-02
    x_29_4    onehot_29_142  1
    x_29_4    stock_lb_204  4
    x_29_4    stock_ub_205  4
    x_29_4    parent_nonstrict_scope_206  4.6546286138966532e-03
    x_29_4    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_4    product_lb_128  1
    w_29_4    product_ub_129  1
    w_29_4    normalized_mass_29_143  1
    w_29_4    normalized_ratio_29_144  -0.8
    w_29_4    full_original_Gini_264  -4.8476190476190473e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_5    OBJ       -1.1636571534741636e-02
    x_29_5    product_lb_130  -0.0257558103881511
    x_29_5    product_ub_131  -4.3334709038425519e-02
    x_29_5    onehot_29_142  1
    x_29_5    stock_lb_204  5
    x_29_5    stock_ub_205  5
    x_29_5    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_5    product_lb_130  1
    w_29_5    product_ub_131  1
    w_29_5    normalized_mass_29_143  1
    w_29_5    normalized_ratio_29_144  -1
    w_29_5    full_original_Gini_264  -4.9238095238095241e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_6    OBJ       -6.9819429208449781e-03
    x_29_6    product_lb_132  -0.0257558103881511
    x_29_6    product_ub_133  -4.3334709038425519e-02
    x_29_6    onehot_29_142  1
    x_29_6    stock_lb_204  6
    x_29_6    stock_ub_205  6
    x_29_6    parent_nonstrict_scope_206  4.6546286138966584e-03
    x_29_6    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_6    product_lb_132  1
    w_29_6    product_ub_133  1
    w_29_6    normalized_mass_29_143  1
    w_29_6    normalized_ratio_29_144  -1.2000000000000002e+00
    w_29_6    full_original_Gini_264  -9.9238095238095276e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_7    OBJ       -2.3273143069483249e-03
    x_29_7    product_lb_134  -0.0257558103881511
    x_29_7    product_ub_135  -4.3334709038425519e-02
    x_29_7    onehot_29_142  1
    x_29_7    stock_lb_204  7
    x_29_7    stock_ub_205  7
    x_29_7    parent_nonstrict_scope_206  9.3092572277933116e-03
    x_29_7    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_7    product_lb_134  1
    w_29_7    product_ub_135  1
    w_29_7    normalized_mass_29_143  1
    w_29_7    normalized_ratio_29_144  -1.4000000000000001e+00
    w_29_7    full_original_Gini_264  -1.4923809523809529e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_8    OBJ       0.00232731430694833
    x_29_8    product_lb_136  -0.0257558103881511
    x_29_8    product_ub_137  -4.3334709038425519e-02
    x_29_8    onehot_29_142  1
    x_29_8    stock_lb_204  8
    x_29_8    stock_ub_205  8
    x_29_8    parent_nonstrict_scope_206  1.3963885841689967e-02
    x_29_8    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_8    product_lb_136  1
    w_29_8    product_ub_137  1
    w_29_8    normalized_mass_29_143  1
    w_29_8    normalized_ratio_29_144  -1.6
    w_29_8    full_original_Gini_264  -2.0123809523809527e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_9    OBJ       6.9819429208449833e-03
    x_29_9    product_lb_138  -0.0257558103881511
    x_29_9    product_ub_139  -4.3334709038425519e-02
    x_29_9    onehot_29_142  1
    x_29_9    stock_lb_204  9
    x_29_9    stock_ub_205  9
    x_29_9    parent_nonstrict_scope_206  1.8618514455586620e-02
    x_29_9    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_9    product_lb_138  1
    w_29_9    product_ub_139  1
    w_29_9    normalized_mass_29_143  1
    w_29_9    normalized_ratio_29_144  -1.8
    w_29_9    full_original_Gini_264  -2.5523809523809529e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_10   OBJ       1.1636571534741636e-02
    x_29_10   product_lb_140  -0.0257558103881511
    x_29_10   product_ub_141  -4.3334709038425519e-02
    x_29_10   onehot_29_142  1
    x_29_10   stock_lb_204  10
    x_29_10   stock_ub_205  10
    x_29_10   parent_nonstrict_scope_206  2.3273143069483273e-02
    x_29_10   unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_10   product_lb_140  1
    w_29_10   product_ub_141  1
    w_29_10   normalized_mass_29_143  1
    w_29_10   normalized_ratio_29_144  -2
    w_29_10   full_original_Gini_264  -3.0923809523809521e+01
    rho_29    normalized_ratio_29_144  1
    rho_29    block_pair_pos_215  1
    rho_29    block_pair_neg_216  -1
    rho_29    block_pair_pos_229  1
    rho_29    block_pair_neg_230  -1
    rho_29    block_pair_pos_241  1
    rho_29    block_pair_neg_242  -1
    rho_29    block_pair_pos_247  -1
    rho_29    block_pair_neg_248  1
    rho_29    block_pair_pos_249  -1
    rho_29    block_pair_neg_250  1
    rho_29    block_pair_pos_251  -1
    rho_29    block_pair_neg_252  1
    rho_29    block_pair_pos_261  1
    rho_29    block_pair_neg_262  -1
    rho_29    normalization_263  1
    MARKER    'MARKER'                 'INTORG'
    x_13_0    OBJ       7.4474103065332977e-03
    x_13_0    product_lb_145  -0.0257558103881511
    x_13_0    product_ub_146  -4.3334709038425519e-02
    x_13_0    onehot_13_163  1
    x_13_0    parent_nonstrict_scope_206  1.4894820613066595e-02
    x_13_0    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_0    product_lb_145  1
    w_13_0    product_ub_146  1
    w_13_0    normalized_mass_13_164  1
    w_13_0    full_original_Gini_264  -2.3076190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_1    OBJ       3.7237051532666493e-03
    x_13_1    product_lb_147  -0.0257558103881511
    x_13_1    product_ub_148  -4.3334709038425519e-02
    x_13_1    onehot_13_163  1
    x_13_1    stock_lb_204  1
    x_13_1    stock_ub_205  1
    x_13_1    parent_nonstrict_scope_206  1.1171115459799947e-02
    x_13_1    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_1    product_lb_147  1
    w_13_1    product_ub_148  1
    w_13_1    normalized_mass_13_164  1
    w_13_1    normalized_ratio_13_165  -0.25
    w_13_1    full_original_Gini_264  -1.6826190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_2    product_lb_149  -0.0257558103881511
    x_13_2    product_ub_150  -4.3334709038425519e-02
    x_13_2    onehot_13_163  1
    x_13_2    stock_lb_204  2
    x_13_2    stock_ub_205  2
    x_13_2    parent_nonstrict_scope_206  7.4474103065332977e-03
    x_13_2    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_2    product_lb_149  1
    w_13_2    product_ub_150  1
    w_13_2    normalized_mass_13_164  1
    w_13_2    normalized_ratio_13_165  -0.5
    w_13_2    full_original_Gini_264  -1.0909523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_3    OBJ       -3.7237051532666488e-03
    x_13_3    product_lb_151  -0.0257558103881511
    x_13_3    product_ub_152  -4.3334709038425519e-02
    x_13_3    onehot_13_163  1
    x_13_3    stock_lb_204  3
    x_13_3    stock_ub_205  3
    x_13_3    parent_nonstrict_scope_206  3.7237051532666488e-03
    x_13_3    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_3    product_lb_151  1
    w_13_3    product_ub_152  1
    w_13_3    normalized_mass_13_164  1
    w_13_3    normalized_ratio_13_165  -0.75
    w_13_3    full_original_Gini_264  -5.3976190476190471e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_4    OBJ       -7.4474103065332977e-03
    x_13_4    product_lb_153  -0.0257558103881511
    x_13_4    product_ub_154  -4.3334709038425519e-02
    x_13_4    onehot_13_163  1
    x_13_4    stock_lb_204  4
    x_13_4    stock_ub_205  4
    x_13_4    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_4    product_lb_153  1
    w_13_4    product_ub_154  1
    w_13_4    normalized_mass_13_164  1
    w_13_4    normalized_ratio_13_165  -1
    w_13_4    full_original_Gini_264  -4.9238095238095241e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_5    OBJ       -3.7237051532666488e-03
    x_13_5    product_lb_155  -0.0257558103881511
    x_13_5    product_ub_156  -4.3334709038425519e-02
    x_13_5    onehot_13_163  1
    x_13_5    stock_lb_204  5
    x_13_5    stock_ub_205  5
    x_13_5    parent_nonstrict_scope_206  3.7237051532666488e-03
    MARKER    'MARKER'                 'INTEND'
    w_13_5    product_lb_155  1
    w_13_5    product_ub_156  1
    w_13_5    normalized_mass_13_164  1
    w_13_5    normalized_ratio_13_165  -1.25
    w_13_5    full_original_Gini_264  -1.1173809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_6    product_lb_157  -0.0257558103881511
    x_13_6    product_ub_158  -4.3334709038425519e-02
    x_13_6    onehot_13_163  1
    x_13_6    stock_lb_204  6
    x_13_6    stock_ub_205  6
    x_13_6    parent_nonstrict_scope_206  7.4474103065332977e-03
    x_13_6    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_6    product_lb_157  1
    w_13_6    product_ub_158  1
    w_13_6    normalized_mass_13_164  1
    w_13_6    normalized_ratio_13_165  -1.5
    w_13_6    full_original_Gini_264  -1.7423809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_7    OBJ       3.7237051532666493e-03
    x_13_7    product_lb_159  -0.0257558103881511
    x_13_7    product_ub_160  -4.3334709038425519e-02
    x_13_7    onehot_13_163  1
    x_13_7    stock_lb_204  7
    x_13_7    stock_ub_205  7
    x_13_7    parent_nonstrict_scope_206  1.1171115459799947e-02
    x_13_7    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_7    product_lb_159  1
    w_13_7    product_ub_160  1
    w_13_7    normalized_mass_13_164  1
    w_13_7    normalized_ratio_13_165  -1.75
    w_13_7    full_original_Gini_264  -2.4173809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_8    OBJ       7.4474103065332977e-03
    x_13_8    product_lb_161  -0.0257558103881511
    x_13_8    product_ub_162  -4.3334709038425519e-02
    x_13_8    onehot_13_163  1
    x_13_8    stock_lb_204  8
    x_13_8    stock_ub_205  8
    x_13_8    parent_nonstrict_scope_206  1.4894820613066595e-02
    x_13_8    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_8    product_lb_161  1
    w_13_8    product_ub_162  1
    w_13_8    normalized_mass_13_164  1
    w_13_8    normalized_ratio_13_165  -2
    w_13_8    full_original_Gini_264  -3.0923809523809521e+01
    rho_13    normalized_ratio_13_165  1
    rho_13    block_pair_pos_207  1
    rho_13    block_pair_neg_208  -1
    rho_13    block_pair_pos_219  -1
    rho_13    block_pair_neg_220  1
    rho_13    block_pair_pos_221  -1
    rho_13    block_pair_neg_222  1
    rho_13    block_pair_pos_223  1
    rho_13    block_pair_neg_224  -1
    rho_13    block_pair_pos_233  1
    rho_13    block_pair_neg_234  -1
    rho_13    block_pair_pos_247  1
    rho_13    block_pair_neg_248  -1
    rho_13    block_pair_pos_253  1
    rho_13    block_pair_neg_254  -1
    rho_13    normalization_263  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_166  -0.0257558103881511
    x_27_0    product_ub_167  -4.3334709038425519e-02
    x_27_0    onehot_27_180  1
    x_27_0    parent_nonstrict_scope_206  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_166  1
    w_27_0    product_ub_167  1
    w_27_0    normalized_mass_27_181  1
    w_27_0    full_original_Gini_264  -2.3076190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_168  -0.0257558103881511
    x_27_1    product_ub_169  -4.3334709038425519e-02
    x_27_1    onehot_27_180  1
    x_27_1    stock_lb_204  1
    x_27_1    stock_ub_205  1
    x_27_1    parent_nonstrict_scope_206  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_168  1
    w_27_1    product_ub_169  1
    w_27_1    normalized_mass_27_181  1
    w_27_1    normalized_ratio_27_182  -3.3333333333333331e-01
    w_27_1    full_original_Gini_264  -1.4742857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_170  -0.0257558103881511
    x_27_2    product_ub_171  -4.3334709038425519e-02
    x_27_2    onehot_27_180  1
    x_27_2    stock_lb_204  2
    x_27_2    stock_ub_205  2
    x_27_2    parent_nonstrict_scope_206  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_170  1
    w_27_2    product_ub_171  1
    w_27_2    normalized_mass_27_181  1
    w_27_2    normalized_ratio_27_182  -6.6666666666666663e-01
    w_27_2    full_original_Gini_264  -7.0761904761904750e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_172  -0.0257558103881511
    x_27_3    product_ub_173  -4.3334709038425519e-02
    x_27_3    onehot_27_180  1
    x_27_3    stock_lb_204  3
    x_27_3    stock_ub_205  3
    x_27_3    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_172  1
    w_27_3    product_ub_173  1
    w_27_3    normalized_mass_27_181  1
    w_27_3    normalized_ratio_27_182  -1
    w_27_3    full_original_Gini_264  -4.9238095238095241e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_174  -0.0257558103881511
    x_27_4    product_ub_175  -4.3334709038425519e-02
    x_27_4    onehot_27_180  1
    x_27_4    stock_lb_204  4
    x_27_4    stock_ub_205  4
    x_27_4    parent_nonstrict_scope_206  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_174  1
    w_27_4    product_ub_175  1
    w_27_4    normalized_mass_27_181  1
    w_27_4    normalized_ratio_27_182  -1.3333333333333333e+00
    w_27_4    full_original_Gini_264  -1.3257142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_176  -0.0257558103881511
    x_27_5    product_ub_177  -4.3334709038425519e-02
    x_27_5    onehot_27_180  1
    x_27_5    stock_lb_204  5
    x_27_5    stock_ub_205  5
    x_27_5    parent_nonstrict_scope_206  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_176  1
    w_27_5    product_ub_177  1
    w_27_5    normalized_mass_27_181  1
    w_27_5    normalized_ratio_27_182  -1.6666666666666665e+00
    w_27_5    full_original_Gini_264  -2.1923809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_178  -0.0257558103881511
    x_27_6    product_ub_179  -4.3334709038425519e-02
    x_27_6    onehot_27_180  1
    x_27_6    stock_lb_204  6
    x_27_6    stock_ub_205  6
    x_27_6    parent_nonstrict_scope_206  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_178  1
    w_27_6    product_ub_179  1
    w_27_6    normalized_mass_27_181  1
    w_27_6    normalized_ratio_27_182  -2
    w_27_6    full_original_Gini_264  -3.0923809523809521e+01
    rho_27    normalized_ratio_27_182  1
    rho_27    block_pair_pos_213  1
    rho_27    block_pair_neg_214  -1
    rho_27    block_pair_pos_221  1
    rho_27    block_pair_neg_222  -1
    rho_27    block_pair_pos_227  1
    rho_27    block_pair_neg_228  -1
    rho_27    block_pair_pos_239  1
    rho_27    block_pair_neg_240  -1
    rho_27    block_pair_pos_245  -1
    rho_27    block_pair_neg_246  1
    rho_27    block_pair_pos_251  1
    rho_27    block_pair_neg_252  -1
    rho_27    block_pair_pos_259  1
    rho_27    block_pair_neg_260  -1
    rho_27    normalization_263  1
    MARKER    'MARKER'                 'INTORG'
    x_15_0    OBJ       7.4474103065332977e-03
    x_15_0    product_lb_183  -0.0257558103881511
    x_15_0    product_ub_184  -4.3334709038425519e-02
    x_15_0    onehot_15_201  1
    x_15_0    parent_nonstrict_scope_206  1.4894820613066595e-02
    x_15_0    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_0    product_lb_183  1
    w_15_0    product_ub_184  1
    w_15_0    normalized_mass_15_202  1
    w_15_0    full_original_Gini_264  -2.3076190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_1    OBJ       3.7237051532666493e-03
    x_15_1    product_lb_185  -0.0257558103881511
    x_15_1    product_ub_186  -4.3334709038425519e-02
    x_15_1    onehot_15_201  1
    x_15_1    stock_lb_204  1
    x_15_1    stock_ub_205  1
    x_15_1    parent_nonstrict_scope_206  1.1171115459799947e-02
    x_15_1    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_1    product_lb_185  1
    w_15_1    product_ub_186  1
    w_15_1    normalized_mass_15_202  1
    w_15_1    normalized_ratio_15_203  -0.25
    w_15_1    full_original_Gini_264  -1.6826190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_2    product_lb_187  -0.0257558103881511
    x_15_2    product_ub_188  -4.3334709038425519e-02
    x_15_2    onehot_15_201  1
    x_15_2    stock_lb_204  2
    x_15_2    stock_ub_205  2
    x_15_2    parent_nonstrict_scope_206  7.4474103065332977e-03
    x_15_2    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_2    product_lb_187  1
    w_15_2    product_ub_188  1
    w_15_2    normalized_mass_15_202  1
    w_15_2    normalized_ratio_15_203  -0.5
    w_15_2    full_original_Gini_264  -1.0909523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_3    OBJ       -3.7237051532666488e-03
    x_15_3    product_lb_189  -0.0257558103881511
    x_15_3    product_ub_190  -4.3334709038425519e-02
    x_15_3    onehot_15_201  1
    x_15_3    stock_lb_204  3
    x_15_3    stock_ub_205  3
    x_15_3    parent_nonstrict_scope_206  3.7237051532666488e-03
    x_15_3    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_3    product_lb_189  1
    w_15_3    product_ub_190  1
    w_15_3    normalized_mass_15_202  1
    w_15_3    normalized_ratio_15_203  -0.75
    w_15_3    full_original_Gini_264  -5.3976190476190471e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_4    OBJ       -7.4474103065332977e-03
    x_15_4    product_lb_191  -0.0257558103881511
    x_15_4    product_ub_192  -4.3334709038425519e-02
    x_15_4    onehot_15_201  1
    x_15_4    stock_lb_204  4
    x_15_4    stock_ub_205  4
    x_15_4    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_4    product_lb_191  1
    w_15_4    product_ub_192  1
    w_15_4    normalized_mass_15_202  1
    w_15_4    normalized_ratio_15_203  -1
    w_15_4    full_original_Gini_264  -4.9238095238095241e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_5    OBJ       -3.7237051532666488e-03
    x_15_5    product_lb_193  -0.0257558103881511
    x_15_5    product_ub_194  -4.3334709038425519e-02
    x_15_5    onehot_15_201  1
    x_15_5    stock_lb_204  5
    x_15_5    stock_ub_205  5
    x_15_5    parent_nonstrict_scope_206  3.7237051532666488e-03
    MARKER    'MARKER'                 'INTEND'
    w_15_5    product_lb_193  1
    w_15_5    product_ub_194  1
    w_15_5    normalized_mass_15_202  1
    w_15_5    normalized_ratio_15_203  -1.25
    w_15_5    full_original_Gini_264  -1.1173809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_6    product_lb_195  -0.0257558103881511
    x_15_6    product_ub_196  -4.3334709038425519e-02
    x_15_6    onehot_15_201  1
    x_15_6    stock_lb_204  6
    x_15_6    stock_ub_205  6
    x_15_6    parent_nonstrict_scope_206  7.4474103065332977e-03
    x_15_6    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_6    product_lb_195  1
    w_15_6    product_ub_196  1
    w_15_6    normalized_mass_15_202  1
    w_15_6    normalized_ratio_15_203  -1.5
    w_15_6    full_original_Gini_264  -1.7423809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_7    OBJ       3.7237051532666493e-03
    x_15_7    product_lb_197  -0.0257558103881511
    x_15_7    product_ub_198  -4.3334709038425519e-02
    x_15_7    onehot_15_201  1
    x_15_7    stock_lb_204  7
    x_15_7    stock_ub_205  7
    x_15_7    parent_nonstrict_scope_206  1.1171115459799947e-02
    x_15_7    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_7    product_lb_197  1
    w_15_7    product_ub_198  1
    w_15_7    normalized_mass_15_202  1
    w_15_7    normalized_ratio_15_203  -1.75
    w_15_7    full_original_Gini_264  -2.4173809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_8    OBJ       7.4474103065332977e-03
    x_15_8    product_lb_199  -0.0257558103881511
    x_15_8    product_ub_200  -4.3334709038425519e-02
    x_15_8    onehot_15_201  1
    x_15_8    stock_lb_204  8
    x_15_8    stock_ub_205  8
    x_15_8    parent_nonstrict_scope_206  1.4894820613066595e-02
    x_15_8    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_8    product_lb_199  1
    w_15_8    product_ub_200  1
    w_15_8    normalized_mass_15_202  1
    w_15_8    normalized_ratio_15_203  -2
    w_15_8    full_original_Gini_264  -3.0923809523809521e+01
    rho_15    normalized_ratio_15_203  1
    rho_15    block_pair_pos_211  1
    rho_15    block_pair_neg_212  -1
    rho_15    block_pair_pos_219  1
    rho_15    block_pair_neg_220  -1
    rho_15    block_pair_pos_225  1
    rho_15    block_pair_neg_226  -1
    rho_15    block_pair_pos_237  1
    rho_15    block_pair_neg_238  -1
    rho_15    block_pair_pos_245  1
    rho_15    block_pair_neg_246  -1
    rho_15    block_pair_pos_249  1
    rho_15    block_pair_neg_250  -1
    rho_15    block_pair_pos_257  1
    rho_15    block_pair_neg_258  -1
    rho_15    normalization_263  1
    a_16_12   block_pair_pos_231  1
    a_16_12   block_pair_neg_232  1
    a_16_12   full_original_Gini_264  -1
    a_16_34   block_pair_pos_243  1
    a_16_34   block_pair_neg_244  1
    a_16_34   full_original_Gini_264  -1
    a_16_14   block_pair_pos_235  1
    a_16_14   block_pair_neg_236  1
    a_16_14   full_original_Gini_264  -1
    a_16_29   block_pair_pos_241  1
    a_16_29   block_pair_neg_242  1
    a_16_29   full_original_Gini_264  -1
    a_16_13   block_pair_pos_233  1
    a_16_13   block_pair_neg_234  1
    a_16_13   full_original_Gini_264  -1
    a_16_27   block_pair_pos_239  1
    a_16_27   block_pair_neg_240  1
    a_16_27   full_original_Gini_264  -1
    a_16_15   block_pair_pos_237  1
    a_16_15   block_pair_neg_238  1
    a_16_15   full_original_Gini_264  -1
    a_12_34   block_pair_pos_217  1
    a_12_34   block_pair_neg_218  1
    a_12_34   full_original_Gini_264  -1
    a_12_14   block_pair_pos_209  1
    a_12_14   block_pair_neg_210  1
    a_12_14   full_original_Gini_264  -1
    a_12_29   block_pair_pos_215  1
    a_12_29   block_pair_neg_216  1
    a_12_29   full_original_Gini_264  -1
    a_12_13   block_pair_pos_207  1
    a_12_13   block_pair_neg_208  1
    a_12_13   full_original_Gini_264  -1
    a_12_27   block_pair_pos_213  1
    a_12_27   block_pair_neg_214  1
    a_12_27   full_original_Gini_264  -1
    a_12_15   block_pair_pos_211  1
    a_12_15   block_pair_neg_212  1
    a_12_15   full_original_Gini_264  -1
    a_34_14   block_pair_pos_255  1
    a_34_14   block_pair_neg_256  1
    a_34_14   full_original_Gini_264  -1
    a_34_29   block_pair_pos_261  1
    a_34_29   block_pair_neg_262  1
    a_34_29   full_original_Gini_264  -1
    a_34_13   block_pair_pos_253  1
    a_34_13   block_pair_neg_254  1
    a_34_13   full_original_Gini_264  -1
    a_34_27   block_pair_pos_259  1
    a_34_27   block_pair_neg_260  1
    a_34_27   full_original_Gini_264  -1
    a_34_15   block_pair_pos_257  1
    a_34_15   block_pair_neg_258  1
    a_34_15   full_original_Gini_264  -1
    a_14_29   block_pair_pos_229  1
    a_14_29   block_pair_neg_230  1
    a_14_29   full_original_Gini_264  -1
    a_14_13   block_pair_pos_223  1
    a_14_13   block_pair_neg_224  1
    a_14_13   full_original_Gini_264  -1
    a_14_27   block_pair_pos_227  1
    a_14_27   block_pair_neg_228  1
    a_14_27   full_original_Gini_264  -1
    a_14_15   block_pair_pos_225  1
    a_14_15   block_pair_neg_226  1
    a_14_15   full_original_Gini_264  -1
    a_29_13   block_pair_pos_247  1
    a_29_13   block_pair_neg_248  1
    a_29_13   full_original_Gini_264  -1
    a_29_27   block_pair_pos_251  1
    a_29_27   block_pair_neg_252  1
    a_29_27   full_original_Gini_264  -1
    a_29_15   block_pair_pos_249  1
    a_29_15   block_pair_neg_250  1
    a_29_15   full_original_Gini_264  -1
    a_13_27   block_pair_pos_221  1
    a_13_27   block_pair_neg_222  1
    a_13_27   full_original_Gini_264  -1
    a_13_15   block_pair_pos_219  1
    a_13_15   block_pair_neg_220  1
    a_13_15   full_original_Gini_264  -1
    a_27_15   block_pair_pos_245  1
    a_27_15   block_pair_neg_246  1
    a_27_15   full_original_Gini_264  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_16_0  unique_nonzero_owner_265  1
    service_0_16_0  service_visit_def_727  1
    service_0_16_0  free_load_conservation_728  -2
    service_0_16_0  original_T_including_depot_unload_775  240
    service_0_16_1  unique_nonzero_owner_266  1
    service_0_16_1  service_visit_def_727  1
    service_0_16_1  free_load_conservation_728  -1
    service_0_16_1  original_T_including_depot_unload_775  120
    service_0_16_3  unique_nonzero_owner_267  1
    service_0_16_3  service_visit_def_727  1
    service_0_16_3  free_load_conservation_728  1
    service_0_16_4  unique_nonzero_owner_268  1
    service_0_16_4  service_visit_def_727  1
    service_0_16_4  free_load_conservation_728  2
    service_0_16_5  unique_nonzero_owner_269  1
    service_0_16_5  service_visit_def_727  1
    service_0_16_5  free_load_conservation_728  3
    service_0_16_6  unique_nonzero_owner_270  1
    service_0_16_6  service_visit_def_727  1
    service_0_16_6  free_load_conservation_728  4
    service_0_16_7  unique_nonzero_owner_271  1
    service_0_16_7  service_visit_def_727  1
    service_0_16_7  free_load_conservation_728  5
    service_0_16_8  unique_nonzero_owner_272  1
    service_0_16_8  service_visit_def_727  1
    service_0_16_8  free_load_conservation_728  6
    service_0_16_9  unique_nonzero_owner_273  1
    service_0_16_9  service_visit_def_727  1
    service_0_16_9  free_load_conservation_728  7
    service_0_16_10  unique_nonzero_owner_274  1
    service_0_16_10  service_visit_def_727  1
    service_0_16_10  free_load_conservation_728  8
    service_0_16_11  unique_nonzero_owner_275  1
    service_0_16_11  service_visit_def_727  1
    service_0_16_11  free_load_conservation_728  9
    service_0_16_12  unique_nonzero_owner_276  1
    service_0_16_12  service_visit_def_727  1
    service_0_16_12  free_load_conservation_728  10
    service_0_16_13  unique_nonzero_owner_277  1
    service_0_16_13  service_visit_def_727  1
    service_0_16_13  free_load_conservation_728  11
    service_0_16_14  unique_nonzero_owner_278  1
    service_0_16_14  service_visit_def_727  1
    service_0_16_14  free_load_conservation_728  12
    service_0_16_15  unique_nonzero_owner_279  1
    service_0_16_15  service_visit_def_727  1
    service_0_16_15  free_load_conservation_728  13
    service_1_16_0  unique_nonzero_owner_265  1
    service_1_16_0  service_visit_def_997  1
    service_1_16_0  free_load_conservation_998  -2
    service_1_16_0  original_T_including_depot_unload_1042  240
    service_1_16_1  unique_nonzero_owner_266  1
    service_1_16_1  service_visit_def_997  1
    service_1_16_1  free_load_conservation_998  -1
    service_1_16_1  original_T_including_depot_unload_1042  120
    service_1_16_3  unique_nonzero_owner_267  1
    service_1_16_3  service_visit_def_997  1
    service_1_16_3  free_load_conservation_998  1
    service_1_16_4  unique_nonzero_owner_268  1
    service_1_16_4  service_visit_def_997  1
    service_1_16_4  free_load_conservation_998  2
    service_1_16_5  unique_nonzero_owner_269  1
    service_1_16_5  service_visit_def_997  1
    service_1_16_5  free_load_conservation_998  3
    service_1_16_6  unique_nonzero_owner_270  1
    service_1_16_6  service_visit_def_997  1
    service_1_16_6  free_load_conservation_998  4
    service_1_16_7  unique_nonzero_owner_271  1
    service_1_16_7  service_visit_def_997  1
    service_1_16_7  free_load_conservation_998  5
    service_1_16_8  unique_nonzero_owner_272  1
    service_1_16_8  service_visit_def_997  1
    service_1_16_8  free_load_conservation_998  6
    service_1_16_9  unique_nonzero_owner_273  1
    service_1_16_9  service_visit_def_997  1
    service_1_16_9  free_load_conservation_998  7
    service_1_16_10  unique_nonzero_owner_274  1
    service_1_16_10  service_visit_def_997  1
    service_1_16_10  free_load_conservation_998  8
    service_1_16_11  unique_nonzero_owner_275  1
    service_1_16_11  service_visit_def_997  1
    service_1_16_11  free_load_conservation_998  9
    service_1_16_12  unique_nonzero_owner_276  1
    service_1_16_12  service_visit_def_997  1
    service_1_16_12  free_load_conservation_998  10
    service_1_16_13  unique_nonzero_owner_277  1
    service_1_16_13  service_visit_def_997  1
    service_1_16_13  free_load_conservation_998  11
    service_1_16_14  unique_nonzero_owner_278  1
    service_1_16_14  service_visit_def_997  1
    service_1_16_14  free_load_conservation_998  12
    service_1_16_15  unique_nonzero_owner_279  1
    service_1_16_15  service_visit_def_997  1
    service_1_16_15  free_load_conservation_998  13
    service_2_16_0  unique_nonzero_owner_265  1
    service_2_16_0  service_visit_def_1423  1
    service_2_16_0  free_load_conservation_1424  -2
    service_2_16_0  original_T_including_depot_unload_1471  240
    service_2_16_1  unique_nonzero_owner_266  1
    service_2_16_1  service_visit_def_1423  1
    service_2_16_1  free_load_conservation_1424  -1
    service_2_16_1  original_T_including_depot_unload_1471  120
    service_2_16_3  unique_nonzero_owner_267  1
    service_2_16_3  service_visit_def_1423  1
    service_2_16_3  free_load_conservation_1424  1
    service_2_16_4  unique_nonzero_owner_268  1
    service_2_16_4  service_visit_def_1423  1
    service_2_16_4  free_load_conservation_1424  2
    service_2_16_5  unique_nonzero_owner_269  1
    service_2_16_5  service_visit_def_1423  1
    service_2_16_5  free_load_conservation_1424  3
    service_2_16_6  unique_nonzero_owner_270  1
    service_2_16_6  service_visit_def_1423  1
    service_2_16_6  free_load_conservation_1424  4
    service_2_16_7  unique_nonzero_owner_271  1
    service_2_16_7  service_visit_def_1423  1
    service_2_16_7  free_load_conservation_1424  5
    service_2_16_8  unique_nonzero_owner_272  1
    service_2_16_8  service_visit_def_1423  1
    service_2_16_8  free_load_conservation_1424  6
    service_2_16_9  unique_nonzero_owner_273  1
    service_2_16_9  service_visit_def_1423  1
    service_2_16_9  free_load_conservation_1424  7
    service_2_16_10  unique_nonzero_owner_274  1
    service_2_16_10  service_visit_def_1423  1
    service_2_16_10  free_load_conservation_1424  8
    service_2_16_11  unique_nonzero_owner_275  1
    service_2_16_11  service_visit_def_1423  1
    service_2_16_11  free_load_conservation_1424  9
    service_2_16_12  unique_nonzero_owner_276  1
    service_2_16_12  service_visit_def_1423  1
    service_2_16_12  free_load_conservation_1424  10
    service_2_16_13  unique_nonzero_owner_277  1
    service_2_16_13  service_visit_def_1423  1
    service_2_16_13  free_load_conservation_1424  11
    service_2_16_14  unique_nonzero_owner_278  1
    service_2_16_14  service_visit_def_1423  1
    service_2_16_14  free_load_conservation_1424  12
    service_2_16_15  unique_nonzero_owner_279  1
    service_2_16_15  service_visit_def_1423  1
    service_2_16_15  free_load_conservation_1424  13
    service_0_12_0  unique_nonzero_owner_280  1
    service_0_12_0  service_visit_def_733  1
    service_0_12_0  free_load_conservation_734  -1
    service_0_12_0  original_T_including_depot_unload_775  120
    service_0_12_2  unique_nonzero_owner_281  1
    service_0_12_2  service_visit_def_733  1
    service_0_12_2  free_load_conservation_734  1
    service_0_12_3  unique_nonzero_owner_282  1
    service_0_12_3  service_visit_def_733  1
    service_0_12_3  free_load_conservation_734  2
    service_0_12_4  unique_nonzero_owner_283  1
    service_0_12_4  service_visit_def_733  1
    service_0_12_4  free_load_conservation_734  3
    service_0_12_5  unique_nonzero_owner_284  1
    service_0_12_5  service_visit_def_733  1
    service_0_12_5  free_load_conservation_734  4
    service_0_12_6  unique_nonzero_owner_285  1
    service_0_12_6  service_visit_def_733  1
    service_0_12_6  free_load_conservation_734  5
    service_0_12_7  unique_nonzero_owner_286  1
    service_0_12_7  service_visit_def_733  1
    service_0_12_7  free_load_conservation_734  6
    service_0_12_8  unique_nonzero_owner_287  1
    service_0_12_8  service_visit_def_733  1
    service_0_12_8  free_load_conservation_734  7
    service_0_12_9  unique_nonzero_owner_288  1
    service_0_12_9  service_visit_def_733  1
    service_0_12_9  free_load_conservation_734  8
    service_0_12_10  unique_nonzero_owner_289  1
    service_0_12_10  service_visit_def_733  1
    service_0_12_10  free_load_conservation_734  9
    service_0_12_11  unique_nonzero_owner_290  1
    service_0_12_11  service_visit_def_733  1
    service_0_12_11  free_load_conservation_734  10
    service_0_12_12  unique_nonzero_owner_291  1
    service_0_12_12  service_visit_def_733  1
    service_0_12_12  free_load_conservation_734  11
    service_1_12_0  unique_nonzero_owner_280  1
    service_1_12_0  service_visit_def_1003  1
    service_1_12_0  free_load_conservation_1004  -1
    service_1_12_0  original_T_including_depot_unload_1042  120
    service_1_12_2  unique_nonzero_owner_281  1
    service_1_12_2  service_visit_def_1003  1
    service_1_12_2  free_load_conservation_1004  1
    service_1_12_3  unique_nonzero_owner_282  1
    service_1_12_3  service_visit_def_1003  1
    service_1_12_3  free_load_conservation_1004  2
    service_1_12_4  unique_nonzero_owner_283  1
    service_1_12_4  service_visit_def_1003  1
    service_1_12_4  free_load_conservation_1004  3
    service_1_12_5  unique_nonzero_owner_284  1
    service_1_12_5  service_visit_def_1003  1
    service_1_12_5  free_load_conservation_1004  4
    service_1_12_6  unique_nonzero_owner_285  1
    service_1_12_6  service_visit_def_1003  1
    service_1_12_6  free_load_conservation_1004  5
    service_1_12_7  unique_nonzero_owner_286  1
    service_1_12_7  service_visit_def_1003  1
    service_1_12_7  free_load_conservation_1004  6
    service_1_12_8  unique_nonzero_owner_287  1
    service_1_12_8  service_visit_def_1003  1
    service_1_12_8  free_load_conservation_1004  7
    service_1_12_9  unique_nonzero_owner_288  1
    service_1_12_9  service_visit_def_1003  1
    service_1_12_9  free_load_conservation_1004  8
    service_1_12_10  unique_nonzero_owner_289  1
    service_1_12_10  service_visit_def_1003  1
    service_1_12_10  free_load_conservation_1004  9
    service_1_12_11  unique_nonzero_owner_290  1
    service_1_12_11  service_visit_def_1003  1
    service_1_12_11  free_load_conservation_1004  10
    service_1_12_12  unique_nonzero_owner_291  1
    service_1_12_12  service_visit_def_1003  1
    service_1_12_12  free_load_conservation_1004  11
    service_2_12_0  unique_nonzero_owner_280  1
    service_2_12_0  service_visit_def_1429  1
    service_2_12_0  free_load_conservation_1430  -1
    service_2_12_0  original_T_including_depot_unload_1471  120
    service_2_12_2  unique_nonzero_owner_281  1
    service_2_12_2  service_visit_def_1429  1
    service_2_12_2  free_load_conservation_1430  1
    service_2_12_3  unique_nonzero_owner_282  1
    service_2_12_3  service_visit_def_1429  1
    service_2_12_3  free_load_conservation_1430  2
    service_2_12_4  unique_nonzero_owner_283  1
    service_2_12_4  service_visit_def_1429  1
    service_2_12_4  free_load_conservation_1430  3
    service_2_12_5  unique_nonzero_owner_284  1
    service_2_12_5  service_visit_def_1429  1
    service_2_12_5  free_load_conservation_1430  4
    service_2_12_6  unique_nonzero_owner_285  1
    service_2_12_6  service_visit_def_1429  1
    service_2_12_6  free_load_conservation_1430  5
    service_2_12_7  unique_nonzero_owner_286  1
    service_2_12_7  service_visit_def_1429  1
    service_2_12_7  free_load_conservation_1430  6
    service_2_12_8  unique_nonzero_owner_287  1
    service_2_12_8  service_visit_def_1429  1
    service_2_12_8  free_load_conservation_1430  7
    service_2_12_9  unique_nonzero_owner_288  1
    service_2_12_9  service_visit_def_1429  1
    service_2_12_9  free_load_conservation_1430  8
    service_2_12_10  unique_nonzero_owner_289  1
    service_2_12_10  service_visit_def_1429  1
    service_2_12_10  free_load_conservation_1430  9
    service_2_12_11  unique_nonzero_owner_290  1
    service_2_12_11  service_visit_def_1429  1
    service_2_12_11  free_load_conservation_1430  10
    service_2_12_12  unique_nonzero_owner_291  1
    service_2_12_12  service_visit_def_1429  1
    service_2_12_12  free_load_conservation_1430  11
    service_0_34_0  unique_nonzero_owner_292  1
    service_0_34_0  service_visit_def_739  1
    service_0_34_0  free_load_conservation_740  -2
    service_0_34_0  original_T_including_depot_unload_775  240
    service_0_34_1  unique_nonzero_owner_293  1
    service_0_34_1  service_visit_def_739  1
    service_0_34_1  free_load_conservation_740  -1
    service_0_34_1  original_T_including_depot_unload_775  120
    service_0_34_3  unique_nonzero_owner_294  1
    service_0_34_3  service_visit_def_739  1
    service_0_34_3  free_load_conservation_740  1
    service_0_34_4  unique_nonzero_owner_295  1
    service_0_34_4  service_visit_def_739  1
    service_0_34_4  free_load_conservation_740  2
    service_0_34_5  unique_nonzero_owner_296  1
    service_0_34_5  service_visit_def_739  1
    service_0_34_5  free_load_conservation_740  3
    service_0_34_6  unique_nonzero_owner_297  1
    service_0_34_6  service_visit_def_739  1
    service_0_34_6  free_load_conservation_740  4
    service_0_34_7  unique_nonzero_owner_298  1
    service_0_34_7  service_visit_def_739  1
    service_0_34_7  free_load_conservation_740  5
    service_0_34_8  unique_nonzero_owner_299  1
    service_0_34_8  service_visit_def_739  1
    service_0_34_8  free_load_conservation_740  6
    service_0_34_9  unique_nonzero_owner_300  1
    service_0_34_9  service_visit_def_739  1
    service_0_34_9  free_load_conservation_740  7
    service_0_34_10  unique_nonzero_owner_301  1
    service_0_34_10  service_visit_def_739  1
    service_0_34_10  free_load_conservation_740  8
    service_0_34_11  unique_nonzero_owner_302  1
    service_0_34_11  service_visit_def_739  1
    service_0_34_11  free_load_conservation_740  9
    service_0_34_12  unique_nonzero_owner_303  1
    service_0_34_12  service_visit_def_739  1
    service_0_34_12  free_load_conservation_740  10
    service_0_34_13  unique_nonzero_owner_304  1
    service_0_34_13  service_visit_def_739  1
    service_0_34_13  free_load_conservation_740  11
    service_0_34_14  unique_nonzero_owner_305  1
    service_0_34_14  service_visit_def_739  1
    service_0_34_14  free_load_conservation_740  12
    service_0_34_15  unique_nonzero_owner_306  1
    service_0_34_15  service_visit_def_739  1
    service_0_34_15  free_load_conservation_740  13
    service_1_34_0  unique_nonzero_owner_292  1
    service_1_34_0  service_visit_def_1009  1
    service_1_34_0  free_load_conservation_1010  -2
    service_1_34_0  original_T_including_depot_unload_1042  240
    service_1_34_1  unique_nonzero_owner_293  1
    service_1_34_1  service_visit_def_1009  1
    service_1_34_1  free_load_conservation_1010  -1
    service_1_34_1  original_T_including_depot_unload_1042  120
    service_1_34_3  unique_nonzero_owner_294  1
    service_1_34_3  service_visit_def_1009  1
    service_1_34_3  free_load_conservation_1010  1
    service_1_34_4  unique_nonzero_owner_295  1
    service_1_34_4  service_visit_def_1009  1
    service_1_34_4  free_load_conservation_1010  2
    service_1_34_5  unique_nonzero_owner_296  1
    service_1_34_5  service_visit_def_1009  1
    service_1_34_5  free_load_conservation_1010  3
    service_1_34_6  unique_nonzero_owner_297  1
    service_1_34_6  service_visit_def_1009  1
    service_1_34_6  free_load_conservation_1010  4
    service_1_34_7  unique_nonzero_owner_298  1
    service_1_34_7  service_visit_def_1009  1
    service_1_34_7  free_load_conservation_1010  5
    service_1_34_8  unique_nonzero_owner_299  1
    service_1_34_8  service_visit_def_1009  1
    service_1_34_8  free_load_conservation_1010  6
    service_1_34_9  unique_nonzero_owner_300  1
    service_1_34_9  service_visit_def_1009  1
    service_1_34_9  free_load_conservation_1010  7
    service_1_34_10  unique_nonzero_owner_301  1
    service_1_34_10  service_visit_def_1009  1
    service_1_34_10  free_load_conservation_1010  8
    service_1_34_11  unique_nonzero_owner_302  1
    service_1_34_11  service_visit_def_1009  1
    service_1_34_11  free_load_conservation_1010  9
    service_1_34_12  unique_nonzero_owner_303  1
    service_1_34_12  service_visit_def_1009  1
    service_1_34_12  free_load_conservation_1010  10
    service_1_34_13  unique_nonzero_owner_304  1
    service_1_34_13  service_visit_def_1009  1
    service_1_34_13  free_load_conservation_1010  11
    service_1_34_14  unique_nonzero_owner_305  1
    service_1_34_14  service_visit_def_1009  1
    service_1_34_14  free_load_conservation_1010  12
    service_1_34_15  unique_nonzero_owner_306  1
    service_1_34_15  service_visit_def_1009  1
    service_1_34_15  free_load_conservation_1010  13
    service_2_34_0  unique_nonzero_owner_292  1
    service_2_34_0  service_visit_def_1435  1
    service_2_34_0  free_load_conservation_1436  -2
    service_2_34_0  original_T_including_depot_unload_1471  240
    service_2_34_1  unique_nonzero_owner_293  1
    service_2_34_1  service_visit_def_1435  1
    service_2_34_1  free_load_conservation_1436  -1
    service_2_34_1  original_T_including_depot_unload_1471  120
    service_2_34_3  unique_nonzero_owner_294  1
    service_2_34_3  service_visit_def_1435  1
    service_2_34_3  free_load_conservation_1436  1
    service_2_34_4  unique_nonzero_owner_295  1
    service_2_34_4  service_visit_def_1435  1
    service_2_34_4  free_load_conservation_1436  2
    service_2_34_5  unique_nonzero_owner_296  1
    service_2_34_5  service_visit_def_1435  1
    service_2_34_5  free_load_conservation_1436  3
    service_2_34_6  unique_nonzero_owner_297  1
    service_2_34_6  service_visit_def_1435  1
    service_2_34_6  free_load_conservation_1436  4
    service_2_34_7  unique_nonzero_owner_298  1
    service_2_34_7  service_visit_def_1435  1
    service_2_34_7  free_load_conservation_1436  5
    service_2_34_8  unique_nonzero_owner_299  1
    service_2_34_8  service_visit_def_1435  1
    service_2_34_8  free_load_conservation_1436  6
    service_2_34_9  unique_nonzero_owner_300  1
    service_2_34_9  service_visit_def_1435  1
    service_2_34_9  free_load_conservation_1436  7
    service_2_34_10  unique_nonzero_owner_301  1
    service_2_34_10  service_visit_def_1435  1
    service_2_34_10  free_load_conservation_1436  8
    service_2_34_11  unique_nonzero_owner_302  1
    service_2_34_11  service_visit_def_1435  1
    service_2_34_11  free_load_conservation_1436  9
    service_2_34_12  unique_nonzero_owner_303  1
    service_2_34_12  service_visit_def_1435  1
    service_2_34_12  free_load_conservation_1436  10
    service_2_34_13  unique_nonzero_owner_304  1
    service_2_34_13  service_visit_def_1435  1
    service_2_34_13  free_load_conservation_1436  11
    service_2_34_14  unique_nonzero_owner_305  1
    service_2_34_14  service_visit_def_1435  1
    service_2_34_14  free_load_conservation_1436  12
    service_2_34_15  unique_nonzero_owner_306  1
    service_2_34_15  service_visit_def_1435  1
    service_2_34_15  free_load_conservation_1436  13
    service_0_14_0  unique_nonzero_owner_307  1
    service_0_14_0  service_visit_def_745  1
    service_0_14_0  free_load_conservation_746  -2
    service_0_14_0  original_T_including_depot_unload_775  240
    service_0_14_1  unique_nonzero_owner_308  1
    service_0_14_1  service_visit_def_745  1
    service_0_14_1  free_load_conservation_746  -1
    service_0_14_1  original_T_including_depot_unload_775  120
    service_0_14_3  unique_nonzero_owner_309  1
    service_0_14_3  service_visit_def_745  1
    service_0_14_3  free_load_conservation_746  1
    service_0_14_4  unique_nonzero_owner_310  1
    service_0_14_4  service_visit_def_745  1
    service_0_14_4  free_load_conservation_746  2
    service_0_14_5  unique_nonzero_owner_311  1
    service_0_14_5  service_visit_def_745  1
    service_0_14_5  free_load_conservation_746  3
    service_0_14_6  unique_nonzero_owner_312  1
    service_0_14_6  service_visit_def_745  1
    service_0_14_6  free_load_conservation_746  4
    service_0_14_7  unique_nonzero_owner_313  1
    service_0_14_7  service_visit_def_745  1
    service_0_14_7  free_load_conservation_746  5
    service_0_14_8  unique_nonzero_owner_314  1
    service_0_14_8  service_visit_def_745  1
    service_0_14_8  free_load_conservation_746  6
    service_1_14_0  unique_nonzero_owner_307  1
    service_1_14_0  service_visit_def_1015  1
    service_1_14_0  free_load_conservation_1016  -2
    service_1_14_0  original_T_including_depot_unload_1042  240
    service_1_14_1  unique_nonzero_owner_308  1
    service_1_14_1  service_visit_def_1015  1
    service_1_14_1  free_load_conservation_1016  -1
    service_1_14_1  original_T_including_depot_unload_1042  120
    service_1_14_3  unique_nonzero_owner_309  1
    service_1_14_3  service_visit_def_1015  1
    service_1_14_3  free_load_conservation_1016  1
    service_1_14_4  unique_nonzero_owner_310  1
    service_1_14_4  service_visit_def_1015  1
    service_1_14_4  free_load_conservation_1016  2
    service_1_14_5  unique_nonzero_owner_311  1
    service_1_14_5  service_visit_def_1015  1
    service_1_14_5  free_load_conservation_1016  3
    service_1_14_6  unique_nonzero_owner_312  1
    service_1_14_6  service_visit_def_1015  1
    service_1_14_6  free_load_conservation_1016  4
    service_1_14_7  unique_nonzero_owner_313  1
    service_1_14_7  service_visit_def_1015  1
    service_1_14_7  free_load_conservation_1016  5
    service_1_14_8  unique_nonzero_owner_314  1
    service_1_14_8  service_visit_def_1015  1
    service_1_14_8  free_load_conservation_1016  6
    service_2_14_0  unique_nonzero_owner_307  1
    service_2_14_0  service_visit_def_1441  1
    service_2_14_0  free_load_conservation_1442  -2
    service_2_14_0  original_T_including_depot_unload_1471  240
    service_2_14_1  unique_nonzero_owner_308  1
    service_2_14_1  service_visit_def_1441  1
    service_2_14_1  free_load_conservation_1442  -1
    service_2_14_1  original_T_including_depot_unload_1471  120
    service_2_14_3  unique_nonzero_owner_309  1
    service_2_14_3  service_visit_def_1441  1
    service_2_14_3  free_load_conservation_1442  1
    service_2_14_4  unique_nonzero_owner_310  1
    service_2_14_4  service_visit_def_1441  1
    service_2_14_4  free_load_conservation_1442  2
    service_2_14_5  unique_nonzero_owner_311  1
    service_2_14_5  service_visit_def_1441  1
    service_2_14_5  free_load_conservation_1442  3
    service_2_14_6  unique_nonzero_owner_312  1
    service_2_14_6  service_visit_def_1441  1
    service_2_14_6  free_load_conservation_1442  4
    service_2_14_7  unique_nonzero_owner_313  1
    service_2_14_7  service_visit_def_1441  1
    service_2_14_7  free_load_conservation_1442  5
    service_2_14_8  unique_nonzero_owner_314  1
    service_2_14_8  service_visit_def_1441  1
    service_2_14_8  free_load_conservation_1442  6
    service_0_29_0  unique_nonzero_owner_315  1
    service_0_29_0  service_visit_def_751  1
    service_0_29_0  free_load_conservation_752  -1
    service_0_29_0  original_T_including_depot_unload_775  120
    service_0_29_2  unique_nonzero_owner_316  1
    service_0_29_2  service_visit_def_751  1
    service_0_29_2  free_load_conservation_752  1
    service_0_29_3  unique_nonzero_owner_317  1
    service_0_29_3  service_visit_def_751  1
    service_0_29_3  free_load_conservation_752  2
    service_0_29_4  unique_nonzero_owner_318  1
    service_0_29_4  service_visit_def_751  1
    service_0_29_4  free_load_conservation_752  3
    service_0_29_5  unique_nonzero_owner_319  1
    service_0_29_5  service_visit_def_751  1
    service_0_29_5  free_load_conservation_752  4
    service_0_29_6  unique_nonzero_owner_320  1
    service_0_29_6  service_visit_def_751  1
    service_0_29_6  free_load_conservation_752  5
    service_0_29_7  unique_nonzero_owner_321  1
    service_0_29_7  service_visit_def_751  1
    service_0_29_7  free_load_conservation_752  6
    service_0_29_8  unique_nonzero_owner_322  1
    service_0_29_8  service_visit_def_751  1
    service_0_29_8  free_load_conservation_752  7
    service_0_29_9  unique_nonzero_owner_323  1
    service_0_29_9  service_visit_def_751  1
    service_0_29_9  free_load_conservation_752  8
    service_0_29_10  unique_nonzero_owner_324  1
    service_0_29_10  service_visit_def_751  1
    service_0_29_10  free_load_conservation_752  9
    service_1_29_0  unique_nonzero_owner_315  1
    service_1_29_0  service_visit_def_1021  1
    service_1_29_0  free_load_conservation_1022  -1
    service_1_29_0  original_T_including_depot_unload_1042  120
    service_1_29_2  unique_nonzero_owner_316  1
    service_1_29_2  service_visit_def_1021  1
    service_1_29_2  free_load_conservation_1022  1
    service_1_29_3  unique_nonzero_owner_317  1
    service_1_29_3  service_visit_def_1021  1
    service_1_29_3  free_load_conservation_1022  2
    service_1_29_4  unique_nonzero_owner_318  1
    service_1_29_4  service_visit_def_1021  1
    service_1_29_4  free_load_conservation_1022  3
    service_1_29_5  unique_nonzero_owner_319  1
    service_1_29_5  service_visit_def_1021  1
    service_1_29_5  free_load_conservation_1022  4
    service_1_29_6  unique_nonzero_owner_320  1
    service_1_29_6  service_visit_def_1021  1
    service_1_29_6  free_load_conservation_1022  5
    service_1_29_7  unique_nonzero_owner_321  1
    service_1_29_7  service_visit_def_1021  1
    service_1_29_7  free_load_conservation_1022  6
    service_1_29_8  unique_nonzero_owner_322  1
    service_1_29_8  service_visit_def_1021  1
    service_1_29_8  free_load_conservation_1022  7
    service_1_29_9  unique_nonzero_owner_323  1
    service_1_29_9  service_visit_def_1021  1
    service_1_29_9  free_load_conservation_1022  8
    service_1_29_10  unique_nonzero_owner_324  1
    service_1_29_10  service_visit_def_1021  1
    service_1_29_10  free_load_conservation_1022  9
    service_2_29_0  unique_nonzero_owner_315  1
    service_2_29_0  service_visit_def_1447  1
    service_2_29_0  free_load_conservation_1448  -1
    service_2_29_0  original_T_including_depot_unload_1471  120
    service_2_29_2  unique_nonzero_owner_316  1
    service_2_29_2  service_visit_def_1447  1
    service_2_29_2  free_load_conservation_1448  1
    service_2_29_3  unique_nonzero_owner_317  1
    service_2_29_3  service_visit_def_1447  1
    service_2_29_3  free_load_conservation_1448  2
    service_2_29_4  unique_nonzero_owner_318  1
    service_2_29_4  service_visit_def_1447  1
    service_2_29_4  free_load_conservation_1448  3
    service_2_29_5  unique_nonzero_owner_319  1
    service_2_29_5  service_visit_def_1447  1
    service_2_29_5  free_load_conservation_1448  4
    service_2_29_6  unique_nonzero_owner_320  1
    service_2_29_6  service_visit_def_1447  1
    service_2_29_6  free_load_conservation_1448  5
    service_2_29_7  unique_nonzero_owner_321  1
    service_2_29_7  service_visit_def_1447  1
    service_2_29_7  free_load_conservation_1448  6
    service_2_29_8  unique_nonzero_owner_322  1
    service_2_29_8  service_visit_def_1447  1
    service_2_29_8  free_load_conservation_1448  7
    service_2_29_9  unique_nonzero_owner_323  1
    service_2_29_9  service_visit_def_1447  1
    service_2_29_9  free_load_conservation_1448  8
    service_2_29_10  unique_nonzero_owner_324  1
    service_2_29_10  service_visit_def_1447  1
    service_2_29_10  free_load_conservation_1448  9
    service_0_13_0  unique_nonzero_owner_325  1
    service_0_13_0  service_visit_def_757  1
    service_0_13_0  free_load_conservation_758  -5
    service_0_13_0  original_T_including_depot_unload_775  600
    service_0_13_1  unique_nonzero_owner_326  1
    service_0_13_1  service_visit_def_757  1
    service_0_13_1  free_load_conservation_758  -4
    service_0_13_1  original_T_including_depot_unload_775  480
    service_0_13_2  unique_nonzero_owner_327  1
    service_0_13_2  service_visit_def_757  1
    service_0_13_2  free_load_conservation_758  -3
    service_0_13_2  original_T_including_depot_unload_775  360
    service_0_13_3  unique_nonzero_owner_328  1
    service_0_13_3  service_visit_def_757  1
    service_0_13_3  free_load_conservation_758  -2
    service_0_13_3  original_T_including_depot_unload_775  240
    service_0_13_4  unique_nonzero_owner_329  1
    service_0_13_4  service_visit_def_757  1
    service_0_13_4  free_load_conservation_758  -1
    service_0_13_4  original_T_including_depot_unload_775  120
    service_0_13_6  unique_nonzero_owner_330  1
    service_0_13_6  service_visit_def_757  1
    service_0_13_6  free_load_conservation_758  1
    service_0_13_7  unique_nonzero_owner_331  1
    service_0_13_7  service_visit_def_757  1
    service_0_13_7  free_load_conservation_758  2
    service_0_13_8  unique_nonzero_owner_332  1
    service_0_13_8  service_visit_def_757  1
    service_0_13_8  free_load_conservation_758  3
    service_1_13_0  unique_nonzero_owner_325  1
    service_1_13_0  service_visit_def_1027  1
    service_1_13_0  free_load_conservation_1028  -5
    service_1_13_0  original_T_including_depot_unload_1042  600
    service_1_13_1  unique_nonzero_owner_326  1
    service_1_13_1  service_visit_def_1027  1
    service_1_13_1  free_load_conservation_1028  -4
    service_1_13_1  original_T_including_depot_unload_1042  480
    service_1_13_2  unique_nonzero_owner_327  1
    service_1_13_2  service_visit_def_1027  1
    service_1_13_2  free_load_conservation_1028  -3
    service_1_13_2  original_T_including_depot_unload_1042  360
    service_1_13_3  unique_nonzero_owner_328  1
    service_1_13_3  service_visit_def_1027  1
    service_1_13_3  free_load_conservation_1028  -2
    service_1_13_3  original_T_including_depot_unload_1042  240
    service_1_13_4  unique_nonzero_owner_329  1
    service_1_13_4  service_visit_def_1027  1
    service_1_13_4  free_load_conservation_1028  -1
    service_1_13_4  original_T_including_depot_unload_1042  120
    service_1_13_6  unique_nonzero_owner_330  1
    service_1_13_6  service_visit_def_1027  1
    service_1_13_6  free_load_conservation_1028  1
    service_1_13_7  unique_nonzero_owner_331  1
    service_1_13_7  service_visit_def_1027  1
    service_1_13_7  free_load_conservation_1028  2
    service_1_13_8  unique_nonzero_owner_332  1
    service_1_13_8  service_visit_def_1027  1
    service_1_13_8  free_load_conservation_1028  3
    service_2_13_0  unique_nonzero_owner_325  1
    service_2_13_0  service_visit_def_1453  1
    service_2_13_0  free_load_conservation_1454  -5
    service_2_13_0  original_T_including_depot_unload_1471  600
    service_2_13_1  unique_nonzero_owner_326  1
    service_2_13_1  service_visit_def_1453  1
    service_2_13_1  free_load_conservation_1454  -4
    service_2_13_1  original_T_including_depot_unload_1471  480
    service_2_13_2  unique_nonzero_owner_327  1
    service_2_13_2  service_visit_def_1453  1
    service_2_13_2  free_load_conservation_1454  -3
    service_2_13_2  original_T_including_depot_unload_1471  360
    service_2_13_3  unique_nonzero_owner_328  1
    service_2_13_3  service_visit_def_1453  1
    service_2_13_3  free_load_conservation_1454  -2
    service_2_13_3  original_T_including_depot_unload_1471  240
    service_2_13_4  unique_nonzero_owner_329  1
    service_2_13_4  service_visit_def_1453  1
    service_2_13_4  free_load_conservation_1454  -1
    service_2_13_4  original_T_including_depot_unload_1471  120
    service_2_13_6  unique_nonzero_owner_330  1
    service_2_13_6  service_visit_def_1453  1
    service_2_13_6  free_load_conservation_1454  1
    service_2_13_7  unique_nonzero_owner_331  1
    service_2_13_7  service_visit_def_1453  1
    service_2_13_7  free_load_conservation_1454  2
    service_2_13_8  unique_nonzero_owner_332  1
    service_2_13_8  service_visit_def_1453  1
    service_2_13_8  free_load_conservation_1454  3
    service_0_27_1  unique_nonzero_owner_333  1
    service_0_27_1  service_visit_def_763  1
    service_0_27_1  free_load_conservation_764  1
    service_0_27_2  unique_nonzero_owner_334  1
    service_0_27_2  service_visit_def_763  1
    service_0_27_2  free_load_conservation_764  2
    service_0_27_3  unique_nonzero_owner_335  1
    service_0_27_3  service_visit_def_763  1
    service_0_27_3  free_load_conservation_764  3
    service_0_27_4  unique_nonzero_owner_336  1
    service_0_27_4  service_visit_def_763  1
    service_0_27_4  free_load_conservation_764  4
    service_0_27_5  unique_nonzero_owner_337  1
    service_0_27_5  service_visit_def_763  1
    service_0_27_5  free_load_conservation_764  5
    service_0_27_6  unique_nonzero_owner_338  1
    service_0_27_6  service_visit_def_763  1
    service_0_27_6  free_load_conservation_764  6
    service_1_27_1  unique_nonzero_owner_333  1
    service_1_27_1  service_visit_def_1033  1
    service_1_27_1  free_load_conservation_1034  1
    service_1_27_2  unique_nonzero_owner_334  1
    service_1_27_2  service_visit_def_1033  1
    service_1_27_2  free_load_conservation_1034  2
    service_1_27_3  unique_nonzero_owner_335  1
    service_1_27_3  service_visit_def_1033  1
    service_1_27_3  free_load_conservation_1034  3
    service_1_27_4  unique_nonzero_owner_336  1
    service_1_27_4  service_visit_def_1033  1
    service_1_27_4  free_load_conservation_1034  4
    service_1_27_5  unique_nonzero_owner_337  1
    service_1_27_5  service_visit_def_1033  1
    service_1_27_5  free_load_conservation_1034  5
    service_1_27_6  unique_nonzero_owner_338  1
    service_1_27_6  service_visit_def_1033  1
    service_1_27_6  free_load_conservation_1034  6
    service_2_27_1  unique_nonzero_owner_333  1
    service_2_27_1  service_visit_def_1459  1
    service_2_27_1  free_load_conservation_1460  1
    service_2_27_2  unique_nonzero_owner_334  1
    service_2_27_2  service_visit_def_1459  1
    service_2_27_2  free_load_conservation_1460  2
    service_2_27_3  unique_nonzero_owner_335  1
    service_2_27_3  service_visit_def_1459  1
    service_2_27_3  free_load_conservation_1460  3
    service_2_27_4  unique_nonzero_owner_336  1
    service_2_27_4  service_visit_def_1459  1
    service_2_27_4  free_load_conservation_1460  4
    service_2_27_5  unique_nonzero_owner_337  1
    service_2_27_5  service_visit_def_1459  1
    service_2_27_5  free_load_conservation_1460  5
    service_2_27_6  unique_nonzero_owner_338  1
    service_2_27_6  service_visit_def_1459  1
    service_2_27_6  free_load_conservation_1460  6
    service_0_15_0  unique_nonzero_owner_339  1
    service_0_15_0  service_visit_def_769  1
    service_0_15_0  free_load_conservation_770  -5
    service_0_15_0  original_T_including_depot_unload_775  600
    service_0_15_1  unique_nonzero_owner_340  1
    service_0_15_1  service_visit_def_769  1
    service_0_15_1  free_load_conservation_770  -4
    service_0_15_1  original_T_including_depot_unload_775  480
    service_0_15_2  unique_nonzero_owner_341  1
    service_0_15_2  service_visit_def_769  1
    service_0_15_2  free_load_conservation_770  -3
    service_0_15_2  original_T_including_depot_unload_775  360
    service_0_15_3  unique_nonzero_owner_342  1
    service_0_15_3  service_visit_def_769  1
    service_0_15_3  free_load_conservation_770  -2
    service_0_15_3  original_T_including_depot_unload_775  240
    service_0_15_4  unique_nonzero_owner_343  1
    service_0_15_4  service_visit_def_769  1
    service_0_15_4  free_load_conservation_770  -1
    service_0_15_4  original_T_including_depot_unload_775  120
    service_0_15_6  unique_nonzero_owner_344  1
    service_0_15_6  service_visit_def_769  1
    service_0_15_6  free_load_conservation_770  1
    service_0_15_7  unique_nonzero_owner_345  1
    service_0_15_7  service_visit_def_769  1
    service_0_15_7  free_load_conservation_770  2
    service_0_15_8  unique_nonzero_owner_346  1
    service_0_15_8  service_visit_def_769  1
    service_0_15_8  free_load_conservation_770  3
    service_1_15_0  unique_nonzero_owner_339  1
    service_1_15_0  service_visit_def_1039  1
    service_1_15_0  free_load_conservation_1040  -5
    service_1_15_0  original_T_including_depot_unload_1042  600
    service_1_15_1  unique_nonzero_owner_340  1
    service_1_15_1  service_visit_def_1039  1
    service_1_15_1  free_load_conservation_1040  -4
    service_1_15_1  original_T_including_depot_unload_1042  480
    service_1_15_2  unique_nonzero_owner_341  1
    service_1_15_2  service_visit_def_1039  1
    service_1_15_2  free_load_conservation_1040  -3
    service_1_15_2  original_T_including_depot_unload_1042  360
    service_1_15_3  unique_nonzero_owner_342  1
    service_1_15_3  service_visit_def_1039  1
    service_1_15_3  free_load_conservation_1040  -2
    service_1_15_3  original_T_including_depot_unload_1042  240
    service_1_15_4  unique_nonzero_owner_343  1
    service_1_15_4  service_visit_def_1039  1
    service_1_15_4  free_load_conservation_1040  -1
    service_1_15_4  original_T_including_depot_unload_1042  120
    service_1_15_6  unique_nonzero_owner_344  1
    service_1_15_6  service_visit_def_1039  1
    service_1_15_6  free_load_conservation_1040  1
    service_1_15_7  unique_nonzero_owner_345  1
    service_1_15_7  service_visit_def_1039  1
    service_1_15_7  free_load_conservation_1040  2
    service_1_15_8  unique_nonzero_owner_346  1
    service_1_15_8  service_visit_def_1039  1
    service_1_15_8  free_load_conservation_1040  3
    service_2_15_0  unique_nonzero_owner_339  1
    service_2_15_0  service_visit_def_1465  1
    service_2_15_0  free_load_conservation_1466  -5
    service_2_15_0  original_T_including_depot_unload_1471  600
    service_2_15_1  unique_nonzero_owner_340  1
    service_2_15_1  service_visit_def_1465  1
    service_2_15_1  free_load_conservation_1466  -4
    service_2_15_1  original_T_including_depot_unload_1471  480
    service_2_15_2  unique_nonzero_owner_341  1
    service_2_15_2  service_visit_def_1465  1
    service_2_15_2  free_load_conservation_1466  -3
    service_2_15_2  original_T_including_depot_unload_1471  360
    service_2_15_3  unique_nonzero_owner_342  1
    service_2_15_3  service_visit_def_1465  1
    service_2_15_3  free_load_conservation_1466  -2
    service_2_15_3  original_T_including_depot_unload_1471  240
    service_2_15_4  unique_nonzero_owner_343  1
    service_2_15_4  service_visit_def_1465  1
    service_2_15_4  free_load_conservation_1466  -1
    service_2_15_4  original_T_including_depot_unload_1471  120
    service_2_15_6  unique_nonzero_owner_344  1
    service_2_15_6  service_visit_def_1465  1
    service_2_15_6  free_load_conservation_1466  1
    service_2_15_7  unique_nonzero_owner_345  1
    service_2_15_7  service_visit_def_1465  1
    service_2_15_7  free_load_conservation_1466  2
    service_2_15_8  unique_nonzero_owner_346  1
    service_2_15_8  service_visit_def_1465  1
    service_2_15_8  free_load_conservation_1466  3
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_688  -1
    visit_0_1  in_degree_689  -1
    visit_0_1  order_active_lb_690  -1
    visit_0_1  order_active_ub_691  -13
    order_0_1  connected_order_arc_363  -1
    order_0_1  connected_order_arc_365  -1
    order_0_1  connected_order_arc_367  -1
    order_0_1  connected_order_arc_369  -1
    order_0_1  connected_order_arc_371  -1
    order_0_1  connected_order_arc_373  -1
    order_0_1  connected_order_arc_375  -1
    order_0_1  connected_order_arc_377  -1
    order_0_1  connected_order_arc_379  -1
    order_0_1  connected_order_arc_381  -1
    order_0_1  connected_order_arc_383  -1
    order_0_1  connected_order_arc_385  -1
    order_0_1  connected_order_arc_388  1
    order_0_1  connected_order_arc_413  1
    order_0_1  connected_order_arc_438  1
    order_0_1  connected_order_arc_463  1
    order_0_1  connected_order_arc_488  1
    order_0_1  connected_order_arc_513  1
    order_0_1  connected_order_arc_538  1
    order_0_1  connected_order_arc_563  1
    order_0_1  connected_order_arc_588  1
    order_0_1  connected_order_arc_613  1
    order_0_1  connected_order_arc_638  1
    order_0_1  connected_order_arc_663  1
    order_0_1  order_active_lb_690  1
    order_0_1  order_active_ub_691  1
    order_0_1  fixed_segment_relative_order_771  -1
    visit_0_2  out_degree_695  -1
    visit_0_2  in_degree_696  -1
    visit_0_2  order_active_lb_697  -1
    visit_0_2  order_active_ub_698  -13
    order_0_2  connected_order_arc_363  1
    order_0_2  connected_order_arc_388  -1
    order_0_2  connected_order_arc_390  -1
    order_0_2  connected_order_arc_392  -1
    order_0_2  connected_order_arc_394  -1
    order_0_2  connected_order_arc_396  -1
    order_0_2  connected_order_arc_398  -1
    order_0_2  connected_order_arc_400  -1
    order_0_2  connected_order_arc_402  -1
    order_0_2  connected_order_arc_404  -1
    order_0_2  connected_order_arc_406  -1
    order_0_2  connected_order_arc_408  -1
    order_0_2  connected_order_arc_410  -1
    order_0_2  connected_order_arc_415  1
    order_0_2  connected_order_arc_440  1
    order_0_2  connected_order_arc_465  1
    order_0_2  connected_order_arc_490  1
    order_0_2  connected_order_arc_515  1
    order_0_2  connected_order_arc_540  1
    order_0_2  connected_order_arc_565  1
    order_0_2  connected_order_arc_590  1
    order_0_2  connected_order_arc_615  1
    order_0_2  connected_order_arc_640  1
    order_0_2  connected_order_arc_665  1
    order_0_2  order_active_lb_697  1
    order_0_2  order_active_ub_698  1
    order_0_2  fixed_segment_relative_order_771  1
    order_0_2  fixed_segment_relative_order_772  -1
    visit_0_3  out_degree_702  -1
    visit_0_3  in_degree_703  -1
    visit_0_3  order_active_lb_704  -1
    visit_0_3  order_active_ub_705  -13
    order_0_3  connected_order_arc_365  1
    order_0_3  connected_order_arc_390  1
    order_0_3  connected_order_arc_413  -1
    order_0_3  connected_order_arc_415  -1
    order_0_3  connected_order_arc_417  -1
    order_0_3  connected_order_arc_419  -1
    order_0_3  connected_order_arc_421  -1
    order_0_3  connected_order_arc_423  -1
    order_0_3  connected_order_arc_425  -1
    order_0_3  connected_order_arc_427  -1
    order_0_3  connected_order_arc_429  -1
    order_0_3  connected_order_arc_431  -1
    order_0_3  connected_order_arc_433  -1
    order_0_3  connected_order_arc_435  -1
    order_0_3  connected_order_arc_442  1
    order_0_3  connected_order_arc_467  1
    order_0_3  connected_order_arc_492  1
    order_0_3  connected_order_arc_517  1
    order_0_3  connected_order_arc_542  1
    order_0_3  connected_order_arc_567  1
    order_0_3  connected_order_arc_592  1
    order_0_3  connected_order_arc_617  1
    order_0_3  connected_order_arc_642  1
    order_0_3  connected_order_arc_667  1
    order_0_3  order_active_lb_704  1
    order_0_3  order_active_ub_705  1
    order_0_3  fixed_segment_relative_order_772  1
    order_0_3  fixed_segment_relative_order_773  -1
    visit_0_4  out_degree_709  -1
    visit_0_4  in_degree_710  -1
    visit_0_4  order_active_lb_711  -1
    visit_0_4  order_active_ub_712  -13
    order_0_4  connected_order_arc_367  1
    order_0_4  connected_order_arc_392  1
    order_0_4  connected_order_arc_417  1
    order_0_4  connected_order_arc_438  -1
    order_0_4  connected_order_arc_440  -1
    order_0_4  connected_order_arc_442  -1
    order_0_4  connected_order_arc_444  -1
    order_0_4  connected_order_arc_446  -1
    order_0_4  connected_order_arc_448  -1
    order_0_4  connected_order_arc_450  -1
    order_0_4  connected_order_arc_452  -1
    order_0_4  connected_order_arc_454  -1
    order_0_4  connected_order_arc_456  -1
    order_0_4  connected_order_arc_458  -1
    order_0_4  connected_order_arc_460  -1
    order_0_4  connected_order_arc_469  1
    order_0_4  connected_order_arc_494  1
    order_0_4  connected_order_arc_519  1
    order_0_4  connected_order_arc_544  1
    order_0_4  connected_order_arc_569  1
    order_0_4  connected_order_arc_594  1
    order_0_4  connected_order_arc_619  1
    order_0_4  connected_order_arc_644  1
    order_0_4  connected_order_arc_669  1
    order_0_4  order_active_lb_711  1
    order_0_4  order_active_ub_712  1
    order_0_4  fixed_segment_relative_order_773  1
    order_0_4  fixed_segment_relative_order_774  -1
    visit_0_5  out_degree_716  -1
    visit_0_5  in_degree_717  -1
    visit_0_5  order_active_lb_718  -1
    visit_0_5  order_active_ub_719  -13
    order_0_5  connected_order_arc_369  1
    order_0_5  connected_order_arc_394  1
    order_0_5  connected_order_arc_419  1
    order_0_5  connected_order_arc_444  1
    order_0_5  connected_order_arc_463  -1
    order_0_5  connected_order_arc_465  -1
    order_0_5  connected_order_arc_467  -1
    order_0_5  connected_order_arc_469  -1
    order_0_5  connected_order_arc_471  -1
    order_0_5  connected_order_arc_473  -1
    order_0_5  connected_order_arc_475  -1
    order_0_5  connected_order_arc_477  -1
    order_0_5  connected_order_arc_479  -1
    order_0_5  connected_order_arc_481  -1
    order_0_5  connected_order_arc_483  -1
    order_0_5  connected_order_arc_485  -1
    order_0_5  connected_order_arc_496  1
    order_0_5  connected_order_arc_521  1
    order_0_5  connected_order_arc_546  1
    order_0_5  connected_order_arc_571  1
    order_0_5  connected_order_arc_596  1
    order_0_5  connected_order_arc_621  1
    order_0_5  connected_order_arc_646  1
    order_0_5  connected_order_arc_671  1
    order_0_5  order_active_lb_718  1
    order_0_5  order_active_ub_719  1
    order_0_5  fixed_segment_relative_order_774  1
    visit_0_13  out_degree_723  -1
    visit_0_13  in_degree_724  -1
    visit_0_13  order_active_lb_725  -1
    visit_0_13  order_active_ub_726  -13
    visit_0_13  service_visit_def_727  -1
    order_0_13  connected_order_arc_371  1
    order_0_13  connected_order_arc_396  1
    order_0_13  connected_order_arc_421  1
    order_0_13  connected_order_arc_446  1
    order_0_13  connected_order_arc_471  1
    order_0_13  connected_order_arc_488  -1
    order_0_13  connected_order_arc_490  -1
    order_0_13  connected_order_arc_492  -1
    order_0_13  connected_order_arc_494  -1
    order_0_13  connected_order_arc_496  -1
    order_0_13  connected_order_arc_498  -1
    order_0_13  connected_order_arc_500  -1
    order_0_13  connected_order_arc_502  -1
    order_0_13  connected_order_arc_504  -1
    order_0_13  connected_order_arc_506  -1
    order_0_13  connected_order_arc_508  -1
    order_0_13  connected_order_arc_510  -1
    order_0_13  connected_order_arc_523  1
    order_0_13  connected_order_arc_548  1
    order_0_13  connected_order_arc_573  1
    order_0_13  connected_order_arc_598  1
    order_0_13  connected_order_arc_623  1
    order_0_13  connected_order_arc_648  1
    order_0_13  connected_order_arc_673  1
    order_0_13  order_active_lb_725  1
    order_0_13  order_active_ub_726  1
    visit_0_14  out_degree_729  -1
    visit_0_14  in_degree_730  -1
    visit_0_14  order_active_lb_731  -1
    visit_0_14  order_active_ub_732  -13
    visit_0_14  service_visit_def_733  -1
    order_0_14  connected_order_arc_373  1
    order_0_14  connected_order_arc_398  1
    order_0_14  connected_order_arc_423  1
    order_0_14  connected_order_arc_448  1
    order_0_14  connected_order_arc_473  1
    order_0_14  connected_order_arc_498  1
    order_0_14  connected_order_arc_513  -1
    order_0_14  connected_order_arc_515  -1
    order_0_14  connected_order_arc_517  -1
    order_0_14  connected_order_arc_519  -1
    order_0_14  connected_order_arc_521  -1
    order_0_14  connected_order_arc_523  -1
    order_0_14  connected_order_arc_525  -1
    order_0_14  connected_order_arc_527  -1
    order_0_14  connected_order_arc_529  -1
    order_0_14  connected_order_arc_531  -1
    order_0_14  connected_order_arc_533  -1
    order_0_14  connected_order_arc_535  -1
    order_0_14  connected_order_arc_550  1
    order_0_14  connected_order_arc_575  1
    order_0_14  connected_order_arc_600  1
    order_0_14  connected_order_arc_625  1
    order_0_14  connected_order_arc_650  1
    order_0_14  connected_order_arc_675  1
    order_0_14  order_active_lb_731  1
    order_0_14  order_active_ub_732  1
    visit_0_15  out_degree_735  -1
    visit_0_15  in_degree_736  -1
    visit_0_15  order_active_lb_737  -1
    visit_0_15  order_active_ub_738  -13
    visit_0_15  service_visit_def_739  -1
    order_0_15  connected_order_arc_375  1
    order_0_15  connected_order_arc_400  1
    order_0_15  connected_order_arc_425  1
    order_0_15  connected_order_arc_450  1
    order_0_15  connected_order_arc_475  1
    order_0_15  connected_order_arc_500  1
    order_0_15  connected_order_arc_525  1
    order_0_15  connected_order_arc_538  -1
    order_0_15  connected_order_arc_540  -1
    order_0_15  connected_order_arc_542  -1
    order_0_15  connected_order_arc_544  -1
    order_0_15  connected_order_arc_546  -1
    order_0_15  connected_order_arc_548  -1
    order_0_15  connected_order_arc_550  -1
    order_0_15  connected_order_arc_552  -1
    order_0_15  connected_order_arc_554  -1
    order_0_15  connected_order_arc_556  -1
    order_0_15  connected_order_arc_558  -1
    order_0_15  connected_order_arc_560  -1
    order_0_15  connected_order_arc_577  1
    order_0_15  connected_order_arc_602  1
    order_0_15  connected_order_arc_627  1
    order_0_15  connected_order_arc_652  1
    order_0_15  connected_order_arc_677  1
    order_0_15  order_active_lb_737  1
    order_0_15  order_active_ub_738  1
    visit_0_16  out_degree_741  -1
    visit_0_16  in_degree_742  -1
    visit_0_16  order_active_lb_743  -1
    visit_0_16  order_active_ub_744  -13
    visit_0_16  service_visit_def_745  -1
    order_0_16  connected_order_arc_377  1
    order_0_16  connected_order_arc_402  1
    order_0_16  connected_order_arc_427  1
    order_0_16  connected_order_arc_452  1
    order_0_16  connected_order_arc_477  1
    order_0_16  connected_order_arc_502  1
    order_0_16  connected_order_arc_527  1
    order_0_16  connected_order_arc_552  1
    order_0_16  connected_order_arc_563  -1
    order_0_16  connected_order_arc_565  -1
    order_0_16  connected_order_arc_567  -1
    order_0_16  connected_order_arc_569  -1
    order_0_16  connected_order_arc_571  -1
    order_0_16  connected_order_arc_573  -1
    order_0_16  connected_order_arc_575  -1
    order_0_16  connected_order_arc_577  -1
    order_0_16  connected_order_arc_579  -1
    order_0_16  connected_order_arc_581  -1
    order_0_16  connected_order_arc_583  -1
    order_0_16  connected_order_arc_585  -1
    order_0_16  connected_order_arc_604  1
    order_0_16  connected_order_arc_629  1
    order_0_16  connected_order_arc_654  1
    order_0_16  connected_order_arc_679  1
    order_0_16  order_active_lb_743  1
    order_0_16  order_active_ub_744  1
    visit_0_17  out_degree_747  -1
    visit_0_17  in_degree_748  -1
    visit_0_17  order_active_lb_749  -1
    visit_0_17  order_active_ub_750  -13
    visit_0_17  service_visit_def_751  -1
    order_0_17  connected_order_arc_379  1
    order_0_17  connected_order_arc_404  1
    order_0_17  connected_order_arc_429  1
    order_0_17  connected_order_arc_454  1
    order_0_17  connected_order_arc_479  1
    order_0_17  connected_order_arc_504  1
    order_0_17  connected_order_arc_529  1
    order_0_17  connected_order_arc_554  1
    order_0_17  connected_order_arc_579  1
    order_0_17  connected_order_arc_588  -1
    order_0_17  connected_order_arc_590  -1
    order_0_17  connected_order_arc_592  -1
    order_0_17  connected_order_arc_594  -1
    order_0_17  connected_order_arc_596  -1
    order_0_17  connected_order_arc_598  -1
    order_0_17  connected_order_arc_600  -1
    order_0_17  connected_order_arc_602  -1
    order_0_17  connected_order_arc_604  -1
    order_0_17  connected_order_arc_606  -1
    order_0_17  connected_order_arc_608  -1
    order_0_17  connected_order_arc_610  -1
    order_0_17  connected_order_arc_631  1
    order_0_17  connected_order_arc_656  1
    order_0_17  connected_order_arc_681  1
    order_0_17  order_active_lb_749  1
    order_0_17  order_active_ub_750  1
    visit_0_18  out_degree_753  -1
    visit_0_18  in_degree_754  -1
    visit_0_18  order_active_lb_755  -1
    visit_0_18  order_active_ub_756  -13
    visit_0_18  service_visit_def_757  -1
    order_0_18  connected_order_arc_381  1
    order_0_18  connected_order_arc_406  1
    order_0_18  connected_order_arc_431  1
    order_0_18  connected_order_arc_456  1
    order_0_18  connected_order_arc_481  1
    order_0_18  connected_order_arc_506  1
    order_0_18  connected_order_arc_531  1
    order_0_18  connected_order_arc_556  1
    order_0_18  connected_order_arc_581  1
    order_0_18  connected_order_arc_606  1
    order_0_18  connected_order_arc_613  -1
    order_0_18  connected_order_arc_615  -1
    order_0_18  connected_order_arc_617  -1
    order_0_18  connected_order_arc_619  -1
    order_0_18  connected_order_arc_621  -1
    order_0_18  connected_order_arc_623  -1
    order_0_18  connected_order_arc_625  -1
    order_0_18  connected_order_arc_627  -1
    order_0_18  connected_order_arc_629  -1
    order_0_18  connected_order_arc_631  -1
    order_0_18  connected_order_arc_633  -1
    order_0_18  connected_order_arc_635  -1
    order_0_18  connected_order_arc_658  1
    order_0_18  connected_order_arc_683  1
    order_0_18  order_active_lb_755  1
    order_0_18  order_active_ub_756  1
    visit_0_19  out_degree_759  -1
    visit_0_19  in_degree_760  -1
    visit_0_19  order_active_lb_761  -1
    visit_0_19  order_active_ub_762  -13
    visit_0_19  service_visit_def_763  -1
    order_0_19  connected_order_arc_383  1
    order_0_19  connected_order_arc_408  1
    order_0_19  connected_order_arc_433  1
    order_0_19  connected_order_arc_458  1
    order_0_19  connected_order_arc_483  1
    order_0_19  connected_order_arc_508  1
    order_0_19  connected_order_arc_533  1
    order_0_19  connected_order_arc_558  1
    order_0_19  connected_order_arc_583  1
    order_0_19  connected_order_arc_608  1
    order_0_19  connected_order_arc_633  1
    order_0_19  connected_order_arc_638  -1
    order_0_19  connected_order_arc_640  -1
    order_0_19  connected_order_arc_642  -1
    order_0_19  connected_order_arc_644  -1
    order_0_19  connected_order_arc_646  -1
    order_0_19  connected_order_arc_648  -1
    order_0_19  connected_order_arc_650  -1
    order_0_19  connected_order_arc_652  -1
    order_0_19  connected_order_arc_654  -1
    order_0_19  connected_order_arc_656  -1
    order_0_19  connected_order_arc_658  -1
    order_0_19  connected_order_arc_660  -1
    order_0_19  connected_order_arc_685  1
    order_0_19  order_active_lb_761  1
    order_0_19  order_active_ub_762  1
    visit_0_20  out_degree_765  -1
    visit_0_20  in_degree_766  -1
    visit_0_20  order_active_lb_767  -1
    visit_0_20  order_active_ub_768  -13
    visit_0_20  service_visit_def_769  -1
    order_0_20  connected_order_arc_385  1
    order_0_20  connected_order_arc_410  1
    order_0_20  connected_order_arc_435  1
    order_0_20  connected_order_arc_460  1
    order_0_20  connected_order_arc_485  1
    order_0_20  connected_order_arc_510  1
    order_0_20  connected_order_arc_535  1
    order_0_20  connected_order_arc_560  1
    order_0_20  connected_order_arc_585  1
    order_0_20  connected_order_arc_610  1
    order_0_20  connected_order_arc_635  1
    order_0_20  connected_order_arc_660  1
    order_0_20  connected_order_arc_663  -1
    order_0_20  connected_order_arc_665  -1
    order_0_20  connected_order_arc_667  -1
    order_0_20  connected_order_arc_669  -1
    order_0_20  connected_order_arc_671  -1
    order_0_20  connected_order_arc_673  -1
    order_0_20  connected_order_arc_675  -1
    order_0_20  connected_order_arc_677  -1
    order_0_20  connected_order_arc_679  -1
    order_0_20  connected_order_arc_681  -1
    order_0_20  connected_order_arc_683  -1
    order_0_20  connected_order_arc_685  -1
    order_0_20  order_active_lb_767  1
    order_0_20  order_active_ub_768  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_347  -20
    arc_0_0_0  depot_departure_or_bypass_686  1
    arc_0_0_0  depot_return_or_bypass_687  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_347  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_348  -20
    arc_0_0_1  depot_departure_or_bypass_686  1
    arc_0_0_1  in_degree_689  1
    arc_0_0_1  original_T_including_depot_unload_775  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_348  1
    load_0_0_1  segment_load_conservation_692  -1
    load_0_0_1  segment_prefix_lb_693  1
    load_0_0_1  segment_prefix_ub_694  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_349  -20
    arc_0_0_2  depot_departure_or_bypass_686  1
    arc_0_0_2  in_degree_696  1
    arc_0_0_2  original_T_including_depot_unload_775  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_349  1
    load_0_0_2  segment_load_conservation_699  -1
    load_0_0_2  segment_prefix_lb_700  1
    load_0_0_2  segment_prefix_ub_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_350  -20
    arc_0_0_3  depot_departure_or_bypass_686  1
    arc_0_0_3  in_degree_703  1
    arc_0_0_3  original_T_including_depot_unload_775  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_350  1
    load_0_0_3  segment_load_conservation_706  -1
    load_0_0_3  segment_prefix_lb_707  1
    load_0_0_3  segment_prefix_ub_708  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_351  -20
    arc_0_0_4  depot_departure_or_bypass_686  1
    arc_0_0_4  in_degree_710  1
    arc_0_0_4  original_T_including_depot_unload_775  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_351  1
    load_0_0_4  segment_load_conservation_713  -1
    load_0_0_4  segment_prefix_lb_714  1
    load_0_0_4  segment_prefix_ub_715  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_352  -20
    arc_0_0_5  depot_departure_or_bypass_686  1
    arc_0_0_5  in_degree_717  1
    arc_0_0_5  original_T_including_depot_unload_775  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_352  1
    load_0_0_5  segment_load_conservation_720  -1
    load_0_0_5  segment_prefix_lb_721  1
    load_0_0_5  segment_prefix_ub_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_353  -20
    arc_0_0_13  depot_departure_or_bypass_686  1
    arc_0_0_13  in_degree_724  1
    arc_0_0_13  original_T_including_depot_unload_775  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_353  1
    load_0_0_13  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_354  -20
    arc_0_0_14  depot_departure_or_bypass_686  1
    arc_0_0_14  in_degree_730  1
    arc_0_0_14  original_T_including_depot_unload_775  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_354  1
    load_0_0_14  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_355  -20
    arc_0_0_15  depot_departure_or_bypass_686  1
    arc_0_0_15  in_degree_736  1
    arc_0_0_15  original_T_including_depot_unload_775  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_355  1
    load_0_0_15  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_356  -20
    arc_0_0_16  depot_departure_or_bypass_686  1
    arc_0_0_16  in_degree_742  1
    arc_0_0_16  original_T_including_depot_unload_775  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_356  1
    load_0_0_16  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_357  -20
    arc_0_0_17  depot_departure_or_bypass_686  1
    arc_0_0_17  in_degree_748  1
    arc_0_0_17  original_T_including_depot_unload_775  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_357  1
    load_0_0_17  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_358  -20
    arc_0_0_18  depot_departure_or_bypass_686  1
    arc_0_0_18  in_degree_754  1
    arc_0_0_18  original_T_including_depot_unload_775  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_358  1
    load_0_0_18  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_359  -20
    arc_0_0_19  depot_departure_or_bypass_686  1
    arc_0_0_19  in_degree_760  1
    arc_0_0_19  original_T_including_depot_unload_775  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_359  1
    load_0_0_19  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_360  -20
    arc_0_0_20  depot_departure_or_bypass_686  1
    arc_0_0_20  in_degree_766  1
    arc_0_0_20  original_T_including_depot_unload_775  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_360  1
    load_0_0_20  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_361  -20
    arc_0_1_0  depot_return_or_bypass_687  1
    arc_0_1_0  out_degree_688  1
    arc_0_1_0  original_T_including_depot_unload_775  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_361  1
    load_0_1_0  segment_load_conservation_692  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_362  -20
    arc_0_1_2  connected_order_arc_363  -14
    arc_0_1_2  out_degree_688  1
    arc_0_1_2  in_degree_696  1
    arc_0_1_2  original_T_including_depot_unload_775  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_362  1
    load_0_1_2  segment_load_conservation_692  1
    load_0_1_2  segment_load_conservation_699  -1
    load_0_1_2  segment_prefix_lb_700  1
    load_0_1_2  segment_prefix_ub_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_364  -20
    arc_0_1_3  connected_order_arc_365  -14
    arc_0_1_3  out_degree_688  1
    arc_0_1_3  in_degree_703  1
    arc_0_1_3  original_T_including_depot_unload_775  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_364  1
    load_0_1_3  segment_load_conservation_692  1
    load_0_1_3  segment_load_conservation_706  -1
    load_0_1_3  segment_prefix_lb_707  1
    load_0_1_3  segment_prefix_ub_708  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_366  -20
    arc_0_1_4  connected_order_arc_367  -14
    arc_0_1_4  out_degree_688  1
    arc_0_1_4  in_degree_710  1
    arc_0_1_4  original_T_including_depot_unload_775  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_366  1
    load_0_1_4  segment_load_conservation_692  1
    load_0_1_4  segment_load_conservation_713  -1
    load_0_1_4  segment_prefix_lb_714  1
    load_0_1_4  segment_prefix_ub_715  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_368  -20
    arc_0_1_5  connected_order_arc_369  -14
    arc_0_1_5  out_degree_688  1
    arc_0_1_5  in_degree_717  1
    arc_0_1_5  original_T_including_depot_unload_775  4.8384395388802926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_368  1
    load_0_1_5  segment_load_conservation_692  1
    load_0_1_5  segment_load_conservation_720  -1
    load_0_1_5  segment_prefix_lb_721  1
    load_0_1_5  segment_prefix_ub_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_370  -20
    arc_0_1_13  connected_order_arc_371  -14
    arc_0_1_13  out_degree_688  1
    arc_0_1_13  in_degree_724  1
    arc_0_1_13  original_T_including_depot_unload_775  6.0082621405522366e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_370  1
    load_0_1_13  segment_load_conservation_692  1
    load_0_1_13  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_372  -20
    arc_0_1_14  connected_order_arc_373  -14
    arc_0_1_14  out_degree_688  1
    arc_0_1_14  in_degree_730  1
    arc_0_1_14  original_T_including_depot_unload_775  3.8231967210987659e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_372  1
    load_0_1_14  segment_load_conservation_692  1
    load_0_1_14  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_374  -20
    arc_0_1_15  connected_order_arc_375  -14
    arc_0_1_15  out_degree_688  1
    arc_0_1_15  in_degree_736  1
    arc_0_1_15  original_T_including_depot_unload_775  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_374  1
    load_0_1_15  segment_load_conservation_692  1
    load_0_1_15  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_376  -20
    arc_0_1_16  connected_order_arc_377  -14
    arc_0_1_16  out_degree_688  1
    arc_0_1_16  in_degree_742  1
    arc_0_1_16  original_T_including_depot_unload_775  6.7008394119213415e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_376  1
    load_0_1_16  segment_load_conservation_692  1
    load_0_1_16  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_378  -20
    arc_0_1_17  connected_order_arc_379  -14
    arc_0_1_17  out_degree_688  1
    arc_0_1_17  in_degree_748  1
    arc_0_1_17  original_T_including_depot_unload_775  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_378  1
    load_0_1_17  segment_load_conservation_692  1
    load_0_1_17  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_380  -20
    arc_0_1_18  connected_order_arc_381  -14
    arc_0_1_18  out_degree_688  1
    arc_0_1_18  in_degree_754  1
    arc_0_1_18  original_T_including_depot_unload_775  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_380  1
    load_0_1_18  segment_load_conservation_692  1
    load_0_1_18  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_382  -20
    arc_0_1_19  connected_order_arc_383  -14
    arc_0_1_19  out_degree_688  1
    arc_0_1_19  in_degree_760  1
    arc_0_1_19  original_T_including_depot_unload_775  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_382  1
    load_0_1_19  segment_load_conservation_692  1
    load_0_1_19  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_384  -20
    arc_0_1_20  connected_order_arc_385  -14
    arc_0_1_20  out_degree_688  1
    arc_0_1_20  in_degree_766  1
    arc_0_1_20  original_T_including_depot_unload_775  2.8856753867620006e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_384  1
    load_0_1_20  segment_load_conservation_692  1
    load_0_1_20  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_386  -20
    arc_0_2_0  depot_return_or_bypass_687  1
    arc_0_2_0  out_degree_695  1
    arc_0_2_0  original_T_including_depot_unload_775  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_386  1
    load_0_2_0  segment_load_conservation_699  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_387  -20
    arc_0_2_1  connected_order_arc_388  -14
    arc_0_2_1  in_degree_689  1
    arc_0_2_1  out_degree_695  1
    arc_0_2_1  original_T_including_depot_unload_775  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_387  1
    load_0_2_1  segment_load_conservation_692  -1
    load_0_2_1  segment_prefix_lb_693  1
    load_0_2_1  segment_prefix_ub_694  1
    load_0_2_1  segment_load_conservation_699  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_389  -20
    arc_0_2_3  connected_order_arc_390  -14
    arc_0_2_3  out_degree_695  1
    arc_0_2_3  in_degree_703  1
    arc_0_2_3  original_T_including_depot_unload_775  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_389  1
    load_0_2_3  segment_load_conservation_699  1
    load_0_2_3  segment_load_conservation_706  -1
    load_0_2_3  segment_prefix_lb_707  1
    load_0_2_3  segment_prefix_ub_708  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_391  -20
    arc_0_2_4  connected_order_arc_392  -14
    arc_0_2_4  out_degree_695  1
    arc_0_2_4  in_degree_710  1
    arc_0_2_4  original_T_including_depot_unload_775  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_391  1
    load_0_2_4  segment_load_conservation_699  1
    load_0_2_4  segment_load_conservation_713  -1
    load_0_2_4  segment_prefix_lb_714  1
    load_0_2_4  segment_prefix_ub_715  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_393  -20
    arc_0_2_5  connected_order_arc_394  -14
    arc_0_2_5  out_degree_695  1
    arc_0_2_5  in_degree_717  1
    arc_0_2_5  original_T_including_depot_unload_775  4.9345054001313224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_393  1
    load_0_2_5  segment_load_conservation_699  1
    load_0_2_5  segment_load_conservation_720  -1
    load_0_2_5  segment_prefix_lb_721  1
    load_0_2_5  segment_prefix_ub_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_395  -20
    arc_0_2_13  connected_order_arc_396  -14
    arc_0_2_13  out_degree_695  1
    arc_0_2_13  in_degree_724  1
    arc_0_2_13  original_T_including_depot_unload_775  5.7164184935040350e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_395  1
    load_0_2_13  segment_load_conservation_699  1
    load_0_2_13  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_397  -20
    arc_0_2_14  connected_order_arc_398  -14
    arc_0_2_14  out_degree_695  1
    arc_0_2_14  in_degree_730  1
    arc_0_2_14  original_T_including_depot_unload_775  3.4724611547105854e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_397  1
    load_0_2_14  segment_load_conservation_699  1
    load_0_2_14  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_399  -20
    arc_0_2_15  connected_order_arc_400  -14
    arc_0_2_15  out_degree_695  1
    arc_0_2_15  in_degree_736  1
    arc_0_2_15  original_T_including_depot_unload_775  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_399  1
    load_0_2_15  segment_load_conservation_699  1
    load_0_2_15  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_401  -20
    arc_0_2_16  connected_order_arc_402  -14
    arc_0_2_16  out_degree_695  1
    arc_0_2_16  in_degree_742  1
    arc_0_2_16  original_T_including_depot_unload_775  634.658635437287
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_401  1
    load_0_2_16  segment_load_conservation_699  1
    load_0_2_16  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_403  -20
    arc_0_2_17  connected_order_arc_404  -14
    arc_0_2_17  out_degree_695  1
    arc_0_2_17  in_degree_748  1
    arc_0_2_17  original_T_including_depot_unload_775  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_403  1
    load_0_2_17  segment_load_conservation_699  1
    load_0_2_17  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_405  -20
    arc_0_2_18  connected_order_arc_406  -14
    arc_0_2_18  out_degree_695  1
    arc_0_2_18  in_degree_754  1
    arc_0_2_18  original_T_including_depot_unload_775  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_405  1
    load_0_2_18  segment_load_conservation_699  1
    load_0_2_18  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_407  -20
    arc_0_2_19  connected_order_arc_408  -14
    arc_0_2_19  out_degree_695  1
    arc_0_2_19  in_degree_760  1
    arc_0_2_19  original_T_including_depot_unload_775  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_407  1
    load_0_2_19  segment_load_conservation_699  1
    load_0_2_19  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_409  -20
    arc_0_2_20  connected_order_arc_410  -14
    arc_0_2_20  out_degree_695  1
    arc_0_2_20  in_degree_766  1
    arc_0_2_20  original_T_including_depot_unload_775  2.9672747884555446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_409  1
    load_0_2_20  segment_load_conservation_699  1
    load_0_2_20  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_411  -20
    arc_0_3_0  depot_return_or_bypass_687  1
    arc_0_3_0  out_degree_702  1
    arc_0_3_0  original_T_including_depot_unload_775  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_411  1
    load_0_3_0  segment_load_conservation_706  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_412  -20
    arc_0_3_1  connected_order_arc_413  -14
    arc_0_3_1  in_degree_689  1
    arc_0_3_1  out_degree_702  1
    arc_0_3_1  original_T_including_depot_unload_775  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_412  1
    load_0_3_1  segment_load_conservation_692  -1
    load_0_3_1  segment_prefix_lb_693  1
    load_0_3_1  segment_prefix_ub_694  1
    load_0_3_1  segment_load_conservation_706  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_414  -20
    arc_0_3_2  connected_order_arc_415  -14
    arc_0_3_2  in_degree_696  1
    arc_0_3_2  out_degree_702  1
    arc_0_3_2  original_T_including_depot_unload_775  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_414  1
    load_0_3_2  segment_load_conservation_699  -1
    load_0_3_2  segment_prefix_lb_700  1
    load_0_3_2  segment_prefix_ub_701  1
    load_0_3_2  segment_load_conservation_706  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_416  -20
    arc_0_3_4  connected_order_arc_417  -14
    arc_0_3_4  out_degree_702  1
    arc_0_3_4  in_degree_710  1
    arc_0_3_4  original_T_including_depot_unload_775  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_416  1
    load_0_3_4  segment_load_conservation_706  1
    load_0_3_4  segment_load_conservation_713  -1
    load_0_3_4  segment_prefix_lb_714  1
    load_0_3_4  segment_prefix_ub_715  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_418  -20
    arc_0_3_5  connected_order_arc_419  -14
    arc_0_3_5  out_degree_702  1
    arc_0_3_5  in_degree_717  1
    arc_0_3_5  original_T_including_depot_unload_775  4.9283602644772810e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_418  1
    load_0_3_5  segment_load_conservation_706  1
    load_0_3_5  segment_load_conservation_720  -1
    load_0_3_5  segment_prefix_lb_721  1
    load_0_3_5  segment_prefix_ub_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_420  -20
    arc_0_3_13  connected_order_arc_421  -14
    arc_0_3_13  out_degree_702  1
    arc_0_3_13  in_degree_724  1
    arc_0_3_13  original_T_including_depot_unload_775  5.7138137092491206e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_420  1
    load_0_3_13  segment_load_conservation_706  1
    load_0_3_13  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_422  -20
    arc_0_3_14  connected_order_arc_423  -14
    arc_0_3_14  out_degree_702  1
    arc_0_3_14  in_degree_730  1
    arc_0_3_14  original_T_including_depot_unload_775  3.4726967782722494e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_422  1
    load_0_3_14  segment_load_conservation_706  1
    load_0_3_14  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_424  -20
    arc_0_3_15  connected_order_arc_425  -14
    arc_0_3_15  out_degree_702  1
    arc_0_3_15  in_degree_736  1
    arc_0_3_15  original_T_including_depot_unload_775  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_424  1
    load_0_3_15  segment_load_conservation_706  1
    load_0_3_15  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_426  -20
    arc_0_3_16  connected_order_arc_427  -14
    arc_0_3_16  out_degree_702  1
    arc_0_3_16  in_degree_742  1
    arc_0_3_16  original_T_including_depot_unload_775  634.778043158074
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_426  1
    load_0_3_16  segment_load_conservation_706  1
    load_0_3_16  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_428  -20
    arc_0_3_17  connected_order_arc_429  -14
    arc_0_3_17  out_degree_702  1
    arc_0_3_17  in_degree_748  1
    arc_0_3_17  original_T_including_depot_unload_775  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_428  1
    load_0_3_17  segment_load_conservation_706  1
    load_0_3_17  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_430  -20
    arc_0_3_18  connected_order_arc_431  -14
    arc_0_3_18  out_degree_702  1
    arc_0_3_18  in_degree_754  1
    arc_0_3_18  original_T_including_depot_unload_775  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_430  1
    load_0_3_18  segment_load_conservation_706  1
    load_0_3_18  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_432  -20
    arc_0_3_19  connected_order_arc_433  -14
    arc_0_3_19  out_degree_702  1
    arc_0_3_19  in_degree_760  1
    arc_0_3_19  original_T_including_depot_unload_775  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_432  1
    load_0_3_19  segment_load_conservation_706  1
    load_0_3_19  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_434  -20
    arc_0_3_20  connected_order_arc_435  -14
    arc_0_3_20  out_degree_702  1
    arc_0_3_20  in_degree_766  1
    arc_0_3_20  original_T_including_depot_unload_775  2.9611166330127878e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_434  1
    load_0_3_20  segment_load_conservation_706  1
    load_0_3_20  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_436  -20
    arc_0_4_0  depot_return_or_bypass_687  1
    arc_0_4_0  out_degree_709  1
    arc_0_4_0  original_T_including_depot_unload_775  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_436  1
    load_0_4_0  segment_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_437  -20
    arc_0_4_1  connected_order_arc_438  -14
    arc_0_4_1  in_degree_689  1
    arc_0_4_1  out_degree_709  1
    arc_0_4_1  original_T_including_depot_unload_775  4.5635886855303721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_437  1
    load_0_4_1  segment_load_conservation_692  -1
    load_0_4_1  segment_prefix_lb_693  1
    load_0_4_1  segment_prefix_ub_694  1
    load_0_4_1  segment_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_439  -20
    arc_0_4_2  connected_order_arc_440  -14
    arc_0_4_2  in_degree_696  1
    arc_0_4_2  out_degree_709  1
    arc_0_4_2  original_T_including_depot_unload_775  4.3076139952356033e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_439  1
    load_0_4_2  segment_load_conservation_699  -1
    load_0_4_2  segment_prefix_lb_700  1
    load_0_4_2  segment_prefix_ub_701  1
    load_0_4_2  segment_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_441  -20
    arc_0_4_3  connected_order_arc_442  -14
    arc_0_4_3  in_degree_703  1
    arc_0_4_3  out_degree_709  1
    arc_0_4_3  original_T_including_depot_unload_775  4.3127471875854752e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_441  1
    load_0_4_3  segment_load_conservation_706  -1
    load_0_4_3  segment_prefix_lb_707  1
    load_0_4_3  segment_prefix_ub_708  1
    load_0_4_3  segment_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_443  -20
    arc_0_4_5  connected_order_arc_444  -14
    arc_0_4_5  out_degree_709  1
    arc_0_4_5  in_degree_717  1
    arc_0_4_5  original_T_including_depot_unload_775  8.9891387855174980e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_443  1
    load_0_4_5  segment_load_conservation_713  1
    load_0_4_5  segment_load_conservation_720  -1
    load_0_4_5  segment_prefix_lb_721  1
    load_0_4_5  segment_prefix_ub_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_445  -20
    arc_0_4_13  connected_order_arc_446  -14
    arc_0_4_13  out_degree_709  1
    arc_0_4_13  in_degree_724  1
    arc_0_4_13  original_T_including_depot_unload_775  6.5890455469873450e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_445  1
    load_0_4_13  segment_load_conservation_713  1
    load_0_4_13  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_447  -20
    arc_0_4_14  connected_order_arc_448  -14
    arc_0_4_14  out_degree_709  1
    arc_0_4_14  in_degree_730  1
    arc_0_4_14  original_T_including_depot_unload_775  3.5999470473353784e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_447  1
    load_0_4_14  segment_load_conservation_713  1
    load_0_4_14  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_449  -20
    arc_0_4_15  connected_order_arc_450  -14
    arc_0_4_15  out_degree_709  1
    arc_0_4_15  in_degree_736  1
    arc_0_4_15  original_T_including_depot_unload_775  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_449  1
    load_0_4_15  segment_load_conservation_713  1
    load_0_4_15  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_451  -20
    arc_0_4_16  connected_order_arc_452  -14
    arc_0_4_16  out_degree_709  1
    arc_0_4_16  in_degree_742  1
    arc_0_4_16  original_T_including_depot_unload_775  4.4818846006897064e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_451  1
    load_0_4_16  segment_load_conservation_713  1
    load_0_4_16  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_453  -20
    arc_0_4_17  connected_order_arc_454  -14
    arc_0_4_17  out_degree_709  1
    arc_0_4_17  in_degree_748  1
    arc_0_4_17  original_T_including_depot_unload_775  1.8150519376858174e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_453  1
    load_0_4_17  segment_load_conservation_713  1
    load_0_4_17  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_455  -20
    arc_0_4_18  connected_order_arc_456  -14
    arc_0_4_18  out_degree_709  1
    arc_0_4_18  in_degree_754  1
    arc_0_4_18  original_T_including_depot_unload_775  5.4635723875297333e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_455  1
    load_0_4_18  segment_load_conservation_713  1
    load_0_4_18  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_457  -20
    arc_0_4_19  connected_order_arc_458  -14
    arc_0_4_19  out_degree_709  1
    arc_0_4_19  in_degree_760  1
    arc_0_4_19  original_T_including_depot_unload_775  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_457  1
    load_0_4_19  segment_load_conservation_713  1
    load_0_4_19  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_459  -20
    arc_0_4_20  connected_order_arc_460  -14
    arc_0_4_20  out_degree_709  1
    arc_0_4_20  in_degree_766  1
    arc_0_4_20  original_T_including_depot_unload_775  7.0663858580683063e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_459  1
    load_0_4_20  segment_load_conservation_713  1
    load_0_4_20  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_461  -20
    arc_0_5_0  depot_return_or_bypass_687  1
    arc_0_5_0  out_degree_716  1
    arc_0_5_0  original_T_including_depot_unload_775  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_461  1
    load_0_5_0  segment_load_conservation_720  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_462  -20
    arc_0_5_1  connected_order_arc_463  -14
    arc_0_5_1  in_degree_689  1
    arc_0_5_1  out_degree_716  1
    arc_0_5_1  original_T_including_depot_unload_775  7.7242003812192672e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_462  1
    load_0_5_1  segment_load_conservation_692  -1
    load_0_5_1  segment_prefix_lb_693  1
    load_0_5_1  segment_prefix_ub_694  1
    load_0_5_1  segment_load_conservation_720  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_464  -20
    arc_0_5_2  connected_order_arc_465  -14
    arc_0_5_2  in_degree_696  1
    arc_0_5_2  out_degree_716  1
    arc_0_5_2  original_T_including_depot_unload_775  7.7662791174533720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_464  1
    load_0_5_2  segment_load_conservation_699  -1
    load_0_5_2  segment_prefix_lb_700  1
    load_0_5_2  segment_prefix_ub_701  1
    load_0_5_2  segment_load_conservation_720  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_466  -20
    arc_0_5_3  connected_order_arc_467  -14
    arc_0_5_3  in_degree_703  1
    arc_0_5_3  out_degree_716  1
    arc_0_5_3  original_T_including_depot_unload_775  7.7600923635341769e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_466  1
    load_0_5_3  segment_load_conservation_706  -1
    load_0_5_3  segment_prefix_lb_707  1
    load_0_5_3  segment_prefix_ub_708  1
    load_0_5_3  segment_load_conservation_720  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_468  -20
    arc_0_5_4  connected_order_arc_469  -14
    arc_0_5_4  in_degree_710  1
    arc_0_5_4  out_degree_716  1
    arc_0_5_4  original_T_including_depot_unload_775  9.2367088355230590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_468  1
    load_0_5_4  segment_load_conservation_713  -1
    load_0_5_4  segment_prefix_lb_714  1
    load_0_5_4  segment_prefix_ub_715  1
    load_0_5_4  segment_load_conservation_720  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_470  -20
    arc_0_5_13  connected_order_arc_471  -14
    arc_0_5_13  out_degree_716  1
    arc_0_5_13  in_degree_724  1
    arc_0_5_13  original_T_including_depot_unload_775  7.2196448570394080e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_470  1
    load_0_5_13  segment_load_conservation_720  1
    load_0_5_13  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_472  -20
    arc_0_5_14  connected_order_arc_473  -14
    arc_0_5_14  out_degree_716  1
    arc_0_5_14  in_degree_730  1
    arc_0_5_14  original_T_including_depot_unload_775  8.4865162627289658e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_472  1
    load_0_5_14  segment_load_conservation_720  1
    load_0_5_14  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_474  -20
    arc_0_5_15  connected_order_arc_475  -14
    arc_0_5_15  out_degree_716  1
    arc_0_5_15  in_degree_736  1
    arc_0_5_15  original_T_including_depot_unload_775  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_474  1
    load_0_5_15  segment_load_conservation_720  1
    load_0_5_15  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_476  -20
    arc_0_5_16  connected_order_arc_477  -14
    arc_0_5_16  out_degree_716  1
    arc_0_5_16  in_degree_742  1
    arc_0_5_16  original_T_including_depot_unload_775  1.0738353745204206e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_476  1
    load_0_5_16  segment_load_conservation_720  1
    load_0_5_16  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_478  -20
    arc_0_5_17  connected_order_arc_479  -14
    arc_0_5_17  out_degree_716  1
    arc_0_5_17  in_degree_748  1
    arc_0_5_17  original_T_including_depot_unload_775  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_478  1
    load_0_5_17  segment_load_conservation_720  1
    load_0_5_17  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_480  -20
    arc_0_5_18  connected_order_arc_481  -14
    arc_0_5_18  out_degree_716  1
    arc_0_5_18  in_degree_754  1
    arc_0_5_18  original_T_including_depot_unload_775  6.4485258452666415e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_480  1
    load_0_5_18  segment_load_conservation_720  1
    load_0_5_18  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_482  -20
    arc_0_5_19  connected_order_arc_483  -14
    arc_0_5_19  out_degree_716  1
    arc_0_5_19  in_degree_760  1
    arc_0_5_19  original_T_including_depot_unload_775  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_482  1
    load_0_5_19  segment_load_conservation_720  1
    load_0_5_19  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_484  -20
    arc_0_5_20  connected_order_arc_485  -14
    arc_0_5_20  out_degree_716  1
    arc_0_5_20  in_degree_766  1
    arc_0_5_20  original_T_including_depot_unload_775  4.8520683722319296e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_484  1
    load_0_5_20  segment_load_conservation_720  1
    load_0_5_20  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_486  -20
    arc_0_13_0  depot_return_or_bypass_687  1
    arc_0_13_0  out_degree_723  1
    arc_0_13_0  original_T_including_depot_unload_775  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_486  1
    load_0_13_0  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_487  -20
    arc_0_13_1  connected_order_arc_488  -14
    arc_0_13_1  in_degree_689  1
    arc_0_13_1  out_degree_723  1
    arc_0_13_1  original_T_including_depot_unload_775  6.0082621405522366e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_487  1
    load_0_13_1  segment_load_conservation_692  -1
    load_0_13_1  segment_prefix_lb_693  1
    load_0_13_1  segment_prefix_ub_694  1
    load_0_13_1  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_489  -20
    arc_0_13_2  connected_order_arc_490  -14
    arc_0_13_2  in_degree_696  1
    arc_0_13_2  out_degree_723  1
    arc_0_13_2  original_T_including_depot_unload_775  5.7164184935040350e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_489  1
    load_0_13_2  segment_load_conservation_699  -1
    load_0_13_2  segment_prefix_lb_700  1
    load_0_13_2  segment_prefix_ub_701  1
    load_0_13_2  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_491  -20
    arc_0_13_3  connected_order_arc_492  -14
    arc_0_13_3  in_degree_703  1
    arc_0_13_3  out_degree_723  1
    arc_0_13_3  original_T_including_depot_unload_775  5.7138137092491206e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_491  1
    load_0_13_3  segment_load_conservation_706  -1
    load_0_13_3  segment_prefix_lb_707  1
    load_0_13_3  segment_prefix_ub_708  1
    load_0_13_3  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_493  -20
    arc_0_13_4  connected_order_arc_494  -14
    arc_0_13_4  in_degree_710  1
    arc_0_13_4  out_degree_723  1
    arc_0_13_4  original_T_including_depot_unload_775  6.9292160543761986e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_493  1
    load_0_13_4  segment_load_conservation_713  -1
    load_0_13_4  segment_prefix_lb_714  1
    load_0_13_4  segment_prefix_ub_715  1
    load_0_13_4  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_495  -20
    arc_0_13_5  connected_order_arc_496  -14
    arc_0_13_5  in_degree_717  1
    arc_0_13_5  out_degree_723  1
    arc_0_13_5  original_T_including_depot_unload_775  6.3069852135268593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_495  1
    load_0_13_5  segment_load_conservation_720  -1
    load_0_13_5  segment_prefix_lb_721  1
    load_0_13_5  segment_prefix_ub_722  1
    load_0_13_5  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_497  -20
    arc_0_13_14  connected_order_arc_498  -14
    arc_0_13_14  out_degree_723  1
    arc_0_13_14  in_degree_730  1
    arc_0_13_14  original_T_including_depot_unload_775  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_497  1
    load_0_13_14  free_load_conservation_728  1
    load_0_13_14  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_499  -20
    arc_0_13_15  connected_order_arc_500  -14
    arc_0_13_15  out_degree_723  1
    arc_0_13_15  in_degree_736  1
    arc_0_13_15  original_T_including_depot_unload_775  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_499  1
    load_0_13_15  free_load_conservation_728  1
    load_0_13_15  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_501  -20
    arc_0_13_16  connected_order_arc_502  -14
    arc_0_13_16  out_degree_723  1
    arc_0_13_16  in_degree_742  1
    arc_0_13_16  original_T_including_depot_unload_775  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_501  1
    load_0_13_16  free_load_conservation_728  1
    load_0_13_16  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_503  -20
    arc_0_13_17  connected_order_arc_504  -14
    arc_0_13_17  out_degree_723  1
    arc_0_13_17  in_degree_748  1
    arc_0_13_17  original_T_including_depot_unload_775  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_503  1
    load_0_13_17  free_load_conservation_728  1
    load_0_13_17  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_505  -20
    arc_0_13_18  connected_order_arc_506  -14
    arc_0_13_18  out_degree_723  1
    arc_0_13_18  in_degree_754  1
    arc_0_13_18  original_T_including_depot_unload_775  5.3222543932043470e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_505  1
    load_0_13_18  free_load_conservation_728  1
    load_0_13_18  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_507  -20
    arc_0_13_19  connected_order_arc_508  -14
    arc_0_13_19  out_degree_723  1
    arc_0_13_19  in_degree_760  1
    arc_0_13_19  original_T_including_depot_unload_775  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_507  1
    load_0_13_19  free_load_conservation_728  1
    load_0_13_19  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_20  arc_capacity_509  -20
    arc_0_13_20  connected_order_arc_510  -14
    arc_0_13_20  out_degree_723  1
    arc_0_13_20  in_degree_766  1
    arc_0_13_20  original_T_including_depot_unload_775  552.429776828834
    MARKER    'MARKER'                 'INTEND'
    load_0_13_20  arc_capacity_509  1
    load_0_13_20  free_load_conservation_728  1
    load_0_13_20  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_511  -20
    arc_0_14_0  depot_return_or_bypass_687  1
    arc_0_14_0  out_degree_729  1
    arc_0_14_0  original_T_including_depot_unload_775  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_511  1
    load_0_14_0  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_512  -20
    arc_0_14_1  connected_order_arc_513  -14
    arc_0_14_1  in_degree_689  1
    arc_0_14_1  out_degree_729  1
    arc_0_14_1  original_T_including_depot_unload_775  3.8231967210987659e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_512  1
    load_0_14_1  segment_load_conservation_692  -1
    load_0_14_1  segment_prefix_lb_693  1
    load_0_14_1  segment_prefix_ub_694  1
    load_0_14_1  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_514  -20
    arc_0_14_2  connected_order_arc_515  -14
    arc_0_14_2  in_degree_696  1
    arc_0_14_2  out_degree_729  1
    arc_0_14_2  original_T_including_depot_unload_775  3.4724611547105854e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_514  1
    load_0_14_2  segment_load_conservation_699  -1
    load_0_14_2  segment_prefix_lb_700  1
    load_0_14_2  segment_prefix_ub_701  1
    load_0_14_2  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_516  -20
    arc_0_14_3  connected_order_arc_517  -14
    arc_0_14_3  in_degree_703  1
    arc_0_14_3  out_degree_729  1
    arc_0_14_3  original_T_including_depot_unload_775  3.4726967782722494e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_516  1
    load_0_14_3  segment_load_conservation_706  -1
    load_0_14_3  segment_prefix_lb_707  1
    load_0_14_3  segment_prefix_ub_708  1
    load_0_14_3  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_518  -20
    arc_0_14_4  connected_order_arc_519  -14
    arc_0_14_4  in_degree_710  1
    arc_0_14_4  out_degree_729  1
    arc_0_14_4  original_T_including_depot_unload_775  4.2580398435897172e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_518  1
    load_0_14_4  segment_load_conservation_713  -1
    load_0_14_4  segment_prefix_lb_714  1
    load_0_14_4  segment_prefix_ub_715  1
    load_0_14_4  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_520  -20
    arc_0_14_5  connected_order_arc_521  -14
    arc_0_14_5  in_degree_717  1
    arc_0_14_5  out_degree_729  1
    arc_0_14_5  original_T_including_depot_unload_775  6.4732789246105290e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_520  1
    load_0_14_5  segment_load_conservation_720  -1
    load_0_14_5  segment_prefix_lb_721  1
    load_0_14_5  segment_prefix_ub_722  1
    load_0_14_5  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_522  -20
    arc_0_14_13  connected_order_arc_523  -14
    arc_0_14_13  in_degree_724  1
    arc_0_14_13  out_degree_729  1
    arc_0_14_13  original_T_including_depot_unload_775  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_522  1
    load_0_14_13  free_load_conservation_728  -1
    load_0_14_13  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_524  -20
    arc_0_14_15  connected_order_arc_525  -14
    arc_0_14_15  out_degree_729  1
    arc_0_14_15  in_degree_736  1
    arc_0_14_15  original_T_including_depot_unload_775  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_524  1
    load_0_14_15  free_load_conservation_734  1
    load_0_14_15  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_526  -20
    arc_0_14_16  connected_order_arc_527  -14
    arc_0_14_16  out_degree_729  1
    arc_0_14_16  in_degree_742  1
    arc_0_14_16  original_T_including_depot_unload_775  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_526  1
    load_0_14_16  free_load_conservation_734  1
    load_0_14_16  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_528  -20
    arc_0_14_17  connected_order_arc_529  -14
    arc_0_14_17  out_degree_729  1
    arc_0_14_17  in_degree_748  1
    arc_0_14_17  original_T_including_depot_unload_775  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_528  1
    load_0_14_17  free_load_conservation_734  1
    load_0_14_17  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_530  -20
    arc_0_14_18  connected_order_arc_531  -14
    arc_0_14_18  out_degree_729  1
    arc_0_14_18  in_degree_754  1
    arc_0_14_18  original_T_including_depot_unload_775  3.7840168155842611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_530  1
    load_0_14_18  free_load_conservation_734  1
    load_0_14_18  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_532  -20
    arc_0_14_19  connected_order_arc_533  -14
    arc_0_14_19  out_degree_729  1
    arc_0_14_19  in_degree_760  1
    arc_0_14_19  original_T_including_depot_unload_775  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_532  1
    load_0_14_19  free_load_conservation_734  1
    load_0_14_19  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_534  -20
    arc_0_14_20  connected_order_arc_535  -14
    arc_0_14_20  out_degree_729  1
    arc_0_14_20  in_degree_766  1
    arc_0_14_20  original_T_including_depot_unload_775  4.8778172744463808e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_534  1
    load_0_14_20  free_load_conservation_734  1
    load_0_14_20  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_536  -20
    arc_0_15_0  depot_return_or_bypass_687  1
    arc_0_15_0  out_degree_735  1
    arc_0_15_0  original_T_including_depot_unload_775  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_536  1
    load_0_15_0  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_537  -20
    arc_0_15_1  connected_order_arc_538  -14
    arc_0_15_1  in_degree_689  1
    arc_0_15_1  out_degree_735  1
    arc_0_15_1  original_T_including_depot_unload_775  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_537  1
    load_0_15_1  segment_load_conservation_692  -1
    load_0_15_1  segment_prefix_lb_693  1
    load_0_15_1  segment_prefix_ub_694  1
    load_0_15_1  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_539  -20
    arc_0_15_2  connected_order_arc_540  -14
    arc_0_15_2  in_degree_696  1
    arc_0_15_2  out_degree_735  1
    arc_0_15_2  original_T_including_depot_unload_775  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_539  1
    load_0_15_2  segment_load_conservation_699  -1
    load_0_15_2  segment_prefix_lb_700  1
    load_0_15_2  segment_prefix_ub_701  1
    load_0_15_2  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_541  -20
    arc_0_15_3  connected_order_arc_542  -14
    arc_0_15_3  in_degree_703  1
    arc_0_15_3  out_degree_735  1
    arc_0_15_3  original_T_including_depot_unload_775  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_541  1
    load_0_15_3  segment_load_conservation_706  -1
    load_0_15_3  segment_prefix_lb_707  1
    load_0_15_3  segment_prefix_ub_708  1
    load_0_15_3  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_543  -20
    arc_0_15_4  connected_order_arc_544  -14
    arc_0_15_4  in_degree_710  1
    arc_0_15_4  out_degree_735  1
    arc_0_15_4  original_T_including_depot_unload_775  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_543  1
    load_0_15_4  segment_load_conservation_713  -1
    load_0_15_4  segment_prefix_lb_714  1
    load_0_15_4  segment_prefix_ub_715  1
    load_0_15_4  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_545  -20
    arc_0_15_5  connected_order_arc_546  -14
    arc_0_15_5  in_degree_717  1
    arc_0_15_5  out_degree_735  1
    arc_0_15_5  original_T_including_depot_unload_775  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_545  1
    load_0_15_5  segment_load_conservation_720  -1
    load_0_15_5  segment_prefix_lb_721  1
    load_0_15_5  segment_prefix_ub_722  1
    load_0_15_5  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_547  -20
    arc_0_15_13  connected_order_arc_548  -14
    arc_0_15_13  in_degree_724  1
    arc_0_15_13  out_degree_735  1
    arc_0_15_13  original_T_including_depot_unload_775  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_547  1
    load_0_15_13  free_load_conservation_728  -1
    load_0_15_13  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_549  -20
    arc_0_15_14  connected_order_arc_550  -14
    arc_0_15_14  in_degree_730  1
    arc_0_15_14  out_degree_735  1
    arc_0_15_14  original_T_including_depot_unload_775  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_549  1
    load_0_15_14  free_load_conservation_734  -1
    load_0_15_14  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_551  -20
    arc_0_15_16  connected_order_arc_552  -14
    arc_0_15_16  out_degree_735  1
    arc_0_15_16  in_degree_742  1
    arc_0_15_16  original_T_including_depot_unload_775  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_551  1
    load_0_15_16  free_load_conservation_740  1
    load_0_15_16  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_553  -20
    arc_0_15_17  connected_order_arc_554  -14
    arc_0_15_17  out_degree_735  1
    arc_0_15_17  in_degree_748  1
    arc_0_15_17  original_T_including_depot_unload_775  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_553  1
    load_0_15_17  free_load_conservation_740  1
    load_0_15_17  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_555  -20
    arc_0_15_18  connected_order_arc_556  -14
    arc_0_15_18  out_degree_735  1
    arc_0_15_18  in_degree_754  1
    arc_0_15_18  original_T_including_depot_unload_775  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_555  1
    load_0_15_18  free_load_conservation_740  1
    load_0_15_18  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_557  -20
    arc_0_15_19  connected_order_arc_558  -14
    arc_0_15_19  out_degree_735  1
    arc_0_15_19  in_degree_760  1
    arc_0_15_19  original_T_including_depot_unload_775  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_557  1
    load_0_15_19  free_load_conservation_740  1
    load_0_15_19  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_559  -20
    arc_0_15_20  connected_order_arc_560  -14
    arc_0_15_20  out_degree_735  1
    arc_0_15_20  in_degree_766  1
    arc_0_15_20  original_T_including_depot_unload_775  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_559  1
    load_0_15_20  free_load_conservation_740  1
    load_0_15_20  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_561  -20
    arc_0_16_0  depot_return_or_bypass_687  1
    arc_0_16_0  out_degree_741  1
    arc_0_16_0  original_T_including_depot_unload_775  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_561  1
    load_0_16_0  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_562  -20
    arc_0_16_1  connected_order_arc_563  -14
    arc_0_16_1  in_degree_689  1
    arc_0_16_1  out_degree_741  1
    arc_0_16_1  original_T_including_depot_unload_775  6.7008394119213415e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_562  1
    load_0_16_1  segment_load_conservation_692  -1
    load_0_16_1  segment_prefix_lb_693  1
    load_0_16_1  segment_prefix_ub_694  1
    load_0_16_1  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_564  -20
    arc_0_16_2  connected_order_arc_565  -14
    arc_0_16_2  in_degree_696  1
    arc_0_16_2  out_degree_741  1
    arc_0_16_2  original_T_including_depot_unload_775  634.658635437287
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_564  1
    load_0_16_2  segment_load_conservation_699  -1
    load_0_16_2  segment_prefix_lb_700  1
    load_0_16_2  segment_prefix_ub_701  1
    load_0_16_2  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_566  -20
    arc_0_16_3  connected_order_arc_567  -14
    arc_0_16_3  in_degree_703  1
    arc_0_16_3  out_degree_741  1
    arc_0_16_3  original_T_including_depot_unload_775  634.778043158074
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_566  1
    load_0_16_3  segment_load_conservation_706  -1
    load_0_16_3  segment_prefix_lb_707  1
    load_0_16_3  segment_prefix_ub_708  1
    load_0_16_3  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_568  -20
    arc_0_16_4  connected_order_arc_569  -14
    arc_0_16_4  in_degree_710  1
    arc_0_16_4  out_degree_741  1
    arc_0_16_4  original_T_including_depot_unload_775  6.8151832047278333e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_568  1
    load_0_16_4  segment_load_conservation_713  -1
    load_0_16_4  segment_prefix_lb_714  1
    load_0_16_4  segment_prefix_ub_715  1
    load_0_16_4  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_570  -20
    arc_0_16_5  connected_order_arc_571  -14
    arc_0_16_5  in_degree_717  1
    arc_0_16_5  out_degree_741  1
    arc_0_16_5  original_T_including_depot_unload_775  9.1749781390727367e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_570  1
    load_0_16_5  segment_load_conservation_720  -1
    load_0_16_5  segment_prefix_lb_721  1
    load_0_16_5  segment_prefix_ub_722  1
    load_0_16_5  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_572  -20
    arc_0_16_13  connected_order_arc_573  -14
    arc_0_16_13  in_degree_724  1
    arc_0_16_13  out_degree_741  1
    arc_0_16_13  original_T_including_depot_unload_775  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_572  1
    load_0_16_13  free_load_conservation_728  -1
    load_0_16_13  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_574  -20
    arc_0_16_14  connected_order_arc_575  -14
    arc_0_16_14  in_degree_730  1
    arc_0_16_14  out_degree_741  1
    arc_0_16_14  original_T_including_depot_unload_775  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_574  1
    load_0_16_14  free_load_conservation_734  -1
    load_0_16_14  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_576  -20
    arc_0_16_15  connected_order_arc_577  -14
    arc_0_16_15  in_degree_736  1
    arc_0_16_15  out_degree_741  1
    arc_0_16_15  original_T_including_depot_unload_775  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_576  1
    load_0_16_15  free_load_conservation_740  -1
    load_0_16_15  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_578  -20
    arc_0_16_17  connected_order_arc_579  -14
    arc_0_16_17  out_degree_741  1
    arc_0_16_17  in_degree_748  1
    arc_0_16_17  original_T_including_depot_unload_775  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_578  1
    load_0_16_17  free_load_conservation_746  1
    load_0_16_17  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_580  -20
    arc_0_16_18  connected_order_arc_581  -14
    arc_0_16_18  out_degree_741  1
    arc_0_16_18  in_degree_754  1
    arc_0_16_18  original_T_including_depot_unload_775  6.7500260835612892e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_580  1
    load_0_16_18  free_load_conservation_746  1
    load_0_16_18  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_582  -20
    arc_0_16_19  connected_order_arc_583  -14
    arc_0_16_19  out_degree_741  1
    arc_0_16_19  in_degree_760  1
    arc_0_16_19  original_T_including_depot_unload_775  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_582  1
    load_0_16_19  free_load_conservation_746  1
    load_0_16_19  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_584  -20
    arc_0_16_20  connected_order_arc_585  -14
    arc_0_16_20  out_degree_741  1
    arc_0_16_20  in_degree_766  1
    arc_0_16_20  original_T_including_depot_unload_775  7.7576476069541832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_584  1
    load_0_16_20  free_load_conservation_746  1
    load_0_16_20  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_586  -20
    arc_0_17_0  depot_return_or_bypass_687  1
    arc_0_17_0  out_degree_747  1
    arc_0_17_0  original_T_including_depot_unload_775  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_586  1
    load_0_17_0  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_587  -20
    arc_0_17_1  connected_order_arc_588  -14
    arc_0_17_1  in_degree_689  1
    arc_0_17_1  out_degree_747  1
    arc_0_17_1  original_T_including_depot_unload_775  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_587  1
    load_0_17_1  segment_load_conservation_692  -1
    load_0_17_1  segment_prefix_lb_693  1
    load_0_17_1  segment_prefix_ub_694  1
    load_0_17_1  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_589  -20
    arc_0_17_2  connected_order_arc_590  -14
    arc_0_17_2  in_degree_696  1
    arc_0_17_2  out_degree_747  1
    arc_0_17_2  original_T_including_depot_unload_775  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_589  1
    load_0_17_2  segment_load_conservation_699  -1
    load_0_17_2  segment_prefix_lb_700  1
    load_0_17_2  segment_prefix_ub_701  1
    load_0_17_2  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_591  -20
    arc_0_17_3  connected_order_arc_592  -14
    arc_0_17_3  in_degree_703  1
    arc_0_17_3  out_degree_747  1
    arc_0_17_3  original_T_including_depot_unload_775  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_591  1
    load_0_17_3  segment_load_conservation_706  -1
    load_0_17_3  segment_prefix_lb_707  1
    load_0_17_3  segment_prefix_ub_708  1
    load_0_17_3  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_593  -20
    arc_0_17_4  connected_order_arc_594  -14
    arc_0_17_4  in_degree_710  1
    arc_0_17_4  out_degree_747  1
    arc_0_17_4  original_T_including_depot_unload_775  1.7807233899807140e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_593  1
    load_0_17_4  segment_load_conservation_713  -1
    load_0_17_4  segment_prefix_lb_714  1
    load_0_17_4  segment_prefix_ub_715  1
    load_0_17_4  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_595  -20
    arc_0_17_5  connected_order_arc_596  -14
    arc_0_17_5  in_degree_717  1
    arc_0_17_5  out_degree_747  1
    arc_0_17_5  original_T_including_depot_unload_775  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_595  1
    load_0_17_5  segment_load_conservation_720  -1
    load_0_17_5  segment_prefix_lb_721  1
    load_0_17_5  segment_prefix_ub_722  1
    load_0_17_5  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_597  -20
    arc_0_17_13  connected_order_arc_598  -14
    arc_0_17_13  in_degree_724  1
    arc_0_17_13  out_degree_747  1
    arc_0_17_13  original_T_including_depot_unload_775  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_597  1
    load_0_17_13  free_load_conservation_728  -1
    load_0_17_13  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_599  -20
    arc_0_17_14  connected_order_arc_600  -14
    arc_0_17_14  in_degree_730  1
    arc_0_17_14  out_degree_747  1
    arc_0_17_14  original_T_including_depot_unload_775  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_599  1
    load_0_17_14  free_load_conservation_734  -1
    load_0_17_14  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_601  -20
    arc_0_17_15  connected_order_arc_602  -14
    arc_0_17_15  in_degree_736  1
    arc_0_17_15  out_degree_747  1
    arc_0_17_15  original_T_including_depot_unload_775  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_601  1
    load_0_17_15  free_load_conservation_740  -1
    load_0_17_15  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_603  -20
    arc_0_17_16  connected_order_arc_604  -14
    arc_0_17_16  in_degree_742  1
    arc_0_17_16  out_degree_747  1
    arc_0_17_16  original_T_including_depot_unload_775  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_603  1
    load_0_17_16  free_load_conservation_746  -1
    load_0_17_16  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_605  -20
    arc_0_17_18  connected_order_arc_606  -14
    arc_0_17_18  out_degree_747  1
    arc_0_17_18  in_degree_754  1
    arc_0_17_18  original_T_including_depot_unload_775  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_605  1
    load_0_17_18  free_load_conservation_752  1
    load_0_17_18  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_607  -20
    arc_0_17_19  connected_order_arc_608  -14
    arc_0_17_19  out_degree_747  1
    arc_0_17_19  in_degree_760  1
    arc_0_17_19  original_T_including_depot_unload_775  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_607  1
    load_0_17_19  free_load_conservation_752  1
    load_0_17_19  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_609  -20
    arc_0_17_20  connected_order_arc_610  -14
    arc_0_17_20  out_degree_747  1
    arc_0_17_20  in_degree_766  1
    arc_0_17_20  original_T_including_depot_unload_775  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_609  1
    load_0_17_20  free_load_conservation_752  1
    load_0_17_20  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_611  -20
    arc_0_18_0  depot_return_or_bypass_687  1
    arc_0_18_0  out_degree_753  1
    arc_0_18_0  original_T_including_depot_unload_775  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_611  1
    load_0_18_0  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_612  -20
    arc_0_18_1  connected_order_arc_613  -14
    arc_0_18_1  in_degree_689  1
    arc_0_18_1  out_degree_753  1
    arc_0_18_1  original_T_including_depot_unload_775  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_612  1
    load_0_18_1  segment_load_conservation_692  -1
    load_0_18_1  segment_prefix_lb_693  1
    load_0_18_1  segment_prefix_ub_694  1
    load_0_18_1  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_614  -20
    arc_0_18_2  connected_order_arc_615  -14
    arc_0_18_2  in_degree_696  1
    arc_0_18_2  out_degree_753  1
    arc_0_18_2  original_T_including_depot_unload_775  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_614  1
    load_0_18_2  segment_load_conservation_699  -1
    load_0_18_2  segment_prefix_lb_700  1
    load_0_18_2  segment_prefix_ub_701  1
    load_0_18_2  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_616  -20
    arc_0_18_3  connected_order_arc_617  -14
    arc_0_18_3  in_degree_703  1
    arc_0_18_3  out_degree_753  1
    arc_0_18_3  original_T_including_depot_unload_775  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_616  1
    load_0_18_3  segment_load_conservation_706  -1
    load_0_18_3  segment_prefix_lb_707  1
    load_0_18_3  segment_prefix_ub_708  1
    load_0_18_3  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_618  -20
    arc_0_18_4  connected_order_arc_619  -14
    arc_0_18_4  in_degree_710  1
    arc_0_18_4  out_degree_753  1
    arc_0_18_4  original_T_including_depot_unload_775  2.8083660458664087e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_618  1
    load_0_18_4  segment_load_conservation_713  -1
    load_0_18_4  segment_prefix_lb_714  1
    load_0_18_4  segment_prefix_ub_715  1
    load_0_18_4  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_620  -20
    arc_0_18_5  connected_order_arc_621  -14
    arc_0_18_5  in_degree_717  1
    arc_0_18_5  out_degree_753  1
    arc_0_18_5  original_T_including_depot_unload_775  362.349437569786
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_620  1
    load_0_18_5  segment_load_conservation_720  -1
    load_0_18_5  segment_prefix_lb_721  1
    load_0_18_5  segment_prefix_ub_722  1
    load_0_18_5  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_622  -20
    arc_0_18_13  connected_order_arc_623  -14
    arc_0_18_13  in_degree_724  1
    arc_0_18_13  out_degree_753  1
    arc_0_18_13  original_T_including_depot_unload_775  5.3222543932043470e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_622  1
    load_0_18_13  free_load_conservation_728  -1
    load_0_18_13  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_624  -20
    arc_0_18_14  connected_order_arc_625  -14
    arc_0_18_14  in_degree_730  1
    arc_0_18_14  out_degree_753  1
    arc_0_18_14  original_T_including_depot_unload_775  3.7840168155842611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_624  1
    load_0_18_14  free_load_conservation_734  -1
    load_0_18_14  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_626  -20
    arc_0_18_15  connected_order_arc_627  -14
    arc_0_18_15  in_degree_736  1
    arc_0_18_15  out_degree_753  1
    arc_0_18_15  original_T_including_depot_unload_775  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_626  1
    load_0_18_15  free_load_conservation_740  -1
    load_0_18_15  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_628  -20
    arc_0_18_16  connected_order_arc_629  -14
    arc_0_18_16  in_degree_742  1
    arc_0_18_16  out_degree_753  1
    arc_0_18_16  original_T_including_depot_unload_775  6.7500260835612892e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_628  1
    load_0_18_16  free_load_conservation_746  -1
    load_0_18_16  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_630  -20
    arc_0_18_17  connected_order_arc_631  -14
    arc_0_18_17  in_degree_748  1
    arc_0_18_17  out_degree_753  1
    arc_0_18_17  original_T_including_depot_unload_775  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_630  1
    load_0_18_17  free_load_conservation_752  -1
    load_0_18_17  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_632  -20
    arc_0_18_19  connected_order_arc_633  -14
    arc_0_18_19  out_degree_753  1
    arc_0_18_19  in_degree_760  1
    arc_0_18_19  original_T_including_depot_unload_775  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_632  1
    load_0_18_19  free_load_conservation_758  1
    load_0_18_19  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_634  -20
    arc_0_18_20  connected_order_arc_635  -14
    arc_0_18_20  out_degree_753  1
    arc_0_18_20  in_degree_766  1
    arc_0_18_20  original_T_including_depot_unload_775  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_634  1
    load_0_18_20  free_load_conservation_758  1
    load_0_18_20  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_636  -20
    arc_0_19_0  depot_return_or_bypass_687  1
    arc_0_19_0  out_degree_759  1
    arc_0_19_0  original_T_including_depot_unload_775  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_636  1
    load_0_19_0  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_637  -20
    arc_0_19_1  connected_order_arc_638  -14
    arc_0_19_1  in_degree_689  1
    arc_0_19_1  out_degree_759  1
    arc_0_19_1  original_T_including_depot_unload_775  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_637  1
    load_0_19_1  segment_load_conservation_692  -1
    load_0_19_1  segment_prefix_lb_693  1
    load_0_19_1  segment_prefix_ub_694  1
    load_0_19_1  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_639  -20
    arc_0_19_2  connected_order_arc_640  -14
    arc_0_19_2  in_degree_696  1
    arc_0_19_2  out_degree_759  1
    arc_0_19_2  original_T_including_depot_unload_775  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_639  1
    load_0_19_2  segment_load_conservation_699  -1
    load_0_19_2  segment_prefix_lb_700  1
    load_0_19_2  segment_prefix_ub_701  1
    load_0_19_2  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_641  -20
    arc_0_19_3  connected_order_arc_642  -14
    arc_0_19_3  in_degree_703  1
    arc_0_19_3  out_degree_759  1
    arc_0_19_3  original_T_including_depot_unload_775  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_641  1
    load_0_19_3  segment_load_conservation_706  -1
    load_0_19_3  segment_prefix_lb_707  1
    load_0_19_3  segment_prefix_ub_708  1
    load_0_19_3  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_643  -20
    arc_0_19_4  connected_order_arc_644  -14
    arc_0_19_4  in_degree_710  1
    arc_0_19_4  out_degree_759  1
    arc_0_19_4  original_T_including_depot_unload_775  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_643  1
    load_0_19_4  segment_load_conservation_713  -1
    load_0_19_4  segment_prefix_lb_714  1
    load_0_19_4  segment_prefix_ub_715  1
    load_0_19_4  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_645  -20
    arc_0_19_5  connected_order_arc_646  -14
    arc_0_19_5  in_degree_717  1
    arc_0_19_5  out_degree_759  1
    arc_0_19_5  original_T_including_depot_unload_775  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_645  1
    load_0_19_5  segment_load_conservation_720  -1
    load_0_19_5  segment_prefix_lb_721  1
    load_0_19_5  segment_prefix_ub_722  1
    load_0_19_5  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_647  -20
    arc_0_19_13  connected_order_arc_648  -14
    arc_0_19_13  in_degree_724  1
    arc_0_19_13  out_degree_759  1
    arc_0_19_13  original_T_including_depot_unload_775  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_647  1
    load_0_19_13  free_load_conservation_728  -1
    load_0_19_13  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_649  -20
    arc_0_19_14  connected_order_arc_650  -14
    arc_0_19_14  in_degree_730  1
    arc_0_19_14  out_degree_759  1
    arc_0_19_14  original_T_including_depot_unload_775  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_649  1
    load_0_19_14  free_load_conservation_734  -1
    load_0_19_14  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_651  -20
    arc_0_19_15  connected_order_arc_652  -14
    arc_0_19_15  in_degree_736  1
    arc_0_19_15  out_degree_759  1
    arc_0_19_15  original_T_including_depot_unload_775  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_651  1
    load_0_19_15  free_load_conservation_740  -1
    load_0_19_15  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_653  -20
    arc_0_19_16  connected_order_arc_654  -14
    arc_0_19_16  in_degree_742  1
    arc_0_19_16  out_degree_759  1
    arc_0_19_16  original_T_including_depot_unload_775  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_653  1
    load_0_19_16  free_load_conservation_746  -1
    load_0_19_16  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_655  -20
    arc_0_19_17  connected_order_arc_656  -14
    arc_0_19_17  in_degree_748  1
    arc_0_19_17  out_degree_759  1
    arc_0_19_17  original_T_including_depot_unload_775  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_655  1
    load_0_19_17  free_load_conservation_752  -1
    load_0_19_17  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_657  -20
    arc_0_19_18  connected_order_arc_658  -14
    arc_0_19_18  in_degree_754  1
    arc_0_19_18  out_degree_759  1
    arc_0_19_18  original_T_including_depot_unload_775  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_657  1
    load_0_19_18  free_load_conservation_758  -1
    load_0_19_18  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_659  -20
    arc_0_19_20  connected_order_arc_660  -14
    arc_0_19_20  out_degree_759  1
    arc_0_19_20  in_degree_766  1
    arc_0_19_20  original_T_including_depot_unload_775  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_659  1
    load_0_19_20  free_load_conservation_764  1
    load_0_19_20  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_661  -20
    arc_0_20_0  depot_return_or_bypass_687  1
    arc_0_20_0  out_degree_765  1
    arc_0_20_0  original_T_including_depot_unload_775  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_661  1
    load_0_20_0  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_662  -20
    arc_0_20_1  connected_order_arc_663  -14
    arc_0_20_1  in_degree_689  1
    arc_0_20_1  out_degree_765  1
    arc_0_20_1  original_T_including_depot_unload_775  2.8856753867620006e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_662  1
    load_0_20_1  segment_load_conservation_692  -1
    load_0_20_1  segment_prefix_lb_693  1
    load_0_20_1  segment_prefix_ub_694  1
    load_0_20_1  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_664  -20
    arc_0_20_2  connected_order_arc_665  -14
    arc_0_20_2  in_degree_696  1
    arc_0_20_2  out_degree_765  1
    arc_0_20_2  original_T_including_depot_unload_775  2.9672747884555446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_664  1
    load_0_20_2  segment_load_conservation_699  -1
    load_0_20_2  segment_prefix_lb_700  1
    load_0_20_2  segment_prefix_ub_701  1
    load_0_20_2  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_666  -20
    arc_0_20_3  connected_order_arc_667  -14
    arc_0_20_3  in_degree_703  1
    arc_0_20_3  out_degree_765  1
    arc_0_20_3  original_T_including_depot_unload_775  2.9611166330127878e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_666  1
    load_0_20_3  segment_load_conservation_706  -1
    load_0_20_3  segment_prefix_lb_707  1
    load_0_20_3  segment_prefix_ub_708  1
    load_0_20_3  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_668  -20
    arc_0_20_4  connected_order_arc_669  -14
    arc_0_20_4  in_degree_710  1
    arc_0_20_4  out_degree_765  1
    arc_0_20_4  original_T_including_depot_unload_775  4.3907641772187384e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_668  1
    load_0_20_4  segment_load_conservation_713  -1
    load_0_20_4  segment_prefix_lb_714  1
    load_0_20_4  segment_prefix_ub_715  1
    load_0_20_4  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_670  -20
    arc_0_20_5  connected_order_arc_671  -14
    arc_0_20_5  in_degree_717  1
    arc_0_20_5  out_degree_765  1
    arc_0_20_5  original_T_including_depot_unload_775  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_670  1
    load_0_20_5  segment_load_conservation_720  -1
    load_0_20_5  segment_prefix_lb_721  1
    load_0_20_5  segment_prefix_ub_722  1
    load_0_20_5  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_13  arc_capacity_672  -20
    arc_0_20_13  connected_order_arc_673  -14
    arc_0_20_13  in_degree_724  1
    arc_0_20_13  out_degree_765  1
    arc_0_20_13  original_T_including_depot_unload_775  552.429776828834
    MARKER    'MARKER'                 'INTEND'
    load_0_20_13  arc_capacity_672  1
    load_0_20_13  free_load_conservation_728  -1
    load_0_20_13  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_674  -20
    arc_0_20_14  connected_order_arc_675  -14
    arc_0_20_14  in_degree_730  1
    arc_0_20_14  out_degree_765  1
    arc_0_20_14  original_T_including_depot_unload_775  4.8778172744463808e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_674  1
    load_0_20_14  free_load_conservation_734  -1
    load_0_20_14  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_676  -20
    arc_0_20_15  connected_order_arc_677  -14
    arc_0_20_15  in_degree_736  1
    arc_0_20_15  out_degree_765  1
    arc_0_20_15  original_T_including_depot_unload_775  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_676  1
    load_0_20_15  free_load_conservation_740  -1
    load_0_20_15  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_678  -20
    arc_0_20_16  connected_order_arc_679  -14
    arc_0_20_16  in_degree_742  1
    arc_0_20_16  out_degree_765  1
    arc_0_20_16  original_T_including_depot_unload_775  7.7576476069541832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_678  1
    load_0_20_16  free_load_conservation_746  -1
    load_0_20_16  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_680  -20
    arc_0_20_17  connected_order_arc_681  -14
    arc_0_20_17  in_degree_748  1
    arc_0_20_17  out_degree_765  1
    arc_0_20_17  original_T_including_depot_unload_775  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_680  1
    load_0_20_17  free_load_conservation_752  -1
    load_0_20_17  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_682  -20
    arc_0_20_18  connected_order_arc_683  -14
    arc_0_20_18  in_degree_754  1
    arc_0_20_18  out_degree_765  1
    arc_0_20_18  original_T_including_depot_unload_775  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_682  1
    load_0_20_18  free_load_conservation_758  -1
    load_0_20_18  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_684  -20
    arc_0_20_19  connected_order_arc_685  -14
    arc_0_20_19  in_degree_760  1
    arc_0_20_19  out_degree_765  1
    arc_0_20_19  original_T_including_depot_unload_775  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_684  1
    load_0_20_19  free_load_conservation_764  -1
    load_0_20_19  free_load_conservation_770  1
    visit_1_6  out_degree_979  -1
    visit_1_6  in_degree_980  -1
    visit_1_6  order_active_lb_981  -1
    visit_1_6  order_active_ub_982  -10
    order_1_6  connected_order_arc_789  -1
    order_1_6  connected_order_arc_791  -1
    order_1_6  connected_order_arc_793  -1
    order_1_6  connected_order_arc_795  -1
    order_1_6  connected_order_arc_797  -1
    order_1_6  connected_order_arc_799  -1
    order_1_6  connected_order_arc_801  -1
    order_1_6  connected_order_arc_803  -1
    order_1_6  connected_order_arc_805  -1
    order_1_6  connected_order_arc_808  1
    order_1_6  connected_order_arc_827  1
    order_1_6  connected_order_arc_846  1
    order_1_6  connected_order_arc_865  1
    order_1_6  connected_order_arc_884  1
    order_1_6  connected_order_arc_903  1
    order_1_6  connected_order_arc_922  1
    order_1_6  connected_order_arc_941  1
    order_1_6  connected_order_arc_960  1
    order_1_6  order_active_lb_981  1
    order_1_6  order_active_ub_982  1
    order_1_6  fixed_segment_relative_order_1041  -1
    visit_1_7  out_degree_986  -1
    visit_1_7  in_degree_987  -1
    visit_1_7  order_active_lb_988  -1
    visit_1_7  order_active_ub_989  -10
    order_1_7  connected_order_arc_789  1
    order_1_7  connected_order_arc_808  -1
    order_1_7  connected_order_arc_810  -1
    order_1_7  connected_order_arc_812  -1
    order_1_7  connected_order_arc_814  -1
    order_1_7  connected_order_arc_816  -1
    order_1_7  connected_order_arc_818  -1
    order_1_7  connected_order_arc_820  -1
    order_1_7  connected_order_arc_822  -1
    order_1_7  connected_order_arc_824  -1
    order_1_7  connected_order_arc_829  1
    order_1_7  connected_order_arc_848  1
    order_1_7  connected_order_arc_867  1
    order_1_7  connected_order_arc_886  1
    order_1_7  connected_order_arc_905  1
    order_1_7  connected_order_arc_924  1
    order_1_7  connected_order_arc_943  1
    order_1_7  connected_order_arc_962  1
    order_1_7  order_active_lb_988  1
    order_1_7  order_active_ub_989  1
    order_1_7  fixed_segment_relative_order_1041  1
    visit_1_13  out_degree_993  -1
    visit_1_13  in_degree_994  -1
    visit_1_13  order_active_lb_995  -1
    visit_1_13  order_active_ub_996  -10
    visit_1_13  service_visit_def_997  -1
    order_1_13  connected_order_arc_791  1
    order_1_13  connected_order_arc_810  1
    order_1_13  connected_order_arc_827  -1
    order_1_13  connected_order_arc_829  -1
    order_1_13  connected_order_arc_831  -1
    order_1_13  connected_order_arc_833  -1
    order_1_13  connected_order_arc_835  -1
    order_1_13  connected_order_arc_837  -1
    order_1_13  connected_order_arc_839  -1
    order_1_13  connected_order_arc_841  -1
    order_1_13  connected_order_arc_843  -1
    order_1_13  connected_order_arc_850  1
    order_1_13  connected_order_arc_869  1
    order_1_13  connected_order_arc_888  1
    order_1_13  connected_order_arc_907  1
    order_1_13  connected_order_arc_926  1
    order_1_13  connected_order_arc_945  1
    order_1_13  connected_order_arc_964  1
    order_1_13  order_active_lb_995  1
    order_1_13  order_active_ub_996  1
    visit_1_14  out_degree_999  -1
    visit_1_14  in_degree_1000  -1
    visit_1_14  order_active_lb_1001  -1
    visit_1_14  order_active_ub_1002  -10
    visit_1_14  service_visit_def_1003  -1
    order_1_14  connected_order_arc_793  1
    order_1_14  connected_order_arc_812  1
    order_1_14  connected_order_arc_831  1
    order_1_14  connected_order_arc_846  -1
    order_1_14  connected_order_arc_848  -1
    order_1_14  connected_order_arc_850  -1
    order_1_14  connected_order_arc_852  -1
    order_1_14  connected_order_arc_854  -1
    order_1_14  connected_order_arc_856  -1
    order_1_14  connected_order_arc_858  -1
    order_1_14  connected_order_arc_860  -1
    order_1_14  connected_order_arc_862  -1
    order_1_14  connected_order_arc_871  1
    order_1_14  connected_order_arc_890  1
    order_1_14  connected_order_arc_909  1
    order_1_14  connected_order_arc_928  1
    order_1_14  connected_order_arc_947  1
    order_1_14  connected_order_arc_966  1
    order_1_14  order_active_lb_1001  1
    order_1_14  order_active_ub_1002  1
    visit_1_15  out_degree_1005  -1
    visit_1_15  in_degree_1006  -1
    visit_1_15  order_active_lb_1007  -1
    visit_1_15  order_active_ub_1008  -10
    visit_1_15  service_visit_def_1009  -1
    order_1_15  connected_order_arc_795  1
    order_1_15  connected_order_arc_814  1
    order_1_15  connected_order_arc_833  1
    order_1_15  connected_order_arc_852  1
    order_1_15  connected_order_arc_865  -1
    order_1_15  connected_order_arc_867  -1
    order_1_15  connected_order_arc_869  -1
    order_1_15  connected_order_arc_871  -1
    order_1_15  connected_order_arc_873  -1
    order_1_15  connected_order_arc_875  -1
    order_1_15  connected_order_arc_877  -1
    order_1_15  connected_order_arc_879  -1
    order_1_15  connected_order_arc_881  -1
    order_1_15  connected_order_arc_892  1
    order_1_15  connected_order_arc_911  1
    order_1_15  connected_order_arc_930  1
    order_1_15  connected_order_arc_949  1
    order_1_15  connected_order_arc_968  1
    order_1_15  order_active_lb_1007  1
    order_1_15  order_active_ub_1008  1
    visit_1_16  out_degree_1011  -1
    visit_1_16  in_degree_1012  -1
    visit_1_16  order_active_lb_1013  -1
    visit_1_16  order_active_ub_1014  -10
    visit_1_16  service_visit_def_1015  -1
    order_1_16  connected_order_arc_797  1
    order_1_16  connected_order_arc_816  1
    order_1_16  connected_order_arc_835  1
    order_1_16  connected_order_arc_854  1
    order_1_16  connected_order_arc_873  1
    order_1_16  connected_order_arc_884  -1
    order_1_16  connected_order_arc_886  -1
    order_1_16  connected_order_arc_888  -1
    order_1_16  connected_order_arc_890  -1
    order_1_16  connected_order_arc_892  -1
    order_1_16  connected_order_arc_894  -1
    order_1_16  connected_order_arc_896  -1
    order_1_16  connected_order_arc_898  -1
    order_1_16  connected_order_arc_900  -1
    order_1_16  connected_order_arc_913  1
    order_1_16  connected_order_arc_932  1
    order_1_16  connected_order_arc_951  1
    order_1_16  connected_order_arc_970  1
    order_1_16  order_active_lb_1013  1
    order_1_16  order_active_ub_1014  1
    visit_1_17  out_degree_1017  -1
    visit_1_17  in_degree_1018  -1
    visit_1_17  order_active_lb_1019  -1
    visit_1_17  order_active_ub_1020  -10
    visit_1_17  service_visit_def_1021  -1
    order_1_17  connected_order_arc_799  1
    order_1_17  connected_order_arc_818  1
    order_1_17  connected_order_arc_837  1
    order_1_17  connected_order_arc_856  1
    order_1_17  connected_order_arc_875  1
    order_1_17  connected_order_arc_894  1
    order_1_17  connected_order_arc_903  -1
    order_1_17  connected_order_arc_905  -1
    order_1_17  connected_order_arc_907  -1
    order_1_17  connected_order_arc_909  -1
    order_1_17  connected_order_arc_911  -1
    order_1_17  connected_order_arc_913  -1
    order_1_17  connected_order_arc_915  -1
    order_1_17  connected_order_arc_917  -1
    order_1_17  connected_order_arc_919  -1
    order_1_17  connected_order_arc_934  1
    order_1_17  connected_order_arc_953  1
    order_1_17  connected_order_arc_972  1
    order_1_17  order_active_lb_1019  1
    order_1_17  order_active_ub_1020  1
    visit_1_18  out_degree_1023  -1
    visit_1_18  in_degree_1024  -1
    visit_1_18  order_active_lb_1025  -1
    visit_1_18  order_active_ub_1026  -10
    visit_1_18  service_visit_def_1027  -1
    order_1_18  connected_order_arc_801  1
    order_1_18  connected_order_arc_820  1
    order_1_18  connected_order_arc_839  1
    order_1_18  connected_order_arc_858  1
    order_1_18  connected_order_arc_877  1
    order_1_18  connected_order_arc_896  1
    order_1_18  connected_order_arc_915  1
    order_1_18  connected_order_arc_922  -1
    order_1_18  connected_order_arc_924  -1
    order_1_18  connected_order_arc_926  -1
    order_1_18  connected_order_arc_928  -1
    order_1_18  connected_order_arc_930  -1
    order_1_18  connected_order_arc_932  -1
    order_1_18  connected_order_arc_934  -1
    order_1_18  connected_order_arc_936  -1
    order_1_18  connected_order_arc_938  -1
    order_1_18  connected_order_arc_955  1
    order_1_18  connected_order_arc_974  1
    order_1_18  order_active_lb_1025  1
    order_1_18  order_active_ub_1026  1
    visit_1_19  out_degree_1029  -1
    visit_1_19  in_degree_1030  -1
    visit_1_19  order_active_lb_1031  -1
    visit_1_19  order_active_ub_1032  -10
    visit_1_19  service_visit_def_1033  -1
    order_1_19  connected_order_arc_803  1
    order_1_19  connected_order_arc_822  1
    order_1_19  connected_order_arc_841  1
    order_1_19  connected_order_arc_860  1
    order_1_19  connected_order_arc_879  1
    order_1_19  connected_order_arc_898  1
    order_1_19  connected_order_arc_917  1
    order_1_19  connected_order_arc_936  1
    order_1_19  connected_order_arc_941  -1
    order_1_19  connected_order_arc_943  -1
    order_1_19  connected_order_arc_945  -1
    order_1_19  connected_order_arc_947  -1
    order_1_19  connected_order_arc_949  -1
    order_1_19  connected_order_arc_951  -1
    order_1_19  connected_order_arc_953  -1
    order_1_19  connected_order_arc_955  -1
    order_1_19  connected_order_arc_957  -1
    order_1_19  connected_order_arc_976  1
    order_1_19  order_active_lb_1031  1
    order_1_19  order_active_ub_1032  1
    visit_1_20  out_degree_1035  -1
    visit_1_20  in_degree_1036  -1
    visit_1_20  order_active_lb_1037  -1
    visit_1_20  order_active_ub_1038  -10
    visit_1_20  service_visit_def_1039  -1
    order_1_20  connected_order_arc_805  1
    order_1_20  connected_order_arc_824  1
    order_1_20  connected_order_arc_843  1
    order_1_20  connected_order_arc_862  1
    order_1_20  connected_order_arc_881  1
    order_1_20  connected_order_arc_900  1
    order_1_20  connected_order_arc_919  1
    order_1_20  connected_order_arc_938  1
    order_1_20  connected_order_arc_957  1
    order_1_20  connected_order_arc_960  -1
    order_1_20  connected_order_arc_962  -1
    order_1_20  connected_order_arc_964  -1
    order_1_20  connected_order_arc_966  -1
    order_1_20  connected_order_arc_968  -1
    order_1_20  connected_order_arc_970  -1
    order_1_20  connected_order_arc_972  -1
    order_1_20  connected_order_arc_974  -1
    order_1_20  connected_order_arc_976  -1
    order_1_20  order_active_lb_1037  1
    order_1_20  order_active_ub_1038  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_776  -25
    arc_1_0_0  depot_departure_or_bypass_977  1
    arc_1_0_0  depot_return_or_bypass_978  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_777  -25
    arc_1_0_6  depot_departure_or_bypass_977  1
    arc_1_0_6  in_degree_980  1
    arc_1_0_6  original_T_including_depot_unload_1042  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_777  1
    load_1_0_6  segment_load_conservation_983  -1
    load_1_0_6  segment_prefix_lb_984  1
    load_1_0_6  segment_prefix_ub_985  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_778  -25
    arc_1_0_7  depot_departure_or_bypass_977  1
    arc_1_0_7  in_degree_987  1
    arc_1_0_7  original_T_including_depot_unload_1042  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_778  1
    load_1_0_7  segment_load_conservation_990  -1
    load_1_0_7  segment_prefix_lb_991  1
    load_1_0_7  segment_prefix_ub_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_779  -25
    arc_1_0_13  depot_departure_or_bypass_977  1
    arc_1_0_13  in_degree_994  1
    arc_1_0_13  original_T_including_depot_unload_1042  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_779  1
    load_1_0_13  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_780  -25
    arc_1_0_14  depot_departure_or_bypass_977  1
    arc_1_0_14  in_degree_1000  1
    arc_1_0_14  original_T_including_depot_unload_1042  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_780  1
    load_1_0_14  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_781  -25
    arc_1_0_15  depot_departure_or_bypass_977  1
    arc_1_0_15  in_degree_1006  1
    arc_1_0_15  original_T_including_depot_unload_1042  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_781  1
    load_1_0_15  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_782  -25
    arc_1_0_16  depot_departure_or_bypass_977  1
    arc_1_0_16  in_degree_1012  1
    arc_1_0_16  original_T_including_depot_unload_1042  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_782  1
    load_1_0_16  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_783  -25
    arc_1_0_17  depot_departure_or_bypass_977  1
    arc_1_0_17  in_degree_1018  1
    arc_1_0_17  original_T_including_depot_unload_1042  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_783  1
    load_1_0_17  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_784  -25
    arc_1_0_18  depot_departure_or_bypass_977  1
    arc_1_0_18  in_degree_1024  1
    arc_1_0_18  original_T_including_depot_unload_1042  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_784  1
    load_1_0_18  free_load_conservation_1028  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_785  -25
    arc_1_0_19  depot_departure_or_bypass_977  1
    arc_1_0_19  in_degree_1030  1
    arc_1_0_19  original_T_including_depot_unload_1042  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_785  1
    load_1_0_19  free_load_conservation_1034  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_786  -25
    arc_1_0_20  depot_departure_or_bypass_977  1
    arc_1_0_20  in_degree_1036  1
    arc_1_0_20  original_T_including_depot_unload_1042  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_786  1
    load_1_0_20  free_load_conservation_1040  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_787  -25
    arc_1_6_0  depot_return_or_bypass_978  1
    arc_1_6_0  out_degree_979  1
    arc_1_6_0  original_T_including_depot_unload_1042  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_787  1
    load_1_6_0  segment_load_conservation_983  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_788  -25
    arc_1_6_7  connected_order_arc_789  -11
    arc_1_6_7  out_degree_979  1
    arc_1_6_7  in_degree_987  1
    arc_1_6_7  original_T_including_depot_unload_1042  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_788  1
    load_1_6_7  segment_load_conservation_983  1
    load_1_6_7  segment_load_conservation_990  -1
    load_1_6_7  segment_prefix_lb_991  1
    load_1_6_7  segment_prefix_ub_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_790  -25
    arc_1_6_13  connected_order_arc_791  -11
    arc_1_6_13  out_degree_979  1
    arc_1_6_13  in_degree_994  1
    arc_1_6_13  original_T_including_depot_unload_1042  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_790  1
    load_1_6_13  segment_load_conservation_983  1
    load_1_6_13  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_792  -25
    arc_1_6_14  connected_order_arc_793  -11
    arc_1_6_14  out_degree_979  1
    arc_1_6_14  in_degree_1000  1
    arc_1_6_14  original_T_including_depot_unload_1042  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_792  1
    load_1_6_14  segment_load_conservation_983  1
    load_1_6_14  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_794  -25
    arc_1_6_15  connected_order_arc_795  -11
    arc_1_6_15  out_degree_979  1
    arc_1_6_15  in_degree_1006  1
    arc_1_6_15  original_T_including_depot_unload_1042  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_794  1
    load_1_6_15  segment_load_conservation_983  1
    load_1_6_15  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_796  -25
    arc_1_6_16  connected_order_arc_797  -11
    arc_1_6_16  out_degree_979  1
    arc_1_6_16  in_degree_1012  1
    arc_1_6_16  original_T_including_depot_unload_1042  1.0819844298451576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_796  1
    load_1_6_16  segment_load_conservation_983  1
    load_1_6_16  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_798  -25
    arc_1_6_17  connected_order_arc_799  -11
    arc_1_6_17  out_degree_979  1
    arc_1_6_17  in_degree_1018  1
    arc_1_6_17  original_T_including_depot_unload_1042  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_798  1
    load_1_6_17  segment_load_conservation_983  1
    load_1_6_17  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_800  -25
    arc_1_6_18  connected_order_arc_801  -11
    arc_1_6_18  out_degree_979  1
    arc_1_6_18  in_degree_1024  1
    arc_1_6_18  original_T_including_depot_unload_1042  1.5634365646683834e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_800  1
    load_1_6_18  segment_load_conservation_983  1
    load_1_6_18  free_load_conservation_1028  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_802  -25
    arc_1_6_19  connected_order_arc_803  -11
    arc_1_6_19  out_degree_979  1
    arc_1_6_19  in_degree_1030  1
    arc_1_6_19  original_T_including_depot_unload_1042  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_802  1
    load_1_6_19  segment_load_conservation_983  1
    load_1_6_19  free_load_conservation_1034  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_804  -25
    arc_1_6_20  connected_order_arc_805  -11
    arc_1_6_20  out_degree_979  1
    arc_1_6_20  in_degree_1036  1
    arc_1_6_20  original_T_including_depot_unload_1042  1.5639034270630727e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_804  1
    load_1_6_20  segment_load_conservation_983  1
    load_1_6_20  free_load_conservation_1040  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_806  -25
    arc_1_7_0  depot_return_or_bypass_978  1
    arc_1_7_0  out_degree_986  1
    arc_1_7_0  original_T_including_depot_unload_1042  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_806  1
    load_1_7_0  segment_load_conservation_990  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_807  -25
    arc_1_7_6  connected_order_arc_808  -11
    arc_1_7_6  in_degree_980  1
    arc_1_7_6  out_degree_986  1
    arc_1_7_6  original_T_including_depot_unload_1042  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_807  1
    load_1_7_6  segment_load_conservation_983  -1
    load_1_7_6  segment_prefix_lb_984  1
    load_1_7_6  segment_prefix_ub_985  1
    load_1_7_6  segment_load_conservation_990  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_809  -25
    arc_1_7_13  connected_order_arc_810  -11
    arc_1_7_13  out_degree_986  1
    arc_1_7_13  in_degree_994  1
    arc_1_7_13  original_T_including_depot_unload_1042  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_809  1
    load_1_7_13  segment_load_conservation_990  1
    load_1_7_13  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_811  -25
    arc_1_7_14  connected_order_arc_812  -11
    arc_1_7_14  out_degree_986  1
    arc_1_7_14  in_degree_1000  1
    arc_1_7_14  original_T_including_depot_unload_1042  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_811  1
    load_1_7_14  segment_load_conservation_990  1
    load_1_7_14  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_813  -25
    arc_1_7_15  connected_order_arc_814  -11
    arc_1_7_15  out_degree_986  1
    arc_1_7_15  in_degree_1006  1
    arc_1_7_15  original_T_including_depot_unload_1042  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_813  1
    load_1_7_15  segment_load_conservation_990  1
    load_1_7_15  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_815  -25
    arc_1_7_16  connected_order_arc_816  -11
    arc_1_7_16  out_degree_986  1
    arc_1_7_16  in_degree_1012  1
    arc_1_7_16  original_T_including_depot_unload_1042  1.0359917537364215e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_815  1
    load_1_7_16  segment_load_conservation_990  1
    load_1_7_16  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_817  -25
    arc_1_7_17  connected_order_arc_818  -11
    arc_1_7_17  out_degree_986  1
    arc_1_7_17  in_degree_1018  1
    arc_1_7_17  original_T_including_depot_unload_1042  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_817  1
    load_1_7_17  segment_load_conservation_990  1
    load_1_7_17  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_819  -25
    arc_1_7_18  connected_order_arc_820  -11
    arc_1_7_18  out_degree_986  1
    arc_1_7_18  in_degree_1024  1
    arc_1_7_18  original_T_including_depot_unload_1042  1.0271253855277889e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_819  1
    load_1_7_18  segment_load_conservation_990  1
    load_1_7_18  free_load_conservation_1028  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_821  -25
    arc_1_7_19  connected_order_arc_822  -11
    arc_1_7_19  out_degree_986  1
    arc_1_7_19  in_degree_1030  1
    arc_1_7_19  original_T_including_depot_unload_1042  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_821  1
    load_1_7_19  segment_load_conservation_990  1
    load_1_7_19  free_load_conservation_1034  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_823  -25
    arc_1_7_20  connected_order_arc_824  -11
    arc_1_7_20  out_degree_986  1
    arc_1_7_20  in_degree_1036  1
    arc_1_7_20  original_T_including_depot_unload_1042  1.1885707701696851e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_823  1
    load_1_7_20  segment_load_conservation_990  1
    load_1_7_20  free_load_conservation_1040  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_825  -25
    arc_1_13_0  depot_return_or_bypass_978  1
    arc_1_13_0  out_degree_993  1
    arc_1_13_0  original_T_including_depot_unload_1042  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_825  1
    load_1_13_0  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_826  -25
    arc_1_13_6  connected_order_arc_827  -11
    arc_1_13_6  in_degree_980  1
    arc_1_13_6  out_degree_993  1
    arc_1_13_6  original_T_including_depot_unload_1042  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_826  1
    load_1_13_6  segment_load_conservation_983  -1
    load_1_13_6  segment_prefix_lb_984  1
    load_1_13_6  segment_prefix_ub_985  1
    load_1_13_6  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_828  -25
    arc_1_13_7  connected_order_arc_829  -11
    arc_1_13_7  in_degree_987  1
    arc_1_13_7  out_degree_993  1
    arc_1_13_7  original_T_including_depot_unload_1042  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_828  1
    load_1_13_7  segment_load_conservation_990  -1
    load_1_13_7  segment_prefix_lb_991  1
    load_1_13_7  segment_prefix_ub_992  1
    load_1_13_7  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_830  -25
    arc_1_13_14  connected_order_arc_831  -11
    arc_1_13_14  out_degree_993  1
    arc_1_13_14  in_degree_1000  1
    arc_1_13_14  original_T_including_depot_unload_1042  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_830  1
    load_1_13_14  free_load_conservation_998  1
    load_1_13_14  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_832  -25
    arc_1_13_15  connected_order_arc_833  -11
    arc_1_13_15  out_degree_993  1
    arc_1_13_15  in_degree_1006  1
    arc_1_13_15  original_T_including_depot_unload_1042  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_832  1
    load_1_13_15  free_load_conservation_998  1
    load_1_13_15  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_834  -25
    arc_1_13_16  connected_order_arc_835  -11
    arc_1_13_16  out_degree_993  1
    arc_1_13_16  in_degree_1012  1
    arc_1_13_16  original_T_including_depot_unload_1042  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_834  1
    load_1_13_16  free_load_conservation_998  1
    load_1_13_16  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_836  -25
    arc_1_13_17  connected_order_arc_837  -11
    arc_1_13_17  out_degree_993  1
    arc_1_13_17  in_degree_1018  1
    arc_1_13_17  original_T_including_depot_unload_1042  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_836  1
    load_1_13_17  free_load_conservation_998  1
    load_1_13_17  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_838  -25
    arc_1_13_18  connected_order_arc_839  -11
    arc_1_13_18  out_degree_993  1
    arc_1_13_18  in_degree_1024  1
    arc_1_13_18  original_T_including_depot_unload_1042  5.3222543932043470e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_838  1
    load_1_13_18  free_load_conservation_998  1
    load_1_13_18  free_load_conservation_1028  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_840  -25
    arc_1_13_19  connected_order_arc_841  -11
    arc_1_13_19  out_degree_993  1
    arc_1_13_19  in_degree_1030  1
    arc_1_13_19  original_T_including_depot_unload_1042  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_840  1
    load_1_13_19  free_load_conservation_998  1
    load_1_13_19  free_load_conservation_1034  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_20  arc_capacity_842  -25
    arc_1_13_20  connected_order_arc_843  -11
    arc_1_13_20  out_degree_993  1
    arc_1_13_20  in_degree_1036  1
    arc_1_13_20  original_T_including_depot_unload_1042  552.429776828834
    MARKER    'MARKER'                 'INTEND'
    load_1_13_20  arc_capacity_842  1
    load_1_13_20  free_load_conservation_998  1
    load_1_13_20  free_load_conservation_1040  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_844  -25
    arc_1_14_0  depot_return_or_bypass_978  1
    arc_1_14_0  out_degree_999  1
    arc_1_14_0  original_T_including_depot_unload_1042  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_844  1
    load_1_14_0  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_845  -25
    arc_1_14_6  connected_order_arc_846  -11
    arc_1_14_6  in_degree_980  1
    arc_1_14_6  out_degree_999  1
    arc_1_14_6  original_T_including_depot_unload_1042  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_845  1
    load_1_14_6  segment_load_conservation_983  -1
    load_1_14_6  segment_prefix_lb_984  1
    load_1_14_6  segment_prefix_ub_985  1
    load_1_14_6  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_847  -25
    arc_1_14_7  connected_order_arc_848  -11
    arc_1_14_7  in_degree_987  1
    arc_1_14_7  out_degree_999  1
    arc_1_14_7  original_T_including_depot_unload_1042  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_847  1
    load_1_14_7  segment_load_conservation_990  -1
    load_1_14_7  segment_prefix_lb_991  1
    load_1_14_7  segment_prefix_ub_992  1
    load_1_14_7  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_849  -25
    arc_1_14_13  connected_order_arc_850  -11
    arc_1_14_13  in_degree_994  1
    arc_1_14_13  out_degree_999  1
    arc_1_14_13  original_T_including_depot_unload_1042  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_849  1
    load_1_14_13  free_load_conservation_998  -1
    load_1_14_13  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_851  -25
    arc_1_14_15  connected_order_arc_852  -11
    arc_1_14_15  out_degree_999  1
    arc_1_14_15  in_degree_1006  1
    arc_1_14_15  original_T_including_depot_unload_1042  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_851  1
    load_1_14_15  free_load_conservation_1004  1
    load_1_14_15  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_853  -25
    arc_1_14_16  connected_order_arc_854  -11
    arc_1_14_16  out_degree_999  1
    arc_1_14_16  in_degree_1012  1
    arc_1_14_16  original_T_including_depot_unload_1042  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_853  1
    load_1_14_16  free_load_conservation_1004  1
    load_1_14_16  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_855  -25
    arc_1_14_17  connected_order_arc_856  -11
    arc_1_14_17  out_degree_999  1
    arc_1_14_17  in_degree_1018  1
    arc_1_14_17  original_T_including_depot_unload_1042  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_855  1
    load_1_14_17  free_load_conservation_1004  1
    load_1_14_17  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_857  -25
    arc_1_14_18  connected_order_arc_858  -11
    arc_1_14_18  out_degree_999  1
    arc_1_14_18  in_degree_1024  1
    arc_1_14_18  original_T_including_depot_unload_1042  3.7840168155842611e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_857  1
    load_1_14_18  free_load_conservation_1004  1
    load_1_14_18  free_load_conservation_1028  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_859  -25
    arc_1_14_19  connected_order_arc_860  -11
    arc_1_14_19  out_degree_999  1
    arc_1_14_19  in_degree_1030  1
    arc_1_14_19  original_T_including_depot_unload_1042  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_859  1
    load_1_14_19  free_load_conservation_1004  1
    load_1_14_19  free_load_conservation_1034  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_861  -25
    arc_1_14_20  connected_order_arc_862  -11
    arc_1_14_20  out_degree_999  1
    arc_1_14_20  in_degree_1036  1
    arc_1_14_20  original_T_including_depot_unload_1042  4.8778172744463808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_861  1
    load_1_14_20  free_load_conservation_1004  1
    load_1_14_20  free_load_conservation_1040  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_863  -25
    arc_1_15_0  depot_return_or_bypass_978  1
    arc_1_15_0  out_degree_1005  1
    arc_1_15_0  original_T_including_depot_unload_1042  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_863  1
    load_1_15_0  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_864  -25
    arc_1_15_6  connected_order_arc_865  -11
    arc_1_15_6  in_degree_980  1
    arc_1_15_6  out_degree_1005  1
    arc_1_15_6  original_T_including_depot_unload_1042  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_864  1
    load_1_15_6  segment_load_conservation_983  -1
    load_1_15_6  segment_prefix_lb_984  1
    load_1_15_6  segment_prefix_ub_985  1
    load_1_15_6  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_866  -25
    arc_1_15_7  connected_order_arc_867  -11
    arc_1_15_7  in_degree_987  1
    arc_1_15_7  out_degree_1005  1
    arc_1_15_7  original_T_including_depot_unload_1042  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_866  1
    load_1_15_7  segment_load_conservation_990  -1
    load_1_15_7  segment_prefix_lb_991  1
    load_1_15_7  segment_prefix_ub_992  1
    load_1_15_7  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_868  -25
    arc_1_15_13  connected_order_arc_869  -11
    arc_1_15_13  in_degree_994  1
    arc_1_15_13  out_degree_1005  1
    arc_1_15_13  original_T_including_depot_unload_1042  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_868  1
    load_1_15_13  free_load_conservation_998  -1
    load_1_15_13  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_870  -25
    arc_1_15_14  connected_order_arc_871  -11
    arc_1_15_14  in_degree_1000  1
    arc_1_15_14  out_degree_1005  1
    arc_1_15_14  original_T_including_depot_unload_1042  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_870  1
    load_1_15_14  free_load_conservation_1004  -1
    load_1_15_14  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_872  -25
    arc_1_15_16  connected_order_arc_873  -11
    arc_1_15_16  out_degree_1005  1
    arc_1_15_16  in_degree_1012  1
    arc_1_15_16  original_T_including_depot_unload_1042  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_872  1
    load_1_15_16  free_load_conservation_1010  1
    load_1_15_16  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_874  -25
    arc_1_15_17  connected_order_arc_875  -11
    arc_1_15_17  out_degree_1005  1
    arc_1_15_17  in_degree_1018  1
    arc_1_15_17  original_T_including_depot_unload_1042  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_874  1
    load_1_15_17  free_load_conservation_1010  1
    load_1_15_17  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_876  -25
    arc_1_15_18  connected_order_arc_877  -11
    arc_1_15_18  out_degree_1005  1
    arc_1_15_18  in_degree_1024  1
    arc_1_15_18  original_T_including_depot_unload_1042  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_876  1
    load_1_15_18  free_load_conservation_1010  1
    load_1_15_18  free_load_conservation_1028  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_878  -25
    arc_1_15_19  connected_order_arc_879  -11
    arc_1_15_19  out_degree_1005  1
    arc_1_15_19  in_degree_1030  1
    arc_1_15_19  original_T_including_depot_unload_1042  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_878  1
    load_1_15_19  free_load_conservation_1010  1
    load_1_15_19  free_load_conservation_1034  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_880  -25
    arc_1_15_20  connected_order_arc_881  -11
    arc_1_15_20  out_degree_1005  1
    arc_1_15_20  in_degree_1036  1
    arc_1_15_20  original_T_including_depot_unload_1042  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_880  1
    load_1_15_20  free_load_conservation_1010  1
    load_1_15_20  free_load_conservation_1040  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_882  -25
    arc_1_16_0  depot_return_or_bypass_978  1
    arc_1_16_0  out_degree_1011  1
    arc_1_16_0  original_T_including_depot_unload_1042  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_882  1
    load_1_16_0  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_883  -25
    arc_1_16_6  connected_order_arc_884  -11
    arc_1_16_6  in_degree_980  1
    arc_1_16_6  out_degree_1011  1
    arc_1_16_6  original_T_including_depot_unload_1042  1.0819844298451576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_883  1
    load_1_16_6  segment_load_conservation_983  -1
    load_1_16_6  segment_prefix_lb_984  1
    load_1_16_6  segment_prefix_ub_985  1
    load_1_16_6  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_885  -25
    arc_1_16_7  connected_order_arc_886  -11
    arc_1_16_7  in_degree_987  1
    arc_1_16_7  out_degree_1011  1
    arc_1_16_7  original_T_including_depot_unload_1042  1.0359917537364215e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_885  1
    load_1_16_7  segment_load_conservation_990  -1
    load_1_16_7  segment_prefix_lb_991  1
    load_1_16_7  segment_prefix_ub_992  1
    load_1_16_7  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_887  -25
    arc_1_16_13  connected_order_arc_888  -11
    arc_1_16_13  in_degree_994  1
    arc_1_16_13  out_degree_1011  1
    arc_1_16_13  original_T_including_depot_unload_1042  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_887  1
    load_1_16_13  free_load_conservation_998  -1
    load_1_16_13  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_889  -25
    arc_1_16_14  connected_order_arc_890  -11
    arc_1_16_14  in_degree_1000  1
    arc_1_16_14  out_degree_1011  1
    arc_1_16_14  original_T_including_depot_unload_1042  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_889  1
    load_1_16_14  free_load_conservation_1004  -1
    load_1_16_14  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_891  -25
    arc_1_16_15  connected_order_arc_892  -11
    arc_1_16_15  in_degree_1006  1
    arc_1_16_15  out_degree_1011  1
    arc_1_16_15  original_T_including_depot_unload_1042  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_891  1
    load_1_16_15  free_load_conservation_1010  -1
    load_1_16_15  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_893  -25
    arc_1_16_17  connected_order_arc_894  -11
    arc_1_16_17  out_degree_1011  1
    arc_1_16_17  in_degree_1018  1
    arc_1_16_17  original_T_including_depot_unload_1042  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_893  1
    load_1_16_17  free_load_conservation_1016  1
    load_1_16_17  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_895  -25
    arc_1_16_18  connected_order_arc_896  -11
    arc_1_16_18  out_degree_1011  1
    arc_1_16_18  in_degree_1024  1
    arc_1_16_18  original_T_including_depot_unload_1042  6.7500260835612892e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_895  1
    load_1_16_18  free_load_conservation_1016  1
    load_1_16_18  free_load_conservation_1028  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_897  -25
    arc_1_16_19  connected_order_arc_898  -11
    arc_1_16_19  out_degree_1011  1
    arc_1_16_19  in_degree_1030  1
    arc_1_16_19  original_T_including_depot_unload_1042  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_897  1
    load_1_16_19  free_load_conservation_1016  1
    load_1_16_19  free_load_conservation_1034  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_899  -25
    arc_1_16_20  connected_order_arc_900  -11
    arc_1_16_20  out_degree_1011  1
    arc_1_16_20  in_degree_1036  1
    arc_1_16_20  original_T_including_depot_unload_1042  7.7576476069541832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_899  1
    load_1_16_20  free_load_conservation_1016  1
    load_1_16_20  free_load_conservation_1040  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_901  -25
    arc_1_17_0  depot_return_or_bypass_978  1
    arc_1_17_0  out_degree_1017  1
    arc_1_17_0  original_T_including_depot_unload_1042  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_901  1
    load_1_17_0  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_902  -25
    arc_1_17_6  connected_order_arc_903  -11
    arc_1_17_6  in_degree_980  1
    arc_1_17_6  out_degree_1017  1
    arc_1_17_6  original_T_including_depot_unload_1042  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_902  1
    load_1_17_6  segment_load_conservation_983  -1
    load_1_17_6  segment_prefix_lb_984  1
    load_1_17_6  segment_prefix_ub_985  1
    load_1_17_6  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_904  -25
    arc_1_17_7  connected_order_arc_905  -11
    arc_1_17_7  in_degree_987  1
    arc_1_17_7  out_degree_1017  1
    arc_1_17_7  original_T_including_depot_unload_1042  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_904  1
    load_1_17_7  segment_load_conservation_990  -1
    load_1_17_7  segment_prefix_lb_991  1
    load_1_17_7  segment_prefix_ub_992  1
    load_1_17_7  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_906  -25
    arc_1_17_13  connected_order_arc_907  -11
    arc_1_17_13  in_degree_994  1
    arc_1_17_13  out_degree_1017  1
    arc_1_17_13  original_T_including_depot_unload_1042  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_906  1
    load_1_17_13  free_load_conservation_998  -1
    load_1_17_13  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_908  -25
    arc_1_17_14  connected_order_arc_909  -11
    arc_1_17_14  in_degree_1000  1
    arc_1_17_14  out_degree_1017  1
    arc_1_17_14  original_T_including_depot_unload_1042  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_908  1
    load_1_17_14  free_load_conservation_1004  -1
    load_1_17_14  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_910  -25
    arc_1_17_15  connected_order_arc_911  -11
    arc_1_17_15  in_degree_1006  1
    arc_1_17_15  out_degree_1017  1
    arc_1_17_15  original_T_including_depot_unload_1042  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_910  1
    load_1_17_15  free_load_conservation_1010  -1
    load_1_17_15  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_912  -25
    arc_1_17_16  connected_order_arc_913  -11
    arc_1_17_16  in_degree_1012  1
    arc_1_17_16  out_degree_1017  1
    arc_1_17_16  original_T_including_depot_unload_1042  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_912  1
    load_1_17_16  free_load_conservation_1016  -1
    load_1_17_16  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_914  -25
    arc_1_17_18  connected_order_arc_915  -11
    arc_1_17_18  out_degree_1017  1
    arc_1_17_18  in_degree_1024  1
    arc_1_17_18  original_T_including_depot_unload_1042  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_914  1
    load_1_17_18  free_load_conservation_1022  1
    load_1_17_18  free_load_conservation_1028  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_916  -25
    arc_1_17_19  connected_order_arc_917  -11
    arc_1_17_19  out_degree_1017  1
    arc_1_17_19  in_degree_1030  1
    arc_1_17_19  original_T_including_depot_unload_1042  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_916  1
    load_1_17_19  free_load_conservation_1022  1
    load_1_17_19  free_load_conservation_1034  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_918  -25
    arc_1_17_20  connected_order_arc_919  -11
    arc_1_17_20  out_degree_1017  1
    arc_1_17_20  in_degree_1036  1
    arc_1_17_20  original_T_including_depot_unload_1042  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_918  1
    load_1_17_20  free_load_conservation_1022  1
    load_1_17_20  free_load_conservation_1040  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_920  -25
    arc_1_18_0  depot_return_or_bypass_978  1
    arc_1_18_0  out_degree_1023  1
    arc_1_18_0  original_T_including_depot_unload_1042  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_920  1
    load_1_18_0  free_load_conservation_1028  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_921  -25
    arc_1_18_6  connected_order_arc_922  -11
    arc_1_18_6  in_degree_980  1
    arc_1_18_6  out_degree_1023  1
    arc_1_18_6  original_T_including_depot_unload_1042  1.5634365646683834e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_921  1
    load_1_18_6  segment_load_conservation_983  -1
    load_1_18_6  segment_prefix_lb_984  1
    load_1_18_6  segment_prefix_ub_985  1
    load_1_18_6  free_load_conservation_1028  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_923  -25
    arc_1_18_7  connected_order_arc_924  -11
    arc_1_18_7  in_degree_987  1
    arc_1_18_7  out_degree_1023  1
    arc_1_18_7  original_T_including_depot_unload_1042  1.0271253855277889e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_923  1
    load_1_18_7  segment_load_conservation_990  -1
    load_1_18_7  segment_prefix_lb_991  1
    load_1_18_7  segment_prefix_ub_992  1
    load_1_18_7  free_load_conservation_1028  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_925  -25
    arc_1_18_13  connected_order_arc_926  -11
    arc_1_18_13  in_degree_994  1
    arc_1_18_13  out_degree_1023  1
    arc_1_18_13  original_T_including_depot_unload_1042  5.3222543932043470e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_925  1
    load_1_18_13  free_load_conservation_998  -1
    load_1_18_13  free_load_conservation_1028  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_927  -25
    arc_1_18_14  connected_order_arc_928  -11
    arc_1_18_14  in_degree_1000  1
    arc_1_18_14  out_degree_1023  1
    arc_1_18_14  original_T_including_depot_unload_1042  3.7840168155842611e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_927  1
    load_1_18_14  free_load_conservation_1004  -1
    load_1_18_14  free_load_conservation_1028  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_929  -25
    arc_1_18_15  connected_order_arc_930  -11
    arc_1_18_15  in_degree_1006  1
    arc_1_18_15  out_degree_1023  1
    arc_1_18_15  original_T_including_depot_unload_1042  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_929  1
    load_1_18_15  free_load_conservation_1010  -1
    load_1_18_15  free_load_conservation_1028  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_931  -25
    arc_1_18_16  connected_order_arc_932  -11
    arc_1_18_16  in_degree_1012  1
    arc_1_18_16  out_degree_1023  1
    arc_1_18_16  original_T_including_depot_unload_1042  6.7500260835612892e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_931  1
    load_1_18_16  free_load_conservation_1016  -1
    load_1_18_16  free_load_conservation_1028  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_933  -25
    arc_1_18_17  connected_order_arc_934  -11
    arc_1_18_17  in_degree_1018  1
    arc_1_18_17  out_degree_1023  1
    arc_1_18_17  original_T_including_depot_unload_1042  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_933  1
    load_1_18_17  free_load_conservation_1022  -1
    load_1_18_17  free_load_conservation_1028  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_935  -25
    arc_1_18_19  connected_order_arc_936  -11
    arc_1_18_19  out_degree_1023  1
    arc_1_18_19  in_degree_1030  1
    arc_1_18_19  original_T_including_depot_unload_1042  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_935  1
    load_1_18_19  free_load_conservation_1028  1
    load_1_18_19  free_load_conservation_1034  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_937  -25
    arc_1_18_20  connected_order_arc_938  -11
    arc_1_18_20  out_degree_1023  1
    arc_1_18_20  in_degree_1036  1
    arc_1_18_20  original_T_including_depot_unload_1042  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_937  1
    load_1_18_20  free_load_conservation_1028  1
    load_1_18_20  free_load_conservation_1040  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_939  -25
    arc_1_19_0  depot_return_or_bypass_978  1
    arc_1_19_0  out_degree_1029  1
    arc_1_19_0  original_T_including_depot_unload_1042  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_939  1
    load_1_19_0  free_load_conservation_1034  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_940  -25
    arc_1_19_6  connected_order_arc_941  -11
    arc_1_19_6  in_degree_980  1
    arc_1_19_6  out_degree_1029  1
    arc_1_19_6  original_T_including_depot_unload_1042  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_940  1
    load_1_19_6  segment_load_conservation_983  -1
    load_1_19_6  segment_prefix_lb_984  1
    load_1_19_6  segment_prefix_ub_985  1
    load_1_19_6  free_load_conservation_1034  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_942  -25
    arc_1_19_7  connected_order_arc_943  -11
    arc_1_19_7  in_degree_987  1
    arc_1_19_7  out_degree_1029  1
    arc_1_19_7  original_T_including_depot_unload_1042  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_942  1
    load_1_19_7  segment_load_conservation_990  -1
    load_1_19_7  segment_prefix_lb_991  1
    load_1_19_7  segment_prefix_ub_992  1
    load_1_19_7  free_load_conservation_1034  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_944  -25
    arc_1_19_13  connected_order_arc_945  -11
    arc_1_19_13  in_degree_994  1
    arc_1_19_13  out_degree_1029  1
    arc_1_19_13  original_T_including_depot_unload_1042  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_944  1
    load_1_19_13  free_load_conservation_998  -1
    load_1_19_13  free_load_conservation_1034  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_946  -25
    arc_1_19_14  connected_order_arc_947  -11
    arc_1_19_14  in_degree_1000  1
    arc_1_19_14  out_degree_1029  1
    arc_1_19_14  original_T_including_depot_unload_1042  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_946  1
    load_1_19_14  free_load_conservation_1004  -1
    load_1_19_14  free_load_conservation_1034  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_948  -25
    arc_1_19_15  connected_order_arc_949  -11
    arc_1_19_15  in_degree_1006  1
    arc_1_19_15  out_degree_1029  1
    arc_1_19_15  original_T_including_depot_unload_1042  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_948  1
    load_1_19_15  free_load_conservation_1010  -1
    load_1_19_15  free_load_conservation_1034  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_950  -25
    arc_1_19_16  connected_order_arc_951  -11
    arc_1_19_16  in_degree_1012  1
    arc_1_19_16  out_degree_1029  1
    arc_1_19_16  original_T_including_depot_unload_1042  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_950  1
    load_1_19_16  free_load_conservation_1016  -1
    load_1_19_16  free_load_conservation_1034  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_952  -25
    arc_1_19_17  connected_order_arc_953  -11
    arc_1_19_17  in_degree_1018  1
    arc_1_19_17  out_degree_1029  1
    arc_1_19_17  original_T_including_depot_unload_1042  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_952  1
    load_1_19_17  free_load_conservation_1022  -1
    load_1_19_17  free_load_conservation_1034  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_954  -25
    arc_1_19_18  connected_order_arc_955  -11
    arc_1_19_18  in_degree_1024  1
    arc_1_19_18  out_degree_1029  1
    arc_1_19_18  original_T_including_depot_unload_1042  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_954  1
    load_1_19_18  free_load_conservation_1028  -1
    load_1_19_18  free_load_conservation_1034  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_956  -25
    arc_1_19_20  connected_order_arc_957  -11
    arc_1_19_20  out_degree_1029  1
    arc_1_19_20  in_degree_1036  1
    arc_1_19_20  original_T_including_depot_unload_1042  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_956  1
    load_1_19_20  free_load_conservation_1034  1
    load_1_19_20  free_load_conservation_1040  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_958  -25
    arc_1_20_0  depot_return_or_bypass_978  1
    arc_1_20_0  out_degree_1035  1
    arc_1_20_0  original_T_including_depot_unload_1042  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_958  1
    load_1_20_0  free_load_conservation_1040  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_959  -25
    arc_1_20_6  connected_order_arc_960  -11
    arc_1_20_6  in_degree_980  1
    arc_1_20_6  out_degree_1035  1
    arc_1_20_6  original_T_including_depot_unload_1042  1.5639034270630727e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_959  1
    load_1_20_6  segment_load_conservation_983  -1
    load_1_20_6  segment_prefix_lb_984  1
    load_1_20_6  segment_prefix_ub_985  1
    load_1_20_6  free_load_conservation_1040  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_961  -25
    arc_1_20_7  connected_order_arc_962  -11
    arc_1_20_7  in_degree_987  1
    arc_1_20_7  out_degree_1035  1
    arc_1_20_7  original_T_including_depot_unload_1042  1.1885707701696851e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_961  1
    load_1_20_7  segment_load_conservation_990  -1
    load_1_20_7  segment_prefix_lb_991  1
    load_1_20_7  segment_prefix_ub_992  1
    load_1_20_7  free_load_conservation_1040  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_13  arc_capacity_963  -25
    arc_1_20_13  connected_order_arc_964  -11
    arc_1_20_13  in_degree_994  1
    arc_1_20_13  out_degree_1035  1
    arc_1_20_13  original_T_including_depot_unload_1042  552.429776828834
    MARKER    'MARKER'                 'INTEND'
    load_1_20_13  arc_capacity_963  1
    load_1_20_13  free_load_conservation_998  -1
    load_1_20_13  free_load_conservation_1040  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_965  -25
    arc_1_20_14  connected_order_arc_966  -11
    arc_1_20_14  in_degree_1000  1
    arc_1_20_14  out_degree_1035  1
    arc_1_20_14  original_T_including_depot_unload_1042  4.8778172744463808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_965  1
    load_1_20_14  free_load_conservation_1004  -1
    load_1_20_14  free_load_conservation_1040  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_967  -25
    arc_1_20_15  connected_order_arc_968  -11
    arc_1_20_15  in_degree_1006  1
    arc_1_20_15  out_degree_1035  1
    arc_1_20_15  original_T_including_depot_unload_1042  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_967  1
    load_1_20_15  free_load_conservation_1010  -1
    load_1_20_15  free_load_conservation_1040  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_969  -25
    arc_1_20_16  connected_order_arc_970  -11
    arc_1_20_16  in_degree_1012  1
    arc_1_20_16  out_degree_1035  1
    arc_1_20_16  original_T_including_depot_unload_1042  7.7576476069541832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_969  1
    load_1_20_16  free_load_conservation_1016  -1
    load_1_20_16  free_load_conservation_1040  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_971  -25
    arc_1_20_17  connected_order_arc_972  -11
    arc_1_20_17  in_degree_1018  1
    arc_1_20_17  out_degree_1035  1
    arc_1_20_17  original_T_including_depot_unload_1042  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_971  1
    load_1_20_17  free_load_conservation_1022  -1
    load_1_20_17  free_load_conservation_1040  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_973  -25
    arc_1_20_18  connected_order_arc_974  -11
    arc_1_20_18  in_degree_1024  1
    arc_1_20_18  out_degree_1035  1
    arc_1_20_18  original_T_including_depot_unload_1042  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_973  1
    load_1_20_18  free_load_conservation_1028  -1
    load_1_20_18  free_load_conservation_1040  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_975  -25
    arc_1_20_19  connected_order_arc_976  -11
    arc_1_20_19  in_degree_1030  1
    arc_1_20_19  out_degree_1035  1
    arc_1_20_19  original_T_including_depot_unload_1042  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_975  1
    load_1_20_19  free_load_conservation_1034  -1
    load_1_20_19  free_load_conservation_1040  1
    visit_2_8  out_degree_1384  -1
    visit_2_8  in_degree_1385  -1
    visit_2_8  order_active_lb_1386  -1
    visit_2_8  order_active_ub_1387  -13
    order_2_8  connected_order_arc_1059  -1
    order_2_8  connected_order_arc_1061  -1
    order_2_8  connected_order_arc_1063  -1
    order_2_8  connected_order_arc_1065  -1
    order_2_8  connected_order_arc_1067  -1
    order_2_8  connected_order_arc_1069  -1
    order_2_8  connected_order_arc_1071  -1
    order_2_8  connected_order_arc_1073  -1
    order_2_8  connected_order_arc_1075  -1
    order_2_8  connected_order_arc_1077  -1
    order_2_8  connected_order_arc_1079  -1
    order_2_8  connected_order_arc_1081  -1
    order_2_8  connected_order_arc_1084  1
    order_2_8  connected_order_arc_1109  1
    order_2_8  connected_order_arc_1134  1
    order_2_8  connected_order_arc_1159  1
    order_2_8  connected_order_arc_1184  1
    order_2_8  connected_order_arc_1209  1
    order_2_8  connected_order_arc_1234  1
    order_2_8  connected_order_arc_1259  1
    order_2_8  connected_order_arc_1284  1
    order_2_8  connected_order_arc_1309  1
    order_2_8  connected_order_arc_1334  1
    order_2_8  connected_order_arc_1359  1
    order_2_8  order_active_lb_1386  1
    order_2_8  order_active_ub_1387  1
    order_2_8  fixed_segment_relative_order_1467  -1
    visit_2_9  out_degree_1391  -1
    visit_2_9  in_degree_1392  -1
    visit_2_9  order_active_lb_1393  -1
    visit_2_9  order_active_ub_1394  -13
    order_2_9  connected_order_arc_1059  1
    order_2_9  connected_order_arc_1084  -1
    order_2_9  connected_order_arc_1086  -1
    order_2_9  connected_order_arc_1088  -1
    order_2_9  connected_order_arc_1090  -1
    order_2_9  connected_order_arc_1092  -1
    order_2_9  connected_order_arc_1094  -1
    order_2_9  connected_order_arc_1096  -1
    order_2_9  connected_order_arc_1098  -1
    order_2_9  connected_order_arc_1100  -1
    order_2_9  connected_order_arc_1102  -1
    order_2_9  connected_order_arc_1104  -1
    order_2_9  connected_order_arc_1106  -1
    order_2_9  connected_order_arc_1111  1
    order_2_9  connected_order_arc_1136  1
    order_2_9  connected_order_arc_1161  1
    order_2_9  connected_order_arc_1186  1
    order_2_9  connected_order_arc_1211  1
    order_2_9  connected_order_arc_1236  1
    order_2_9  connected_order_arc_1261  1
    order_2_9  connected_order_arc_1286  1
    order_2_9  connected_order_arc_1311  1
    order_2_9  connected_order_arc_1336  1
    order_2_9  connected_order_arc_1361  1
    order_2_9  order_active_lb_1393  1
    order_2_9  order_active_ub_1394  1
    order_2_9  fixed_segment_relative_order_1467  1
    order_2_9  fixed_segment_relative_order_1468  -1
    visit_2_10  out_degree_1398  -1
    visit_2_10  in_degree_1399  -1
    visit_2_10  order_active_lb_1400  -1
    visit_2_10  order_active_ub_1401  -13
    order_2_10  connected_order_arc_1061  1
    order_2_10  connected_order_arc_1086  1
    order_2_10  connected_order_arc_1109  -1
    order_2_10  connected_order_arc_1111  -1
    order_2_10  connected_order_arc_1113  -1
    order_2_10  connected_order_arc_1115  -1
    order_2_10  connected_order_arc_1117  -1
    order_2_10  connected_order_arc_1119  -1
    order_2_10  connected_order_arc_1121  -1
    order_2_10  connected_order_arc_1123  -1
    order_2_10  connected_order_arc_1125  -1
    order_2_10  connected_order_arc_1127  -1
    order_2_10  connected_order_arc_1129  -1
    order_2_10  connected_order_arc_1131  -1
    order_2_10  connected_order_arc_1138  1
    order_2_10  connected_order_arc_1163  1
    order_2_10  connected_order_arc_1188  1
    order_2_10  connected_order_arc_1213  1
    order_2_10  connected_order_arc_1238  1
    order_2_10  connected_order_arc_1263  1
    order_2_10  connected_order_arc_1288  1
    order_2_10  connected_order_arc_1313  1
    order_2_10  connected_order_arc_1338  1
    order_2_10  connected_order_arc_1363  1
    order_2_10  order_active_lb_1400  1
    order_2_10  order_active_ub_1401  1
    order_2_10  fixed_segment_relative_order_1468  1
    order_2_10  fixed_segment_relative_order_1469  -1
    visit_2_11  out_degree_1405  -1
    visit_2_11  in_degree_1406  -1
    visit_2_11  order_active_lb_1407  -1
    visit_2_11  order_active_ub_1408  -13
    order_2_11  connected_order_arc_1063  1
    order_2_11  connected_order_arc_1088  1
    order_2_11  connected_order_arc_1113  1
    order_2_11  connected_order_arc_1134  -1
    order_2_11  connected_order_arc_1136  -1
    order_2_11  connected_order_arc_1138  -1
    order_2_11  connected_order_arc_1140  -1
    order_2_11  connected_order_arc_1142  -1
    order_2_11  connected_order_arc_1144  -1
    order_2_11  connected_order_arc_1146  -1
    order_2_11  connected_order_arc_1148  -1
    order_2_11  connected_order_arc_1150  -1
    order_2_11  connected_order_arc_1152  -1
    order_2_11  connected_order_arc_1154  -1
    order_2_11  connected_order_arc_1156  -1
    order_2_11  connected_order_arc_1165  1
    order_2_11  connected_order_arc_1190  1
    order_2_11  connected_order_arc_1215  1
    order_2_11  connected_order_arc_1240  1
    order_2_11  connected_order_arc_1265  1
    order_2_11  connected_order_arc_1290  1
    order_2_11  connected_order_arc_1315  1
    order_2_11  connected_order_arc_1340  1
    order_2_11  connected_order_arc_1365  1
    order_2_11  order_active_lb_1407  1
    order_2_11  order_active_ub_1408  1
    order_2_11  fixed_segment_relative_order_1469  1
    order_2_11  fixed_segment_relative_order_1470  -1
    visit_2_12  out_degree_1412  -1
    visit_2_12  in_degree_1413  -1
    visit_2_12  order_active_lb_1414  -1
    visit_2_12  order_active_ub_1415  -13
    order_2_12  connected_order_arc_1065  1
    order_2_12  connected_order_arc_1090  1
    order_2_12  connected_order_arc_1115  1
    order_2_12  connected_order_arc_1140  1
    order_2_12  connected_order_arc_1159  -1
    order_2_12  connected_order_arc_1161  -1
    order_2_12  connected_order_arc_1163  -1
    order_2_12  connected_order_arc_1165  -1
    order_2_12  connected_order_arc_1167  -1
    order_2_12  connected_order_arc_1169  -1
    order_2_12  connected_order_arc_1171  -1
    order_2_12  connected_order_arc_1173  -1
    order_2_12  connected_order_arc_1175  -1
    order_2_12  connected_order_arc_1177  -1
    order_2_12  connected_order_arc_1179  -1
    order_2_12  connected_order_arc_1181  -1
    order_2_12  connected_order_arc_1192  1
    order_2_12  connected_order_arc_1217  1
    order_2_12  connected_order_arc_1242  1
    order_2_12  connected_order_arc_1267  1
    order_2_12  connected_order_arc_1292  1
    order_2_12  connected_order_arc_1317  1
    order_2_12  connected_order_arc_1342  1
    order_2_12  connected_order_arc_1367  1
    order_2_12  order_active_lb_1414  1
    order_2_12  order_active_ub_1415  1
    order_2_12  fixed_segment_relative_order_1470  1
    visit_2_13  out_degree_1419  -1
    visit_2_13  in_degree_1420  -1
    visit_2_13  order_active_lb_1421  -1
    visit_2_13  order_active_ub_1422  -13
    visit_2_13  service_visit_def_1423  -1
    order_2_13  connected_order_arc_1067  1
    order_2_13  connected_order_arc_1092  1
    order_2_13  connected_order_arc_1117  1
    order_2_13  connected_order_arc_1142  1
    order_2_13  connected_order_arc_1167  1
    order_2_13  connected_order_arc_1184  -1
    order_2_13  connected_order_arc_1186  -1
    order_2_13  connected_order_arc_1188  -1
    order_2_13  connected_order_arc_1190  -1
    order_2_13  connected_order_arc_1192  -1
    order_2_13  connected_order_arc_1194  -1
    order_2_13  connected_order_arc_1196  -1
    order_2_13  connected_order_arc_1198  -1
    order_2_13  connected_order_arc_1200  -1
    order_2_13  connected_order_arc_1202  -1
    order_2_13  connected_order_arc_1204  -1
    order_2_13  connected_order_arc_1206  -1
    order_2_13  connected_order_arc_1219  1
    order_2_13  connected_order_arc_1244  1
    order_2_13  connected_order_arc_1269  1
    order_2_13  connected_order_arc_1294  1
    order_2_13  connected_order_arc_1319  1
    order_2_13  connected_order_arc_1344  1
    order_2_13  connected_order_arc_1369  1
    order_2_13  order_active_lb_1421  1
    order_2_13  order_active_ub_1422  1
    visit_2_14  out_degree_1425  -1
    visit_2_14  in_degree_1426  -1
    visit_2_14  order_active_lb_1427  -1
    visit_2_14  order_active_ub_1428  -13
    visit_2_14  service_visit_def_1429  -1
    order_2_14  connected_order_arc_1069  1
    order_2_14  connected_order_arc_1094  1
    order_2_14  connected_order_arc_1119  1
    order_2_14  connected_order_arc_1144  1
    order_2_14  connected_order_arc_1169  1
    order_2_14  connected_order_arc_1194  1
    order_2_14  connected_order_arc_1209  -1
    order_2_14  connected_order_arc_1211  -1
    order_2_14  connected_order_arc_1213  -1
    order_2_14  connected_order_arc_1215  -1
    order_2_14  connected_order_arc_1217  -1
    order_2_14  connected_order_arc_1219  -1
    order_2_14  connected_order_arc_1221  -1
    order_2_14  connected_order_arc_1223  -1
    order_2_14  connected_order_arc_1225  -1
    order_2_14  connected_order_arc_1227  -1
    order_2_14  connected_order_arc_1229  -1
    order_2_14  connected_order_arc_1231  -1
    order_2_14  connected_order_arc_1246  1
    order_2_14  connected_order_arc_1271  1
    order_2_14  connected_order_arc_1296  1
    order_2_14  connected_order_arc_1321  1
    order_2_14  connected_order_arc_1346  1
    order_2_14  connected_order_arc_1371  1
    order_2_14  order_active_lb_1427  1
    order_2_14  order_active_ub_1428  1
    visit_2_15  out_degree_1431  -1
    visit_2_15  in_degree_1432  -1
    visit_2_15  order_active_lb_1433  -1
    visit_2_15  order_active_ub_1434  -13
    visit_2_15  service_visit_def_1435  -1
    order_2_15  connected_order_arc_1071  1
    order_2_15  connected_order_arc_1096  1
    order_2_15  connected_order_arc_1121  1
    order_2_15  connected_order_arc_1146  1
    order_2_15  connected_order_arc_1171  1
    order_2_15  connected_order_arc_1196  1
    order_2_15  connected_order_arc_1221  1
    order_2_15  connected_order_arc_1234  -1
    order_2_15  connected_order_arc_1236  -1
    order_2_15  connected_order_arc_1238  -1
    order_2_15  connected_order_arc_1240  -1
    order_2_15  connected_order_arc_1242  -1
    order_2_15  connected_order_arc_1244  -1
    order_2_15  connected_order_arc_1246  -1
    order_2_15  connected_order_arc_1248  -1
    order_2_15  connected_order_arc_1250  -1
    order_2_15  connected_order_arc_1252  -1
    order_2_15  connected_order_arc_1254  -1
    order_2_15  connected_order_arc_1256  -1
    order_2_15  connected_order_arc_1273  1
    order_2_15  connected_order_arc_1298  1
    order_2_15  connected_order_arc_1323  1
    order_2_15  connected_order_arc_1348  1
    order_2_15  connected_order_arc_1373  1
    order_2_15  order_active_lb_1433  1
    order_2_15  order_active_ub_1434  1
    visit_2_16  out_degree_1437  -1
    visit_2_16  in_degree_1438  -1
    visit_2_16  order_active_lb_1439  -1
    visit_2_16  order_active_ub_1440  -13
    visit_2_16  service_visit_def_1441  -1
    order_2_16  connected_order_arc_1073  1
    order_2_16  connected_order_arc_1098  1
    order_2_16  connected_order_arc_1123  1
    order_2_16  connected_order_arc_1148  1
    order_2_16  connected_order_arc_1173  1
    order_2_16  connected_order_arc_1198  1
    order_2_16  connected_order_arc_1223  1
    order_2_16  connected_order_arc_1248  1
    order_2_16  connected_order_arc_1259  -1
    order_2_16  connected_order_arc_1261  -1
    order_2_16  connected_order_arc_1263  -1
    order_2_16  connected_order_arc_1265  -1
    order_2_16  connected_order_arc_1267  -1
    order_2_16  connected_order_arc_1269  -1
    order_2_16  connected_order_arc_1271  -1
    order_2_16  connected_order_arc_1273  -1
    order_2_16  connected_order_arc_1275  -1
    order_2_16  connected_order_arc_1277  -1
    order_2_16  connected_order_arc_1279  -1
    order_2_16  connected_order_arc_1281  -1
    order_2_16  connected_order_arc_1300  1
    order_2_16  connected_order_arc_1325  1
    order_2_16  connected_order_arc_1350  1
    order_2_16  connected_order_arc_1375  1
    order_2_16  order_active_lb_1439  1
    order_2_16  order_active_ub_1440  1
    visit_2_17  out_degree_1443  -1
    visit_2_17  in_degree_1444  -1
    visit_2_17  order_active_lb_1445  -1
    visit_2_17  order_active_ub_1446  -13
    visit_2_17  service_visit_def_1447  -1
    order_2_17  connected_order_arc_1075  1
    order_2_17  connected_order_arc_1100  1
    order_2_17  connected_order_arc_1125  1
    order_2_17  connected_order_arc_1150  1
    order_2_17  connected_order_arc_1175  1
    order_2_17  connected_order_arc_1200  1
    order_2_17  connected_order_arc_1225  1
    order_2_17  connected_order_arc_1250  1
    order_2_17  connected_order_arc_1275  1
    order_2_17  connected_order_arc_1284  -1
    order_2_17  connected_order_arc_1286  -1
    order_2_17  connected_order_arc_1288  -1
    order_2_17  connected_order_arc_1290  -1
    order_2_17  connected_order_arc_1292  -1
    order_2_17  connected_order_arc_1294  -1
    order_2_17  connected_order_arc_1296  -1
    order_2_17  connected_order_arc_1298  -1
    order_2_17  connected_order_arc_1300  -1
    order_2_17  connected_order_arc_1302  -1
    order_2_17  connected_order_arc_1304  -1
    order_2_17  connected_order_arc_1306  -1
    order_2_17  connected_order_arc_1327  1
    order_2_17  connected_order_arc_1352  1
    order_2_17  connected_order_arc_1377  1
    order_2_17  order_active_lb_1445  1
    order_2_17  order_active_ub_1446  1
    visit_2_18  out_degree_1449  -1
    visit_2_18  in_degree_1450  -1
    visit_2_18  order_active_lb_1451  -1
    visit_2_18  order_active_ub_1452  -13
    visit_2_18  service_visit_def_1453  -1
    order_2_18  connected_order_arc_1077  1
    order_2_18  connected_order_arc_1102  1
    order_2_18  connected_order_arc_1127  1
    order_2_18  connected_order_arc_1152  1
    order_2_18  connected_order_arc_1177  1
    order_2_18  connected_order_arc_1202  1
    order_2_18  connected_order_arc_1227  1
    order_2_18  connected_order_arc_1252  1
    order_2_18  connected_order_arc_1277  1
    order_2_18  connected_order_arc_1302  1
    order_2_18  connected_order_arc_1309  -1
    order_2_18  connected_order_arc_1311  -1
    order_2_18  connected_order_arc_1313  -1
    order_2_18  connected_order_arc_1315  -1
    order_2_18  connected_order_arc_1317  -1
    order_2_18  connected_order_arc_1319  -1
    order_2_18  connected_order_arc_1321  -1
    order_2_18  connected_order_arc_1323  -1
    order_2_18  connected_order_arc_1325  -1
    order_2_18  connected_order_arc_1327  -1
    order_2_18  connected_order_arc_1329  -1
    order_2_18  connected_order_arc_1331  -1
    order_2_18  connected_order_arc_1354  1
    order_2_18  connected_order_arc_1379  1
    order_2_18  order_active_lb_1451  1
    order_2_18  order_active_ub_1452  1
    visit_2_19  out_degree_1455  -1
    visit_2_19  in_degree_1456  -1
    visit_2_19  order_active_lb_1457  -1
    visit_2_19  order_active_ub_1458  -13
    visit_2_19  service_visit_def_1459  -1
    order_2_19  connected_order_arc_1079  1
    order_2_19  connected_order_arc_1104  1
    order_2_19  connected_order_arc_1129  1
    order_2_19  connected_order_arc_1154  1
    order_2_19  connected_order_arc_1179  1
    order_2_19  connected_order_arc_1204  1
    order_2_19  connected_order_arc_1229  1
    order_2_19  connected_order_arc_1254  1
    order_2_19  connected_order_arc_1279  1
    order_2_19  connected_order_arc_1304  1
    order_2_19  connected_order_arc_1329  1
    order_2_19  connected_order_arc_1334  -1
    order_2_19  connected_order_arc_1336  -1
    order_2_19  connected_order_arc_1338  -1
    order_2_19  connected_order_arc_1340  -1
    order_2_19  connected_order_arc_1342  -1
    order_2_19  connected_order_arc_1344  -1
    order_2_19  connected_order_arc_1346  -1
    order_2_19  connected_order_arc_1348  -1
    order_2_19  connected_order_arc_1350  -1
    order_2_19  connected_order_arc_1352  -1
    order_2_19  connected_order_arc_1354  -1
    order_2_19  connected_order_arc_1356  -1
    order_2_19  connected_order_arc_1381  1
    order_2_19  order_active_lb_1457  1
    order_2_19  order_active_ub_1458  1
    visit_2_20  out_degree_1461  -1
    visit_2_20  in_degree_1462  -1
    visit_2_20  order_active_lb_1463  -1
    visit_2_20  order_active_ub_1464  -13
    visit_2_20  service_visit_def_1465  -1
    order_2_20  connected_order_arc_1081  1
    order_2_20  connected_order_arc_1106  1
    order_2_20  connected_order_arc_1131  1
    order_2_20  connected_order_arc_1156  1
    order_2_20  connected_order_arc_1181  1
    order_2_20  connected_order_arc_1206  1
    order_2_20  connected_order_arc_1231  1
    order_2_20  connected_order_arc_1256  1
    order_2_20  connected_order_arc_1281  1
    order_2_20  connected_order_arc_1306  1
    order_2_20  connected_order_arc_1331  1
    order_2_20  connected_order_arc_1356  1
    order_2_20  connected_order_arc_1359  -1
    order_2_20  connected_order_arc_1361  -1
    order_2_20  connected_order_arc_1363  -1
    order_2_20  connected_order_arc_1365  -1
    order_2_20  connected_order_arc_1367  -1
    order_2_20  connected_order_arc_1369  -1
    order_2_20  connected_order_arc_1371  -1
    order_2_20  connected_order_arc_1373  -1
    order_2_20  connected_order_arc_1375  -1
    order_2_20  connected_order_arc_1377  -1
    order_2_20  connected_order_arc_1379  -1
    order_2_20  connected_order_arc_1381  -1
    order_2_20  order_active_lb_1463  1
    order_2_20  order_active_ub_1464  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1043  -30
    arc_2_0_0  depot_departure_or_bypass_1382  1
    arc_2_0_0  depot_return_or_bypass_1383  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1043  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_8  arc_capacity_1044  -30
    arc_2_0_8  depot_departure_or_bypass_1382  1
    arc_2_0_8  in_degree_1385  1
    arc_2_0_8  original_T_including_depot_unload_1471  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_8  arc_capacity_1044  1
    load_2_0_8  segment_load_conservation_1388  -1
    load_2_0_8  segment_prefix_lb_1389  1
    load_2_0_8  segment_prefix_ub_1390  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_9  arc_capacity_1045  -30
    arc_2_0_9  depot_departure_or_bypass_1382  1
    arc_2_0_9  in_degree_1392  1
    arc_2_0_9  original_T_including_depot_unload_1471  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_9  arc_capacity_1045  1
    load_2_0_9  segment_load_conservation_1395  -1
    load_2_0_9  segment_prefix_lb_1396  1
    load_2_0_9  segment_prefix_ub_1397  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1046  -30
    arc_2_0_10  depot_departure_or_bypass_1382  1
    arc_2_0_10  in_degree_1399  1
    arc_2_0_10  original_T_including_depot_unload_1471  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1046  1
    load_2_0_10  segment_load_conservation_1402  -1
    load_2_0_10  segment_prefix_lb_1403  1
    load_2_0_10  segment_prefix_ub_1404  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1047  -30
    arc_2_0_11  depot_departure_or_bypass_1382  1
    arc_2_0_11  in_degree_1406  1
    arc_2_0_11  original_T_including_depot_unload_1471  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1047  1
    load_2_0_11  segment_load_conservation_1409  -1
    load_2_0_11  segment_prefix_lb_1410  1
    load_2_0_11  segment_prefix_ub_1411  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1048  -30
    arc_2_0_12  depot_departure_or_bypass_1382  1
    arc_2_0_12  in_degree_1413  1
    arc_2_0_12  original_T_including_depot_unload_1471  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1048  1
    load_2_0_12  segment_load_conservation_1416  -1
    load_2_0_12  segment_prefix_lb_1417  1
    load_2_0_12  segment_prefix_ub_1418  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1049  -30
    arc_2_0_13  depot_departure_or_bypass_1382  1
    arc_2_0_13  in_degree_1420  1
    arc_2_0_13  original_T_including_depot_unload_1471  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1049  1
    load_2_0_13  free_load_conservation_1424  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1050  -30
    arc_2_0_14  depot_departure_or_bypass_1382  1
    arc_2_0_14  in_degree_1426  1
    arc_2_0_14  original_T_including_depot_unload_1471  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1050  1
    load_2_0_14  free_load_conservation_1430  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1051  -30
    arc_2_0_15  depot_departure_or_bypass_1382  1
    arc_2_0_15  in_degree_1432  1
    arc_2_0_15  original_T_including_depot_unload_1471  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1051  1
    load_2_0_15  free_load_conservation_1436  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1052  -30
    arc_2_0_16  depot_departure_or_bypass_1382  1
    arc_2_0_16  in_degree_1438  1
    arc_2_0_16  original_T_including_depot_unload_1471  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1052  1
    load_2_0_16  free_load_conservation_1442  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1053  -30
    arc_2_0_17  depot_departure_or_bypass_1382  1
    arc_2_0_17  in_degree_1444  1
    arc_2_0_17  original_T_including_depot_unload_1471  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1053  1
    load_2_0_17  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1054  -30
    arc_2_0_18  depot_departure_or_bypass_1382  1
    arc_2_0_18  in_degree_1450  1
    arc_2_0_18  original_T_including_depot_unload_1471  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1054  1
    load_2_0_18  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1055  -30
    arc_2_0_19  depot_departure_or_bypass_1382  1
    arc_2_0_19  in_degree_1456  1
    arc_2_0_19  original_T_including_depot_unload_1471  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1055  1
    load_2_0_19  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1056  -30
    arc_2_0_20  depot_departure_or_bypass_1382  1
    arc_2_0_20  in_degree_1462  1
    arc_2_0_20  original_T_including_depot_unload_1471  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1056  1
    load_2_0_20  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_0  arc_capacity_1057  -30
    arc_2_8_0  depot_return_or_bypass_1383  1
    arc_2_8_0  out_degree_1384  1
    arc_2_8_0  original_T_including_depot_unload_1471  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_0  arc_capacity_1057  1
    load_2_8_0  segment_load_conservation_1388  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_9  arc_capacity_1058  -30
    arc_2_8_9  connected_order_arc_1059  -14
    arc_2_8_9  out_degree_1384  1
    arc_2_8_9  in_degree_1392  1
    arc_2_8_9  original_T_including_depot_unload_1471  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_9  arc_capacity_1058  1
    load_2_8_9  segment_load_conservation_1388  1
    load_2_8_9  segment_load_conservation_1395  -1
    load_2_8_9  segment_prefix_lb_1396  1
    load_2_8_9  segment_prefix_ub_1397  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_10  arc_capacity_1060  -30
    arc_2_8_10  connected_order_arc_1061  -14
    arc_2_8_10  out_degree_1384  1
    arc_2_8_10  in_degree_1399  1
    arc_2_8_10  original_T_including_depot_unload_1471  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_10  arc_capacity_1060  1
    load_2_8_10  segment_load_conservation_1388  1
    load_2_8_10  segment_load_conservation_1402  -1
    load_2_8_10  segment_prefix_lb_1403  1
    load_2_8_10  segment_prefix_ub_1404  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_11  arc_capacity_1062  -30
    arc_2_8_11  connected_order_arc_1063  -14
    arc_2_8_11  out_degree_1384  1
    arc_2_8_11  in_degree_1406  1
    arc_2_8_11  original_T_including_depot_unload_1471  7.0252509787186375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_11  arc_capacity_1062  1
    load_2_8_11  segment_load_conservation_1388  1
    load_2_8_11  segment_load_conservation_1409  -1
    load_2_8_11  segment_prefix_lb_1410  1
    load_2_8_11  segment_prefix_ub_1411  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_12  arc_capacity_1064  -30
    arc_2_8_12  connected_order_arc_1065  -14
    arc_2_8_12  out_degree_1384  1
    arc_2_8_12  in_degree_1413  1
    arc_2_8_12  original_T_including_depot_unload_1471  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_12  arc_capacity_1064  1
    load_2_8_12  segment_load_conservation_1388  1
    load_2_8_12  segment_load_conservation_1416  -1
    load_2_8_12  segment_prefix_lb_1417  1
    load_2_8_12  segment_prefix_ub_1418  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_13  arc_capacity_1066  -30
    arc_2_8_13  connected_order_arc_1067  -14
    arc_2_8_13  out_degree_1384  1
    arc_2_8_13  in_degree_1420  1
    arc_2_8_13  original_T_including_depot_unload_1471  1.0363838262442744e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_8_13  arc_capacity_1066  1
    load_2_8_13  segment_load_conservation_1388  1
    load_2_8_13  free_load_conservation_1424  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_14  arc_capacity_1068  -30
    arc_2_8_14  connected_order_arc_1069  -14
    arc_2_8_14  out_degree_1384  1
    arc_2_8_14  in_degree_1426  1
    arc_2_8_14  original_T_including_depot_unload_1471  1.3156708792004563e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_8_14  arc_capacity_1068  1
    load_2_8_14  segment_load_conservation_1388  1
    load_2_8_14  free_load_conservation_1430  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_15  arc_capacity_1070  -30
    arc_2_8_15  connected_order_arc_1071  -14
    arc_2_8_15  out_degree_1384  1
    arc_2_8_15  in_degree_1432  1
    arc_2_8_15  original_T_including_depot_unload_1471  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_15  arc_capacity_1070  1
    load_2_8_15  segment_load_conservation_1388  1
    load_2_8_15  free_load_conservation_1436  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_16  arc_capacity_1072  -30
    arc_2_8_16  connected_order_arc_1073  -14
    arc_2_8_16  out_degree_1384  1
    arc_2_8_16  in_degree_1438  1
    arc_2_8_16  original_T_including_depot_unload_1471  1.3923205390152336e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_8_16  arc_capacity_1072  1
    load_2_8_16  segment_load_conservation_1388  1
    load_2_8_16  free_load_conservation_1442  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_17  arc_capacity_1074  -30
    arc_2_8_17  connected_order_arc_1075  -14
    arc_2_8_17  out_degree_1384  1
    arc_2_8_17  in_degree_1444  1
    arc_2_8_17  original_T_including_depot_unload_1471  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_17  arc_capacity_1074  1
    load_2_8_17  segment_load_conservation_1388  1
    load_2_8_17  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_18  arc_capacity_1076  -30
    arc_2_8_18  connected_order_arc_1077  -14
    arc_2_8_18  out_degree_1384  1
    arc_2_8_18  in_degree_1450  1
    arc_2_8_18  original_T_including_depot_unload_1471  1.3060135543268104e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_8_18  arc_capacity_1076  1
    load_2_8_18  segment_load_conservation_1388  1
    load_2_8_18  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_19  arc_capacity_1078  -30
    arc_2_8_19  connected_order_arc_1079  -14
    arc_2_8_19  out_degree_1384  1
    arc_2_8_19  in_degree_1456  1
    arc_2_8_19  original_T_including_depot_unload_1471  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_19  arc_capacity_1078  1
    load_2_8_19  segment_load_conservation_1388  1
    load_2_8_19  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_20  arc_capacity_1080  -30
    arc_2_8_20  connected_order_arc_1081  -14
    arc_2_8_20  out_degree_1384  1
    arc_2_8_20  in_degree_1462  1
    arc_2_8_20  original_T_including_depot_unload_1471  1.1827214856899616e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_8_20  arc_capacity_1080  1
    load_2_8_20  segment_load_conservation_1388  1
    load_2_8_20  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_0  arc_capacity_1082  -30
    arc_2_9_0  depot_return_or_bypass_1383  1
    arc_2_9_0  out_degree_1391  1
    arc_2_9_0  original_T_including_depot_unload_1471  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_0  arc_capacity_1082  1
    load_2_9_0  segment_load_conservation_1395  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_8  arc_capacity_1083  -30
    arc_2_9_8  connected_order_arc_1084  -14
    arc_2_9_8  in_degree_1385  1
    arc_2_9_8  out_degree_1391  1
    arc_2_9_8  original_T_including_depot_unload_1471  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_8  arc_capacity_1083  1
    load_2_9_8  segment_load_conservation_1388  -1
    load_2_9_8  segment_prefix_lb_1389  1
    load_2_9_8  segment_prefix_ub_1390  1
    load_2_9_8  segment_load_conservation_1395  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_10  arc_capacity_1085  -30
    arc_2_9_10  connected_order_arc_1086  -14
    arc_2_9_10  out_degree_1391  1
    arc_2_9_10  in_degree_1399  1
    arc_2_9_10  original_T_including_depot_unload_1471  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_10  arc_capacity_1085  1
    load_2_9_10  segment_load_conservation_1395  1
    load_2_9_10  segment_load_conservation_1402  -1
    load_2_9_10  segment_prefix_lb_1403  1
    load_2_9_10  segment_prefix_ub_1404  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_11  arc_capacity_1087  -30
    arc_2_9_11  connected_order_arc_1088  -14
    arc_2_9_11  out_degree_1391  1
    arc_2_9_11  in_degree_1406  1
    arc_2_9_11  original_T_including_depot_unload_1471  8.2580969662641792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_11  arc_capacity_1087  1
    load_2_9_11  segment_load_conservation_1395  1
    load_2_9_11  segment_load_conservation_1409  -1
    load_2_9_11  segment_prefix_lb_1410  1
    load_2_9_11  segment_prefix_ub_1411  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_12  arc_capacity_1089  -30
    arc_2_9_12  connected_order_arc_1090  -14
    arc_2_9_12  out_degree_1391  1
    arc_2_9_12  in_degree_1413  1
    arc_2_9_12  original_T_including_depot_unload_1471  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_12  arc_capacity_1089  1
    load_2_9_12  segment_load_conservation_1395  1
    load_2_9_12  segment_load_conservation_1416  -1
    load_2_9_12  segment_prefix_lb_1417  1
    load_2_9_12  segment_prefix_ub_1418  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_13  arc_capacity_1091  -30
    arc_2_9_13  connected_order_arc_1092  -14
    arc_2_9_13  out_degree_1391  1
    arc_2_9_13  in_degree_1420  1
    arc_2_9_13  original_T_including_depot_unload_1471  1.7397988912348303e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_13  arc_capacity_1091  1
    load_2_9_13  segment_load_conservation_1395  1
    load_2_9_13  free_load_conservation_1424  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_14  arc_capacity_1093  -30
    arc_2_9_14  connected_order_arc_1094  -14
    arc_2_9_14  out_degree_1391  1
    arc_2_9_14  in_degree_1426  1
    arc_2_9_14  original_T_including_depot_unload_1471  1.9859678280953403e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_14  arc_capacity_1093  1
    load_2_9_14  segment_load_conservation_1395  1
    load_2_9_14  free_load_conservation_1430  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_15  arc_capacity_1095  -30
    arc_2_9_15  connected_order_arc_1096  -14
    arc_2_9_15  out_degree_1391  1
    arc_2_9_15  in_degree_1432  1
    arc_2_9_15  original_T_including_depot_unload_1471  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_15  arc_capacity_1095  1
    load_2_9_15  segment_load_conservation_1395  1
    load_2_9_15  free_load_conservation_1436  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_16  arc_capacity_1097  -30
    arc_2_9_16  connected_order_arc_1098  -14
    arc_2_9_16  out_degree_1391  1
    arc_2_9_16  in_degree_1438  1
    arc_2_9_16  original_T_including_depot_unload_1471  2.1118429424496589e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_16  arc_capacity_1097  1
    load_2_9_16  segment_load_conservation_1395  1
    load_2_9_16  free_load_conservation_1442  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_17  arc_capacity_1099  -30
    arc_2_9_17  connected_order_arc_1100  -14
    arc_2_9_17  out_degree_1391  1
    arc_2_9_17  in_degree_1444  1
    arc_2_9_17  original_T_including_depot_unload_1471  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_9_17  arc_capacity_1099  1
    load_2_9_17  segment_load_conservation_1395  1
    load_2_9_17  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_18  arc_capacity_1101  -30
    arc_2_9_18  connected_order_arc_1102  -14
    arc_2_9_18  out_degree_1391  1
    arc_2_9_18  in_degree_1450  1
    arc_2_9_18  original_T_including_depot_unload_1471  1.8758493536744261e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_18  arc_capacity_1101  1
    load_2_9_18  segment_load_conservation_1395  1
    load_2_9_18  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_19  arc_capacity_1103  -30
    arc_2_9_19  connected_order_arc_1104  -14
    arc_2_9_19  out_degree_1391  1
    arc_2_9_19  in_degree_1456  1
    arc_2_9_19  original_T_including_depot_unload_1471  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_19  arc_capacity_1103  1
    load_2_9_19  segment_load_conservation_1395  1
    load_2_9_19  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_20  arc_capacity_1105  -30
    arc_2_9_20  connected_order_arc_1106  -14
    arc_2_9_20  out_degree_1391  1
    arc_2_9_20  in_degree_1462  1
    arc_2_9_20  original_T_including_depot_unload_1471  1.7224091675467555e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_20  arc_capacity_1105  1
    load_2_9_20  segment_load_conservation_1395  1
    load_2_9_20  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1107  -30
    arc_2_10_0  depot_return_or_bypass_1383  1
    arc_2_10_0  out_degree_1398  1
    arc_2_10_0  original_T_including_depot_unload_1471  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1107  1
    load_2_10_0  segment_load_conservation_1402  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_8  arc_capacity_1108  -30
    arc_2_10_8  connected_order_arc_1109  -14
    arc_2_10_8  in_degree_1385  1
    arc_2_10_8  out_degree_1398  1
    arc_2_10_8  original_T_including_depot_unload_1471  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_8  arc_capacity_1108  1
    load_2_10_8  segment_load_conservation_1388  -1
    load_2_10_8  segment_prefix_lb_1389  1
    load_2_10_8  segment_prefix_ub_1390  1
    load_2_10_8  segment_load_conservation_1402  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_9  arc_capacity_1110  -30
    arc_2_10_9  connected_order_arc_1111  -14
    arc_2_10_9  in_degree_1392  1
    arc_2_10_9  out_degree_1398  1
    arc_2_10_9  original_T_including_depot_unload_1471  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_9  arc_capacity_1110  1
    load_2_10_9  segment_load_conservation_1395  -1
    load_2_10_9  segment_prefix_lb_1396  1
    load_2_10_9  segment_prefix_ub_1397  1
    load_2_10_9  segment_load_conservation_1402  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1112  -30
    arc_2_10_11  connected_order_arc_1113  -14
    arc_2_10_11  out_degree_1398  1
    arc_2_10_11  in_degree_1406  1
    arc_2_10_11  original_T_including_depot_unload_1471  604.307118555145
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1112  1
    load_2_10_11  segment_load_conservation_1402  1
    load_2_10_11  segment_load_conservation_1409  -1
    load_2_10_11  segment_prefix_lb_1410  1
    load_2_10_11  segment_prefix_ub_1411  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1114  -30
    arc_2_10_12  connected_order_arc_1115  -14
    arc_2_10_12  out_degree_1398  1
    arc_2_10_12  in_degree_1413  1
    arc_2_10_12  original_T_including_depot_unload_1471  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1114  1
    load_2_10_12  segment_load_conservation_1402  1
    load_2_10_12  segment_load_conservation_1416  -1
    load_2_10_12  segment_prefix_lb_1417  1
    load_2_10_12  segment_prefix_ub_1418  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1116  -30
    arc_2_10_13  connected_order_arc_1117  -14
    arc_2_10_13  out_degree_1398  1
    arc_2_10_13  in_degree_1420  1
    arc_2_10_13  original_T_including_depot_unload_1471  1.6950562242445128e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1116  1
    load_2_10_13  segment_load_conservation_1402  1
    load_2_10_13  free_load_conservation_1424  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1118  -30
    arc_2_10_14  connected_order_arc_1119  -14
    arc_2_10_14  out_degree_1398  1
    arc_2_10_14  in_degree_1426  1
    arc_2_10_14  original_T_including_depot_unload_1471  1.9612089457952206e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1118  1
    load_2_10_14  segment_load_conservation_1402  1
    load_2_10_14  free_load_conservation_1430  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1120  -30
    arc_2_10_15  connected_order_arc_1121  -14
    arc_2_10_15  out_degree_1398  1
    arc_2_10_15  in_degree_1432  1
    arc_2_10_15  original_T_including_depot_unload_1471  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1120  1
    load_2_10_15  segment_load_conservation_1402  1
    load_2_10_15  free_load_conservation_1436  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1122  -30
    arc_2_10_16  connected_order_arc_1123  -14
    arc_2_10_16  out_degree_1398  1
    arc_2_10_16  in_degree_1438  1
    arc_2_10_16  original_T_including_depot_unload_1471  2.0573170852107110e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1122  1
    load_2_10_16  segment_load_conservation_1402  1
    load_2_10_16  free_load_conservation_1442  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1124  -30
    arc_2_10_17  connected_order_arc_1125  -14
    arc_2_10_17  out_degree_1398  1
    arc_2_10_17  in_degree_1444  1
    arc_2_10_17  original_T_including_depot_unload_1471  7.5965235847304257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1124  1
    load_2_10_17  segment_load_conservation_1402  1
    load_2_10_17  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1126  -30
    arc_2_10_18  connected_order_arc_1127  -14
    arc_2_10_18  out_degree_1398  1
    arc_2_10_18  in_degree_1450  1
    arc_2_10_18  original_T_including_depot_unload_1471  1.8936300338347210e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1126  1
    load_2_10_18  segment_load_conservation_1402  1
    load_2_10_18  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1128  -30
    arc_2_10_19  connected_order_arc_1129  -14
    arc_2_10_19  out_degree_1398  1
    arc_2_10_19  in_degree_1456  1
    arc_2_10_19  original_T_including_depot_unload_1471  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1128  1
    load_2_10_19  segment_load_conservation_1402  1
    load_2_10_19  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1130  -30
    arc_2_10_20  connected_order_arc_1131  -14
    arc_2_10_20  out_degree_1398  1
    arc_2_10_20  in_degree_1462  1
    arc_2_10_20  original_T_including_depot_unload_1471  1.7489516402613351e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1130  1
    load_2_10_20  segment_load_conservation_1402  1
    load_2_10_20  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1132  -30
    arc_2_11_0  depot_return_or_bypass_1383  1
    arc_2_11_0  out_degree_1405  1
    arc_2_11_0  original_T_including_depot_unload_1471  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1132  1
    load_2_11_0  segment_load_conservation_1409  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_8  arc_capacity_1133  -30
    arc_2_11_8  connected_order_arc_1134  -14
    arc_2_11_8  in_degree_1385  1
    arc_2_11_8  out_degree_1405  1
    arc_2_11_8  original_T_including_depot_unload_1471  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_8  arc_capacity_1133  1
    load_2_11_8  segment_load_conservation_1388  -1
    load_2_11_8  segment_prefix_lb_1389  1
    load_2_11_8  segment_prefix_ub_1390  1
    load_2_11_8  segment_load_conservation_1409  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_9  arc_capacity_1135  -30
    arc_2_11_9  connected_order_arc_1136  -14
    arc_2_11_9  in_degree_1392  1
    arc_2_11_9  out_degree_1405  1
    arc_2_11_9  original_T_including_depot_unload_1471  1.6865464326628071e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_9  arc_capacity_1135  1
    load_2_11_9  segment_load_conservation_1395  -1
    load_2_11_9  segment_prefix_lb_1396  1
    load_2_11_9  segment_prefix_ub_1397  1
    load_2_11_9  segment_load_conservation_1409  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1137  -30
    arc_2_11_10  connected_order_arc_1138  -14
    arc_2_11_10  in_degree_1399  1
    arc_2_11_10  out_degree_1405  1
    arc_2_11_10  original_T_including_depot_unload_1471  1.4754486297628157e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1137  1
    load_2_11_10  segment_load_conservation_1402  -1
    load_2_11_10  segment_prefix_lb_1403  1
    load_2_11_10  segment_prefix_ub_1404  1
    load_2_11_10  segment_load_conservation_1409  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1139  -30
    arc_2_11_12  connected_order_arc_1140  -14
    arc_2_11_12  out_degree_1405  1
    arc_2_11_12  in_degree_1413  1
    arc_2_11_12  original_T_including_depot_unload_1471  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1139  1
    load_2_11_12  segment_load_conservation_1409  1
    load_2_11_12  segment_load_conservation_1416  -1
    load_2_11_12  segment_prefix_lb_1417  1
    load_2_11_12  segment_prefix_ub_1418  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1141  -30
    arc_2_11_13  connected_order_arc_1142  -14
    arc_2_11_13  out_degree_1405  1
    arc_2_11_13  in_degree_1420  1
    arc_2_11_13  original_T_including_depot_unload_1471  1.6406378986588031e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1141  1
    load_2_11_13  segment_load_conservation_1409  1
    load_2_11_13  free_load_conservation_1424  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1143  -30
    arc_2_11_14  connected_order_arc_1144  -14
    arc_2_11_14  out_degree_1405  1
    arc_2_11_14  in_degree_1426  1
    arc_2_11_14  original_T_including_depot_unload_1471  1.9305399866194357e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1143  1
    load_2_11_14  segment_load_conservation_1409  1
    load_2_11_14  free_load_conservation_1430  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1145  -30
    arc_2_11_15  connected_order_arc_1146  -14
    arc_2_11_15  out_degree_1405  1
    arc_2_11_15  in_degree_1432  1
    arc_2_11_15  original_T_including_depot_unload_1471  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1145  1
    load_2_11_15  segment_load_conservation_1409  1
    load_2_11_15  free_load_conservation_1436  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1147  -30
    arc_2_11_16  connected_order_arc_1148  -14
    arc_2_11_16  out_degree_1405  1
    arc_2_11_16  in_degree_1438  1
    arc_2_11_16  original_T_including_depot_unload_1471  1.8021002410302701e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1147  1
    load_2_11_16  segment_load_conservation_1409  1
    load_2_11_16  free_load_conservation_1442  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1149  -30
    arc_2_11_17  connected_order_arc_1150  -14
    arc_2_11_17  out_degree_1405  1
    arc_2_11_17  in_degree_1444  1
    arc_2_11_17  original_T_including_depot_unload_1471  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1149  1
    load_2_11_17  segment_load_conservation_1409  1
    load_2_11_17  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1151  -30
    arc_2_11_18  connected_order_arc_1152  -14
    arc_2_11_18  out_degree_1405  1
    arc_2_11_18  in_degree_1450  1
    arc_2_11_18  original_T_including_depot_unload_1471  2.1385293969918903e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1151  1
    load_2_11_18  segment_load_conservation_1409  1
    load_2_11_18  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1153  -30
    arc_2_11_19  connected_order_arc_1154  -14
    arc_2_11_19  out_degree_1405  1
    arc_2_11_19  in_degree_1456  1
    arc_2_11_19  original_T_including_depot_unload_1471  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1153  1
    load_2_11_19  segment_load_conservation_1409  1
    load_2_11_19  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1155  -30
    arc_2_11_20  connected_order_arc_1156  -14
    arc_2_11_20  out_degree_1405  1
    arc_2_11_20  in_degree_1462  1
    arc_2_11_20  original_T_including_depot_unload_1471  2.0883063288244971e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1155  1
    load_2_11_20  segment_load_conservation_1409  1
    load_2_11_20  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1157  -30
    arc_2_12_0  depot_return_or_bypass_1383  1
    arc_2_12_0  out_degree_1412  1
    arc_2_12_0  original_T_including_depot_unload_1471  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1157  1
    load_2_12_0  segment_load_conservation_1416  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_8  arc_capacity_1158  -30
    arc_2_12_8  connected_order_arc_1159  -14
    arc_2_12_8  in_degree_1385  1
    arc_2_12_8  out_degree_1412  1
    arc_2_12_8  original_T_including_depot_unload_1471  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_8  arc_capacity_1158  1
    load_2_12_8  segment_load_conservation_1388  -1
    load_2_12_8  segment_prefix_lb_1389  1
    load_2_12_8  segment_prefix_ub_1390  1
    load_2_12_8  segment_load_conservation_1416  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_9  arc_capacity_1160  -30
    arc_2_12_9  connected_order_arc_1161  -14
    arc_2_12_9  in_degree_1392  1
    arc_2_12_9  out_degree_1412  1
    arc_2_12_9  original_T_including_depot_unload_1471  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_9  arc_capacity_1160  1
    load_2_12_9  segment_load_conservation_1395  -1
    load_2_12_9  segment_prefix_lb_1396  1
    load_2_12_9  segment_prefix_ub_1397  1
    load_2_12_9  segment_load_conservation_1416  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1162  -30
    arc_2_12_10  connected_order_arc_1163  -14
    arc_2_12_10  in_degree_1399  1
    arc_2_12_10  out_degree_1412  1
    arc_2_12_10  original_T_including_depot_unload_1471  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1162  1
    load_2_12_10  segment_load_conservation_1402  -1
    load_2_12_10  segment_prefix_lb_1403  1
    load_2_12_10  segment_prefix_ub_1404  1
    load_2_12_10  segment_load_conservation_1416  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1164  -30
    arc_2_12_11  connected_order_arc_1165  -14
    arc_2_12_11  in_degree_1406  1
    arc_2_12_11  out_degree_1412  1
    arc_2_12_11  original_T_including_depot_unload_1471  1.0279345387929015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1164  1
    load_2_12_11  segment_load_conservation_1409  -1
    load_2_12_11  segment_prefix_lb_1410  1
    load_2_12_11  segment_prefix_ub_1411  1
    load_2_12_11  segment_load_conservation_1416  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1166  -30
    arc_2_12_13  connected_order_arc_1167  -14
    arc_2_12_13  out_degree_1412  1
    arc_2_12_13  in_degree_1420  1
    arc_2_12_13  original_T_including_depot_unload_1471  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1166  1
    load_2_12_13  segment_load_conservation_1416  1
    load_2_12_13  free_load_conservation_1424  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1168  -30
    arc_2_12_14  connected_order_arc_1169  -14
    arc_2_12_14  out_degree_1412  1
    arc_2_12_14  in_degree_1426  1
    arc_2_12_14  original_T_including_depot_unload_1471  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1168  1
    load_2_12_14  segment_load_conservation_1416  1
    load_2_12_14  free_load_conservation_1430  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1170  -30
    arc_2_12_15  connected_order_arc_1171  -14
    arc_2_12_15  out_degree_1412  1
    arc_2_12_15  in_degree_1432  1
    arc_2_12_15  original_T_including_depot_unload_1471  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1170  1
    load_2_12_15  segment_load_conservation_1416  1
    load_2_12_15  free_load_conservation_1436  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1172  -30
    arc_2_12_16  connected_order_arc_1173  -14
    arc_2_12_16  out_degree_1412  1
    arc_2_12_16  in_degree_1438  1
    arc_2_12_16  original_T_including_depot_unload_1471  1.0198535056659911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1172  1
    load_2_12_16  segment_load_conservation_1416  1
    load_2_12_16  free_load_conservation_1442  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1174  -30
    arc_2_12_17  connected_order_arc_1175  -14
    arc_2_12_17  out_degree_1412  1
    arc_2_12_17  in_degree_1444  1
    arc_2_12_17  original_T_including_depot_unload_1471  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1174  1
    load_2_12_17  segment_load_conservation_1416  1
    load_2_12_17  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1176  -30
    arc_2_12_18  connected_order_arc_1177  -14
    arc_2_12_18  out_degree_1412  1
    arc_2_12_18  in_degree_1450  1
    arc_2_12_18  original_T_including_depot_unload_1471  9.5968099967049886e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1176  1
    load_2_12_18  segment_load_conservation_1416  1
    load_2_12_18  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1178  -30
    arc_2_12_19  connected_order_arc_1179  -14
    arc_2_12_19  out_degree_1412  1
    arc_2_12_19  in_degree_1456  1
    arc_2_12_19  original_T_including_depot_unload_1471  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1178  1
    load_2_12_19  segment_load_conservation_1416  1
    load_2_12_19  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1180  -30
    arc_2_12_20  connected_order_arc_1181  -14
    arc_2_12_20  out_degree_1412  1
    arc_2_12_20  in_degree_1462  1
    arc_2_12_20  original_T_including_depot_unload_1471  8.5579830526745980e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1180  1
    load_2_12_20  segment_load_conservation_1416  1
    load_2_12_20  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1182  -30
    arc_2_13_0  depot_return_or_bypass_1383  1
    arc_2_13_0  out_degree_1419  1
    arc_2_13_0  original_T_including_depot_unload_1471  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1182  1
    load_2_13_0  free_load_conservation_1424  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_8  arc_capacity_1183  -30
    arc_2_13_8  connected_order_arc_1184  -14
    arc_2_13_8  in_degree_1385  1
    arc_2_13_8  out_degree_1419  1
    arc_2_13_8  original_T_including_depot_unload_1471  1.0363838262442744e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_8  arc_capacity_1183  1
    load_2_13_8  segment_load_conservation_1388  -1
    load_2_13_8  segment_prefix_lb_1389  1
    load_2_13_8  segment_prefix_ub_1390  1
    load_2_13_8  free_load_conservation_1424  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_9  arc_capacity_1185  -30
    arc_2_13_9  connected_order_arc_1186  -14
    arc_2_13_9  in_degree_1392  1
    arc_2_13_9  out_degree_1419  1
    arc_2_13_9  original_T_including_depot_unload_1471  1.7397988912348303e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_9  arc_capacity_1185  1
    load_2_13_9  segment_load_conservation_1395  -1
    load_2_13_9  segment_prefix_lb_1396  1
    load_2_13_9  segment_prefix_ub_1397  1
    load_2_13_9  free_load_conservation_1424  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1187  -30
    arc_2_13_10  connected_order_arc_1188  -14
    arc_2_13_10  in_degree_1399  1
    arc_2_13_10  out_degree_1419  1
    arc_2_13_10  original_T_including_depot_unload_1471  1.6950562242445128e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1187  1
    load_2_13_10  segment_load_conservation_1402  -1
    load_2_13_10  segment_prefix_lb_1403  1
    load_2_13_10  segment_prefix_ub_1404  1
    load_2_13_10  free_load_conservation_1424  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1189  -30
    arc_2_13_11  connected_order_arc_1190  -14
    arc_2_13_11  in_degree_1406  1
    arc_2_13_11  out_degree_1419  1
    arc_2_13_11  original_T_including_depot_unload_1471  1.6359122202972637e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1189  1
    load_2_13_11  segment_load_conservation_1409  -1
    load_2_13_11  segment_prefix_lb_1410  1
    load_2_13_11  segment_prefix_ub_1411  1
    load_2_13_11  free_load_conservation_1424  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1191  -30
    arc_2_13_12  connected_order_arc_1192  -14
    arc_2_13_12  in_degree_1413  1
    arc_2_13_12  out_degree_1419  1
    arc_2_13_12  original_T_including_depot_unload_1471  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1191  1
    load_2_13_12  segment_load_conservation_1416  -1
    load_2_13_12  segment_prefix_lb_1417  1
    load_2_13_12  segment_prefix_ub_1418  1
    load_2_13_12  free_load_conservation_1424  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1193  -30
    arc_2_13_14  connected_order_arc_1194  -14
    arc_2_13_14  out_degree_1419  1
    arc_2_13_14  in_degree_1426  1
    arc_2_13_14  original_T_including_depot_unload_1471  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1193  1
    load_2_13_14  free_load_conservation_1424  1
    load_2_13_14  free_load_conservation_1430  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1195  -30
    arc_2_13_15  connected_order_arc_1196  -14
    arc_2_13_15  out_degree_1419  1
    arc_2_13_15  in_degree_1432  1
    arc_2_13_15  original_T_including_depot_unload_1471  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1195  1
    load_2_13_15  free_load_conservation_1424  1
    load_2_13_15  free_load_conservation_1436  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1197  -30
    arc_2_13_16  connected_order_arc_1198  -14
    arc_2_13_16  out_degree_1419  1
    arc_2_13_16  in_degree_1438  1
    arc_2_13_16  original_T_including_depot_unload_1471  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1197  1
    load_2_13_16  free_load_conservation_1424  1
    load_2_13_16  free_load_conservation_1442  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1199  -30
    arc_2_13_17  connected_order_arc_1200  -14
    arc_2_13_17  out_degree_1419  1
    arc_2_13_17  in_degree_1444  1
    arc_2_13_17  original_T_including_depot_unload_1471  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1199  1
    load_2_13_17  free_load_conservation_1424  1
    load_2_13_17  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1201  -30
    arc_2_13_18  connected_order_arc_1202  -14
    arc_2_13_18  out_degree_1419  1
    arc_2_13_18  in_degree_1450  1
    arc_2_13_18  original_T_including_depot_unload_1471  5.3222543932043470e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1201  1
    load_2_13_18  free_load_conservation_1424  1
    load_2_13_18  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1203  -30
    arc_2_13_19  connected_order_arc_1204  -14
    arc_2_13_19  out_degree_1419  1
    arc_2_13_19  in_degree_1456  1
    arc_2_13_19  original_T_including_depot_unload_1471  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1203  1
    load_2_13_19  free_load_conservation_1424  1
    load_2_13_19  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1205  -30
    arc_2_13_20  connected_order_arc_1206  -14
    arc_2_13_20  out_degree_1419  1
    arc_2_13_20  in_degree_1462  1
    arc_2_13_20  original_T_including_depot_unload_1471  552.429776828834
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1205  1
    load_2_13_20  free_load_conservation_1424  1
    load_2_13_20  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1207  -30
    arc_2_14_0  depot_return_or_bypass_1383  1
    arc_2_14_0  out_degree_1425  1
    arc_2_14_0  original_T_including_depot_unload_1471  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1207  1
    load_2_14_0  free_load_conservation_1430  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_8  arc_capacity_1208  -30
    arc_2_14_8  connected_order_arc_1209  -14
    arc_2_14_8  in_degree_1385  1
    arc_2_14_8  out_degree_1425  1
    arc_2_14_8  original_T_including_depot_unload_1471  1.3156708792004563e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_8  arc_capacity_1208  1
    load_2_14_8  segment_load_conservation_1388  -1
    load_2_14_8  segment_prefix_lb_1389  1
    load_2_14_8  segment_prefix_ub_1390  1
    load_2_14_8  free_load_conservation_1430  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_9  arc_capacity_1210  -30
    arc_2_14_9  connected_order_arc_1211  -14
    arc_2_14_9  in_degree_1392  1
    arc_2_14_9  out_degree_1425  1
    arc_2_14_9  original_T_including_depot_unload_1471  1.9859678280953403e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_9  arc_capacity_1210  1
    load_2_14_9  segment_load_conservation_1395  -1
    load_2_14_9  segment_prefix_lb_1396  1
    load_2_14_9  segment_prefix_ub_1397  1
    load_2_14_9  free_load_conservation_1430  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1212  -30
    arc_2_14_10  connected_order_arc_1213  -14
    arc_2_14_10  in_degree_1399  1
    arc_2_14_10  out_degree_1425  1
    arc_2_14_10  original_T_including_depot_unload_1471  1.9612089457952206e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1212  1
    load_2_14_10  segment_load_conservation_1402  -1
    load_2_14_10  segment_prefix_lb_1403  1
    load_2_14_10  segment_prefix_ub_1404  1
    load_2_14_10  free_load_conservation_1430  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1214  -30
    arc_2_14_11  connected_order_arc_1215  -14
    arc_2_14_11  in_degree_1406  1
    arc_2_14_11  out_degree_1425  1
    arc_2_14_11  original_T_including_depot_unload_1471  1.9370748198308336e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1214  1
    load_2_14_11  segment_load_conservation_1409  -1
    load_2_14_11  segment_prefix_lb_1410  1
    load_2_14_11  segment_prefix_ub_1411  1
    load_2_14_11  free_load_conservation_1430  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1216  -30
    arc_2_14_12  connected_order_arc_1217  -14
    arc_2_14_12  in_degree_1413  1
    arc_2_14_12  out_degree_1425  1
    arc_2_14_12  original_T_including_depot_unload_1471  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1216  1
    load_2_14_12  segment_load_conservation_1416  -1
    load_2_14_12  segment_prefix_lb_1417  1
    load_2_14_12  segment_prefix_ub_1418  1
    load_2_14_12  free_load_conservation_1430  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1218  -30
    arc_2_14_13  connected_order_arc_1219  -14
    arc_2_14_13  in_degree_1420  1
    arc_2_14_13  out_degree_1425  1
    arc_2_14_13  original_T_including_depot_unload_1471  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1218  1
    load_2_14_13  free_load_conservation_1424  -1
    load_2_14_13  free_load_conservation_1430  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1220  -30
    arc_2_14_15  connected_order_arc_1221  -14
    arc_2_14_15  out_degree_1425  1
    arc_2_14_15  in_degree_1432  1
    arc_2_14_15  original_T_including_depot_unload_1471  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1220  1
    load_2_14_15  free_load_conservation_1430  1
    load_2_14_15  free_load_conservation_1436  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1222  -30
    arc_2_14_16  connected_order_arc_1223  -14
    arc_2_14_16  out_degree_1425  1
    arc_2_14_16  in_degree_1438  1
    arc_2_14_16  original_T_including_depot_unload_1471  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1222  1
    load_2_14_16  free_load_conservation_1430  1
    load_2_14_16  free_load_conservation_1442  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1224  -30
    arc_2_14_17  connected_order_arc_1225  -14
    arc_2_14_17  out_degree_1425  1
    arc_2_14_17  in_degree_1444  1
    arc_2_14_17  original_T_including_depot_unload_1471  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1224  1
    load_2_14_17  free_load_conservation_1430  1
    load_2_14_17  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1226  -30
    arc_2_14_18  connected_order_arc_1227  -14
    arc_2_14_18  out_degree_1425  1
    arc_2_14_18  in_degree_1450  1
    arc_2_14_18  original_T_including_depot_unload_1471  3.7840168155842611e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1226  1
    load_2_14_18  free_load_conservation_1430  1
    load_2_14_18  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1228  -30
    arc_2_14_19  connected_order_arc_1229  -14
    arc_2_14_19  out_degree_1425  1
    arc_2_14_19  in_degree_1456  1
    arc_2_14_19  original_T_including_depot_unload_1471  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1228  1
    load_2_14_19  free_load_conservation_1430  1
    load_2_14_19  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1230  -30
    arc_2_14_20  connected_order_arc_1231  -14
    arc_2_14_20  out_degree_1425  1
    arc_2_14_20  in_degree_1462  1
    arc_2_14_20  original_T_including_depot_unload_1471  4.8778172744463808e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1230  1
    load_2_14_20  free_load_conservation_1430  1
    load_2_14_20  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1232  -30
    arc_2_15_0  depot_return_or_bypass_1383  1
    arc_2_15_0  out_degree_1431  1
    arc_2_15_0  original_T_including_depot_unload_1471  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1232  1
    load_2_15_0  free_load_conservation_1436  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_8  arc_capacity_1233  -30
    arc_2_15_8  connected_order_arc_1234  -14
    arc_2_15_8  in_degree_1385  1
    arc_2_15_8  out_degree_1431  1
    arc_2_15_8  original_T_including_depot_unload_1471  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_8  arc_capacity_1233  1
    load_2_15_8  segment_load_conservation_1388  -1
    load_2_15_8  segment_prefix_lb_1389  1
    load_2_15_8  segment_prefix_ub_1390  1
    load_2_15_8  free_load_conservation_1436  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_9  arc_capacity_1235  -30
    arc_2_15_9  connected_order_arc_1236  -14
    arc_2_15_9  in_degree_1392  1
    arc_2_15_9  out_degree_1431  1
    arc_2_15_9  original_T_including_depot_unload_1471  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_9  arc_capacity_1235  1
    load_2_15_9  segment_load_conservation_1395  -1
    load_2_15_9  segment_prefix_lb_1396  1
    load_2_15_9  segment_prefix_ub_1397  1
    load_2_15_9  free_load_conservation_1436  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1237  -30
    arc_2_15_10  connected_order_arc_1238  -14
    arc_2_15_10  in_degree_1399  1
    arc_2_15_10  out_degree_1431  1
    arc_2_15_10  original_T_including_depot_unload_1471  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1237  1
    load_2_15_10  segment_load_conservation_1402  -1
    load_2_15_10  segment_prefix_lb_1403  1
    load_2_15_10  segment_prefix_ub_1404  1
    load_2_15_10  free_load_conservation_1436  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1239  -30
    arc_2_15_11  connected_order_arc_1240  -14
    arc_2_15_11  in_degree_1406  1
    arc_2_15_11  out_degree_1431  1
    arc_2_15_11  original_T_including_depot_unload_1471  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1239  1
    load_2_15_11  segment_load_conservation_1409  -1
    load_2_15_11  segment_prefix_lb_1410  1
    load_2_15_11  segment_prefix_ub_1411  1
    load_2_15_11  free_load_conservation_1436  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1241  -30
    arc_2_15_12  connected_order_arc_1242  -14
    arc_2_15_12  in_degree_1413  1
    arc_2_15_12  out_degree_1431  1
    arc_2_15_12  original_T_including_depot_unload_1471  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1241  1
    load_2_15_12  segment_load_conservation_1416  -1
    load_2_15_12  segment_prefix_lb_1417  1
    load_2_15_12  segment_prefix_ub_1418  1
    load_2_15_12  free_load_conservation_1436  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1243  -30
    arc_2_15_13  connected_order_arc_1244  -14
    arc_2_15_13  in_degree_1420  1
    arc_2_15_13  out_degree_1431  1
    arc_2_15_13  original_T_including_depot_unload_1471  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1243  1
    load_2_15_13  free_load_conservation_1424  -1
    load_2_15_13  free_load_conservation_1436  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1245  -30
    arc_2_15_14  connected_order_arc_1246  -14
    arc_2_15_14  in_degree_1426  1
    arc_2_15_14  out_degree_1431  1
    arc_2_15_14  original_T_including_depot_unload_1471  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1245  1
    load_2_15_14  free_load_conservation_1430  -1
    load_2_15_14  free_load_conservation_1436  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1247  -30
    arc_2_15_16  connected_order_arc_1248  -14
    arc_2_15_16  out_degree_1431  1
    arc_2_15_16  in_degree_1438  1
    arc_2_15_16  original_T_including_depot_unload_1471  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1247  1
    load_2_15_16  free_load_conservation_1436  1
    load_2_15_16  free_load_conservation_1442  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1249  -30
    arc_2_15_17  connected_order_arc_1250  -14
    arc_2_15_17  out_degree_1431  1
    arc_2_15_17  in_degree_1444  1
    arc_2_15_17  original_T_including_depot_unload_1471  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1249  1
    load_2_15_17  free_load_conservation_1436  1
    load_2_15_17  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1251  -30
    arc_2_15_18  connected_order_arc_1252  -14
    arc_2_15_18  out_degree_1431  1
    arc_2_15_18  in_degree_1450  1
    arc_2_15_18  original_T_including_depot_unload_1471  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1251  1
    load_2_15_18  free_load_conservation_1436  1
    load_2_15_18  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1253  -30
    arc_2_15_19  connected_order_arc_1254  -14
    arc_2_15_19  out_degree_1431  1
    arc_2_15_19  in_degree_1456  1
    arc_2_15_19  original_T_including_depot_unload_1471  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1253  1
    load_2_15_19  free_load_conservation_1436  1
    load_2_15_19  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1255  -30
    arc_2_15_20  connected_order_arc_1256  -14
    arc_2_15_20  out_degree_1431  1
    arc_2_15_20  in_degree_1462  1
    arc_2_15_20  original_T_including_depot_unload_1471  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1255  1
    load_2_15_20  free_load_conservation_1436  1
    load_2_15_20  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1257  -30
    arc_2_16_0  depot_return_or_bypass_1383  1
    arc_2_16_0  out_degree_1437  1
    arc_2_16_0  original_T_including_depot_unload_1471  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1257  1
    load_2_16_0  free_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_8  arc_capacity_1258  -30
    arc_2_16_8  connected_order_arc_1259  -14
    arc_2_16_8  in_degree_1385  1
    arc_2_16_8  out_degree_1437  1
    arc_2_16_8  original_T_including_depot_unload_1471  1.3923205390152336e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_8  arc_capacity_1258  1
    load_2_16_8  segment_load_conservation_1388  -1
    load_2_16_8  segment_prefix_lb_1389  1
    load_2_16_8  segment_prefix_ub_1390  1
    load_2_16_8  free_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_9  arc_capacity_1260  -30
    arc_2_16_9  connected_order_arc_1261  -14
    arc_2_16_9  in_degree_1392  1
    arc_2_16_9  out_degree_1437  1
    arc_2_16_9  original_T_including_depot_unload_1471  2.1118429424496589e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_9  arc_capacity_1260  1
    load_2_16_9  segment_load_conservation_1395  -1
    load_2_16_9  segment_prefix_lb_1396  1
    load_2_16_9  segment_prefix_ub_1397  1
    load_2_16_9  free_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1262  -30
    arc_2_16_10  connected_order_arc_1263  -14
    arc_2_16_10  in_degree_1399  1
    arc_2_16_10  out_degree_1437  1
    arc_2_16_10  original_T_including_depot_unload_1471  2.0573170852107110e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1262  1
    load_2_16_10  segment_load_conservation_1402  -1
    load_2_16_10  segment_prefix_lb_1403  1
    load_2_16_10  segment_prefix_ub_1404  1
    load_2_16_10  free_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1264  -30
    arc_2_16_11  connected_order_arc_1265  -14
    arc_2_16_11  in_degree_1406  1
    arc_2_16_11  out_degree_1437  1
    arc_2_16_11  original_T_including_depot_unload_1471  1.9444044143793826e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1264  1
    load_2_16_11  segment_load_conservation_1409  -1
    load_2_16_11  segment_prefix_lb_1410  1
    load_2_16_11  segment_prefix_ub_1411  1
    load_2_16_11  free_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1266  -30
    arc_2_16_12  connected_order_arc_1267  -14
    arc_2_16_12  in_degree_1413  1
    arc_2_16_12  out_degree_1437  1
    arc_2_16_12  original_T_including_depot_unload_1471  1.0198535056659911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1266  1
    load_2_16_12  segment_load_conservation_1416  -1
    load_2_16_12  segment_prefix_lb_1417  1
    load_2_16_12  segment_prefix_ub_1418  1
    load_2_16_12  free_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1268  -30
    arc_2_16_13  connected_order_arc_1269  -14
    arc_2_16_13  in_degree_1420  1
    arc_2_16_13  out_degree_1437  1
    arc_2_16_13  original_T_including_depot_unload_1471  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1268  1
    load_2_16_13  free_load_conservation_1424  -1
    load_2_16_13  free_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1270  -30
    arc_2_16_14  connected_order_arc_1271  -14
    arc_2_16_14  in_degree_1426  1
    arc_2_16_14  out_degree_1437  1
    arc_2_16_14  original_T_including_depot_unload_1471  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1270  1
    load_2_16_14  free_load_conservation_1430  -1
    load_2_16_14  free_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1272  -30
    arc_2_16_15  connected_order_arc_1273  -14
    arc_2_16_15  in_degree_1432  1
    arc_2_16_15  out_degree_1437  1
    arc_2_16_15  original_T_including_depot_unload_1471  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1272  1
    load_2_16_15  free_load_conservation_1436  -1
    load_2_16_15  free_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1274  -30
    arc_2_16_17  connected_order_arc_1275  -14
    arc_2_16_17  out_degree_1437  1
    arc_2_16_17  in_degree_1444  1
    arc_2_16_17  original_T_including_depot_unload_1471  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1274  1
    load_2_16_17  free_load_conservation_1442  1
    load_2_16_17  free_load_conservation_1448  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1276  -30
    arc_2_16_18  connected_order_arc_1277  -14
    arc_2_16_18  out_degree_1437  1
    arc_2_16_18  in_degree_1450  1
    arc_2_16_18  original_T_including_depot_unload_1471  6.7500260835612892e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1276  1
    load_2_16_18  free_load_conservation_1442  1
    load_2_16_18  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1278  -30
    arc_2_16_19  connected_order_arc_1279  -14
    arc_2_16_19  out_degree_1437  1
    arc_2_16_19  in_degree_1456  1
    arc_2_16_19  original_T_including_depot_unload_1471  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1278  1
    load_2_16_19  free_load_conservation_1442  1
    load_2_16_19  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1280  -30
    arc_2_16_20  connected_order_arc_1281  -14
    arc_2_16_20  out_degree_1437  1
    arc_2_16_20  in_degree_1462  1
    arc_2_16_20  original_T_including_depot_unload_1471  7.7576476069541832e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1280  1
    load_2_16_20  free_load_conservation_1442  1
    load_2_16_20  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1282  -30
    arc_2_17_0  depot_return_or_bypass_1383  1
    arc_2_17_0  out_degree_1443  1
    arc_2_17_0  original_T_including_depot_unload_1471  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1282  1
    load_2_17_0  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_8  arc_capacity_1283  -30
    arc_2_17_8  connected_order_arc_1284  -14
    arc_2_17_8  in_degree_1385  1
    arc_2_17_8  out_degree_1443  1
    arc_2_17_8  original_T_including_depot_unload_1471  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_8  arc_capacity_1283  1
    load_2_17_8  segment_load_conservation_1388  -1
    load_2_17_8  segment_prefix_lb_1389  1
    load_2_17_8  segment_prefix_ub_1390  1
    load_2_17_8  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_9  arc_capacity_1285  -30
    arc_2_17_9  connected_order_arc_1286  -14
    arc_2_17_9  in_degree_1392  1
    arc_2_17_9  out_degree_1443  1
    arc_2_17_9  original_T_including_depot_unload_1471  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_17_9  arc_capacity_1285  1
    load_2_17_9  segment_load_conservation_1395  -1
    load_2_17_9  segment_prefix_lb_1396  1
    load_2_17_9  segment_prefix_ub_1397  1
    load_2_17_9  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1287  -30
    arc_2_17_10  connected_order_arc_1288  -14
    arc_2_17_10  in_degree_1399  1
    arc_2_17_10  out_degree_1443  1
    arc_2_17_10  original_T_including_depot_unload_1471  7.5965235847304257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1287  1
    load_2_17_10  segment_load_conservation_1402  -1
    load_2_17_10  segment_prefix_lb_1403  1
    load_2_17_10  segment_prefix_ub_1404  1
    load_2_17_10  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1289  -30
    arc_2_17_11  connected_order_arc_1290  -14
    arc_2_17_11  in_degree_1406  1
    arc_2_17_11  out_degree_1443  1
    arc_2_17_11  original_T_including_depot_unload_1471  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1289  1
    load_2_17_11  segment_load_conservation_1409  -1
    load_2_17_11  segment_prefix_lb_1410  1
    load_2_17_11  segment_prefix_ub_1411  1
    load_2_17_11  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1291  -30
    arc_2_17_12  connected_order_arc_1292  -14
    arc_2_17_12  in_degree_1413  1
    arc_2_17_12  out_degree_1443  1
    arc_2_17_12  original_T_including_depot_unload_1471  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1291  1
    load_2_17_12  segment_load_conservation_1416  -1
    load_2_17_12  segment_prefix_lb_1417  1
    load_2_17_12  segment_prefix_ub_1418  1
    load_2_17_12  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1293  -30
    arc_2_17_13  connected_order_arc_1294  -14
    arc_2_17_13  in_degree_1420  1
    arc_2_17_13  out_degree_1443  1
    arc_2_17_13  original_T_including_depot_unload_1471  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1293  1
    load_2_17_13  free_load_conservation_1424  -1
    load_2_17_13  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1295  -30
    arc_2_17_14  connected_order_arc_1296  -14
    arc_2_17_14  in_degree_1426  1
    arc_2_17_14  out_degree_1443  1
    arc_2_17_14  original_T_including_depot_unload_1471  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1295  1
    load_2_17_14  free_load_conservation_1430  -1
    load_2_17_14  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1297  -30
    arc_2_17_15  connected_order_arc_1298  -14
    arc_2_17_15  in_degree_1432  1
    arc_2_17_15  out_degree_1443  1
    arc_2_17_15  original_T_including_depot_unload_1471  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1297  1
    load_2_17_15  free_load_conservation_1436  -1
    load_2_17_15  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1299  -30
    arc_2_17_16  connected_order_arc_1300  -14
    arc_2_17_16  in_degree_1438  1
    arc_2_17_16  out_degree_1443  1
    arc_2_17_16  original_T_including_depot_unload_1471  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1299  1
    load_2_17_16  free_load_conservation_1442  -1
    load_2_17_16  free_load_conservation_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1301  -30
    arc_2_17_18  connected_order_arc_1302  -14
    arc_2_17_18  out_degree_1443  1
    arc_2_17_18  in_degree_1450  1
    arc_2_17_18  original_T_including_depot_unload_1471  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1301  1
    load_2_17_18  free_load_conservation_1448  1
    load_2_17_18  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1303  -30
    arc_2_17_19  connected_order_arc_1304  -14
    arc_2_17_19  out_degree_1443  1
    arc_2_17_19  in_degree_1456  1
    arc_2_17_19  original_T_including_depot_unload_1471  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1303  1
    load_2_17_19  free_load_conservation_1448  1
    load_2_17_19  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1305  -30
    arc_2_17_20  connected_order_arc_1306  -14
    arc_2_17_20  out_degree_1443  1
    arc_2_17_20  in_degree_1462  1
    arc_2_17_20  original_T_including_depot_unload_1471  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1305  1
    load_2_17_20  free_load_conservation_1448  1
    load_2_17_20  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1307  -30
    arc_2_18_0  depot_return_or_bypass_1383  1
    arc_2_18_0  out_degree_1449  1
    arc_2_18_0  original_T_including_depot_unload_1471  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1307  1
    load_2_18_0  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_8  arc_capacity_1308  -30
    arc_2_18_8  connected_order_arc_1309  -14
    arc_2_18_8  in_degree_1385  1
    arc_2_18_8  out_degree_1449  1
    arc_2_18_8  original_T_including_depot_unload_1471  1.3060135543268104e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_8  arc_capacity_1308  1
    load_2_18_8  segment_load_conservation_1388  -1
    load_2_18_8  segment_prefix_lb_1389  1
    load_2_18_8  segment_prefix_ub_1390  1
    load_2_18_8  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_9  arc_capacity_1310  -30
    arc_2_18_9  connected_order_arc_1311  -14
    arc_2_18_9  in_degree_1392  1
    arc_2_18_9  out_degree_1449  1
    arc_2_18_9  original_T_including_depot_unload_1471  1.8758493536744261e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_9  arc_capacity_1310  1
    load_2_18_9  segment_load_conservation_1395  -1
    load_2_18_9  segment_prefix_lb_1396  1
    load_2_18_9  segment_prefix_ub_1397  1
    load_2_18_9  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1312  -30
    arc_2_18_10  connected_order_arc_1313  -14
    arc_2_18_10  in_degree_1399  1
    arc_2_18_10  out_degree_1449  1
    arc_2_18_10  original_T_including_depot_unload_1471  1.8936300338347210e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1312  1
    load_2_18_10  segment_load_conservation_1402  -1
    load_2_18_10  segment_prefix_lb_1403  1
    load_2_18_10  segment_prefix_ub_1404  1
    load_2_18_10  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1314  -30
    arc_2_18_11  connected_order_arc_1315  -14
    arc_2_18_11  in_degree_1406  1
    arc_2_18_11  out_degree_1449  1
    arc_2_18_11  original_T_including_depot_unload_1471  1.9868605646773756e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1314  1
    load_2_18_11  segment_load_conservation_1409  -1
    load_2_18_11  segment_prefix_lb_1410  1
    load_2_18_11  segment_prefix_ub_1411  1
    load_2_18_11  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1316  -30
    arc_2_18_12  connected_order_arc_1317  -14
    arc_2_18_12  in_degree_1413  1
    arc_2_18_12  out_degree_1449  1
    arc_2_18_12  original_T_including_depot_unload_1471  9.5968099967049886e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1316  1
    load_2_18_12  segment_load_conservation_1416  -1
    load_2_18_12  segment_prefix_lb_1417  1
    load_2_18_12  segment_prefix_ub_1418  1
    load_2_18_12  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1318  -30
    arc_2_18_13  connected_order_arc_1319  -14
    arc_2_18_13  in_degree_1420  1
    arc_2_18_13  out_degree_1449  1
    arc_2_18_13  original_T_including_depot_unload_1471  5.3222543932043470e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1318  1
    load_2_18_13  free_load_conservation_1424  -1
    load_2_18_13  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1320  -30
    arc_2_18_14  connected_order_arc_1321  -14
    arc_2_18_14  in_degree_1426  1
    arc_2_18_14  out_degree_1449  1
    arc_2_18_14  original_T_including_depot_unload_1471  3.7840168155842611e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1320  1
    load_2_18_14  free_load_conservation_1430  -1
    load_2_18_14  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1322  -30
    arc_2_18_15  connected_order_arc_1323  -14
    arc_2_18_15  in_degree_1432  1
    arc_2_18_15  out_degree_1449  1
    arc_2_18_15  original_T_including_depot_unload_1471  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1322  1
    load_2_18_15  free_load_conservation_1436  -1
    load_2_18_15  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1324  -30
    arc_2_18_16  connected_order_arc_1325  -14
    arc_2_18_16  in_degree_1438  1
    arc_2_18_16  out_degree_1449  1
    arc_2_18_16  original_T_including_depot_unload_1471  6.7500260835612892e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1324  1
    load_2_18_16  free_load_conservation_1442  -1
    load_2_18_16  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1326  -30
    arc_2_18_17  connected_order_arc_1327  -14
    arc_2_18_17  in_degree_1444  1
    arc_2_18_17  out_degree_1449  1
    arc_2_18_17  original_T_including_depot_unload_1471  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1326  1
    load_2_18_17  free_load_conservation_1448  -1
    load_2_18_17  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1328  -30
    arc_2_18_19  connected_order_arc_1329  -14
    arc_2_18_19  out_degree_1449  1
    arc_2_18_19  in_degree_1456  1
    arc_2_18_19  original_T_including_depot_unload_1471  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1328  1
    load_2_18_19  free_load_conservation_1454  1
    load_2_18_19  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1330  -30
    arc_2_18_20  connected_order_arc_1331  -14
    arc_2_18_20  out_degree_1449  1
    arc_2_18_20  in_degree_1462  1
    arc_2_18_20  original_T_including_depot_unload_1471  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1330  1
    load_2_18_20  free_load_conservation_1454  1
    load_2_18_20  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1332  -30
    arc_2_19_0  depot_return_or_bypass_1383  1
    arc_2_19_0  out_degree_1455  1
    arc_2_19_0  original_T_including_depot_unload_1471  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1332  1
    load_2_19_0  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_8  arc_capacity_1333  -30
    arc_2_19_8  connected_order_arc_1334  -14
    arc_2_19_8  in_degree_1385  1
    arc_2_19_8  out_degree_1455  1
    arc_2_19_8  original_T_including_depot_unload_1471  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_8  arc_capacity_1333  1
    load_2_19_8  segment_load_conservation_1388  -1
    load_2_19_8  segment_prefix_lb_1389  1
    load_2_19_8  segment_prefix_ub_1390  1
    load_2_19_8  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_9  arc_capacity_1335  -30
    arc_2_19_9  connected_order_arc_1336  -14
    arc_2_19_9  in_degree_1392  1
    arc_2_19_9  out_degree_1455  1
    arc_2_19_9  original_T_including_depot_unload_1471  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_9  arc_capacity_1335  1
    load_2_19_9  segment_load_conservation_1395  -1
    load_2_19_9  segment_prefix_lb_1396  1
    load_2_19_9  segment_prefix_ub_1397  1
    load_2_19_9  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1337  -30
    arc_2_19_10  connected_order_arc_1338  -14
    arc_2_19_10  in_degree_1399  1
    arc_2_19_10  out_degree_1455  1
    arc_2_19_10  original_T_including_depot_unload_1471  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1337  1
    load_2_19_10  segment_load_conservation_1402  -1
    load_2_19_10  segment_prefix_lb_1403  1
    load_2_19_10  segment_prefix_ub_1404  1
    load_2_19_10  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1339  -30
    arc_2_19_11  connected_order_arc_1340  -14
    arc_2_19_11  in_degree_1406  1
    arc_2_19_11  out_degree_1455  1
    arc_2_19_11  original_T_including_depot_unload_1471  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1339  1
    load_2_19_11  segment_load_conservation_1409  -1
    load_2_19_11  segment_prefix_lb_1410  1
    load_2_19_11  segment_prefix_ub_1411  1
    load_2_19_11  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1341  -30
    arc_2_19_12  connected_order_arc_1342  -14
    arc_2_19_12  in_degree_1413  1
    arc_2_19_12  out_degree_1455  1
    arc_2_19_12  original_T_including_depot_unload_1471  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1341  1
    load_2_19_12  segment_load_conservation_1416  -1
    load_2_19_12  segment_prefix_lb_1417  1
    load_2_19_12  segment_prefix_ub_1418  1
    load_2_19_12  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1343  -30
    arc_2_19_13  connected_order_arc_1344  -14
    arc_2_19_13  in_degree_1420  1
    arc_2_19_13  out_degree_1455  1
    arc_2_19_13  original_T_including_depot_unload_1471  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1343  1
    load_2_19_13  free_load_conservation_1424  -1
    load_2_19_13  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1345  -30
    arc_2_19_14  connected_order_arc_1346  -14
    arc_2_19_14  in_degree_1426  1
    arc_2_19_14  out_degree_1455  1
    arc_2_19_14  original_T_including_depot_unload_1471  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1345  1
    load_2_19_14  free_load_conservation_1430  -1
    load_2_19_14  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1347  -30
    arc_2_19_15  connected_order_arc_1348  -14
    arc_2_19_15  in_degree_1432  1
    arc_2_19_15  out_degree_1455  1
    arc_2_19_15  original_T_including_depot_unload_1471  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1347  1
    load_2_19_15  free_load_conservation_1436  -1
    load_2_19_15  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1349  -30
    arc_2_19_16  connected_order_arc_1350  -14
    arc_2_19_16  in_degree_1438  1
    arc_2_19_16  out_degree_1455  1
    arc_2_19_16  original_T_including_depot_unload_1471  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1349  1
    load_2_19_16  free_load_conservation_1442  -1
    load_2_19_16  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1351  -30
    arc_2_19_17  connected_order_arc_1352  -14
    arc_2_19_17  in_degree_1444  1
    arc_2_19_17  out_degree_1455  1
    arc_2_19_17  original_T_including_depot_unload_1471  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1351  1
    load_2_19_17  free_load_conservation_1448  -1
    load_2_19_17  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1353  -30
    arc_2_19_18  connected_order_arc_1354  -14
    arc_2_19_18  in_degree_1450  1
    arc_2_19_18  out_degree_1455  1
    arc_2_19_18  original_T_including_depot_unload_1471  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1353  1
    load_2_19_18  free_load_conservation_1454  -1
    load_2_19_18  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1355  -30
    arc_2_19_20  connected_order_arc_1356  -14
    arc_2_19_20  out_degree_1455  1
    arc_2_19_20  in_degree_1462  1
    arc_2_19_20  original_T_including_depot_unload_1471  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1355  1
    load_2_19_20  free_load_conservation_1460  1
    load_2_19_20  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1357  -30
    arc_2_20_0  depot_return_or_bypass_1383  1
    arc_2_20_0  out_degree_1461  1
    arc_2_20_0  original_T_including_depot_unload_1471  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1357  1
    load_2_20_0  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_8  arc_capacity_1358  -30
    arc_2_20_8  connected_order_arc_1359  -14
    arc_2_20_8  in_degree_1385  1
    arc_2_20_8  out_degree_1461  1
    arc_2_20_8  original_T_including_depot_unload_1471  1.1827214856899616e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_8  arc_capacity_1358  1
    load_2_20_8  segment_load_conservation_1388  -1
    load_2_20_8  segment_prefix_lb_1389  1
    load_2_20_8  segment_prefix_ub_1390  1
    load_2_20_8  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_9  arc_capacity_1360  -30
    arc_2_20_9  connected_order_arc_1361  -14
    arc_2_20_9  in_degree_1392  1
    arc_2_20_9  out_degree_1461  1
    arc_2_20_9  original_T_including_depot_unload_1471  1.7224091675467555e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_9  arc_capacity_1360  1
    load_2_20_9  segment_load_conservation_1395  -1
    load_2_20_9  segment_prefix_lb_1396  1
    load_2_20_9  segment_prefix_ub_1397  1
    load_2_20_9  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1362  -30
    arc_2_20_10  connected_order_arc_1363  -14
    arc_2_20_10  in_degree_1399  1
    arc_2_20_10  out_degree_1461  1
    arc_2_20_10  original_T_including_depot_unload_1471  1.7489516402613351e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1362  1
    load_2_20_10  segment_load_conservation_1402  -1
    load_2_20_10  segment_prefix_lb_1403  1
    load_2_20_10  segment_prefix_ub_1404  1
    load_2_20_10  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1364  -30
    arc_2_20_11  connected_order_arc_1365  -14
    arc_2_20_11  in_degree_1406  1
    arc_2_20_11  out_degree_1461  1
    arc_2_20_11  original_T_including_depot_unload_1471  1.8746346603188274e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1364  1
    load_2_20_11  segment_load_conservation_1409  -1
    load_2_20_11  segment_prefix_lb_1410  1
    load_2_20_11  segment_prefix_ub_1411  1
    load_2_20_11  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1366  -30
    arc_2_20_12  connected_order_arc_1367  -14
    arc_2_20_12  in_degree_1413  1
    arc_2_20_12  out_degree_1461  1
    arc_2_20_12  original_T_including_depot_unload_1471  8.5579830526745980e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1366  1
    load_2_20_12  segment_load_conservation_1416  -1
    load_2_20_12  segment_prefix_lb_1417  1
    load_2_20_12  segment_prefix_ub_1418  1
    load_2_20_12  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1368  -30
    arc_2_20_13  connected_order_arc_1369  -14
    arc_2_20_13  in_degree_1420  1
    arc_2_20_13  out_degree_1461  1
    arc_2_20_13  original_T_including_depot_unload_1471  552.429776828834
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1368  1
    load_2_20_13  free_load_conservation_1424  -1
    load_2_20_13  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1370  -30
    arc_2_20_14  connected_order_arc_1371  -14
    arc_2_20_14  in_degree_1426  1
    arc_2_20_14  out_degree_1461  1
    arc_2_20_14  original_T_including_depot_unload_1471  4.8778172744463808e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1370  1
    load_2_20_14  free_load_conservation_1430  -1
    load_2_20_14  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1372  -30
    arc_2_20_15  connected_order_arc_1373  -14
    arc_2_20_15  in_degree_1432  1
    arc_2_20_15  out_degree_1461  1
    arc_2_20_15  original_T_including_depot_unload_1471  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1372  1
    load_2_20_15  free_load_conservation_1436  -1
    load_2_20_15  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1374  -30
    arc_2_20_16  connected_order_arc_1375  -14
    arc_2_20_16  in_degree_1438  1
    arc_2_20_16  out_degree_1461  1
    arc_2_20_16  original_T_including_depot_unload_1471  7.7576476069541832e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1374  1
    load_2_20_16  free_load_conservation_1442  -1
    load_2_20_16  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1376  -30
    arc_2_20_17  connected_order_arc_1377  -14
    arc_2_20_17  in_degree_1444  1
    arc_2_20_17  out_degree_1461  1
    arc_2_20_17  original_T_including_depot_unload_1471  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1376  1
    load_2_20_17  free_load_conservation_1448  -1
    load_2_20_17  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1378  -30
    arc_2_20_18  connected_order_arc_1379  -14
    arc_2_20_18  in_degree_1450  1
    arc_2_20_18  out_degree_1461  1
    arc_2_20_18  original_T_including_depot_unload_1471  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1378  1
    load_2_20_18  free_load_conservation_1454  -1
    load_2_20_18  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1380  -30
    arc_2_20_19  connected_order_arc_1381  -14
    arc_2_20_19  in_degree_1456  1
    arc_2_20_19  out_degree_1461  1
    arc_2_20_19  original_T_including_depot_unload_1471  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1380  1
    load_2_20_19  free_load_conservation_1460  -1
    load_2_20_19  free_load_conservation_1466  1
RHS
    RHS1      OBJ       -2.4027184693691542e-01
    RHS1      onehot_16_32  1
    RHS1      onehot_12_61  1
    RHS1      onehot_34_96  1
    RHS1      onehot_14_117  1
    RHS1      onehot_29_142  1
    RHS1      onehot_13_163  1
    RHS1      onehot_27_180  1
    RHS1      onehot_15_201  1
    RHS1      stock_ub_205  26
    RHS1      parent_nonstrict_scope_206  2.7585198987888115e-01
    RHS1      normalization_263  1
    RHS1      connected_order_arc_363  -13
    RHS1      connected_order_arc_365  -13
    RHS1      connected_order_arc_367  -13
    RHS1      connected_order_arc_369  -13
    RHS1      connected_order_arc_371  -13
    RHS1      connected_order_arc_373  -13
    RHS1      connected_order_arc_375  -13
    RHS1      connected_order_arc_377  -13
    RHS1      connected_order_arc_379  -13
    RHS1      connected_order_arc_381  -13
    RHS1      connected_order_arc_383  -13
    RHS1      connected_order_arc_385  -13
    RHS1      connected_order_arc_388  -13
    RHS1      connected_order_arc_390  -13
    RHS1      connected_order_arc_392  -13
    RHS1      connected_order_arc_394  -13
    RHS1      connected_order_arc_396  -13
    RHS1      connected_order_arc_398  -13
    RHS1      connected_order_arc_400  -13
    RHS1      connected_order_arc_402  -13
    RHS1      connected_order_arc_404  -13
    RHS1      connected_order_arc_406  -13
    RHS1      connected_order_arc_408  -13
    RHS1      connected_order_arc_410  -13
    RHS1      connected_order_arc_413  -13
    RHS1      connected_order_arc_415  -13
    RHS1      connected_order_arc_417  -13
    RHS1      connected_order_arc_419  -13
    RHS1      connected_order_arc_421  -13
    RHS1      connected_order_arc_423  -13
    RHS1      connected_order_arc_425  -13
    RHS1      connected_order_arc_427  -13
    RHS1      connected_order_arc_429  -13
    RHS1      connected_order_arc_431  -13
    RHS1      connected_order_arc_433  -13
    RHS1      connected_order_arc_435  -13
    RHS1      connected_order_arc_438  -13
    RHS1      connected_order_arc_440  -13
    RHS1      connected_order_arc_442  -13
    RHS1      connected_order_arc_444  -13
    RHS1      connected_order_arc_446  -13
    RHS1      connected_order_arc_448  -13
    RHS1      connected_order_arc_450  -13
    RHS1      connected_order_arc_452  -13
    RHS1      connected_order_arc_454  -13
    RHS1      connected_order_arc_456  -13
    RHS1      connected_order_arc_458  -13
    RHS1      connected_order_arc_460  -13
    RHS1      connected_order_arc_463  -13
    RHS1      connected_order_arc_465  -13
    RHS1      connected_order_arc_467  -13
    RHS1      connected_order_arc_469  -13
    RHS1      connected_order_arc_471  -13
    RHS1      connected_order_arc_473  -13
    RHS1      connected_order_arc_475  -13
    RHS1      connected_order_arc_477  -13
    RHS1      connected_order_arc_479  -13
    RHS1      connected_order_arc_481  -13
    RHS1      connected_order_arc_483  -13
    RHS1      connected_order_arc_485  -13
    RHS1      connected_order_arc_488  -13
    RHS1      connected_order_arc_490  -13
    RHS1      connected_order_arc_492  -13
    RHS1      connected_order_arc_494  -13
    RHS1      connected_order_arc_496  -13
    RHS1      connected_order_arc_498  -13
    RHS1      connected_order_arc_500  -13
    RHS1      connected_order_arc_502  -13
    RHS1      connected_order_arc_504  -13
    RHS1      connected_order_arc_506  -13
    RHS1      connected_order_arc_508  -13
    RHS1      connected_order_arc_510  -13
    RHS1      connected_order_arc_513  -13
    RHS1      connected_order_arc_515  -13
    RHS1      connected_order_arc_517  -13
    RHS1      connected_order_arc_519  -13
    RHS1      connected_order_arc_521  -13
    RHS1      connected_order_arc_523  -13
    RHS1      connected_order_arc_525  -13
    RHS1      connected_order_arc_527  -13
    RHS1      connected_order_arc_529  -13
    RHS1      connected_order_arc_531  -13
    RHS1      connected_order_arc_533  -13
    RHS1      connected_order_arc_535  -13
    RHS1      connected_order_arc_538  -13
    RHS1      connected_order_arc_540  -13
    RHS1      connected_order_arc_542  -13
    RHS1      connected_order_arc_544  -13
    RHS1      connected_order_arc_546  -13
    RHS1      connected_order_arc_548  -13
    RHS1      connected_order_arc_550  -13
    RHS1      connected_order_arc_552  -13
    RHS1      connected_order_arc_554  -13
    RHS1      connected_order_arc_556  -13
    RHS1      connected_order_arc_558  -13
    RHS1      connected_order_arc_560  -13
    RHS1      connected_order_arc_563  -13
    RHS1      connected_order_arc_565  -13
    RHS1      connected_order_arc_567  -13
    RHS1      connected_order_arc_569  -13
    RHS1      connected_order_arc_571  -13
    RHS1      connected_order_arc_573  -13
    RHS1      connected_order_arc_575  -13
    RHS1      connected_order_arc_577  -13
    RHS1      connected_order_arc_579  -13
    RHS1      connected_order_arc_581  -13
    RHS1      connected_order_arc_583  -13
    RHS1      connected_order_arc_585  -13
    RHS1      connected_order_arc_588  -13
    RHS1      connected_order_arc_590  -13
    RHS1      connected_order_arc_592  -13
    RHS1      connected_order_arc_594  -13
    RHS1      connected_order_arc_596  -13
    RHS1      connected_order_arc_598  -13
    RHS1      connected_order_arc_600  -13
    RHS1      connected_order_arc_602  -13
    RHS1      connected_order_arc_604  -13
    RHS1      connected_order_arc_606  -13
    RHS1      connected_order_arc_608  -13
    RHS1      connected_order_arc_610  -13
    RHS1      connected_order_arc_613  -13
    RHS1      connected_order_arc_615  -13
    RHS1      connected_order_arc_617  -13
    RHS1      connected_order_arc_619  -13
    RHS1      connected_order_arc_621  -13
    RHS1      connected_order_arc_623  -13
    RHS1      connected_order_arc_625  -13
    RHS1      connected_order_arc_627  -13
    RHS1      connected_order_arc_629  -13
    RHS1      connected_order_arc_631  -13
    RHS1      connected_order_arc_633  -13
    RHS1      connected_order_arc_635  -13
    RHS1      connected_order_arc_638  -13
    RHS1      connected_order_arc_640  -13
    RHS1      connected_order_arc_642  -13
    RHS1      connected_order_arc_644  -13
    RHS1      connected_order_arc_646  -13
    RHS1      connected_order_arc_648  -13
    RHS1      connected_order_arc_650  -13
    RHS1      connected_order_arc_652  -13
    RHS1      connected_order_arc_654  -13
    RHS1      connected_order_arc_656  -13
    RHS1      connected_order_arc_658  -13
    RHS1      connected_order_arc_660  -13
    RHS1      connected_order_arc_663  -13
    RHS1      connected_order_arc_665  -13
    RHS1      connected_order_arc_667  -13
    RHS1      connected_order_arc_669  -13
    RHS1      connected_order_arc_671  -13
    RHS1      connected_order_arc_673  -13
    RHS1      connected_order_arc_675  -13
    RHS1      connected_order_arc_677  -13
    RHS1      connected_order_arc_679  -13
    RHS1      connected_order_arc_681  -13
    RHS1      connected_order_arc_683  -13
    RHS1      connected_order_arc_685  -13
    RHS1      depot_departure_or_bypass_686  1
    RHS1      depot_return_or_bypass_687  1
    RHS1      segment_load_conservation_692  -2
    RHS1      segment_prefix_lb_693  2
    RHS1      segment_prefix_ub_694  20
    RHS1      segment_load_conservation_699  1
    RHS1      segment_prefix_ub_701  19
    RHS1      segment_load_conservation_706  3
    RHS1      segment_prefix_ub_708  17
    RHS1      segment_load_conservation_713  -4
    RHS1      segment_prefix_lb_714  4
    RHS1      segment_prefix_ub_715  14
    RHS1      segment_prefix_ub_722  15
    RHS1      fixed_segment_relative_order_771  1
    RHS1      fixed_segment_relative_order_772  1
    RHS1      fixed_segment_relative_order_773  1
    RHS1      fixed_segment_relative_order_774  1
    RHS1      original_T_including_depot_unload_775  2.5264082199032355e+03
    RHS1      connected_order_arc_789  -10
    RHS1      connected_order_arc_791  -10
    RHS1      connected_order_arc_793  -10
    RHS1      connected_order_arc_795  -10
    RHS1      connected_order_arc_797  -10
    RHS1      connected_order_arc_799  -10
    RHS1      connected_order_arc_801  -10
    RHS1      connected_order_arc_803  -10
    RHS1      connected_order_arc_805  -10
    RHS1      connected_order_arc_808  -10
    RHS1      connected_order_arc_810  -10
    RHS1      connected_order_arc_812  -10
    RHS1      connected_order_arc_814  -10
    RHS1      connected_order_arc_816  -10
    RHS1      connected_order_arc_818  -10
    RHS1      connected_order_arc_820  -10
    RHS1      connected_order_arc_822  -10
    RHS1      connected_order_arc_824  -10
    RHS1      connected_order_arc_827  -10
    RHS1      connected_order_arc_829  -10
    RHS1      connected_order_arc_831  -10
    RHS1      connected_order_arc_833  -10
    RHS1      connected_order_arc_835  -10
    RHS1      connected_order_arc_837  -10
    RHS1      connected_order_arc_839  -10
    RHS1      connected_order_arc_841  -10
    RHS1      connected_order_arc_843  -10
    RHS1      connected_order_arc_846  -10
    RHS1      connected_order_arc_848  -10
    RHS1      connected_order_arc_850  -10
    RHS1      connected_order_arc_852  -10
    RHS1      connected_order_arc_854  -10
    RHS1      connected_order_arc_856  -10
    RHS1      connected_order_arc_858  -10
    RHS1      connected_order_arc_860  -10
    RHS1      connected_order_arc_862  -10
    RHS1      connected_order_arc_865  -10
    RHS1      connected_order_arc_867  -10
    RHS1      connected_order_arc_869  -10
    RHS1      connected_order_arc_871  -10
    RHS1      connected_order_arc_873  -10
    RHS1      connected_order_arc_875  -10
    RHS1      connected_order_arc_877  -10
    RHS1      connected_order_arc_879  -10
    RHS1      connected_order_arc_881  -10
    RHS1      connected_order_arc_884  -10
    RHS1      connected_order_arc_886  -10
    RHS1      connected_order_arc_888  -10
    RHS1      connected_order_arc_890  -10
    RHS1      connected_order_arc_892  -10
    RHS1      connected_order_arc_894  -10
    RHS1      connected_order_arc_896  -10
    RHS1      connected_order_arc_898  -10
    RHS1      connected_order_arc_900  -10
    RHS1      connected_order_arc_903  -10
    RHS1      connected_order_arc_905  -10
    RHS1      connected_order_arc_907  -10
    RHS1      connected_order_arc_909  -10
    RHS1      connected_order_arc_911  -10
    RHS1      connected_order_arc_913  -10
    RHS1      connected_order_arc_915  -10
    RHS1      connected_order_arc_917  -10
    RHS1      connected_order_arc_919  -10
    RHS1      connected_order_arc_922  -10
    RHS1      connected_order_arc_924  -10
    RHS1      connected_order_arc_926  -10
    RHS1      connected_order_arc_928  -10
    RHS1      connected_order_arc_930  -10
    RHS1      connected_order_arc_932  -10
    RHS1      connected_order_arc_934  -10
    RHS1      connected_order_arc_936  -10
    RHS1      connected_order_arc_938  -10
    RHS1      connected_order_arc_941  -10
    RHS1      connected_order_arc_943  -10
    RHS1      connected_order_arc_945  -10
    RHS1      connected_order_arc_947  -10
    RHS1      connected_order_arc_949  -10
    RHS1      connected_order_arc_951  -10
    RHS1      connected_order_arc_953  -10
    RHS1      connected_order_arc_955  -10
    RHS1      connected_order_arc_957  -10
    RHS1      connected_order_arc_960  -10
    RHS1      connected_order_arc_962  -10
    RHS1      connected_order_arc_964  -10
    RHS1      connected_order_arc_966  -10
    RHS1      connected_order_arc_968  -10
    RHS1      connected_order_arc_970  -10
    RHS1      connected_order_arc_972  -10
    RHS1      connected_order_arc_974  -10
    RHS1      connected_order_arc_976  -10
    RHS1      depot_departure_or_bypass_977  1
    RHS1      depot_return_or_bypass_978  1
    RHS1      segment_load_conservation_983  5
    RHS1      segment_prefix_ub_985  20
    RHS1      segment_load_conservation_990  5
    RHS1      segment_prefix_ub_992  20
    RHS1      fixed_segment_relative_order_1041  1
    RHS1      original_T_including_depot_unload_1042  5100
    RHS1      connected_order_arc_1059  -13
    RHS1      connected_order_arc_1061  -13
    RHS1      connected_order_arc_1063  -13
    RHS1      connected_order_arc_1065  -13
    RHS1      connected_order_arc_1067  -13
    RHS1      connected_order_arc_1069  -13
    RHS1      connected_order_arc_1071  -13
    RHS1      connected_order_arc_1073  -13
    RHS1      connected_order_arc_1075  -13
    RHS1      connected_order_arc_1077  -13
    RHS1      connected_order_arc_1079  -13
    RHS1      connected_order_arc_1081  -13
    RHS1      connected_order_arc_1084  -13
    RHS1      connected_order_arc_1086  -13
    RHS1      connected_order_arc_1088  -13
    RHS1      connected_order_arc_1090  -13
    RHS1      connected_order_arc_1092  -13
    RHS1      connected_order_arc_1094  -13
    RHS1      connected_order_arc_1096  -13
    RHS1      connected_order_arc_1098  -13
    RHS1      connected_order_arc_1100  -13
    RHS1      connected_order_arc_1102  -13
    RHS1      connected_order_arc_1104  -13
    RHS1      connected_order_arc_1106  -13
    RHS1      connected_order_arc_1109  -13
    RHS1      connected_order_arc_1111  -13
    RHS1      connected_order_arc_1113  -13
    RHS1      connected_order_arc_1115  -13
    RHS1      connected_order_arc_1117  -13
    RHS1      connected_order_arc_1119  -13
    RHS1      connected_order_arc_1121  -13
    RHS1      connected_order_arc_1123  -13
    RHS1      connected_order_arc_1125  -13
    RHS1      connected_order_arc_1127  -13
    RHS1      connected_order_arc_1129  -13
    RHS1      connected_order_arc_1131  -13
    RHS1      connected_order_arc_1134  -13
    RHS1      connected_order_arc_1136  -13
    RHS1      connected_order_arc_1138  -13
    RHS1      connected_order_arc_1140  -13
    RHS1      connected_order_arc_1142  -13
    RHS1      connected_order_arc_1144  -13
    RHS1      connected_order_arc_1146  -13
    RHS1      connected_order_arc_1148  -13
    RHS1      connected_order_arc_1150  -13
    RHS1      connected_order_arc_1152  -13
    RHS1      connected_order_arc_1154  -13
    RHS1      connected_order_arc_1156  -13
    RHS1      connected_order_arc_1159  -13
    RHS1      connected_order_arc_1161  -13
    RHS1      connected_order_arc_1163  -13
    RHS1      connected_order_arc_1165  -13
    RHS1      connected_order_arc_1167  -13
    RHS1      connected_order_arc_1169  -13
    RHS1      connected_order_arc_1171  -13
    RHS1      connected_order_arc_1173  -13
    RHS1      connected_order_arc_1175  -13
    RHS1      connected_order_arc_1177  -13
    RHS1      connected_order_arc_1179  -13
    RHS1      connected_order_arc_1181  -13
    RHS1      connected_order_arc_1184  -13
    RHS1      connected_order_arc_1186  -13
    RHS1      connected_order_arc_1188  -13
    RHS1      connected_order_arc_1190  -13
    RHS1      connected_order_arc_1192  -13
    RHS1      connected_order_arc_1194  -13
    RHS1      connected_order_arc_1196  -13
    RHS1      connected_order_arc_1198  -13
    RHS1      connected_order_arc_1200  -13
    RHS1      connected_order_arc_1202  -13
    RHS1      connected_order_arc_1204  -13
    RHS1      connected_order_arc_1206  -13
    RHS1      connected_order_arc_1209  -13
    RHS1      connected_order_arc_1211  -13
    RHS1      connected_order_arc_1213  -13
    RHS1      connected_order_arc_1215  -13
    RHS1      connected_order_arc_1217  -13
    RHS1      connected_order_arc_1219  -13
    RHS1      connected_order_arc_1221  -13
    RHS1      connected_order_arc_1223  -13
    RHS1      connected_order_arc_1225  -13
    RHS1      connected_order_arc_1227  -13
    RHS1      connected_order_arc_1229  -13
    RHS1      connected_order_arc_1231  -13
    RHS1      connected_order_arc_1234  -13
    RHS1      connected_order_arc_1236  -13
    RHS1      connected_order_arc_1238  -13
    RHS1      connected_order_arc_1240  -13
    RHS1      connected_order_arc_1242  -13
    RHS1      connected_order_arc_1244  -13
    RHS1      connected_order_arc_1246  -13
    RHS1      connected_order_arc_1248  -13
    RHS1      connected_order_arc_1250  -13
    RHS1      connected_order_arc_1252  -13
    RHS1      connected_order_arc_1254  -13
    RHS1      connected_order_arc_1256  -13
    RHS1      connected_order_arc_1259  -13
    RHS1      connected_order_arc_1261  -13
    RHS1      connected_order_arc_1263  -13
    RHS1      connected_order_arc_1265  -13
    RHS1      connected_order_arc_1267  -13
    RHS1      connected_order_arc_1269  -13
    RHS1      connected_order_arc_1271  -13
    RHS1      connected_order_arc_1273  -13
    RHS1      connected_order_arc_1275  -13
    RHS1      connected_order_arc_1277  -13
    RHS1      connected_order_arc_1279  -13
    RHS1      connected_order_arc_1281  -13
    RHS1      connected_order_arc_1284  -13
    RHS1      connected_order_arc_1286  -13
    RHS1      connected_order_arc_1288  -13
    RHS1      connected_order_arc_1290  -13
    RHS1      connected_order_arc_1292  -13
    RHS1      connected_order_arc_1294  -13
    RHS1      connected_order_arc_1296  -13
    RHS1      connected_order_arc_1298  -13
    RHS1      connected_order_arc_1300  -13
    RHS1      connected_order_arc_1302  -13
    RHS1      connected_order_arc_1304  -13
    RHS1      connected_order_arc_1306  -13
    RHS1      connected_order_arc_1309  -13
    RHS1      connected_order_arc_1311  -13
    RHS1      connected_order_arc_1313  -13
    RHS1      connected_order_arc_1315  -13
    RHS1      connected_order_arc_1317  -13
    RHS1      connected_order_arc_1319  -13
    RHS1      connected_order_arc_1321  -13
    RHS1      connected_order_arc_1323  -13
    RHS1      connected_order_arc_1325  -13
    RHS1      connected_order_arc_1327  -13
    RHS1      connected_order_arc_1329  -13
    RHS1      connected_order_arc_1331  -13
    RHS1      connected_order_arc_1334  -13
    RHS1      connected_order_arc_1336  -13
    RHS1      connected_order_arc_1338  -13
    RHS1      connected_order_arc_1340  -13
    RHS1      connected_order_arc_1342  -13
    RHS1      connected_order_arc_1344  -13
    RHS1      connected_order_arc_1346  -13
    RHS1      connected_order_arc_1348  -13
    RHS1      connected_order_arc_1350  -13
    RHS1      connected_order_arc_1352  -13
    RHS1      connected_order_arc_1354  -13
    RHS1      connected_order_arc_1356  -13
    RHS1      connected_order_arc_1359  -13
    RHS1      connected_order_arc_1361  -13
    RHS1      connected_order_arc_1363  -13
    RHS1      connected_order_arc_1365  -13
    RHS1      connected_order_arc_1367  -13
    RHS1      connected_order_arc_1369  -13
    RHS1      connected_order_arc_1371  -13
    RHS1      connected_order_arc_1373  -13
    RHS1      connected_order_arc_1375  -13
    RHS1      connected_order_arc_1377  -13
    RHS1      connected_order_arc_1379  -13
    RHS1      connected_order_arc_1381  -13
    RHS1      depot_departure_or_bypass_1382  1
    RHS1      depot_return_or_bypass_1383  1
    RHS1      segment_load_conservation_1388  2
    RHS1      segment_prefix_ub_1390  28
    RHS1      segment_load_conservation_1395  2
    RHS1      segment_prefix_ub_1397  28
    RHS1      segment_load_conservation_1402  -4
    RHS1      segment_prefix_lb_1403  4
    RHS1      segment_prefix_ub_1404  30
    RHS1      segment_load_conservation_1409  3
    RHS1      segment_prefix_ub_1411  26
    RHS1      segment_load_conservation_1416  -3
    RHS1      segment_prefix_lb_1417  3
    RHS1      segment_prefix_ub_1418  30
    RHS1      fixed_segment_relative_order_1467  1
    RHS1      fixed_segment_relative_order_1468  1
    RHS1      fixed_segment_relative_order_1469  1
    RHS1      fixed_segment_relative_order_1470  1
    RHS1      original_T_including_depot_unload_1471  4.1591520335762489e+03
BOUNDS
 LO BND1      t         0.0257558103881511
 UP BND1      t         4.3334709038425519e-02
 UP BND1      q         4.0162002117312451e-01
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.3334709038425519e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.3334709038425519e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.3334709038425519e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.3334709038425519e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.3334709038425519e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.3334709038425519e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.3334709038425519e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.3334709038425519e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.3334709038425519e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.3334709038425519e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.3334709038425519e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.3334709038425519e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.3334709038425519e-02
 BV BND1      x_16_13 
 UP BND1      w_16_13   4.3334709038425519e-02
 BV BND1      x_16_14 
 UP BND1      w_16_14   4.3334709038425519e-02
 BV BND1      x_16_15 
 UP BND1      w_16_15   4.3334709038425519e-02
 UP BND1      rho_16    1
 BV BND1      x_12_0  
 UP BND1      w_12_0    4.3334709038425519e-02
 BV BND1      x_12_1  
 UP BND1      w_12_1    4.3334709038425519e-02
 BV BND1      x_12_2  
 UP BND1      w_12_2    4.3334709038425519e-02
 BV BND1      x_12_3  
 UP BND1      w_12_3    4.3334709038425519e-02
 BV BND1      x_12_4  
 UP BND1      w_12_4    4.3334709038425519e-02
 BV BND1      x_12_5  
 UP BND1      w_12_5    4.3334709038425519e-02
 BV BND1      x_12_6  
 UP BND1      w_12_6    4.3334709038425519e-02
 BV BND1      x_12_7  
 UP BND1      w_12_7    4.3334709038425519e-02
 BV BND1      x_12_8  
 UP BND1      w_12_8    4.3334709038425519e-02
 BV BND1      x_12_9  
 UP BND1      w_12_9    4.3334709038425519e-02
 BV BND1      x_12_10 
 UP BND1      w_12_10   4.3334709038425519e-02
 BV BND1      x_12_11 
 UP BND1      w_12_11   4.3334709038425519e-02
 BV BND1      x_12_12 
 UP BND1      w_12_12   4.3334709038425519e-02
 UP BND1      rho_12    1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.3334709038425519e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.3334709038425519e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.3334709038425519e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.3334709038425519e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.3334709038425519e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.3334709038425519e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.3334709038425519e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.3334709038425519e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.3334709038425519e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.3334709038425519e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.3334709038425519e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.3334709038425519e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.3334709038425519e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.3334709038425519e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.3334709038425519e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.3334709038425519e-02
 UP BND1      rho_34    1
 BV BND1      x_14_0  
 UP BND1      w_14_0    4.3334709038425519e-02
 BV BND1      x_14_1  
 UP BND1      w_14_1    4.3334709038425519e-02
 BV BND1      x_14_2  
 UP BND1      w_14_2    4.3334709038425519e-02
 BV BND1      x_14_3  
 UP BND1      w_14_3    4.3334709038425519e-02
 BV BND1      x_14_4  
 UP BND1      w_14_4    4.3334709038425519e-02
 BV BND1      x_14_5  
 UP BND1      w_14_5    4.3334709038425519e-02
 BV BND1      x_14_6  
 UP BND1      w_14_6    4.3334709038425519e-02
 BV BND1      x_14_7  
 UP BND1      w_14_7    4.3334709038425519e-02
 BV BND1      x_14_8  
 UP BND1      w_14_8    4.3334709038425519e-02
 UP BND1      rho_14    1
 BV BND1      x_29_0  
 UP BND1      w_29_0    4.3334709038425519e-02
 BV BND1      x_29_1  
 UP BND1      w_29_1    4.3334709038425519e-02
 BV BND1      x_29_2  
 UP BND1      w_29_2    4.3334709038425519e-02
 BV BND1      x_29_3  
 UP BND1      w_29_3    4.3334709038425519e-02
 BV BND1      x_29_4  
 UP BND1      w_29_4    4.3334709038425519e-02
 BV BND1      x_29_5  
 UP BND1      w_29_5    4.3334709038425519e-02
 BV BND1      x_29_6  
 UP BND1      w_29_6    4.3334709038425519e-02
 BV BND1      x_29_7  
 UP BND1      w_29_7    4.3334709038425519e-02
 BV BND1      x_29_8  
 UP BND1      w_29_8    4.3334709038425519e-02
 BV BND1      x_29_9  
 UP BND1      w_29_9    4.3334709038425519e-02
 BV BND1      x_29_10 
 UP BND1      w_29_10   4.3334709038425519e-02
 UP BND1      rho_29    1
 BV BND1      x_13_0  
 UP BND1      w_13_0    4.3334709038425519e-02
 BV BND1      x_13_1  
 UP BND1      w_13_1    4.3334709038425519e-02
 BV BND1      x_13_2  
 UP BND1      w_13_2    4.3334709038425519e-02
 BV BND1      x_13_3  
 UP BND1      w_13_3    4.3334709038425519e-02
 BV BND1      x_13_4  
 UP BND1      w_13_4    4.3334709038425519e-02
 BV BND1      x_13_5  
 UP BND1      w_13_5    4.3334709038425519e-02
 BV BND1      x_13_6  
 UP BND1      w_13_6    4.3334709038425519e-02
 BV BND1      x_13_7  
 UP BND1      w_13_7    4.3334709038425519e-02
 BV BND1      x_13_8  
 UP BND1      w_13_8    4.3334709038425519e-02
 UP BND1      rho_13    1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.3334709038425519e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.3334709038425519e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.3334709038425519e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.3334709038425519e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.3334709038425519e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.3334709038425519e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.3334709038425519e-02
 UP BND1      rho_27    1
 BV BND1      x_15_0  
 UP BND1      w_15_0    4.3334709038425519e-02
 BV BND1      x_15_1  
 UP BND1      w_15_1    4.3334709038425519e-02
 BV BND1      x_15_2  
 UP BND1      w_15_2    4.3334709038425519e-02
 BV BND1      x_15_3  
 UP BND1      w_15_3    4.3334709038425519e-02
 BV BND1      x_15_4  
 UP BND1      w_15_4    4.3334709038425519e-02
 BV BND1      x_15_5  
 UP BND1      w_15_5    4.3334709038425519e-02
 BV BND1      x_15_6  
 UP BND1      w_15_6    4.3334709038425519e-02
 BV BND1      x_15_7  
 UP BND1      w_15_7    4.3334709038425519e-02
 BV BND1      x_15_8  
 UP BND1      w_15_8    4.3334709038425519e-02
 UP BND1      rho_15    1
 UP BND1      a_16_12   1
 UP BND1      a_16_34   1
 UP BND1      a_16_14   1
 UP BND1      a_16_29   1
 UP BND1      a_16_13   1
 UP BND1      a_16_27   1
 UP BND1      a_16_15   1
 UP BND1      a_12_34   1
 UP BND1      a_12_14   1
 UP BND1      a_12_29   1
 UP BND1      a_12_13   1
 UP BND1      a_12_27   1
 UP BND1      a_12_15   1
 UP BND1      a_34_14   1
 UP BND1      a_34_29   1
 UP BND1      a_34_13   1
 UP BND1      a_34_27   1
 UP BND1      a_34_15   1
 UP BND1      a_14_29   1
 UP BND1      a_14_13   1
 UP BND1      a_14_27   1
 UP BND1      a_14_15   1
 UP BND1      a_29_13   1
 UP BND1      a_29_27   1
 UP BND1      a_29_15   1
 UP BND1      a_13_27   1
 UP BND1      a_13_15   1
 UP BND1      a_27_15   1
 BV BND1      service_0_16_0
 BV BND1      service_0_16_1
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_0_16_13
 BV BND1      service_0_16_14
 BV BND1      service_0_16_15
 BV BND1      service_1_16_0
 BV BND1      service_1_16_1
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_1_16_13
 BV BND1      service_1_16_14
 BV BND1      service_1_16_15
 BV BND1      service_2_16_0
 BV BND1      service_2_16_1
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_2_16_13
 BV BND1      service_2_16_14
 BV BND1      service_2_16_15
 BV BND1      service_0_12_0
 BV BND1      service_0_12_2
 BV BND1      service_0_12_3
 BV BND1      service_0_12_4
 BV BND1      service_0_12_5
 BV BND1      service_0_12_6
 BV BND1      service_0_12_7
 BV BND1      service_0_12_8
 BV BND1      service_0_12_9
 BV BND1      service_0_12_10
 BV BND1      service_0_12_11
 BV BND1      service_0_12_12
 BV BND1      service_1_12_0
 BV BND1      service_1_12_2
 BV BND1      service_1_12_3
 BV BND1      service_1_12_4
 BV BND1      service_1_12_5
 BV BND1      service_1_12_6
 BV BND1      service_1_12_7
 BV BND1      service_1_12_8
 BV BND1      service_1_12_9
 BV BND1      service_1_12_10
 BV BND1      service_1_12_11
 BV BND1      service_1_12_12
 BV BND1      service_2_12_0
 BV BND1      service_2_12_2
 BV BND1      service_2_12_3
 BV BND1      service_2_12_4
 BV BND1      service_2_12_5
 BV BND1      service_2_12_6
 BV BND1      service_2_12_7
 BV BND1      service_2_12_8
 BV BND1      service_2_12_9
 BV BND1      service_2_12_10
 BV BND1      service_2_12_11
 BV BND1      service_2_12_12
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_14_0
 BV BND1      service_0_14_1
 BV BND1      service_0_14_3
 BV BND1      service_0_14_4
 BV BND1      service_0_14_5
 BV BND1      service_0_14_6
 BV BND1      service_0_14_7
 BV BND1      service_0_14_8
 BV BND1      service_1_14_0
 BV BND1      service_1_14_1
 BV BND1      service_1_14_3
 BV BND1      service_1_14_4
 BV BND1      service_1_14_5
 BV BND1      service_1_14_6
 BV BND1      service_1_14_7
 BV BND1      service_1_14_8
 BV BND1      service_2_14_0
 BV BND1      service_2_14_1
 BV BND1      service_2_14_3
 BV BND1      service_2_14_4
 BV BND1      service_2_14_5
 BV BND1      service_2_14_6
 BV BND1      service_2_14_7
 BV BND1      service_2_14_8
 BV BND1      service_0_29_0
 BV BND1      service_0_29_2
 BV BND1      service_0_29_3
 BV BND1      service_0_29_4
 BV BND1      service_0_29_5
 BV BND1      service_0_29_6
 BV BND1      service_0_29_7
 BV BND1      service_0_29_8
 BV BND1      service_0_29_9
 BV BND1      service_0_29_10
 BV BND1      service_1_29_0
 BV BND1      service_1_29_2
 BV BND1      service_1_29_3
 BV BND1      service_1_29_4
 BV BND1      service_1_29_5
 BV BND1      service_1_29_6
 BV BND1      service_1_29_7
 BV BND1      service_1_29_8
 BV BND1      service_1_29_9
 BV BND1      service_1_29_10
 BV BND1      service_2_29_0
 BV BND1      service_2_29_2
 BV BND1      service_2_29_3
 BV BND1      service_2_29_4
 BV BND1      service_2_29_5
 BV BND1      service_2_29_6
 BV BND1      service_2_29_7
 BV BND1      service_2_29_8
 BV BND1      service_2_29_9
 BV BND1      service_2_29_10
 BV BND1      service_0_13_0
 BV BND1      service_0_13_1
 BV BND1      service_0_13_2
 BV BND1      service_0_13_3
 BV BND1      service_0_13_4
 BV BND1      service_0_13_6
 BV BND1      service_0_13_7
 BV BND1      service_0_13_8
 BV BND1      service_1_13_0
 BV BND1      service_1_13_1
 BV BND1      service_1_13_2
 BV BND1      service_1_13_3
 BV BND1      service_1_13_4
 BV BND1      service_1_13_6
 BV BND1      service_1_13_7
 BV BND1      service_1_13_8
 BV BND1      service_2_13_0
 BV BND1      service_2_13_1
 BV BND1      service_2_13_2
 BV BND1      service_2_13_3
 BV BND1      service_2_13_4
 BV BND1      service_2_13_6
 BV BND1      service_2_13_7
 BV BND1      service_2_13_8
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_15_0
 BV BND1      service_0_15_1
 BV BND1      service_0_15_2
 BV BND1      service_0_15_3
 BV BND1      service_0_15_4
 BV BND1      service_0_15_6
 BV BND1      service_0_15_7
 BV BND1      service_0_15_8
 BV BND1      service_1_15_0
 BV BND1      service_1_15_1
 BV BND1      service_1_15_2
 BV BND1      service_1_15_3
 BV BND1      service_1_15_4
 BV BND1      service_1_15_6
 BV BND1      service_1_15_7
 BV BND1      service_1_15_8
 BV BND1      service_2_15_0
 BV BND1      service_2_15_1
 BV BND1      service_2_15_2
 BV BND1      service_2_15_3
 BV BND1      service_2_15_4
 BV BND1      service_2_15_6
 BV BND1      service_2_15_7
 BV BND1      service_2_15_8
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_13_20
 UP BND1      load_0_13_20  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_13
 UP BND1      load_0_20_13  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  10
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  10
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  10
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  10
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  10
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  10
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  10
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  10
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  10
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  10
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_13_20
 UP BND1      load_1_13_20  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_13
 UP BND1      load_1_20_13  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 FX BND1      visit_2_8  1
 UP BND1      order_2_8  13
 FX BND1      visit_2_9  1
 UP BND1      order_2_9  13
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  13
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  13
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  13
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  13
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  13
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  13
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  13
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  13
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  13
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  13
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  13
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_8
 FX BND1      load_2_0_8  0
 BV BND1      arc_2_0_9
 FX BND1      load_2_0_9  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_8_0
 UP BND1      load_2_8_0  30
 BV BND1      arc_2_8_9
 UP BND1      load_2_8_9  30
 BV BND1      arc_2_8_10
 UP BND1      load_2_8_10  30
 BV BND1      arc_2_8_11
 UP BND1      load_2_8_11  30
 BV BND1      arc_2_8_12
 UP BND1      load_2_8_12  30
 BV BND1      arc_2_8_13
 UP BND1      load_2_8_13  30
 BV BND1      arc_2_8_14
 UP BND1      load_2_8_14  30
 BV BND1      arc_2_8_15
 UP BND1      load_2_8_15  30
 BV BND1      arc_2_8_16
 UP BND1      load_2_8_16  30
 BV BND1      arc_2_8_17
 UP BND1      load_2_8_17  30
 BV BND1      arc_2_8_18
 UP BND1      load_2_8_18  30
 BV BND1      arc_2_8_19
 UP BND1      load_2_8_19  30
 BV BND1      arc_2_8_20
 UP BND1      load_2_8_20  30
 BV BND1      arc_2_9_0
 UP BND1      load_2_9_0  30
 BV BND1      arc_2_9_8
 UP BND1      load_2_9_8  30
 BV BND1      arc_2_9_10
 UP BND1      load_2_9_10  30
 BV BND1      arc_2_9_11
 UP BND1      load_2_9_11  30
 BV BND1      arc_2_9_12
 UP BND1      load_2_9_12  30
 BV BND1      arc_2_9_13
 UP BND1      load_2_9_13  30
 BV BND1      arc_2_9_14
 UP BND1      load_2_9_14  30
 BV BND1      arc_2_9_15
 UP BND1      load_2_9_15  30
 BV BND1      arc_2_9_16
 UP BND1      load_2_9_16  30
 BV BND1      arc_2_9_17
 UP BND1      load_2_9_17  30
 BV BND1      arc_2_9_18
 UP BND1      load_2_9_18  30
 BV BND1      arc_2_9_19
 UP BND1      load_2_9_19  30
 BV BND1      arc_2_9_20
 UP BND1      load_2_9_20  30
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_8
 UP BND1      load_2_10_8  30
 BV BND1      arc_2_10_9
 UP BND1      load_2_10_9  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_8
 UP BND1      load_2_11_8  30
 BV BND1      arc_2_11_9
 UP BND1      load_2_11_9  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_8
 UP BND1      load_2_12_8  30
 BV BND1      arc_2_12_9
 UP BND1      load_2_12_9  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_8
 UP BND1      load_2_13_8  30
 BV BND1      arc_2_13_9
 UP BND1      load_2_13_9  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_8
 UP BND1      load_2_14_8  30
 BV BND1      arc_2_14_9
 UP BND1      load_2_14_9  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_8
 UP BND1      load_2_15_8  30
 BV BND1      arc_2_15_9
 UP BND1      load_2_15_9  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_8
 UP BND1      load_2_16_8  30
 BV BND1      arc_2_16_9
 UP BND1      load_2_16_9  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_8
 UP BND1      load_2_17_8  30
 BV BND1      arc_2_17_9
 UP BND1      load_2_17_9  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_8
 UP BND1      load_2_18_8  30
 BV BND1      arc_2_18_9
 UP BND1      load_2_18_9  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_8
 UP BND1      load_2_19_8  30
 BV BND1      arc_2_19_9
 UP BND1      load_2_19_9  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_8
 UP BND1      load_2_20_8  30
 BV BND1      arc_2_20_9
 UP BND1      load_2_20_9  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
ENDATA
