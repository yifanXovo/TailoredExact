* Signature: 0x2609f20de1c42e53
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 E  onehot_26_18
 E  normalized_mass_26_19
 E  normalized_ratio_26_20
 G  product_lb_21
 L  product_ub_22
 G  product_lb_23
 L  product_ub_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 E  onehot_32_47
 E  normalized_mass_32_48
 E  normalized_ratio_32_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 E  onehot_2_82
 E  normalized_mass_2_83
 E  normalized_ratio_2_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 E  onehot_30_103
 E  normalized_mass_30_104
 E  normalized_ratio_30_105
 G  product_lb_106
 L  product_ub_107
 G  product_lb_108
 L  product_ub_109
 G  product_lb_110
 L  product_ub_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 E  onehot_31_132
 E  normalized_mass_31_133
 E  normalized_ratio_31_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 G  product_lb_143
 L  product_ub_144
 G  product_lb_145
 L  product_ub_146
 G  product_lb_147
 L  product_ub_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 E  onehot_19_153
 E  normalized_mass_19_154
 E  normalized_ratio_19_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 G  product_lb_178
 L  product_ub_179
 G  product_lb_180
 L  product_ub_181
 G  product_lb_182
 L  product_ub_183
 G  product_lb_184
 L  product_ub_185
 G  product_lb_186
 L  product_ub_187
 E  onehot_12_188
 E  normalized_mass_12_189
 E  normalized_ratio_12_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 G  product_lb_211
 L  product_ub_212
 G  product_lb_213
 L  product_ub_214
 G  product_lb_215
 L  product_ub_216
 G  product_lb_217
 L  product_ub_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 E  onehot_35_223
 E  normalized_mass_35_224
 E  normalized_ratio_35_225
 G  stock_lb_226
 L  stock_ub_227
 L  parent_nonstrict_scope_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 E  normalization_285
 G  full_original_Gini_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 L  arc_capacity_380
 L  arc_capacity_381
 L  arc_capacity_382
 L  arc_capacity_383
 L  arc_capacity_384
 L  arc_capacity_385
 L  arc_capacity_386
 L  arc_capacity_387
 L  arc_capacity_388
 L  arc_capacity_389
 L  arc_capacity_390
 L  arc_capacity_391
 L  arc_capacity_392
 L  arc_capacity_393
 L  arc_capacity_394
 L  arc_capacity_395
 G  connected_order_arc_396
 L  arc_capacity_397
 G  connected_order_arc_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 G  connected_order_arc_402
 L  arc_capacity_403
 G  connected_order_arc_404
 L  arc_capacity_405
 G  connected_order_arc_406
 L  arc_capacity_407
 G  connected_order_arc_408
 L  arc_capacity_409
 G  connected_order_arc_410
 L  arc_capacity_411
 G  connected_order_arc_412
 L  arc_capacity_413
 G  connected_order_arc_414
 L  arc_capacity_415
 G  connected_order_arc_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 G  connected_order_arc_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 G  connected_order_arc_435
 L  arc_capacity_436
 G  connected_order_arc_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 G  connected_order_arc_718
 E  depot_departure_or_bypass_719
 E  depot_return_or_bypass_720
 E  out_degree_721
 E  in_degree_722
 G  order_active_lb_723
 L  order_active_ub_724
 E  segment_load_conservation_725
 G  segment_prefix_lb_726
 L  segment_prefix_ub_727
 E  out_degree_728
 E  in_degree_729
 G  order_active_lb_730
 L  order_active_ub_731
 E  segment_load_conservation_732
 G  segment_prefix_lb_733
 L  segment_prefix_ub_734
 E  out_degree_735
 E  in_degree_736
 G  order_active_lb_737
 L  order_active_ub_738
 E  segment_load_conservation_739
 G  segment_prefix_lb_740
 L  segment_prefix_ub_741
 E  out_degree_742
 E  in_degree_743
 G  order_active_lb_744
 L  order_active_ub_745
 E  segment_load_conservation_746
 G  segment_prefix_lb_747
 L  segment_prefix_ub_748
 E  out_degree_749
 E  in_degree_750
 G  order_active_lb_751
 L  order_active_ub_752
 E  segment_load_conservation_753
 G  segment_prefix_lb_754
 L  segment_prefix_ub_755
 E  out_degree_756
 E  in_degree_757
 G  order_active_lb_758
 L  order_active_ub_759
 E  service_visit_def_760
 E  free_load_conservation_761
 E  out_degree_762
 E  in_degree_763
 G  order_active_lb_764
 L  order_active_ub_765
 E  service_visit_def_766
 E  free_load_conservation_767
 E  out_degree_768
 E  in_degree_769
 G  order_active_lb_770
 L  order_active_ub_771
 E  service_visit_def_772
 E  free_load_conservation_773
 E  out_degree_774
 E  in_degree_775
 G  order_active_lb_776
 L  order_active_ub_777
 E  service_visit_def_778
 E  free_load_conservation_779
 E  out_degree_780
 E  in_degree_781
 G  order_active_lb_782
 L  order_active_ub_783
 E  service_visit_def_784
 E  free_load_conservation_785
 E  out_degree_786
 E  in_degree_787
 G  order_active_lb_788
 L  order_active_ub_789
 E  service_visit_def_790
 E  free_load_conservation_791
 E  out_degree_792
 E  in_degree_793
 G  order_active_lb_794
 L  order_active_ub_795
 E  service_visit_def_796
 E  free_load_conservation_797
 E  out_degree_798
 E  in_degree_799
 G  order_active_lb_800
 L  order_active_ub_801
 E  service_visit_def_802
 E  free_load_conservation_803
 G  fixed_segment_relative_order_804
 G  fixed_segment_relative_order_805
 G  fixed_segment_relative_order_806
 G  fixed_segment_relative_order_807
 L  original_T_including_depot_unload_808
 L  arc_capacity_809
 L  arc_capacity_810
 L  arc_capacity_811
 L  arc_capacity_812
 L  arc_capacity_813
 L  arc_capacity_814
 L  arc_capacity_815
 L  arc_capacity_816
 L  arc_capacity_817
 L  arc_capacity_818
 L  arc_capacity_819
 L  arc_capacity_820
 L  arc_capacity_821
 L  arc_capacity_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 G  connected_order_arc_836
 L  arc_capacity_837
 G  connected_order_arc_838
 L  arc_capacity_839
 G  connected_order_arc_840
 L  arc_capacity_841
 G  connected_order_arc_842
 L  arc_capacity_843
 G  connected_order_arc_844
 L  arc_capacity_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 G  connected_order_arc_863
 L  arc_capacity_864
 G  connected_order_arc_865
 L  arc_capacity_866
 G  connected_order_arc_867
 L  arc_capacity_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 G  connected_order_arc_880
 L  arc_capacity_881
 G  connected_order_arc_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 E  depot_departure_or_bypass_1098
 E  depot_return_or_bypass_1099
 E  out_degree_1100
 E  in_degree_1101
 G  order_active_lb_1102
 L  order_active_ub_1103
 E  segment_load_conservation_1104
 G  segment_prefix_lb_1105
 L  segment_prefix_ub_1106
 E  out_degree_1107
 E  in_degree_1108
 G  order_active_lb_1109
 L  order_active_ub_1110
 E  segment_load_conservation_1111
 G  segment_prefix_lb_1112
 L  segment_prefix_ub_1113
 E  out_degree_1114
 E  in_degree_1115
 G  order_active_lb_1116
 L  order_active_ub_1117
 E  segment_load_conservation_1118
 G  segment_prefix_lb_1119
 L  segment_prefix_ub_1120
 E  out_degree_1121
 E  in_degree_1122
 G  order_active_lb_1123
 L  order_active_ub_1124
 E  segment_load_conservation_1125
 G  segment_prefix_lb_1126
 L  segment_prefix_ub_1127
 E  out_degree_1128
 E  in_degree_1129
 G  order_active_lb_1130
 L  order_active_ub_1131
 E  service_visit_def_1132
 E  free_load_conservation_1133
 E  out_degree_1134
 E  in_degree_1135
 G  order_active_lb_1136
 L  order_active_ub_1137
 E  service_visit_def_1138
 E  free_load_conservation_1139
 E  out_degree_1140
 E  in_degree_1141
 G  order_active_lb_1142
 L  order_active_ub_1143
 E  service_visit_def_1144
 E  free_load_conservation_1145
 E  out_degree_1146
 E  in_degree_1147
 G  order_active_lb_1148
 L  order_active_ub_1149
 E  service_visit_def_1150
 E  free_load_conservation_1151
 E  out_degree_1152
 E  in_degree_1153
 G  order_active_lb_1154
 L  order_active_ub_1155
 E  service_visit_def_1156
 E  free_load_conservation_1157
 E  out_degree_1158
 E  in_degree_1159
 G  order_active_lb_1160
 L  order_active_ub_1161
 E  service_visit_def_1162
 E  free_load_conservation_1163
 E  out_degree_1164
 E  in_degree_1165
 G  order_active_lb_1166
 L  order_active_ub_1167
 E  service_visit_def_1168
 E  free_load_conservation_1169
 E  out_degree_1170
 E  in_degree_1171
 G  order_active_lb_1172
 L  order_active_ub_1173
 E  service_visit_def_1174
 E  free_load_conservation_1175
 G  fixed_segment_relative_order_1176
 G  fixed_segment_relative_order_1177
 G  fixed_segment_relative_order_1178
 L  original_T_including_depot_unload_1179
 L  arc_capacity_1180
 L  arc_capacity_1181
 L  arc_capacity_1182
 L  arc_capacity_1183
 L  arc_capacity_1184
 L  arc_capacity_1185
 L  arc_capacity_1186
 L  arc_capacity_1187
 L  arc_capacity_1188
 L  arc_capacity_1189
 L  arc_capacity_1190
 L  arc_capacity_1191
 L  arc_capacity_1192
 L  arc_capacity_1193
 L  arc_capacity_1194
 G  connected_order_arc_1195
 L  arc_capacity_1196
 G  connected_order_arc_1197
 L  arc_capacity_1198
 G  connected_order_arc_1199
 L  arc_capacity_1200
 G  connected_order_arc_1201
 L  arc_capacity_1202
 G  connected_order_arc_1203
 L  arc_capacity_1204
 G  connected_order_arc_1205
 L  arc_capacity_1206
 G  connected_order_arc_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 G  connected_order_arc_1213
 L  arc_capacity_1214
 G  connected_order_arc_1215
 L  arc_capacity_1216
 L  arc_capacity_1217
 G  connected_order_arc_1218
 L  arc_capacity_1219
 G  connected_order_arc_1220
 L  arc_capacity_1221
 G  connected_order_arc_1222
 L  arc_capacity_1223
 G  connected_order_arc_1224
 L  arc_capacity_1225
 G  connected_order_arc_1226
 L  arc_capacity_1227
 G  connected_order_arc_1228
 L  arc_capacity_1229
 G  connected_order_arc_1230
 L  arc_capacity_1231
 G  connected_order_arc_1232
 L  arc_capacity_1233
 G  connected_order_arc_1234
 L  arc_capacity_1235
 G  connected_order_arc_1236
 L  arc_capacity_1237
 G  connected_order_arc_1238
 L  arc_capacity_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 G  connected_order_arc_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 G  connected_order_arc_1249
 L  arc_capacity_1250
 G  connected_order_arc_1251
 L  arc_capacity_1252
 G  connected_order_arc_1253
 L  arc_capacity_1254
 G  connected_order_arc_1255
 L  arc_capacity_1256
 G  connected_order_arc_1257
 L  arc_capacity_1258
 G  connected_order_arc_1259
 L  arc_capacity_1260
 G  connected_order_arc_1261
 L  arc_capacity_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 G  connected_order_arc_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 L  arc_capacity_1275
 G  connected_order_arc_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 G  connected_order_arc_1280
 L  arc_capacity_1281
 G  connected_order_arc_1282
 L  arc_capacity_1283
 G  connected_order_arc_1284
 L  arc_capacity_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 G  connected_order_arc_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 G  connected_order_arc_1305
 L  arc_capacity_1306
 G  connected_order_arc_1307
 L  arc_capacity_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 G  connected_order_arc_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 G  connected_order_arc_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 G  connected_order_arc_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 G  connected_order_arc_1364
 L  arc_capacity_1365
 G  connected_order_arc_1366
 L  arc_capacity_1367
 G  connected_order_arc_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 G  connected_order_arc_1385
 L  arc_capacity_1386
 G  connected_order_arc_1387
 L  arc_capacity_1388
 G  connected_order_arc_1389
 L  arc_capacity_1390
 G  connected_order_arc_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 G  connected_order_arc_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 L  arc_capacity_1401
 G  connected_order_arc_1402
 L  arc_capacity_1403
 G  connected_order_arc_1404
 L  arc_capacity_1405
 G  connected_order_arc_1406
 L  arc_capacity_1407
 G  connected_order_arc_1408
 L  arc_capacity_1409
 G  connected_order_arc_1410
 L  arc_capacity_1411
 G  connected_order_arc_1412
 L  arc_capacity_1413
 G  connected_order_arc_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 G  connected_order_arc_1418
 L  arc_capacity_1419
 G  connected_order_arc_1420
 L  arc_capacity_1421
 G  connected_order_arc_1422
 L  arc_capacity_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 L  arc_capacity_1426
 G  connected_order_arc_1427
 L  arc_capacity_1428
 G  connected_order_arc_1429
 L  arc_capacity_1430
 G  connected_order_arc_1431
 L  arc_capacity_1432
 G  connected_order_arc_1433
 L  arc_capacity_1434
 G  connected_order_arc_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 L  arc_capacity_1438
 G  connected_order_arc_1439
 L  arc_capacity_1440
 G  connected_order_arc_1441
 L  arc_capacity_1442
 G  connected_order_arc_1443
 L  arc_capacity_1444
 G  connected_order_arc_1445
 L  arc_capacity_1446
 L  arc_capacity_1447
 G  connected_order_arc_1448
 L  arc_capacity_1449
 G  connected_order_arc_1450
 L  arc_capacity_1451
 G  connected_order_arc_1452
 L  arc_capacity_1453
 G  connected_order_arc_1454
 L  arc_capacity_1455
 G  connected_order_arc_1456
 L  arc_capacity_1457
 G  connected_order_arc_1458
 L  arc_capacity_1459
 G  connected_order_arc_1460
 L  arc_capacity_1461
 G  connected_order_arc_1462
 L  arc_capacity_1463
 G  connected_order_arc_1464
 L  arc_capacity_1465
 G  connected_order_arc_1466
 L  arc_capacity_1467
 G  connected_order_arc_1468
 E  depot_departure_or_bypass_1469
 E  depot_return_or_bypass_1470
 E  out_degree_1471
 E  in_degree_1472
 G  order_active_lb_1473
 L  order_active_ub_1474
 E  segment_load_conservation_1475
 G  segment_prefix_lb_1476
 L  segment_prefix_ub_1477
 E  out_degree_1478
 E  in_degree_1479
 G  order_active_lb_1480
 L  order_active_ub_1481
 E  segment_load_conservation_1482
 G  segment_prefix_lb_1483
 L  segment_prefix_ub_1484
 E  out_degree_1485
 E  in_degree_1486
 G  order_active_lb_1487
 L  order_active_ub_1488
 E  segment_load_conservation_1489
 G  segment_prefix_lb_1490
 L  segment_prefix_ub_1491
 E  out_degree_1492
 E  in_degree_1493
 G  order_active_lb_1494
 L  order_active_ub_1495
 E  segment_load_conservation_1496
 G  segment_prefix_lb_1497
 L  segment_prefix_ub_1498
 E  out_degree_1499
 E  in_degree_1500
 G  order_active_lb_1501
 L  order_active_ub_1502
 E  service_visit_def_1503
 E  free_load_conservation_1504
 E  out_degree_1505
 E  in_degree_1506
 G  order_active_lb_1507
 L  order_active_ub_1508
 E  service_visit_def_1509
 E  free_load_conservation_1510
 E  out_degree_1511
 E  in_degree_1512
 G  order_active_lb_1513
 L  order_active_ub_1514
 E  service_visit_def_1515
 E  free_load_conservation_1516
 E  out_degree_1517
 E  in_degree_1518
 G  order_active_lb_1519
 L  order_active_ub_1520
 E  service_visit_def_1521
 E  free_load_conservation_1522
 E  out_degree_1523
 E  in_degree_1524
 G  order_active_lb_1525
 L  order_active_ub_1526
 E  service_visit_def_1527
 E  free_load_conservation_1528
 E  out_degree_1529
 E  in_degree_1530
 G  order_active_lb_1531
 L  order_active_ub_1532
 E  service_visit_def_1533
 E  free_load_conservation_1534
 E  out_degree_1535
 E  in_degree_1536
 G  order_active_lb_1537
 L  order_active_ub_1538
 E  service_visit_def_1539
 E  free_load_conservation_1540
 E  out_degree_1541
 E  in_degree_1542
 G  order_active_lb_1543
 L  order_active_ub_1544
 E  service_visit_def_1545
 E  free_load_conservation_1546
 G  fixed_segment_relative_order_1547
 G  fixed_segment_relative_order_1548
 G  fixed_segment_relative_order_1549
 L  original_T_including_depot_unload_1550
COLUMNS
    t         normalized_mass_26_19  -1
    t         normalized_mass_32_48  -1
    t         normalized_mass_2_83  -1
    t         normalized_mass_30_104  -1
    t         normalized_mass_31_133  -1
    t         normalized_mass_19_154  -1
    t         normalized_mass_12_189  -1
    t         normalized_mass_35_224  -1
    t         normalization_285  2.4896428571428572e+01
    t         full_original_Gini_286  -7.4850000000000122e+01
    q         OBJ       1
    q         parent_nonstrict_scope_228  1
    q         full_original_Gini_286  35
    MARKER    'MARKER'                 'INTORG'
    x_26_0    OBJ       0.012
    x_26_0    product_lb_0  -2.4288688410801524e-02
    x_26_0    product_ub_1  -4.0166403672397079e-02
    x_26_0    onehot_26_18  1
    x_26_0    parent_nonstrict_scope_228  0.024
    MARKER    'MARKER'                 'INTEND'
    w_26_0    product_lb_0  1
    w_26_0    product_ub_1  1
    w_26_0    normalized_mass_26_19  1
    w_26_0    full_original_Gini_286  -2.4896428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_1    OBJ       6.0000000000000019e-03
    x_26_1    product_lb_2  -2.4288688410801524e-02
    x_26_1    product_ub_3  -4.0166403672397079e-02
    x_26_1    onehot_26_18  1
    x_26_1    stock_lb_226  1
    x_26_1    stock_ub_227  1
    x_26_1    parent_nonstrict_scope_228  1.8000000000000002e-02
    x_26_1    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_1    product_lb_2  1
    w_26_1    product_ub_3  1
    w_26_1    normalized_mass_26_19  1
    w_26_1    normalized_ratio_26_20  -0.25
    w_26_1    full_original_Gini_286  -1.8246428571428570e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_2    product_lb_4  -2.4288688410801524e-02
    x_26_2    product_ub_5  -4.0166403672397079e-02
    x_26_2    onehot_26_18  1
    x_26_2    stock_lb_226  2
    x_26_2    stock_ub_227  2
    x_26_2    parent_nonstrict_scope_228  0.012
    x_26_2    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_2    product_lb_4  1
    w_26_2    product_ub_5  1
    w_26_2    normalized_mass_26_19  1
    w_26_2    normalized_ratio_26_20  -0.5
    w_26_2    full_original_Gini_286  -1.2196428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_3    OBJ       -0.006
    x_26_3    product_lb_6  -2.4288688410801524e-02
    x_26_3    product_ub_7  -4.0166403672397079e-02
    x_26_3    onehot_26_18  1
    x_26_3    stock_lb_226  3
    x_26_3    stock_ub_227  3
    x_26_3    parent_nonstrict_scope_228  0.006
    x_26_3    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_3    product_lb_6  1
    w_26_3    product_ub_7  1
    w_26_3    normalized_mass_26_19  1
    w_26_3    normalized_ratio_26_20  -0.75
    w_26_3    full_original_Gini_286  -7.0178571428571423e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_4    OBJ       -0.012
    x_26_4    product_lb_8  -2.4288688410801524e-02
    x_26_4    product_ub_9  -4.0166403672397079e-02
    x_26_4    onehot_26_18  1
    x_26_4    stock_lb_226  4
    x_26_4    stock_ub_227  4
    x_26_4    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_4    product_lb_8  1
    w_26_4    product_ub_9  1
    w_26_4    normalized_mass_26_19  1
    w_26_4    normalized_ratio_26_20  -1
    w_26_4    full_original_Gini_286  -3.3035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_5    OBJ       -0.006
    x_26_5    product_lb_10  -2.4288688410801524e-02
    x_26_5    product_ub_11  -4.0166403672397079e-02
    x_26_5    onehot_26_18  1
    x_26_5    stock_lb_226  5
    x_26_5    stock_ub_227  5
    x_26_5    parent_nonstrict_scope_228  0.006
    x_26_5    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_5    product_lb_10  1
    w_26_5    product_ub_11  1
    w_26_5    normalized_mass_26_19  1
    w_26_5    normalized_ratio_26_20  -1.25
    w_26_5    full_original_Gini_286  -8.8535714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_6    product_lb_12  -2.4288688410801524e-02
    x_26_6    product_ub_13  -4.0166403672397079e-02
    x_26_6    onehot_26_18  1
    x_26_6    stock_lb_226  6
    x_26_6    stock_ub_227  6
    x_26_6    parent_nonstrict_scope_228  0.012
    x_26_6    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_6    product_lb_12  1
    w_26_6    product_ub_13  1
    w_26_6    normalized_mass_26_19  1
    w_26_6    normalized_ratio_26_20  -1.5
    w_26_6    full_original_Gini_286  -1.5603571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_7    OBJ       6.0000000000000019e-03
    x_26_7    product_lb_14  -2.4288688410801524e-02
    x_26_7    product_ub_15  -4.0166403672397079e-02
    x_26_7    onehot_26_18  1
    x_26_7    stock_lb_226  7
    x_26_7    stock_ub_227  7
    x_26_7    parent_nonstrict_scope_228  1.8000000000000002e-02
    x_26_7    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_7    product_lb_14  1
    w_26_7    product_ub_15  1
    w_26_7    normalized_mass_26_19  1
    w_26_7    normalized_ratio_26_20  -1.75
    w_26_7    full_original_Gini_286  -2.2353571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_8    OBJ       0.012
    x_26_8    product_lb_16  -2.4288688410801524e-02
    x_26_8    product_ub_17  -4.0166403672397079e-02
    x_26_8    onehot_26_18  1
    x_26_8    stock_lb_226  8
    x_26_8    stock_ub_227  8
    x_26_8    parent_nonstrict_scope_228  0.024
    x_26_8    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_8    product_lb_16  1
    w_26_8    product_ub_17  1
    w_26_8    normalized_mass_26_19  1
    w_26_8    normalized_ratio_26_20  -2
    w_26_8    full_original_Gini_286  -2.9103571428571431e+01
    rho_26    normalized_ratio_26_20  1
    rho_26    block_pair_pos_245  -1
    rho_26    block_pair_neg_246  1
    rho_26    block_pair_pos_247  -1
    rho_26    block_pair_neg_248  1
    rho_26    block_pair_pos_249  -1
    rho_26    block_pair_neg_250  1
    rho_26    block_pair_pos_251  -1
    rho_26    block_pair_neg_252  1
    rho_26    block_pair_pos_253  -1
    rho_26    block_pair_neg_254  1
    rho_26    block_pair_pos_255  -1
    rho_26    block_pair_neg_256  1
    rho_26    block_pair_pos_257  -1
    rho_26    block_pair_neg_258  1
    rho_26    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_21  -2.4288688410801524e-02
    x_32_0    product_ub_22  -4.0166403672397079e-02
    x_32_0    onehot_32_47  1
    x_32_0    parent_nonstrict_scope_228  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_21  1
    w_32_0    product_ub_22  1
    w_32_0    normalized_mass_32_48  1
    w_32_0    full_original_Gini_286  -2.4896428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_23  -2.4288688410801524e-02
    x_32_1    product_ub_24  -4.0166403672397079e-02
    x_32_1    onehot_32_47  1
    x_32_1    stock_lb_226  1
    x_32_1    stock_ub_227  1
    x_32_1    parent_nonstrict_scope_228  0.03
    x_32_1    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_23  1
    w_32_1    product_ub_24  1
    w_32_1    normalized_mass_32_48  1
    w_32_1    normalized_ratio_32_49  -0.2
    w_32_1    full_original_Gini_286  -1.9496428571428581e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_25  -2.4288688410801524e-02
    x_32_2    product_ub_26  -4.0166403672397079e-02
    x_32_2    onehot_32_47  1
    x_32_2    stock_lb_226  2
    x_32_2    stock_ub_227  2
    x_32_2    parent_nonstrict_scope_228  0.0225
    x_32_2    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_25  1
    w_32_2    product_ub_26  1
    w_32_2    normalized_mass_32_48  1
    w_32_2    normalized_ratio_32_49  -0.4
    w_32_2    full_original_Gini_286  -1.4496428571428568e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_27  -2.4288688410801524e-02
    x_32_3    product_ub_28  -4.0166403672397079e-02
    x_32_3    onehot_32_47  1
    x_32_3    stock_lb_226  3
    x_32_3    stock_ub_227  3
    x_32_3    parent_nonstrict_scope_228  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_27  1
    w_32_3    product_ub_28  1
    w_32_3    normalized_mass_32_48  1
    w_32_3    normalized_ratio_32_49  -6.0000000000000009e-01
    w_32_3    full_original_Gini_286  -1.0096428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_29  -2.4288688410801524e-02
    x_32_4    product_ub_30  -4.0166403672397079e-02
    x_32_4    onehot_32_47  1
    x_32_4    stock_lb_226  4
    x_32_4    stock_ub_227  4
    x_32_4    parent_nonstrict_scope_228  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_29  1
    w_32_4    product_ub_30  1
    w_32_4    normalized_mass_32_48  1
    w_32_4    normalized_ratio_32_49  -0.8
    w_32_4    full_original_Gini_286  -6.1678571428571454e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_31  -2.4288688410801524e-02
    x_32_5    product_ub_32  -4.0166403672397079e-02
    x_32_5    onehot_32_47  1
    x_32_5    stock_lb_226  5
    x_32_5    stock_ub_227  5
    x_32_5    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_31  1
    w_32_5    product_ub_32  1
    w_32_5    normalized_mass_32_48  1
    w_32_5    normalized_ratio_32_49  -1
    w_32_5    full_original_Gini_286  -3.3035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_33  -2.4288688410801524e-02
    x_32_6    product_ub_34  -4.0166403672397079e-02
    x_32_6    onehot_32_47  1
    x_32_6    stock_lb_226  6
    x_32_6    stock_ub_227  6
    x_32_6    parent_nonstrict_scope_228  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_33  1
    w_32_6    product_ub_34  1
    w_32_6    normalized_mass_32_48  1
    w_32_6    normalized_ratio_32_49  -1.2000000000000002e+00
    w_32_6    full_original_Gini_286  -7.5035714285714326e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_35  -2.4288688410801524e-02
    x_32_7    product_ub_36  -4.0166403672397079e-02
    x_32_7    onehot_32_47  1
    x_32_7    stock_lb_226  7
    x_32_7    stock_ub_227  7
    x_32_7    parent_nonstrict_scope_228  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_35  1
    w_32_7    product_ub_36  1
    w_32_7    normalized_mass_32_48  1
    w_32_7    normalized_ratio_32_49  -1.4000000000000001e+00
    w_32_7    full_original_Gini_286  -1.2903571428571436e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_37  -2.4288688410801524e-02
    x_32_8    product_ub_38  -4.0166403672397079e-02
    x_32_8    onehot_32_47  1
    x_32_8    stock_lb_226  8
    x_32_8    stock_ub_227  8
    x_32_8    parent_nonstrict_scope_228  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_37  1
    w_32_8    product_ub_38  1
    w_32_8    normalized_mass_32_48  1
    w_32_8    normalized_ratio_32_49  -1.6
    w_32_8    full_original_Gini_286  -1.8303571428571427e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_39  -2.4288688410801524e-02
    x_32_9    product_ub_40  -4.0166403672397079e-02
    x_32_9    onehot_32_47  1
    x_32_9    stock_lb_226  9
    x_32_9    stock_ub_227  9
    x_32_9    parent_nonstrict_scope_228  0.03
    x_32_9    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_39  1
    w_32_9    product_ub_40  1
    w_32_9    normalized_mass_32_48  1
    w_32_9    normalized_ratio_32_49  -1.8
    w_32_9    full_original_Gini_286  -2.3703571428571436e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_41  -2.4288688410801524e-02
    x_32_10   product_ub_42  -4.0166403672397079e-02
    x_32_10   onehot_32_47  1
    x_32_10   stock_lb_226  10
    x_32_10   stock_ub_227  10
    x_32_10   parent_nonstrict_scope_228  0.0375
    x_32_10   unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_41  1
    w_32_10   product_ub_42  1
    w_32_10   normalized_mass_32_48  1
    w_32_10   normalized_ratio_32_49  -2
    w_32_10   full_original_Gini_286  -2.9103571428571431e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_43  -2.4288688410801524e-02
    x_32_11   product_ub_44  -4.0166403672397079e-02
    x_32_11   onehot_32_47  1
    x_32_11   stock_lb_226  11
    x_32_11   stock_ub_227  11
    x_32_11   parent_nonstrict_scope_228  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_43  1
    w_32_11   product_ub_44  1
    w_32_11   normalized_mass_32_48  1
    w_32_11   normalized_ratio_32_49  -2.2
    w_32_11   full_original_Gini_286  -3.4503571428571419e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_45  -2.4288688410801524e-02
    x_32_12   product_ub_46  -4.0166403672397079e-02
    x_32_12   onehot_32_47  1
    x_32_12   stock_lb_226  12
    x_32_12   stock_ub_227  12
    x_32_12   parent_nonstrict_scope_228  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_45  1
    w_32_12   product_ub_46  1
    w_32_12   normalized_mass_32_48  1
    w_32_12   normalized_ratio_32_49  -2.4000000000000004e+00
    w_32_12   full_original_Gini_286  -3.9903571428571418e+01
    rho_32    normalized_ratio_32_49  1
    rho_32    block_pair_pos_255  1
    rho_32    block_pair_neg_256  -1
    rho_32    block_pair_pos_273  -1
    rho_32    block_pair_neg_274  1
    rho_32    block_pair_pos_275  -1
    rho_32    block_pair_neg_276  1
    rho_32    block_pair_pos_277  -1
    rho_32    block_pair_neg_278  1
    rho_32    block_pair_pos_279  -1
    rho_32    block_pair_neg_280  1
    rho_32    block_pair_pos_281  -1
    rho_32    block_pair_neg_282  1
    rho_32    block_pair_pos_283  -1
    rho_32    block_pair_neg_284  1
    rho_32    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_50  -2.4288688410801524e-02
    x_2_0     product_ub_51  -4.0166403672397079e-02
    x_2_0     onehot_2_82  1
    x_2_0     parent_nonstrict_scope_228  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_50  1
    w_2_0     product_ub_51  1
    w_2_0     normalized_mass_2_83  1
    w_2_0     full_original_Gini_286  -2.4896428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_52  -2.4288688410801524e-02
    x_2_1     product_ub_53  -4.0166403672397079e-02
    x_2_1     onehot_2_82  1
    x_2_1     stock_lb_226  1
    x_2_1     stock_ub_227  1
    x_2_1     parent_nonstrict_scope_228  0.063
    x_2_1     unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_52  1
    w_2_1     product_ub_53  1
    w_2_1     normalized_mass_2_83  1
    w_2_1     normalized_ratio_2_84  -1.4285714285714285e-01
    w_2_1     full_original_Gini_286  -2.1039285714285725e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_54  -2.4288688410801524e-02
    x_2_2     product_ub_55  -4.0166403672397079e-02
    x_2_2     onehot_2_82  1
    x_2_2     stock_lb_226  2
    x_2_2     stock_ub_227  2
    x_2_2     parent_nonstrict_scope_228  0.0525
    x_2_2     unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_54  1
    w_2_2     product_ub_55  1
    w_2_2     normalized_mass_2_83  1
    w_2_2     normalized_ratio_2_84  -2.8571428571428570e-01
    w_2_2     full_original_Gini_286  -1.7353571428571424e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_56  -2.4288688410801524e-02
    x_2_3     product_ub_57  -4.0166403672397079e-02
    x_2_3     onehot_2_82  1
    x_2_3     stock_lb_226  3
    x_2_3     stock_ub_227  3
    x_2_3     parent_nonstrict_scope_228  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_56  1
    w_2_3     product_ub_57  1
    w_2_3     normalized_mass_2_83  1
    w_2_3     normalized_ratio_2_84  -4.2857142857142855e-01
    w_2_3     full_original_Gini_286  -1.3839285714285712e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_58  -2.4288688410801524e-02
    x_2_4     product_ub_59  -4.0166403672397079e-02
    x_2_4     onehot_2_82  1
    x_2_4     stock_lb_226  4
    x_2_4     stock_ub_227  4
    x_2_4     parent_nonstrict_scope_228  0.0315
    x_2_4     unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_58  1
    w_2_4     product_ub_59  1
    w_2_4     normalized_mass_2_83  1
    w_2_4     normalized_ratio_2_84  -5.7142857142857140e-01
    w_2_4     full_original_Gini_286  -1.0696428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_60  -2.4288688410801524e-02
    x_2_5     product_ub_61  -4.0166403672397079e-02
    x_2_5     onehot_2_82  1
    x_2_5     stock_lb_226  5
    x_2_5     stock_ub_227  5
    x_2_5     parent_nonstrict_scope_228  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_60  1
    w_2_5     product_ub_61  1
    w_2_5     normalized_mass_2_83  1
    w_2_5     normalized_ratio_2_84  -7.1428571428571419e-01
    w_2_5     full_original_Gini_286  -7.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_62  -2.4288688410801524e-02
    x_2_6     product_ub_63  -4.0166403672397079e-02
    x_2_6     onehot_2_82  1
    x_2_6     stock_lb_226  6
    x_2_6     stock_ub_227  6
    x_2_6     parent_nonstrict_scope_228  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_62  1
    w_2_6     product_ub_63  1
    w_2_6     normalized_mass_2_83  1
    w_2_6     normalized_ratio_2_84  -8.5714285714285710e-01
    w_2_6     full_original_Gini_286  -5.1964285714285738e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_64  -2.4288688410801524e-02
    x_2_7     product_ub_65  -4.0166403672397079e-02
    x_2_7     onehot_2_82  1
    x_2_7     stock_lb_226  7
    x_2_7     stock_ub_227  7
    x_2_7     unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_64  1
    w_2_7     product_ub_65  1
    w_2_7     normalized_mass_2_83  1
    w_2_7     normalized_ratio_2_84  -1
    w_2_7     full_original_Gini_286  -3.3035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_66  -2.4288688410801524e-02
    x_2_8     product_ub_67  -4.0166403672397079e-02
    x_2_8     onehot_2_82  1
    x_2_8     stock_lb_226  8
    x_2_8     stock_ub_227  8
    x_2_8     parent_nonstrict_scope_228  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_66  1
    w_2_8     product_ub_67  1
    w_2_8     normalized_mass_2_83  1
    w_2_8     normalized_ratio_2_84  -1.1428571428571428e+00
    w_2_8     full_original_Gini_286  -6.3035714285714253e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_68  -2.4288688410801524e-02
    x_2_9     product_ub_69  -4.0166403672397079e-02
    x_2_9     onehot_2_82  1
    x_2_9     stock_lb_226  9
    x_2_9     stock_ub_227  9
    x_2_9     parent_nonstrict_scope_228  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_68  1
    w_2_9     product_ub_69  1
    w_2_9     normalized_mass_2_83  1
    w_2_9     normalized_ratio_2_84  -1.2857142857142856e+00
    w_2_9     full_original_Gini_286  -9.8178571428571377e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_70  -2.4288688410801524e-02
    x_2_10    product_ub_71  -4.0166403672397079e-02
    x_2_10    onehot_2_82  1
    x_2_10    stock_lb_226  10
    x_2_10    stock_ub_227  10
    x_2_10    parent_nonstrict_scope_228  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_70  1
    w_2_10    product_ub_71  1
    w_2_10    normalized_mass_2_83  1
    w_2_10    normalized_ratio_2_84  -1.4285714285714284e+00
    w_2_10    full_original_Gini_286  -1.3674999999999999e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_72  -2.4288688410801524e-02
    x_2_11    product_ub_73  -4.0166403672397079e-02
    x_2_11    onehot_2_82  1
    x_2_11    stock_lb_226  11
    x_2_11    stock_ub_227  11
    x_2_11    parent_nonstrict_scope_228  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_72  1
    w_2_11    product_ub_73  1
    w_2_11    normalized_mass_2_83  1
    w_2_11    normalized_ratio_2_84  -1.5714285714285714e+00
    w_2_11    full_original_Gini_286  -1.7532142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_74  -2.4288688410801524e-02
    x_2_12    product_ub_75  -4.0166403672397079e-02
    x_2_12    onehot_2_82  1
    x_2_12    stock_lb_226  12
    x_2_12    stock_ub_227  12
    x_2_12    parent_nonstrict_scope_228  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_74  1
    w_2_12    product_ub_75  1
    w_2_12    normalized_mass_2_83  1
    w_2_12    normalized_ratio_2_84  -1.7142857142857142e+00
    w_2_12    full_original_Gini_286  -2.1389285714285709e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_76  -2.4288688410801524e-02
    x_2_13    product_ub_77  -4.0166403672397079e-02
    x_2_13    onehot_2_82  1
    x_2_13    stock_lb_226  13
    x_2_13    stock_ub_227  13
    x_2_13    parent_nonstrict_scope_228  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_76  1
    w_2_13    product_ub_77  1
    w_2_13    normalized_mass_2_83  1
    w_2_13    normalized_ratio_2_84  -1.8571428571428570e+00
    w_2_13    full_original_Gini_286  -2.5246428571428574e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_78  -2.4288688410801524e-02
    x_2_14    product_ub_79  -4.0166403672397079e-02
    x_2_14    onehot_2_82  1
    x_2_14    stock_lb_226  14
    x_2_14    stock_ub_227  14
    x_2_14    parent_nonstrict_scope_228  0.0735
    x_2_14    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_78  1
    w_2_14    product_ub_79  1
    w_2_14    normalized_mass_2_83  1
    w_2_14    normalized_ratio_2_84  -2
    w_2_14    full_original_Gini_286  -2.9103571428571431e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_80  -2.4288688410801524e-02
    x_2_15    product_ub_81  -4.0166403672397079e-02
    x_2_15    onehot_2_82  1
    x_2_15    stock_lb_226  15
    x_2_15    stock_ub_227  15
    x_2_15    parent_nonstrict_scope_228  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_80  1
    w_2_15    product_ub_81  1
    w_2_15    normalized_mass_2_83  1
    w_2_15    normalized_ratio_2_84  -2.1428571428571428e+00
    w_2_15    full_original_Gini_286  -3.2960714285714275e+01
    rho_2     normalized_ratio_2_84  1
    rho_2     block_pair_pos_229  -1
    rho_2     block_pair_neg_230  1
    rho_2     block_pair_pos_231  -1
    rho_2     block_pair_neg_232  1
    rho_2     block_pair_pos_233  -1
    rho_2     block_pair_neg_234  1
    rho_2     block_pair_pos_235  -1
    rho_2     block_pair_neg_236  1
    rho_2     block_pair_pos_237  -1
    rho_2     block_pair_neg_238  1
    rho_2     block_pair_pos_245  1
    rho_2     block_pair_neg_246  -1
    rho_2     block_pair_pos_273  1
    rho_2     block_pair_neg_274  -1
    rho_2     normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_30_0    OBJ       0.012
    x_30_0    product_lb_85  -2.4288688410801524e-02
    x_30_0    product_ub_86  -4.0166403672397079e-02
    x_30_0    onehot_30_103  1
    x_30_0    parent_nonstrict_scope_228  0.024
    x_30_0    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_0    product_lb_85  1
    w_30_0    product_ub_86  1
    w_30_0    normalized_mass_30_104  1
    w_30_0    full_original_Gini_286  -2.4896428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_1    OBJ       6.0000000000000019e-03
    x_30_1    product_lb_87  -2.4288688410801524e-02
    x_30_1    product_ub_88  -4.0166403672397079e-02
    x_30_1    onehot_30_103  1
    x_30_1    stock_lb_226  1
    x_30_1    stock_ub_227  1
    x_30_1    parent_nonstrict_scope_228  1.8000000000000002e-02
    x_30_1    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_1    product_lb_87  1
    w_30_1    product_ub_88  1
    w_30_1    normalized_mass_30_104  1
    w_30_1    normalized_ratio_30_105  -0.25
    w_30_1    full_original_Gini_286  -1.8246428571428570e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_2    product_lb_89  -2.4288688410801524e-02
    x_30_2    product_ub_90  -4.0166403672397079e-02
    x_30_2    onehot_30_103  1
    x_30_2    stock_lb_226  2
    x_30_2    stock_ub_227  2
    x_30_2    parent_nonstrict_scope_228  0.012
    x_30_2    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_2    product_lb_89  1
    w_30_2    product_ub_90  1
    w_30_2    normalized_mass_30_104  1
    w_30_2    normalized_ratio_30_105  -0.5
    w_30_2    full_original_Gini_286  -1.2196428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_3    OBJ       -0.006
    x_30_3    product_lb_91  -2.4288688410801524e-02
    x_30_3    product_ub_92  -4.0166403672397079e-02
    x_30_3    onehot_30_103  1
    x_30_3    stock_lb_226  3
    x_30_3    stock_ub_227  3
    x_30_3    parent_nonstrict_scope_228  0.006
    x_30_3    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_3    product_lb_91  1
    w_30_3    product_ub_92  1
    w_30_3    normalized_mass_30_104  1
    w_30_3    normalized_ratio_30_105  -0.75
    w_30_3    full_original_Gini_286  -7.0178571428571423e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_4    OBJ       -0.012
    x_30_4    product_lb_93  -2.4288688410801524e-02
    x_30_4    product_ub_94  -4.0166403672397079e-02
    x_30_4    onehot_30_103  1
    x_30_4    stock_lb_226  4
    x_30_4    stock_ub_227  4
    x_30_4    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_4    product_lb_93  1
    w_30_4    product_ub_94  1
    w_30_4    normalized_mass_30_104  1
    w_30_4    normalized_ratio_30_105  -1
    w_30_4    full_original_Gini_286  -3.3035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_5    OBJ       -0.006
    x_30_5    product_lb_95  -2.4288688410801524e-02
    x_30_5    product_ub_96  -4.0166403672397079e-02
    x_30_5    onehot_30_103  1
    x_30_5    stock_lb_226  5
    x_30_5    stock_ub_227  5
    x_30_5    parent_nonstrict_scope_228  0.006
    MARKER    'MARKER'                 'INTEND'
    w_30_5    product_lb_95  1
    w_30_5    product_ub_96  1
    w_30_5    normalized_mass_30_104  1
    w_30_5    normalized_ratio_30_105  -1.25
    w_30_5    full_original_Gini_286  -8.8535714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_6    product_lb_97  -2.4288688410801524e-02
    x_30_6    product_ub_98  -4.0166403672397079e-02
    x_30_6    onehot_30_103  1
    x_30_6    stock_lb_226  6
    x_30_6    stock_ub_227  6
    x_30_6    parent_nonstrict_scope_228  0.012
    x_30_6    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_6    product_lb_97  1
    w_30_6    product_ub_98  1
    w_30_6    normalized_mass_30_104  1
    w_30_6    normalized_ratio_30_105  -1.5
    w_30_6    full_original_Gini_286  -1.5603571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_7    OBJ       6.0000000000000019e-03
    x_30_7    product_lb_99  -2.4288688410801524e-02
    x_30_7    product_ub_100  -4.0166403672397079e-02
    x_30_7    onehot_30_103  1
    x_30_7    stock_lb_226  7
    x_30_7    stock_ub_227  7
    x_30_7    parent_nonstrict_scope_228  1.8000000000000002e-02
    x_30_7    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_7    product_lb_99  1
    w_30_7    product_ub_100  1
    w_30_7    normalized_mass_30_104  1
    w_30_7    normalized_ratio_30_105  -1.75
    w_30_7    full_original_Gini_286  -2.2353571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_8    OBJ       0.012
    x_30_8    product_lb_101  -2.4288688410801524e-02
    x_30_8    product_ub_102  -4.0166403672397079e-02
    x_30_8    onehot_30_103  1
    x_30_8    stock_lb_226  8
    x_30_8    stock_ub_227  8
    x_30_8    parent_nonstrict_scope_228  0.024
    x_30_8    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_8    product_lb_101  1
    w_30_8    product_ub_102  1
    w_30_8    normalized_mass_30_104  1
    w_30_8    normalized_ratio_30_105  -2
    w_30_8    full_original_Gini_286  -2.9103571428571431e+01
    rho_30    normalized_ratio_30_105  1
    rho_30    block_pair_pos_233  1
    rho_30    block_pair_neg_234  -1
    rho_30    block_pair_pos_251  1
    rho_30    block_pair_neg_252  -1
    rho_30    block_pair_pos_259  -1
    rho_30    block_pair_neg_260  1
    rho_30    block_pair_pos_261  -1
    rho_30    block_pair_neg_262  1
    rho_30    block_pair_pos_263  -1
    rho_30    block_pair_neg_264  1
    rho_30    block_pair_pos_265  -1
    rho_30    block_pair_neg_266  1
    rho_30    block_pair_pos_279  1
    rho_30    block_pair_neg_280  -1
    rho_30    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_106  -2.4288688410801524e-02
    x_31_0    product_ub_107  -4.0166403672397079e-02
    x_31_0    onehot_31_132  1
    x_31_0    parent_nonstrict_scope_228  0.0735
    x_31_0    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_106  1
    w_31_0    product_ub_107  1
    w_31_0    normalized_mass_31_133  1
    w_31_0    full_original_Gini_286  -2.4896428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_108  -2.4288688410801524e-02
    x_31_1    product_ub_109  -4.0166403672397079e-02
    x_31_1    onehot_31_132  1
    x_31_1    stock_lb_226  1
    x_31_1    stock_ub_227  1
    x_31_1    parent_nonstrict_scope_228  0.063
    x_31_1    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_108  1
    w_31_1    product_ub_109  1
    w_31_1    normalized_mass_31_133  1
    w_31_1    normalized_ratio_31_134  -1.4285714285714285e-01
    w_31_1    full_original_Gini_286  -2.1039285714285725e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_110  -2.4288688410801524e-02
    x_31_2    product_ub_111  -4.0166403672397079e-02
    x_31_2    onehot_31_132  1
    x_31_2    stock_lb_226  2
    x_31_2    stock_ub_227  2
    x_31_2    parent_nonstrict_scope_228  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_110  1
    w_31_2    product_ub_111  1
    w_31_2    normalized_mass_31_133  1
    w_31_2    normalized_ratio_31_134  -2.8571428571428570e-01
    w_31_2    full_original_Gini_286  -1.7353571428571424e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_112  -2.4288688410801524e-02
    x_31_3    product_ub_113  -4.0166403672397079e-02
    x_31_3    onehot_31_132  1
    x_31_3    stock_lb_226  3
    x_31_3    stock_ub_227  3
    x_31_3    parent_nonstrict_scope_228  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_112  1
    w_31_3    product_ub_113  1
    w_31_3    normalized_mass_31_133  1
    w_31_3    normalized_ratio_31_134  -4.2857142857142855e-01
    w_31_3    full_original_Gini_286  -1.3839285714285712e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_114  -2.4288688410801524e-02
    x_31_4    product_ub_115  -4.0166403672397079e-02
    x_31_4    onehot_31_132  1
    x_31_4    stock_lb_226  4
    x_31_4    stock_ub_227  4
    x_31_4    parent_nonstrict_scope_228  0.0315
    x_31_4    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_114  1
    w_31_4    product_ub_115  1
    w_31_4    normalized_mass_31_133  1
    w_31_4    normalized_ratio_31_134  -5.7142857142857140e-01
    w_31_4    full_original_Gini_286  -1.0696428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_116  -2.4288688410801524e-02
    x_31_5    product_ub_117  -4.0166403672397079e-02
    x_31_5    onehot_31_132  1
    x_31_5    stock_lb_226  5
    x_31_5    stock_ub_227  5
    x_31_5    parent_nonstrict_scope_228  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_116  1
    w_31_5    product_ub_117  1
    w_31_5    normalized_mass_31_133  1
    w_31_5    normalized_ratio_31_134  -7.1428571428571419e-01
    w_31_5    full_original_Gini_286  -7.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_118  -2.4288688410801524e-02
    x_31_6    product_ub_119  -4.0166403672397079e-02
    x_31_6    onehot_31_132  1
    x_31_6    stock_lb_226  6
    x_31_6    stock_ub_227  6
    x_31_6    parent_nonstrict_scope_228  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_118  1
    w_31_6    product_ub_119  1
    w_31_6    normalized_mass_31_133  1
    w_31_6    normalized_ratio_31_134  -8.5714285714285710e-01
    w_31_6    full_original_Gini_286  -5.1964285714285738e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_120  -2.4288688410801524e-02
    x_31_7    product_ub_121  -4.0166403672397079e-02
    x_31_7    onehot_31_132  1
    x_31_7    stock_lb_226  7
    x_31_7    stock_ub_227  7
    x_31_7    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_120  1
    w_31_7    product_ub_121  1
    w_31_7    normalized_mass_31_133  1
    w_31_7    normalized_ratio_31_134  -1
    w_31_7    full_original_Gini_286  -3.3035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_122  -2.4288688410801524e-02
    x_31_8    product_ub_123  -4.0166403672397079e-02
    x_31_8    onehot_31_132  1
    x_31_8    stock_lb_226  8
    x_31_8    stock_ub_227  8
    x_31_8    parent_nonstrict_scope_228  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_122  1
    w_31_8    product_ub_123  1
    w_31_8    normalized_mass_31_133  1
    w_31_8    normalized_ratio_31_134  -1.1428571428571428e+00
    w_31_8    full_original_Gini_286  -6.3035714285714253e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_124  -2.4288688410801524e-02
    x_31_9    product_ub_125  -4.0166403672397079e-02
    x_31_9    onehot_31_132  1
    x_31_9    stock_lb_226  9
    x_31_9    stock_ub_227  9
    x_31_9    parent_nonstrict_scope_228  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_124  1
    w_31_9    product_ub_125  1
    w_31_9    normalized_mass_31_133  1
    w_31_9    normalized_ratio_31_134  -1.2857142857142856e+00
    w_31_9    full_original_Gini_286  -9.8178571428571377e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_126  -2.4288688410801524e-02
    x_31_10   product_ub_127  -4.0166403672397079e-02
    x_31_10   onehot_31_132  1
    x_31_10   stock_lb_226  10
    x_31_10   stock_ub_227  10
    x_31_10   parent_nonstrict_scope_228  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_126  1
    w_31_10   product_ub_127  1
    w_31_10   normalized_mass_31_133  1
    w_31_10   normalized_ratio_31_134  -1.4285714285714284e+00
    w_31_10   full_original_Gini_286  -1.3674999999999999e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_128  -2.4288688410801524e-02
    x_31_11   product_ub_129  -4.0166403672397079e-02
    x_31_11   onehot_31_132  1
    x_31_11   stock_lb_226  11
    x_31_11   stock_ub_227  11
    x_31_11   parent_nonstrict_scope_228  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_128  1
    w_31_11   product_ub_129  1
    w_31_11   normalized_mass_31_133  1
    w_31_11   normalized_ratio_31_134  -1.5714285714285714e+00
    w_31_11   full_original_Gini_286  -1.7532142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_130  -2.4288688410801524e-02
    x_31_12   product_ub_131  -4.0166403672397079e-02
    x_31_12   onehot_31_132  1
    x_31_12   stock_lb_226  12
    x_31_12   stock_ub_227  12
    x_31_12   parent_nonstrict_scope_228  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_130  1
    w_31_12   product_ub_131  1
    w_31_12   normalized_mass_31_133  1
    w_31_12   normalized_ratio_31_134  -1.7142857142857142e+00
    w_31_12   full_original_Gini_286  -2.1389285714285709e+01
    rho_31    normalized_ratio_31_134  1
    rho_31    block_pair_pos_235  1
    rho_31    block_pair_neg_236  -1
    rho_31    block_pair_pos_253  1
    rho_31    block_pair_neg_254  -1
    rho_31    block_pair_pos_263  1
    rho_31    block_pair_neg_264  -1
    rho_31    block_pair_pos_267  -1
    rho_31    block_pair_neg_268  1
    rho_31    block_pair_pos_269  -1
    rho_31    block_pair_neg_270  1
    rho_31    block_pair_pos_271  -1
    rho_31    block_pair_neg_272  1
    rho_31    block_pair_pos_281  1
    rho_31    block_pair_neg_282  -1
    rho_31    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       0.012
    x_19_0    product_lb_135  -2.4288688410801524e-02
    x_19_0    product_ub_136  -4.0166403672397079e-02
    x_19_0    onehot_19_153  1
    x_19_0    parent_nonstrict_scope_228  0.024
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_135  1
    w_19_0    product_ub_136  1
    w_19_0    normalized_mass_19_154  1
    w_19_0    full_original_Gini_286  -2.4896428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.0000000000000019e-03
    x_19_1    product_lb_137  -2.4288688410801524e-02
    x_19_1    product_ub_138  -4.0166403672397079e-02
    x_19_1    onehot_19_153  1
    x_19_1    stock_lb_226  1
    x_19_1    stock_ub_227  1
    x_19_1    parent_nonstrict_scope_228  1.8000000000000002e-02
    x_19_1    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_137  1
    w_19_1    product_ub_138  1
    w_19_1    normalized_mass_19_154  1
    w_19_1    normalized_ratio_19_155  -0.25
    w_19_1    full_original_Gini_286  -1.8246428571428570e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    product_lb_139  -2.4288688410801524e-02
    x_19_2    product_ub_140  -4.0166403672397079e-02
    x_19_2    onehot_19_153  1
    x_19_2    stock_lb_226  2
    x_19_2    stock_ub_227  2
    x_19_2    parent_nonstrict_scope_228  0.012
    x_19_2    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_139  1
    w_19_2    product_ub_140  1
    w_19_2    normalized_mass_19_154  1
    w_19_2    normalized_ratio_19_155  -0.5
    w_19_2    full_original_Gini_286  -1.2196428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.006
    x_19_3    product_lb_141  -2.4288688410801524e-02
    x_19_3    product_ub_142  -4.0166403672397079e-02
    x_19_3    onehot_19_153  1
    x_19_3    stock_lb_226  3
    x_19_3    stock_ub_227  3
    x_19_3    parent_nonstrict_scope_228  0.006
    x_19_3    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_141  1
    w_19_3    product_ub_142  1
    w_19_3    normalized_mass_19_154  1
    w_19_3    normalized_ratio_19_155  -0.75
    w_19_3    full_original_Gini_286  -7.0178571428571423e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -0.012
    x_19_4    product_lb_143  -2.4288688410801524e-02
    x_19_4    product_ub_144  -4.0166403672397079e-02
    x_19_4    onehot_19_153  1
    x_19_4    stock_lb_226  4
    x_19_4    stock_ub_227  4
    x_19_4    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_143  1
    w_19_4    product_ub_144  1
    w_19_4    normalized_mass_19_154  1
    w_19_4    normalized_ratio_19_155  -1
    w_19_4    full_original_Gini_286  -3.3035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -0.006
    x_19_5    product_lb_145  -2.4288688410801524e-02
    x_19_5    product_ub_146  -4.0166403672397079e-02
    x_19_5    onehot_19_153  1
    x_19_5    stock_lb_226  5
    x_19_5    stock_ub_227  5
    x_19_5    parent_nonstrict_scope_228  0.006
    x_19_5    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_145  1
    w_19_5    product_ub_146  1
    w_19_5    normalized_mass_19_154  1
    w_19_5    normalized_ratio_19_155  -1.25
    w_19_5    full_original_Gini_286  -8.8535714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_6    product_lb_147  -2.4288688410801524e-02
    x_19_6    product_ub_148  -4.0166403672397079e-02
    x_19_6    onehot_19_153  1
    x_19_6    stock_lb_226  6
    x_19_6    stock_ub_227  6
    x_19_6    parent_nonstrict_scope_228  0.012
    x_19_6    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_147  1
    w_19_6    product_ub_148  1
    w_19_6    normalized_mass_19_154  1
    w_19_6    normalized_ratio_19_155  -1.5
    w_19_6    full_original_Gini_286  -1.5603571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       6.0000000000000019e-03
    x_19_7    product_lb_149  -2.4288688410801524e-02
    x_19_7    product_ub_150  -4.0166403672397079e-02
    x_19_7    onehot_19_153  1
    x_19_7    stock_lb_226  7
    x_19_7    stock_ub_227  7
    x_19_7    parent_nonstrict_scope_228  1.8000000000000002e-02
    x_19_7    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_149  1
    w_19_7    product_ub_150  1
    w_19_7    normalized_mass_19_154  1
    w_19_7    normalized_ratio_19_155  -1.75
    w_19_7    full_original_Gini_286  -2.2353571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.012
    x_19_8    product_lb_151  -2.4288688410801524e-02
    x_19_8    product_ub_152  -4.0166403672397079e-02
    x_19_8    onehot_19_153  1
    x_19_8    stock_lb_226  8
    x_19_8    stock_ub_227  8
    x_19_8    parent_nonstrict_scope_228  0.024
    x_19_8    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_151  1
    w_19_8    product_ub_152  1
    w_19_8    normalized_mass_19_154  1
    w_19_8    normalized_ratio_19_155  -2
    w_19_8    full_original_Gini_286  -2.9103571428571431e+01
    rho_19    normalized_ratio_19_155  1
    rho_19    block_pair_pos_231  1
    rho_19    block_pair_neg_232  -1
    rho_19    block_pair_pos_241  -1
    rho_19    block_pair_neg_242  1
    rho_19    block_pair_pos_243  -1
    rho_19    block_pair_neg_244  1
    rho_19    block_pair_pos_249  1
    rho_19    block_pair_neg_250  -1
    rho_19    block_pair_pos_261  1
    rho_19    block_pair_neg_262  -1
    rho_19    block_pair_pos_269  1
    rho_19    block_pair_neg_270  -1
    rho_19    block_pair_pos_277  1
    rho_19    block_pair_neg_278  -1
    rho_19    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_12_0    OBJ       0.0315
    x_12_0    product_lb_156  -2.4288688410801524e-02
    x_12_0    product_ub_157  -4.0166403672397079e-02
    x_12_0    onehot_12_188  1
    x_12_0    parent_nonstrict_scope_228  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_12_0    product_lb_156  1
    w_12_0    product_ub_157  1
    w_12_0    normalized_mass_12_189  1
    w_12_0    full_original_Gini_286  -2.4896428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_1    OBJ       2.1000000000000005e-02
    x_12_1    product_lb_158  -2.4288688410801524e-02
    x_12_1    product_ub_159  -4.0166403672397079e-02
    x_12_1    onehot_12_188  1
    x_12_1    stock_lb_226  1
    x_12_1    stock_ub_227  1
    x_12_1    parent_nonstrict_scope_228  0.063
    x_12_1    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_1    product_lb_158  1
    w_12_1    product_ub_159  1
    w_12_1    normalized_mass_12_189  1
    w_12_1    normalized_ratio_12_190  -1.4285714285714285e-01
    w_12_1    full_original_Gini_286  -2.1039285714285725e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_2    OBJ       1.0500000000000002e-02
    x_12_2    product_lb_160  -2.4288688410801524e-02
    x_12_2    product_ub_161  -4.0166403672397079e-02
    x_12_2    onehot_12_188  1
    x_12_2    stock_lb_226  2
    x_12_2    stock_ub_227  2
    x_12_2    parent_nonstrict_scope_228  0.0525
    x_12_2    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_2    product_lb_160  1
    w_12_2    product_ub_161  1
    w_12_2    normalized_mass_12_189  1
    w_12_2    normalized_ratio_12_190  -2.8571428571428570e-01
    w_12_2    full_original_Gini_286  -1.7353571428571424e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_3    product_lb_162  -2.4288688410801524e-02
    x_12_3    product_ub_163  -4.0166403672397079e-02
    x_12_3    onehot_12_188  1
    x_12_3    stock_lb_226  3
    x_12_3    stock_ub_227  3
    x_12_3    parent_nonstrict_scope_228  4.1999999999999996e-02
    x_12_3    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_3    product_lb_162  1
    w_12_3    product_ub_163  1
    w_12_3    normalized_mass_12_189  1
    w_12_3    normalized_ratio_12_190  -4.2857142857142855e-01
    w_12_3    full_original_Gini_286  -1.3839285714285712e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_4    OBJ       -1.0499999999999995e-02
    x_12_4    product_lb_164  -2.4288688410801524e-02
    x_12_4    product_ub_165  -4.0166403672397079e-02
    x_12_4    onehot_12_188  1
    x_12_4    stock_lb_226  4
    x_12_4    stock_ub_227  4
    x_12_4    parent_nonstrict_scope_228  0.0315
    x_12_4    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_4    product_lb_164  1
    w_12_4    product_ub_165  1
    w_12_4    normalized_mass_12_189  1
    w_12_4    normalized_ratio_12_190  -5.7142857142857140e-01
    w_12_4    full_original_Gini_286  -1.0696428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_5    OBJ       -2.0999999999999991e-02
    x_12_5    product_lb_166  -2.4288688410801524e-02
    x_12_5    product_ub_167  -4.0166403672397079e-02
    x_12_5    onehot_12_188  1
    x_12_5    stock_lb_226  5
    x_12_5    stock_ub_227  5
    x_12_5    parent_nonstrict_scope_228  2.1000000000000005e-02
    x_12_5    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_5    product_lb_166  1
    w_12_5    product_ub_167  1
    w_12_5    normalized_mass_12_189  1
    w_12_5    normalized_ratio_12_190  -7.1428571428571419e-01
    w_12_5    full_original_Gini_286  -7.6964285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_6    OBJ       -3.1499999999999993e-02
    x_12_6    product_lb_168  -2.4288688410801524e-02
    x_12_6    product_ub_169  -4.0166403672397079e-02
    x_12_6    onehot_12_188  1
    x_12_6    stock_lb_226  6
    x_12_6    stock_ub_227  6
    x_12_6    parent_nonstrict_scope_228  1.0500000000000002e-02
    x_12_6    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_6    product_lb_168  1
    w_12_6    product_ub_169  1
    w_12_6    normalized_mass_12_189  1
    w_12_6    normalized_ratio_12_190  -8.5714285714285710e-01
    w_12_6    full_original_Gini_286  -5.1964285714285738e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_7    OBJ       -4.1999999999999996e-02
    x_12_7    product_lb_170  -2.4288688410801524e-02
    x_12_7    product_ub_171  -4.0166403672397079e-02
    x_12_7    onehot_12_188  1
    x_12_7    stock_lb_226  7
    x_12_7    stock_ub_227  7
    x_12_7    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_7    product_lb_170  1
    w_12_7    product_ub_171  1
    w_12_7    normalized_mass_12_189  1
    w_12_7    normalized_ratio_12_190  -1
    w_12_7    full_original_Gini_286  -3.3035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_8    OBJ       -0.0315
    x_12_8    product_lb_172  -2.4288688410801524e-02
    x_12_8    product_ub_173  -4.0166403672397079e-02
    x_12_8    onehot_12_188  1
    x_12_8    stock_lb_226  8
    x_12_8    stock_ub_227  8
    x_12_8    parent_nonstrict_scope_228  1.0499999999999995e-02
    x_12_8    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_8    product_lb_172  1
    w_12_8    product_ub_173  1
    w_12_8    normalized_mass_12_189  1
    w_12_8    normalized_ratio_12_190  -1.1428571428571428e+00
    w_12_8    full_original_Gini_286  -6.3035714285714253e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_9    OBJ       -2.1000000000000005e-02
    x_12_9    product_lb_174  -2.4288688410801524e-02
    x_12_9    product_ub_175  -4.0166403672397079e-02
    x_12_9    onehot_12_188  1
    x_12_9    stock_lb_226  9
    x_12_9    stock_ub_227  9
    x_12_9    parent_nonstrict_scope_228  2.0999999999999991e-02
    x_12_9    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_9    product_lb_174  1
    w_12_9    product_ub_175  1
    w_12_9    normalized_mass_12_189  1
    w_12_9    normalized_ratio_12_190  -1.2857142857142856e+00
    w_12_9    full_original_Gini_286  -9.8178571428571377e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_10   OBJ       -1.0500000000000009e-02
    x_12_10   product_lb_176  -2.4288688410801524e-02
    x_12_10   product_ub_177  -4.0166403672397079e-02
    x_12_10   onehot_12_188  1
    x_12_10   stock_lb_226  10
    x_12_10   stock_ub_227  10
    x_12_10   parent_nonstrict_scope_228  3.1499999999999986e-02
    x_12_10   unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_10   product_lb_176  1
    w_12_10   product_ub_177  1
    w_12_10   normalized_mass_12_189  1
    w_12_10   normalized_ratio_12_190  -1.4285714285714284e+00
    w_12_10   full_original_Gini_286  -1.3674999999999999e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_11   product_lb_178  -2.4288688410801524e-02
    x_12_11   product_ub_179  -4.0166403672397079e-02
    x_12_11   onehot_12_188  1
    x_12_11   stock_lb_226  11
    x_12_11   stock_ub_227  11
    x_12_11   parent_nonstrict_scope_228  4.1999999999999996e-02
    x_12_11   unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_11   product_lb_178  1
    w_12_11   product_ub_179  1
    w_12_11   normalized_mass_12_189  1
    w_12_11   normalized_ratio_12_190  -1.5714285714285714e+00
    w_12_11   full_original_Gini_286  -1.7532142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_12   OBJ       1.0499999999999995e-02
    x_12_12   product_lb_180  -2.4288688410801524e-02
    x_12_12   product_ub_181  -4.0166403672397079e-02
    x_12_12   onehot_12_188  1
    x_12_12   stock_lb_226  12
    x_12_12   stock_ub_227  12
    x_12_12   parent_nonstrict_scope_228  5.2499999999999991e-02
    x_12_12   unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_12   product_lb_180  1
    w_12_12   product_ub_181  1
    w_12_12   normalized_mass_12_189  1
    w_12_12   normalized_ratio_12_190  -1.7142857142857142e+00
    w_12_12   full_original_Gini_286  -2.1389285714285709e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_13   OBJ       2.0999999999999991e-02
    x_12_13   product_lb_182  -2.4288688410801524e-02
    x_12_13   product_ub_183  -4.0166403672397079e-02
    x_12_13   onehot_12_188  1
    x_12_13   stock_lb_226  13
    x_12_13   stock_ub_227  13
    x_12_13   parent_nonstrict_scope_228  6.2999999999999987e-02
    x_12_13   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_13   product_lb_182  1
    w_12_13   product_ub_183  1
    w_12_13   normalized_mass_12_189  1
    w_12_13   normalized_ratio_12_190  -1.8571428571428570e+00
    w_12_13   full_original_Gini_286  -2.5246428571428574e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_14   OBJ       0.0315
    x_12_14   product_lb_184  -2.4288688410801524e-02
    x_12_14   product_ub_185  -4.0166403672397079e-02
    x_12_14   onehot_12_188  1
    x_12_14   stock_lb_226  14
    x_12_14   stock_ub_227  14
    x_12_14   parent_nonstrict_scope_228  0.0735
    x_12_14   unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_14   product_lb_184  1
    w_12_14   product_ub_185  1
    w_12_14   normalized_mass_12_189  1
    w_12_14   normalized_ratio_12_190  -2
    w_12_14   full_original_Gini_286  -2.9103571428571431e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_15   OBJ       4.1999999999999996e-02
    x_12_15   product_lb_186  -2.4288688410801524e-02
    x_12_15   product_ub_187  -4.0166403672397079e-02
    x_12_15   onehot_12_188  1
    x_12_15   stock_lb_226  15
    x_12_15   stock_ub_227  15
    x_12_15   parent_nonstrict_scope_228  8.3999999999999991e-02
    x_12_15   unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_15   product_lb_186  1
    w_12_15   product_ub_187  1
    w_12_15   normalized_mass_12_189  1
    w_12_15   normalized_ratio_12_190  -2.1428571428571428e+00
    w_12_15   full_original_Gini_286  -3.2960714285714275e+01
    rho_12    normalized_ratio_12_190  1
    rho_12    block_pair_pos_229  1
    rho_12    block_pair_neg_230  -1
    rho_12    block_pair_pos_239  -1
    rho_12    block_pair_neg_240  1
    rho_12    block_pair_pos_241  1
    rho_12    block_pair_neg_242  -1
    rho_12    block_pair_pos_247  1
    rho_12    block_pair_neg_248  -1
    rho_12    block_pair_pos_259  1
    rho_12    block_pair_neg_260  -1
    rho_12    block_pair_pos_267  1
    rho_12    block_pair_neg_268  -1
    rho_12    block_pair_pos_275  1
    rho_12    block_pair_neg_276  -1
    rho_12    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_35_0    OBJ       0.048
    x_35_0    product_lb_191  -2.4288688410801524e-02
    x_35_0    product_ub_192  -4.0166403672397079e-02
    x_35_0    onehot_35_223  1
    x_35_0    parent_nonstrict_scope_228  0.096
    x_35_0    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_0    product_lb_191  1
    w_35_0    product_ub_192  1
    w_35_0    normalized_mass_35_224  1
    w_35_0    full_original_Gini_286  -2.4896428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_1    OBJ       3.6000000000000004e-02
    x_35_1    product_lb_193  -2.4288688410801524e-02
    x_35_1    product_ub_194  -4.0166403672397079e-02
    x_35_1    onehot_35_223  1
    x_35_1    stock_lb_226  1
    x_35_1    stock_ub_227  1
    x_35_1    parent_nonstrict_scope_228  0.084
    x_35_1    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_1    product_lb_193  1
    w_35_1    product_ub_194  1
    w_35_1    normalized_mass_35_224  1
    w_35_1    normalized_ratio_35_225  -0.125
    w_35_1    full_original_Gini_286  -2.1521428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_2    OBJ       2.4000000000000007e-02
    x_35_2    product_lb_195  -2.4288688410801524e-02
    x_35_2    product_ub_196  -4.0166403672397079e-02
    x_35_2    onehot_35_223  1
    x_35_2    stock_lb_226  2
    x_35_2    stock_ub_227  2
    x_35_2    parent_nonstrict_scope_228  7.2000000000000008e-02
    x_35_2    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_2    product_lb_195  1
    w_35_2    product_ub_196  1
    w_35_2    normalized_mass_35_224  1
    w_35_2    normalized_ratio_35_225  -0.25
    w_35_2    full_original_Gini_286  -1.8246428571428570e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_3    OBJ       1.1999999999999997e-02
    x_35_3    product_lb_197  -2.4288688410801524e-02
    x_35_3    product_ub_198  -4.0166403672397079e-02
    x_35_3    onehot_35_223  1
    x_35_3    stock_lb_226  3
    x_35_3    stock_ub_227  3
    x_35_3    parent_nonstrict_scope_228  0.06
    x_35_3    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_3    product_lb_197  1
    w_35_3    product_ub_198  1
    w_35_3    normalized_mass_35_224  1
    w_35_3    normalized_ratio_35_225  -0.375
    w_35_3    full_original_Gini_286  -1.5121428571428570e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_4    product_lb_199  -2.4288688410801524e-02
    x_35_4    product_ub_200  -4.0166403672397079e-02
    x_35_4    onehot_35_223  1
    x_35_4    stock_lb_226  4
    x_35_4    stock_ub_227  4
    x_35_4    parent_nonstrict_scope_228  0.048
    x_35_4    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_4    product_lb_199  1
    w_35_4    product_ub_200  1
    w_35_4    normalized_mass_35_224  1
    w_35_4    normalized_ratio_35_225  -0.5
    w_35_4    full_original_Gini_286  -1.2196428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_5    OBJ       -1.1999999999999997e-02
    x_35_5    product_lb_201  -2.4288688410801524e-02
    x_35_5    product_ub_202  -4.0166403672397079e-02
    x_35_5    onehot_35_223  1
    x_35_5    stock_lb_226  5
    x_35_5    stock_ub_227  5
    x_35_5    parent_nonstrict_scope_228  3.6000000000000004e-02
    x_35_5    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_5    product_lb_201  1
    w_35_5    product_ub_202  1
    w_35_5    normalized_mass_35_224  1
    w_35_5    normalized_ratio_35_225  -0.625
    w_35_5    full_original_Gini_286  -9.5714285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_6    OBJ       -0.024
    x_35_6    product_lb_203  -2.4288688410801524e-02
    x_35_6    product_ub_204  -4.0166403672397079e-02
    x_35_6    onehot_35_223  1
    x_35_6    stock_lb_226  6
    x_35_6    stock_ub_227  6
    x_35_6    parent_nonstrict_scope_228  0.024
    x_35_6    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_6    product_lb_203  1
    w_35_6    product_ub_204  1
    w_35_6    normalized_mass_35_224  1
    w_35_6    normalized_ratio_35_225  -0.75
    w_35_6    full_original_Gini_286  -7.0178571428571423e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_7    OBJ       -3.6000000000000004e-02
    x_35_7    product_lb_205  -2.4288688410801524e-02
    x_35_7    product_ub_206  -4.0166403672397079e-02
    x_35_7    onehot_35_223  1
    x_35_7    stock_lb_226  7
    x_35_7    stock_ub_227  7
    x_35_7    parent_nonstrict_scope_228  0.012
    x_35_7    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_7    product_lb_205  1
    w_35_7    product_ub_206  1
    w_35_7    normalized_mass_35_224  1
    w_35_7    normalized_ratio_35_225  -0.875
    w_35_7    full_original_Gini_286  -4.9285714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_8    OBJ       -0.048
    x_35_8    product_lb_207  -2.4288688410801524e-02
    x_35_8    product_ub_208  -4.0166403672397079e-02
    x_35_8    onehot_35_223  1
    x_35_8    stock_lb_226  8
    x_35_8    stock_ub_227  8
    x_35_8    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_8    product_lb_207  1
    w_35_8    product_ub_208  1
    w_35_8    normalized_mass_35_224  1
    w_35_8    normalized_ratio_35_225  -1
    w_35_8    full_original_Gini_286  -3.3035714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_9    OBJ       -3.6000000000000004e-02
    x_35_9    product_lb_209  -2.4288688410801524e-02
    x_35_9    product_ub_210  -4.0166403672397079e-02
    x_35_9    onehot_35_223  1
    x_35_9    stock_lb_226  9
    x_35_9    stock_ub_227  9
    x_35_9    parent_nonstrict_scope_228  0.012
    x_35_9    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_9    product_lb_209  1
    w_35_9    product_ub_210  1
    w_35_9    normalized_mass_35_224  1
    w_35_9    normalized_ratio_35_225  -1.125
    w_35_9    full_original_Gini_286  -5.9285714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_10   OBJ       -0.024
    x_35_10   product_lb_211  -2.4288688410801524e-02
    x_35_10   product_ub_212  -4.0166403672397079e-02
    x_35_10   onehot_35_223  1
    x_35_10   stock_lb_226  10
    x_35_10   stock_ub_227  10
    x_35_10   parent_nonstrict_scope_228  0.024
    x_35_10   unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_10   product_lb_211  1
    w_35_10   product_ub_212  1
    w_35_10   normalized_mass_35_224  1
    w_35_10   normalized_ratio_35_225  -1.25
    w_35_10   full_original_Gini_286  -8.8535714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_11   OBJ       -1.1999999999999997e-02
    x_35_11   product_lb_213  -2.4288688410801524e-02
    x_35_11   product_ub_214  -4.0166403672397079e-02
    x_35_11   onehot_35_223  1
    x_35_11   stock_lb_226  11
    x_35_11   stock_ub_227  11
    x_35_11   parent_nonstrict_scope_228  3.6000000000000004e-02
    MARKER    'MARKER'                 'INTEND'
    w_35_11   product_lb_213  1
    w_35_11   product_ub_214  1
    w_35_11   normalized_mass_35_224  1
    w_35_11   normalized_ratio_35_225  -1.375
    w_35_11   full_original_Gini_286  -1.2228571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_12   product_lb_215  -2.4288688410801524e-02
    x_35_12   product_ub_216  -4.0166403672397079e-02
    x_35_12   onehot_35_223  1
    x_35_12   stock_lb_226  12
    x_35_12   stock_ub_227  12
    x_35_12   parent_nonstrict_scope_228  0.048
    x_35_12   unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_12   product_lb_215  1
    w_35_12   product_ub_216  1
    w_35_12   normalized_mass_35_224  1
    w_35_12   normalized_ratio_35_225  -1.5
    w_35_12   full_original_Gini_286  -1.5603571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_13   OBJ       1.1999999999999997e-02
    x_35_13   product_lb_217  -2.4288688410801524e-02
    x_35_13   product_ub_218  -4.0166403672397079e-02
    x_35_13   onehot_35_223  1
    x_35_13   stock_lb_226  13
    x_35_13   stock_ub_227  13
    x_35_13   parent_nonstrict_scope_228  0.06
    x_35_13   unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_13   product_lb_217  1
    w_35_13   product_ub_218  1
    w_35_13   normalized_mass_35_224  1
    w_35_13   normalized_ratio_35_225  -1.625
    w_35_13   full_original_Gini_286  -1.8978571428571431e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_14   OBJ       2.4000000000000007e-02
    x_35_14   product_lb_219  -2.4288688410801524e-02
    x_35_14   product_ub_220  -4.0166403672397079e-02
    x_35_14   onehot_35_223  1
    x_35_14   stock_lb_226  14
    x_35_14   stock_ub_227  14
    x_35_14   parent_nonstrict_scope_228  7.2000000000000008e-02
    x_35_14   unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_14   product_lb_219  1
    w_35_14   product_ub_220  1
    w_35_14   normalized_mass_35_224  1
    w_35_14   normalized_ratio_35_225  -1.75
    w_35_14   full_original_Gini_286  -2.2353571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_15   OBJ       3.6000000000000004e-02
    x_35_15   product_lb_221  -2.4288688410801524e-02
    x_35_15   product_ub_222  -4.0166403672397079e-02
    x_35_15   onehot_35_223  1
    x_35_15   stock_lb_226  15
    x_35_15   stock_ub_227  15
    x_35_15   parent_nonstrict_scope_228  0.084
    x_35_15   unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_15   product_lb_221  1
    w_35_15   product_ub_222  1
    w_35_15   normalized_mass_35_224  1
    w_35_15   normalized_ratio_35_225  -1.875
    w_35_15   full_original_Gini_286  -2.5728571428571428e+01
    rho_35    normalized_ratio_35_225  1
    rho_35    block_pair_pos_237  1
    rho_35    block_pair_neg_238  -1
    rho_35    block_pair_pos_239  1
    rho_35    block_pair_neg_240  -1
    rho_35    block_pair_pos_243  1
    rho_35    block_pair_neg_244  -1
    rho_35    block_pair_pos_257  1
    rho_35    block_pair_neg_258  -1
    rho_35    block_pair_pos_265  1
    rho_35    block_pair_neg_266  -1
    rho_35    block_pair_pos_271  1
    rho_35    block_pair_neg_272  -1
    rho_35    block_pair_pos_283  1
    rho_35    block_pair_neg_284  -1
    rho_35    normalization_285  1
    a_26_32   block_pair_pos_255  1
    a_26_32   block_pair_neg_256  1
    a_26_32   full_original_Gini_286  -1
    a_26_2    block_pair_pos_245  1
    a_26_2    block_pair_neg_246  1
    a_26_2    full_original_Gini_286  -1
    a_26_30   block_pair_pos_251  1
    a_26_30   block_pair_neg_252  1
    a_26_30   full_original_Gini_286  -1
    a_26_31   block_pair_pos_253  1
    a_26_31   block_pair_neg_254  1
    a_26_31   full_original_Gini_286  -1
    a_26_19   block_pair_pos_249  1
    a_26_19   block_pair_neg_250  1
    a_26_19   full_original_Gini_286  -1
    a_26_12   block_pair_pos_247  1
    a_26_12   block_pair_neg_248  1
    a_26_12   full_original_Gini_286  -1
    a_26_35   block_pair_pos_257  1
    a_26_35   block_pair_neg_258  1
    a_26_35   full_original_Gini_286  -1
    a_32_2    block_pair_pos_273  1
    a_32_2    block_pair_neg_274  1
    a_32_2    full_original_Gini_286  -1
    a_32_30   block_pair_pos_279  1
    a_32_30   block_pair_neg_280  1
    a_32_30   full_original_Gini_286  -1
    a_32_31   block_pair_pos_281  1
    a_32_31   block_pair_neg_282  1
    a_32_31   full_original_Gini_286  -1
    a_32_19   block_pair_pos_277  1
    a_32_19   block_pair_neg_278  1
    a_32_19   full_original_Gini_286  -1
    a_32_12   block_pair_pos_275  1
    a_32_12   block_pair_neg_276  1
    a_32_12   full_original_Gini_286  -1
    a_32_35   block_pair_pos_283  1
    a_32_35   block_pair_neg_284  1
    a_32_35   full_original_Gini_286  -1
    a_2_30    block_pair_pos_233  1
    a_2_30    block_pair_neg_234  1
    a_2_30    full_original_Gini_286  -1
    a_2_31    block_pair_pos_235  1
    a_2_31    block_pair_neg_236  1
    a_2_31    full_original_Gini_286  -1
    a_2_19    block_pair_pos_231  1
    a_2_19    block_pair_neg_232  1
    a_2_19    full_original_Gini_286  -1
    a_2_12    block_pair_pos_229  1
    a_2_12    block_pair_neg_230  1
    a_2_12    full_original_Gini_286  -1
    a_2_35    block_pair_pos_237  1
    a_2_35    block_pair_neg_238  1
    a_2_35    full_original_Gini_286  -1
    a_30_31   block_pair_pos_263  1
    a_30_31   block_pair_neg_264  1
    a_30_31   full_original_Gini_286  -1
    a_30_19   block_pair_pos_261  1
    a_30_19   block_pair_neg_262  1
    a_30_19   full_original_Gini_286  -1
    a_30_12   block_pair_pos_259  1
    a_30_12   block_pair_neg_260  1
    a_30_12   full_original_Gini_286  -1
    a_30_35   block_pair_pos_265  1
    a_30_35   block_pair_neg_266  1
    a_30_35   full_original_Gini_286  -1
    a_31_19   block_pair_pos_269  1
    a_31_19   block_pair_neg_270  1
    a_31_19   full_original_Gini_286  -1
    a_31_12   block_pair_pos_267  1
    a_31_12   block_pair_neg_268  1
    a_31_12   full_original_Gini_286  -1
    a_31_35   block_pair_pos_271  1
    a_31_35   block_pair_neg_272  1
    a_31_35   full_original_Gini_286  -1
    a_19_12   block_pair_pos_241  1
    a_19_12   block_pair_neg_242  1
    a_19_12   full_original_Gini_286  -1
    a_19_35   block_pair_pos_243  1
    a_19_35   block_pair_neg_244  1
    a_19_35   full_original_Gini_286  -1
    a_12_35   block_pair_pos_239  1
    a_12_35   block_pair_neg_240  1
    a_12_35   full_original_Gini_286  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_26_1  unique_nonzero_owner_287  1
    service_0_26_1  service_visit_def_760  1
    service_0_26_1  free_load_conservation_761  1
    service_0_26_2  unique_nonzero_owner_288  1
    service_0_26_2  service_visit_def_760  1
    service_0_26_2  free_load_conservation_761  2
    service_0_26_3  unique_nonzero_owner_289  1
    service_0_26_3  service_visit_def_760  1
    service_0_26_3  free_load_conservation_761  3
    service_0_26_4  unique_nonzero_owner_290  1
    service_0_26_4  service_visit_def_760  1
    service_0_26_4  free_load_conservation_761  4
    service_0_26_5  unique_nonzero_owner_291  1
    service_0_26_5  service_visit_def_760  1
    service_0_26_5  free_load_conservation_761  5
    service_0_26_6  unique_nonzero_owner_292  1
    service_0_26_6  service_visit_def_760  1
    service_0_26_6  free_load_conservation_761  6
    service_0_26_7  unique_nonzero_owner_293  1
    service_0_26_7  service_visit_def_760  1
    service_0_26_7  free_load_conservation_761  7
    service_0_26_8  unique_nonzero_owner_294  1
    service_0_26_8  service_visit_def_760  1
    service_0_26_8  free_load_conservation_761  8
    service_1_26_1  unique_nonzero_owner_287  1
    service_1_26_1  service_visit_def_1132  1
    service_1_26_1  free_load_conservation_1133  1
    service_1_26_2  unique_nonzero_owner_288  1
    service_1_26_2  service_visit_def_1132  1
    service_1_26_2  free_load_conservation_1133  2
    service_1_26_3  unique_nonzero_owner_289  1
    service_1_26_3  service_visit_def_1132  1
    service_1_26_3  free_load_conservation_1133  3
    service_1_26_4  unique_nonzero_owner_290  1
    service_1_26_4  service_visit_def_1132  1
    service_1_26_4  free_load_conservation_1133  4
    service_1_26_5  unique_nonzero_owner_291  1
    service_1_26_5  service_visit_def_1132  1
    service_1_26_5  free_load_conservation_1133  5
    service_1_26_6  unique_nonzero_owner_292  1
    service_1_26_6  service_visit_def_1132  1
    service_1_26_6  free_load_conservation_1133  6
    service_1_26_7  unique_nonzero_owner_293  1
    service_1_26_7  service_visit_def_1132  1
    service_1_26_7  free_load_conservation_1133  7
    service_1_26_8  unique_nonzero_owner_294  1
    service_1_26_8  service_visit_def_1132  1
    service_1_26_8  free_load_conservation_1133  8
    service_2_26_1  unique_nonzero_owner_287  1
    service_2_26_1  service_visit_def_1503  1
    service_2_26_1  free_load_conservation_1504  1
    service_2_26_2  unique_nonzero_owner_288  1
    service_2_26_2  service_visit_def_1503  1
    service_2_26_2  free_load_conservation_1504  2
    service_2_26_3  unique_nonzero_owner_289  1
    service_2_26_3  service_visit_def_1503  1
    service_2_26_3  free_load_conservation_1504  3
    service_2_26_4  unique_nonzero_owner_290  1
    service_2_26_4  service_visit_def_1503  1
    service_2_26_4  free_load_conservation_1504  4
    service_2_26_5  unique_nonzero_owner_291  1
    service_2_26_5  service_visit_def_1503  1
    service_2_26_5  free_load_conservation_1504  5
    service_2_26_6  unique_nonzero_owner_292  1
    service_2_26_6  service_visit_def_1503  1
    service_2_26_6  free_load_conservation_1504  6
    service_2_26_7  unique_nonzero_owner_293  1
    service_2_26_7  service_visit_def_1503  1
    service_2_26_7  free_load_conservation_1504  7
    service_2_26_8  unique_nonzero_owner_294  1
    service_2_26_8  service_visit_def_1503  1
    service_2_26_8  free_load_conservation_1504  8
    service_0_32_1  unique_nonzero_owner_295  1
    service_0_32_1  service_visit_def_766  1
    service_0_32_1  free_load_conservation_767  1
    service_0_32_2  unique_nonzero_owner_296  1
    service_0_32_2  service_visit_def_766  1
    service_0_32_2  free_load_conservation_767  2
    service_0_32_3  unique_nonzero_owner_297  1
    service_0_32_3  service_visit_def_766  1
    service_0_32_3  free_load_conservation_767  3
    service_0_32_4  unique_nonzero_owner_298  1
    service_0_32_4  service_visit_def_766  1
    service_0_32_4  free_load_conservation_767  4
    service_0_32_5  unique_nonzero_owner_299  1
    service_0_32_5  service_visit_def_766  1
    service_0_32_5  free_load_conservation_767  5
    service_0_32_6  unique_nonzero_owner_300  1
    service_0_32_6  service_visit_def_766  1
    service_0_32_6  free_load_conservation_767  6
    service_0_32_7  unique_nonzero_owner_301  1
    service_0_32_7  service_visit_def_766  1
    service_0_32_7  free_load_conservation_767  7
    service_0_32_8  unique_nonzero_owner_302  1
    service_0_32_8  service_visit_def_766  1
    service_0_32_8  free_load_conservation_767  8
    service_0_32_9  unique_nonzero_owner_303  1
    service_0_32_9  service_visit_def_766  1
    service_0_32_9  free_load_conservation_767  9
    service_0_32_10  unique_nonzero_owner_304  1
    service_0_32_10  service_visit_def_766  1
    service_0_32_10  free_load_conservation_767  10
    service_0_32_11  unique_nonzero_owner_305  1
    service_0_32_11  service_visit_def_766  1
    service_0_32_11  free_load_conservation_767  11
    service_0_32_12  unique_nonzero_owner_306  1
    service_0_32_12  service_visit_def_766  1
    service_0_32_12  free_load_conservation_767  12
    service_1_32_1  unique_nonzero_owner_295  1
    service_1_32_1  service_visit_def_1138  1
    service_1_32_1  free_load_conservation_1139  1
    service_1_32_2  unique_nonzero_owner_296  1
    service_1_32_2  service_visit_def_1138  1
    service_1_32_2  free_load_conservation_1139  2
    service_1_32_3  unique_nonzero_owner_297  1
    service_1_32_3  service_visit_def_1138  1
    service_1_32_3  free_load_conservation_1139  3
    service_1_32_4  unique_nonzero_owner_298  1
    service_1_32_4  service_visit_def_1138  1
    service_1_32_4  free_load_conservation_1139  4
    service_1_32_5  unique_nonzero_owner_299  1
    service_1_32_5  service_visit_def_1138  1
    service_1_32_5  free_load_conservation_1139  5
    service_1_32_6  unique_nonzero_owner_300  1
    service_1_32_6  service_visit_def_1138  1
    service_1_32_6  free_load_conservation_1139  6
    service_1_32_7  unique_nonzero_owner_301  1
    service_1_32_7  service_visit_def_1138  1
    service_1_32_7  free_load_conservation_1139  7
    service_1_32_8  unique_nonzero_owner_302  1
    service_1_32_8  service_visit_def_1138  1
    service_1_32_8  free_load_conservation_1139  8
    service_1_32_9  unique_nonzero_owner_303  1
    service_1_32_9  service_visit_def_1138  1
    service_1_32_9  free_load_conservation_1139  9
    service_1_32_10  unique_nonzero_owner_304  1
    service_1_32_10  service_visit_def_1138  1
    service_1_32_10  free_load_conservation_1139  10
    service_1_32_11  unique_nonzero_owner_305  1
    service_1_32_11  service_visit_def_1138  1
    service_1_32_11  free_load_conservation_1139  11
    service_1_32_12  unique_nonzero_owner_306  1
    service_1_32_12  service_visit_def_1138  1
    service_1_32_12  free_load_conservation_1139  12
    service_2_32_1  unique_nonzero_owner_295  1
    service_2_32_1  service_visit_def_1509  1
    service_2_32_1  free_load_conservation_1510  1
    service_2_32_2  unique_nonzero_owner_296  1
    service_2_32_2  service_visit_def_1509  1
    service_2_32_2  free_load_conservation_1510  2
    service_2_32_3  unique_nonzero_owner_297  1
    service_2_32_3  service_visit_def_1509  1
    service_2_32_3  free_load_conservation_1510  3
    service_2_32_4  unique_nonzero_owner_298  1
    service_2_32_4  service_visit_def_1509  1
    service_2_32_4  free_load_conservation_1510  4
    service_2_32_5  unique_nonzero_owner_299  1
    service_2_32_5  service_visit_def_1509  1
    service_2_32_5  free_load_conservation_1510  5
    service_2_32_6  unique_nonzero_owner_300  1
    service_2_32_6  service_visit_def_1509  1
    service_2_32_6  free_load_conservation_1510  6
    service_2_32_7  unique_nonzero_owner_301  1
    service_2_32_7  service_visit_def_1509  1
    service_2_32_7  free_load_conservation_1510  7
    service_2_32_8  unique_nonzero_owner_302  1
    service_2_32_8  service_visit_def_1509  1
    service_2_32_8  free_load_conservation_1510  8
    service_2_32_9  unique_nonzero_owner_303  1
    service_2_32_9  service_visit_def_1509  1
    service_2_32_9  free_load_conservation_1510  9
    service_2_32_10  unique_nonzero_owner_304  1
    service_2_32_10  service_visit_def_1509  1
    service_2_32_10  free_load_conservation_1510  10
    service_2_32_11  unique_nonzero_owner_305  1
    service_2_32_11  service_visit_def_1509  1
    service_2_32_11  free_load_conservation_1510  11
    service_2_32_12  unique_nonzero_owner_306  1
    service_2_32_12  service_visit_def_1509  1
    service_2_32_12  free_load_conservation_1510  12
    service_0_2_1  unique_nonzero_owner_307  1
    service_0_2_1  service_visit_def_772  1
    service_0_2_1  free_load_conservation_773  1
    service_0_2_2  unique_nonzero_owner_308  1
    service_0_2_2  service_visit_def_772  1
    service_0_2_2  free_load_conservation_773  2
    service_0_2_3  unique_nonzero_owner_309  1
    service_0_2_3  service_visit_def_772  1
    service_0_2_3  free_load_conservation_773  3
    service_0_2_4  unique_nonzero_owner_310  1
    service_0_2_4  service_visit_def_772  1
    service_0_2_4  free_load_conservation_773  4
    service_0_2_5  unique_nonzero_owner_311  1
    service_0_2_5  service_visit_def_772  1
    service_0_2_5  free_load_conservation_773  5
    service_0_2_6  unique_nonzero_owner_312  1
    service_0_2_6  service_visit_def_772  1
    service_0_2_6  free_load_conservation_773  6
    service_0_2_7  unique_nonzero_owner_313  1
    service_0_2_7  service_visit_def_772  1
    service_0_2_7  free_load_conservation_773  7
    service_0_2_8  unique_nonzero_owner_314  1
    service_0_2_8  service_visit_def_772  1
    service_0_2_8  free_load_conservation_773  8
    service_0_2_9  unique_nonzero_owner_315  1
    service_0_2_9  service_visit_def_772  1
    service_0_2_9  free_load_conservation_773  9
    service_0_2_10  unique_nonzero_owner_316  1
    service_0_2_10  service_visit_def_772  1
    service_0_2_10  free_load_conservation_773  10
    service_0_2_11  unique_nonzero_owner_317  1
    service_0_2_11  service_visit_def_772  1
    service_0_2_11  free_load_conservation_773  11
    service_0_2_12  unique_nonzero_owner_318  1
    service_0_2_12  service_visit_def_772  1
    service_0_2_12  free_load_conservation_773  12
    service_0_2_13  unique_nonzero_owner_319  1
    service_0_2_13  service_visit_def_772  1
    service_0_2_13  free_load_conservation_773  13
    service_0_2_14  unique_nonzero_owner_320  1
    service_0_2_14  service_visit_def_772  1
    service_0_2_14  free_load_conservation_773  14
    service_0_2_15  unique_nonzero_owner_321  1
    service_0_2_15  service_visit_def_772  1
    service_0_2_15  free_load_conservation_773  15
    service_1_2_1  unique_nonzero_owner_307  1
    service_1_2_1  service_visit_def_1144  1
    service_1_2_1  free_load_conservation_1145  1
    service_1_2_2  unique_nonzero_owner_308  1
    service_1_2_2  service_visit_def_1144  1
    service_1_2_2  free_load_conservation_1145  2
    service_1_2_3  unique_nonzero_owner_309  1
    service_1_2_3  service_visit_def_1144  1
    service_1_2_3  free_load_conservation_1145  3
    service_1_2_4  unique_nonzero_owner_310  1
    service_1_2_4  service_visit_def_1144  1
    service_1_2_4  free_load_conservation_1145  4
    service_1_2_5  unique_nonzero_owner_311  1
    service_1_2_5  service_visit_def_1144  1
    service_1_2_5  free_load_conservation_1145  5
    service_1_2_6  unique_nonzero_owner_312  1
    service_1_2_6  service_visit_def_1144  1
    service_1_2_6  free_load_conservation_1145  6
    service_1_2_7  unique_nonzero_owner_313  1
    service_1_2_7  service_visit_def_1144  1
    service_1_2_7  free_load_conservation_1145  7
    service_1_2_8  unique_nonzero_owner_314  1
    service_1_2_8  service_visit_def_1144  1
    service_1_2_8  free_load_conservation_1145  8
    service_1_2_9  unique_nonzero_owner_315  1
    service_1_2_9  service_visit_def_1144  1
    service_1_2_9  free_load_conservation_1145  9
    service_1_2_10  unique_nonzero_owner_316  1
    service_1_2_10  service_visit_def_1144  1
    service_1_2_10  free_load_conservation_1145  10
    service_1_2_11  unique_nonzero_owner_317  1
    service_1_2_11  service_visit_def_1144  1
    service_1_2_11  free_load_conservation_1145  11
    service_1_2_12  unique_nonzero_owner_318  1
    service_1_2_12  service_visit_def_1144  1
    service_1_2_12  free_load_conservation_1145  12
    service_1_2_13  unique_nonzero_owner_319  1
    service_1_2_13  service_visit_def_1144  1
    service_1_2_13  free_load_conservation_1145  13
    service_1_2_14  unique_nonzero_owner_320  1
    service_1_2_14  service_visit_def_1144  1
    service_1_2_14  free_load_conservation_1145  14
    service_1_2_15  unique_nonzero_owner_321  1
    service_1_2_15  service_visit_def_1144  1
    service_1_2_15  free_load_conservation_1145  15
    service_2_2_1  unique_nonzero_owner_307  1
    service_2_2_1  service_visit_def_1515  1
    service_2_2_1  free_load_conservation_1516  1
    service_2_2_2  unique_nonzero_owner_308  1
    service_2_2_2  service_visit_def_1515  1
    service_2_2_2  free_load_conservation_1516  2
    service_2_2_3  unique_nonzero_owner_309  1
    service_2_2_3  service_visit_def_1515  1
    service_2_2_3  free_load_conservation_1516  3
    service_2_2_4  unique_nonzero_owner_310  1
    service_2_2_4  service_visit_def_1515  1
    service_2_2_4  free_load_conservation_1516  4
    service_2_2_5  unique_nonzero_owner_311  1
    service_2_2_5  service_visit_def_1515  1
    service_2_2_5  free_load_conservation_1516  5
    service_2_2_6  unique_nonzero_owner_312  1
    service_2_2_6  service_visit_def_1515  1
    service_2_2_6  free_load_conservation_1516  6
    service_2_2_7  unique_nonzero_owner_313  1
    service_2_2_7  service_visit_def_1515  1
    service_2_2_7  free_load_conservation_1516  7
    service_2_2_8  unique_nonzero_owner_314  1
    service_2_2_8  service_visit_def_1515  1
    service_2_2_8  free_load_conservation_1516  8
    service_2_2_9  unique_nonzero_owner_315  1
    service_2_2_9  service_visit_def_1515  1
    service_2_2_9  free_load_conservation_1516  9
    service_2_2_10  unique_nonzero_owner_316  1
    service_2_2_10  service_visit_def_1515  1
    service_2_2_10  free_load_conservation_1516  10
    service_2_2_11  unique_nonzero_owner_317  1
    service_2_2_11  service_visit_def_1515  1
    service_2_2_11  free_load_conservation_1516  11
    service_2_2_12  unique_nonzero_owner_318  1
    service_2_2_12  service_visit_def_1515  1
    service_2_2_12  free_load_conservation_1516  12
    service_2_2_13  unique_nonzero_owner_319  1
    service_2_2_13  service_visit_def_1515  1
    service_2_2_13  free_load_conservation_1516  13
    service_2_2_14  unique_nonzero_owner_320  1
    service_2_2_14  service_visit_def_1515  1
    service_2_2_14  free_load_conservation_1516  14
    service_2_2_15  unique_nonzero_owner_321  1
    service_2_2_15  service_visit_def_1515  1
    service_2_2_15  free_load_conservation_1516  15
    service_0_30_0  unique_nonzero_owner_322  1
    service_0_30_0  service_visit_def_778  1
    service_0_30_0  free_load_conservation_779  -5
    service_0_30_0  original_T_including_depot_unload_808  600
    service_0_30_1  unique_nonzero_owner_323  1
    service_0_30_1  service_visit_def_778  1
    service_0_30_1  free_load_conservation_779  -4
    service_0_30_1  original_T_including_depot_unload_808  480
    service_0_30_2  unique_nonzero_owner_324  1
    service_0_30_2  service_visit_def_778  1
    service_0_30_2  free_load_conservation_779  -3
    service_0_30_2  original_T_including_depot_unload_808  360
    service_0_30_3  unique_nonzero_owner_325  1
    service_0_30_3  service_visit_def_778  1
    service_0_30_3  free_load_conservation_779  -2
    service_0_30_3  original_T_including_depot_unload_808  240
    service_0_30_4  unique_nonzero_owner_326  1
    service_0_30_4  service_visit_def_778  1
    service_0_30_4  free_load_conservation_779  -1
    service_0_30_4  original_T_including_depot_unload_808  120
    service_0_30_6  unique_nonzero_owner_327  1
    service_0_30_6  service_visit_def_778  1
    service_0_30_6  free_load_conservation_779  1
    service_0_30_7  unique_nonzero_owner_328  1
    service_0_30_7  service_visit_def_778  1
    service_0_30_7  free_load_conservation_779  2
    service_0_30_8  unique_nonzero_owner_329  1
    service_0_30_8  service_visit_def_778  1
    service_0_30_8  free_load_conservation_779  3
    service_1_30_0  unique_nonzero_owner_322  1
    service_1_30_0  service_visit_def_1150  1
    service_1_30_0  free_load_conservation_1151  -5
    service_1_30_0  original_T_including_depot_unload_1179  600
    service_1_30_1  unique_nonzero_owner_323  1
    service_1_30_1  service_visit_def_1150  1
    service_1_30_1  free_load_conservation_1151  -4
    service_1_30_1  original_T_including_depot_unload_1179  480
    service_1_30_2  unique_nonzero_owner_324  1
    service_1_30_2  service_visit_def_1150  1
    service_1_30_2  free_load_conservation_1151  -3
    service_1_30_2  original_T_including_depot_unload_1179  360
    service_1_30_3  unique_nonzero_owner_325  1
    service_1_30_3  service_visit_def_1150  1
    service_1_30_3  free_load_conservation_1151  -2
    service_1_30_3  original_T_including_depot_unload_1179  240
    service_1_30_4  unique_nonzero_owner_326  1
    service_1_30_4  service_visit_def_1150  1
    service_1_30_4  free_load_conservation_1151  -1
    service_1_30_4  original_T_including_depot_unload_1179  120
    service_1_30_6  unique_nonzero_owner_327  1
    service_1_30_6  service_visit_def_1150  1
    service_1_30_6  free_load_conservation_1151  1
    service_1_30_7  unique_nonzero_owner_328  1
    service_1_30_7  service_visit_def_1150  1
    service_1_30_7  free_load_conservation_1151  2
    service_1_30_8  unique_nonzero_owner_329  1
    service_1_30_8  service_visit_def_1150  1
    service_1_30_8  free_load_conservation_1151  3
    service_2_30_0  unique_nonzero_owner_322  1
    service_2_30_0  service_visit_def_1521  1
    service_2_30_0  free_load_conservation_1522  -5
    service_2_30_0  original_T_including_depot_unload_1550  600
    service_2_30_1  unique_nonzero_owner_323  1
    service_2_30_1  service_visit_def_1521  1
    service_2_30_1  free_load_conservation_1522  -4
    service_2_30_1  original_T_including_depot_unload_1550  480
    service_2_30_2  unique_nonzero_owner_324  1
    service_2_30_2  service_visit_def_1521  1
    service_2_30_2  free_load_conservation_1522  -3
    service_2_30_2  original_T_including_depot_unload_1550  360
    service_2_30_3  unique_nonzero_owner_325  1
    service_2_30_3  service_visit_def_1521  1
    service_2_30_3  free_load_conservation_1522  -2
    service_2_30_3  original_T_including_depot_unload_1550  240
    service_2_30_4  unique_nonzero_owner_326  1
    service_2_30_4  service_visit_def_1521  1
    service_2_30_4  free_load_conservation_1522  -1
    service_2_30_4  original_T_including_depot_unload_1550  120
    service_2_30_6  unique_nonzero_owner_327  1
    service_2_30_6  service_visit_def_1521  1
    service_2_30_6  free_load_conservation_1522  1
    service_2_30_7  unique_nonzero_owner_328  1
    service_2_30_7  service_visit_def_1521  1
    service_2_30_7  free_load_conservation_1522  2
    service_2_30_8  unique_nonzero_owner_329  1
    service_2_30_8  service_visit_def_1521  1
    service_2_30_8  free_load_conservation_1522  3
    service_0_31_0  unique_nonzero_owner_330  1
    service_0_31_0  service_visit_def_784  1
    service_0_31_0  free_load_conservation_785  -2
    service_0_31_0  original_T_including_depot_unload_808  240
    service_0_31_1  unique_nonzero_owner_331  1
    service_0_31_1  service_visit_def_784  1
    service_0_31_1  free_load_conservation_785  -1
    service_0_31_1  original_T_including_depot_unload_808  120
    service_0_31_3  unique_nonzero_owner_332  1
    service_0_31_3  service_visit_def_784  1
    service_0_31_3  free_load_conservation_785  1
    service_0_31_4  unique_nonzero_owner_333  1
    service_0_31_4  service_visit_def_784  1
    service_0_31_4  free_load_conservation_785  2
    service_0_31_5  unique_nonzero_owner_334  1
    service_0_31_5  service_visit_def_784  1
    service_0_31_5  free_load_conservation_785  3
    service_0_31_6  unique_nonzero_owner_335  1
    service_0_31_6  service_visit_def_784  1
    service_0_31_6  free_load_conservation_785  4
    service_0_31_7  unique_nonzero_owner_336  1
    service_0_31_7  service_visit_def_784  1
    service_0_31_7  free_load_conservation_785  5
    service_0_31_8  unique_nonzero_owner_337  1
    service_0_31_8  service_visit_def_784  1
    service_0_31_8  free_load_conservation_785  6
    service_0_31_9  unique_nonzero_owner_338  1
    service_0_31_9  service_visit_def_784  1
    service_0_31_9  free_load_conservation_785  7
    service_0_31_10  unique_nonzero_owner_339  1
    service_0_31_10  service_visit_def_784  1
    service_0_31_10  free_load_conservation_785  8
    service_0_31_11  unique_nonzero_owner_340  1
    service_0_31_11  service_visit_def_784  1
    service_0_31_11  free_load_conservation_785  9
    service_0_31_12  unique_nonzero_owner_341  1
    service_0_31_12  service_visit_def_784  1
    service_0_31_12  free_load_conservation_785  10
    service_1_31_0  unique_nonzero_owner_330  1
    service_1_31_0  service_visit_def_1156  1
    service_1_31_0  free_load_conservation_1157  -2
    service_1_31_0  original_T_including_depot_unload_1179  240
    service_1_31_1  unique_nonzero_owner_331  1
    service_1_31_1  service_visit_def_1156  1
    service_1_31_1  free_load_conservation_1157  -1
    service_1_31_1  original_T_including_depot_unload_1179  120
    service_1_31_3  unique_nonzero_owner_332  1
    service_1_31_3  service_visit_def_1156  1
    service_1_31_3  free_load_conservation_1157  1
    service_1_31_4  unique_nonzero_owner_333  1
    service_1_31_4  service_visit_def_1156  1
    service_1_31_4  free_load_conservation_1157  2
    service_1_31_5  unique_nonzero_owner_334  1
    service_1_31_5  service_visit_def_1156  1
    service_1_31_5  free_load_conservation_1157  3
    service_1_31_6  unique_nonzero_owner_335  1
    service_1_31_6  service_visit_def_1156  1
    service_1_31_6  free_load_conservation_1157  4
    service_1_31_7  unique_nonzero_owner_336  1
    service_1_31_7  service_visit_def_1156  1
    service_1_31_7  free_load_conservation_1157  5
    service_1_31_8  unique_nonzero_owner_337  1
    service_1_31_8  service_visit_def_1156  1
    service_1_31_8  free_load_conservation_1157  6
    service_1_31_9  unique_nonzero_owner_338  1
    service_1_31_9  service_visit_def_1156  1
    service_1_31_9  free_load_conservation_1157  7
    service_1_31_10  unique_nonzero_owner_339  1
    service_1_31_10  service_visit_def_1156  1
    service_1_31_10  free_load_conservation_1157  8
    service_1_31_11  unique_nonzero_owner_340  1
    service_1_31_11  service_visit_def_1156  1
    service_1_31_11  free_load_conservation_1157  9
    service_1_31_12  unique_nonzero_owner_341  1
    service_1_31_12  service_visit_def_1156  1
    service_1_31_12  free_load_conservation_1157  10
    service_2_31_0  unique_nonzero_owner_330  1
    service_2_31_0  service_visit_def_1527  1
    service_2_31_0  free_load_conservation_1528  -2
    service_2_31_0  original_T_including_depot_unload_1550  240
    service_2_31_1  unique_nonzero_owner_331  1
    service_2_31_1  service_visit_def_1527  1
    service_2_31_1  free_load_conservation_1528  -1
    service_2_31_1  original_T_including_depot_unload_1550  120
    service_2_31_3  unique_nonzero_owner_332  1
    service_2_31_3  service_visit_def_1527  1
    service_2_31_3  free_load_conservation_1528  1
    service_2_31_4  unique_nonzero_owner_333  1
    service_2_31_4  service_visit_def_1527  1
    service_2_31_4  free_load_conservation_1528  2
    service_2_31_5  unique_nonzero_owner_334  1
    service_2_31_5  service_visit_def_1527  1
    service_2_31_5  free_load_conservation_1528  3
    service_2_31_6  unique_nonzero_owner_335  1
    service_2_31_6  service_visit_def_1527  1
    service_2_31_6  free_load_conservation_1528  4
    service_2_31_7  unique_nonzero_owner_336  1
    service_2_31_7  service_visit_def_1527  1
    service_2_31_7  free_load_conservation_1528  5
    service_2_31_8  unique_nonzero_owner_337  1
    service_2_31_8  service_visit_def_1527  1
    service_2_31_8  free_load_conservation_1528  6
    service_2_31_9  unique_nonzero_owner_338  1
    service_2_31_9  service_visit_def_1527  1
    service_2_31_9  free_load_conservation_1528  7
    service_2_31_10  unique_nonzero_owner_339  1
    service_2_31_10  service_visit_def_1527  1
    service_2_31_10  free_load_conservation_1528  8
    service_2_31_11  unique_nonzero_owner_340  1
    service_2_31_11  service_visit_def_1527  1
    service_2_31_11  free_load_conservation_1528  9
    service_2_31_12  unique_nonzero_owner_341  1
    service_2_31_12  service_visit_def_1527  1
    service_2_31_12  free_load_conservation_1528  10
    service_0_19_1  unique_nonzero_owner_342  1
    service_0_19_1  service_visit_def_790  1
    service_0_19_1  free_load_conservation_791  1
    service_0_19_2  unique_nonzero_owner_343  1
    service_0_19_2  service_visit_def_790  1
    service_0_19_2  free_load_conservation_791  2
    service_0_19_3  unique_nonzero_owner_344  1
    service_0_19_3  service_visit_def_790  1
    service_0_19_3  free_load_conservation_791  3
    service_0_19_4  unique_nonzero_owner_345  1
    service_0_19_4  service_visit_def_790  1
    service_0_19_4  free_load_conservation_791  4
    service_0_19_5  unique_nonzero_owner_346  1
    service_0_19_5  service_visit_def_790  1
    service_0_19_5  free_load_conservation_791  5
    service_0_19_6  unique_nonzero_owner_347  1
    service_0_19_6  service_visit_def_790  1
    service_0_19_6  free_load_conservation_791  6
    service_0_19_7  unique_nonzero_owner_348  1
    service_0_19_7  service_visit_def_790  1
    service_0_19_7  free_load_conservation_791  7
    service_0_19_8  unique_nonzero_owner_349  1
    service_0_19_8  service_visit_def_790  1
    service_0_19_8  free_load_conservation_791  8
    service_1_19_1  unique_nonzero_owner_342  1
    service_1_19_1  service_visit_def_1162  1
    service_1_19_1  free_load_conservation_1163  1
    service_1_19_2  unique_nonzero_owner_343  1
    service_1_19_2  service_visit_def_1162  1
    service_1_19_2  free_load_conservation_1163  2
    service_1_19_3  unique_nonzero_owner_344  1
    service_1_19_3  service_visit_def_1162  1
    service_1_19_3  free_load_conservation_1163  3
    service_1_19_4  unique_nonzero_owner_345  1
    service_1_19_4  service_visit_def_1162  1
    service_1_19_4  free_load_conservation_1163  4
    service_1_19_5  unique_nonzero_owner_346  1
    service_1_19_5  service_visit_def_1162  1
    service_1_19_5  free_load_conservation_1163  5
    service_1_19_6  unique_nonzero_owner_347  1
    service_1_19_6  service_visit_def_1162  1
    service_1_19_6  free_load_conservation_1163  6
    service_1_19_7  unique_nonzero_owner_348  1
    service_1_19_7  service_visit_def_1162  1
    service_1_19_7  free_load_conservation_1163  7
    service_1_19_8  unique_nonzero_owner_349  1
    service_1_19_8  service_visit_def_1162  1
    service_1_19_8  free_load_conservation_1163  8
    service_2_19_1  unique_nonzero_owner_342  1
    service_2_19_1  service_visit_def_1533  1
    service_2_19_1  free_load_conservation_1534  1
    service_2_19_2  unique_nonzero_owner_343  1
    service_2_19_2  service_visit_def_1533  1
    service_2_19_2  free_load_conservation_1534  2
    service_2_19_3  unique_nonzero_owner_344  1
    service_2_19_3  service_visit_def_1533  1
    service_2_19_3  free_load_conservation_1534  3
    service_2_19_4  unique_nonzero_owner_345  1
    service_2_19_4  service_visit_def_1533  1
    service_2_19_4  free_load_conservation_1534  4
    service_2_19_5  unique_nonzero_owner_346  1
    service_2_19_5  service_visit_def_1533  1
    service_2_19_5  free_load_conservation_1534  5
    service_2_19_6  unique_nonzero_owner_347  1
    service_2_19_6  service_visit_def_1533  1
    service_2_19_6  free_load_conservation_1534  6
    service_2_19_7  unique_nonzero_owner_348  1
    service_2_19_7  service_visit_def_1533  1
    service_2_19_7  free_load_conservation_1534  7
    service_2_19_8  unique_nonzero_owner_349  1
    service_2_19_8  service_visit_def_1533  1
    service_2_19_8  free_load_conservation_1534  8
    service_0_12_1  unique_nonzero_owner_350  1
    service_0_12_1  service_visit_def_796  1
    service_0_12_1  free_load_conservation_797  1
    service_0_12_2  unique_nonzero_owner_351  1
    service_0_12_2  service_visit_def_796  1
    service_0_12_2  free_load_conservation_797  2
    service_0_12_3  unique_nonzero_owner_352  1
    service_0_12_3  service_visit_def_796  1
    service_0_12_3  free_load_conservation_797  3
    service_0_12_4  unique_nonzero_owner_353  1
    service_0_12_4  service_visit_def_796  1
    service_0_12_4  free_load_conservation_797  4
    service_0_12_5  unique_nonzero_owner_354  1
    service_0_12_5  service_visit_def_796  1
    service_0_12_5  free_load_conservation_797  5
    service_0_12_6  unique_nonzero_owner_355  1
    service_0_12_6  service_visit_def_796  1
    service_0_12_6  free_load_conservation_797  6
    service_0_12_7  unique_nonzero_owner_356  1
    service_0_12_7  service_visit_def_796  1
    service_0_12_7  free_load_conservation_797  7
    service_0_12_8  unique_nonzero_owner_357  1
    service_0_12_8  service_visit_def_796  1
    service_0_12_8  free_load_conservation_797  8
    service_0_12_9  unique_nonzero_owner_358  1
    service_0_12_9  service_visit_def_796  1
    service_0_12_9  free_load_conservation_797  9
    service_0_12_10  unique_nonzero_owner_359  1
    service_0_12_10  service_visit_def_796  1
    service_0_12_10  free_load_conservation_797  10
    service_0_12_11  unique_nonzero_owner_360  1
    service_0_12_11  service_visit_def_796  1
    service_0_12_11  free_load_conservation_797  11
    service_0_12_12  unique_nonzero_owner_361  1
    service_0_12_12  service_visit_def_796  1
    service_0_12_12  free_load_conservation_797  12
    service_0_12_13  unique_nonzero_owner_362  1
    service_0_12_13  service_visit_def_796  1
    service_0_12_13  free_load_conservation_797  13
    service_0_12_14  unique_nonzero_owner_363  1
    service_0_12_14  service_visit_def_796  1
    service_0_12_14  free_load_conservation_797  14
    service_0_12_15  unique_nonzero_owner_364  1
    service_0_12_15  service_visit_def_796  1
    service_0_12_15  free_load_conservation_797  15
    service_1_12_1  unique_nonzero_owner_350  1
    service_1_12_1  service_visit_def_1168  1
    service_1_12_1  free_load_conservation_1169  1
    service_1_12_2  unique_nonzero_owner_351  1
    service_1_12_2  service_visit_def_1168  1
    service_1_12_2  free_load_conservation_1169  2
    service_1_12_3  unique_nonzero_owner_352  1
    service_1_12_3  service_visit_def_1168  1
    service_1_12_3  free_load_conservation_1169  3
    service_1_12_4  unique_nonzero_owner_353  1
    service_1_12_4  service_visit_def_1168  1
    service_1_12_4  free_load_conservation_1169  4
    service_1_12_5  unique_nonzero_owner_354  1
    service_1_12_5  service_visit_def_1168  1
    service_1_12_5  free_load_conservation_1169  5
    service_1_12_6  unique_nonzero_owner_355  1
    service_1_12_6  service_visit_def_1168  1
    service_1_12_6  free_load_conservation_1169  6
    service_1_12_7  unique_nonzero_owner_356  1
    service_1_12_7  service_visit_def_1168  1
    service_1_12_7  free_load_conservation_1169  7
    service_1_12_8  unique_nonzero_owner_357  1
    service_1_12_8  service_visit_def_1168  1
    service_1_12_8  free_load_conservation_1169  8
    service_1_12_9  unique_nonzero_owner_358  1
    service_1_12_9  service_visit_def_1168  1
    service_1_12_9  free_load_conservation_1169  9
    service_1_12_10  unique_nonzero_owner_359  1
    service_1_12_10  service_visit_def_1168  1
    service_1_12_10  free_load_conservation_1169  10
    service_1_12_11  unique_nonzero_owner_360  1
    service_1_12_11  service_visit_def_1168  1
    service_1_12_11  free_load_conservation_1169  11
    service_1_12_12  unique_nonzero_owner_361  1
    service_1_12_12  service_visit_def_1168  1
    service_1_12_12  free_load_conservation_1169  12
    service_1_12_13  unique_nonzero_owner_362  1
    service_1_12_13  service_visit_def_1168  1
    service_1_12_13  free_load_conservation_1169  13
    service_1_12_14  unique_nonzero_owner_363  1
    service_1_12_14  service_visit_def_1168  1
    service_1_12_14  free_load_conservation_1169  14
    service_1_12_15  unique_nonzero_owner_364  1
    service_1_12_15  service_visit_def_1168  1
    service_1_12_15  free_load_conservation_1169  15
    service_2_12_1  unique_nonzero_owner_350  1
    service_2_12_1  service_visit_def_1539  1
    service_2_12_1  free_load_conservation_1540  1
    service_2_12_2  unique_nonzero_owner_351  1
    service_2_12_2  service_visit_def_1539  1
    service_2_12_2  free_load_conservation_1540  2
    service_2_12_3  unique_nonzero_owner_352  1
    service_2_12_3  service_visit_def_1539  1
    service_2_12_3  free_load_conservation_1540  3
    service_2_12_4  unique_nonzero_owner_353  1
    service_2_12_4  service_visit_def_1539  1
    service_2_12_4  free_load_conservation_1540  4
    service_2_12_5  unique_nonzero_owner_354  1
    service_2_12_5  service_visit_def_1539  1
    service_2_12_5  free_load_conservation_1540  5
    service_2_12_6  unique_nonzero_owner_355  1
    service_2_12_6  service_visit_def_1539  1
    service_2_12_6  free_load_conservation_1540  6
    service_2_12_7  unique_nonzero_owner_356  1
    service_2_12_7  service_visit_def_1539  1
    service_2_12_7  free_load_conservation_1540  7
    service_2_12_8  unique_nonzero_owner_357  1
    service_2_12_8  service_visit_def_1539  1
    service_2_12_8  free_load_conservation_1540  8
    service_2_12_9  unique_nonzero_owner_358  1
    service_2_12_9  service_visit_def_1539  1
    service_2_12_9  free_load_conservation_1540  9
    service_2_12_10  unique_nonzero_owner_359  1
    service_2_12_10  service_visit_def_1539  1
    service_2_12_10  free_load_conservation_1540  10
    service_2_12_11  unique_nonzero_owner_360  1
    service_2_12_11  service_visit_def_1539  1
    service_2_12_11  free_load_conservation_1540  11
    service_2_12_12  unique_nonzero_owner_361  1
    service_2_12_12  service_visit_def_1539  1
    service_2_12_12  free_load_conservation_1540  12
    service_2_12_13  unique_nonzero_owner_362  1
    service_2_12_13  service_visit_def_1539  1
    service_2_12_13  free_load_conservation_1540  13
    service_2_12_14  unique_nonzero_owner_363  1
    service_2_12_14  service_visit_def_1539  1
    service_2_12_14  free_load_conservation_1540  14
    service_2_12_15  unique_nonzero_owner_364  1
    service_2_12_15  service_visit_def_1539  1
    service_2_12_15  free_load_conservation_1540  15
    service_0_35_0  unique_nonzero_owner_365  1
    service_0_35_0  service_visit_def_802  1
    service_0_35_0  free_load_conservation_803  -11
    service_0_35_0  original_T_including_depot_unload_808  1320
    service_0_35_1  unique_nonzero_owner_366  1
    service_0_35_1  service_visit_def_802  1
    service_0_35_1  free_load_conservation_803  -10
    service_0_35_1  original_T_including_depot_unload_808  1200
    service_0_35_2  unique_nonzero_owner_367  1
    service_0_35_2  service_visit_def_802  1
    service_0_35_2  free_load_conservation_803  -9
    service_0_35_2  original_T_including_depot_unload_808  1080
    service_0_35_3  unique_nonzero_owner_368  1
    service_0_35_3  service_visit_def_802  1
    service_0_35_3  free_load_conservation_803  -8
    service_0_35_3  original_T_including_depot_unload_808  960
    service_0_35_4  unique_nonzero_owner_369  1
    service_0_35_4  service_visit_def_802  1
    service_0_35_4  free_load_conservation_803  -7
    service_0_35_4  original_T_including_depot_unload_808  840
    service_0_35_5  unique_nonzero_owner_370  1
    service_0_35_5  service_visit_def_802  1
    service_0_35_5  free_load_conservation_803  -6
    service_0_35_5  original_T_including_depot_unload_808  720
    service_0_35_6  unique_nonzero_owner_371  1
    service_0_35_6  service_visit_def_802  1
    service_0_35_6  free_load_conservation_803  -5
    service_0_35_6  original_T_including_depot_unload_808  600
    service_0_35_7  unique_nonzero_owner_372  1
    service_0_35_7  service_visit_def_802  1
    service_0_35_7  free_load_conservation_803  -4
    service_0_35_7  original_T_including_depot_unload_808  480
    service_0_35_8  unique_nonzero_owner_373  1
    service_0_35_8  service_visit_def_802  1
    service_0_35_8  free_load_conservation_803  -3
    service_0_35_8  original_T_including_depot_unload_808  360
    service_0_35_9  unique_nonzero_owner_374  1
    service_0_35_9  service_visit_def_802  1
    service_0_35_9  free_load_conservation_803  -2
    service_0_35_9  original_T_including_depot_unload_808  240
    service_0_35_10  unique_nonzero_owner_375  1
    service_0_35_10  service_visit_def_802  1
    service_0_35_10  free_load_conservation_803  -1
    service_0_35_10  original_T_including_depot_unload_808  120
    service_0_35_12  unique_nonzero_owner_376  1
    service_0_35_12  service_visit_def_802  1
    service_0_35_12  free_load_conservation_803  1
    service_0_35_13  unique_nonzero_owner_377  1
    service_0_35_13  service_visit_def_802  1
    service_0_35_13  free_load_conservation_803  2
    service_0_35_14  unique_nonzero_owner_378  1
    service_0_35_14  service_visit_def_802  1
    service_0_35_14  free_load_conservation_803  3
    service_0_35_15  unique_nonzero_owner_379  1
    service_0_35_15  service_visit_def_802  1
    service_0_35_15  free_load_conservation_803  4
    service_1_35_0  unique_nonzero_owner_365  1
    service_1_35_0  service_visit_def_1174  1
    service_1_35_0  free_load_conservation_1175  -11
    service_1_35_0  original_T_including_depot_unload_1179  1320
    service_1_35_1  unique_nonzero_owner_366  1
    service_1_35_1  service_visit_def_1174  1
    service_1_35_1  free_load_conservation_1175  -10
    service_1_35_1  original_T_including_depot_unload_1179  1200
    service_1_35_2  unique_nonzero_owner_367  1
    service_1_35_2  service_visit_def_1174  1
    service_1_35_2  free_load_conservation_1175  -9
    service_1_35_2  original_T_including_depot_unload_1179  1080
    service_1_35_3  unique_nonzero_owner_368  1
    service_1_35_3  service_visit_def_1174  1
    service_1_35_3  free_load_conservation_1175  -8
    service_1_35_3  original_T_including_depot_unload_1179  960
    service_1_35_4  unique_nonzero_owner_369  1
    service_1_35_4  service_visit_def_1174  1
    service_1_35_4  free_load_conservation_1175  -7
    service_1_35_4  original_T_including_depot_unload_1179  840
    service_1_35_5  unique_nonzero_owner_370  1
    service_1_35_5  service_visit_def_1174  1
    service_1_35_5  free_load_conservation_1175  -6
    service_1_35_5  original_T_including_depot_unload_1179  720
    service_1_35_6  unique_nonzero_owner_371  1
    service_1_35_6  service_visit_def_1174  1
    service_1_35_6  free_load_conservation_1175  -5
    service_1_35_6  original_T_including_depot_unload_1179  600
    service_1_35_7  unique_nonzero_owner_372  1
    service_1_35_7  service_visit_def_1174  1
    service_1_35_7  free_load_conservation_1175  -4
    service_1_35_7  original_T_including_depot_unload_1179  480
    service_1_35_8  unique_nonzero_owner_373  1
    service_1_35_8  service_visit_def_1174  1
    service_1_35_8  free_load_conservation_1175  -3
    service_1_35_8  original_T_including_depot_unload_1179  360
    service_1_35_9  unique_nonzero_owner_374  1
    service_1_35_9  service_visit_def_1174  1
    service_1_35_9  free_load_conservation_1175  -2
    service_1_35_9  original_T_including_depot_unload_1179  240
    service_1_35_10  unique_nonzero_owner_375  1
    service_1_35_10  service_visit_def_1174  1
    service_1_35_10  free_load_conservation_1175  -1
    service_1_35_10  original_T_including_depot_unload_1179  120
    service_1_35_12  unique_nonzero_owner_376  1
    service_1_35_12  service_visit_def_1174  1
    service_1_35_12  free_load_conservation_1175  1
    service_1_35_13  unique_nonzero_owner_377  1
    service_1_35_13  service_visit_def_1174  1
    service_1_35_13  free_load_conservation_1175  2
    service_1_35_14  unique_nonzero_owner_378  1
    service_1_35_14  service_visit_def_1174  1
    service_1_35_14  free_load_conservation_1175  3
    service_1_35_15  unique_nonzero_owner_379  1
    service_1_35_15  service_visit_def_1174  1
    service_1_35_15  free_load_conservation_1175  4
    service_2_35_0  unique_nonzero_owner_365  1
    service_2_35_0  service_visit_def_1545  1
    service_2_35_0  free_load_conservation_1546  -11
    service_2_35_0  original_T_including_depot_unload_1550  1320
    service_2_35_1  unique_nonzero_owner_366  1
    service_2_35_1  service_visit_def_1545  1
    service_2_35_1  free_load_conservation_1546  -10
    service_2_35_1  original_T_including_depot_unload_1550  1200
    service_2_35_2  unique_nonzero_owner_367  1
    service_2_35_2  service_visit_def_1545  1
    service_2_35_2  free_load_conservation_1546  -9
    service_2_35_2  original_T_including_depot_unload_1550  1080
    service_2_35_3  unique_nonzero_owner_368  1
    service_2_35_3  service_visit_def_1545  1
    service_2_35_3  free_load_conservation_1546  -8
    service_2_35_3  original_T_including_depot_unload_1550  960
    service_2_35_4  unique_nonzero_owner_369  1
    service_2_35_4  service_visit_def_1545  1
    service_2_35_4  free_load_conservation_1546  -7
    service_2_35_4  original_T_including_depot_unload_1550  840
    service_2_35_5  unique_nonzero_owner_370  1
    service_2_35_5  service_visit_def_1545  1
    service_2_35_5  free_load_conservation_1546  -6
    service_2_35_5  original_T_including_depot_unload_1550  720
    service_2_35_6  unique_nonzero_owner_371  1
    service_2_35_6  service_visit_def_1545  1
    service_2_35_6  free_load_conservation_1546  -5
    service_2_35_6  original_T_including_depot_unload_1550  600
    service_2_35_7  unique_nonzero_owner_372  1
    service_2_35_7  service_visit_def_1545  1
    service_2_35_7  free_load_conservation_1546  -4
    service_2_35_7  original_T_including_depot_unload_1550  480
    service_2_35_8  unique_nonzero_owner_373  1
    service_2_35_8  service_visit_def_1545  1
    service_2_35_8  free_load_conservation_1546  -3
    service_2_35_8  original_T_including_depot_unload_1550  360
    service_2_35_9  unique_nonzero_owner_374  1
    service_2_35_9  service_visit_def_1545  1
    service_2_35_9  free_load_conservation_1546  -2
    service_2_35_9  original_T_including_depot_unload_1550  240
    service_2_35_10  unique_nonzero_owner_375  1
    service_2_35_10  service_visit_def_1545  1
    service_2_35_10  free_load_conservation_1546  -1
    service_2_35_10  original_T_including_depot_unload_1550  120
    service_2_35_12  unique_nonzero_owner_376  1
    service_2_35_12  service_visit_def_1545  1
    service_2_35_12  free_load_conservation_1546  1
    service_2_35_13  unique_nonzero_owner_377  1
    service_2_35_13  service_visit_def_1545  1
    service_2_35_13  free_load_conservation_1546  2
    service_2_35_14  unique_nonzero_owner_378  1
    service_2_35_14  service_visit_def_1545  1
    service_2_35_14  free_load_conservation_1546  3
    service_2_35_15  unique_nonzero_owner_379  1
    service_2_35_15  service_visit_def_1545  1
    service_2_35_15  free_load_conservation_1546  4
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_721  -1
    visit_0_1  in_degree_722  -1
    visit_0_1  order_active_lb_723  -1
    visit_0_1  order_active_ub_724  -13
    order_0_1  connected_order_arc_396  -1
    order_0_1  connected_order_arc_398  -1
    order_0_1  connected_order_arc_400  -1
    order_0_1  connected_order_arc_402  -1
    order_0_1  connected_order_arc_404  -1
    order_0_1  connected_order_arc_406  -1
    order_0_1  connected_order_arc_408  -1
    order_0_1  connected_order_arc_410  -1
    order_0_1  connected_order_arc_412  -1
    order_0_1  connected_order_arc_414  -1
    order_0_1  connected_order_arc_416  -1
    order_0_1  connected_order_arc_418  -1
    order_0_1  connected_order_arc_421  1
    order_0_1  connected_order_arc_446  1
    order_0_1  connected_order_arc_471  1
    order_0_1  connected_order_arc_496  1
    order_0_1  connected_order_arc_521  1
    order_0_1  connected_order_arc_546  1
    order_0_1  connected_order_arc_571  1
    order_0_1  connected_order_arc_596  1
    order_0_1  connected_order_arc_621  1
    order_0_1  connected_order_arc_646  1
    order_0_1  connected_order_arc_671  1
    order_0_1  connected_order_arc_696  1
    order_0_1  order_active_lb_723  1
    order_0_1  order_active_ub_724  1
    order_0_1  fixed_segment_relative_order_804  -1
    visit_0_2  out_degree_728  -1
    visit_0_2  in_degree_729  -1
    visit_0_2  order_active_lb_730  -1
    visit_0_2  order_active_ub_731  -13
    order_0_2  connected_order_arc_396  1
    order_0_2  connected_order_arc_421  -1
    order_0_2  connected_order_arc_423  -1
    order_0_2  connected_order_arc_425  -1
    order_0_2  connected_order_arc_427  -1
    order_0_2  connected_order_arc_429  -1
    order_0_2  connected_order_arc_431  -1
    order_0_2  connected_order_arc_433  -1
    order_0_2  connected_order_arc_435  -1
    order_0_2  connected_order_arc_437  -1
    order_0_2  connected_order_arc_439  -1
    order_0_2  connected_order_arc_441  -1
    order_0_2  connected_order_arc_443  -1
    order_0_2  connected_order_arc_448  1
    order_0_2  connected_order_arc_473  1
    order_0_2  connected_order_arc_498  1
    order_0_2  connected_order_arc_523  1
    order_0_2  connected_order_arc_548  1
    order_0_2  connected_order_arc_573  1
    order_0_2  connected_order_arc_598  1
    order_0_2  connected_order_arc_623  1
    order_0_2  connected_order_arc_648  1
    order_0_2  connected_order_arc_673  1
    order_0_2  connected_order_arc_698  1
    order_0_2  order_active_lb_730  1
    order_0_2  order_active_ub_731  1
    order_0_2  fixed_segment_relative_order_804  1
    order_0_2  fixed_segment_relative_order_805  -1
    visit_0_3  out_degree_735  -1
    visit_0_3  in_degree_736  -1
    visit_0_3  order_active_lb_737  -1
    visit_0_3  order_active_ub_738  -13
    order_0_3  connected_order_arc_398  1
    order_0_3  connected_order_arc_423  1
    order_0_3  connected_order_arc_446  -1
    order_0_3  connected_order_arc_448  -1
    order_0_3  connected_order_arc_450  -1
    order_0_3  connected_order_arc_452  -1
    order_0_3  connected_order_arc_454  -1
    order_0_3  connected_order_arc_456  -1
    order_0_3  connected_order_arc_458  -1
    order_0_3  connected_order_arc_460  -1
    order_0_3  connected_order_arc_462  -1
    order_0_3  connected_order_arc_464  -1
    order_0_3  connected_order_arc_466  -1
    order_0_3  connected_order_arc_468  -1
    order_0_3  connected_order_arc_475  1
    order_0_3  connected_order_arc_500  1
    order_0_3  connected_order_arc_525  1
    order_0_3  connected_order_arc_550  1
    order_0_3  connected_order_arc_575  1
    order_0_3  connected_order_arc_600  1
    order_0_3  connected_order_arc_625  1
    order_0_3  connected_order_arc_650  1
    order_0_3  connected_order_arc_675  1
    order_0_3  connected_order_arc_700  1
    order_0_3  order_active_lb_737  1
    order_0_3  order_active_ub_738  1
    order_0_3  fixed_segment_relative_order_805  1
    order_0_3  fixed_segment_relative_order_806  -1
    visit_0_4  out_degree_742  -1
    visit_0_4  in_degree_743  -1
    visit_0_4  order_active_lb_744  -1
    visit_0_4  order_active_ub_745  -13
    order_0_4  connected_order_arc_400  1
    order_0_4  connected_order_arc_425  1
    order_0_4  connected_order_arc_450  1
    order_0_4  connected_order_arc_471  -1
    order_0_4  connected_order_arc_473  -1
    order_0_4  connected_order_arc_475  -1
    order_0_4  connected_order_arc_477  -1
    order_0_4  connected_order_arc_479  -1
    order_0_4  connected_order_arc_481  -1
    order_0_4  connected_order_arc_483  -1
    order_0_4  connected_order_arc_485  -1
    order_0_4  connected_order_arc_487  -1
    order_0_4  connected_order_arc_489  -1
    order_0_4  connected_order_arc_491  -1
    order_0_4  connected_order_arc_493  -1
    order_0_4  connected_order_arc_502  1
    order_0_4  connected_order_arc_527  1
    order_0_4  connected_order_arc_552  1
    order_0_4  connected_order_arc_577  1
    order_0_4  connected_order_arc_602  1
    order_0_4  connected_order_arc_627  1
    order_0_4  connected_order_arc_652  1
    order_0_4  connected_order_arc_677  1
    order_0_4  connected_order_arc_702  1
    order_0_4  order_active_lb_744  1
    order_0_4  order_active_ub_745  1
    order_0_4  fixed_segment_relative_order_806  1
    order_0_4  fixed_segment_relative_order_807  -1
    visit_0_5  out_degree_749  -1
    visit_0_5  in_degree_750  -1
    visit_0_5  order_active_lb_751  -1
    visit_0_5  order_active_ub_752  -13
    order_0_5  connected_order_arc_402  1
    order_0_5  connected_order_arc_427  1
    order_0_5  connected_order_arc_452  1
    order_0_5  connected_order_arc_477  1
    order_0_5  connected_order_arc_496  -1
    order_0_5  connected_order_arc_498  -1
    order_0_5  connected_order_arc_500  -1
    order_0_5  connected_order_arc_502  -1
    order_0_5  connected_order_arc_504  -1
    order_0_5  connected_order_arc_506  -1
    order_0_5  connected_order_arc_508  -1
    order_0_5  connected_order_arc_510  -1
    order_0_5  connected_order_arc_512  -1
    order_0_5  connected_order_arc_514  -1
    order_0_5  connected_order_arc_516  -1
    order_0_5  connected_order_arc_518  -1
    order_0_5  connected_order_arc_529  1
    order_0_5  connected_order_arc_554  1
    order_0_5  connected_order_arc_579  1
    order_0_5  connected_order_arc_604  1
    order_0_5  connected_order_arc_629  1
    order_0_5  connected_order_arc_654  1
    order_0_5  connected_order_arc_679  1
    order_0_5  connected_order_arc_704  1
    order_0_5  order_active_lb_751  1
    order_0_5  order_active_ub_752  1
    order_0_5  fixed_segment_relative_order_807  1
    visit_0_14  out_degree_756  -1
    visit_0_14  in_degree_757  -1
    visit_0_14  order_active_lb_758  -1
    visit_0_14  order_active_ub_759  -13
    visit_0_14  service_visit_def_760  -1
    order_0_14  connected_order_arc_404  1
    order_0_14  connected_order_arc_429  1
    order_0_14  connected_order_arc_454  1
    order_0_14  connected_order_arc_479  1
    order_0_14  connected_order_arc_504  1
    order_0_14  connected_order_arc_521  -1
    order_0_14  connected_order_arc_523  -1
    order_0_14  connected_order_arc_525  -1
    order_0_14  connected_order_arc_527  -1
    order_0_14  connected_order_arc_529  -1
    order_0_14  connected_order_arc_531  -1
    order_0_14  connected_order_arc_533  -1
    order_0_14  connected_order_arc_535  -1
    order_0_14  connected_order_arc_537  -1
    order_0_14  connected_order_arc_539  -1
    order_0_14  connected_order_arc_541  -1
    order_0_14  connected_order_arc_543  -1
    order_0_14  connected_order_arc_556  1
    order_0_14  connected_order_arc_581  1
    order_0_14  connected_order_arc_606  1
    order_0_14  connected_order_arc_631  1
    order_0_14  connected_order_arc_656  1
    order_0_14  connected_order_arc_681  1
    order_0_14  connected_order_arc_706  1
    order_0_14  order_active_lb_758  1
    order_0_14  order_active_ub_759  1
    visit_0_15  out_degree_762  -1
    visit_0_15  in_degree_763  -1
    visit_0_15  order_active_lb_764  -1
    visit_0_15  order_active_ub_765  -13
    visit_0_15  service_visit_def_766  -1
    order_0_15  connected_order_arc_406  1
    order_0_15  connected_order_arc_431  1
    order_0_15  connected_order_arc_456  1
    order_0_15  connected_order_arc_481  1
    order_0_15  connected_order_arc_506  1
    order_0_15  connected_order_arc_531  1
    order_0_15  connected_order_arc_546  -1
    order_0_15  connected_order_arc_548  -1
    order_0_15  connected_order_arc_550  -1
    order_0_15  connected_order_arc_552  -1
    order_0_15  connected_order_arc_554  -1
    order_0_15  connected_order_arc_556  -1
    order_0_15  connected_order_arc_558  -1
    order_0_15  connected_order_arc_560  -1
    order_0_15  connected_order_arc_562  -1
    order_0_15  connected_order_arc_564  -1
    order_0_15  connected_order_arc_566  -1
    order_0_15  connected_order_arc_568  -1
    order_0_15  connected_order_arc_583  1
    order_0_15  connected_order_arc_608  1
    order_0_15  connected_order_arc_633  1
    order_0_15  connected_order_arc_658  1
    order_0_15  connected_order_arc_683  1
    order_0_15  connected_order_arc_708  1
    order_0_15  order_active_lb_764  1
    order_0_15  order_active_ub_765  1
    visit_0_16  out_degree_768  -1
    visit_0_16  in_degree_769  -1
    visit_0_16  order_active_lb_770  -1
    visit_0_16  order_active_ub_771  -13
    visit_0_16  service_visit_def_772  -1
    order_0_16  connected_order_arc_408  1
    order_0_16  connected_order_arc_433  1
    order_0_16  connected_order_arc_458  1
    order_0_16  connected_order_arc_483  1
    order_0_16  connected_order_arc_508  1
    order_0_16  connected_order_arc_533  1
    order_0_16  connected_order_arc_558  1
    order_0_16  connected_order_arc_571  -1
    order_0_16  connected_order_arc_573  -1
    order_0_16  connected_order_arc_575  -1
    order_0_16  connected_order_arc_577  -1
    order_0_16  connected_order_arc_579  -1
    order_0_16  connected_order_arc_581  -1
    order_0_16  connected_order_arc_583  -1
    order_0_16  connected_order_arc_585  -1
    order_0_16  connected_order_arc_587  -1
    order_0_16  connected_order_arc_589  -1
    order_0_16  connected_order_arc_591  -1
    order_0_16  connected_order_arc_593  -1
    order_0_16  connected_order_arc_610  1
    order_0_16  connected_order_arc_635  1
    order_0_16  connected_order_arc_660  1
    order_0_16  connected_order_arc_685  1
    order_0_16  connected_order_arc_710  1
    order_0_16  order_active_lb_770  1
    order_0_16  order_active_ub_771  1
    visit_0_17  out_degree_774  -1
    visit_0_17  in_degree_775  -1
    visit_0_17  order_active_lb_776  -1
    visit_0_17  order_active_ub_777  -13
    visit_0_17  service_visit_def_778  -1
    order_0_17  connected_order_arc_410  1
    order_0_17  connected_order_arc_435  1
    order_0_17  connected_order_arc_460  1
    order_0_17  connected_order_arc_485  1
    order_0_17  connected_order_arc_510  1
    order_0_17  connected_order_arc_535  1
    order_0_17  connected_order_arc_560  1
    order_0_17  connected_order_arc_585  1
    order_0_17  connected_order_arc_596  -1
    order_0_17  connected_order_arc_598  -1
    order_0_17  connected_order_arc_600  -1
    order_0_17  connected_order_arc_602  -1
    order_0_17  connected_order_arc_604  -1
    order_0_17  connected_order_arc_606  -1
    order_0_17  connected_order_arc_608  -1
    order_0_17  connected_order_arc_610  -1
    order_0_17  connected_order_arc_612  -1
    order_0_17  connected_order_arc_614  -1
    order_0_17  connected_order_arc_616  -1
    order_0_17  connected_order_arc_618  -1
    order_0_17  connected_order_arc_637  1
    order_0_17  connected_order_arc_662  1
    order_0_17  connected_order_arc_687  1
    order_0_17  connected_order_arc_712  1
    order_0_17  order_active_lb_776  1
    order_0_17  order_active_ub_777  1
    visit_0_18  out_degree_780  -1
    visit_0_18  in_degree_781  -1
    visit_0_18  order_active_lb_782  -1
    visit_0_18  order_active_ub_783  -13
    visit_0_18  service_visit_def_784  -1
    order_0_18  connected_order_arc_412  1
    order_0_18  connected_order_arc_437  1
    order_0_18  connected_order_arc_462  1
    order_0_18  connected_order_arc_487  1
    order_0_18  connected_order_arc_512  1
    order_0_18  connected_order_arc_537  1
    order_0_18  connected_order_arc_562  1
    order_0_18  connected_order_arc_587  1
    order_0_18  connected_order_arc_612  1
    order_0_18  connected_order_arc_621  -1
    order_0_18  connected_order_arc_623  -1
    order_0_18  connected_order_arc_625  -1
    order_0_18  connected_order_arc_627  -1
    order_0_18  connected_order_arc_629  -1
    order_0_18  connected_order_arc_631  -1
    order_0_18  connected_order_arc_633  -1
    order_0_18  connected_order_arc_635  -1
    order_0_18  connected_order_arc_637  -1
    order_0_18  connected_order_arc_639  -1
    order_0_18  connected_order_arc_641  -1
    order_0_18  connected_order_arc_643  -1
    order_0_18  connected_order_arc_664  1
    order_0_18  connected_order_arc_689  1
    order_0_18  connected_order_arc_714  1
    order_0_18  order_active_lb_782  1
    order_0_18  order_active_ub_783  1
    visit_0_19  out_degree_786  -1
    visit_0_19  in_degree_787  -1
    visit_0_19  order_active_lb_788  -1
    visit_0_19  order_active_ub_789  -13
    visit_0_19  service_visit_def_790  -1
    order_0_19  connected_order_arc_414  1
    order_0_19  connected_order_arc_439  1
    order_0_19  connected_order_arc_464  1
    order_0_19  connected_order_arc_489  1
    order_0_19  connected_order_arc_514  1
    order_0_19  connected_order_arc_539  1
    order_0_19  connected_order_arc_564  1
    order_0_19  connected_order_arc_589  1
    order_0_19  connected_order_arc_614  1
    order_0_19  connected_order_arc_639  1
    order_0_19  connected_order_arc_646  -1
    order_0_19  connected_order_arc_648  -1
    order_0_19  connected_order_arc_650  -1
    order_0_19  connected_order_arc_652  -1
    order_0_19  connected_order_arc_654  -1
    order_0_19  connected_order_arc_656  -1
    order_0_19  connected_order_arc_658  -1
    order_0_19  connected_order_arc_660  -1
    order_0_19  connected_order_arc_662  -1
    order_0_19  connected_order_arc_664  -1
    order_0_19  connected_order_arc_666  -1
    order_0_19  connected_order_arc_668  -1
    order_0_19  connected_order_arc_691  1
    order_0_19  connected_order_arc_716  1
    order_0_19  order_active_lb_788  1
    order_0_19  order_active_ub_789  1
    visit_0_20  out_degree_792  -1
    visit_0_20  in_degree_793  -1
    visit_0_20  order_active_lb_794  -1
    visit_0_20  order_active_ub_795  -13
    visit_0_20  service_visit_def_796  -1
    order_0_20  connected_order_arc_416  1
    order_0_20  connected_order_arc_441  1
    order_0_20  connected_order_arc_466  1
    order_0_20  connected_order_arc_491  1
    order_0_20  connected_order_arc_516  1
    order_0_20  connected_order_arc_541  1
    order_0_20  connected_order_arc_566  1
    order_0_20  connected_order_arc_591  1
    order_0_20  connected_order_arc_616  1
    order_0_20  connected_order_arc_641  1
    order_0_20  connected_order_arc_666  1
    order_0_20  connected_order_arc_671  -1
    order_0_20  connected_order_arc_673  -1
    order_0_20  connected_order_arc_675  -1
    order_0_20  connected_order_arc_677  -1
    order_0_20  connected_order_arc_679  -1
    order_0_20  connected_order_arc_681  -1
    order_0_20  connected_order_arc_683  -1
    order_0_20  connected_order_arc_685  -1
    order_0_20  connected_order_arc_687  -1
    order_0_20  connected_order_arc_689  -1
    order_0_20  connected_order_arc_691  -1
    order_0_20  connected_order_arc_693  -1
    order_0_20  connected_order_arc_718  1
    order_0_20  order_active_lb_794  1
    order_0_20  order_active_ub_795  1
    visit_0_21  out_degree_798  -1
    visit_0_21  in_degree_799  -1
    visit_0_21  order_active_lb_800  -1
    visit_0_21  order_active_ub_801  -13
    visit_0_21  service_visit_def_802  -1
    order_0_21  connected_order_arc_418  1
    order_0_21  connected_order_arc_443  1
    order_0_21  connected_order_arc_468  1
    order_0_21  connected_order_arc_493  1
    order_0_21  connected_order_arc_518  1
    order_0_21  connected_order_arc_543  1
    order_0_21  connected_order_arc_568  1
    order_0_21  connected_order_arc_593  1
    order_0_21  connected_order_arc_618  1
    order_0_21  connected_order_arc_643  1
    order_0_21  connected_order_arc_668  1
    order_0_21  connected_order_arc_693  1
    order_0_21  connected_order_arc_696  -1
    order_0_21  connected_order_arc_698  -1
    order_0_21  connected_order_arc_700  -1
    order_0_21  connected_order_arc_702  -1
    order_0_21  connected_order_arc_704  -1
    order_0_21  connected_order_arc_706  -1
    order_0_21  connected_order_arc_708  -1
    order_0_21  connected_order_arc_710  -1
    order_0_21  connected_order_arc_712  -1
    order_0_21  connected_order_arc_714  -1
    order_0_21  connected_order_arc_716  -1
    order_0_21  connected_order_arc_718  -1
    order_0_21  order_active_lb_800  1
    order_0_21  order_active_ub_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_380  -20
    arc_0_0_0  depot_departure_or_bypass_719  1
    arc_0_0_0  depot_return_or_bypass_720  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_380  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_381  -20
    arc_0_0_1  depot_departure_or_bypass_719  1
    arc_0_0_1  in_degree_722  1
    arc_0_0_1  original_T_including_depot_unload_808  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_381  1
    load_0_0_1  segment_load_conservation_725  -1
    load_0_0_1  segment_prefix_lb_726  1
    load_0_0_1  segment_prefix_ub_727  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_382  -20
    arc_0_0_2  depot_departure_or_bypass_719  1
    arc_0_0_2  in_degree_729  1
    arc_0_0_2  original_T_including_depot_unload_808  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_382  1
    load_0_0_2  segment_load_conservation_732  -1
    load_0_0_2  segment_prefix_lb_733  1
    load_0_0_2  segment_prefix_ub_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_383  -20
    arc_0_0_3  depot_departure_or_bypass_719  1
    arc_0_0_3  in_degree_736  1
    arc_0_0_3  original_T_including_depot_unload_808  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_383  1
    load_0_0_3  segment_load_conservation_739  -1
    load_0_0_3  segment_prefix_lb_740  1
    load_0_0_3  segment_prefix_ub_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_384  -20
    arc_0_0_4  depot_departure_or_bypass_719  1
    arc_0_0_4  in_degree_743  1
    arc_0_0_4  original_T_including_depot_unload_808  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_384  1
    load_0_0_4  segment_load_conservation_746  -1
    load_0_0_4  segment_prefix_lb_747  1
    load_0_0_4  segment_prefix_ub_748  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_385  -20
    arc_0_0_5  depot_departure_or_bypass_719  1
    arc_0_0_5  in_degree_750  1
    arc_0_0_5  original_T_including_depot_unload_808  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_385  1
    load_0_0_5  segment_load_conservation_753  -1
    load_0_0_5  segment_prefix_lb_754  1
    load_0_0_5  segment_prefix_ub_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_386  -20
    arc_0_0_14  depot_departure_or_bypass_719  1
    arc_0_0_14  in_degree_757  1
    arc_0_0_14  original_T_including_depot_unload_808  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_386  1
    load_0_0_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_387  -20
    arc_0_0_15  depot_departure_or_bypass_719  1
    arc_0_0_15  in_degree_763  1
    arc_0_0_15  original_T_including_depot_unload_808  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_387  1
    load_0_0_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_388  -20
    arc_0_0_16  depot_departure_or_bypass_719  1
    arc_0_0_16  in_degree_769  1
    arc_0_0_16  original_T_including_depot_unload_808  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_388  1
    load_0_0_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_389  -20
    arc_0_0_17  depot_departure_or_bypass_719  1
    arc_0_0_17  in_degree_775  1
    arc_0_0_17  original_T_including_depot_unload_808  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_389  1
    load_0_0_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_390  -20
    arc_0_0_18  depot_departure_or_bypass_719  1
    arc_0_0_18  in_degree_781  1
    arc_0_0_18  original_T_including_depot_unload_808  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_390  1
    load_0_0_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_391  -20
    arc_0_0_19  depot_departure_or_bypass_719  1
    arc_0_0_19  in_degree_787  1
    arc_0_0_19  original_T_including_depot_unload_808  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_391  1
    load_0_0_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_392  -20
    arc_0_0_20  depot_departure_or_bypass_719  1
    arc_0_0_20  in_degree_793  1
    arc_0_0_20  original_T_including_depot_unload_808  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_392  1
    load_0_0_20  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_393  -20
    arc_0_0_21  depot_departure_or_bypass_719  1
    arc_0_0_21  in_degree_799  1
    arc_0_0_21  original_T_including_depot_unload_808  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_393  1
    load_0_0_21  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_394  -20
    arc_0_1_0  depot_return_or_bypass_720  1
    arc_0_1_0  out_degree_721  1
    arc_0_1_0  original_T_including_depot_unload_808  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_394  1
    load_0_1_0  segment_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_395  -20
    arc_0_1_2  connected_order_arc_396  -14
    arc_0_1_2  out_degree_721  1
    arc_0_1_2  in_degree_729  1
    arc_0_1_2  original_T_including_depot_unload_808  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_395  1
    load_0_1_2  segment_load_conservation_725  1
    load_0_1_2  segment_load_conservation_732  -1
    load_0_1_2  segment_prefix_lb_733  1
    load_0_1_2  segment_prefix_ub_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_397  -20
    arc_0_1_3  connected_order_arc_398  -14
    arc_0_1_3  out_degree_721  1
    arc_0_1_3  in_degree_736  1
    arc_0_1_3  original_T_including_depot_unload_808  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_397  1
    load_0_1_3  segment_load_conservation_725  1
    load_0_1_3  segment_load_conservation_739  -1
    load_0_1_3  segment_prefix_lb_740  1
    load_0_1_3  segment_prefix_ub_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_399  -20
    arc_0_1_4  connected_order_arc_400  -14
    arc_0_1_4  out_degree_721  1
    arc_0_1_4  in_degree_743  1
    arc_0_1_4  original_T_including_depot_unload_808  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_399  1
    load_0_1_4  segment_load_conservation_725  1
    load_0_1_4  segment_load_conservation_746  -1
    load_0_1_4  segment_prefix_lb_747  1
    load_0_1_4  segment_prefix_ub_748  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_401  -20
    arc_0_1_5  connected_order_arc_402  -14
    arc_0_1_5  out_degree_721  1
    arc_0_1_5  in_degree_750  1
    arc_0_1_5  original_T_including_depot_unload_808  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_401  1
    load_0_1_5  segment_load_conservation_725  1
    load_0_1_5  segment_load_conservation_753  -1
    load_0_1_5  segment_prefix_lb_754  1
    load_0_1_5  segment_prefix_ub_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_403  -20
    arc_0_1_14  connected_order_arc_404  -14
    arc_0_1_14  out_degree_721  1
    arc_0_1_14  in_degree_757  1
    arc_0_1_14  original_T_including_depot_unload_808  1.5552905028977075e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_403  1
    load_0_1_14  segment_load_conservation_725  1
    load_0_1_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_405  -20
    arc_0_1_15  connected_order_arc_406  -14
    arc_0_1_15  out_degree_721  1
    arc_0_1_15  in_degree_763  1
    arc_0_1_15  original_T_including_depot_unload_808  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_405  1
    load_0_1_15  segment_load_conservation_725  1
    load_0_1_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_407  -20
    arc_0_1_16  connected_order_arc_408  -14
    arc_0_1_16  out_degree_721  1
    arc_0_1_16  in_degree_769  1
    arc_0_1_16  original_T_including_depot_unload_808  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_407  1
    load_0_1_16  segment_load_conservation_725  1
    load_0_1_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_409  -20
    arc_0_1_17  connected_order_arc_410  -14
    arc_0_1_17  out_degree_721  1
    arc_0_1_17  in_degree_775  1
    arc_0_1_17  original_T_including_depot_unload_808  1.7022035239152008e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_409  1
    load_0_1_17  segment_load_conservation_725  1
    load_0_1_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_411  -20
    arc_0_1_18  connected_order_arc_412  -14
    arc_0_1_18  out_degree_721  1
    arc_0_1_18  in_degree_781  1
    arc_0_1_18  original_T_including_depot_unload_808  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_411  1
    load_0_1_18  segment_load_conservation_725  1
    load_0_1_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_413  -20
    arc_0_1_19  connected_order_arc_414  -14
    arc_0_1_19  out_degree_721  1
    arc_0_1_19  in_degree_787  1
    arc_0_1_19  original_T_including_depot_unload_808  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_413  1
    load_0_1_19  segment_load_conservation_725  1
    load_0_1_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_415  -20
    arc_0_1_20  connected_order_arc_416  -14
    arc_0_1_20  out_degree_721  1
    arc_0_1_20  in_degree_793  1
    arc_0_1_20  original_T_including_depot_unload_808  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_415  1
    load_0_1_20  segment_load_conservation_725  1
    load_0_1_20  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_417  -20
    arc_0_1_21  connected_order_arc_418  -14
    arc_0_1_21  out_degree_721  1
    arc_0_1_21  in_degree_799  1
    arc_0_1_21  original_T_including_depot_unload_808  1.8805180645589260e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_417  1
    load_0_1_21  segment_load_conservation_725  1
    load_0_1_21  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_419  -20
    arc_0_2_0  depot_return_or_bypass_720  1
    arc_0_2_0  out_degree_728  1
    arc_0_2_0  original_T_including_depot_unload_808  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_419  1
    load_0_2_0  segment_load_conservation_732  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_420  -20
    arc_0_2_1  connected_order_arc_421  -14
    arc_0_2_1  in_degree_722  1
    arc_0_2_1  out_degree_728  1
    arc_0_2_1  original_T_including_depot_unload_808  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_420  1
    load_0_2_1  segment_load_conservation_725  -1
    load_0_2_1  segment_prefix_lb_726  1
    load_0_2_1  segment_prefix_ub_727  1
    load_0_2_1  segment_load_conservation_732  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_422  -20
    arc_0_2_3  connected_order_arc_423  -14
    arc_0_2_3  out_degree_728  1
    arc_0_2_3  in_degree_736  1
    arc_0_2_3  original_T_including_depot_unload_808  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_422  1
    load_0_2_3  segment_load_conservation_732  1
    load_0_2_3  segment_load_conservation_739  -1
    load_0_2_3  segment_prefix_lb_740  1
    load_0_2_3  segment_prefix_ub_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_424  -20
    arc_0_2_4  connected_order_arc_425  -14
    arc_0_2_4  out_degree_728  1
    arc_0_2_4  in_degree_743  1
    arc_0_2_4  original_T_including_depot_unload_808  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_424  1
    load_0_2_4  segment_load_conservation_732  1
    load_0_2_4  segment_load_conservation_746  -1
    load_0_2_4  segment_prefix_lb_747  1
    load_0_2_4  segment_prefix_ub_748  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_426  -20
    arc_0_2_5  connected_order_arc_427  -14
    arc_0_2_5  out_degree_728  1
    arc_0_2_5  in_degree_750  1
    arc_0_2_5  original_T_including_depot_unload_808  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_426  1
    load_0_2_5  segment_load_conservation_732  1
    load_0_2_5  segment_load_conservation_753  -1
    load_0_2_5  segment_prefix_lb_754  1
    load_0_2_5  segment_prefix_ub_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_428  -20
    arc_0_2_14  connected_order_arc_429  -14
    arc_0_2_14  out_degree_728  1
    arc_0_2_14  in_degree_757  1
    arc_0_2_14  original_T_including_depot_unload_808  1.3812305438169078e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_428  1
    load_0_2_14  segment_load_conservation_732  1
    load_0_2_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_430  -20
    arc_0_2_15  connected_order_arc_431  -14
    arc_0_2_15  out_degree_728  1
    arc_0_2_15  in_degree_763  1
    arc_0_2_15  original_T_including_depot_unload_808  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_430  1
    load_0_2_15  segment_load_conservation_732  1
    load_0_2_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_432  -20
    arc_0_2_16  connected_order_arc_433  -14
    arc_0_2_16  out_degree_728  1
    arc_0_2_16  in_degree_769  1
    arc_0_2_16  original_T_including_depot_unload_808  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_432  1
    load_0_2_16  segment_load_conservation_732  1
    load_0_2_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_434  -20
    arc_0_2_17  connected_order_arc_435  -14
    arc_0_2_17  out_degree_728  1
    arc_0_2_17  in_degree_775  1
    arc_0_2_17  original_T_including_depot_unload_808  1.5362659379368008e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_434  1
    load_0_2_17  segment_load_conservation_732  1
    load_0_2_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_436  -20
    arc_0_2_18  connected_order_arc_437  -14
    arc_0_2_18  out_degree_728  1
    arc_0_2_18  in_degree_781  1
    arc_0_2_18  original_T_including_depot_unload_808  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_436  1
    load_0_2_18  segment_load_conservation_732  1
    load_0_2_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_438  -20
    arc_0_2_19  connected_order_arc_439  -14
    arc_0_2_19  out_degree_728  1
    arc_0_2_19  in_degree_787  1
    arc_0_2_19  original_T_including_depot_unload_808  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_438  1
    load_0_2_19  segment_load_conservation_732  1
    load_0_2_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_440  -20
    arc_0_2_20  connected_order_arc_441  -14
    arc_0_2_20  out_degree_728  1
    arc_0_2_20  in_degree_793  1
    arc_0_2_20  original_T_including_depot_unload_808  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_440  1
    load_0_2_20  segment_load_conservation_732  1
    load_0_2_20  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_442  -20
    arc_0_2_21  connected_order_arc_443  -14
    arc_0_2_21  out_degree_728  1
    arc_0_2_21  in_degree_799  1
    arc_0_2_21  original_T_including_depot_unload_808  1.7155529120526971e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_442  1
    load_0_2_21  segment_load_conservation_732  1
    load_0_2_21  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_444  -20
    arc_0_3_0  depot_return_or_bypass_720  1
    arc_0_3_0  out_degree_735  1
    arc_0_3_0  original_T_including_depot_unload_808  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_444  1
    load_0_3_0  segment_load_conservation_739  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_445  -20
    arc_0_3_1  connected_order_arc_446  -14
    arc_0_3_1  in_degree_722  1
    arc_0_3_1  out_degree_735  1
    arc_0_3_1  original_T_including_depot_unload_808  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_445  1
    load_0_3_1  segment_load_conservation_725  -1
    load_0_3_1  segment_prefix_lb_726  1
    load_0_3_1  segment_prefix_ub_727  1
    load_0_3_1  segment_load_conservation_739  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_447  -20
    arc_0_3_2  connected_order_arc_448  -14
    arc_0_3_2  in_degree_729  1
    arc_0_3_2  out_degree_735  1
    arc_0_3_2  original_T_including_depot_unload_808  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_447  1
    load_0_3_2  segment_load_conservation_732  -1
    load_0_3_2  segment_prefix_lb_733  1
    load_0_3_2  segment_prefix_ub_734  1
    load_0_3_2  segment_load_conservation_739  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_449  -20
    arc_0_3_4  connected_order_arc_450  -14
    arc_0_3_4  out_degree_735  1
    arc_0_3_4  in_degree_743  1
    arc_0_3_4  original_T_including_depot_unload_808  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_449  1
    load_0_3_4  segment_load_conservation_739  1
    load_0_3_4  segment_load_conservation_746  -1
    load_0_3_4  segment_prefix_lb_747  1
    load_0_3_4  segment_prefix_ub_748  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_451  -20
    arc_0_3_5  connected_order_arc_452  -14
    arc_0_3_5  out_degree_735  1
    arc_0_3_5  in_degree_750  1
    arc_0_3_5  original_T_including_depot_unload_808  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_451  1
    load_0_3_5  segment_load_conservation_739  1
    load_0_3_5  segment_load_conservation_753  -1
    load_0_3_5  segment_prefix_lb_754  1
    load_0_3_5  segment_prefix_ub_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_453  -20
    arc_0_3_14  connected_order_arc_454  -14
    arc_0_3_14  out_degree_735  1
    arc_0_3_14  in_degree_757  1
    arc_0_3_14  original_T_including_depot_unload_808  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_453  1
    load_0_3_14  segment_load_conservation_739  1
    load_0_3_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_455  -20
    arc_0_3_15  connected_order_arc_456  -14
    arc_0_3_15  out_degree_735  1
    arc_0_3_15  in_degree_763  1
    arc_0_3_15  original_T_including_depot_unload_808  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_455  1
    load_0_3_15  segment_load_conservation_739  1
    load_0_3_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_457  -20
    arc_0_3_16  connected_order_arc_458  -14
    arc_0_3_16  out_degree_735  1
    arc_0_3_16  in_degree_769  1
    arc_0_3_16  original_T_including_depot_unload_808  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_457  1
    load_0_3_16  segment_load_conservation_739  1
    load_0_3_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_459  -20
    arc_0_3_17  connected_order_arc_460  -14
    arc_0_3_17  out_degree_735  1
    arc_0_3_17  in_degree_775  1
    arc_0_3_17  original_T_including_depot_unload_808  1.6185675384860760e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_459  1
    load_0_3_17  segment_load_conservation_739  1
    load_0_3_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_461  -20
    arc_0_3_18  connected_order_arc_462  -14
    arc_0_3_18  out_degree_735  1
    arc_0_3_18  in_degree_781  1
    arc_0_3_18  original_T_including_depot_unload_808  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_461  1
    load_0_3_18  segment_load_conservation_739  1
    load_0_3_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_463  -20
    arc_0_3_19  connected_order_arc_464  -14
    arc_0_3_19  out_degree_735  1
    arc_0_3_19  in_degree_787  1
    arc_0_3_19  original_T_including_depot_unload_808  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_463  1
    load_0_3_19  segment_load_conservation_739  1
    load_0_3_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_465  -20
    arc_0_3_20  connected_order_arc_466  -14
    arc_0_3_20  out_degree_735  1
    arc_0_3_20  in_degree_793  1
    arc_0_3_20  original_T_including_depot_unload_808  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_465  1
    load_0_3_20  segment_load_conservation_739  1
    load_0_3_20  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_467  -20
    arc_0_3_21  connected_order_arc_468  -14
    arc_0_3_21  out_degree_735  1
    arc_0_3_21  in_degree_799  1
    arc_0_3_21  original_T_including_depot_unload_808  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_467  1
    load_0_3_21  segment_load_conservation_739  1
    load_0_3_21  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_469  -20
    arc_0_4_0  depot_return_or_bypass_720  1
    arc_0_4_0  out_degree_742  1
    arc_0_4_0  original_T_including_depot_unload_808  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_469  1
    load_0_4_0  segment_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_470  -20
    arc_0_4_1  connected_order_arc_471  -14
    arc_0_4_1  in_degree_722  1
    arc_0_4_1  out_degree_742  1
    arc_0_4_1  original_T_including_depot_unload_808  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_470  1
    load_0_4_1  segment_load_conservation_725  -1
    load_0_4_1  segment_prefix_lb_726  1
    load_0_4_1  segment_prefix_ub_727  1
    load_0_4_1  segment_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_472  -20
    arc_0_4_2  connected_order_arc_473  -14
    arc_0_4_2  in_degree_729  1
    arc_0_4_2  out_degree_742  1
    arc_0_4_2  original_T_including_depot_unload_808  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_472  1
    load_0_4_2  segment_load_conservation_732  -1
    load_0_4_2  segment_prefix_lb_733  1
    load_0_4_2  segment_prefix_ub_734  1
    load_0_4_2  segment_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_474  -20
    arc_0_4_3  connected_order_arc_475  -14
    arc_0_4_3  in_degree_736  1
    arc_0_4_3  out_degree_742  1
    arc_0_4_3  original_T_including_depot_unload_808  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_474  1
    load_0_4_3  segment_load_conservation_739  -1
    load_0_4_3  segment_prefix_lb_740  1
    load_0_4_3  segment_prefix_ub_741  1
    load_0_4_3  segment_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_476  -20
    arc_0_4_5  connected_order_arc_477  -14
    arc_0_4_5  out_degree_742  1
    arc_0_4_5  in_degree_750  1
    arc_0_4_5  original_T_including_depot_unload_808  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_476  1
    load_0_4_5  segment_load_conservation_746  1
    load_0_4_5  segment_load_conservation_753  -1
    load_0_4_5  segment_prefix_lb_754  1
    load_0_4_5  segment_prefix_ub_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_478  -20
    arc_0_4_14  connected_order_arc_479  -14
    arc_0_4_14  out_degree_742  1
    arc_0_4_14  in_degree_757  1
    arc_0_4_14  original_T_including_depot_unload_808  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_478  1
    load_0_4_14  segment_load_conservation_746  1
    load_0_4_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_480  -20
    arc_0_4_15  connected_order_arc_481  -14
    arc_0_4_15  out_degree_742  1
    arc_0_4_15  in_degree_763  1
    arc_0_4_15  original_T_including_depot_unload_808  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_480  1
    load_0_4_15  segment_load_conservation_746  1
    load_0_4_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_482  -20
    arc_0_4_16  connected_order_arc_483  -14
    arc_0_4_16  out_degree_742  1
    arc_0_4_16  in_degree_769  1
    arc_0_4_16  original_T_including_depot_unload_808  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_482  1
    load_0_4_16  segment_load_conservation_746  1
    load_0_4_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_484  -20
    arc_0_4_17  connected_order_arc_485  -14
    arc_0_4_17  out_degree_742  1
    arc_0_4_17  in_degree_775  1
    arc_0_4_17  original_T_including_depot_unload_808  7.9829177317292124e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_484  1
    load_0_4_17  segment_load_conservation_746  1
    load_0_4_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_486  -20
    arc_0_4_18  connected_order_arc_487  -14
    arc_0_4_18  out_degree_742  1
    arc_0_4_18  in_degree_781  1
    arc_0_4_18  original_T_including_depot_unload_808  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_486  1
    load_0_4_18  segment_load_conservation_746  1
    load_0_4_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_488  -20
    arc_0_4_19  connected_order_arc_489  -14
    arc_0_4_19  out_degree_742  1
    arc_0_4_19  in_degree_787  1
    arc_0_4_19  original_T_including_depot_unload_808  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_488  1
    load_0_4_19  segment_load_conservation_746  1
    load_0_4_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_490  -20
    arc_0_4_20  connected_order_arc_491  -14
    arc_0_4_20  out_degree_742  1
    arc_0_4_20  in_degree_793  1
    arc_0_4_20  original_T_including_depot_unload_808  7.9613989083692911e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_490  1
    load_0_4_20  segment_load_conservation_746  1
    load_0_4_20  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_492  -20
    arc_0_4_21  connected_order_arc_493  -14
    arc_0_4_21  out_degree_742  1
    arc_0_4_21  in_degree_799  1
    arc_0_4_21  original_T_including_depot_unload_808  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_492  1
    load_0_4_21  segment_load_conservation_746  1
    load_0_4_21  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_494  -20
    arc_0_5_0  depot_return_or_bypass_720  1
    arc_0_5_0  out_degree_749  1
    arc_0_5_0  original_T_including_depot_unload_808  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_494  1
    load_0_5_0  segment_load_conservation_753  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_495  -20
    arc_0_5_1  connected_order_arc_496  -14
    arc_0_5_1  in_degree_722  1
    arc_0_5_1  out_degree_749  1
    arc_0_5_1  original_T_including_depot_unload_808  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_495  1
    load_0_5_1  segment_load_conservation_725  -1
    load_0_5_1  segment_prefix_lb_726  1
    load_0_5_1  segment_prefix_ub_727  1
    load_0_5_1  segment_load_conservation_753  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_497  -20
    arc_0_5_2  connected_order_arc_498  -14
    arc_0_5_2  in_degree_729  1
    arc_0_5_2  out_degree_749  1
    arc_0_5_2  original_T_including_depot_unload_808  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_497  1
    load_0_5_2  segment_load_conservation_732  -1
    load_0_5_2  segment_prefix_lb_733  1
    load_0_5_2  segment_prefix_ub_734  1
    load_0_5_2  segment_load_conservation_753  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_499  -20
    arc_0_5_3  connected_order_arc_500  -14
    arc_0_5_3  in_degree_736  1
    arc_0_5_3  out_degree_749  1
    arc_0_5_3  original_T_including_depot_unload_808  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_499  1
    load_0_5_3  segment_load_conservation_739  -1
    load_0_5_3  segment_prefix_lb_740  1
    load_0_5_3  segment_prefix_ub_741  1
    load_0_5_3  segment_load_conservation_753  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_501  -20
    arc_0_5_4  connected_order_arc_502  -14
    arc_0_5_4  in_degree_743  1
    arc_0_5_4  out_degree_749  1
    arc_0_5_4  original_T_including_depot_unload_808  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_501  1
    load_0_5_4  segment_load_conservation_746  -1
    load_0_5_4  segment_prefix_lb_747  1
    load_0_5_4  segment_prefix_ub_748  1
    load_0_5_4  segment_load_conservation_753  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_503  -20
    arc_0_5_14  connected_order_arc_504  -14
    arc_0_5_14  out_degree_749  1
    arc_0_5_14  in_degree_757  1
    arc_0_5_14  original_T_including_depot_unload_808  7.8724938919046190e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_503  1
    load_0_5_14  segment_load_conservation_753  1
    load_0_5_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_505  -20
    arc_0_5_15  connected_order_arc_506  -14
    arc_0_5_15  out_degree_749  1
    arc_0_5_15  in_degree_763  1
    arc_0_5_15  original_T_including_depot_unload_808  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_505  1
    load_0_5_15  segment_load_conservation_753  1
    load_0_5_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_507  -20
    arc_0_5_16  connected_order_arc_508  -14
    arc_0_5_16  out_degree_749  1
    arc_0_5_16  in_degree_769  1
    arc_0_5_16  original_T_including_depot_unload_808  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_507  1
    load_0_5_16  segment_load_conservation_753  1
    load_0_5_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_509  -20
    arc_0_5_17  connected_order_arc_510  -14
    arc_0_5_17  out_degree_749  1
    arc_0_5_17  in_degree_775  1
    arc_0_5_17  original_T_including_depot_unload_808  8.6622936529310709e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_509  1
    load_0_5_17  segment_load_conservation_753  1
    load_0_5_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_511  -20
    arc_0_5_18  connected_order_arc_512  -14
    arc_0_5_18  out_degree_749  1
    arc_0_5_18  in_degree_781  1
    arc_0_5_18  original_T_including_depot_unload_808  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_511  1
    load_0_5_18  segment_load_conservation_753  1
    load_0_5_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_513  -20
    arc_0_5_19  connected_order_arc_514  -14
    arc_0_5_19  out_degree_749  1
    arc_0_5_19  in_degree_787  1
    arc_0_5_19  original_T_including_depot_unload_808  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_513  1
    load_0_5_19  segment_load_conservation_753  1
    load_0_5_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_515  -20
    arc_0_5_20  connected_order_arc_516  -14
    arc_0_5_20  out_degree_749  1
    arc_0_5_20  in_degree_793  1
    arc_0_5_20  original_T_including_depot_unload_808  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_515  1
    load_0_5_20  segment_load_conservation_753  1
    load_0_5_20  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_517  -20
    arc_0_5_21  connected_order_arc_518  -14
    arc_0_5_21  out_degree_749  1
    arc_0_5_21  in_degree_799  1
    arc_0_5_21  original_T_including_depot_unload_808  1.0428195034234207e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_517  1
    load_0_5_21  segment_load_conservation_753  1
    load_0_5_21  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_519  -20
    arc_0_14_0  depot_return_or_bypass_720  1
    arc_0_14_0  out_degree_756  1
    arc_0_14_0  original_T_including_depot_unload_808  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_519  1
    load_0_14_0  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_520  -20
    arc_0_14_1  connected_order_arc_521  -14
    arc_0_14_1  in_degree_722  1
    arc_0_14_1  out_degree_756  1
    arc_0_14_1  original_T_including_depot_unload_808  1.4479451378803963e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_520  1
    load_0_14_1  segment_load_conservation_725  -1
    load_0_14_1  segment_prefix_lb_726  1
    load_0_14_1  segment_prefix_ub_727  1
    load_0_14_1  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_522  -20
    arc_0_14_2  connected_order_arc_523  -14
    arc_0_14_2  in_degree_729  1
    arc_0_14_2  out_degree_756  1
    arc_0_14_2  original_T_including_depot_unload_808  1.3812305438169078e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_522  1
    load_0_14_2  segment_load_conservation_732  -1
    load_0_14_2  segment_prefix_lb_733  1
    load_0_14_2  segment_prefix_ub_734  1
    load_0_14_2  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_524  -20
    arc_0_14_3  connected_order_arc_525  -14
    arc_0_14_3  in_degree_736  1
    arc_0_14_3  out_degree_756  1
    arc_0_14_3  original_T_including_depot_unload_808  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_524  1
    load_0_14_3  segment_load_conservation_739  -1
    load_0_14_3  segment_prefix_lb_740  1
    load_0_14_3  segment_prefix_ub_741  1
    load_0_14_3  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_526  -20
    arc_0_14_4  connected_order_arc_527  -14
    arc_0_14_4  in_degree_743  1
    arc_0_14_4  out_degree_756  1
    arc_0_14_4  original_T_including_depot_unload_808  1.0917254946216958e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_526  1
    load_0_14_4  segment_load_conservation_746  -1
    load_0_14_4  segment_prefix_lb_747  1
    load_0_14_4  segment_prefix_ub_748  1
    load_0_14_4  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_528  -20
    arc_0_14_5  connected_order_arc_529  -14
    arc_0_14_5  in_degree_750  1
    arc_0_14_5  out_degree_756  1
    arc_0_14_5  original_T_including_depot_unload_808  7.8724938919046190e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_528  1
    load_0_14_5  segment_load_conservation_753  -1
    load_0_14_5  segment_prefix_lb_754  1
    load_0_14_5  segment_prefix_ub_755  1
    load_0_14_5  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_530  -20
    arc_0_14_15  connected_order_arc_531  -14
    arc_0_14_15  out_degree_756  1
    arc_0_14_15  in_degree_763  1
    arc_0_14_15  original_T_including_depot_unload_808  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_530  1
    load_0_14_15  free_load_conservation_761  1
    load_0_14_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_532  -20
    arc_0_14_16  connected_order_arc_533  -14
    arc_0_14_16  out_degree_756  1
    arc_0_14_16  in_degree_769  1
    arc_0_14_16  original_T_including_depot_unload_808  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_532  1
    load_0_14_16  free_load_conservation_761  1
    load_0_14_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_534  -20
    arc_0_14_17  connected_order_arc_535  -14
    arc_0_14_17  out_degree_756  1
    arc_0_14_17  in_degree_775  1
    arc_0_14_17  original_T_including_depot_unload_808  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_534  1
    load_0_14_17  free_load_conservation_761  1
    load_0_14_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_536  -20
    arc_0_14_18  connected_order_arc_537  -14
    arc_0_14_18  out_degree_756  1
    arc_0_14_18  in_degree_781  1
    arc_0_14_18  original_T_including_depot_unload_808  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_536  1
    load_0_14_18  free_load_conservation_761  1
    load_0_14_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_538  -20
    arc_0_14_19  connected_order_arc_539  -14
    arc_0_14_19  out_degree_756  1
    arc_0_14_19  in_degree_787  1
    arc_0_14_19  original_T_including_depot_unload_808  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_538  1
    load_0_14_19  free_load_conservation_761  1
    load_0_14_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_540  -20
    arc_0_14_20  connected_order_arc_541  -14
    arc_0_14_20  out_degree_756  1
    arc_0_14_20  in_degree_793  1
    arc_0_14_20  original_T_including_depot_unload_808  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_540  1
    load_0_14_20  free_load_conservation_761  1
    load_0_14_20  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_21  arc_capacity_542  -20
    arc_0_14_21  connected_order_arc_543  -14
    arc_0_14_21  out_degree_756  1
    arc_0_14_21  in_degree_799  1
    arc_0_14_21  original_T_including_depot_unload_808  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_21  arc_capacity_542  1
    load_0_14_21  free_load_conservation_761  1
    load_0_14_21  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_544  -20
    arc_0_15_0  depot_return_or_bypass_720  1
    arc_0_15_0  out_degree_762  1
    arc_0_15_0  original_T_including_depot_unload_808  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_544  1
    load_0_15_0  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_545  -20
    arc_0_15_1  connected_order_arc_546  -14
    arc_0_15_1  in_degree_722  1
    arc_0_15_1  out_degree_762  1
    arc_0_15_1  original_T_including_depot_unload_808  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_545  1
    load_0_15_1  segment_load_conservation_725  -1
    load_0_15_1  segment_prefix_lb_726  1
    load_0_15_1  segment_prefix_ub_727  1
    load_0_15_1  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_547  -20
    arc_0_15_2  connected_order_arc_548  -14
    arc_0_15_2  in_degree_729  1
    arc_0_15_2  out_degree_762  1
    arc_0_15_2  original_T_including_depot_unload_808  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_547  1
    load_0_15_2  segment_load_conservation_732  -1
    load_0_15_2  segment_prefix_lb_733  1
    load_0_15_2  segment_prefix_ub_734  1
    load_0_15_2  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_549  -20
    arc_0_15_3  connected_order_arc_550  -14
    arc_0_15_3  in_degree_736  1
    arc_0_15_3  out_degree_762  1
    arc_0_15_3  original_T_including_depot_unload_808  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_549  1
    load_0_15_3  segment_load_conservation_739  -1
    load_0_15_3  segment_prefix_lb_740  1
    load_0_15_3  segment_prefix_ub_741  1
    load_0_15_3  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_551  -20
    arc_0_15_4  connected_order_arc_552  -14
    arc_0_15_4  in_degree_743  1
    arc_0_15_4  out_degree_762  1
    arc_0_15_4  original_T_including_depot_unload_808  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_551  1
    load_0_15_4  segment_load_conservation_746  -1
    load_0_15_4  segment_prefix_lb_747  1
    load_0_15_4  segment_prefix_ub_748  1
    load_0_15_4  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_553  -20
    arc_0_15_5  connected_order_arc_554  -14
    arc_0_15_5  in_degree_750  1
    arc_0_15_5  out_degree_762  1
    arc_0_15_5  original_T_including_depot_unload_808  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_553  1
    load_0_15_5  segment_load_conservation_753  -1
    load_0_15_5  segment_prefix_lb_754  1
    load_0_15_5  segment_prefix_ub_755  1
    load_0_15_5  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_555  -20
    arc_0_15_14  connected_order_arc_556  -14
    arc_0_15_14  in_degree_757  1
    arc_0_15_14  out_degree_762  1
    arc_0_15_14  original_T_including_depot_unload_808  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_555  1
    load_0_15_14  free_load_conservation_761  -1
    load_0_15_14  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_557  -20
    arc_0_15_16  connected_order_arc_558  -14
    arc_0_15_16  out_degree_762  1
    arc_0_15_16  in_degree_769  1
    arc_0_15_16  original_T_including_depot_unload_808  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_557  1
    load_0_15_16  free_load_conservation_767  1
    load_0_15_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_559  -20
    arc_0_15_17  connected_order_arc_560  -14
    arc_0_15_17  out_degree_762  1
    arc_0_15_17  in_degree_775  1
    arc_0_15_17  original_T_including_depot_unload_808  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_559  1
    load_0_15_17  free_load_conservation_767  1
    load_0_15_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_561  -20
    arc_0_15_18  connected_order_arc_562  -14
    arc_0_15_18  out_degree_762  1
    arc_0_15_18  in_degree_781  1
    arc_0_15_18  original_T_including_depot_unload_808  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_561  1
    load_0_15_18  free_load_conservation_767  1
    load_0_15_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_563  -20
    arc_0_15_19  connected_order_arc_564  -14
    arc_0_15_19  out_degree_762  1
    arc_0_15_19  in_degree_787  1
    arc_0_15_19  original_T_including_depot_unload_808  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_563  1
    load_0_15_19  free_load_conservation_767  1
    load_0_15_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_565  -20
    arc_0_15_20  connected_order_arc_566  -14
    arc_0_15_20  out_degree_762  1
    arc_0_15_20  in_degree_793  1
    arc_0_15_20  original_T_including_depot_unload_808  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_565  1
    load_0_15_20  free_load_conservation_767  1
    load_0_15_20  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_567  -20
    arc_0_15_21  connected_order_arc_568  -14
    arc_0_15_21  out_degree_762  1
    arc_0_15_21  in_degree_799  1
    arc_0_15_21  original_T_including_depot_unload_808  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_567  1
    load_0_15_21  free_load_conservation_767  1
    load_0_15_21  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_569  -20
    arc_0_16_0  depot_return_or_bypass_720  1
    arc_0_16_0  out_degree_768  1
    arc_0_16_0  original_T_including_depot_unload_808  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_569  1
    load_0_16_0  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_570  -20
    arc_0_16_1  connected_order_arc_571  -14
    arc_0_16_1  in_degree_722  1
    arc_0_16_1  out_degree_768  1
    arc_0_16_1  original_T_including_depot_unload_808  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_570  1
    load_0_16_1  segment_load_conservation_725  -1
    load_0_16_1  segment_prefix_lb_726  1
    load_0_16_1  segment_prefix_ub_727  1
    load_0_16_1  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_572  -20
    arc_0_16_2  connected_order_arc_573  -14
    arc_0_16_2  in_degree_729  1
    arc_0_16_2  out_degree_768  1
    arc_0_16_2  original_T_including_depot_unload_808  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_572  1
    load_0_16_2  segment_load_conservation_732  -1
    load_0_16_2  segment_prefix_lb_733  1
    load_0_16_2  segment_prefix_ub_734  1
    load_0_16_2  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_574  -20
    arc_0_16_3  connected_order_arc_575  -14
    arc_0_16_3  in_degree_736  1
    arc_0_16_3  out_degree_768  1
    arc_0_16_3  original_T_including_depot_unload_808  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_574  1
    load_0_16_3  segment_load_conservation_739  -1
    load_0_16_3  segment_prefix_lb_740  1
    load_0_16_3  segment_prefix_ub_741  1
    load_0_16_3  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_576  -20
    arc_0_16_4  connected_order_arc_577  -14
    arc_0_16_4  in_degree_743  1
    arc_0_16_4  out_degree_768  1
    arc_0_16_4  original_T_including_depot_unload_808  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_576  1
    load_0_16_4  segment_load_conservation_746  -1
    load_0_16_4  segment_prefix_lb_747  1
    load_0_16_4  segment_prefix_ub_748  1
    load_0_16_4  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_578  -20
    arc_0_16_5  connected_order_arc_579  -14
    arc_0_16_5  in_degree_750  1
    arc_0_16_5  out_degree_768  1
    arc_0_16_5  original_T_including_depot_unload_808  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_578  1
    load_0_16_5  segment_load_conservation_753  -1
    load_0_16_5  segment_prefix_lb_754  1
    load_0_16_5  segment_prefix_ub_755  1
    load_0_16_5  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_580  -20
    arc_0_16_14  connected_order_arc_581  -14
    arc_0_16_14  in_degree_757  1
    arc_0_16_14  out_degree_768  1
    arc_0_16_14  original_T_including_depot_unload_808  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_580  1
    load_0_16_14  free_load_conservation_761  -1
    load_0_16_14  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_582  -20
    arc_0_16_15  connected_order_arc_583  -14
    arc_0_16_15  in_degree_763  1
    arc_0_16_15  out_degree_768  1
    arc_0_16_15  original_T_including_depot_unload_808  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_582  1
    load_0_16_15  free_load_conservation_767  -1
    load_0_16_15  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_584  -20
    arc_0_16_17  connected_order_arc_585  -14
    arc_0_16_17  out_degree_768  1
    arc_0_16_17  in_degree_775  1
    arc_0_16_17  original_T_including_depot_unload_808  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_584  1
    load_0_16_17  free_load_conservation_773  1
    load_0_16_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_586  -20
    arc_0_16_18  connected_order_arc_587  -14
    arc_0_16_18  out_degree_768  1
    arc_0_16_18  in_degree_781  1
    arc_0_16_18  original_T_including_depot_unload_808  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_586  1
    load_0_16_18  free_load_conservation_773  1
    load_0_16_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_588  -20
    arc_0_16_19  connected_order_arc_589  -14
    arc_0_16_19  out_degree_768  1
    arc_0_16_19  in_degree_787  1
    arc_0_16_19  original_T_including_depot_unload_808  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_588  1
    load_0_16_19  free_load_conservation_773  1
    load_0_16_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_590  -20
    arc_0_16_20  connected_order_arc_591  -14
    arc_0_16_20  out_degree_768  1
    arc_0_16_20  in_degree_793  1
    arc_0_16_20  original_T_including_depot_unload_808  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_590  1
    load_0_16_20  free_load_conservation_773  1
    load_0_16_20  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_592  -20
    arc_0_16_21  connected_order_arc_593  -14
    arc_0_16_21  out_degree_768  1
    arc_0_16_21  in_degree_799  1
    arc_0_16_21  original_T_including_depot_unload_808  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_592  1
    load_0_16_21  free_load_conservation_773  1
    load_0_16_21  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_594  -20
    arc_0_17_0  depot_return_or_bypass_720  1
    arc_0_17_0  out_degree_774  1
    arc_0_17_0  original_T_including_depot_unload_808  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_594  1
    load_0_17_0  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_595  -20
    arc_0_17_1  connected_order_arc_596  -14
    arc_0_17_1  in_degree_722  1
    arc_0_17_1  out_degree_774  1
    arc_0_17_1  original_T_including_depot_unload_808  1.5346053834915313e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_595  1
    load_0_17_1  segment_load_conservation_725  -1
    load_0_17_1  segment_prefix_lb_726  1
    load_0_17_1  segment_prefix_ub_727  1
    load_0_17_1  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_597  -20
    arc_0_17_2  connected_order_arc_598  -14
    arc_0_17_2  in_degree_729  1
    arc_0_17_2  out_degree_774  1
    arc_0_17_2  original_T_including_depot_unload_808  1.5362659379368008e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_597  1
    load_0_17_2  segment_load_conservation_732  -1
    load_0_17_2  segment_prefix_lb_733  1
    load_0_17_2  segment_prefix_ub_734  1
    load_0_17_2  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_599  -20
    arc_0_17_3  connected_order_arc_600  -14
    arc_0_17_3  in_degree_736  1
    arc_0_17_3  out_degree_774  1
    arc_0_17_3  original_T_including_depot_unload_808  1.6185675384860760e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_599  1
    load_0_17_3  segment_load_conservation_739  -1
    load_0_17_3  segment_prefix_lb_740  1
    load_0_17_3  segment_prefix_ub_741  1
    load_0_17_3  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_601  -20
    arc_0_17_4  connected_order_arc_602  -14
    arc_0_17_4  in_degree_743  1
    arc_0_17_4  out_degree_774  1
    arc_0_17_4  original_T_including_depot_unload_808  1.3279253844180159e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_601  1
    load_0_17_4  segment_load_conservation_746  -1
    load_0_17_4  segment_prefix_lb_747  1
    load_0_17_4  segment_prefix_ub_748  1
    load_0_17_4  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_603  -20
    arc_0_17_5  connected_order_arc_604  -14
    arc_0_17_5  in_degree_750  1
    arc_0_17_5  out_degree_774  1
    arc_0_17_5  original_T_including_depot_unload_808  8.6622936529310709e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_603  1
    load_0_17_5  segment_load_conservation_753  -1
    load_0_17_5  segment_prefix_lb_754  1
    load_0_17_5  segment_prefix_ub_755  1
    load_0_17_5  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_605  -20
    arc_0_17_14  connected_order_arc_606  -14
    arc_0_17_14  in_degree_757  1
    arc_0_17_14  out_degree_774  1
    arc_0_17_14  original_T_including_depot_unload_808  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_605  1
    load_0_17_14  free_load_conservation_761  -1
    load_0_17_14  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_607  -20
    arc_0_17_15  connected_order_arc_608  -14
    arc_0_17_15  in_degree_763  1
    arc_0_17_15  out_degree_774  1
    arc_0_17_15  original_T_including_depot_unload_808  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_607  1
    load_0_17_15  free_load_conservation_767  -1
    load_0_17_15  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_609  -20
    arc_0_17_16  connected_order_arc_610  -14
    arc_0_17_16  in_degree_769  1
    arc_0_17_16  out_degree_774  1
    arc_0_17_16  original_T_including_depot_unload_808  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_609  1
    load_0_17_16  free_load_conservation_773  -1
    load_0_17_16  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_611  -20
    arc_0_17_18  connected_order_arc_612  -14
    arc_0_17_18  out_degree_774  1
    arc_0_17_18  in_degree_781  1
    arc_0_17_18  original_T_including_depot_unload_808  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_611  1
    load_0_17_18  free_load_conservation_779  1
    load_0_17_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_613  -20
    arc_0_17_19  connected_order_arc_614  -14
    arc_0_17_19  out_degree_774  1
    arc_0_17_19  in_degree_787  1
    arc_0_17_19  original_T_including_depot_unload_808  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_613  1
    load_0_17_19  free_load_conservation_779  1
    load_0_17_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_615  -20
    arc_0_17_20  connected_order_arc_616  -14
    arc_0_17_20  out_degree_774  1
    arc_0_17_20  in_degree_793  1
    arc_0_17_20  original_T_including_depot_unload_808  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_615  1
    load_0_17_20  free_load_conservation_779  1
    load_0_17_20  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_617  -20
    arc_0_17_21  connected_order_arc_618  -14
    arc_0_17_21  out_degree_774  1
    arc_0_17_21  in_degree_799  1
    arc_0_17_21  original_T_including_depot_unload_808  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_617  1
    load_0_17_21  free_load_conservation_779  1
    load_0_17_21  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_619  -20
    arc_0_18_0  depot_return_or_bypass_720  1
    arc_0_18_0  out_degree_780  1
    arc_0_18_0  original_T_including_depot_unload_808  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_619  1
    load_0_18_0  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_620  -20
    arc_0_18_1  connected_order_arc_621  -14
    arc_0_18_1  in_degree_722  1
    arc_0_18_1  out_degree_780  1
    arc_0_18_1  original_T_including_depot_unload_808  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_620  1
    load_0_18_1  segment_load_conservation_725  -1
    load_0_18_1  segment_prefix_lb_726  1
    load_0_18_1  segment_prefix_ub_727  1
    load_0_18_1  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_622  -20
    arc_0_18_2  connected_order_arc_623  -14
    arc_0_18_2  in_degree_729  1
    arc_0_18_2  out_degree_780  1
    arc_0_18_2  original_T_including_depot_unload_808  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_622  1
    load_0_18_2  segment_load_conservation_732  -1
    load_0_18_2  segment_prefix_lb_733  1
    load_0_18_2  segment_prefix_ub_734  1
    load_0_18_2  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_624  -20
    arc_0_18_3  connected_order_arc_625  -14
    arc_0_18_3  in_degree_736  1
    arc_0_18_3  out_degree_780  1
    arc_0_18_3  original_T_including_depot_unload_808  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_624  1
    load_0_18_3  segment_load_conservation_739  -1
    load_0_18_3  segment_prefix_lb_740  1
    load_0_18_3  segment_prefix_ub_741  1
    load_0_18_3  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_626  -20
    arc_0_18_4  connected_order_arc_627  -14
    arc_0_18_4  in_degree_743  1
    arc_0_18_4  out_degree_780  1
    arc_0_18_4  original_T_including_depot_unload_808  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_626  1
    load_0_18_4  segment_load_conservation_746  -1
    load_0_18_4  segment_prefix_lb_747  1
    load_0_18_4  segment_prefix_ub_748  1
    load_0_18_4  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_628  -20
    arc_0_18_5  connected_order_arc_629  -14
    arc_0_18_5  in_degree_750  1
    arc_0_18_5  out_degree_780  1
    arc_0_18_5  original_T_including_depot_unload_808  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_628  1
    load_0_18_5  segment_load_conservation_753  -1
    load_0_18_5  segment_prefix_lb_754  1
    load_0_18_5  segment_prefix_ub_755  1
    load_0_18_5  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_630  -20
    arc_0_18_14  connected_order_arc_631  -14
    arc_0_18_14  in_degree_757  1
    arc_0_18_14  out_degree_780  1
    arc_0_18_14  original_T_including_depot_unload_808  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_630  1
    load_0_18_14  free_load_conservation_761  -1
    load_0_18_14  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_632  -20
    arc_0_18_15  connected_order_arc_633  -14
    arc_0_18_15  in_degree_763  1
    arc_0_18_15  out_degree_780  1
    arc_0_18_15  original_T_including_depot_unload_808  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_632  1
    load_0_18_15  free_load_conservation_767  -1
    load_0_18_15  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_634  -20
    arc_0_18_16  connected_order_arc_635  -14
    arc_0_18_16  in_degree_769  1
    arc_0_18_16  out_degree_780  1
    arc_0_18_16  original_T_including_depot_unload_808  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_634  1
    load_0_18_16  free_load_conservation_773  -1
    load_0_18_16  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_636  -20
    arc_0_18_17  connected_order_arc_637  -14
    arc_0_18_17  in_degree_775  1
    arc_0_18_17  out_degree_780  1
    arc_0_18_17  original_T_including_depot_unload_808  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_636  1
    load_0_18_17  free_load_conservation_779  -1
    load_0_18_17  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_638  -20
    arc_0_18_19  connected_order_arc_639  -14
    arc_0_18_19  out_degree_780  1
    arc_0_18_19  in_degree_787  1
    arc_0_18_19  original_T_including_depot_unload_808  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_638  1
    load_0_18_19  free_load_conservation_785  1
    load_0_18_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_640  -20
    arc_0_18_20  connected_order_arc_641  -14
    arc_0_18_20  out_degree_780  1
    arc_0_18_20  in_degree_793  1
    arc_0_18_20  original_T_including_depot_unload_808  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_640  1
    load_0_18_20  free_load_conservation_785  1
    load_0_18_20  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_642  -20
    arc_0_18_21  connected_order_arc_643  -14
    arc_0_18_21  out_degree_780  1
    arc_0_18_21  in_degree_799  1
    arc_0_18_21  original_T_including_depot_unload_808  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_642  1
    load_0_18_21  free_load_conservation_785  1
    load_0_18_21  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_644  -20
    arc_0_19_0  depot_return_or_bypass_720  1
    arc_0_19_0  out_degree_786  1
    arc_0_19_0  original_T_including_depot_unload_808  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_644  1
    load_0_19_0  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_645  -20
    arc_0_19_1  connected_order_arc_646  -14
    arc_0_19_1  in_degree_722  1
    arc_0_19_1  out_degree_786  1
    arc_0_19_1  original_T_including_depot_unload_808  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_645  1
    load_0_19_1  segment_load_conservation_725  -1
    load_0_19_1  segment_prefix_lb_726  1
    load_0_19_1  segment_prefix_ub_727  1
    load_0_19_1  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_647  -20
    arc_0_19_2  connected_order_arc_648  -14
    arc_0_19_2  in_degree_729  1
    arc_0_19_2  out_degree_786  1
    arc_0_19_2  original_T_including_depot_unload_808  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_647  1
    load_0_19_2  segment_load_conservation_732  -1
    load_0_19_2  segment_prefix_lb_733  1
    load_0_19_2  segment_prefix_ub_734  1
    load_0_19_2  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_649  -20
    arc_0_19_3  connected_order_arc_650  -14
    arc_0_19_3  in_degree_736  1
    arc_0_19_3  out_degree_786  1
    arc_0_19_3  original_T_including_depot_unload_808  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_649  1
    load_0_19_3  segment_load_conservation_739  -1
    load_0_19_3  segment_prefix_lb_740  1
    load_0_19_3  segment_prefix_ub_741  1
    load_0_19_3  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_651  -20
    arc_0_19_4  connected_order_arc_652  -14
    arc_0_19_4  in_degree_743  1
    arc_0_19_4  out_degree_786  1
    arc_0_19_4  original_T_including_depot_unload_808  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_651  1
    load_0_19_4  segment_load_conservation_746  -1
    load_0_19_4  segment_prefix_lb_747  1
    load_0_19_4  segment_prefix_ub_748  1
    load_0_19_4  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_653  -20
    arc_0_19_5  connected_order_arc_654  -14
    arc_0_19_5  in_degree_750  1
    arc_0_19_5  out_degree_786  1
    arc_0_19_5  original_T_including_depot_unload_808  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_653  1
    load_0_19_5  segment_load_conservation_753  -1
    load_0_19_5  segment_prefix_lb_754  1
    load_0_19_5  segment_prefix_ub_755  1
    load_0_19_5  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_655  -20
    arc_0_19_14  connected_order_arc_656  -14
    arc_0_19_14  in_degree_757  1
    arc_0_19_14  out_degree_786  1
    arc_0_19_14  original_T_including_depot_unload_808  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_655  1
    load_0_19_14  free_load_conservation_761  -1
    load_0_19_14  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_657  -20
    arc_0_19_15  connected_order_arc_658  -14
    arc_0_19_15  in_degree_763  1
    arc_0_19_15  out_degree_786  1
    arc_0_19_15  original_T_including_depot_unload_808  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_657  1
    load_0_19_15  free_load_conservation_767  -1
    load_0_19_15  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_659  -20
    arc_0_19_16  connected_order_arc_660  -14
    arc_0_19_16  in_degree_769  1
    arc_0_19_16  out_degree_786  1
    arc_0_19_16  original_T_including_depot_unload_808  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_659  1
    load_0_19_16  free_load_conservation_773  -1
    load_0_19_16  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_661  -20
    arc_0_19_17  connected_order_arc_662  -14
    arc_0_19_17  in_degree_775  1
    arc_0_19_17  out_degree_786  1
    arc_0_19_17  original_T_including_depot_unload_808  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_661  1
    load_0_19_17  free_load_conservation_779  -1
    load_0_19_17  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_663  -20
    arc_0_19_18  connected_order_arc_664  -14
    arc_0_19_18  in_degree_781  1
    arc_0_19_18  out_degree_786  1
    arc_0_19_18  original_T_including_depot_unload_808  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_663  1
    load_0_19_18  free_load_conservation_785  -1
    load_0_19_18  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_665  -20
    arc_0_19_20  connected_order_arc_666  -14
    arc_0_19_20  out_degree_786  1
    arc_0_19_20  in_degree_793  1
    arc_0_19_20  original_T_including_depot_unload_808  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_665  1
    load_0_19_20  free_load_conservation_791  1
    load_0_19_20  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_667  -20
    arc_0_19_21  connected_order_arc_668  -14
    arc_0_19_21  out_degree_786  1
    arc_0_19_21  in_degree_799  1
    arc_0_19_21  original_T_including_depot_unload_808  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_667  1
    load_0_19_21  free_load_conservation_791  1
    load_0_19_21  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_669  -20
    arc_0_20_0  depot_return_or_bypass_720  1
    arc_0_20_0  out_degree_792  1
    arc_0_20_0  original_T_including_depot_unload_808  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_669  1
    load_0_20_0  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_670  -20
    arc_0_20_1  connected_order_arc_671  -14
    arc_0_20_1  in_degree_722  1
    arc_0_20_1  out_degree_792  1
    arc_0_20_1  original_T_including_depot_unload_808  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_670  1
    load_0_20_1  segment_load_conservation_725  -1
    load_0_20_1  segment_prefix_lb_726  1
    load_0_20_1  segment_prefix_ub_727  1
    load_0_20_1  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_672  -20
    arc_0_20_2  connected_order_arc_673  -14
    arc_0_20_2  in_degree_729  1
    arc_0_20_2  out_degree_792  1
    arc_0_20_2  original_T_including_depot_unload_808  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_672  1
    load_0_20_2  segment_load_conservation_732  -1
    load_0_20_2  segment_prefix_lb_733  1
    load_0_20_2  segment_prefix_ub_734  1
    load_0_20_2  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_674  -20
    arc_0_20_3  connected_order_arc_675  -14
    arc_0_20_3  in_degree_736  1
    arc_0_20_3  out_degree_792  1
    arc_0_20_3  original_T_including_depot_unload_808  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_674  1
    load_0_20_3  segment_load_conservation_739  -1
    load_0_20_3  segment_prefix_lb_740  1
    load_0_20_3  segment_prefix_ub_741  1
    load_0_20_3  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_676  -20
    arc_0_20_4  connected_order_arc_677  -14
    arc_0_20_4  in_degree_743  1
    arc_0_20_4  out_degree_792  1
    arc_0_20_4  original_T_including_depot_unload_808  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_676  1
    load_0_20_4  segment_load_conservation_746  -1
    load_0_20_4  segment_prefix_lb_747  1
    load_0_20_4  segment_prefix_ub_748  1
    load_0_20_4  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_678  -20
    arc_0_20_5  connected_order_arc_679  -14
    arc_0_20_5  in_degree_750  1
    arc_0_20_5  out_degree_792  1
    arc_0_20_5  original_T_including_depot_unload_808  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_678  1
    load_0_20_5  segment_load_conservation_753  -1
    load_0_20_5  segment_prefix_lb_754  1
    load_0_20_5  segment_prefix_ub_755  1
    load_0_20_5  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_680  -20
    arc_0_20_14  connected_order_arc_681  -14
    arc_0_20_14  in_degree_757  1
    arc_0_20_14  out_degree_792  1
    arc_0_20_14  original_T_including_depot_unload_808  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_680  1
    load_0_20_14  free_load_conservation_761  -1
    load_0_20_14  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_682  -20
    arc_0_20_15  connected_order_arc_683  -14
    arc_0_20_15  in_degree_763  1
    arc_0_20_15  out_degree_792  1
    arc_0_20_15  original_T_including_depot_unload_808  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_682  1
    load_0_20_15  free_load_conservation_767  -1
    load_0_20_15  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_684  -20
    arc_0_20_16  connected_order_arc_685  -14
    arc_0_20_16  in_degree_769  1
    arc_0_20_16  out_degree_792  1
    arc_0_20_16  original_T_including_depot_unload_808  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_684  1
    load_0_20_16  free_load_conservation_773  -1
    load_0_20_16  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_686  -20
    arc_0_20_17  connected_order_arc_687  -14
    arc_0_20_17  in_degree_775  1
    arc_0_20_17  out_degree_792  1
    arc_0_20_17  original_T_including_depot_unload_808  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_686  1
    load_0_20_17  free_load_conservation_779  -1
    load_0_20_17  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_688  -20
    arc_0_20_18  connected_order_arc_689  -14
    arc_0_20_18  in_degree_781  1
    arc_0_20_18  out_degree_792  1
    arc_0_20_18  original_T_including_depot_unload_808  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_688  1
    load_0_20_18  free_load_conservation_785  -1
    load_0_20_18  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_690  -20
    arc_0_20_19  connected_order_arc_691  -14
    arc_0_20_19  in_degree_787  1
    arc_0_20_19  out_degree_792  1
    arc_0_20_19  original_T_including_depot_unload_808  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_690  1
    load_0_20_19  free_load_conservation_791  -1
    load_0_20_19  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_692  -20
    arc_0_20_21  connected_order_arc_693  -14
    arc_0_20_21  out_degree_792  1
    arc_0_20_21  in_degree_799  1
    arc_0_20_21  original_T_including_depot_unload_808  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_692  1
    load_0_20_21  free_load_conservation_797  1
    load_0_20_21  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_694  -20
    arc_0_21_0  depot_return_or_bypass_720  1
    arc_0_21_0  out_degree_798  1
    arc_0_21_0  original_T_including_depot_unload_808  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_694  1
    load_0_21_0  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_695  -20
    arc_0_21_1  connected_order_arc_696  -14
    arc_0_21_1  in_degree_722  1
    arc_0_21_1  out_degree_798  1
    arc_0_21_1  original_T_including_depot_unload_808  1.7069358358556344e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_695  1
    load_0_21_1  segment_load_conservation_725  -1
    load_0_21_1  segment_prefix_lb_726  1
    load_0_21_1  segment_prefix_ub_727  1
    load_0_21_1  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_697  -20
    arc_0_21_2  connected_order_arc_698  -14
    arc_0_21_2  in_degree_729  1
    arc_0_21_2  out_degree_798  1
    arc_0_21_2  original_T_including_depot_unload_808  1.7155529120526971e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_697  1
    load_0_21_2  segment_load_conservation_732  -1
    load_0_21_2  segment_prefix_lb_733  1
    load_0_21_2  segment_prefix_ub_734  1
    load_0_21_2  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_699  -20
    arc_0_21_3  connected_order_arc_700  -14
    arc_0_21_3  in_degree_736  1
    arc_0_21_3  out_degree_798  1
    arc_0_21_3  original_T_including_depot_unload_808  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_699  1
    load_0_21_3  segment_load_conservation_739  -1
    load_0_21_3  segment_prefix_lb_740  1
    load_0_21_3  segment_prefix_ub_741  1
    load_0_21_3  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_701  -20
    arc_0_21_4  connected_order_arc_702  -14
    arc_0_21_4  in_degree_743  1
    arc_0_21_4  out_degree_798  1
    arc_0_21_4  original_T_including_depot_unload_808  1.5086201853425566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_701  1
    load_0_21_4  segment_load_conservation_746  -1
    load_0_21_4  segment_prefix_lb_747  1
    load_0_21_4  segment_prefix_ub_748  1
    load_0_21_4  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_703  -20
    arc_0_21_5  connected_order_arc_704  -14
    arc_0_21_5  in_degree_750  1
    arc_0_21_5  out_degree_798  1
    arc_0_21_5  original_T_including_depot_unload_808  1.0428195034234207e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_703  1
    load_0_21_5  segment_load_conservation_753  -1
    load_0_21_5  segment_prefix_lb_754  1
    load_0_21_5  segment_prefix_ub_755  1
    load_0_21_5  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_14  arc_capacity_705  -20
    arc_0_21_14  connected_order_arc_706  -14
    arc_0_21_14  in_degree_757  1
    arc_0_21_14  out_degree_798  1
    arc_0_21_14  original_T_including_depot_unload_808  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_14  arc_capacity_705  1
    load_0_21_14  free_load_conservation_761  -1
    load_0_21_14  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_707  -20
    arc_0_21_15  connected_order_arc_708  -14
    arc_0_21_15  in_degree_763  1
    arc_0_21_15  out_degree_798  1
    arc_0_21_15  original_T_including_depot_unload_808  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_707  1
    load_0_21_15  free_load_conservation_767  -1
    load_0_21_15  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_709  -20
    arc_0_21_16  connected_order_arc_710  -14
    arc_0_21_16  in_degree_769  1
    arc_0_21_16  out_degree_798  1
    arc_0_21_16  original_T_including_depot_unload_808  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_709  1
    load_0_21_16  free_load_conservation_773  -1
    load_0_21_16  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_711  -20
    arc_0_21_17  connected_order_arc_712  -14
    arc_0_21_17  in_degree_775  1
    arc_0_21_17  out_degree_798  1
    arc_0_21_17  original_T_including_depot_unload_808  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_711  1
    load_0_21_17  free_load_conservation_779  -1
    load_0_21_17  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_713  -20
    arc_0_21_18  connected_order_arc_714  -14
    arc_0_21_18  in_degree_781  1
    arc_0_21_18  out_degree_798  1
    arc_0_21_18  original_T_including_depot_unload_808  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_713  1
    load_0_21_18  free_load_conservation_785  -1
    load_0_21_18  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_715  -20
    arc_0_21_19  connected_order_arc_716  -14
    arc_0_21_19  in_degree_787  1
    arc_0_21_19  out_degree_798  1
    arc_0_21_19  original_T_including_depot_unload_808  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_715  1
    load_0_21_19  free_load_conservation_791  -1
    load_0_21_19  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_717  -20
    arc_0_21_20  connected_order_arc_718  -14
    arc_0_21_20  in_degree_793  1
    arc_0_21_20  out_degree_798  1
    arc_0_21_20  original_T_including_depot_unload_808  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_717  1
    load_0_21_20  free_load_conservation_797  -1
    load_0_21_20  free_load_conservation_803  1
    visit_1_6  out_degree_1100  -1
    visit_1_6  in_degree_1101  -1
    visit_1_6  order_active_lb_1102  -1
    visit_1_6  order_active_ub_1103  -12
    order_1_6  connected_order_arc_824  -1
    order_1_6  connected_order_arc_826  -1
    order_1_6  connected_order_arc_828  -1
    order_1_6  connected_order_arc_830  -1
    order_1_6  connected_order_arc_832  -1
    order_1_6  connected_order_arc_834  -1
    order_1_6  connected_order_arc_836  -1
    order_1_6  connected_order_arc_838  -1
    order_1_6  connected_order_arc_840  -1
    order_1_6  connected_order_arc_842  -1
    order_1_6  connected_order_arc_844  -1
    order_1_6  connected_order_arc_847  1
    order_1_6  connected_order_arc_870  1
    order_1_6  connected_order_arc_893  1
    order_1_6  connected_order_arc_916  1
    order_1_6  connected_order_arc_939  1
    order_1_6  connected_order_arc_962  1
    order_1_6  connected_order_arc_985  1
    order_1_6  connected_order_arc_1008  1
    order_1_6  connected_order_arc_1031  1
    order_1_6  connected_order_arc_1054  1
    order_1_6  connected_order_arc_1077  1
    order_1_6  order_active_lb_1102  1
    order_1_6  order_active_ub_1103  1
    order_1_6  fixed_segment_relative_order_1176  -1
    visit_1_7  out_degree_1107  -1
    visit_1_7  in_degree_1108  -1
    visit_1_7  order_active_lb_1109  -1
    visit_1_7  order_active_ub_1110  -12
    order_1_7  connected_order_arc_824  1
    order_1_7  connected_order_arc_847  -1
    order_1_7  connected_order_arc_849  -1
    order_1_7  connected_order_arc_851  -1
    order_1_7  connected_order_arc_853  -1
    order_1_7  connected_order_arc_855  -1
    order_1_7  connected_order_arc_857  -1
    order_1_7  connected_order_arc_859  -1
    order_1_7  connected_order_arc_861  -1
    order_1_7  connected_order_arc_863  -1
    order_1_7  connected_order_arc_865  -1
    order_1_7  connected_order_arc_867  -1
    order_1_7  connected_order_arc_872  1
    order_1_7  connected_order_arc_895  1
    order_1_7  connected_order_arc_918  1
    order_1_7  connected_order_arc_941  1
    order_1_7  connected_order_arc_964  1
    order_1_7  connected_order_arc_987  1
    order_1_7  connected_order_arc_1010  1
    order_1_7  connected_order_arc_1033  1
    order_1_7  connected_order_arc_1056  1
    order_1_7  connected_order_arc_1079  1
    order_1_7  order_active_lb_1109  1
    order_1_7  order_active_ub_1110  1
    order_1_7  fixed_segment_relative_order_1176  1
    order_1_7  fixed_segment_relative_order_1177  -1
    visit_1_8  out_degree_1114  -1
    visit_1_8  in_degree_1115  -1
    visit_1_8  order_active_lb_1116  -1
    visit_1_8  order_active_ub_1117  -12
    order_1_8  connected_order_arc_826  1
    order_1_8  connected_order_arc_849  1
    order_1_8  connected_order_arc_870  -1
    order_1_8  connected_order_arc_872  -1
    order_1_8  connected_order_arc_874  -1
    order_1_8  connected_order_arc_876  -1
    order_1_8  connected_order_arc_878  -1
    order_1_8  connected_order_arc_880  -1
    order_1_8  connected_order_arc_882  -1
    order_1_8  connected_order_arc_884  -1
    order_1_8  connected_order_arc_886  -1
    order_1_8  connected_order_arc_888  -1
    order_1_8  connected_order_arc_890  -1
    order_1_8  connected_order_arc_897  1
    order_1_8  connected_order_arc_920  1
    order_1_8  connected_order_arc_943  1
    order_1_8  connected_order_arc_966  1
    order_1_8  connected_order_arc_989  1
    order_1_8  connected_order_arc_1012  1
    order_1_8  connected_order_arc_1035  1
    order_1_8  connected_order_arc_1058  1
    order_1_8  connected_order_arc_1081  1
    order_1_8  order_active_lb_1116  1
    order_1_8  order_active_ub_1117  1
    order_1_8  fixed_segment_relative_order_1177  1
    order_1_8  fixed_segment_relative_order_1178  -1
    visit_1_9  out_degree_1121  -1
    visit_1_9  in_degree_1122  -1
    visit_1_9  order_active_lb_1123  -1
    visit_1_9  order_active_ub_1124  -12
    order_1_9  connected_order_arc_828  1
    order_1_9  connected_order_arc_851  1
    order_1_9  connected_order_arc_874  1
    order_1_9  connected_order_arc_893  -1
    order_1_9  connected_order_arc_895  -1
    order_1_9  connected_order_arc_897  -1
    order_1_9  connected_order_arc_899  -1
    order_1_9  connected_order_arc_901  -1
    order_1_9  connected_order_arc_903  -1
    order_1_9  connected_order_arc_905  -1
    order_1_9  connected_order_arc_907  -1
    order_1_9  connected_order_arc_909  -1
    order_1_9  connected_order_arc_911  -1
    order_1_9  connected_order_arc_913  -1
    order_1_9  connected_order_arc_922  1
    order_1_9  connected_order_arc_945  1
    order_1_9  connected_order_arc_968  1
    order_1_9  connected_order_arc_991  1
    order_1_9  connected_order_arc_1014  1
    order_1_9  connected_order_arc_1037  1
    order_1_9  connected_order_arc_1060  1
    order_1_9  connected_order_arc_1083  1
    order_1_9  order_active_lb_1123  1
    order_1_9  order_active_ub_1124  1
    order_1_9  fixed_segment_relative_order_1178  1
    visit_1_14  out_degree_1128  -1
    visit_1_14  in_degree_1129  -1
    visit_1_14  order_active_lb_1130  -1
    visit_1_14  order_active_ub_1131  -12
    visit_1_14  service_visit_def_1132  -1
    order_1_14  connected_order_arc_830  1
    order_1_14  connected_order_arc_853  1
    order_1_14  connected_order_arc_876  1
    order_1_14  connected_order_arc_899  1
    order_1_14  connected_order_arc_916  -1
    order_1_14  connected_order_arc_918  -1
    order_1_14  connected_order_arc_920  -1
    order_1_14  connected_order_arc_922  -1
    order_1_14  connected_order_arc_924  -1
    order_1_14  connected_order_arc_926  -1
    order_1_14  connected_order_arc_928  -1
    order_1_14  connected_order_arc_930  -1
    order_1_14  connected_order_arc_932  -1
    order_1_14  connected_order_arc_934  -1
    order_1_14  connected_order_arc_936  -1
    order_1_14  connected_order_arc_947  1
    order_1_14  connected_order_arc_970  1
    order_1_14  connected_order_arc_993  1
    order_1_14  connected_order_arc_1016  1
    order_1_14  connected_order_arc_1039  1
    order_1_14  connected_order_arc_1062  1
    order_1_14  connected_order_arc_1085  1
    order_1_14  order_active_lb_1130  1
    order_1_14  order_active_ub_1131  1
    visit_1_15  out_degree_1134  -1
    visit_1_15  in_degree_1135  -1
    visit_1_15  order_active_lb_1136  -1
    visit_1_15  order_active_ub_1137  -12
    visit_1_15  service_visit_def_1138  -1
    order_1_15  connected_order_arc_832  1
    order_1_15  connected_order_arc_855  1
    order_1_15  connected_order_arc_878  1
    order_1_15  connected_order_arc_901  1
    order_1_15  connected_order_arc_924  1
    order_1_15  connected_order_arc_939  -1
    order_1_15  connected_order_arc_941  -1
    order_1_15  connected_order_arc_943  -1
    order_1_15  connected_order_arc_945  -1
    order_1_15  connected_order_arc_947  -1
    order_1_15  connected_order_arc_949  -1
    order_1_15  connected_order_arc_951  -1
    order_1_15  connected_order_arc_953  -1
    order_1_15  connected_order_arc_955  -1
    order_1_15  connected_order_arc_957  -1
    order_1_15  connected_order_arc_959  -1
    order_1_15  connected_order_arc_972  1
    order_1_15  connected_order_arc_995  1
    order_1_15  connected_order_arc_1018  1
    order_1_15  connected_order_arc_1041  1
    order_1_15  connected_order_arc_1064  1
    order_1_15  connected_order_arc_1087  1
    order_1_15  order_active_lb_1136  1
    order_1_15  order_active_ub_1137  1
    visit_1_16  out_degree_1140  -1
    visit_1_16  in_degree_1141  -1
    visit_1_16  order_active_lb_1142  -1
    visit_1_16  order_active_ub_1143  -12
    visit_1_16  service_visit_def_1144  -1
    order_1_16  connected_order_arc_834  1
    order_1_16  connected_order_arc_857  1
    order_1_16  connected_order_arc_880  1
    order_1_16  connected_order_arc_903  1
    order_1_16  connected_order_arc_926  1
    order_1_16  connected_order_arc_949  1
    order_1_16  connected_order_arc_962  -1
    order_1_16  connected_order_arc_964  -1
    order_1_16  connected_order_arc_966  -1
    order_1_16  connected_order_arc_968  -1
    order_1_16  connected_order_arc_970  -1
    order_1_16  connected_order_arc_972  -1
    order_1_16  connected_order_arc_974  -1
    order_1_16  connected_order_arc_976  -1
    order_1_16  connected_order_arc_978  -1
    order_1_16  connected_order_arc_980  -1
    order_1_16  connected_order_arc_982  -1
    order_1_16  connected_order_arc_997  1
    order_1_16  connected_order_arc_1020  1
    order_1_16  connected_order_arc_1043  1
    order_1_16  connected_order_arc_1066  1
    order_1_16  connected_order_arc_1089  1
    order_1_16  order_active_lb_1142  1
    order_1_16  order_active_ub_1143  1
    visit_1_17  out_degree_1146  -1
    visit_1_17  in_degree_1147  -1
    visit_1_17  order_active_lb_1148  -1
    visit_1_17  order_active_ub_1149  -12
    visit_1_17  service_visit_def_1150  -1
    order_1_17  connected_order_arc_836  1
    order_1_17  connected_order_arc_859  1
    order_1_17  connected_order_arc_882  1
    order_1_17  connected_order_arc_905  1
    order_1_17  connected_order_arc_928  1
    order_1_17  connected_order_arc_951  1
    order_1_17  connected_order_arc_974  1
    order_1_17  connected_order_arc_985  -1
    order_1_17  connected_order_arc_987  -1
    order_1_17  connected_order_arc_989  -1
    order_1_17  connected_order_arc_991  -1
    order_1_17  connected_order_arc_993  -1
    order_1_17  connected_order_arc_995  -1
    order_1_17  connected_order_arc_997  -1
    order_1_17  connected_order_arc_999  -1
    order_1_17  connected_order_arc_1001  -1
    order_1_17  connected_order_arc_1003  -1
    order_1_17  connected_order_arc_1005  -1
    order_1_17  connected_order_arc_1022  1
    order_1_17  connected_order_arc_1045  1
    order_1_17  connected_order_arc_1068  1
    order_1_17  connected_order_arc_1091  1
    order_1_17  order_active_lb_1148  1
    order_1_17  order_active_ub_1149  1
    visit_1_18  out_degree_1152  -1
    visit_1_18  in_degree_1153  -1
    visit_1_18  order_active_lb_1154  -1
    visit_1_18  order_active_ub_1155  -12
    visit_1_18  service_visit_def_1156  -1
    order_1_18  connected_order_arc_838  1
    order_1_18  connected_order_arc_861  1
    order_1_18  connected_order_arc_884  1
    order_1_18  connected_order_arc_907  1
    order_1_18  connected_order_arc_930  1
    order_1_18  connected_order_arc_953  1
    order_1_18  connected_order_arc_976  1
    order_1_18  connected_order_arc_999  1
    order_1_18  connected_order_arc_1008  -1
    order_1_18  connected_order_arc_1010  -1
    order_1_18  connected_order_arc_1012  -1
    order_1_18  connected_order_arc_1014  -1
    order_1_18  connected_order_arc_1016  -1
    order_1_18  connected_order_arc_1018  -1
    order_1_18  connected_order_arc_1020  -1
    order_1_18  connected_order_arc_1022  -1
    order_1_18  connected_order_arc_1024  -1
    order_1_18  connected_order_arc_1026  -1
    order_1_18  connected_order_arc_1028  -1
    order_1_18  connected_order_arc_1047  1
    order_1_18  connected_order_arc_1070  1
    order_1_18  connected_order_arc_1093  1
    order_1_18  order_active_lb_1154  1
    order_1_18  order_active_ub_1155  1
    visit_1_19  out_degree_1158  -1
    visit_1_19  in_degree_1159  -1
    visit_1_19  order_active_lb_1160  -1
    visit_1_19  order_active_ub_1161  -12
    visit_1_19  service_visit_def_1162  -1
    order_1_19  connected_order_arc_840  1
    order_1_19  connected_order_arc_863  1
    order_1_19  connected_order_arc_886  1
    order_1_19  connected_order_arc_909  1
    order_1_19  connected_order_arc_932  1
    order_1_19  connected_order_arc_955  1
    order_1_19  connected_order_arc_978  1
    order_1_19  connected_order_arc_1001  1
    order_1_19  connected_order_arc_1024  1
    order_1_19  connected_order_arc_1031  -1
    order_1_19  connected_order_arc_1033  -1
    order_1_19  connected_order_arc_1035  -1
    order_1_19  connected_order_arc_1037  -1
    order_1_19  connected_order_arc_1039  -1
    order_1_19  connected_order_arc_1041  -1
    order_1_19  connected_order_arc_1043  -1
    order_1_19  connected_order_arc_1045  -1
    order_1_19  connected_order_arc_1047  -1
    order_1_19  connected_order_arc_1049  -1
    order_1_19  connected_order_arc_1051  -1
    order_1_19  connected_order_arc_1072  1
    order_1_19  connected_order_arc_1095  1
    order_1_19  order_active_lb_1160  1
    order_1_19  order_active_ub_1161  1
    visit_1_20  out_degree_1164  -1
    visit_1_20  in_degree_1165  -1
    visit_1_20  order_active_lb_1166  -1
    visit_1_20  order_active_ub_1167  -12
    visit_1_20  service_visit_def_1168  -1
    order_1_20  connected_order_arc_842  1
    order_1_20  connected_order_arc_865  1
    order_1_20  connected_order_arc_888  1
    order_1_20  connected_order_arc_911  1
    order_1_20  connected_order_arc_934  1
    order_1_20  connected_order_arc_957  1
    order_1_20  connected_order_arc_980  1
    order_1_20  connected_order_arc_1003  1
    order_1_20  connected_order_arc_1026  1
    order_1_20  connected_order_arc_1049  1
    order_1_20  connected_order_arc_1054  -1
    order_1_20  connected_order_arc_1056  -1
    order_1_20  connected_order_arc_1058  -1
    order_1_20  connected_order_arc_1060  -1
    order_1_20  connected_order_arc_1062  -1
    order_1_20  connected_order_arc_1064  -1
    order_1_20  connected_order_arc_1066  -1
    order_1_20  connected_order_arc_1068  -1
    order_1_20  connected_order_arc_1070  -1
    order_1_20  connected_order_arc_1072  -1
    order_1_20  connected_order_arc_1074  -1
    order_1_20  connected_order_arc_1097  1
    order_1_20  order_active_lb_1166  1
    order_1_20  order_active_ub_1167  1
    visit_1_21  out_degree_1170  -1
    visit_1_21  in_degree_1171  -1
    visit_1_21  order_active_lb_1172  -1
    visit_1_21  order_active_ub_1173  -12
    visit_1_21  service_visit_def_1174  -1
    order_1_21  connected_order_arc_844  1
    order_1_21  connected_order_arc_867  1
    order_1_21  connected_order_arc_890  1
    order_1_21  connected_order_arc_913  1
    order_1_21  connected_order_arc_936  1
    order_1_21  connected_order_arc_959  1
    order_1_21  connected_order_arc_982  1
    order_1_21  connected_order_arc_1005  1
    order_1_21  connected_order_arc_1028  1
    order_1_21  connected_order_arc_1051  1
    order_1_21  connected_order_arc_1074  1
    order_1_21  connected_order_arc_1077  -1
    order_1_21  connected_order_arc_1079  -1
    order_1_21  connected_order_arc_1081  -1
    order_1_21  connected_order_arc_1083  -1
    order_1_21  connected_order_arc_1085  -1
    order_1_21  connected_order_arc_1087  -1
    order_1_21  connected_order_arc_1089  -1
    order_1_21  connected_order_arc_1091  -1
    order_1_21  connected_order_arc_1093  -1
    order_1_21  connected_order_arc_1095  -1
    order_1_21  connected_order_arc_1097  -1
    order_1_21  order_active_lb_1172  1
    order_1_21  order_active_ub_1173  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_809  -25
    arc_1_0_0  depot_departure_or_bypass_1098  1
    arc_1_0_0  depot_return_or_bypass_1099  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_810  -25
    arc_1_0_6  depot_departure_or_bypass_1098  1
    arc_1_0_6  in_degree_1101  1
    arc_1_0_6  original_T_including_depot_unload_1179  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_810  1
    load_1_0_6  segment_load_conservation_1104  -1
    load_1_0_6  segment_prefix_lb_1105  1
    load_1_0_6  segment_prefix_ub_1106  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_811  -25
    arc_1_0_7  depot_departure_or_bypass_1098  1
    arc_1_0_7  in_degree_1108  1
    arc_1_0_7  original_T_including_depot_unload_1179  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_811  1
    load_1_0_7  segment_load_conservation_1111  -1
    load_1_0_7  segment_prefix_lb_1112  1
    load_1_0_7  segment_prefix_ub_1113  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_812  -25
    arc_1_0_8  depot_departure_or_bypass_1098  1
    arc_1_0_8  in_degree_1115  1
    arc_1_0_8  original_T_including_depot_unload_1179  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_812  1
    load_1_0_8  segment_load_conservation_1118  -1
    load_1_0_8  segment_prefix_lb_1119  1
    load_1_0_8  segment_prefix_ub_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_813  -25
    arc_1_0_9  depot_departure_or_bypass_1098  1
    arc_1_0_9  in_degree_1122  1
    arc_1_0_9  original_T_including_depot_unload_1179  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_813  1
    load_1_0_9  segment_load_conservation_1125  -1
    load_1_0_9  segment_prefix_lb_1126  1
    load_1_0_9  segment_prefix_ub_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_814  -25
    arc_1_0_14  depot_departure_or_bypass_1098  1
    arc_1_0_14  in_degree_1129  1
    arc_1_0_14  original_T_including_depot_unload_1179  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_814  1
    load_1_0_14  free_load_conservation_1133  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_815  -25
    arc_1_0_15  depot_departure_or_bypass_1098  1
    arc_1_0_15  in_degree_1135  1
    arc_1_0_15  original_T_including_depot_unload_1179  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_815  1
    load_1_0_15  free_load_conservation_1139  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_816  -25
    arc_1_0_16  depot_departure_or_bypass_1098  1
    arc_1_0_16  in_degree_1141  1
    arc_1_0_16  original_T_including_depot_unload_1179  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_816  1
    load_1_0_16  free_load_conservation_1145  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_817  -25
    arc_1_0_17  depot_departure_or_bypass_1098  1
    arc_1_0_17  in_degree_1147  1
    arc_1_0_17  original_T_including_depot_unload_1179  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_817  1
    load_1_0_17  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_818  -25
    arc_1_0_18  depot_departure_or_bypass_1098  1
    arc_1_0_18  in_degree_1153  1
    arc_1_0_18  original_T_including_depot_unload_1179  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_818  1
    load_1_0_18  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_819  -25
    arc_1_0_19  depot_departure_or_bypass_1098  1
    arc_1_0_19  in_degree_1159  1
    arc_1_0_19  original_T_including_depot_unload_1179  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_819  1
    load_1_0_19  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_820  -25
    arc_1_0_20  depot_departure_or_bypass_1098  1
    arc_1_0_20  in_degree_1165  1
    arc_1_0_20  original_T_including_depot_unload_1179  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_820  1
    load_1_0_20  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_821  -25
    arc_1_0_21  depot_departure_or_bypass_1098  1
    arc_1_0_21  in_degree_1171  1
    arc_1_0_21  original_T_including_depot_unload_1179  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_821  1
    load_1_0_21  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_822  -25
    arc_1_6_0  depot_return_or_bypass_1099  1
    arc_1_6_0  out_degree_1100  1
    arc_1_6_0  original_T_including_depot_unload_1179  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_822  1
    load_1_6_0  segment_load_conservation_1104  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_823  -25
    arc_1_6_7  connected_order_arc_824  -13
    arc_1_6_7  out_degree_1100  1
    arc_1_6_7  in_degree_1108  1
    arc_1_6_7  original_T_including_depot_unload_1179  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_823  1
    load_1_6_7  segment_load_conservation_1104  1
    load_1_6_7  segment_load_conservation_1111  -1
    load_1_6_7  segment_prefix_lb_1112  1
    load_1_6_7  segment_prefix_ub_1113  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_825  -25
    arc_1_6_8  connected_order_arc_826  -13
    arc_1_6_8  out_degree_1100  1
    arc_1_6_8  in_degree_1115  1
    arc_1_6_8  original_T_including_depot_unload_1179  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_825  1
    load_1_6_8  segment_load_conservation_1104  1
    load_1_6_8  segment_load_conservation_1118  -1
    load_1_6_8  segment_prefix_lb_1119  1
    load_1_6_8  segment_prefix_ub_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_827  -25
    arc_1_6_9  connected_order_arc_828  -13
    arc_1_6_9  out_degree_1100  1
    arc_1_6_9  in_degree_1122  1
    arc_1_6_9  original_T_including_depot_unload_1179  7.0141209816069022e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_827  1
    load_1_6_9  segment_load_conservation_1104  1
    load_1_6_9  segment_load_conservation_1125  -1
    load_1_6_9  segment_prefix_lb_1126  1
    load_1_6_9  segment_prefix_ub_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_829  -25
    arc_1_6_14  connected_order_arc_830  -13
    arc_1_6_14  out_degree_1100  1
    arc_1_6_14  in_degree_1129  1
    arc_1_6_14  original_T_including_depot_unload_1179  2.0204177348160229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_829  1
    load_1_6_14  segment_load_conservation_1104  1
    load_1_6_14  free_load_conservation_1133  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_831  -25
    arc_1_6_15  connected_order_arc_832  -13
    arc_1_6_15  out_degree_1100  1
    arc_1_6_15  in_degree_1135  1
    arc_1_6_15  original_T_including_depot_unload_1179  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_831  1
    load_1_6_15  segment_load_conservation_1104  1
    load_1_6_15  free_load_conservation_1139  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_833  -25
    arc_1_6_16  connected_order_arc_834  -13
    arc_1_6_16  out_degree_1100  1
    arc_1_6_16  in_degree_1141  1
    arc_1_6_16  original_T_including_depot_unload_1179  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_833  1
    load_1_6_16  segment_load_conservation_1104  1
    load_1_6_16  free_load_conservation_1145  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_835  -25
    arc_1_6_17  connected_order_arc_836  -13
    arc_1_6_17  out_degree_1100  1
    arc_1_6_17  in_degree_1147  1
    arc_1_6_17  original_T_including_depot_unload_1179  2.0027314450664605e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_835  1
    load_1_6_17  segment_load_conservation_1104  1
    load_1_6_17  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_837  -25
    arc_1_6_18  connected_order_arc_838  -13
    arc_1_6_18  out_degree_1100  1
    arc_1_6_18  in_degree_1153  1
    arc_1_6_18  original_T_including_depot_unload_1179  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_837  1
    load_1_6_18  segment_load_conservation_1104  1
    load_1_6_18  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_839  -25
    arc_1_6_19  connected_order_arc_840  -13
    arc_1_6_19  out_degree_1100  1
    arc_1_6_19  in_degree_1159  1
    arc_1_6_19  original_T_including_depot_unload_1179  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_839  1
    load_1_6_19  segment_load_conservation_1104  1
    load_1_6_19  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_841  -25
    arc_1_6_20  connected_order_arc_842  -13
    arc_1_6_20  out_degree_1100  1
    arc_1_6_20  in_degree_1165  1
    arc_1_6_20  original_T_including_depot_unload_1179  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_841  1
    load_1_6_20  segment_load_conservation_1104  1
    load_1_6_20  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_21  arc_capacity_843  -25
    arc_1_6_21  connected_order_arc_844  -13
    arc_1_6_21  out_degree_1100  1
    arc_1_6_21  in_degree_1171  1
    arc_1_6_21  original_T_including_depot_unload_1179  2.1519454102199375e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_21  arc_capacity_843  1
    load_1_6_21  segment_load_conservation_1104  1
    load_1_6_21  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_845  -25
    arc_1_7_0  depot_return_or_bypass_1099  1
    arc_1_7_0  out_degree_1107  1
    arc_1_7_0  original_T_including_depot_unload_1179  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_845  1
    load_1_7_0  segment_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_846  -25
    arc_1_7_6  connected_order_arc_847  -13
    arc_1_7_6  in_degree_1101  1
    arc_1_7_6  out_degree_1107  1
    arc_1_7_6  original_T_including_depot_unload_1179  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_846  1
    load_1_7_6  segment_load_conservation_1104  -1
    load_1_7_6  segment_prefix_lb_1105  1
    load_1_7_6  segment_prefix_ub_1106  1
    load_1_7_6  segment_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_848  -25
    arc_1_7_8  connected_order_arc_849  -13
    arc_1_7_8  out_degree_1107  1
    arc_1_7_8  in_degree_1115  1
    arc_1_7_8  original_T_including_depot_unload_1179  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_848  1
    load_1_7_8  segment_load_conservation_1111  1
    load_1_7_8  segment_load_conservation_1118  -1
    load_1_7_8  segment_prefix_lb_1119  1
    load_1_7_8  segment_prefix_ub_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_850  -25
    arc_1_7_9  connected_order_arc_851  -13
    arc_1_7_9  out_degree_1107  1
    arc_1_7_9  in_degree_1122  1
    arc_1_7_9  original_T_including_depot_unload_1179  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_850  1
    load_1_7_9  segment_load_conservation_1111  1
    load_1_7_9  segment_load_conservation_1125  -1
    load_1_7_9  segment_prefix_lb_1126  1
    load_1_7_9  segment_prefix_ub_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_852  -25
    arc_1_7_14  connected_order_arc_853  -13
    arc_1_7_14  out_degree_1107  1
    arc_1_7_14  in_degree_1129  1
    arc_1_7_14  original_T_including_depot_unload_1179  1.8050468619497597e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_852  1
    load_1_7_14  segment_load_conservation_1111  1
    load_1_7_14  free_load_conservation_1133  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_854  -25
    arc_1_7_15  connected_order_arc_855  -13
    arc_1_7_15  out_degree_1107  1
    arc_1_7_15  in_degree_1135  1
    arc_1_7_15  original_T_including_depot_unload_1179  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_854  1
    load_1_7_15  segment_load_conservation_1111  1
    load_1_7_15  free_load_conservation_1139  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_856  -25
    arc_1_7_16  connected_order_arc_857  -13
    arc_1_7_16  out_degree_1107  1
    arc_1_7_16  in_degree_1141  1
    arc_1_7_16  original_T_including_depot_unload_1179  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_856  1
    load_1_7_16  segment_load_conservation_1111  1
    load_1_7_16  free_load_conservation_1145  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_858  -25
    arc_1_7_17  connected_order_arc_859  -13
    arc_1_7_17  out_degree_1107  1
    arc_1_7_17  in_degree_1147  1
    arc_1_7_17  original_T_including_depot_unload_1179  1.5951553402938971e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_858  1
    load_1_7_17  segment_load_conservation_1111  1
    load_1_7_17  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_860  -25
    arc_1_7_18  connected_order_arc_861  -13
    arc_1_7_18  out_degree_1107  1
    arc_1_7_18  in_degree_1153  1
    arc_1_7_18  original_T_including_depot_unload_1179  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_860  1
    load_1_7_18  segment_load_conservation_1111  1
    load_1_7_18  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_862  -25
    arc_1_7_19  connected_order_arc_863  -13
    arc_1_7_19  out_degree_1107  1
    arc_1_7_19  in_degree_1159  1
    arc_1_7_19  original_T_including_depot_unload_1179  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_862  1
    load_1_7_19  segment_load_conservation_1111  1
    load_1_7_19  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_864  -25
    arc_1_7_20  connected_order_arc_865  -13
    arc_1_7_20  out_degree_1107  1
    arc_1_7_20  in_degree_1165  1
    arc_1_7_20  original_T_including_depot_unload_1179  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_864  1
    load_1_7_20  segment_load_conservation_1111  1
    load_1_7_20  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_866  -25
    arc_1_7_21  connected_order_arc_867  -13
    arc_1_7_21  out_degree_1107  1
    arc_1_7_21  in_degree_1171  1
    arc_1_7_21  original_T_including_depot_unload_1179  1.6785246977297163e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_866  1
    load_1_7_21  segment_load_conservation_1111  1
    load_1_7_21  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_868  -25
    arc_1_8_0  depot_return_or_bypass_1099  1
    arc_1_8_0  out_degree_1114  1
    arc_1_8_0  original_T_including_depot_unload_1179  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_868  1
    load_1_8_0  segment_load_conservation_1118  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_869  -25
    arc_1_8_6  connected_order_arc_870  -13
    arc_1_8_6  in_degree_1101  1
    arc_1_8_6  out_degree_1114  1
    arc_1_8_6  original_T_including_depot_unload_1179  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_869  1
    load_1_8_6  segment_load_conservation_1104  -1
    load_1_8_6  segment_prefix_lb_1105  1
    load_1_8_6  segment_prefix_ub_1106  1
    load_1_8_6  segment_load_conservation_1118  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_871  -25
    arc_1_8_7  connected_order_arc_872  -13
    arc_1_8_7  in_degree_1108  1
    arc_1_8_7  out_degree_1114  1
    arc_1_8_7  original_T_including_depot_unload_1179  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_871  1
    load_1_8_7  segment_load_conservation_1111  -1
    load_1_8_7  segment_prefix_lb_1112  1
    load_1_8_7  segment_prefix_ub_1113  1
    load_1_8_7  segment_load_conservation_1118  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_873  -25
    arc_1_8_9  connected_order_arc_874  -13
    arc_1_8_9  out_degree_1114  1
    arc_1_8_9  in_degree_1122  1
    arc_1_8_9  original_T_including_depot_unload_1179  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_873  1
    load_1_8_9  segment_load_conservation_1118  1
    load_1_8_9  segment_load_conservation_1125  -1
    load_1_8_9  segment_prefix_lb_1126  1
    load_1_8_9  segment_prefix_ub_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_875  -25
    arc_1_8_14  connected_order_arc_876  -13
    arc_1_8_14  out_degree_1114  1
    arc_1_8_14  in_degree_1129  1
    arc_1_8_14  original_T_including_depot_unload_1179  1.5636076207019653e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_875  1
    load_1_8_14  segment_load_conservation_1118  1
    load_1_8_14  free_load_conservation_1133  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_877  -25
    arc_1_8_15  connected_order_arc_878  -13
    arc_1_8_15  out_degree_1114  1
    arc_1_8_15  in_degree_1135  1
    arc_1_8_15  original_T_including_depot_unload_1179  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_877  1
    load_1_8_15  segment_load_conservation_1118  1
    load_1_8_15  free_load_conservation_1139  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_879  -25
    arc_1_8_16  connected_order_arc_880  -13
    arc_1_8_16  out_degree_1114  1
    arc_1_8_16  in_degree_1141  1
    arc_1_8_16  original_T_including_depot_unload_1179  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_879  1
    load_1_8_16  segment_load_conservation_1118  1
    load_1_8_16  free_load_conservation_1145  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_881  -25
    arc_1_8_17  connected_order_arc_882  -13
    arc_1_8_17  out_degree_1114  1
    arc_1_8_17  in_degree_1147  1
    arc_1_8_17  original_T_including_depot_unload_1179  1.3608236268862893e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_881  1
    load_1_8_17  segment_load_conservation_1118  1
    load_1_8_17  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_883  -25
    arc_1_8_18  connected_order_arc_884  -13
    arc_1_8_18  out_degree_1114  1
    arc_1_8_18  in_degree_1153  1
    arc_1_8_18  original_T_including_depot_unload_1179  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_883  1
    load_1_8_18  segment_load_conservation_1118  1
    load_1_8_18  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_885  -25
    arc_1_8_19  connected_order_arc_886  -13
    arc_1_8_19  out_degree_1114  1
    arc_1_8_19  in_degree_1159  1
    arc_1_8_19  original_T_including_depot_unload_1179  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_885  1
    load_1_8_19  segment_load_conservation_1118  1
    load_1_8_19  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_887  -25
    arc_1_8_20  connected_order_arc_888  -13
    arc_1_8_20  out_degree_1114  1
    arc_1_8_20  in_degree_1165  1
    arc_1_8_20  original_T_including_depot_unload_1179  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_887  1
    load_1_8_20  segment_load_conservation_1118  1
    load_1_8_20  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_889  -25
    arc_1_8_21  connected_order_arc_890  -13
    arc_1_8_21  out_degree_1114  1
    arc_1_8_21  in_degree_1171  1
    arc_1_8_21  original_T_including_depot_unload_1179  1.4516198129136008e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_889  1
    load_1_8_21  segment_load_conservation_1118  1
    load_1_8_21  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_891  -25
    arc_1_9_0  depot_return_or_bypass_1099  1
    arc_1_9_0  out_degree_1121  1
    arc_1_9_0  original_T_including_depot_unload_1179  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_891  1
    load_1_9_0  segment_load_conservation_1125  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_892  -25
    arc_1_9_6  connected_order_arc_893  -13
    arc_1_9_6  in_degree_1101  1
    arc_1_9_6  out_degree_1121  1
    arc_1_9_6  original_T_including_depot_unload_1179  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_892  1
    load_1_9_6  segment_load_conservation_1104  -1
    load_1_9_6  segment_prefix_lb_1105  1
    load_1_9_6  segment_prefix_ub_1106  1
    load_1_9_6  segment_load_conservation_1125  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_894  -25
    arc_1_9_7  connected_order_arc_895  -13
    arc_1_9_7  in_degree_1108  1
    arc_1_9_7  out_degree_1121  1
    arc_1_9_7  original_T_including_depot_unload_1179  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_894  1
    load_1_9_7  segment_load_conservation_1111  -1
    load_1_9_7  segment_prefix_lb_1112  1
    load_1_9_7  segment_prefix_ub_1113  1
    load_1_9_7  segment_load_conservation_1125  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_896  -25
    arc_1_9_8  connected_order_arc_897  -13
    arc_1_9_8  in_degree_1115  1
    arc_1_9_8  out_degree_1121  1
    arc_1_9_8  original_T_including_depot_unload_1179  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_896  1
    load_1_9_8  segment_load_conservation_1118  -1
    load_1_9_8  segment_prefix_lb_1119  1
    load_1_9_8  segment_prefix_ub_1120  1
    load_1_9_8  segment_load_conservation_1125  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_898  -25
    arc_1_9_14  connected_order_arc_899  -13
    arc_1_9_14  out_degree_1121  1
    arc_1_9_14  in_degree_1129  1
    arc_1_9_14  original_T_including_depot_unload_1179  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_898  1
    load_1_9_14  segment_load_conservation_1125  1
    load_1_9_14  free_load_conservation_1133  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_900  -25
    arc_1_9_15  connected_order_arc_901  -13
    arc_1_9_15  out_degree_1121  1
    arc_1_9_15  in_degree_1135  1
    arc_1_9_15  original_T_including_depot_unload_1179  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_900  1
    load_1_9_15  segment_load_conservation_1125  1
    load_1_9_15  free_load_conservation_1139  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_902  -25
    arc_1_9_16  connected_order_arc_903  -13
    arc_1_9_16  out_degree_1121  1
    arc_1_9_16  in_degree_1141  1
    arc_1_9_16  original_T_including_depot_unload_1179  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_902  1
    load_1_9_16  segment_load_conservation_1125  1
    load_1_9_16  free_load_conservation_1145  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_904  -25
    arc_1_9_17  connected_order_arc_905  -13
    arc_1_9_17  out_degree_1121  1
    arc_1_9_17  in_degree_1147  1
    arc_1_9_17  original_T_including_depot_unload_1179  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_904  1
    load_1_9_17  segment_load_conservation_1125  1
    load_1_9_17  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_906  -25
    arc_1_9_18  connected_order_arc_907  -13
    arc_1_9_18  out_degree_1121  1
    arc_1_9_18  in_degree_1153  1
    arc_1_9_18  original_T_including_depot_unload_1179  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_906  1
    load_1_9_18  segment_load_conservation_1125  1
    load_1_9_18  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_908  -25
    arc_1_9_19  connected_order_arc_909  -13
    arc_1_9_19  out_degree_1121  1
    arc_1_9_19  in_degree_1159  1
    arc_1_9_19  original_T_including_depot_unload_1179  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_908  1
    load_1_9_19  segment_load_conservation_1125  1
    load_1_9_19  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_910  -25
    arc_1_9_20  connected_order_arc_911  -13
    arc_1_9_20  out_degree_1121  1
    arc_1_9_20  in_degree_1165  1
    arc_1_9_20  original_T_including_depot_unload_1179  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_910  1
    load_1_9_20  segment_load_conservation_1125  1
    load_1_9_20  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_912  -25
    arc_1_9_21  connected_order_arc_913  -13
    arc_1_9_21  out_degree_1121  1
    arc_1_9_21  in_degree_1171  1
    arc_1_9_21  original_T_including_depot_unload_1179  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_912  1
    load_1_9_21  segment_load_conservation_1125  1
    load_1_9_21  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_914  -25
    arc_1_14_0  depot_return_or_bypass_1099  1
    arc_1_14_0  out_degree_1128  1
    arc_1_14_0  original_T_including_depot_unload_1179  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_914  1
    load_1_14_0  free_load_conservation_1133  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_915  -25
    arc_1_14_6  connected_order_arc_916  -13
    arc_1_14_6  in_degree_1101  1
    arc_1_14_6  out_degree_1128  1
    arc_1_14_6  original_T_including_depot_unload_1179  2.0204177348160229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_915  1
    load_1_14_6  segment_load_conservation_1104  -1
    load_1_14_6  segment_prefix_lb_1105  1
    load_1_14_6  segment_prefix_ub_1106  1
    load_1_14_6  free_load_conservation_1133  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_917  -25
    arc_1_14_7  connected_order_arc_918  -13
    arc_1_14_7  in_degree_1108  1
    arc_1_14_7  out_degree_1128  1
    arc_1_14_7  original_T_including_depot_unload_1179  1.8250469514445369e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_917  1
    load_1_14_7  segment_load_conservation_1111  -1
    load_1_14_7  segment_prefix_lb_1112  1
    load_1_14_7  segment_prefix_ub_1113  1
    load_1_14_7  free_load_conservation_1133  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_919  -25
    arc_1_14_8  connected_order_arc_920  -13
    arc_1_14_8  in_degree_1115  1
    arc_1_14_8  out_degree_1128  1
    arc_1_14_8  original_T_including_depot_unload_1179  1.5636076207019653e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_919  1
    load_1_14_8  segment_load_conservation_1118  -1
    load_1_14_8  segment_prefix_lb_1119  1
    load_1_14_8  segment_prefix_ub_1120  1
    load_1_14_8  free_load_conservation_1133  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_921  -25
    arc_1_14_9  connected_order_arc_922  -13
    arc_1_14_9  in_degree_1122  1
    arc_1_14_9  out_degree_1128  1
    arc_1_14_9  original_T_including_depot_unload_1179  1.9912760202020529e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_921  1
    load_1_14_9  segment_load_conservation_1125  -1
    load_1_14_9  segment_prefix_lb_1126  1
    load_1_14_9  segment_prefix_ub_1127  1
    load_1_14_9  free_load_conservation_1133  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_923  -25
    arc_1_14_15  connected_order_arc_924  -13
    arc_1_14_15  out_degree_1128  1
    arc_1_14_15  in_degree_1135  1
    arc_1_14_15  original_T_including_depot_unload_1179  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_923  1
    load_1_14_15  free_load_conservation_1133  1
    load_1_14_15  free_load_conservation_1139  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_925  -25
    arc_1_14_16  connected_order_arc_926  -13
    arc_1_14_16  out_degree_1128  1
    arc_1_14_16  in_degree_1141  1
    arc_1_14_16  original_T_including_depot_unload_1179  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_925  1
    load_1_14_16  free_load_conservation_1133  1
    load_1_14_16  free_load_conservation_1145  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_927  -25
    arc_1_14_17  connected_order_arc_928  -13
    arc_1_14_17  out_degree_1128  1
    arc_1_14_17  in_degree_1147  1
    arc_1_14_17  original_T_including_depot_unload_1179  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_927  1
    load_1_14_17  free_load_conservation_1133  1
    load_1_14_17  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_929  -25
    arc_1_14_18  connected_order_arc_930  -13
    arc_1_14_18  out_degree_1128  1
    arc_1_14_18  in_degree_1153  1
    arc_1_14_18  original_T_including_depot_unload_1179  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_929  1
    load_1_14_18  free_load_conservation_1133  1
    load_1_14_18  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_931  -25
    arc_1_14_19  connected_order_arc_932  -13
    arc_1_14_19  out_degree_1128  1
    arc_1_14_19  in_degree_1159  1
    arc_1_14_19  original_T_including_depot_unload_1179  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_931  1
    load_1_14_19  free_load_conservation_1133  1
    load_1_14_19  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_933  -25
    arc_1_14_20  connected_order_arc_934  -13
    arc_1_14_20  out_degree_1128  1
    arc_1_14_20  in_degree_1165  1
    arc_1_14_20  original_T_including_depot_unload_1179  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_933  1
    load_1_14_20  free_load_conservation_1133  1
    load_1_14_20  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_21  arc_capacity_935  -25
    arc_1_14_21  connected_order_arc_936  -13
    arc_1_14_21  out_degree_1128  1
    arc_1_14_21  in_degree_1171  1
    arc_1_14_21  original_T_including_depot_unload_1179  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_21  arc_capacity_935  1
    load_1_14_21  free_load_conservation_1133  1
    load_1_14_21  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_937  -25
    arc_1_15_0  depot_return_or_bypass_1099  1
    arc_1_15_0  out_degree_1134  1
    arc_1_15_0  original_T_including_depot_unload_1179  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_937  1
    load_1_15_0  free_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_938  -25
    arc_1_15_6  connected_order_arc_939  -13
    arc_1_15_6  in_degree_1101  1
    arc_1_15_6  out_degree_1134  1
    arc_1_15_6  original_T_including_depot_unload_1179  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_938  1
    load_1_15_6  segment_load_conservation_1104  -1
    load_1_15_6  segment_prefix_lb_1105  1
    load_1_15_6  segment_prefix_ub_1106  1
    load_1_15_6  free_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_940  -25
    arc_1_15_7  connected_order_arc_941  -13
    arc_1_15_7  in_degree_1108  1
    arc_1_15_7  out_degree_1134  1
    arc_1_15_7  original_T_including_depot_unload_1179  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_940  1
    load_1_15_7  segment_load_conservation_1111  -1
    load_1_15_7  segment_prefix_lb_1112  1
    load_1_15_7  segment_prefix_ub_1113  1
    load_1_15_7  free_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_942  -25
    arc_1_15_8  connected_order_arc_943  -13
    arc_1_15_8  in_degree_1115  1
    arc_1_15_8  out_degree_1134  1
    arc_1_15_8  original_T_including_depot_unload_1179  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_942  1
    load_1_15_8  segment_load_conservation_1118  -1
    load_1_15_8  segment_prefix_lb_1119  1
    load_1_15_8  segment_prefix_ub_1120  1
    load_1_15_8  free_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_944  -25
    arc_1_15_9  connected_order_arc_945  -13
    arc_1_15_9  in_degree_1122  1
    arc_1_15_9  out_degree_1134  1
    arc_1_15_9  original_T_including_depot_unload_1179  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_944  1
    load_1_15_9  segment_load_conservation_1125  -1
    load_1_15_9  segment_prefix_lb_1126  1
    load_1_15_9  segment_prefix_ub_1127  1
    load_1_15_9  free_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_946  -25
    arc_1_15_14  connected_order_arc_947  -13
    arc_1_15_14  in_degree_1129  1
    arc_1_15_14  out_degree_1134  1
    arc_1_15_14  original_T_including_depot_unload_1179  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_946  1
    load_1_15_14  free_load_conservation_1133  -1
    load_1_15_14  free_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_948  -25
    arc_1_15_16  connected_order_arc_949  -13
    arc_1_15_16  out_degree_1134  1
    arc_1_15_16  in_degree_1141  1
    arc_1_15_16  original_T_including_depot_unload_1179  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_948  1
    load_1_15_16  free_load_conservation_1139  1
    load_1_15_16  free_load_conservation_1145  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_950  -25
    arc_1_15_17  connected_order_arc_951  -13
    arc_1_15_17  out_degree_1134  1
    arc_1_15_17  in_degree_1147  1
    arc_1_15_17  original_T_including_depot_unload_1179  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_950  1
    load_1_15_17  free_load_conservation_1139  1
    load_1_15_17  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_952  -25
    arc_1_15_18  connected_order_arc_953  -13
    arc_1_15_18  out_degree_1134  1
    arc_1_15_18  in_degree_1153  1
    arc_1_15_18  original_T_including_depot_unload_1179  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_952  1
    load_1_15_18  free_load_conservation_1139  1
    load_1_15_18  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_954  -25
    arc_1_15_19  connected_order_arc_955  -13
    arc_1_15_19  out_degree_1134  1
    arc_1_15_19  in_degree_1159  1
    arc_1_15_19  original_T_including_depot_unload_1179  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_954  1
    load_1_15_19  free_load_conservation_1139  1
    load_1_15_19  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_956  -25
    arc_1_15_20  connected_order_arc_957  -13
    arc_1_15_20  out_degree_1134  1
    arc_1_15_20  in_degree_1165  1
    arc_1_15_20  original_T_including_depot_unload_1179  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_956  1
    load_1_15_20  free_load_conservation_1139  1
    load_1_15_20  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_958  -25
    arc_1_15_21  connected_order_arc_959  -13
    arc_1_15_21  out_degree_1134  1
    arc_1_15_21  in_degree_1171  1
    arc_1_15_21  original_T_including_depot_unload_1179  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_958  1
    load_1_15_21  free_load_conservation_1139  1
    load_1_15_21  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_960  -25
    arc_1_16_0  depot_return_or_bypass_1099  1
    arc_1_16_0  out_degree_1140  1
    arc_1_16_0  original_T_including_depot_unload_1179  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_960  1
    load_1_16_0  free_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_961  -25
    arc_1_16_6  connected_order_arc_962  -13
    arc_1_16_6  in_degree_1101  1
    arc_1_16_6  out_degree_1140  1
    arc_1_16_6  original_T_including_depot_unload_1179  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_961  1
    load_1_16_6  segment_load_conservation_1104  -1
    load_1_16_6  segment_prefix_lb_1105  1
    load_1_16_6  segment_prefix_ub_1106  1
    load_1_16_6  free_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_963  -25
    arc_1_16_7  connected_order_arc_964  -13
    arc_1_16_7  in_degree_1108  1
    arc_1_16_7  out_degree_1140  1
    arc_1_16_7  original_T_including_depot_unload_1179  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_963  1
    load_1_16_7  segment_load_conservation_1111  -1
    load_1_16_7  segment_prefix_lb_1112  1
    load_1_16_7  segment_prefix_ub_1113  1
    load_1_16_7  free_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_965  -25
    arc_1_16_8  connected_order_arc_966  -13
    arc_1_16_8  in_degree_1115  1
    arc_1_16_8  out_degree_1140  1
    arc_1_16_8  original_T_including_depot_unload_1179  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_965  1
    load_1_16_8  segment_load_conservation_1118  -1
    load_1_16_8  segment_prefix_lb_1119  1
    load_1_16_8  segment_prefix_ub_1120  1
    load_1_16_8  free_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_967  -25
    arc_1_16_9  connected_order_arc_968  -13
    arc_1_16_9  in_degree_1122  1
    arc_1_16_9  out_degree_1140  1
    arc_1_16_9  original_T_including_depot_unload_1179  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_967  1
    load_1_16_9  segment_load_conservation_1125  -1
    load_1_16_9  segment_prefix_lb_1126  1
    load_1_16_9  segment_prefix_ub_1127  1
    load_1_16_9  free_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_969  -25
    arc_1_16_14  connected_order_arc_970  -13
    arc_1_16_14  in_degree_1129  1
    arc_1_16_14  out_degree_1140  1
    arc_1_16_14  original_T_including_depot_unload_1179  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_969  1
    load_1_16_14  free_load_conservation_1133  -1
    load_1_16_14  free_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_971  -25
    arc_1_16_15  connected_order_arc_972  -13
    arc_1_16_15  in_degree_1135  1
    arc_1_16_15  out_degree_1140  1
    arc_1_16_15  original_T_including_depot_unload_1179  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_971  1
    load_1_16_15  free_load_conservation_1139  -1
    load_1_16_15  free_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_973  -25
    arc_1_16_17  connected_order_arc_974  -13
    arc_1_16_17  out_degree_1140  1
    arc_1_16_17  in_degree_1147  1
    arc_1_16_17  original_T_including_depot_unload_1179  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_973  1
    load_1_16_17  free_load_conservation_1145  1
    load_1_16_17  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_975  -25
    arc_1_16_18  connected_order_arc_976  -13
    arc_1_16_18  out_degree_1140  1
    arc_1_16_18  in_degree_1153  1
    arc_1_16_18  original_T_including_depot_unload_1179  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_975  1
    load_1_16_18  free_load_conservation_1145  1
    load_1_16_18  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_977  -25
    arc_1_16_19  connected_order_arc_978  -13
    arc_1_16_19  out_degree_1140  1
    arc_1_16_19  in_degree_1159  1
    arc_1_16_19  original_T_including_depot_unload_1179  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_977  1
    load_1_16_19  free_load_conservation_1145  1
    load_1_16_19  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_979  -25
    arc_1_16_20  connected_order_arc_980  -13
    arc_1_16_20  out_degree_1140  1
    arc_1_16_20  in_degree_1165  1
    arc_1_16_20  original_T_including_depot_unload_1179  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_979  1
    load_1_16_20  free_load_conservation_1145  1
    load_1_16_20  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_981  -25
    arc_1_16_21  connected_order_arc_982  -13
    arc_1_16_21  out_degree_1140  1
    arc_1_16_21  in_degree_1171  1
    arc_1_16_21  original_T_including_depot_unload_1179  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_981  1
    load_1_16_21  free_load_conservation_1145  1
    load_1_16_21  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_983  -25
    arc_1_17_0  depot_return_or_bypass_1099  1
    arc_1_17_0  out_degree_1146  1
    arc_1_17_0  original_T_including_depot_unload_1179  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_983  1
    load_1_17_0  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_984  -25
    arc_1_17_6  connected_order_arc_985  -13
    arc_1_17_6  in_degree_1101  1
    arc_1_17_6  out_degree_1146  1
    arc_1_17_6  original_T_including_depot_unload_1179  2.0027314450664605e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_984  1
    load_1_17_6  segment_load_conservation_1104  -1
    load_1_17_6  segment_prefix_lb_1105  1
    load_1_17_6  segment_prefix_ub_1106  1
    load_1_17_6  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_986  -25
    arc_1_17_7  connected_order_arc_987  -13
    arc_1_17_7  in_degree_1108  1
    arc_1_17_7  out_degree_1146  1
    arc_1_17_7  original_T_including_depot_unload_1179  1.6726682877661206e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_986  1
    load_1_17_7  segment_load_conservation_1111  -1
    load_1_17_7  segment_prefix_lb_1112  1
    load_1_17_7  segment_prefix_ub_1113  1
    load_1_17_7  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_988  -25
    arc_1_17_8  connected_order_arc_989  -13
    arc_1_17_8  in_degree_1115  1
    arc_1_17_8  out_degree_1146  1
    arc_1_17_8  original_T_including_depot_unload_1179  1.3608236268862893e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_988  1
    load_1_17_8  segment_load_conservation_1118  -1
    load_1_17_8  segment_prefix_lb_1119  1
    load_1_17_8  segment_prefix_ub_1120  1
    load_1_17_8  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_990  -25
    arc_1_17_9  connected_order_arc_991  -13
    arc_1_17_9  in_degree_1122  1
    arc_1_17_9  out_degree_1146  1
    arc_1_17_9  original_T_including_depot_unload_1179  1.8375396100269363e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_990  1
    load_1_17_9  segment_load_conservation_1125  -1
    load_1_17_9  segment_prefix_lb_1126  1
    load_1_17_9  segment_prefix_ub_1127  1
    load_1_17_9  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_992  -25
    arc_1_17_14  connected_order_arc_993  -13
    arc_1_17_14  in_degree_1129  1
    arc_1_17_14  out_degree_1146  1
    arc_1_17_14  original_T_including_depot_unload_1179  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_992  1
    load_1_17_14  free_load_conservation_1133  -1
    load_1_17_14  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_994  -25
    arc_1_17_15  connected_order_arc_995  -13
    arc_1_17_15  in_degree_1135  1
    arc_1_17_15  out_degree_1146  1
    arc_1_17_15  original_T_including_depot_unload_1179  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_994  1
    load_1_17_15  free_load_conservation_1139  -1
    load_1_17_15  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_996  -25
    arc_1_17_16  connected_order_arc_997  -13
    arc_1_17_16  in_degree_1141  1
    arc_1_17_16  out_degree_1146  1
    arc_1_17_16  original_T_including_depot_unload_1179  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_996  1
    load_1_17_16  free_load_conservation_1145  -1
    load_1_17_16  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_998  -25
    arc_1_17_18  connected_order_arc_999  -13
    arc_1_17_18  out_degree_1146  1
    arc_1_17_18  in_degree_1153  1
    arc_1_17_18  original_T_including_depot_unload_1179  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_998  1
    load_1_17_18  free_load_conservation_1151  1
    load_1_17_18  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1000  -25
    arc_1_17_19  connected_order_arc_1001  -13
    arc_1_17_19  out_degree_1146  1
    arc_1_17_19  in_degree_1159  1
    arc_1_17_19  original_T_including_depot_unload_1179  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1000  1
    load_1_17_19  free_load_conservation_1151  1
    load_1_17_19  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1002  -25
    arc_1_17_20  connected_order_arc_1003  -13
    arc_1_17_20  out_degree_1146  1
    arc_1_17_20  in_degree_1165  1
    arc_1_17_20  original_T_including_depot_unload_1179  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1002  1
    load_1_17_20  free_load_conservation_1151  1
    load_1_17_20  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1004  -25
    arc_1_17_21  connected_order_arc_1005  -13
    arc_1_17_21  out_degree_1146  1
    arc_1_17_21  in_degree_1171  1
    arc_1_17_21  original_T_including_depot_unload_1179  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1004  1
    load_1_17_21  free_load_conservation_1151  1
    load_1_17_21  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1006  -25
    arc_1_18_0  depot_return_or_bypass_1099  1
    arc_1_18_0  out_degree_1152  1
    arc_1_18_0  original_T_including_depot_unload_1179  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1006  1
    load_1_18_0  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1007  -25
    arc_1_18_6  connected_order_arc_1008  -13
    arc_1_18_6  in_degree_1101  1
    arc_1_18_6  out_degree_1152  1
    arc_1_18_6  original_T_including_depot_unload_1179  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1007  1
    load_1_18_6  segment_load_conservation_1104  -1
    load_1_18_6  segment_prefix_lb_1105  1
    load_1_18_6  segment_prefix_ub_1106  1
    load_1_18_6  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1009  -25
    arc_1_18_7  connected_order_arc_1010  -13
    arc_1_18_7  in_degree_1108  1
    arc_1_18_7  out_degree_1152  1
    arc_1_18_7  original_T_including_depot_unload_1179  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1009  1
    load_1_18_7  segment_load_conservation_1111  -1
    load_1_18_7  segment_prefix_lb_1112  1
    load_1_18_7  segment_prefix_ub_1113  1
    load_1_18_7  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1011  -25
    arc_1_18_8  connected_order_arc_1012  -13
    arc_1_18_8  in_degree_1115  1
    arc_1_18_8  out_degree_1152  1
    arc_1_18_8  original_T_including_depot_unload_1179  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1011  1
    load_1_18_8  segment_load_conservation_1118  -1
    load_1_18_8  segment_prefix_lb_1119  1
    load_1_18_8  segment_prefix_ub_1120  1
    load_1_18_8  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1013  -25
    arc_1_18_9  connected_order_arc_1014  -13
    arc_1_18_9  in_degree_1122  1
    arc_1_18_9  out_degree_1152  1
    arc_1_18_9  original_T_including_depot_unload_1179  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1013  1
    load_1_18_9  segment_load_conservation_1125  -1
    load_1_18_9  segment_prefix_lb_1126  1
    load_1_18_9  segment_prefix_ub_1127  1
    load_1_18_9  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1015  -25
    arc_1_18_14  connected_order_arc_1016  -13
    arc_1_18_14  in_degree_1129  1
    arc_1_18_14  out_degree_1152  1
    arc_1_18_14  original_T_including_depot_unload_1179  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1015  1
    load_1_18_14  free_load_conservation_1133  -1
    load_1_18_14  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1017  -25
    arc_1_18_15  connected_order_arc_1018  -13
    arc_1_18_15  in_degree_1135  1
    arc_1_18_15  out_degree_1152  1
    arc_1_18_15  original_T_including_depot_unload_1179  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1017  1
    load_1_18_15  free_load_conservation_1139  -1
    load_1_18_15  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1019  -25
    arc_1_18_16  connected_order_arc_1020  -13
    arc_1_18_16  in_degree_1141  1
    arc_1_18_16  out_degree_1152  1
    arc_1_18_16  original_T_including_depot_unload_1179  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1019  1
    load_1_18_16  free_load_conservation_1145  -1
    load_1_18_16  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1021  -25
    arc_1_18_17  connected_order_arc_1022  -13
    arc_1_18_17  in_degree_1147  1
    arc_1_18_17  out_degree_1152  1
    arc_1_18_17  original_T_including_depot_unload_1179  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1021  1
    load_1_18_17  free_load_conservation_1151  -1
    load_1_18_17  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1023  -25
    arc_1_18_19  connected_order_arc_1024  -13
    arc_1_18_19  out_degree_1152  1
    arc_1_18_19  in_degree_1159  1
    arc_1_18_19  original_T_including_depot_unload_1179  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1023  1
    load_1_18_19  free_load_conservation_1157  1
    load_1_18_19  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1025  -25
    arc_1_18_20  connected_order_arc_1026  -13
    arc_1_18_20  out_degree_1152  1
    arc_1_18_20  in_degree_1165  1
    arc_1_18_20  original_T_including_depot_unload_1179  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1025  1
    load_1_18_20  free_load_conservation_1157  1
    load_1_18_20  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1027  -25
    arc_1_18_21  connected_order_arc_1028  -13
    arc_1_18_21  out_degree_1152  1
    arc_1_18_21  in_degree_1171  1
    arc_1_18_21  original_T_including_depot_unload_1179  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1027  1
    load_1_18_21  free_load_conservation_1157  1
    load_1_18_21  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1029  -25
    arc_1_19_0  depot_return_or_bypass_1099  1
    arc_1_19_0  out_degree_1158  1
    arc_1_19_0  original_T_including_depot_unload_1179  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1029  1
    load_1_19_0  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1030  -25
    arc_1_19_6  connected_order_arc_1031  -13
    arc_1_19_6  in_degree_1101  1
    arc_1_19_6  out_degree_1158  1
    arc_1_19_6  original_T_including_depot_unload_1179  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1030  1
    load_1_19_6  segment_load_conservation_1104  -1
    load_1_19_6  segment_prefix_lb_1105  1
    load_1_19_6  segment_prefix_ub_1106  1
    load_1_19_6  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1032  -25
    arc_1_19_7  connected_order_arc_1033  -13
    arc_1_19_7  in_degree_1108  1
    arc_1_19_7  out_degree_1158  1
    arc_1_19_7  original_T_including_depot_unload_1179  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1032  1
    load_1_19_7  segment_load_conservation_1111  -1
    load_1_19_7  segment_prefix_lb_1112  1
    load_1_19_7  segment_prefix_ub_1113  1
    load_1_19_7  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1034  -25
    arc_1_19_8  connected_order_arc_1035  -13
    arc_1_19_8  in_degree_1115  1
    arc_1_19_8  out_degree_1158  1
    arc_1_19_8  original_T_including_depot_unload_1179  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1034  1
    load_1_19_8  segment_load_conservation_1118  -1
    load_1_19_8  segment_prefix_lb_1119  1
    load_1_19_8  segment_prefix_ub_1120  1
    load_1_19_8  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1036  -25
    arc_1_19_9  connected_order_arc_1037  -13
    arc_1_19_9  in_degree_1122  1
    arc_1_19_9  out_degree_1158  1
    arc_1_19_9  original_T_including_depot_unload_1179  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1036  1
    load_1_19_9  segment_load_conservation_1125  -1
    load_1_19_9  segment_prefix_lb_1126  1
    load_1_19_9  segment_prefix_ub_1127  1
    load_1_19_9  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1038  -25
    arc_1_19_14  connected_order_arc_1039  -13
    arc_1_19_14  in_degree_1129  1
    arc_1_19_14  out_degree_1158  1
    arc_1_19_14  original_T_including_depot_unload_1179  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1038  1
    load_1_19_14  free_load_conservation_1133  -1
    load_1_19_14  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1040  -25
    arc_1_19_15  connected_order_arc_1041  -13
    arc_1_19_15  in_degree_1135  1
    arc_1_19_15  out_degree_1158  1
    arc_1_19_15  original_T_including_depot_unload_1179  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1040  1
    load_1_19_15  free_load_conservation_1139  -1
    load_1_19_15  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1042  -25
    arc_1_19_16  connected_order_arc_1043  -13
    arc_1_19_16  in_degree_1141  1
    arc_1_19_16  out_degree_1158  1
    arc_1_19_16  original_T_including_depot_unload_1179  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1042  1
    load_1_19_16  free_load_conservation_1145  -1
    load_1_19_16  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1044  -25
    arc_1_19_17  connected_order_arc_1045  -13
    arc_1_19_17  in_degree_1147  1
    arc_1_19_17  out_degree_1158  1
    arc_1_19_17  original_T_including_depot_unload_1179  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1044  1
    load_1_19_17  free_load_conservation_1151  -1
    load_1_19_17  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1046  -25
    arc_1_19_18  connected_order_arc_1047  -13
    arc_1_19_18  in_degree_1153  1
    arc_1_19_18  out_degree_1158  1
    arc_1_19_18  original_T_including_depot_unload_1179  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1046  1
    load_1_19_18  free_load_conservation_1157  -1
    load_1_19_18  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1048  -25
    arc_1_19_20  connected_order_arc_1049  -13
    arc_1_19_20  out_degree_1158  1
    arc_1_19_20  in_degree_1165  1
    arc_1_19_20  original_T_including_depot_unload_1179  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1048  1
    load_1_19_20  free_load_conservation_1163  1
    load_1_19_20  free_load_conservation_1169  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1050  -25
    arc_1_19_21  connected_order_arc_1051  -13
    arc_1_19_21  out_degree_1158  1
    arc_1_19_21  in_degree_1171  1
    arc_1_19_21  original_T_including_depot_unload_1179  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1050  1
    load_1_19_21  free_load_conservation_1163  1
    load_1_19_21  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1052  -25
    arc_1_20_0  depot_return_or_bypass_1099  1
    arc_1_20_0  out_degree_1164  1
    arc_1_20_0  original_T_including_depot_unload_1179  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1052  1
    load_1_20_0  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1053  -25
    arc_1_20_6  connected_order_arc_1054  -13
    arc_1_20_6  in_degree_1101  1
    arc_1_20_6  out_degree_1164  1
    arc_1_20_6  original_T_including_depot_unload_1179  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1053  1
    load_1_20_6  segment_load_conservation_1104  -1
    load_1_20_6  segment_prefix_lb_1105  1
    load_1_20_6  segment_prefix_ub_1106  1
    load_1_20_6  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1055  -25
    arc_1_20_7  connected_order_arc_1056  -13
    arc_1_20_7  in_degree_1108  1
    arc_1_20_7  out_degree_1164  1
    arc_1_20_7  original_T_including_depot_unload_1179  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1055  1
    load_1_20_7  segment_load_conservation_1111  -1
    load_1_20_7  segment_prefix_lb_1112  1
    load_1_20_7  segment_prefix_ub_1113  1
    load_1_20_7  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1057  -25
    arc_1_20_8  connected_order_arc_1058  -13
    arc_1_20_8  in_degree_1115  1
    arc_1_20_8  out_degree_1164  1
    arc_1_20_8  original_T_including_depot_unload_1179  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1057  1
    load_1_20_8  segment_load_conservation_1118  -1
    load_1_20_8  segment_prefix_lb_1119  1
    load_1_20_8  segment_prefix_ub_1120  1
    load_1_20_8  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1059  -25
    arc_1_20_9  connected_order_arc_1060  -13
    arc_1_20_9  in_degree_1122  1
    arc_1_20_9  out_degree_1164  1
    arc_1_20_9  original_T_including_depot_unload_1179  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1059  1
    load_1_20_9  segment_load_conservation_1125  -1
    load_1_20_9  segment_prefix_lb_1126  1
    load_1_20_9  segment_prefix_ub_1127  1
    load_1_20_9  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1061  -25
    arc_1_20_14  connected_order_arc_1062  -13
    arc_1_20_14  in_degree_1129  1
    arc_1_20_14  out_degree_1164  1
    arc_1_20_14  original_T_including_depot_unload_1179  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1061  1
    load_1_20_14  free_load_conservation_1133  -1
    load_1_20_14  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1063  -25
    arc_1_20_15  connected_order_arc_1064  -13
    arc_1_20_15  in_degree_1135  1
    arc_1_20_15  out_degree_1164  1
    arc_1_20_15  original_T_including_depot_unload_1179  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1063  1
    load_1_20_15  free_load_conservation_1139  -1
    load_1_20_15  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1065  -25
    arc_1_20_16  connected_order_arc_1066  -13
    arc_1_20_16  in_degree_1141  1
    arc_1_20_16  out_degree_1164  1
    arc_1_20_16  original_T_including_depot_unload_1179  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1065  1
    load_1_20_16  free_load_conservation_1145  -1
    load_1_20_16  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1067  -25
    arc_1_20_17  connected_order_arc_1068  -13
    arc_1_20_17  in_degree_1147  1
    arc_1_20_17  out_degree_1164  1
    arc_1_20_17  original_T_including_depot_unload_1179  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1067  1
    load_1_20_17  free_load_conservation_1151  -1
    load_1_20_17  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1069  -25
    arc_1_20_18  connected_order_arc_1070  -13
    arc_1_20_18  in_degree_1153  1
    arc_1_20_18  out_degree_1164  1
    arc_1_20_18  original_T_including_depot_unload_1179  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1069  1
    load_1_20_18  free_load_conservation_1157  -1
    load_1_20_18  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1071  -25
    arc_1_20_19  connected_order_arc_1072  -13
    arc_1_20_19  in_degree_1159  1
    arc_1_20_19  out_degree_1164  1
    arc_1_20_19  original_T_including_depot_unload_1179  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1071  1
    load_1_20_19  free_load_conservation_1163  -1
    load_1_20_19  free_load_conservation_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1073  -25
    arc_1_20_21  connected_order_arc_1074  -13
    arc_1_20_21  out_degree_1164  1
    arc_1_20_21  in_degree_1171  1
    arc_1_20_21  original_T_including_depot_unload_1179  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1073  1
    load_1_20_21  free_load_conservation_1169  1
    load_1_20_21  free_load_conservation_1175  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1075  -25
    arc_1_21_0  depot_return_or_bypass_1099  1
    arc_1_21_0  out_degree_1170  1
    arc_1_21_0  original_T_including_depot_unload_1179  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1075  1
    load_1_21_0  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_6  arc_capacity_1076  -25
    arc_1_21_6  connected_order_arc_1077  -13
    arc_1_21_6  in_degree_1101  1
    arc_1_21_6  out_degree_1170  1
    arc_1_21_6  original_T_including_depot_unload_1179  2.1519454102199375e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_6  arc_capacity_1076  1
    load_1_21_6  segment_load_conservation_1104  -1
    load_1_21_6  segment_prefix_lb_1105  1
    load_1_21_6  segment_prefix_ub_1106  1
    load_1_21_6  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1078  -25
    arc_1_21_7  connected_order_arc_1079  -13
    arc_1_21_7  in_degree_1108  1
    arc_1_21_7  out_degree_1170  1
    arc_1_21_7  original_T_including_depot_unload_1179  1.7809992976396034e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1078  1
    load_1_21_7  segment_load_conservation_1111  -1
    load_1_21_7  segment_prefix_lb_1112  1
    load_1_21_7  segment_prefix_ub_1113  1
    load_1_21_7  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1080  -25
    arc_1_21_8  connected_order_arc_1081  -13
    arc_1_21_8  in_degree_1115  1
    arc_1_21_8  out_degree_1170  1
    arc_1_21_8  original_T_including_depot_unload_1179  1.4516198129136008e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1080  1
    load_1_21_8  segment_load_conservation_1118  -1
    load_1_21_8  segment_prefix_lb_1119  1
    load_1_21_8  segment_prefix_ub_1120  1
    load_1_21_8  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1082  -25
    arc_1_21_9  connected_order_arc_1083  -13
    arc_1_21_9  in_degree_1122  1
    arc_1_21_9  out_degree_1170  1
    arc_1_21_9  original_T_including_depot_unload_1179  1.9434430494183746e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1082  1
    load_1_21_9  segment_load_conservation_1125  -1
    load_1_21_9  segment_prefix_lb_1126  1
    load_1_21_9  segment_prefix_ub_1127  1
    load_1_21_9  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_14  arc_capacity_1084  -25
    arc_1_21_14  connected_order_arc_1085  -13
    arc_1_21_14  in_degree_1129  1
    arc_1_21_14  out_degree_1170  1
    arc_1_21_14  original_T_including_depot_unload_1179  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_14  arc_capacity_1084  1
    load_1_21_14  free_load_conservation_1133  -1
    load_1_21_14  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1086  -25
    arc_1_21_15  connected_order_arc_1087  -13
    arc_1_21_15  in_degree_1135  1
    arc_1_21_15  out_degree_1170  1
    arc_1_21_15  original_T_including_depot_unload_1179  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1086  1
    load_1_21_15  free_load_conservation_1139  -1
    load_1_21_15  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1088  -25
    arc_1_21_16  connected_order_arc_1089  -13
    arc_1_21_16  in_degree_1141  1
    arc_1_21_16  out_degree_1170  1
    arc_1_21_16  original_T_including_depot_unload_1179  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1088  1
    load_1_21_16  free_load_conservation_1145  -1
    load_1_21_16  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1090  -25
    arc_1_21_17  connected_order_arc_1091  -13
    arc_1_21_17  in_degree_1147  1
    arc_1_21_17  out_degree_1170  1
    arc_1_21_17  original_T_including_depot_unload_1179  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1090  1
    load_1_21_17  free_load_conservation_1151  -1
    load_1_21_17  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1092  -25
    arc_1_21_18  connected_order_arc_1093  -13
    arc_1_21_18  in_degree_1153  1
    arc_1_21_18  out_degree_1170  1
    arc_1_21_18  original_T_including_depot_unload_1179  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1092  1
    load_1_21_18  free_load_conservation_1157  -1
    load_1_21_18  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1094  -25
    arc_1_21_19  connected_order_arc_1095  -13
    arc_1_21_19  in_degree_1159  1
    arc_1_21_19  out_degree_1170  1
    arc_1_21_19  original_T_including_depot_unload_1179  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1094  1
    load_1_21_19  free_load_conservation_1163  -1
    load_1_21_19  free_load_conservation_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1096  -25
    arc_1_21_20  connected_order_arc_1097  -13
    arc_1_21_20  in_degree_1165  1
    arc_1_21_20  out_degree_1170  1
    arc_1_21_20  original_T_including_depot_unload_1179  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1096  1
    load_1_21_20  free_load_conservation_1169  -1
    load_1_21_20  free_load_conservation_1175  1
    visit_2_10  out_degree_1471  -1
    visit_2_10  in_degree_1472  -1
    visit_2_10  order_active_lb_1473  -1
    visit_2_10  order_active_ub_1474  -12
    order_2_10  connected_order_arc_1195  -1
    order_2_10  connected_order_arc_1197  -1
    order_2_10  connected_order_arc_1199  -1
    order_2_10  connected_order_arc_1201  -1
    order_2_10  connected_order_arc_1203  -1
    order_2_10  connected_order_arc_1205  -1
    order_2_10  connected_order_arc_1207  -1
    order_2_10  connected_order_arc_1209  -1
    order_2_10  connected_order_arc_1211  -1
    order_2_10  connected_order_arc_1213  -1
    order_2_10  connected_order_arc_1215  -1
    order_2_10  connected_order_arc_1218  1
    order_2_10  connected_order_arc_1241  1
    order_2_10  connected_order_arc_1264  1
    order_2_10  connected_order_arc_1287  1
    order_2_10  connected_order_arc_1310  1
    order_2_10  connected_order_arc_1333  1
    order_2_10  connected_order_arc_1356  1
    order_2_10  connected_order_arc_1379  1
    order_2_10  connected_order_arc_1402  1
    order_2_10  connected_order_arc_1425  1
    order_2_10  connected_order_arc_1448  1
    order_2_10  order_active_lb_1473  1
    order_2_10  order_active_ub_1474  1
    order_2_10  fixed_segment_relative_order_1547  -1
    visit_2_11  out_degree_1478  -1
    visit_2_11  in_degree_1479  -1
    visit_2_11  order_active_lb_1480  -1
    visit_2_11  order_active_ub_1481  -12
    order_2_11  connected_order_arc_1195  1
    order_2_11  connected_order_arc_1218  -1
    order_2_11  connected_order_arc_1220  -1
    order_2_11  connected_order_arc_1222  -1
    order_2_11  connected_order_arc_1224  -1
    order_2_11  connected_order_arc_1226  -1
    order_2_11  connected_order_arc_1228  -1
    order_2_11  connected_order_arc_1230  -1
    order_2_11  connected_order_arc_1232  -1
    order_2_11  connected_order_arc_1234  -1
    order_2_11  connected_order_arc_1236  -1
    order_2_11  connected_order_arc_1238  -1
    order_2_11  connected_order_arc_1243  1
    order_2_11  connected_order_arc_1266  1
    order_2_11  connected_order_arc_1289  1
    order_2_11  connected_order_arc_1312  1
    order_2_11  connected_order_arc_1335  1
    order_2_11  connected_order_arc_1358  1
    order_2_11  connected_order_arc_1381  1
    order_2_11  connected_order_arc_1404  1
    order_2_11  connected_order_arc_1427  1
    order_2_11  connected_order_arc_1450  1
    order_2_11  order_active_lb_1480  1
    order_2_11  order_active_ub_1481  1
    order_2_11  fixed_segment_relative_order_1547  1
    order_2_11  fixed_segment_relative_order_1548  -1
    visit_2_12  out_degree_1485  -1
    visit_2_12  in_degree_1486  -1
    visit_2_12  order_active_lb_1487  -1
    visit_2_12  order_active_ub_1488  -12
    order_2_12  connected_order_arc_1197  1
    order_2_12  connected_order_arc_1220  1
    order_2_12  connected_order_arc_1241  -1
    order_2_12  connected_order_arc_1243  -1
    order_2_12  connected_order_arc_1245  -1
    order_2_12  connected_order_arc_1247  -1
    order_2_12  connected_order_arc_1249  -1
    order_2_12  connected_order_arc_1251  -1
    order_2_12  connected_order_arc_1253  -1
    order_2_12  connected_order_arc_1255  -1
    order_2_12  connected_order_arc_1257  -1
    order_2_12  connected_order_arc_1259  -1
    order_2_12  connected_order_arc_1261  -1
    order_2_12  connected_order_arc_1268  1
    order_2_12  connected_order_arc_1291  1
    order_2_12  connected_order_arc_1314  1
    order_2_12  connected_order_arc_1337  1
    order_2_12  connected_order_arc_1360  1
    order_2_12  connected_order_arc_1383  1
    order_2_12  connected_order_arc_1406  1
    order_2_12  connected_order_arc_1429  1
    order_2_12  connected_order_arc_1452  1
    order_2_12  order_active_lb_1487  1
    order_2_12  order_active_ub_1488  1
    order_2_12  fixed_segment_relative_order_1548  1
    order_2_12  fixed_segment_relative_order_1549  -1
    visit_2_13  out_degree_1492  -1
    visit_2_13  in_degree_1493  -1
    visit_2_13  order_active_lb_1494  -1
    visit_2_13  order_active_ub_1495  -12
    order_2_13  connected_order_arc_1199  1
    order_2_13  connected_order_arc_1222  1
    order_2_13  connected_order_arc_1245  1
    order_2_13  connected_order_arc_1264  -1
    order_2_13  connected_order_arc_1266  -1
    order_2_13  connected_order_arc_1268  -1
    order_2_13  connected_order_arc_1270  -1
    order_2_13  connected_order_arc_1272  -1
    order_2_13  connected_order_arc_1274  -1
    order_2_13  connected_order_arc_1276  -1
    order_2_13  connected_order_arc_1278  -1
    order_2_13  connected_order_arc_1280  -1
    order_2_13  connected_order_arc_1282  -1
    order_2_13  connected_order_arc_1284  -1
    order_2_13  connected_order_arc_1293  1
    order_2_13  connected_order_arc_1316  1
    order_2_13  connected_order_arc_1339  1
    order_2_13  connected_order_arc_1362  1
    order_2_13  connected_order_arc_1385  1
    order_2_13  connected_order_arc_1408  1
    order_2_13  connected_order_arc_1431  1
    order_2_13  connected_order_arc_1454  1
    order_2_13  order_active_lb_1494  1
    order_2_13  order_active_ub_1495  1
    order_2_13  fixed_segment_relative_order_1549  1
    visit_2_14  out_degree_1499  -1
    visit_2_14  in_degree_1500  -1
    visit_2_14  order_active_lb_1501  -1
    visit_2_14  order_active_ub_1502  -12
    visit_2_14  service_visit_def_1503  -1
    order_2_14  connected_order_arc_1201  1
    order_2_14  connected_order_arc_1224  1
    order_2_14  connected_order_arc_1247  1
    order_2_14  connected_order_arc_1270  1
    order_2_14  connected_order_arc_1287  -1
    order_2_14  connected_order_arc_1289  -1
    order_2_14  connected_order_arc_1291  -1
    order_2_14  connected_order_arc_1293  -1
    order_2_14  connected_order_arc_1295  -1
    order_2_14  connected_order_arc_1297  -1
    order_2_14  connected_order_arc_1299  -1
    order_2_14  connected_order_arc_1301  -1
    order_2_14  connected_order_arc_1303  -1
    order_2_14  connected_order_arc_1305  -1
    order_2_14  connected_order_arc_1307  -1
    order_2_14  connected_order_arc_1318  1
    order_2_14  connected_order_arc_1341  1
    order_2_14  connected_order_arc_1364  1
    order_2_14  connected_order_arc_1387  1
    order_2_14  connected_order_arc_1410  1
    order_2_14  connected_order_arc_1433  1
    order_2_14  connected_order_arc_1456  1
    order_2_14  order_active_lb_1501  1
    order_2_14  order_active_ub_1502  1
    visit_2_15  out_degree_1505  -1
    visit_2_15  in_degree_1506  -1
    visit_2_15  order_active_lb_1507  -1
    visit_2_15  order_active_ub_1508  -12
    visit_2_15  service_visit_def_1509  -1
    order_2_15  connected_order_arc_1203  1
    order_2_15  connected_order_arc_1226  1
    order_2_15  connected_order_arc_1249  1
    order_2_15  connected_order_arc_1272  1
    order_2_15  connected_order_arc_1295  1
    order_2_15  connected_order_arc_1310  -1
    order_2_15  connected_order_arc_1312  -1
    order_2_15  connected_order_arc_1314  -1
    order_2_15  connected_order_arc_1316  -1
    order_2_15  connected_order_arc_1318  -1
    order_2_15  connected_order_arc_1320  -1
    order_2_15  connected_order_arc_1322  -1
    order_2_15  connected_order_arc_1324  -1
    order_2_15  connected_order_arc_1326  -1
    order_2_15  connected_order_arc_1328  -1
    order_2_15  connected_order_arc_1330  -1
    order_2_15  connected_order_arc_1343  1
    order_2_15  connected_order_arc_1366  1
    order_2_15  connected_order_arc_1389  1
    order_2_15  connected_order_arc_1412  1
    order_2_15  connected_order_arc_1435  1
    order_2_15  connected_order_arc_1458  1
    order_2_15  order_active_lb_1507  1
    order_2_15  order_active_ub_1508  1
    visit_2_16  out_degree_1511  -1
    visit_2_16  in_degree_1512  -1
    visit_2_16  order_active_lb_1513  -1
    visit_2_16  order_active_ub_1514  -12
    visit_2_16  service_visit_def_1515  -1
    order_2_16  connected_order_arc_1205  1
    order_2_16  connected_order_arc_1228  1
    order_2_16  connected_order_arc_1251  1
    order_2_16  connected_order_arc_1274  1
    order_2_16  connected_order_arc_1297  1
    order_2_16  connected_order_arc_1320  1
    order_2_16  connected_order_arc_1333  -1
    order_2_16  connected_order_arc_1335  -1
    order_2_16  connected_order_arc_1337  -1
    order_2_16  connected_order_arc_1339  -1
    order_2_16  connected_order_arc_1341  -1
    order_2_16  connected_order_arc_1343  -1
    order_2_16  connected_order_arc_1345  -1
    order_2_16  connected_order_arc_1347  -1
    order_2_16  connected_order_arc_1349  -1
    order_2_16  connected_order_arc_1351  -1
    order_2_16  connected_order_arc_1353  -1
    order_2_16  connected_order_arc_1368  1
    order_2_16  connected_order_arc_1391  1
    order_2_16  connected_order_arc_1414  1
    order_2_16  connected_order_arc_1437  1
    order_2_16  connected_order_arc_1460  1
    order_2_16  order_active_lb_1513  1
    order_2_16  order_active_ub_1514  1
    visit_2_17  out_degree_1517  -1
    visit_2_17  in_degree_1518  -1
    visit_2_17  order_active_lb_1519  -1
    visit_2_17  order_active_ub_1520  -12
    visit_2_17  service_visit_def_1521  -1
    order_2_17  connected_order_arc_1207  1
    order_2_17  connected_order_arc_1230  1
    order_2_17  connected_order_arc_1253  1
    order_2_17  connected_order_arc_1276  1
    order_2_17  connected_order_arc_1299  1
    order_2_17  connected_order_arc_1322  1
    order_2_17  connected_order_arc_1345  1
    order_2_17  connected_order_arc_1356  -1
    order_2_17  connected_order_arc_1358  -1
    order_2_17  connected_order_arc_1360  -1
    order_2_17  connected_order_arc_1362  -1
    order_2_17  connected_order_arc_1364  -1
    order_2_17  connected_order_arc_1366  -1
    order_2_17  connected_order_arc_1368  -1
    order_2_17  connected_order_arc_1370  -1
    order_2_17  connected_order_arc_1372  -1
    order_2_17  connected_order_arc_1374  -1
    order_2_17  connected_order_arc_1376  -1
    order_2_17  connected_order_arc_1393  1
    order_2_17  connected_order_arc_1416  1
    order_2_17  connected_order_arc_1439  1
    order_2_17  connected_order_arc_1462  1
    order_2_17  order_active_lb_1519  1
    order_2_17  order_active_ub_1520  1
    visit_2_18  out_degree_1523  -1
    visit_2_18  in_degree_1524  -1
    visit_2_18  order_active_lb_1525  -1
    visit_2_18  order_active_ub_1526  -12
    visit_2_18  service_visit_def_1527  -1
    order_2_18  connected_order_arc_1209  1
    order_2_18  connected_order_arc_1232  1
    order_2_18  connected_order_arc_1255  1
    order_2_18  connected_order_arc_1278  1
    order_2_18  connected_order_arc_1301  1
    order_2_18  connected_order_arc_1324  1
    order_2_18  connected_order_arc_1347  1
    order_2_18  connected_order_arc_1370  1
    order_2_18  connected_order_arc_1379  -1
    order_2_18  connected_order_arc_1381  -1
    order_2_18  connected_order_arc_1383  -1
    order_2_18  connected_order_arc_1385  -1
    order_2_18  connected_order_arc_1387  -1
    order_2_18  connected_order_arc_1389  -1
    order_2_18  connected_order_arc_1391  -1
    order_2_18  connected_order_arc_1393  -1
    order_2_18  connected_order_arc_1395  -1
    order_2_18  connected_order_arc_1397  -1
    order_2_18  connected_order_arc_1399  -1
    order_2_18  connected_order_arc_1418  1
    order_2_18  connected_order_arc_1441  1
    order_2_18  connected_order_arc_1464  1
    order_2_18  order_active_lb_1525  1
    order_2_18  order_active_ub_1526  1
    visit_2_19  out_degree_1529  -1
    visit_2_19  in_degree_1530  -1
    visit_2_19  order_active_lb_1531  -1
    visit_2_19  order_active_ub_1532  -12
    visit_2_19  service_visit_def_1533  -1
    order_2_19  connected_order_arc_1211  1
    order_2_19  connected_order_arc_1234  1
    order_2_19  connected_order_arc_1257  1
    order_2_19  connected_order_arc_1280  1
    order_2_19  connected_order_arc_1303  1
    order_2_19  connected_order_arc_1326  1
    order_2_19  connected_order_arc_1349  1
    order_2_19  connected_order_arc_1372  1
    order_2_19  connected_order_arc_1395  1
    order_2_19  connected_order_arc_1402  -1
    order_2_19  connected_order_arc_1404  -1
    order_2_19  connected_order_arc_1406  -1
    order_2_19  connected_order_arc_1408  -1
    order_2_19  connected_order_arc_1410  -1
    order_2_19  connected_order_arc_1412  -1
    order_2_19  connected_order_arc_1414  -1
    order_2_19  connected_order_arc_1416  -1
    order_2_19  connected_order_arc_1418  -1
    order_2_19  connected_order_arc_1420  -1
    order_2_19  connected_order_arc_1422  -1
    order_2_19  connected_order_arc_1443  1
    order_2_19  connected_order_arc_1466  1
    order_2_19  order_active_lb_1531  1
    order_2_19  order_active_ub_1532  1
    visit_2_20  out_degree_1535  -1
    visit_2_20  in_degree_1536  -1
    visit_2_20  order_active_lb_1537  -1
    visit_2_20  order_active_ub_1538  -12
    visit_2_20  service_visit_def_1539  -1
    order_2_20  connected_order_arc_1213  1
    order_2_20  connected_order_arc_1236  1
    order_2_20  connected_order_arc_1259  1
    order_2_20  connected_order_arc_1282  1
    order_2_20  connected_order_arc_1305  1
    order_2_20  connected_order_arc_1328  1
    order_2_20  connected_order_arc_1351  1
    order_2_20  connected_order_arc_1374  1
    order_2_20  connected_order_arc_1397  1
    order_2_20  connected_order_arc_1420  1
    order_2_20  connected_order_arc_1425  -1
    order_2_20  connected_order_arc_1427  -1
    order_2_20  connected_order_arc_1429  -1
    order_2_20  connected_order_arc_1431  -1
    order_2_20  connected_order_arc_1433  -1
    order_2_20  connected_order_arc_1435  -1
    order_2_20  connected_order_arc_1437  -1
    order_2_20  connected_order_arc_1439  -1
    order_2_20  connected_order_arc_1441  -1
    order_2_20  connected_order_arc_1443  -1
    order_2_20  connected_order_arc_1445  -1
    order_2_20  connected_order_arc_1468  1
    order_2_20  order_active_lb_1537  1
    order_2_20  order_active_ub_1538  1
    visit_2_21  out_degree_1541  -1
    visit_2_21  in_degree_1542  -1
    visit_2_21  order_active_lb_1543  -1
    visit_2_21  order_active_ub_1544  -12
    visit_2_21  service_visit_def_1545  -1
    order_2_21  connected_order_arc_1215  1
    order_2_21  connected_order_arc_1238  1
    order_2_21  connected_order_arc_1261  1
    order_2_21  connected_order_arc_1284  1
    order_2_21  connected_order_arc_1307  1
    order_2_21  connected_order_arc_1330  1
    order_2_21  connected_order_arc_1353  1
    order_2_21  connected_order_arc_1376  1
    order_2_21  connected_order_arc_1399  1
    order_2_21  connected_order_arc_1422  1
    order_2_21  connected_order_arc_1445  1
    order_2_21  connected_order_arc_1448  -1
    order_2_21  connected_order_arc_1450  -1
    order_2_21  connected_order_arc_1452  -1
    order_2_21  connected_order_arc_1454  -1
    order_2_21  connected_order_arc_1456  -1
    order_2_21  connected_order_arc_1458  -1
    order_2_21  connected_order_arc_1460  -1
    order_2_21  connected_order_arc_1462  -1
    order_2_21  connected_order_arc_1464  -1
    order_2_21  connected_order_arc_1466  -1
    order_2_21  connected_order_arc_1468  -1
    order_2_21  order_active_lb_1543  1
    order_2_21  order_active_ub_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1180  -30
    arc_2_0_0  depot_departure_or_bypass_1469  1
    arc_2_0_0  depot_return_or_bypass_1470  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1181  -30
    arc_2_0_10  depot_departure_or_bypass_1469  1
    arc_2_0_10  in_degree_1472  1
    arc_2_0_10  original_T_including_depot_unload_1550  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1181  1
    load_2_0_10  segment_load_conservation_1475  -1
    load_2_0_10  segment_prefix_lb_1476  1
    load_2_0_10  segment_prefix_ub_1477  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1182  -30
    arc_2_0_11  depot_departure_or_bypass_1469  1
    arc_2_0_11  in_degree_1479  1
    arc_2_0_11  original_T_including_depot_unload_1550  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1182  1
    load_2_0_11  segment_load_conservation_1482  -1
    load_2_0_11  segment_prefix_lb_1483  1
    load_2_0_11  segment_prefix_ub_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1183  -30
    arc_2_0_12  depot_departure_or_bypass_1469  1
    arc_2_0_12  in_degree_1486  1
    arc_2_0_12  original_T_including_depot_unload_1550  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1183  1
    load_2_0_12  segment_load_conservation_1489  -1
    load_2_0_12  segment_prefix_lb_1490  1
    load_2_0_12  segment_prefix_ub_1491  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1184  -30
    arc_2_0_13  depot_departure_or_bypass_1469  1
    arc_2_0_13  in_degree_1493  1
    arc_2_0_13  original_T_including_depot_unload_1550  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1184  1
    load_2_0_13  segment_load_conservation_1496  -1
    load_2_0_13  segment_prefix_lb_1497  1
    load_2_0_13  segment_prefix_ub_1498  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1185  -30
    arc_2_0_14  depot_departure_or_bypass_1469  1
    arc_2_0_14  in_degree_1500  1
    arc_2_0_14  original_T_including_depot_unload_1550  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1185  1
    load_2_0_14  free_load_conservation_1504  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1186  -30
    arc_2_0_15  depot_departure_or_bypass_1469  1
    arc_2_0_15  in_degree_1506  1
    arc_2_0_15  original_T_including_depot_unload_1550  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1186  1
    load_2_0_15  free_load_conservation_1510  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1187  -30
    arc_2_0_16  depot_departure_or_bypass_1469  1
    arc_2_0_16  in_degree_1512  1
    arc_2_0_16  original_T_including_depot_unload_1550  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1187  1
    load_2_0_16  free_load_conservation_1516  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1188  -30
    arc_2_0_17  depot_departure_or_bypass_1469  1
    arc_2_0_17  in_degree_1518  1
    arc_2_0_17  original_T_including_depot_unload_1550  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1188  1
    load_2_0_17  free_load_conservation_1522  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1189  -30
    arc_2_0_18  depot_departure_or_bypass_1469  1
    arc_2_0_18  in_degree_1524  1
    arc_2_0_18  original_T_including_depot_unload_1550  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1189  1
    load_2_0_18  free_load_conservation_1528  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1190  -30
    arc_2_0_19  depot_departure_or_bypass_1469  1
    arc_2_0_19  in_degree_1530  1
    arc_2_0_19  original_T_including_depot_unload_1550  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1190  1
    load_2_0_19  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1191  -30
    arc_2_0_20  depot_departure_or_bypass_1469  1
    arc_2_0_20  in_degree_1536  1
    arc_2_0_20  original_T_including_depot_unload_1550  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1191  1
    load_2_0_20  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1192  -30
    arc_2_0_21  depot_departure_or_bypass_1469  1
    arc_2_0_21  in_degree_1542  1
    arc_2_0_21  original_T_including_depot_unload_1550  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1192  1
    load_2_0_21  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1193  -30
    arc_2_10_0  depot_return_or_bypass_1470  1
    arc_2_10_0  out_degree_1471  1
    arc_2_10_0  original_T_including_depot_unload_1550  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1193  1
    load_2_10_0  segment_load_conservation_1475  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1194  -30
    arc_2_10_11  connected_order_arc_1195  -13
    arc_2_10_11  out_degree_1471  1
    arc_2_10_11  in_degree_1479  1
    arc_2_10_11  original_T_including_depot_unload_1550  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1194  1
    load_2_10_11  segment_load_conservation_1475  1
    load_2_10_11  segment_load_conservation_1482  -1
    load_2_10_11  segment_prefix_lb_1483  1
    load_2_10_11  segment_prefix_ub_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1196  -30
    arc_2_10_12  connected_order_arc_1197  -13
    arc_2_10_12  out_degree_1471  1
    arc_2_10_12  in_degree_1486  1
    arc_2_10_12  original_T_including_depot_unload_1550  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1196  1
    load_2_10_12  segment_load_conservation_1475  1
    load_2_10_12  segment_load_conservation_1489  -1
    load_2_10_12  segment_prefix_lb_1490  1
    load_2_10_12  segment_prefix_ub_1491  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1198  -30
    arc_2_10_13  connected_order_arc_1199  -13
    arc_2_10_13  out_degree_1471  1
    arc_2_10_13  in_degree_1493  1
    arc_2_10_13  original_T_including_depot_unload_1550  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1198  1
    load_2_10_13  segment_load_conservation_1475  1
    load_2_10_13  segment_load_conservation_1496  -1
    load_2_10_13  segment_prefix_lb_1497  1
    load_2_10_13  segment_prefix_ub_1498  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1200  -30
    arc_2_10_14  connected_order_arc_1201  -13
    arc_2_10_14  out_degree_1471  1
    arc_2_10_14  in_degree_1500  1
    arc_2_10_14  original_T_including_depot_unload_1550  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1200  1
    load_2_10_14  segment_load_conservation_1475  1
    load_2_10_14  free_load_conservation_1504  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1202  -30
    arc_2_10_15  connected_order_arc_1203  -13
    arc_2_10_15  out_degree_1471  1
    arc_2_10_15  in_degree_1506  1
    arc_2_10_15  original_T_including_depot_unload_1550  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1202  1
    load_2_10_15  segment_load_conservation_1475  1
    load_2_10_15  free_load_conservation_1510  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1204  -30
    arc_2_10_16  connected_order_arc_1205  -13
    arc_2_10_16  out_degree_1471  1
    arc_2_10_16  in_degree_1512  1
    arc_2_10_16  original_T_including_depot_unload_1550  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1204  1
    load_2_10_16  segment_load_conservation_1475  1
    load_2_10_16  free_load_conservation_1516  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1206  -30
    arc_2_10_17  connected_order_arc_1207  -13
    arc_2_10_17  out_degree_1471  1
    arc_2_10_17  in_degree_1518  1
    arc_2_10_17  original_T_including_depot_unload_1550  1.1077505469776054e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1206  1
    load_2_10_17  segment_load_conservation_1475  1
    load_2_10_17  free_load_conservation_1522  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1208  -30
    arc_2_10_18  connected_order_arc_1209  -13
    arc_2_10_18  out_degree_1471  1
    arc_2_10_18  in_degree_1524  1
    arc_2_10_18  original_T_including_depot_unload_1550  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1208  1
    load_2_10_18  segment_load_conservation_1475  1
    load_2_10_18  free_load_conservation_1528  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1210  -30
    arc_2_10_19  connected_order_arc_1211  -13
    arc_2_10_19  out_degree_1471  1
    arc_2_10_19  in_degree_1530  1
    arc_2_10_19  original_T_including_depot_unload_1550  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1210  1
    load_2_10_19  segment_load_conservation_1475  1
    load_2_10_19  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1212  -30
    arc_2_10_20  connected_order_arc_1213  -13
    arc_2_10_20  out_degree_1471  1
    arc_2_10_20  in_degree_1536  1
    arc_2_10_20  original_T_including_depot_unload_1550  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1212  1
    load_2_10_20  segment_load_conservation_1475  1
    load_2_10_20  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_21  arc_capacity_1214  -30
    arc_2_10_21  connected_order_arc_1215  -13
    arc_2_10_21  out_degree_1471  1
    arc_2_10_21  in_degree_1542  1
    arc_2_10_21  original_T_including_depot_unload_1550  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_21  arc_capacity_1214  1
    load_2_10_21  segment_load_conservation_1475  1
    load_2_10_21  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1216  -30
    arc_2_11_0  depot_return_or_bypass_1470  1
    arc_2_11_0  out_degree_1478  1
    arc_2_11_0  original_T_including_depot_unload_1550  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1216  1
    load_2_11_0  segment_load_conservation_1482  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1217  -30
    arc_2_11_10  connected_order_arc_1218  -13
    arc_2_11_10  in_degree_1472  1
    arc_2_11_10  out_degree_1478  1
    arc_2_11_10  original_T_including_depot_unload_1550  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1217  1
    load_2_11_10  segment_load_conservation_1475  -1
    load_2_11_10  segment_prefix_lb_1476  1
    load_2_11_10  segment_prefix_ub_1477  1
    load_2_11_10  segment_load_conservation_1482  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1219  -30
    arc_2_11_12  connected_order_arc_1220  -13
    arc_2_11_12  out_degree_1478  1
    arc_2_11_12  in_degree_1486  1
    arc_2_11_12  original_T_including_depot_unload_1550  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1219  1
    load_2_11_12  segment_load_conservation_1482  1
    load_2_11_12  segment_load_conservation_1489  -1
    load_2_11_12  segment_prefix_lb_1490  1
    load_2_11_12  segment_prefix_ub_1491  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1221  -30
    arc_2_11_13  connected_order_arc_1222  -13
    arc_2_11_13  out_degree_1478  1
    arc_2_11_13  in_degree_1493  1
    arc_2_11_13  original_T_including_depot_unload_1550  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1221  1
    load_2_11_13  segment_load_conservation_1482  1
    load_2_11_13  segment_load_conservation_1496  -1
    load_2_11_13  segment_prefix_lb_1497  1
    load_2_11_13  segment_prefix_ub_1498  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1223  -30
    arc_2_11_14  connected_order_arc_1224  -13
    arc_2_11_14  out_degree_1478  1
    arc_2_11_14  in_degree_1500  1
    arc_2_11_14  original_T_including_depot_unload_1550  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1223  1
    load_2_11_14  segment_load_conservation_1482  1
    load_2_11_14  free_load_conservation_1504  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1225  -30
    arc_2_11_15  connected_order_arc_1226  -13
    arc_2_11_15  out_degree_1478  1
    arc_2_11_15  in_degree_1506  1
    arc_2_11_15  original_T_including_depot_unload_1550  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1225  1
    load_2_11_15  segment_load_conservation_1482  1
    load_2_11_15  free_load_conservation_1510  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1227  -30
    arc_2_11_16  connected_order_arc_1228  -13
    arc_2_11_16  out_degree_1478  1
    arc_2_11_16  in_degree_1512  1
    arc_2_11_16  original_T_including_depot_unload_1550  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1227  1
    load_2_11_16  segment_load_conservation_1482  1
    load_2_11_16  free_load_conservation_1516  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1229  -30
    arc_2_11_17  connected_order_arc_1230  -13
    arc_2_11_17  out_degree_1478  1
    arc_2_11_17  in_degree_1518  1
    arc_2_11_17  original_T_including_depot_unload_1550  2184.10509638866
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1229  1
    load_2_11_17  segment_load_conservation_1482  1
    load_2_11_17  free_load_conservation_1522  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1231  -30
    arc_2_11_18  connected_order_arc_1232  -13
    arc_2_11_18  out_degree_1478  1
    arc_2_11_18  in_degree_1524  1
    arc_2_11_18  original_T_including_depot_unload_1550  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1231  1
    load_2_11_18  segment_load_conservation_1482  1
    load_2_11_18  free_load_conservation_1528  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1233  -30
    arc_2_11_19  connected_order_arc_1234  -13
    arc_2_11_19  out_degree_1478  1
    arc_2_11_19  in_degree_1530  1
    arc_2_11_19  original_T_including_depot_unload_1550  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1233  1
    load_2_11_19  segment_load_conservation_1482  1
    load_2_11_19  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1235  -30
    arc_2_11_20  connected_order_arc_1236  -13
    arc_2_11_20  out_degree_1478  1
    arc_2_11_20  in_degree_1536  1
    arc_2_11_20  original_T_including_depot_unload_1550  1.4593103211867947e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1235  1
    load_2_11_20  segment_load_conservation_1482  1
    load_2_11_20  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1237  -30
    arc_2_11_21  connected_order_arc_1238  -13
    arc_2_11_21  out_degree_1478  1
    arc_2_11_21  in_degree_1542  1
    arc_2_11_21  original_T_including_depot_unload_1550  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1237  1
    load_2_11_21  segment_load_conservation_1482  1
    load_2_11_21  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1239  -30
    arc_2_12_0  depot_return_or_bypass_1470  1
    arc_2_12_0  out_degree_1485  1
    arc_2_12_0  original_T_including_depot_unload_1550  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1239  1
    load_2_12_0  segment_load_conservation_1489  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1240  -30
    arc_2_12_10  connected_order_arc_1241  -13
    arc_2_12_10  in_degree_1472  1
    arc_2_12_10  out_degree_1485  1
    arc_2_12_10  original_T_including_depot_unload_1550  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1240  1
    load_2_12_10  segment_load_conservation_1475  -1
    load_2_12_10  segment_prefix_lb_1476  1
    load_2_12_10  segment_prefix_ub_1477  1
    load_2_12_10  segment_load_conservation_1489  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1242  -30
    arc_2_12_11  connected_order_arc_1243  -13
    arc_2_12_11  in_degree_1479  1
    arc_2_12_11  out_degree_1485  1
    arc_2_12_11  original_T_including_depot_unload_1550  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1242  1
    load_2_12_11  segment_load_conservation_1482  -1
    load_2_12_11  segment_prefix_lb_1483  1
    load_2_12_11  segment_prefix_ub_1484  1
    load_2_12_11  segment_load_conservation_1489  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1244  -30
    arc_2_12_13  connected_order_arc_1245  -13
    arc_2_12_13  out_degree_1485  1
    arc_2_12_13  in_degree_1493  1
    arc_2_12_13  original_T_including_depot_unload_1550  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1244  1
    load_2_12_13  segment_load_conservation_1489  1
    load_2_12_13  segment_load_conservation_1496  -1
    load_2_12_13  segment_prefix_lb_1497  1
    load_2_12_13  segment_prefix_ub_1498  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1246  -30
    arc_2_12_14  connected_order_arc_1247  -13
    arc_2_12_14  out_degree_1485  1
    arc_2_12_14  in_degree_1500  1
    arc_2_12_14  original_T_including_depot_unload_1550  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1246  1
    load_2_12_14  segment_load_conservation_1489  1
    load_2_12_14  free_load_conservation_1504  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1248  -30
    arc_2_12_15  connected_order_arc_1249  -13
    arc_2_12_15  out_degree_1485  1
    arc_2_12_15  in_degree_1506  1
    arc_2_12_15  original_T_including_depot_unload_1550  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1248  1
    load_2_12_15  segment_load_conservation_1489  1
    load_2_12_15  free_load_conservation_1510  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1250  -30
    arc_2_12_16  connected_order_arc_1251  -13
    arc_2_12_16  out_degree_1485  1
    arc_2_12_16  in_degree_1512  1
    arc_2_12_16  original_T_including_depot_unload_1550  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1250  1
    load_2_12_16  segment_load_conservation_1489  1
    load_2_12_16  free_load_conservation_1516  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1252  -30
    arc_2_12_17  connected_order_arc_1253  -13
    arc_2_12_17  out_degree_1485  1
    arc_2_12_17  in_degree_1518  1
    arc_2_12_17  original_T_including_depot_unload_1550  1.9853708143200565e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1252  1
    load_2_12_17  segment_load_conservation_1489  1
    load_2_12_17  free_load_conservation_1522  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1254  -30
    arc_2_12_18  connected_order_arc_1255  -13
    arc_2_12_18  out_degree_1485  1
    arc_2_12_18  in_degree_1524  1
    arc_2_12_18  original_T_including_depot_unload_1550  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1254  1
    load_2_12_18  segment_load_conservation_1489  1
    load_2_12_18  free_load_conservation_1528  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1256  -30
    arc_2_12_19  connected_order_arc_1257  -13
    arc_2_12_19  out_degree_1485  1
    arc_2_12_19  in_degree_1530  1
    arc_2_12_19  original_T_including_depot_unload_1550  1.4688211749637876e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1256  1
    load_2_12_19  segment_load_conservation_1489  1
    load_2_12_19  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1258  -30
    arc_2_12_20  connected_order_arc_1259  -13
    arc_2_12_20  out_degree_1485  1
    arc_2_12_20  in_degree_1536  1
    arc_2_12_20  original_T_including_depot_unload_1550  1.5757088859257728e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1258  1
    load_2_12_20  segment_load_conservation_1489  1
    load_2_12_20  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1260  -30
    arc_2_12_21  connected_order_arc_1261  -13
    arc_2_12_21  out_degree_1485  1
    arc_2_12_21  in_degree_1542  1
    arc_2_12_21  original_T_including_depot_unload_1550  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1260  1
    load_2_12_21  segment_load_conservation_1489  1
    load_2_12_21  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1262  -30
    arc_2_13_0  depot_return_or_bypass_1470  1
    arc_2_13_0  out_degree_1492  1
    arc_2_13_0  original_T_including_depot_unload_1550  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1262  1
    load_2_13_0  segment_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1263  -30
    arc_2_13_10  connected_order_arc_1264  -13
    arc_2_13_10  in_degree_1472  1
    arc_2_13_10  out_degree_1492  1
    arc_2_13_10  original_T_including_depot_unload_1550  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1263  1
    load_2_13_10  segment_load_conservation_1475  -1
    load_2_13_10  segment_prefix_lb_1476  1
    load_2_13_10  segment_prefix_ub_1477  1
    load_2_13_10  segment_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1265  -30
    arc_2_13_11  connected_order_arc_1266  -13
    arc_2_13_11  in_degree_1479  1
    arc_2_13_11  out_degree_1492  1
    arc_2_13_11  original_T_including_depot_unload_1550  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1265  1
    load_2_13_11  segment_load_conservation_1482  -1
    load_2_13_11  segment_prefix_lb_1483  1
    load_2_13_11  segment_prefix_ub_1484  1
    load_2_13_11  segment_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1267  -30
    arc_2_13_12  connected_order_arc_1268  -13
    arc_2_13_12  in_degree_1486  1
    arc_2_13_12  out_degree_1492  1
    arc_2_13_12  original_T_including_depot_unload_1550  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1267  1
    load_2_13_12  segment_load_conservation_1489  -1
    load_2_13_12  segment_prefix_lb_1490  1
    load_2_13_12  segment_prefix_ub_1491  1
    load_2_13_12  segment_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1269  -30
    arc_2_13_14  connected_order_arc_1270  -13
    arc_2_13_14  out_degree_1492  1
    arc_2_13_14  in_degree_1500  1
    arc_2_13_14  original_T_including_depot_unload_1550  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1269  1
    load_2_13_14  segment_load_conservation_1496  1
    load_2_13_14  free_load_conservation_1504  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1271  -30
    arc_2_13_15  connected_order_arc_1272  -13
    arc_2_13_15  out_degree_1492  1
    arc_2_13_15  in_degree_1506  1
    arc_2_13_15  original_T_including_depot_unload_1550  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1271  1
    load_2_13_15  segment_load_conservation_1496  1
    load_2_13_15  free_load_conservation_1510  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1273  -30
    arc_2_13_16  connected_order_arc_1274  -13
    arc_2_13_16  out_degree_1492  1
    arc_2_13_16  in_degree_1512  1
    arc_2_13_16  original_T_including_depot_unload_1550  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1273  1
    load_2_13_16  segment_load_conservation_1496  1
    load_2_13_16  free_load_conservation_1516  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1275  -30
    arc_2_13_17  connected_order_arc_1276  -13
    arc_2_13_17  out_degree_1492  1
    arc_2_13_17  in_degree_1518  1
    arc_2_13_17  original_T_including_depot_unload_1550  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1275  1
    load_2_13_17  segment_load_conservation_1496  1
    load_2_13_17  free_load_conservation_1522  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1277  -30
    arc_2_13_18  connected_order_arc_1278  -13
    arc_2_13_18  out_degree_1492  1
    arc_2_13_18  in_degree_1524  1
    arc_2_13_18  original_T_including_depot_unload_1550  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1277  1
    load_2_13_18  segment_load_conservation_1496  1
    load_2_13_18  free_load_conservation_1528  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1279  -30
    arc_2_13_19  connected_order_arc_1280  -13
    arc_2_13_19  out_degree_1492  1
    arc_2_13_19  in_degree_1530  1
    arc_2_13_19  original_T_including_depot_unload_1550  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1279  1
    load_2_13_19  segment_load_conservation_1496  1
    load_2_13_19  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1281  -30
    arc_2_13_20  connected_order_arc_1282  -13
    arc_2_13_20  out_degree_1492  1
    arc_2_13_20  in_degree_1536  1
    arc_2_13_20  original_T_including_depot_unload_1550  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1281  1
    load_2_13_20  segment_load_conservation_1496  1
    load_2_13_20  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1283  -30
    arc_2_13_21  connected_order_arc_1284  -13
    arc_2_13_21  out_degree_1492  1
    arc_2_13_21  in_degree_1542  1
    arc_2_13_21  original_T_including_depot_unload_1550  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1283  1
    load_2_13_21  segment_load_conservation_1496  1
    load_2_13_21  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1285  -30
    arc_2_14_0  depot_return_or_bypass_1470  1
    arc_2_14_0  out_degree_1499  1
    arc_2_14_0  original_T_including_depot_unload_1550  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1285  1
    load_2_14_0  free_load_conservation_1504  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1286  -30
    arc_2_14_10  connected_order_arc_1287  -13
    arc_2_14_10  in_degree_1472  1
    arc_2_14_10  out_degree_1499  1
    arc_2_14_10  original_T_including_depot_unload_1550  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1286  1
    load_2_14_10  segment_load_conservation_1475  -1
    load_2_14_10  segment_prefix_lb_1476  1
    load_2_14_10  segment_prefix_ub_1477  1
    load_2_14_10  free_load_conservation_1504  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1288  -30
    arc_2_14_11  connected_order_arc_1289  -13
    arc_2_14_11  in_degree_1479  1
    arc_2_14_11  out_degree_1499  1
    arc_2_14_11  original_T_including_depot_unload_1550  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1288  1
    load_2_14_11  segment_load_conservation_1482  -1
    load_2_14_11  segment_prefix_lb_1483  1
    load_2_14_11  segment_prefix_ub_1484  1
    load_2_14_11  free_load_conservation_1504  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1290  -30
    arc_2_14_12  connected_order_arc_1291  -13
    arc_2_14_12  in_degree_1486  1
    arc_2_14_12  out_degree_1499  1
    arc_2_14_12  original_T_including_depot_unload_1550  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1290  1
    load_2_14_12  segment_load_conservation_1489  -1
    load_2_14_12  segment_prefix_lb_1490  1
    load_2_14_12  segment_prefix_ub_1491  1
    load_2_14_12  free_load_conservation_1504  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1292  -30
    arc_2_14_13  connected_order_arc_1293  -13
    arc_2_14_13  in_degree_1493  1
    arc_2_14_13  out_degree_1499  1
    arc_2_14_13  original_T_including_depot_unload_1550  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1292  1
    load_2_14_13  segment_load_conservation_1496  -1
    load_2_14_13  segment_prefix_lb_1497  1
    load_2_14_13  segment_prefix_ub_1498  1
    load_2_14_13  free_load_conservation_1504  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1294  -30
    arc_2_14_15  connected_order_arc_1295  -13
    arc_2_14_15  out_degree_1499  1
    arc_2_14_15  in_degree_1506  1
    arc_2_14_15  original_T_including_depot_unload_1550  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1294  1
    load_2_14_15  free_load_conservation_1504  1
    load_2_14_15  free_load_conservation_1510  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1296  -30
    arc_2_14_16  connected_order_arc_1297  -13
    arc_2_14_16  out_degree_1499  1
    arc_2_14_16  in_degree_1512  1
    arc_2_14_16  original_T_including_depot_unload_1550  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1296  1
    load_2_14_16  free_load_conservation_1504  1
    load_2_14_16  free_load_conservation_1516  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1298  -30
    arc_2_14_17  connected_order_arc_1299  -13
    arc_2_14_17  out_degree_1499  1
    arc_2_14_17  in_degree_1518  1
    arc_2_14_17  original_T_including_depot_unload_1550  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1298  1
    load_2_14_17  free_load_conservation_1504  1
    load_2_14_17  free_load_conservation_1522  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1300  -30
    arc_2_14_18  connected_order_arc_1301  -13
    arc_2_14_18  out_degree_1499  1
    arc_2_14_18  in_degree_1524  1
    arc_2_14_18  original_T_including_depot_unload_1550  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1300  1
    load_2_14_18  free_load_conservation_1504  1
    load_2_14_18  free_load_conservation_1528  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1302  -30
    arc_2_14_19  connected_order_arc_1303  -13
    arc_2_14_19  out_degree_1499  1
    arc_2_14_19  in_degree_1530  1
    arc_2_14_19  original_T_including_depot_unload_1550  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1302  1
    load_2_14_19  free_load_conservation_1504  1
    load_2_14_19  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1304  -30
    arc_2_14_20  connected_order_arc_1305  -13
    arc_2_14_20  out_degree_1499  1
    arc_2_14_20  in_degree_1536  1
    arc_2_14_20  original_T_including_depot_unload_1550  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1304  1
    load_2_14_20  free_load_conservation_1504  1
    load_2_14_20  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1306  -30
    arc_2_14_21  connected_order_arc_1307  -13
    arc_2_14_21  out_degree_1499  1
    arc_2_14_21  in_degree_1542  1
    arc_2_14_21  original_T_including_depot_unload_1550  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1306  1
    load_2_14_21  free_load_conservation_1504  1
    load_2_14_21  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1308  -30
    arc_2_15_0  depot_return_or_bypass_1470  1
    arc_2_15_0  out_degree_1505  1
    arc_2_15_0  original_T_including_depot_unload_1550  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1308  1
    load_2_15_0  free_load_conservation_1510  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1309  -30
    arc_2_15_10  connected_order_arc_1310  -13
    arc_2_15_10  in_degree_1472  1
    arc_2_15_10  out_degree_1505  1
    arc_2_15_10  original_T_including_depot_unload_1550  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1309  1
    load_2_15_10  segment_load_conservation_1475  -1
    load_2_15_10  segment_prefix_lb_1476  1
    load_2_15_10  segment_prefix_ub_1477  1
    load_2_15_10  free_load_conservation_1510  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1311  -30
    arc_2_15_11  connected_order_arc_1312  -13
    arc_2_15_11  in_degree_1479  1
    arc_2_15_11  out_degree_1505  1
    arc_2_15_11  original_T_including_depot_unload_1550  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1311  1
    load_2_15_11  segment_load_conservation_1482  -1
    load_2_15_11  segment_prefix_lb_1483  1
    load_2_15_11  segment_prefix_ub_1484  1
    load_2_15_11  free_load_conservation_1510  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1313  -30
    arc_2_15_12  connected_order_arc_1314  -13
    arc_2_15_12  in_degree_1486  1
    arc_2_15_12  out_degree_1505  1
    arc_2_15_12  original_T_including_depot_unload_1550  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1313  1
    load_2_15_12  segment_load_conservation_1489  -1
    load_2_15_12  segment_prefix_lb_1490  1
    load_2_15_12  segment_prefix_ub_1491  1
    load_2_15_12  free_load_conservation_1510  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1315  -30
    arc_2_15_13  connected_order_arc_1316  -13
    arc_2_15_13  in_degree_1493  1
    arc_2_15_13  out_degree_1505  1
    arc_2_15_13  original_T_including_depot_unload_1550  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1315  1
    load_2_15_13  segment_load_conservation_1496  -1
    load_2_15_13  segment_prefix_lb_1497  1
    load_2_15_13  segment_prefix_ub_1498  1
    load_2_15_13  free_load_conservation_1510  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1317  -30
    arc_2_15_14  connected_order_arc_1318  -13
    arc_2_15_14  in_degree_1500  1
    arc_2_15_14  out_degree_1505  1
    arc_2_15_14  original_T_including_depot_unload_1550  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1317  1
    load_2_15_14  free_load_conservation_1504  -1
    load_2_15_14  free_load_conservation_1510  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1319  -30
    arc_2_15_16  connected_order_arc_1320  -13
    arc_2_15_16  out_degree_1505  1
    arc_2_15_16  in_degree_1512  1
    arc_2_15_16  original_T_including_depot_unload_1550  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1319  1
    load_2_15_16  free_load_conservation_1510  1
    load_2_15_16  free_load_conservation_1516  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1321  -30
    arc_2_15_17  connected_order_arc_1322  -13
    arc_2_15_17  out_degree_1505  1
    arc_2_15_17  in_degree_1518  1
    arc_2_15_17  original_T_including_depot_unload_1550  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1321  1
    load_2_15_17  free_load_conservation_1510  1
    load_2_15_17  free_load_conservation_1522  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1323  -30
    arc_2_15_18  connected_order_arc_1324  -13
    arc_2_15_18  out_degree_1505  1
    arc_2_15_18  in_degree_1524  1
    arc_2_15_18  original_T_including_depot_unload_1550  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1323  1
    load_2_15_18  free_load_conservation_1510  1
    load_2_15_18  free_load_conservation_1528  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1325  -30
    arc_2_15_19  connected_order_arc_1326  -13
    arc_2_15_19  out_degree_1505  1
    arc_2_15_19  in_degree_1530  1
    arc_2_15_19  original_T_including_depot_unload_1550  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1325  1
    load_2_15_19  free_load_conservation_1510  1
    load_2_15_19  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1327  -30
    arc_2_15_20  connected_order_arc_1328  -13
    arc_2_15_20  out_degree_1505  1
    arc_2_15_20  in_degree_1536  1
    arc_2_15_20  original_T_including_depot_unload_1550  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1327  1
    load_2_15_20  free_load_conservation_1510  1
    load_2_15_20  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1329  -30
    arc_2_15_21  connected_order_arc_1330  -13
    arc_2_15_21  out_degree_1505  1
    arc_2_15_21  in_degree_1542  1
    arc_2_15_21  original_T_including_depot_unload_1550  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1329  1
    load_2_15_21  free_load_conservation_1510  1
    load_2_15_21  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1331  -30
    arc_2_16_0  depot_return_or_bypass_1470  1
    arc_2_16_0  out_degree_1511  1
    arc_2_16_0  original_T_including_depot_unload_1550  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1331  1
    load_2_16_0  free_load_conservation_1516  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1332  -30
    arc_2_16_10  connected_order_arc_1333  -13
    arc_2_16_10  in_degree_1472  1
    arc_2_16_10  out_degree_1511  1
    arc_2_16_10  original_T_including_depot_unload_1550  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1332  1
    load_2_16_10  segment_load_conservation_1475  -1
    load_2_16_10  segment_prefix_lb_1476  1
    load_2_16_10  segment_prefix_ub_1477  1
    load_2_16_10  free_load_conservation_1516  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1334  -30
    arc_2_16_11  connected_order_arc_1335  -13
    arc_2_16_11  in_degree_1479  1
    arc_2_16_11  out_degree_1511  1
    arc_2_16_11  original_T_including_depot_unload_1550  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1334  1
    load_2_16_11  segment_load_conservation_1482  -1
    load_2_16_11  segment_prefix_lb_1483  1
    load_2_16_11  segment_prefix_ub_1484  1
    load_2_16_11  free_load_conservation_1516  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1336  -30
    arc_2_16_12  connected_order_arc_1337  -13
    arc_2_16_12  in_degree_1486  1
    arc_2_16_12  out_degree_1511  1
    arc_2_16_12  original_T_including_depot_unload_1550  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1336  1
    load_2_16_12  segment_load_conservation_1489  -1
    load_2_16_12  segment_prefix_lb_1490  1
    load_2_16_12  segment_prefix_ub_1491  1
    load_2_16_12  free_load_conservation_1516  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1338  -30
    arc_2_16_13  connected_order_arc_1339  -13
    arc_2_16_13  in_degree_1493  1
    arc_2_16_13  out_degree_1511  1
    arc_2_16_13  original_T_including_depot_unload_1550  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1338  1
    load_2_16_13  segment_load_conservation_1496  -1
    load_2_16_13  segment_prefix_lb_1497  1
    load_2_16_13  segment_prefix_ub_1498  1
    load_2_16_13  free_load_conservation_1516  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1340  -30
    arc_2_16_14  connected_order_arc_1341  -13
    arc_2_16_14  in_degree_1500  1
    arc_2_16_14  out_degree_1511  1
    arc_2_16_14  original_T_including_depot_unload_1550  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1340  1
    load_2_16_14  free_load_conservation_1504  -1
    load_2_16_14  free_load_conservation_1516  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1342  -30
    arc_2_16_15  connected_order_arc_1343  -13
    arc_2_16_15  in_degree_1506  1
    arc_2_16_15  out_degree_1511  1
    arc_2_16_15  original_T_including_depot_unload_1550  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1342  1
    load_2_16_15  free_load_conservation_1510  -1
    load_2_16_15  free_load_conservation_1516  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1344  -30
    arc_2_16_17  connected_order_arc_1345  -13
    arc_2_16_17  out_degree_1511  1
    arc_2_16_17  in_degree_1518  1
    arc_2_16_17  original_T_including_depot_unload_1550  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1344  1
    load_2_16_17  free_load_conservation_1516  1
    load_2_16_17  free_load_conservation_1522  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1346  -30
    arc_2_16_18  connected_order_arc_1347  -13
    arc_2_16_18  out_degree_1511  1
    arc_2_16_18  in_degree_1524  1
    arc_2_16_18  original_T_including_depot_unload_1550  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1346  1
    load_2_16_18  free_load_conservation_1516  1
    load_2_16_18  free_load_conservation_1528  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1348  -30
    arc_2_16_19  connected_order_arc_1349  -13
    arc_2_16_19  out_degree_1511  1
    arc_2_16_19  in_degree_1530  1
    arc_2_16_19  original_T_including_depot_unload_1550  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1348  1
    load_2_16_19  free_load_conservation_1516  1
    load_2_16_19  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1350  -30
    arc_2_16_20  connected_order_arc_1351  -13
    arc_2_16_20  out_degree_1511  1
    arc_2_16_20  in_degree_1536  1
    arc_2_16_20  original_T_including_depot_unload_1550  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1350  1
    load_2_16_20  free_load_conservation_1516  1
    load_2_16_20  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1352  -30
    arc_2_16_21  connected_order_arc_1353  -13
    arc_2_16_21  out_degree_1511  1
    arc_2_16_21  in_degree_1542  1
    arc_2_16_21  original_T_including_depot_unload_1550  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1352  1
    load_2_16_21  free_load_conservation_1516  1
    load_2_16_21  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1354  -30
    arc_2_17_0  depot_return_or_bypass_1470  1
    arc_2_17_0  out_degree_1517  1
    arc_2_17_0  original_T_including_depot_unload_1550  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1354  1
    load_2_17_0  free_load_conservation_1522  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1355  -30
    arc_2_17_10  connected_order_arc_1356  -13
    arc_2_17_10  in_degree_1472  1
    arc_2_17_10  out_degree_1517  1
    arc_2_17_10  original_T_including_depot_unload_1550  1.1077505469776054e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1355  1
    load_2_17_10  segment_load_conservation_1475  -1
    load_2_17_10  segment_prefix_lb_1476  1
    load_2_17_10  segment_prefix_ub_1477  1
    load_2_17_10  free_load_conservation_1522  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1357  -30
    arc_2_17_11  connected_order_arc_1358  -13
    arc_2_17_11  in_degree_1479  1
    arc_2_17_11  out_degree_1517  1
    arc_2_17_11  original_T_including_depot_unload_1550  2184.10509638866
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1357  1
    load_2_17_11  segment_load_conservation_1482  -1
    load_2_17_11  segment_prefix_lb_1483  1
    load_2_17_11  segment_prefix_ub_1484  1
    load_2_17_11  free_load_conservation_1522  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1359  -30
    arc_2_17_12  connected_order_arc_1360  -13
    arc_2_17_12  in_degree_1486  1
    arc_2_17_12  out_degree_1517  1
    arc_2_17_12  original_T_including_depot_unload_1550  1.9853708143200565e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1359  1
    load_2_17_12  segment_load_conservation_1489  -1
    load_2_17_12  segment_prefix_lb_1490  1
    load_2_17_12  segment_prefix_ub_1491  1
    load_2_17_12  free_load_conservation_1522  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1361  -30
    arc_2_17_13  connected_order_arc_1362  -13
    arc_2_17_13  in_degree_1493  1
    arc_2_17_13  out_degree_1517  1
    arc_2_17_13  original_T_including_depot_unload_1550  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1361  1
    load_2_17_13  segment_load_conservation_1496  -1
    load_2_17_13  segment_prefix_lb_1497  1
    load_2_17_13  segment_prefix_ub_1498  1
    load_2_17_13  free_load_conservation_1522  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1363  -30
    arc_2_17_14  connected_order_arc_1364  -13
    arc_2_17_14  in_degree_1500  1
    arc_2_17_14  out_degree_1517  1
    arc_2_17_14  original_T_including_depot_unload_1550  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1363  1
    load_2_17_14  free_load_conservation_1504  -1
    load_2_17_14  free_load_conservation_1522  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1365  -30
    arc_2_17_15  connected_order_arc_1366  -13
    arc_2_17_15  in_degree_1506  1
    arc_2_17_15  out_degree_1517  1
    arc_2_17_15  original_T_including_depot_unload_1550  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1365  1
    load_2_17_15  free_load_conservation_1510  -1
    load_2_17_15  free_load_conservation_1522  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1367  -30
    arc_2_17_16  connected_order_arc_1368  -13
    arc_2_17_16  in_degree_1512  1
    arc_2_17_16  out_degree_1517  1
    arc_2_17_16  original_T_including_depot_unload_1550  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1367  1
    load_2_17_16  free_load_conservation_1516  -1
    load_2_17_16  free_load_conservation_1522  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1369  -30
    arc_2_17_18  connected_order_arc_1370  -13
    arc_2_17_18  out_degree_1517  1
    arc_2_17_18  in_degree_1524  1
    arc_2_17_18  original_T_including_depot_unload_1550  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1369  1
    load_2_17_18  free_load_conservation_1522  1
    load_2_17_18  free_load_conservation_1528  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1371  -30
    arc_2_17_19  connected_order_arc_1372  -13
    arc_2_17_19  out_degree_1517  1
    arc_2_17_19  in_degree_1530  1
    arc_2_17_19  original_T_including_depot_unload_1550  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1371  1
    load_2_17_19  free_load_conservation_1522  1
    load_2_17_19  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1373  -30
    arc_2_17_20  connected_order_arc_1374  -13
    arc_2_17_20  out_degree_1517  1
    arc_2_17_20  in_degree_1536  1
    arc_2_17_20  original_T_including_depot_unload_1550  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1373  1
    load_2_17_20  free_load_conservation_1522  1
    load_2_17_20  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1375  -30
    arc_2_17_21  connected_order_arc_1376  -13
    arc_2_17_21  out_degree_1517  1
    arc_2_17_21  in_degree_1542  1
    arc_2_17_21  original_T_including_depot_unload_1550  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1375  1
    load_2_17_21  free_load_conservation_1522  1
    load_2_17_21  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1377  -30
    arc_2_18_0  depot_return_or_bypass_1470  1
    arc_2_18_0  out_degree_1523  1
    arc_2_18_0  original_T_including_depot_unload_1550  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1377  1
    load_2_18_0  free_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1378  -30
    arc_2_18_10  connected_order_arc_1379  -13
    arc_2_18_10  in_degree_1472  1
    arc_2_18_10  out_degree_1523  1
    arc_2_18_10  original_T_including_depot_unload_1550  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1378  1
    load_2_18_10  segment_load_conservation_1475  -1
    load_2_18_10  segment_prefix_lb_1476  1
    load_2_18_10  segment_prefix_ub_1477  1
    load_2_18_10  free_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1380  -30
    arc_2_18_11  connected_order_arc_1381  -13
    arc_2_18_11  in_degree_1479  1
    arc_2_18_11  out_degree_1523  1
    arc_2_18_11  original_T_including_depot_unload_1550  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1380  1
    load_2_18_11  segment_load_conservation_1482  -1
    load_2_18_11  segment_prefix_lb_1483  1
    load_2_18_11  segment_prefix_ub_1484  1
    load_2_18_11  free_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1382  -30
    arc_2_18_12  connected_order_arc_1383  -13
    arc_2_18_12  in_degree_1486  1
    arc_2_18_12  out_degree_1523  1
    arc_2_18_12  original_T_including_depot_unload_1550  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1382  1
    load_2_18_12  segment_load_conservation_1489  -1
    load_2_18_12  segment_prefix_lb_1490  1
    load_2_18_12  segment_prefix_ub_1491  1
    load_2_18_12  free_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1384  -30
    arc_2_18_13  connected_order_arc_1385  -13
    arc_2_18_13  in_degree_1493  1
    arc_2_18_13  out_degree_1523  1
    arc_2_18_13  original_T_including_depot_unload_1550  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1384  1
    load_2_18_13  segment_load_conservation_1496  -1
    load_2_18_13  segment_prefix_lb_1497  1
    load_2_18_13  segment_prefix_ub_1498  1
    load_2_18_13  free_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1386  -30
    arc_2_18_14  connected_order_arc_1387  -13
    arc_2_18_14  in_degree_1500  1
    arc_2_18_14  out_degree_1523  1
    arc_2_18_14  original_T_including_depot_unload_1550  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1386  1
    load_2_18_14  free_load_conservation_1504  -1
    load_2_18_14  free_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1388  -30
    arc_2_18_15  connected_order_arc_1389  -13
    arc_2_18_15  in_degree_1506  1
    arc_2_18_15  out_degree_1523  1
    arc_2_18_15  original_T_including_depot_unload_1550  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1388  1
    load_2_18_15  free_load_conservation_1510  -1
    load_2_18_15  free_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1390  -30
    arc_2_18_16  connected_order_arc_1391  -13
    arc_2_18_16  in_degree_1512  1
    arc_2_18_16  out_degree_1523  1
    arc_2_18_16  original_T_including_depot_unload_1550  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1390  1
    load_2_18_16  free_load_conservation_1516  -1
    load_2_18_16  free_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1392  -30
    arc_2_18_17  connected_order_arc_1393  -13
    arc_2_18_17  in_degree_1518  1
    arc_2_18_17  out_degree_1523  1
    arc_2_18_17  original_T_including_depot_unload_1550  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1392  1
    load_2_18_17  free_load_conservation_1522  -1
    load_2_18_17  free_load_conservation_1528  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1394  -30
    arc_2_18_19  connected_order_arc_1395  -13
    arc_2_18_19  out_degree_1523  1
    arc_2_18_19  in_degree_1530  1
    arc_2_18_19  original_T_including_depot_unload_1550  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1394  1
    load_2_18_19  free_load_conservation_1528  1
    load_2_18_19  free_load_conservation_1534  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1396  -30
    arc_2_18_20  connected_order_arc_1397  -13
    arc_2_18_20  out_degree_1523  1
    arc_2_18_20  in_degree_1536  1
    arc_2_18_20  original_T_including_depot_unload_1550  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1396  1
    load_2_18_20  free_load_conservation_1528  1
    load_2_18_20  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1398  -30
    arc_2_18_21  connected_order_arc_1399  -13
    arc_2_18_21  out_degree_1523  1
    arc_2_18_21  in_degree_1542  1
    arc_2_18_21  original_T_including_depot_unload_1550  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1398  1
    load_2_18_21  free_load_conservation_1528  1
    load_2_18_21  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1400  -30
    arc_2_19_0  depot_return_or_bypass_1470  1
    arc_2_19_0  out_degree_1529  1
    arc_2_19_0  original_T_including_depot_unload_1550  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1400  1
    load_2_19_0  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1401  -30
    arc_2_19_10  connected_order_arc_1402  -13
    arc_2_19_10  in_degree_1472  1
    arc_2_19_10  out_degree_1529  1
    arc_2_19_10  original_T_including_depot_unload_1550  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1401  1
    load_2_19_10  segment_load_conservation_1475  -1
    load_2_19_10  segment_prefix_lb_1476  1
    load_2_19_10  segment_prefix_ub_1477  1
    load_2_19_10  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1403  -30
    arc_2_19_11  connected_order_arc_1404  -13
    arc_2_19_11  in_degree_1479  1
    arc_2_19_11  out_degree_1529  1
    arc_2_19_11  original_T_including_depot_unload_1550  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1403  1
    load_2_19_11  segment_load_conservation_1482  -1
    load_2_19_11  segment_prefix_lb_1483  1
    load_2_19_11  segment_prefix_ub_1484  1
    load_2_19_11  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1405  -30
    arc_2_19_12  connected_order_arc_1406  -13
    arc_2_19_12  in_degree_1486  1
    arc_2_19_12  out_degree_1529  1
    arc_2_19_12  original_T_including_depot_unload_1550  1.4688211749637876e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1405  1
    load_2_19_12  segment_load_conservation_1489  -1
    load_2_19_12  segment_prefix_lb_1490  1
    load_2_19_12  segment_prefix_ub_1491  1
    load_2_19_12  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1407  -30
    arc_2_19_13  connected_order_arc_1408  -13
    arc_2_19_13  in_degree_1493  1
    arc_2_19_13  out_degree_1529  1
    arc_2_19_13  original_T_including_depot_unload_1550  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1407  1
    load_2_19_13  segment_load_conservation_1496  -1
    load_2_19_13  segment_prefix_lb_1497  1
    load_2_19_13  segment_prefix_ub_1498  1
    load_2_19_13  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1409  -30
    arc_2_19_14  connected_order_arc_1410  -13
    arc_2_19_14  in_degree_1500  1
    arc_2_19_14  out_degree_1529  1
    arc_2_19_14  original_T_including_depot_unload_1550  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1409  1
    load_2_19_14  free_load_conservation_1504  -1
    load_2_19_14  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1411  -30
    arc_2_19_15  connected_order_arc_1412  -13
    arc_2_19_15  in_degree_1506  1
    arc_2_19_15  out_degree_1529  1
    arc_2_19_15  original_T_including_depot_unload_1550  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1411  1
    load_2_19_15  free_load_conservation_1510  -1
    load_2_19_15  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1413  -30
    arc_2_19_16  connected_order_arc_1414  -13
    arc_2_19_16  in_degree_1512  1
    arc_2_19_16  out_degree_1529  1
    arc_2_19_16  original_T_including_depot_unload_1550  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1413  1
    load_2_19_16  free_load_conservation_1516  -1
    load_2_19_16  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1415  -30
    arc_2_19_17  connected_order_arc_1416  -13
    arc_2_19_17  in_degree_1518  1
    arc_2_19_17  out_degree_1529  1
    arc_2_19_17  original_T_including_depot_unload_1550  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1415  1
    load_2_19_17  free_load_conservation_1522  -1
    load_2_19_17  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1417  -30
    arc_2_19_18  connected_order_arc_1418  -13
    arc_2_19_18  in_degree_1524  1
    arc_2_19_18  out_degree_1529  1
    arc_2_19_18  original_T_including_depot_unload_1550  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1417  1
    load_2_19_18  free_load_conservation_1528  -1
    load_2_19_18  free_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1419  -30
    arc_2_19_20  connected_order_arc_1420  -13
    arc_2_19_20  out_degree_1529  1
    arc_2_19_20  in_degree_1536  1
    arc_2_19_20  original_T_including_depot_unload_1550  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1419  1
    load_2_19_20  free_load_conservation_1534  1
    load_2_19_20  free_load_conservation_1540  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1421  -30
    arc_2_19_21  connected_order_arc_1422  -13
    arc_2_19_21  out_degree_1529  1
    arc_2_19_21  in_degree_1542  1
    arc_2_19_21  original_T_including_depot_unload_1550  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1421  1
    load_2_19_21  free_load_conservation_1534  1
    load_2_19_21  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1423  -30
    arc_2_20_0  depot_return_or_bypass_1470  1
    arc_2_20_0  out_degree_1535  1
    arc_2_20_0  original_T_including_depot_unload_1550  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1423  1
    load_2_20_0  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1424  -30
    arc_2_20_10  connected_order_arc_1425  -13
    arc_2_20_10  in_degree_1472  1
    arc_2_20_10  out_degree_1535  1
    arc_2_20_10  original_T_including_depot_unload_1550  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1424  1
    load_2_20_10  segment_load_conservation_1475  -1
    load_2_20_10  segment_prefix_lb_1476  1
    load_2_20_10  segment_prefix_ub_1477  1
    load_2_20_10  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1426  -30
    arc_2_20_11  connected_order_arc_1427  -13
    arc_2_20_11  in_degree_1479  1
    arc_2_20_11  out_degree_1535  1
    arc_2_20_11  original_T_including_depot_unload_1550  1.4593103211867947e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1426  1
    load_2_20_11  segment_load_conservation_1482  -1
    load_2_20_11  segment_prefix_lb_1483  1
    load_2_20_11  segment_prefix_ub_1484  1
    load_2_20_11  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1428  -30
    arc_2_20_12  connected_order_arc_1429  -13
    arc_2_20_12  in_degree_1486  1
    arc_2_20_12  out_degree_1535  1
    arc_2_20_12  original_T_including_depot_unload_1550  1.5757088859257728e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1428  1
    load_2_20_12  segment_load_conservation_1489  -1
    load_2_20_12  segment_prefix_lb_1490  1
    load_2_20_12  segment_prefix_ub_1491  1
    load_2_20_12  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1430  -30
    arc_2_20_13  connected_order_arc_1431  -13
    arc_2_20_13  in_degree_1493  1
    arc_2_20_13  out_degree_1535  1
    arc_2_20_13  original_T_including_depot_unload_1550  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1430  1
    load_2_20_13  segment_load_conservation_1496  -1
    load_2_20_13  segment_prefix_lb_1497  1
    load_2_20_13  segment_prefix_ub_1498  1
    load_2_20_13  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1432  -30
    arc_2_20_14  connected_order_arc_1433  -13
    arc_2_20_14  in_degree_1500  1
    arc_2_20_14  out_degree_1535  1
    arc_2_20_14  original_T_including_depot_unload_1550  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1432  1
    load_2_20_14  free_load_conservation_1504  -1
    load_2_20_14  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1434  -30
    arc_2_20_15  connected_order_arc_1435  -13
    arc_2_20_15  in_degree_1506  1
    arc_2_20_15  out_degree_1535  1
    arc_2_20_15  original_T_including_depot_unload_1550  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1434  1
    load_2_20_15  free_load_conservation_1510  -1
    load_2_20_15  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1436  -30
    arc_2_20_16  connected_order_arc_1437  -13
    arc_2_20_16  in_degree_1512  1
    arc_2_20_16  out_degree_1535  1
    arc_2_20_16  original_T_including_depot_unload_1550  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1436  1
    load_2_20_16  free_load_conservation_1516  -1
    load_2_20_16  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1438  -30
    arc_2_20_17  connected_order_arc_1439  -13
    arc_2_20_17  in_degree_1518  1
    arc_2_20_17  out_degree_1535  1
    arc_2_20_17  original_T_including_depot_unload_1550  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1438  1
    load_2_20_17  free_load_conservation_1522  -1
    load_2_20_17  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1440  -30
    arc_2_20_18  connected_order_arc_1441  -13
    arc_2_20_18  in_degree_1524  1
    arc_2_20_18  out_degree_1535  1
    arc_2_20_18  original_T_including_depot_unload_1550  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1440  1
    load_2_20_18  free_load_conservation_1528  -1
    load_2_20_18  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1442  -30
    arc_2_20_19  connected_order_arc_1443  -13
    arc_2_20_19  in_degree_1530  1
    arc_2_20_19  out_degree_1535  1
    arc_2_20_19  original_T_including_depot_unload_1550  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1442  1
    load_2_20_19  free_load_conservation_1534  -1
    load_2_20_19  free_load_conservation_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1444  -30
    arc_2_20_21  connected_order_arc_1445  -13
    arc_2_20_21  out_degree_1535  1
    arc_2_20_21  in_degree_1542  1
    arc_2_20_21  original_T_including_depot_unload_1550  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1444  1
    load_2_20_21  free_load_conservation_1540  1
    load_2_20_21  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1446  -30
    arc_2_21_0  depot_return_or_bypass_1470  1
    arc_2_21_0  out_degree_1541  1
    arc_2_21_0  original_T_including_depot_unload_1550  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1446  1
    load_2_21_0  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_10  arc_capacity_1447  -30
    arc_2_21_10  connected_order_arc_1448  -13
    arc_2_21_10  in_degree_1472  1
    arc_2_21_10  out_degree_1541  1
    arc_2_21_10  original_T_including_depot_unload_1550  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_10  arc_capacity_1447  1
    load_2_21_10  segment_load_conservation_1475  -1
    load_2_21_10  segment_prefix_lb_1476  1
    load_2_21_10  segment_prefix_ub_1477  1
    load_2_21_10  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1449  -30
    arc_2_21_11  connected_order_arc_1450  -13
    arc_2_21_11  in_degree_1479  1
    arc_2_21_11  out_degree_1541  1
    arc_2_21_11  original_T_including_depot_unload_1550  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1449  1
    load_2_21_11  segment_load_conservation_1482  -1
    load_2_21_11  segment_prefix_lb_1483  1
    load_2_21_11  segment_prefix_ub_1484  1
    load_2_21_11  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1451  -30
    arc_2_21_12  connected_order_arc_1452  -13
    arc_2_21_12  in_degree_1486  1
    arc_2_21_12  out_degree_1541  1
    arc_2_21_12  original_T_including_depot_unload_1550  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1451  1
    load_2_21_12  segment_load_conservation_1489  -1
    load_2_21_12  segment_prefix_lb_1490  1
    load_2_21_12  segment_prefix_ub_1491  1
    load_2_21_12  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1453  -30
    arc_2_21_13  connected_order_arc_1454  -13
    arc_2_21_13  in_degree_1493  1
    arc_2_21_13  out_degree_1541  1
    arc_2_21_13  original_T_including_depot_unload_1550  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1453  1
    load_2_21_13  segment_load_conservation_1496  -1
    load_2_21_13  segment_prefix_lb_1497  1
    load_2_21_13  segment_prefix_ub_1498  1
    load_2_21_13  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1455  -30
    arc_2_21_14  connected_order_arc_1456  -13
    arc_2_21_14  in_degree_1500  1
    arc_2_21_14  out_degree_1541  1
    arc_2_21_14  original_T_including_depot_unload_1550  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1455  1
    load_2_21_14  free_load_conservation_1504  -1
    load_2_21_14  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1457  -30
    arc_2_21_15  connected_order_arc_1458  -13
    arc_2_21_15  in_degree_1506  1
    arc_2_21_15  out_degree_1541  1
    arc_2_21_15  original_T_including_depot_unload_1550  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1457  1
    load_2_21_15  free_load_conservation_1510  -1
    load_2_21_15  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1459  -30
    arc_2_21_16  connected_order_arc_1460  -13
    arc_2_21_16  in_degree_1512  1
    arc_2_21_16  out_degree_1541  1
    arc_2_21_16  original_T_including_depot_unload_1550  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1459  1
    load_2_21_16  free_load_conservation_1516  -1
    load_2_21_16  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1461  -30
    arc_2_21_17  connected_order_arc_1462  -13
    arc_2_21_17  in_degree_1518  1
    arc_2_21_17  out_degree_1541  1
    arc_2_21_17  original_T_including_depot_unload_1550  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1461  1
    load_2_21_17  free_load_conservation_1522  -1
    load_2_21_17  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1463  -30
    arc_2_21_18  connected_order_arc_1464  -13
    arc_2_21_18  in_degree_1524  1
    arc_2_21_18  out_degree_1541  1
    arc_2_21_18  original_T_including_depot_unload_1550  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1463  1
    load_2_21_18  free_load_conservation_1528  -1
    load_2_21_18  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1465  -30
    arc_2_21_19  connected_order_arc_1466  -13
    arc_2_21_19  in_degree_1530  1
    arc_2_21_19  out_degree_1541  1
    arc_2_21_19  original_T_including_depot_unload_1550  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1465  1
    load_2_21_19  free_load_conservation_1534  -1
    load_2_21_19  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1467  -30
    arc_2_21_20  connected_order_arc_1468  -13
    arc_2_21_20  in_degree_1536  1
    arc_2_21_20  out_degree_1541  1
    arc_2_21_20  original_T_including_depot_unload_1550  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1467  1
    load_2_21_20  free_load_conservation_1540  -1
    load_2_21_20  free_load_conservation_1546  1
RHS
    RHS1      OBJ       -0.4005
    RHS1      onehot_26_18  1
    RHS1      onehot_32_47  1
    RHS1      onehot_2_82  1
    RHS1      onehot_30_103  1
    RHS1      onehot_31_132  1
    RHS1      onehot_19_153  1
    RHS1      onehot_12_188  1
    RHS1      onehot_35_223  1
    RHS1      stock_ub_227  24
    RHS1      parent_nonstrict_scope_228  4.0610049128436188e-01
    RHS1      normalization_285  1
    RHS1      connected_order_arc_396  -13
    RHS1      connected_order_arc_398  -13
    RHS1      connected_order_arc_400  -13
    RHS1      connected_order_arc_402  -13
    RHS1      connected_order_arc_404  -13
    RHS1      connected_order_arc_406  -13
    RHS1      connected_order_arc_408  -13
    RHS1      connected_order_arc_410  -13
    RHS1      connected_order_arc_412  -13
    RHS1      connected_order_arc_414  -13
    RHS1      connected_order_arc_416  -13
    RHS1      connected_order_arc_418  -13
    RHS1      connected_order_arc_421  -13
    RHS1      connected_order_arc_423  -13
    RHS1      connected_order_arc_425  -13
    RHS1      connected_order_arc_427  -13
    RHS1      connected_order_arc_429  -13
    RHS1      connected_order_arc_431  -13
    RHS1      connected_order_arc_433  -13
    RHS1      connected_order_arc_435  -13
    RHS1      connected_order_arc_437  -13
    RHS1      connected_order_arc_439  -13
    RHS1      connected_order_arc_441  -13
    RHS1      connected_order_arc_443  -13
    RHS1      connected_order_arc_446  -13
    RHS1      connected_order_arc_448  -13
    RHS1      connected_order_arc_450  -13
    RHS1      connected_order_arc_452  -13
    RHS1      connected_order_arc_454  -13
    RHS1      connected_order_arc_456  -13
    RHS1      connected_order_arc_458  -13
    RHS1      connected_order_arc_460  -13
    RHS1      connected_order_arc_462  -13
    RHS1      connected_order_arc_464  -13
    RHS1      connected_order_arc_466  -13
    RHS1      connected_order_arc_468  -13
    RHS1      connected_order_arc_471  -13
    RHS1      connected_order_arc_473  -13
    RHS1      connected_order_arc_475  -13
    RHS1      connected_order_arc_477  -13
    RHS1      connected_order_arc_479  -13
    RHS1      connected_order_arc_481  -13
    RHS1      connected_order_arc_483  -13
    RHS1      connected_order_arc_485  -13
    RHS1      connected_order_arc_487  -13
    RHS1      connected_order_arc_489  -13
    RHS1      connected_order_arc_491  -13
    RHS1      connected_order_arc_493  -13
    RHS1      connected_order_arc_496  -13
    RHS1      connected_order_arc_498  -13
    RHS1      connected_order_arc_500  -13
    RHS1      connected_order_arc_502  -13
    RHS1      connected_order_arc_504  -13
    RHS1      connected_order_arc_506  -13
    RHS1      connected_order_arc_508  -13
    RHS1      connected_order_arc_510  -13
    RHS1      connected_order_arc_512  -13
    RHS1      connected_order_arc_514  -13
    RHS1      connected_order_arc_516  -13
    RHS1      connected_order_arc_518  -13
    RHS1      connected_order_arc_521  -13
    RHS1      connected_order_arc_523  -13
    RHS1      connected_order_arc_525  -13
    RHS1      connected_order_arc_527  -13
    RHS1      connected_order_arc_529  -13
    RHS1      connected_order_arc_531  -13
    RHS1      connected_order_arc_533  -13
    RHS1      connected_order_arc_535  -13
    RHS1      connected_order_arc_537  -13
    RHS1      connected_order_arc_539  -13
    RHS1      connected_order_arc_541  -13
    RHS1      connected_order_arc_543  -13
    RHS1      connected_order_arc_546  -13
    RHS1      connected_order_arc_548  -13
    RHS1      connected_order_arc_550  -13
    RHS1      connected_order_arc_552  -13
    RHS1      connected_order_arc_554  -13
    RHS1      connected_order_arc_556  -13
    RHS1      connected_order_arc_558  -13
    RHS1      connected_order_arc_560  -13
    RHS1      connected_order_arc_562  -13
    RHS1      connected_order_arc_564  -13
    RHS1      connected_order_arc_566  -13
    RHS1      connected_order_arc_568  -13
    RHS1      connected_order_arc_571  -13
    RHS1      connected_order_arc_573  -13
    RHS1      connected_order_arc_575  -13
    RHS1      connected_order_arc_577  -13
    RHS1      connected_order_arc_579  -13
    RHS1      connected_order_arc_581  -13
    RHS1      connected_order_arc_583  -13
    RHS1      connected_order_arc_585  -13
    RHS1      connected_order_arc_587  -13
    RHS1      connected_order_arc_589  -13
    RHS1      connected_order_arc_591  -13
    RHS1      connected_order_arc_593  -13
    RHS1      connected_order_arc_596  -13
    RHS1      connected_order_arc_598  -13
    RHS1      connected_order_arc_600  -13
    RHS1      connected_order_arc_602  -13
    RHS1      connected_order_arc_604  -13
    RHS1      connected_order_arc_606  -13
    RHS1      connected_order_arc_608  -13
    RHS1      connected_order_arc_610  -13
    RHS1      connected_order_arc_612  -13
    RHS1      connected_order_arc_614  -13
    RHS1      connected_order_arc_616  -13
    RHS1      connected_order_arc_618  -13
    RHS1      connected_order_arc_621  -13
    RHS1      connected_order_arc_623  -13
    RHS1      connected_order_arc_625  -13
    RHS1      connected_order_arc_627  -13
    RHS1      connected_order_arc_629  -13
    RHS1      connected_order_arc_631  -13
    RHS1      connected_order_arc_633  -13
    RHS1      connected_order_arc_635  -13
    RHS1      connected_order_arc_637  -13
    RHS1      connected_order_arc_639  -13
    RHS1      connected_order_arc_641  -13
    RHS1      connected_order_arc_643  -13
    RHS1      connected_order_arc_646  -13
    RHS1      connected_order_arc_648  -13
    RHS1      connected_order_arc_650  -13
    RHS1      connected_order_arc_652  -13
    RHS1      connected_order_arc_654  -13
    RHS1      connected_order_arc_656  -13
    RHS1      connected_order_arc_658  -13
    RHS1      connected_order_arc_660  -13
    RHS1      connected_order_arc_662  -13
    RHS1      connected_order_arc_664  -13
    RHS1      connected_order_arc_666  -13
    RHS1      connected_order_arc_668  -13
    RHS1      connected_order_arc_671  -13
    RHS1      connected_order_arc_673  -13
    RHS1      connected_order_arc_675  -13
    RHS1      connected_order_arc_677  -13
    RHS1      connected_order_arc_679  -13
    RHS1      connected_order_arc_681  -13
    RHS1      connected_order_arc_683  -13
    RHS1      connected_order_arc_685  -13
    RHS1      connected_order_arc_687  -13
    RHS1      connected_order_arc_689  -13
    RHS1      connected_order_arc_691  -13
    RHS1      connected_order_arc_693  -13
    RHS1      connected_order_arc_696  -13
    RHS1      connected_order_arc_698  -13
    RHS1      connected_order_arc_700  -13
    RHS1      connected_order_arc_702  -13
    RHS1      connected_order_arc_704  -13
    RHS1      connected_order_arc_706  -13
    RHS1      connected_order_arc_708  -13
    RHS1      connected_order_arc_710  -13
    RHS1      connected_order_arc_712  -13
    RHS1      connected_order_arc_714  -13
    RHS1      connected_order_arc_716  -13
    RHS1      connected_order_arc_718  -13
    RHS1      depot_departure_or_bypass_719  1
    RHS1      depot_return_or_bypass_720  1
    RHS1      segment_load_conservation_725  18
    RHS1      segment_prefix_ub_727  2
    RHS1      segment_load_conservation_732  -8
    RHS1      segment_prefix_lb_733  8
    RHS1      segment_prefix_ub_734  20
    RHS1      segment_load_conservation_739  -4
    RHS1      segment_prefix_lb_740  4
    RHS1      segment_prefix_ub_741  20
    RHS1      segment_load_conservation_746  4
    RHS1      segment_prefix_ub_748  10
    RHS1      segment_load_conservation_753  -6
    RHS1      segment_prefix_lb_754  6
    RHS1      segment_prefix_ub_755  20
    RHS1      fixed_segment_relative_order_804  1
    RHS1      fixed_segment_relative_order_805  1
    RHS1      fixed_segment_relative_order_806  1
    RHS1      fixed_segment_relative_order_807  1
    RHS1      original_T_including_depot_unload_808  2.2308628253179650e+03
    RHS1      connected_order_arc_824  -12
    RHS1      connected_order_arc_826  -12
    RHS1      connected_order_arc_828  -12
    RHS1      connected_order_arc_830  -12
    RHS1      connected_order_arc_832  -12
    RHS1      connected_order_arc_834  -12
    RHS1      connected_order_arc_836  -12
    RHS1      connected_order_arc_838  -12
    RHS1      connected_order_arc_840  -12
    RHS1      connected_order_arc_842  -12
    RHS1      connected_order_arc_844  -12
    RHS1      connected_order_arc_847  -12
    RHS1      connected_order_arc_849  -12
    RHS1      connected_order_arc_851  -12
    RHS1      connected_order_arc_853  -12
    RHS1      connected_order_arc_855  -12
    RHS1      connected_order_arc_857  -12
    RHS1      connected_order_arc_859  -12
    RHS1      connected_order_arc_861  -12
    RHS1      connected_order_arc_863  -12
    RHS1      connected_order_arc_865  -12
    RHS1      connected_order_arc_867  -12
    RHS1      connected_order_arc_870  -12
    RHS1      connected_order_arc_872  -12
    RHS1      connected_order_arc_874  -12
    RHS1      connected_order_arc_876  -12
    RHS1      connected_order_arc_878  -12
    RHS1      connected_order_arc_880  -12
    RHS1      connected_order_arc_882  -12
    RHS1      connected_order_arc_884  -12
    RHS1      connected_order_arc_886  -12
    RHS1      connected_order_arc_888  -12
    RHS1      connected_order_arc_890  -12
    RHS1      connected_order_arc_893  -12
    RHS1      connected_order_arc_895  -12
    RHS1      connected_order_arc_897  -12
    RHS1      connected_order_arc_899  -12
    RHS1      connected_order_arc_901  -12
    RHS1      connected_order_arc_903  -12
    RHS1      connected_order_arc_905  -12
    RHS1      connected_order_arc_907  -12
    RHS1      connected_order_arc_909  -12
    RHS1      connected_order_arc_911  -12
    RHS1      connected_order_arc_913  -12
    RHS1      connected_order_arc_916  -12
    RHS1      connected_order_arc_918  -12
    RHS1      connected_order_arc_920  -12
    RHS1      connected_order_arc_922  -12
    RHS1      connected_order_arc_924  -12
    RHS1      connected_order_arc_926  -12
    RHS1      connected_order_arc_928  -12
    RHS1      connected_order_arc_930  -12
    RHS1      connected_order_arc_932  -12
    RHS1      connected_order_arc_934  -12
    RHS1      connected_order_arc_936  -12
    RHS1      connected_order_arc_939  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_943  -12
    RHS1      connected_order_arc_945  -12
    RHS1      connected_order_arc_947  -12
    RHS1      connected_order_arc_949  -12
    RHS1      connected_order_arc_951  -12
    RHS1      connected_order_arc_953  -12
    RHS1      connected_order_arc_955  -12
    RHS1      connected_order_arc_957  -12
    RHS1      connected_order_arc_959  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_966  -12
    RHS1      connected_order_arc_968  -12
    RHS1      connected_order_arc_970  -12
    RHS1      connected_order_arc_972  -12
    RHS1      connected_order_arc_974  -12
    RHS1      connected_order_arc_976  -12
    RHS1      connected_order_arc_978  -12
    RHS1      connected_order_arc_980  -12
    RHS1      connected_order_arc_982  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_989  -12
    RHS1      connected_order_arc_991  -12
    RHS1      connected_order_arc_993  -12
    RHS1      connected_order_arc_995  -12
    RHS1      connected_order_arc_997  -12
    RHS1      connected_order_arc_999  -12
    RHS1      connected_order_arc_1001  -12
    RHS1      connected_order_arc_1003  -12
    RHS1      connected_order_arc_1005  -12
    RHS1      connected_order_arc_1008  -12
    RHS1      connected_order_arc_1010  -12
    RHS1      connected_order_arc_1012  -12
    RHS1      connected_order_arc_1014  -12
    RHS1      connected_order_arc_1016  -12
    RHS1      connected_order_arc_1018  -12
    RHS1      connected_order_arc_1020  -12
    RHS1      connected_order_arc_1022  -12
    RHS1      connected_order_arc_1024  -12
    RHS1      connected_order_arc_1026  -12
    RHS1      connected_order_arc_1028  -12
    RHS1      connected_order_arc_1031  -12
    RHS1      connected_order_arc_1033  -12
    RHS1      connected_order_arc_1035  -12
    RHS1      connected_order_arc_1037  -12
    RHS1      connected_order_arc_1039  -12
    RHS1      connected_order_arc_1041  -12
    RHS1      connected_order_arc_1043  -12
    RHS1      connected_order_arc_1045  -12
    RHS1      connected_order_arc_1047  -12
    RHS1      connected_order_arc_1049  -12
    RHS1      connected_order_arc_1051  -12
    RHS1      connected_order_arc_1054  -12
    RHS1      connected_order_arc_1056  -12
    RHS1      connected_order_arc_1058  -12
    RHS1      connected_order_arc_1060  -12
    RHS1      connected_order_arc_1062  -12
    RHS1      connected_order_arc_1064  -12
    RHS1      connected_order_arc_1066  -12
    RHS1      connected_order_arc_1068  -12
    RHS1      connected_order_arc_1070  -12
    RHS1      connected_order_arc_1072  -12
    RHS1      connected_order_arc_1074  -12
    RHS1      connected_order_arc_1077  -12
    RHS1      connected_order_arc_1079  -12
    RHS1      connected_order_arc_1081  -12
    RHS1      connected_order_arc_1083  -12
    RHS1      connected_order_arc_1085  -12
    RHS1      connected_order_arc_1087  -12
    RHS1      connected_order_arc_1089  -12
    RHS1      connected_order_arc_1091  -12
    RHS1      connected_order_arc_1093  -12
    RHS1      connected_order_arc_1095  -12
    RHS1      connected_order_arc_1097  -12
    RHS1      depot_departure_or_bypass_1098  1
    RHS1      depot_return_or_bypass_1099  1
    RHS1      segment_load_conservation_1104  3
    RHS1      segment_prefix_ub_1106  22
    RHS1      segment_load_conservation_1111  6
    RHS1      segment_prefix_ub_1113  19
    RHS1      segment_load_conservation_1118  -4
    RHS1      segment_prefix_lb_1119  4
    RHS1      segment_prefix_ub_1120  25
    RHS1      segment_load_conservation_1125  -5
    RHS1      segment_prefix_lb_1126  5
    RHS1      segment_prefix_ub_1127  21
    RHS1      fixed_segment_relative_order_1176  1
    RHS1      fixed_segment_relative_order_1177  1
    RHS1      fixed_segment_relative_order_1178  1
    RHS1      original_T_including_depot_unload_1179  2.8302444064231877e+03
    RHS1      connected_order_arc_1195  -12
    RHS1      connected_order_arc_1197  -12
    RHS1      connected_order_arc_1199  -12
    RHS1      connected_order_arc_1201  -12
    RHS1      connected_order_arc_1203  -12
    RHS1      connected_order_arc_1205  -12
    RHS1      connected_order_arc_1207  -12
    RHS1      connected_order_arc_1209  -12
    RHS1      connected_order_arc_1211  -12
    RHS1      connected_order_arc_1213  -12
    RHS1      connected_order_arc_1215  -12
    RHS1      connected_order_arc_1218  -12
    RHS1      connected_order_arc_1220  -12
    RHS1      connected_order_arc_1222  -12
    RHS1      connected_order_arc_1224  -12
    RHS1      connected_order_arc_1226  -12
    RHS1      connected_order_arc_1228  -12
    RHS1      connected_order_arc_1230  -12
    RHS1      connected_order_arc_1232  -12
    RHS1      connected_order_arc_1234  -12
    RHS1      connected_order_arc_1236  -12
    RHS1      connected_order_arc_1238  -12
    RHS1      connected_order_arc_1241  -12
    RHS1      connected_order_arc_1243  -12
    RHS1      connected_order_arc_1245  -12
    RHS1      connected_order_arc_1247  -12
    RHS1      connected_order_arc_1249  -12
    RHS1      connected_order_arc_1251  -12
    RHS1      connected_order_arc_1253  -12
    RHS1      connected_order_arc_1255  -12
    RHS1      connected_order_arc_1257  -12
    RHS1      connected_order_arc_1259  -12
    RHS1      connected_order_arc_1261  -12
    RHS1      connected_order_arc_1264  -12
    RHS1      connected_order_arc_1266  -12
    RHS1      connected_order_arc_1268  -12
    RHS1      connected_order_arc_1270  -12
    RHS1      connected_order_arc_1272  -12
    RHS1      connected_order_arc_1274  -12
    RHS1      connected_order_arc_1276  -12
    RHS1      connected_order_arc_1278  -12
    RHS1      connected_order_arc_1280  -12
    RHS1      connected_order_arc_1282  -12
    RHS1      connected_order_arc_1284  -12
    RHS1      connected_order_arc_1287  -12
    RHS1      connected_order_arc_1289  -12
    RHS1      connected_order_arc_1291  -12
    RHS1      connected_order_arc_1293  -12
    RHS1      connected_order_arc_1295  -12
    RHS1      connected_order_arc_1297  -12
    RHS1      connected_order_arc_1299  -12
    RHS1      connected_order_arc_1301  -12
    RHS1      connected_order_arc_1303  -12
    RHS1      connected_order_arc_1305  -12
    RHS1      connected_order_arc_1307  -12
    RHS1      connected_order_arc_1310  -12
    RHS1      connected_order_arc_1312  -12
    RHS1      connected_order_arc_1314  -12
    RHS1      connected_order_arc_1316  -12
    RHS1      connected_order_arc_1318  -12
    RHS1      connected_order_arc_1320  -12
    RHS1      connected_order_arc_1322  -12
    RHS1      connected_order_arc_1324  -12
    RHS1      connected_order_arc_1326  -12
    RHS1      connected_order_arc_1328  -12
    RHS1      connected_order_arc_1330  -12
    RHS1      connected_order_arc_1333  -12
    RHS1      connected_order_arc_1335  -12
    RHS1      connected_order_arc_1337  -12
    RHS1      connected_order_arc_1339  -12
    RHS1      connected_order_arc_1341  -12
    RHS1      connected_order_arc_1343  -12
    RHS1      connected_order_arc_1345  -12
    RHS1      connected_order_arc_1347  -12
    RHS1      connected_order_arc_1349  -12
    RHS1      connected_order_arc_1351  -12
    RHS1      connected_order_arc_1353  -12
    RHS1      connected_order_arc_1356  -12
    RHS1      connected_order_arc_1358  -12
    RHS1      connected_order_arc_1360  -12
    RHS1      connected_order_arc_1362  -12
    RHS1      connected_order_arc_1364  -12
    RHS1      connected_order_arc_1366  -12
    RHS1      connected_order_arc_1368  -12
    RHS1      connected_order_arc_1370  -12
    RHS1      connected_order_arc_1372  -12
    RHS1      connected_order_arc_1374  -12
    RHS1      connected_order_arc_1376  -12
    RHS1      connected_order_arc_1379  -12
    RHS1      connected_order_arc_1381  -12
    RHS1      connected_order_arc_1383  -12
    RHS1      connected_order_arc_1385  -12
    RHS1      connected_order_arc_1387  -12
    RHS1      connected_order_arc_1389  -12
    RHS1      connected_order_arc_1391  -12
    RHS1      connected_order_arc_1393  -12
    RHS1      connected_order_arc_1395  -12
    RHS1      connected_order_arc_1397  -12
    RHS1      connected_order_arc_1399  -12
    RHS1      connected_order_arc_1402  -12
    RHS1      connected_order_arc_1404  -12
    RHS1      connected_order_arc_1406  -12
    RHS1      connected_order_arc_1408  -12
    RHS1      connected_order_arc_1410  -12
    RHS1      connected_order_arc_1412  -12
    RHS1      connected_order_arc_1414  -12
    RHS1      connected_order_arc_1416  -12
    RHS1      connected_order_arc_1418  -12
    RHS1      connected_order_arc_1420  -12
    RHS1      connected_order_arc_1422  -12
    RHS1      connected_order_arc_1425  -12
    RHS1      connected_order_arc_1427  -12
    RHS1      connected_order_arc_1429  -12
    RHS1      connected_order_arc_1431  -12
    RHS1      connected_order_arc_1433  -12
    RHS1      connected_order_arc_1435  -12
    RHS1      connected_order_arc_1437  -12
    RHS1      connected_order_arc_1439  -12
    RHS1      connected_order_arc_1441  -12
    RHS1      connected_order_arc_1443  -12
    RHS1      connected_order_arc_1445  -12
    RHS1      connected_order_arc_1448  -12
    RHS1      connected_order_arc_1450  -12
    RHS1      connected_order_arc_1452  -12
    RHS1      connected_order_arc_1454  -12
    RHS1      connected_order_arc_1456  -12
    RHS1      connected_order_arc_1458  -12
    RHS1      connected_order_arc_1460  -12
    RHS1      connected_order_arc_1462  -12
    RHS1      connected_order_arc_1464  -12
    RHS1      connected_order_arc_1466  -12
    RHS1      connected_order_arc_1468  -12
    RHS1      depot_departure_or_bypass_1469  1
    RHS1      depot_return_or_bypass_1470  1
    RHS1      segment_load_conservation_1475  2
    RHS1      segment_prefix_ub_1477  28
    RHS1      segment_load_conservation_1482  3
    RHS1      segment_prefix_ub_1484  27
    RHS1      segment_load_conservation_1489  2
    RHS1      segment_prefix_ub_1491  28
    RHS1      segment_load_conservation_1496  -5
    RHS1      segment_prefix_lb_1497  5
    RHS1      segment_prefix_ub_1498  30
    RHS1      fixed_segment_relative_order_1547  1
    RHS1      fixed_segment_relative_order_1548  1
    RHS1      fixed_segment_relative_order_1549  1
    RHS1      original_T_including_depot_unload_1550  6360
BOUNDS
 LO BND1      t         2.4288688410801524e-02
 UP BND1      t         4.0166403672397079e-02
 UP BND1      q         5.7560049128436186e-01
 BV BND1      x_26_0  
 UP BND1      w_26_0    4.0166403672397079e-02
 BV BND1      x_26_1  
 UP BND1      w_26_1    4.0166403672397079e-02
 BV BND1      x_26_2  
 UP BND1      w_26_2    4.0166403672397079e-02
 BV BND1      x_26_3  
 UP BND1      w_26_3    4.0166403672397079e-02
 BV BND1      x_26_4  
 UP BND1      w_26_4    4.0166403672397079e-02
 BV BND1      x_26_5  
 UP BND1      w_26_5    4.0166403672397079e-02
 BV BND1      x_26_6  
 UP BND1      w_26_6    4.0166403672397079e-02
 BV BND1      x_26_7  
 UP BND1      w_26_7    4.0166403672397079e-02
 BV BND1      x_26_8  
 UP BND1      w_26_8    4.0166403672397079e-02
 UP BND1      rho_26    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.0166403672397079e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.0166403672397079e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.0166403672397079e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.0166403672397079e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.0166403672397079e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.0166403672397079e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.0166403672397079e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.0166403672397079e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.0166403672397079e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.0166403672397079e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.0166403672397079e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.0166403672397079e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.0166403672397079e-02
 UP BND1      rho_32    1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.0166403672397079e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.0166403672397079e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.0166403672397079e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.0166403672397079e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.0166403672397079e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.0166403672397079e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.0166403672397079e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.0166403672397079e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.0166403672397079e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.0166403672397079e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.0166403672397079e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.0166403672397079e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.0166403672397079e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.0166403672397079e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.0166403672397079e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.0166403672397079e-02
 UP BND1      rho_2     1
 BV BND1      x_30_0  
 UP BND1      w_30_0    4.0166403672397079e-02
 BV BND1      x_30_1  
 UP BND1      w_30_1    4.0166403672397079e-02
 BV BND1      x_30_2  
 UP BND1      w_30_2    4.0166403672397079e-02
 BV BND1      x_30_3  
 UP BND1      w_30_3    4.0166403672397079e-02
 BV BND1      x_30_4  
 UP BND1      w_30_4    4.0166403672397079e-02
 BV BND1      x_30_5  
 UP BND1      w_30_5    4.0166403672397079e-02
 BV BND1      x_30_6  
 UP BND1      w_30_6    4.0166403672397079e-02
 BV BND1      x_30_7  
 UP BND1      w_30_7    4.0166403672397079e-02
 BV BND1      x_30_8  
 UP BND1      w_30_8    4.0166403672397079e-02
 UP BND1      rho_30    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.0166403672397079e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.0166403672397079e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.0166403672397079e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.0166403672397079e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.0166403672397079e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.0166403672397079e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.0166403672397079e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.0166403672397079e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.0166403672397079e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.0166403672397079e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.0166403672397079e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.0166403672397079e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.0166403672397079e-02
 UP BND1      rho_31    1
 BV BND1      x_19_0  
 UP BND1      w_19_0    4.0166403672397079e-02
 BV BND1      x_19_1  
 UP BND1      w_19_1    4.0166403672397079e-02
 BV BND1      x_19_2  
 UP BND1      w_19_2    4.0166403672397079e-02
 BV BND1      x_19_3  
 UP BND1      w_19_3    4.0166403672397079e-02
 BV BND1      x_19_4  
 UP BND1      w_19_4    4.0166403672397079e-02
 BV BND1      x_19_5  
 UP BND1      w_19_5    4.0166403672397079e-02
 BV BND1      x_19_6  
 UP BND1      w_19_6    4.0166403672397079e-02
 BV BND1      x_19_7  
 UP BND1      w_19_7    4.0166403672397079e-02
 BV BND1      x_19_8  
 UP BND1      w_19_8    4.0166403672397079e-02
 UP BND1      rho_19    1
 BV BND1      x_12_0  
 UP BND1      w_12_0    4.0166403672397079e-02
 BV BND1      x_12_1  
 UP BND1      w_12_1    4.0166403672397079e-02
 BV BND1      x_12_2  
 UP BND1      w_12_2    4.0166403672397079e-02
 BV BND1      x_12_3  
 UP BND1      w_12_3    4.0166403672397079e-02
 BV BND1      x_12_4  
 UP BND1      w_12_4    4.0166403672397079e-02
 BV BND1      x_12_5  
 UP BND1      w_12_5    4.0166403672397079e-02
 BV BND1      x_12_6  
 UP BND1      w_12_6    4.0166403672397079e-02
 BV BND1      x_12_7  
 UP BND1      w_12_7    4.0166403672397079e-02
 BV BND1      x_12_8  
 UP BND1      w_12_8    4.0166403672397079e-02
 BV BND1      x_12_9  
 UP BND1      w_12_9    4.0166403672397079e-02
 BV BND1      x_12_10 
 UP BND1      w_12_10   4.0166403672397079e-02
 BV BND1      x_12_11 
 UP BND1      w_12_11   4.0166403672397079e-02
 BV BND1      x_12_12 
 UP BND1      w_12_12   4.0166403672397079e-02
 BV BND1      x_12_13 
 UP BND1      w_12_13   4.0166403672397079e-02
 BV BND1      x_12_14 
 UP BND1      w_12_14   4.0166403672397079e-02
 BV BND1      x_12_15 
 UP BND1      w_12_15   4.0166403672397079e-02
 UP BND1      rho_12    1
 BV BND1      x_35_0  
 UP BND1      w_35_0    4.0166403672397079e-02
 BV BND1      x_35_1  
 UP BND1      w_35_1    4.0166403672397079e-02
 BV BND1      x_35_2  
 UP BND1      w_35_2    4.0166403672397079e-02
 BV BND1      x_35_3  
 UP BND1      w_35_3    4.0166403672397079e-02
 BV BND1      x_35_4  
 UP BND1      w_35_4    4.0166403672397079e-02
 BV BND1      x_35_5  
 UP BND1      w_35_5    4.0166403672397079e-02
 BV BND1      x_35_6  
 UP BND1      w_35_6    4.0166403672397079e-02
 BV BND1      x_35_7  
 UP BND1      w_35_7    4.0166403672397079e-02
 BV BND1      x_35_8  
 UP BND1      w_35_8    4.0166403672397079e-02
 BV BND1      x_35_9  
 UP BND1      w_35_9    4.0166403672397079e-02
 BV BND1      x_35_10 
 UP BND1      w_35_10   4.0166403672397079e-02
 BV BND1      x_35_11 
 UP BND1      w_35_11   4.0166403672397079e-02
 BV BND1      x_35_12 
 UP BND1      w_35_12   4.0166403672397079e-02
 BV BND1      x_35_13 
 UP BND1      w_35_13   4.0166403672397079e-02
 BV BND1      x_35_14 
 UP BND1      w_35_14   4.0166403672397079e-02
 BV BND1      x_35_15 
 UP BND1      w_35_15   4.0166403672397079e-02
 UP BND1      rho_35    1
 UP BND1      a_26_32   1
 UP BND1      a_26_2    1
 UP BND1      a_26_30   1
 UP BND1      a_26_31   1
 UP BND1      a_26_19   1
 UP BND1      a_26_12   1
 UP BND1      a_26_35   1
 UP BND1      a_32_2    1
 UP BND1      a_32_30   1
 UP BND1      a_32_31   1
 UP BND1      a_32_19   1
 UP BND1      a_32_12   1
 UP BND1      a_32_35   1
 UP BND1      a_2_30    1
 UP BND1      a_2_31    1
 UP BND1      a_2_19    1
 UP BND1      a_2_12    1
 UP BND1      a_2_35    1
 UP BND1      a_30_31   1
 UP BND1      a_30_19   1
 UP BND1      a_30_12   1
 UP BND1      a_30_35   1
 UP BND1      a_31_19   1
 UP BND1      a_31_12   1
 UP BND1      a_31_35   1
 UP BND1      a_19_12   1
 UP BND1      a_19_35   1
 UP BND1      a_12_35   1
 BV BND1      service_0_26_1
 BV BND1      service_0_26_2
 BV BND1      service_0_26_3
 BV BND1      service_0_26_4
 BV BND1      service_0_26_5
 BV BND1      service_0_26_6
 BV BND1      service_0_26_7
 BV BND1      service_0_26_8
 BV BND1      service_1_26_1
 BV BND1      service_1_26_2
 BV BND1      service_1_26_3
 BV BND1      service_1_26_4
 BV BND1      service_1_26_5
 BV BND1      service_1_26_6
 BV BND1      service_1_26_7
 BV BND1      service_1_26_8
 BV BND1      service_2_26_1
 BV BND1      service_2_26_2
 BV BND1      service_2_26_3
 BV BND1      service_2_26_4
 BV BND1      service_2_26_5
 BV BND1      service_2_26_6
 BV BND1      service_2_26_7
 BV BND1      service_2_26_8
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_30_0
 BV BND1      service_0_30_1
 BV BND1      service_0_30_2
 BV BND1      service_0_30_3
 BV BND1      service_0_30_4
 BV BND1      service_0_30_6
 BV BND1      service_0_30_7
 BV BND1      service_0_30_8
 BV BND1      service_1_30_0
 BV BND1      service_1_30_1
 BV BND1      service_1_30_2
 BV BND1      service_1_30_3
 BV BND1      service_1_30_4
 BV BND1      service_1_30_6
 BV BND1      service_1_30_7
 BV BND1      service_1_30_8
 BV BND1      service_2_30_0
 BV BND1      service_2_30_1
 BV BND1      service_2_30_2
 BV BND1      service_2_30_3
 BV BND1      service_2_30_4
 BV BND1      service_2_30_6
 BV BND1      service_2_30_7
 BV BND1      service_2_30_8
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_2_19_1
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 BV BND1      service_0_12_1
 BV BND1      service_0_12_2
 BV BND1      service_0_12_3
 BV BND1      service_0_12_4
 BV BND1      service_0_12_5
 BV BND1      service_0_12_6
 BV BND1      service_0_12_7
 BV BND1      service_0_12_8
 BV BND1      service_0_12_9
 BV BND1      service_0_12_10
 BV BND1      service_0_12_11
 BV BND1      service_0_12_12
 BV BND1      service_0_12_13
 BV BND1      service_0_12_14
 BV BND1      service_0_12_15
 BV BND1      service_1_12_1
 BV BND1      service_1_12_2
 BV BND1      service_1_12_3
 BV BND1      service_1_12_4
 BV BND1      service_1_12_5
 BV BND1      service_1_12_6
 BV BND1      service_1_12_7
 BV BND1      service_1_12_8
 BV BND1      service_1_12_9
 BV BND1      service_1_12_10
 BV BND1      service_1_12_11
 BV BND1      service_1_12_12
 BV BND1      service_1_12_13
 BV BND1      service_1_12_14
 BV BND1      service_1_12_15
 BV BND1      service_2_12_1
 BV BND1      service_2_12_2
 BV BND1      service_2_12_3
 BV BND1      service_2_12_4
 BV BND1      service_2_12_5
 BV BND1      service_2_12_6
 BV BND1      service_2_12_7
 BV BND1      service_2_12_8
 BV BND1      service_2_12_9
 BV BND1      service_2_12_10
 BV BND1      service_2_12_11
 BV BND1      service_2_12_12
 BV BND1      service_2_12_13
 BV BND1      service_2_12_14
 BV BND1      service_2_12_15
 BV BND1      service_0_35_0
 BV BND1      service_0_35_1
 BV BND1      service_0_35_2
 BV BND1      service_0_35_3
 BV BND1      service_0_35_4
 BV BND1      service_0_35_5
 BV BND1      service_0_35_6
 BV BND1      service_0_35_7
 BV BND1      service_0_35_8
 BV BND1      service_0_35_9
 BV BND1      service_0_35_10
 BV BND1      service_0_35_12
 BV BND1      service_0_35_13
 BV BND1      service_0_35_14
 BV BND1      service_0_35_15
 BV BND1      service_1_35_0
 BV BND1      service_1_35_1
 BV BND1      service_1_35_2
 BV BND1      service_1_35_3
 BV BND1      service_1_35_4
 BV BND1      service_1_35_5
 BV BND1      service_1_35_6
 BV BND1      service_1_35_7
 BV BND1      service_1_35_8
 BV BND1      service_1_35_9
 BV BND1      service_1_35_10
 BV BND1      service_1_35_12
 BV BND1      service_1_35_13
 BV BND1      service_1_35_14
 BV BND1      service_1_35_15
 BV BND1      service_2_35_0
 BV BND1      service_2_35_1
 BV BND1      service_2_35_2
 BV BND1      service_2_35_3
 BV BND1      service_2_35_4
 BV BND1      service_2_35_5
 BV BND1      service_2_35_6
 BV BND1      service_2_35_7
 BV BND1      service_2_35_8
 BV BND1      service_2_35_9
 BV BND1      service_2_35_10
 BV BND1      service_2_35_12
 BV BND1      service_2_35_13
 BV BND1      service_2_35_14
 BV BND1      service_2_35_15
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_14_21
 UP BND1      load_0_14_21  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_14
 UP BND1      load_0_21_14  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_6_21
 UP BND1      load_1_6_21  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_14_21
 UP BND1      load_1_14_21  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_6
 UP BND1      load_1_21_6  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_14
 UP BND1      load_1_21_14  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  12
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  12
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  12
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  12
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  12
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  12
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  12
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  12
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  12
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  12
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  12
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  12
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_10_21
 UP BND1      load_2_10_21  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_10
 UP BND1      load_2_21_10  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
ENDATA
