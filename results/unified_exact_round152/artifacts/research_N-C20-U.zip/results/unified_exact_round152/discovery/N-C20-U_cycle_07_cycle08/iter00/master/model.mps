* Signature: 0xd561a8079dc54f89
NAME 
OBJSENSE MAX
ROWS
 N  OBJ
 L  column_0
 L  column_1
 L  column_2
 L  column_3
 L  column_4
 L  column_5
 L  column_6
 L  column_7
 L  column_8
 L  column_9
 L  column_10
 L  column_11
COLUMNS
    psi[1,11]  OBJ       1
    psi[1,11]  column_0  1
    psi[1,11]  column_1  1
    psi[1,11]  column_2  1
    psi[1,11]  column_3  1
    psi[1,11]  column_4  1
    psi[1,11]  column_5  1
    psi[1,11]  column_6  1
    psi[1,11]  column_7  1
    psi[1,11]  column_8  1
    psi[1,11]  column_9  1
    psi[1,11]  column_10  1
    psi[1,11]  column_11  1
    psi[2,14]  OBJ       1
    psi[2,14]  column_0  1
    psi[2,14]  column_1  1
    psi[2,14]  column_2  1
    psi[2,14]  column_3  1
    psi[2,14]  column_4  1
    psi[2,14]  column_5  1
    psi[2,14]  column_6  1
    psi[2,14]  column_7  1
    psi[2,14]  column_8  1
    psi[2,14]  column_9  1
    psi[2,14]  column_10  1
    psi[2,14]  column_11  1
    psi[3,15]  OBJ       9.8864876867121176e-01
    psi[3,15]  column_0  1
    psi[3,15]  column_1  1
    psi[3,15]  column_2  1
    psi[3,15]  column_3  1
    psi[3,15]  column_4  1
    psi[3,15]  column_5  1
    psi[3,15]  column_6  1
    psi[3,15]  column_7  1
    psi[3,15]  column_8  1
    psi[3,15]  column_9  1
    psi[3,24]  OBJ       1.1351231328788181e-02
    psi[3,24]  column_10  1
    psi[3,24]  column_11  1
    psi[4,11]  OBJ       1
    psi[4,11]  column_0  1
    psi[4,11]  column_1  1
    psi[4,11]  column_2  1
    psi[4,11]  column_3  1
    psi[4,11]  column_4  1
    psi[4,11]  column_5  1
    psi[4,11]  column_6  1
    psi[4,11]  column_7  1
    psi[4,11]  column_8  1
    psi[4,11]  column_9  1
    psi[4,11]  column_10  1
    psi[4,11]  column_11  1
    psi[5,11]  OBJ       6.2048763898899262e-01
    psi[5,11]  column_0  1
    psi[5,11]  column_1  1
    psi[5,11]  column_2  1
    psi[5,11]  column_3  1
    psi[5,11]  column_4  1
    psi[5,11]  column_5  1
    psi[5,11]  column_6  1
    psi[5,11]  column_10  1
    psi[5,11]  column_11  1
    psi[5,18]  OBJ       3.7951236101100733e-01
    psi[5,18]  column_7  1
    psi[5,18]  column_8  1
    psi[5,18]  column_9  1
    psi[6,11]  OBJ       0.704823719213661
    psi[6,11]  column_0  1
    psi[6,11]  column_1  1
    psi[6,11]  column_2  1
    psi[6,11]  column_3  1
    psi[6,11]  column_4  1
    psi[6,11]  column_7  1
    psi[6,11]  column_8  1
    psi[6,11]  column_9  1
    psi[6,20]  OBJ       0.295176280786339
    psi[6,20]  column_5  1
    psi[6,20]  column_6  1
    psi[6,20]  column_10  1
    psi[6,20]  column_11  1
    psi[7,10]  OBJ       1
    psi[7,10]  column_0  1
    psi[7,10]  column_1  1
    psi[7,10]  column_2  1
    psi[7,10]  column_3  1
    psi[7,10]  column_4  1
    psi[7,10]  column_5  1
    psi[7,10]  column_6  1
    psi[7,10]  column_7  1
    psi[7,10]  column_8  1
    psi[7,10]  column_9  1
    psi[7,10]  column_10  1
    psi[7,10]  column_11  1
    psi[8,11]  OBJ       1
    psi[8,11]  column_0  1
    psi[8,11]  column_1  1
    psi[8,11]  column_2  1
    psi[8,11]  column_3  1
    psi[8,11]  column_4  1
    psi[8,11]  column_5  1
    psi[8,11]  column_6  1
    psi[8,11]  column_7  1
    psi[8,11]  column_8  1
    psi[8,11]  column_9  1
    psi[8,11]  column_10  1
    psi[8,11]  column_11  1
    psi[9,9]  OBJ       1
    psi[9,9]  column_0  1
    psi[9,9]  column_1  1
    psi[9,9]  column_2  1
    psi[9,9]  column_3  1
    psi[9,9]  column_4  1
    psi[9,9]  column_5  1
    psi[9,9]  column_6  1
    psi[9,9]  column_7  1
    psi[9,9]  column_8  1
    psi[9,9]  column_9  1
    psi[9,9]  column_10  1
    psi[9,9]  column_11  1
    psi[10,16]  OBJ       1
    psi[10,16]  column_0  1
    psi[10,16]  column_1  1
    psi[10,16]  column_2  1
    psi[10,16]  column_3  1
    psi[10,16]  column_4  1
    psi[10,16]  column_5  1
    psi[10,16]  column_6  1
    psi[10,16]  column_7  1
    psi[10,16]  column_8  1
    psi[10,16]  column_9  1
    psi[10,16]  column_10  1
    psi[10,16]  column_11  1
    psi[11,17]  OBJ       1
    psi[11,17]  column_0  1
    psi[11,17]  column_1  1
    psi[11,17]  column_2  1
    psi[11,17]  column_3  1
    psi[11,17]  column_4  1
    psi[11,17]  column_5  1
    psi[11,17]  column_6  1
    psi[11,17]  column_7  1
    psi[11,17]  column_8  1
    psi[11,17]  column_9  1
    psi[11,17]  column_10  1
    psi[11,17]  column_11  1
    psi[12,10]  OBJ       6.9811516737760781e-01
    psi[12,10]  column_0  1
    psi[12,10]  column_1  1
    psi[12,10]  column_2  1
    psi[12,10]  column_3  1
    psi[12,10]  column_4  1
    psi[12,10]  column_5  1
    psi[12,10]  column_7  1
    psi[12,10]  column_8  1
    psi[12,10]  column_10  1
    psi[12,10]  column_11  1
    psi[12,18]  OBJ       3.0188483262239219e-01
    psi[12,18]  column_6  1
    psi[12,18]  column_9  1
    psi[13,13]  OBJ       1
    psi[13,13]  column_0  1
    psi[13,13]  column_1  1
    psi[13,13]  column_2  1
    psi[13,13]  column_3  1
    psi[13,13]  column_4  1
    psi[13,13]  column_5  1
    psi[13,13]  column_6  1
    psi[13,13]  column_7  1
    psi[13,13]  column_8  1
    psi[13,13]  column_9  1
    psi[13,13]  column_10  1
    psi[13,13]  column_11  1
    psi[14,13]  OBJ       1
    psi[14,13]  column_0  1
    psi[14,13]  column_1  1
    psi[14,13]  column_2  1
    psi[14,13]  column_3  1
    psi[14,13]  column_4  1
    psi[14,13]  column_5  1
    psi[14,13]  column_6  1
    psi[14,13]  column_7  1
    psi[14,13]  column_8  1
    psi[14,13]  column_9  1
    psi[14,13]  column_10  1
    psi[14,13]  column_11  1
    psi[15,14]  OBJ       1
    psi[15,14]  column_0  1
    psi[15,14]  column_1  1
    psi[15,14]  column_2  1
    psi[15,14]  column_3  1
    psi[15,14]  column_4  1
    psi[15,14]  column_5  1
    psi[15,14]  column_6  1
    psi[15,14]  column_7  1
    psi[15,14]  column_8  1
    psi[15,14]  column_9  1
    psi[15,14]  column_10  1
    psi[15,14]  column_11  1
    psi[16,12]  OBJ       0.654569455194751
    psi[16,12]  column_0  1
    psi[16,12]  column_1  1
    psi[16,12]  column_2  1
    psi[16,12]  column_3  1
    psi[16,12]  column_7  1
    psi[16,12]  column_9  1
    psi[16,12]  column_10  1
    psi[16,13]  OBJ       2.6347563759034465e-02
    psi[16,13]  column_8  1
    psi[16,21]  OBJ       3.1908298104621452e-01
    psi[16,21]  column_4  1
    psi[16,21]  column_5  1
    psi[16,21]  column_6  1
    psi[16,21]  column_11  1
    psi[17,8]  OBJ       7.5849213390208625e-01
    psi[17,8]  column_0  1
    psi[17,8]  column_1  1
    psi[17,8]  column_2  1
    psi[17,8]  column_4  1
    psi[17,8]  column_5  1
    psi[17,8]  column_6  1
    psi[17,8]  column_7  1
    psi[17,8]  column_8  1
    psi[17,8]  column_9  1
    psi[17,8]  column_10  1
    psi[17,8]  column_11  1
    psi[17,16]  OBJ       2.4150786609791375e-01
    psi[17,16]  column_3  1
    psi[18,11]  OBJ       0.704823719213661
    psi[18,11]  column_0  1
    psi[18,11]  column_1  1
    psi[18,11]  column_2  1
    psi[18,11]  column_5  1
    psi[18,11]  column_6  1
    psi[18,11]  column_7  1
    psi[18,11]  column_9  1
    psi[18,11]  column_10  1
    psi[18,11]  column_11  1
    psi[18,20]  OBJ       0.295176280786339
    psi[18,20]  column_3  1
    psi[18,20]  column_4  1
    psi[18,20]  column_8  1
    psi[19,12]  OBJ       5.5015816130927231e-01
    psi[19,12]  column_0  1
    psi[19,12]  column_6  1
    psi[19,12]  column_7  1
    psi[19,13]  OBJ       1.0009147376440808e-01
    psi[19,13]  column_1  1
    psi[19,13]  column_4  1
    psi[19,13]  column_5  1
    psi[19,13]  column_10  1
    psi[19,13]  column_11  1
    psi[19,20]  OBJ       3.4975036492631961e-01
    psi[19,20]  column_2  1
    psi[19,20]  column_3  1
    psi[19,20]  column_8  1
    psi[19,20]  column_9  1
    psi[20,13]  OBJ       6.0754971759089038e-01
    psi[20,13]  column_0  1
    psi[20,13]  column_3  1
    psi[20,13]  column_6  1
    psi[20,13]  column_8  1
    psi[20,13]  column_9  1
    psi[20,13]  column_11  1
    psi[20,21]  OBJ       3.9245028240910962e-01
    psi[20,21]  column_1  1
    psi[20,21]  column_2  1
    psi[20,21]  column_4  1
    psi[20,21]  column_5  1
    psi[20,21]  column_7  1
    psi[20,21]  column_10  1
    a         OBJ       1
    a         column_0  1
    a         column_1  1
    a         column_2  1
    a         column_3  1
    a         column_4  1
    a         column_5  1
    a         column_6  1
    a         column_7  1
    a         column_8  1
    a         column_9  1
    a         column_10  1
    a         column_11  1
RHS
    RHS1      column_0  2.3037127760972e-17
    RHS1      column_1  3.1666150510994140e-02
    RHS1      column_2  5.4337349397590377e-02
    RHS1      column_3  9.5417789757412413e-02
    RHS1      column_4  8.6697199685946108e-02
    RHS1      column_5  8.6697199685946108e-02
    RHS1      column_6  9.0296687665108746e-02
    RHS1      column_7  5.3060217176702888e-02
    RHS1      column_8  0.0844592289321051
    RHS1      column_9  8.1615026048807257e-02
    RHS1      column_10  8.1589930597640234e-02
    RHS1      column_11  0.086238594579872
BOUNDS
 FX BND1      psi[1,11]  0
 FX BND1      psi[2,14]  0
 FX BND1      psi[3,15]  0
 LO BND1      psi[3,24]  -0.05
 UP BND1      psi[3,24]  0.05
 FX BND1      psi[4,11]  0
 FX BND1      psi[5,11]  0
 LO BND1      psi[5,18]  -0.05
 UP BND1      psi[5,18]  0.05
 FX BND1      psi[6,11]  0
 LO BND1      psi[6,20]  -0.05
 UP BND1      psi[6,20]  0.05
 FX BND1      psi[7,10]  0
 FX BND1      psi[8,11]  0
 FX BND1      psi[9,9]  0
 FX BND1      psi[10,16]  0
 FX BND1      psi[11,17]  0
 FX BND1      psi[12,10]  0
 LO BND1      psi[12,18]  -0.05
 UP BND1      psi[12,18]  0.05
 FX BND1      psi[13,13]  0
 FX BND1      psi[14,13]  0
 FX BND1      psi[15,14]  0
 FX BND1      psi[16,12]  0
 LO BND1      psi[16,13]  -0.05
 UP BND1      psi[16,13]  0.05
 LO BND1      psi[16,21]  -0.05
 UP BND1      psi[16,21]  0.05
 FX BND1      psi[17,8]  0
 LO BND1      psi[17,16]  -0.05
 UP BND1      psi[17,16]  0.05
 FX BND1      psi[18,11]  0
 LO BND1      psi[18,20]  -0.05
 UP BND1      psi[18,20]  0.05
 FX BND1      psi[19,12]  0
 LO BND1      psi[19,13]  -0.05
 UP BND1      psi[19,13]  0.05
 LO BND1      psi[19,20]  -0.05
 UP BND1      psi[19,20]  0.05
 FX BND1      psi[20,13]  0
 LO BND1      psi[20,21]  -0.05
 UP BND1      psi[20,21]  0.05
 FR BND1      a       
ENDATA
