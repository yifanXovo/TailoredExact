* Signature: 0x6983c590e928df4
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_18_32
 E  normalized_mass_18_33
 E  normalized_ratio_18_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 E  onehot_15_39
 E  normalized_mass_15_40
 E  normalized_ratio_15_41
 G  product_lb_42
 L  product_ub_43
 G  product_lb_44
 L  product_ub_45
 G  product_lb_46
 L  product_ub_47
 G  product_lb_48
 L  product_ub_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 E  onehot_17_76
 E  normalized_mass_17_77
 E  normalized_ratio_17_78
 G  product_lb_79
 L  product_ub_80
 G  product_lb_81
 L  product_ub_82
 G  product_lb_83
 L  product_ub_84
 E  onehot_16_85
 E  normalized_mass_16_86
 E  normalized_ratio_16_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 G  product_lb_108
 L  product_ub_109
 G  product_lb_110
 L  product_ub_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 E  onehot_20_120
 E  normalized_mass_20_121
 E  normalized_ratio_20_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 E  onehot_19_135
 E  normalized_mass_19_136
 E  normalized_ratio_19_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 E  onehot_11_170
 E  normalized_mass_11_171
 E  normalized_ratio_11_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 E  onehot_12_205
 E  normalized_mass_12_206
 E  normalized_ratio_12_207
 G  stock_lb_208
 L  stock_ub_209
 L  parent_nonstrict_scope_210
 G  block_pair_pos_211
 G  block_pair_neg_212
 G  block_pair_pos_213
 G  block_pair_neg_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 E  normalization_267
 G  full_original_Gini_268
 E  unique_nonzero_owner_269
 E  unique_nonzero_owner_270
 E  unique_nonzero_owner_271
 E  unique_nonzero_owner_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 L  arc_capacity_353
 L  arc_capacity_354
 L  arc_capacity_355
 L  arc_capacity_356
 L  arc_capacity_357
 L  arc_capacity_358
 L  arc_capacity_359
 L  arc_capacity_360
 L  arc_capacity_361
 L  arc_capacity_362
 L  arc_capacity_363
 L  arc_capacity_364
 L  arc_capacity_365
 L  arc_capacity_366
 L  arc_capacity_367
 L  arc_capacity_368
 L  arc_capacity_369
 G  connected_order_arc_370
 L  arc_capacity_371
 G  connected_order_arc_372
 L  arc_capacity_373
 G  connected_order_arc_374
 L  arc_capacity_375
 G  connected_order_arc_376
 L  arc_capacity_377
 G  connected_order_arc_378
 L  arc_capacity_379
 G  connected_order_arc_380
 L  arc_capacity_381
 G  connected_order_arc_382
 L  arc_capacity_383
 G  connected_order_arc_384
 L  arc_capacity_385
 G  connected_order_arc_386
 L  arc_capacity_387
 G  connected_order_arc_388
 L  arc_capacity_389
 G  connected_order_arc_390
 L  arc_capacity_391
 G  connected_order_arc_392
 L  arc_capacity_393
 G  connected_order_arc_394
 L  arc_capacity_395
 L  arc_capacity_396
 G  connected_order_arc_397
 L  arc_capacity_398
 G  connected_order_arc_399
 L  arc_capacity_400
 G  connected_order_arc_401
 L  arc_capacity_402
 G  connected_order_arc_403
 L  arc_capacity_404
 G  connected_order_arc_405
 L  arc_capacity_406
 G  connected_order_arc_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 G  connected_order_arc_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 G  connected_order_arc_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 G  connected_order_arc_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 L  arc_capacity_740
 G  connected_order_arc_741
 L  arc_capacity_742
 G  connected_order_arc_743
 L  arc_capacity_744
 G  connected_order_arc_745
 E  depot_departure_or_bypass_746
 E  depot_return_or_bypass_747
 E  out_degree_748
 E  in_degree_749
 G  order_active_lb_750
 L  order_active_ub_751
 E  segment_load_conservation_752
 G  segment_prefix_lb_753
 L  segment_prefix_ub_754
 E  out_degree_755
 E  in_degree_756
 G  order_active_lb_757
 L  order_active_ub_758
 E  segment_load_conservation_759
 G  segment_prefix_lb_760
 L  segment_prefix_ub_761
 E  out_degree_762
 E  in_degree_763
 G  order_active_lb_764
 L  order_active_ub_765
 E  segment_load_conservation_766
 G  segment_prefix_lb_767
 L  segment_prefix_ub_768
 E  out_degree_769
 E  in_degree_770
 G  order_active_lb_771
 L  order_active_ub_772
 E  segment_load_conservation_773
 G  segment_prefix_lb_774
 L  segment_prefix_ub_775
 E  out_degree_776
 E  in_degree_777
 G  order_active_lb_778
 L  order_active_ub_779
 E  segment_load_conservation_780
 G  segment_prefix_lb_781
 L  segment_prefix_ub_782
 E  out_degree_783
 E  in_degree_784
 G  order_active_lb_785
 L  order_active_ub_786
 E  segment_load_conservation_787
 G  segment_prefix_lb_788
 L  segment_prefix_ub_789
 E  out_degree_790
 E  in_degree_791
 G  order_active_lb_792
 L  order_active_ub_793
 E  service_visit_def_794
 E  free_load_conservation_795
 E  out_degree_796
 E  in_degree_797
 G  order_active_lb_798
 L  order_active_ub_799
 E  service_visit_def_800
 E  free_load_conservation_801
 E  out_degree_802
 E  in_degree_803
 G  order_active_lb_804
 L  order_active_ub_805
 E  service_visit_def_806
 E  free_load_conservation_807
 E  out_degree_808
 E  in_degree_809
 G  order_active_lb_810
 L  order_active_ub_811
 E  service_visit_def_812
 E  free_load_conservation_813
 E  out_degree_814
 E  in_degree_815
 G  order_active_lb_816
 L  order_active_ub_817
 E  service_visit_def_818
 E  free_load_conservation_819
 E  out_degree_820
 E  in_degree_821
 G  order_active_lb_822
 L  order_active_ub_823
 E  service_visit_def_824
 E  free_load_conservation_825
 E  out_degree_826
 E  in_degree_827
 G  order_active_lb_828
 L  order_active_ub_829
 E  service_visit_def_830
 E  free_load_conservation_831
 E  out_degree_832
 E  in_degree_833
 G  order_active_lb_834
 L  order_active_ub_835
 E  service_visit_def_836
 E  free_load_conservation_837
 G  fixed_segment_relative_order_838
 G  fixed_segment_relative_order_839
 G  fixed_segment_relative_order_840
 G  fixed_segment_relative_order_841
 G  fixed_segment_relative_order_842
 L  original_T_including_depot_unload_843
 L  arc_capacity_844
 L  arc_capacity_845
 L  arc_capacity_846
 L  arc_capacity_847
 L  arc_capacity_848
 L  arc_capacity_849
 L  arc_capacity_850
 L  arc_capacity_851
 L  arc_capacity_852
 L  arc_capacity_853
 L  arc_capacity_854
 L  arc_capacity_855
 L  arc_capacity_856
 L  arc_capacity_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 G  connected_order_arc_863
 L  arc_capacity_864
 G  connected_order_arc_865
 L  arc_capacity_866
 G  connected_order_arc_867
 L  arc_capacity_868
 G  connected_order_arc_869
 L  arc_capacity_870
 G  connected_order_arc_871
 L  arc_capacity_872
 G  connected_order_arc_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 L  arc_capacity_881
 G  connected_order_arc_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 G  connected_order_arc_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 E  depot_departure_or_bypass_1133
 E  depot_return_or_bypass_1134
 E  out_degree_1135
 E  in_degree_1136
 G  order_active_lb_1137
 L  order_active_ub_1138
 E  segment_load_conservation_1139
 G  segment_prefix_lb_1140
 L  segment_prefix_ub_1141
 E  out_degree_1142
 E  in_degree_1143
 G  order_active_lb_1144
 L  order_active_ub_1145
 E  segment_load_conservation_1146
 G  segment_prefix_lb_1147
 L  segment_prefix_ub_1148
 E  out_degree_1149
 E  in_degree_1150
 G  order_active_lb_1151
 L  order_active_ub_1152
 E  segment_load_conservation_1153
 G  segment_prefix_lb_1154
 L  segment_prefix_ub_1155
 E  out_degree_1156
 E  in_degree_1157
 G  order_active_lb_1158
 L  order_active_ub_1159
 E  segment_load_conservation_1160
 G  segment_prefix_lb_1161
 L  segment_prefix_ub_1162
 E  out_degree_1163
 E  in_degree_1164
 G  order_active_lb_1165
 L  order_active_ub_1166
 E  service_visit_def_1167
 E  free_load_conservation_1168
 E  out_degree_1169
 E  in_degree_1170
 G  order_active_lb_1171
 L  order_active_ub_1172
 E  service_visit_def_1173
 E  free_load_conservation_1174
 E  out_degree_1175
 E  in_degree_1176
 G  order_active_lb_1177
 L  order_active_ub_1178
 E  service_visit_def_1179
 E  free_load_conservation_1180
 E  out_degree_1181
 E  in_degree_1182
 G  order_active_lb_1183
 L  order_active_ub_1184
 E  service_visit_def_1185
 E  free_load_conservation_1186
 E  out_degree_1187
 E  in_degree_1188
 G  order_active_lb_1189
 L  order_active_ub_1190
 E  service_visit_def_1191
 E  free_load_conservation_1192
 E  out_degree_1193
 E  in_degree_1194
 G  order_active_lb_1195
 L  order_active_ub_1196
 E  service_visit_def_1197
 E  free_load_conservation_1198
 E  out_degree_1199
 E  in_degree_1200
 G  order_active_lb_1201
 L  order_active_ub_1202
 E  service_visit_def_1203
 E  free_load_conservation_1204
 E  out_degree_1205
 E  in_degree_1206
 G  order_active_lb_1207
 L  order_active_ub_1208
 E  service_visit_def_1209
 E  free_load_conservation_1210
 G  fixed_segment_relative_order_1211
 G  fixed_segment_relative_order_1212
 G  fixed_segment_relative_order_1213
 L  original_T_including_depot_unload_1214
COLUMNS
    t         normalized_mass_18_33  -1
    t         normalized_mass_15_40  -1
    t         normalized_mass_17_77  -1
    t         normalized_mass_16_86  -1
    t         normalized_mass_20_121  -1
    t         normalized_mass_19_136  -1
    t         normalized_mass_11_171  -1
    t         normalized_mass_12_206  -1
    t         normalization_267  9.29642857142857
    t         full_original_Gini_268  -2.6374999999999993e+01
    q         OBJ       1
    q         parent_nonstrict_scope_210  1
    q         full_original_Gini_268  20
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       3.2863847044708572e-02
    x_18_0    product_lb_0  -0.040634019704234
    x_18_0    product_ub_1  -1.0756819054947372e-01
    x_18_0    onehot_18_32  1
    x_18_0    parent_nonstrict_scope_210  7.6682309770986667e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_0  1
    w_18_0    product_ub_1  1
    w_18_0    normalized_mass_18_33  1
    w_18_0    full_original_Gini_268  -9.29642857142857
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       2.1909231363139048e-02
    x_18_1    product_lb_2  -0.040634019704234
    x_18_1    product_ub_3  -1.0756819054947372e-01
    x_18_1    onehot_18_32  1
    x_18_1    stock_lb_208  1
    x_18_1    stock_ub_209  1
    x_18_1    parent_nonstrict_scope_210  6.5727694089417144e-02
    x_18_1    unique_nonzero_owner_269  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_2  1
    w_18_1    product_ub_3  1
    w_18_1    normalized_mass_18_33  1
    w_18_1    normalized_ratio_18_34  -1.4285714285714285e-01
    w_18_1    full_original_Gini_268  -8.15357142857143
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       1.0954615681569524e-02
    x_18_2    product_lb_4  -0.040634019704234
    x_18_2    product_ub_5  -1.0756819054947372e-01
    x_18_2    onehot_18_32  1
    x_18_2    stock_lb_208  2
    x_18_2    stock_ub_209  2
    x_18_2    parent_nonstrict_scope_210  5.4773078407847620e-02
    x_18_2    unique_nonzero_owner_270  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_4  1
    w_18_2    product_ub_5  1
    w_18_2    normalized_mass_18_33  1
    w_18_2    normalized_ratio_18_34  -2.8571428571428570e-01
    w_18_2    full_original_Gini_268  -7.0107142857142870e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_3    product_lb_6  -0.040634019704234
    x_18_3    product_ub_7  -1.0756819054947372e-01
    x_18_3    onehot_18_32  1
    x_18_3    stock_lb_208  3
    x_18_3    stock_ub_209  3
    x_18_3    parent_nonstrict_scope_210  4.3818462726278096e-02
    x_18_3    unique_nonzero_owner_271  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_6  1
    w_18_3    product_ub_7  1
    w_18_3    normalized_mass_18_33  1
    w_18_3    normalized_ratio_18_34  -4.2857142857142855e-01
    w_18_3    full_original_Gini_268  -5.8678571428571420e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       -1.0954615681569524e-02
    x_18_4    product_lb_8  -0.040634019704234
    x_18_4    product_ub_9  -1.0756819054947372e-01
    x_18_4    onehot_18_32  1
    x_18_4    stock_lb_208  4
    x_18_4    stock_ub_209  4
    x_18_4    parent_nonstrict_scope_210  3.2863847044708572e-02
    x_18_4    unique_nonzero_owner_272  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_8  1
    w_18_4    product_ub_9  1
    w_18_4    normalized_mass_18_33  1
    w_18_4    normalized_ratio_18_34  -5.7142857142857140e-01
    w_18_4    full_original_Gini_268  -4.7250000000000005e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -2.1909231363139041e-02
    x_18_5    product_lb_10  -0.040634019704234
    x_18_5    product_ub_11  -1.0756819054947372e-01
    x_18_5    onehot_18_32  1
    x_18_5    stock_lb_208  5
    x_18_5    stock_ub_209  5
    x_18_5    parent_nonstrict_scope_210  2.1909231363139055e-02
    x_18_5    unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_10  1
    w_18_5    product_ub_11  1
    w_18_5    normalized_mass_18_33  1
    w_18_5    normalized_ratio_18_34  -7.1428571428571419e-01
    w_18_5    full_original_Gini_268  -4.0964285714285706e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -3.2863847044708572e-02
    x_18_6    product_lb_12  -0.040634019704234
    x_18_6    product_ub_13  -1.0756819054947372e-01
    x_18_6    onehot_18_32  1
    x_18_6    stock_lb_208  6
    x_18_6    stock_ub_209  6
    x_18_6    parent_nonstrict_scope_210  1.0954615681569527e-02
    x_18_6    unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_12  1
    w_18_6    product_ub_13  1
    w_18_6    normalized_mass_18_33  1
    w_18_6    normalized_ratio_18_34  -8.5714285714285710e-01
    w_18_6    full_original_Gini_268  -3.5249999999999995e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -4.3818462726278096e-02
    x_18_7    product_lb_14  -0.040634019704234
    x_18_7    product_ub_15  -1.0756819054947372e-01
    x_18_7    onehot_18_32  1
    x_18_7    stock_lb_208  7
    x_18_7    stock_ub_209  7
    x_18_7    unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_14  1
    w_18_7    product_ub_15  1
    w_18_7    normalized_mass_18_33  1
    w_18_7    normalized_ratio_18_34  -1
    w_18_7    full_original_Gini_268  -2.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       -3.2863847044708579e-02
    x_18_8    product_lb_16  -0.040634019704234
    x_18_8    product_ub_17  -1.0756819054947372e-01
    x_18_8    onehot_18_32  1
    x_18_8    stock_lb_208  8
    x_18_8    stock_ub_209  8
    x_18_8    parent_nonstrict_scope_210  1.0954615681569519e-02
    x_18_8    unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_16  1
    w_18_8    product_ub_17  1
    w_18_8    normalized_mass_18_33  1
    w_18_8    normalized_ratio_18_34  -1.1428571428571428e+00
    w_18_8    full_original_Gini_268  -4.4178571428571409e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       -2.1909231363139058e-02
    x_18_9    product_lb_18  -0.040634019704234
    x_18_9    product_ub_19  -1.0756819054947372e-01
    x_18_9    onehot_18_32  1
    x_18_9    stock_lb_208  9
    x_18_9    stock_ub_209  9
    x_18_9    parent_nonstrict_scope_210  2.1909231363139037e-02
    x_18_9    unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_18  1
    w_18_9    product_ub_19  1
    w_18_9    normalized_mass_18_33  1
    w_18_9    normalized_ratio_18_34  -1.2857142857142856e+00
    w_18_9    full_original_Gini_268  -6.1321428571428562e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       -1.0954615681569538e-02
    x_18_10   product_lb_20  -0.040634019704234
    x_18_10   product_ub_21  -1.0756819054947372e-01
    x_18_10   onehot_18_32  1
    x_18_10   stock_lb_208  10
    x_18_10   stock_ub_209  10
    x_18_10   parent_nonstrict_scope_210  3.2863847044708558e-02
    x_18_10   unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_20  1
    w_18_10   product_ub_21  1
    w_18_10   normalized_mass_18_33  1
    w_18_10   normalized_ratio_18_34  -1.4285714285714284e+00
    w_18_10   full_original_Gini_268  -7.8464285714285715e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_11   product_lb_22  -0.040634019704234
    x_18_11   product_ub_23  -1.0756819054947372e-01
    x_18_11   onehot_18_32  1
    x_18_11   stock_lb_208  11
    x_18_11   stock_ub_209  11
    x_18_11   parent_nonstrict_scope_210  4.3818462726278096e-02
    x_18_11   unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_11   product_lb_22  1
    w_18_11   product_ub_23  1
    w_18_11   normalized_mass_18_33  1
    w_18_11   normalized_ratio_18_34  -1.5714285714285714e+00
    w_18_11   full_original_Gini_268  -9.5607142857142833e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_12   OBJ       1.0954615681569517e-02
    x_18_12   product_lb_24  -0.040634019704234
    x_18_12   product_ub_25  -1.0756819054947372e-01
    x_18_12   onehot_18_32  1
    x_18_12   stock_lb_208  12
    x_18_12   stock_ub_209  12
    x_18_12   parent_nonstrict_scope_210  5.4773078407847613e-02
    x_18_12   unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_12   product_lb_24  1
    w_18_12   product_ub_25  1
    w_18_12   normalized_mass_18_33  1
    w_18_12   normalized_ratio_18_34  -1.7142857142857142e+00
    w_18_12   full_original_Gini_268  -1.1274999999999997e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_13   OBJ       2.1909231363139034e-02
    x_18_13   product_lb_26  -0.040634019704234
    x_18_13   product_ub_27  -1.0756819054947372e-01
    x_18_13   onehot_18_32  1
    x_18_13   stock_lb_208  13
    x_18_13   stock_ub_209  13
    x_18_13   parent_nonstrict_scope_210  6.5727694089417130e-02
    x_18_13   unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_13   product_lb_26  1
    w_18_13   product_ub_27  1
    w_18_13   normalized_mass_18_33  1
    w_18_13   normalized_ratio_18_34  -1.8571428571428570e+00
    w_18_13   full_original_Gini_268  -1.2989285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_14   OBJ       3.2863847044708572e-02
    x_18_14   product_lb_28  -0.040634019704234
    x_18_14   product_ub_29  -1.0756819054947372e-01
    x_18_14   onehot_18_32  1
    x_18_14   stock_lb_208  14
    x_18_14   stock_ub_209  14
    x_18_14   parent_nonstrict_scope_210  7.6682309770986667e-02
    x_18_14   unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_14   product_lb_28  1
    w_18_14   product_ub_29  1
    w_18_14   normalized_mass_18_33  1
    w_18_14   normalized_ratio_18_34  -2
    w_18_14   full_original_Gini_268  -1.4703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_15   OBJ       4.3818462726278096e-02
    x_18_15   product_lb_30  -0.040634019704234
    x_18_15   product_ub_31  -1.0756819054947372e-01
    x_18_15   onehot_18_32  1
    x_18_15   stock_lb_208  15
    x_18_15   stock_ub_209  15
    x_18_15   parent_nonstrict_scope_210  8.7636925452556191e-02
    x_18_15   unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_15   product_lb_30  1
    w_18_15   product_ub_31  1
    w_18_15   normalized_mass_18_33  1
    w_18_15   normalized_ratio_18_34  -2.1428571428571428e+00
    w_18_15   full_original_Gini_268  -1.6417857142857141e+01
    rho_18    normalized_ratio_18_34  1
    rho_18    block_pair_pos_243  -1
    rho_18    block_pair_neg_244  1
    rho_18    block_pair_pos_245  -1
    rho_18    block_pair_neg_246  1
    rho_18    block_pair_pos_247  -1
    rho_18    block_pair_neg_248  1
    rho_18    block_pair_pos_249  -1
    rho_18    block_pair_neg_250  1
    rho_18    block_pair_pos_251  -1
    rho_18    block_pair_neg_252  1
    rho_18    block_pair_pos_253  -1
    rho_18    block_pair_neg_254  1
    rho_18    block_pair_pos_255  -1
    rho_18    block_pair_neg_256  1
    rho_18    normalization_267  1
    MARKER    'MARKER'                 'INTORG'
    x_15_0    OBJ       6.3380304899829966e-03
    x_15_0    product_lb_35  -0.040634019704234
    x_15_0    product_ub_36  -1.0756819054947372e-01
    x_15_0    onehot_15_39  1
    x_15_0    parent_nonstrict_scope_210  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_15_0    product_lb_35  1
    w_15_0    product_ub_36  1
    w_15_0    normalized_mass_15_40  1
    w_15_0    full_original_Gini_268  -9.29642857142857
    MARKER    'MARKER'                 'INTORG'
    x_15_1    OBJ       -6.3380304899829966e-03
    x_15_1    product_lb_37  -0.040634019704234
    x_15_1    product_ub_38  -1.0756819054947372e-01
    x_15_1    onehot_15_39  1
    x_15_1    stock_lb_208  1
    x_15_1    stock_ub_209  1
    x_15_1    unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_1    product_lb_37  1
    w_15_1    product_ub_38  1
    w_15_1    normalized_mass_15_40  1
    w_15_1    normalized_ratio_15_41  -1
    w_15_1    full_original_Gini_268  -2.9535714285714283e+00
    rho_15    normalized_ratio_15_41  1
    rho_15    block_pair_pos_213  -1
    rho_15    block_pair_neg_214  1
    rho_15    block_pair_pos_215  -1
    rho_15    block_pair_neg_216  1
    rho_15    block_pair_pos_217  -1
    rho_15    block_pair_neg_218  1
    rho_15    block_pair_pos_219  -1
    rho_15    block_pair_neg_220  1
    rho_15    block_pair_pos_221  -1
    rho_15    block_pair_neg_222  1
    rho_15    block_pair_pos_223  -1
    rho_15    block_pair_neg_224  1
    rho_15    block_pair_pos_247  1
    rho_15    block_pair_neg_248  -1
    rho_15    normalization_267  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       6.3380304899829959e-02
    x_17_0    product_lb_42  -0.040634019704234
    x_17_0    product_ub_43  -1.0756819054947372e-01
    x_17_0    onehot_17_76  1
    x_17_0    parent_nonstrict_scope_210  1.2676060979965992e-01
    x_17_0    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_42  1
    w_17_0    product_ub_43  1
    w_17_0    normalized_mass_17_77  1
    w_17_0    full_original_Gini_268  -9.29642857142857
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.9295792699867738e-02
    x_17_1    product_lb_44  -0.040634019704234
    x_17_1    product_ub_45  -1.0756819054947372e-01
    x_17_1    onehot_17_76  1
    x_17_1    stock_lb_208  1
    x_17_1    stock_ub_209  1
    x_17_1    parent_nonstrict_scope_210  1.1267609759969770e-01
    x_17_1    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_44  1
    w_17_1    product_ub_45  1
    w_17_1    normalized_mass_17_77  1
    w_17_1    normalized_ratio_17_78  -1.1111111111111110e-01
    w_17_1    full_original_Gini_268  -8.4075396825396833e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       3.5211280499905531e-02
    x_17_2    product_lb_46  -0.040634019704234
    x_17_2    product_ub_47  -1.0756819054947372e-01
    x_17_2    onehot_17_76  1
    x_17_2    stock_lb_208  2
    x_17_2    stock_ub_209  2
    x_17_2    parent_nonstrict_scope_210  9.8591585399735490e-02
    x_17_2    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_46  1
    w_17_2    product_ub_47  1
    w_17_2    normalized_mass_17_77  1
    w_17_2    normalized_ratio_17_78  -2.2222222222222221e-01
    w_17_2    full_original_Gini_268  -7.5186507936507931e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.1126768299943324e-02
    x_17_3    product_lb_48  -0.040634019704234
    x_17_3    product_ub_49  -1.0756819054947372e-01
    x_17_3    onehot_17_76  1
    x_17_3    stock_lb_208  3
    x_17_3    stock_ub_209  3
    x_17_3    parent_nonstrict_scope_210  8.4507073199773283e-02
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_48  1
    w_17_3    product_ub_49  1
    w_17_3    normalized_mass_17_77  1
    w_17_3    normalized_ratio_17_78  -3.3333333333333331e-01
    w_17_3    full_original_Gini_268  -6.6297619047619065e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       7.0422560999811035e-03
    x_17_4    product_lb_50  -0.040634019704234
    x_17_4    product_ub_51  -1.0756819054947372e-01
    x_17_4    onehot_17_76  1
    x_17_4    stock_lb_208  4
    x_17_4    stock_ub_209  4
    x_17_4    parent_nonstrict_scope_210  7.0422560999811062e-02
    x_17_4    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_50  1
    w_17_4    product_ub_51  1
    w_17_4    normalized_mass_17_77  1
    w_17_4    normalized_ratio_17_78  -4.4444444444444442e-01
    w_17_4    full_original_Gini_268  -5.7408730158730155e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -0.00704225609998111
    x_17_5    product_lb_52  -0.040634019704234
    x_17_5    product_ub_53  -1.0756819054947372e-01
    x_17_5    onehot_17_76  1
    x_17_5    stock_lb_208  5
    x_17_5    stock_ub_209  5
    x_17_5    parent_nonstrict_scope_210  5.6338048799848849e-02
    x_17_5    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_52  1
    w_17_5    product_ub_53  1
    w_17_5    normalized_mass_17_77  1
    w_17_5    normalized_ratio_17_78  -5.5555555555555558e-01
    w_17_5    full_original_Gini_268  -4.8519841269841271e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.1126768299943317e-02
    x_17_6    product_lb_54  -0.040634019704234
    x_17_6    product_ub_55  -1.0756819054947372e-01
    x_17_6    onehot_17_76  1
    x_17_6    stock_lb_208  6
    x_17_6    stock_ub_209  6
    x_17_6    parent_nonstrict_scope_210  4.2253536599886642e-02
    x_17_6    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_54  1
    w_17_6    product_ub_55  1
    w_17_6    normalized_mass_17_77  1
    w_17_6    normalized_ratio_17_78  -6.6666666666666663e-01
    w_17_6    full_original_Gini_268  -4.2869047619047622e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.5211280499905517e-02
    x_17_7    product_lb_56  -0.040634019704234
    x_17_7    product_ub_57  -1.0756819054947372e-01
    x_17_7    onehot_17_76  1
    x_17_7    stock_lb_208  7
    x_17_7    stock_ub_209  7
    x_17_7    parent_nonstrict_scope_210  2.8169024399924438e-02
    x_17_7    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_56  1
    w_17_7    product_ub_57  1
    w_17_7    normalized_mass_17_77  1
    w_17_7    normalized_ratio_17_78  -7.7777777777777768e-01
    w_17_7    full_original_Gini_268  -3.8424603174603176e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.9295792699867738e-02
    x_17_8    product_lb_58  -0.040634019704234
    x_17_8    product_ub_59  -1.0756819054947372e-01
    x_17_8    onehot_17_76  1
    x_17_8    stock_lb_208  8
    x_17_8    stock_ub_209  8
    x_17_8    parent_nonstrict_scope_210  1.4084512199962219e-02
    x_17_8    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_58  1
    w_17_8    product_ub_59  1
    w_17_8    normalized_mass_17_77  1
    w_17_8    normalized_ratio_17_78  -8.8888888888888884e-01
    w_17_8    full_original_Gini_268  -3.3980158730158734e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -6.3380304899829959e-02
    x_17_9    product_lb_60  -0.040634019704234
    x_17_9    product_ub_61  -1.0756819054947372e-01
    x_17_9    onehot_17_76  1
    x_17_9    stock_lb_208  9
    x_17_9    stock_ub_209  9
    x_17_9    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_60  1
    w_17_9    product_ub_61  1
    w_17_9    normalized_mass_17_77  1
    w_17_9    normalized_ratio_17_78  -1
    w_17_9    full_original_Gini_268  -2.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.9295792699867738e-02
    x_17_10   product_lb_62  -0.040634019704234
    x_17_10   product_ub_63  -1.0756819054947372e-01
    x_17_10   onehot_17_76  1
    x_17_10   stock_lb_208  10
    x_17_10   stock_ub_209  10
    x_17_10   parent_nonstrict_scope_210  1.4084512199962219e-02
    x_17_10   unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_62  1
    w_17_10   product_ub_63  1
    w_17_10   normalized_mass_17_77  1
    w_17_10   normalized_ratio_17_78  -1.1111111111111112e+00
    w_17_10   full_original_Gini_268  -4.06468253968254
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.5211280499905545e-02
    x_17_11   product_lb_64  -0.040634019704234
    x_17_11   product_ub_65  -1.0756819054947372e-01
    x_17_11   onehot_17_76  1
    x_17_11   stock_lb_208  11
    x_17_11   stock_ub_209  11
    x_17_11   parent_nonstrict_scope_210  2.8169024399924410e-02
    x_17_11   unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_64  1
    w_17_11   product_ub_65  1
    w_17_11   normalized_mass_17_77  1
    w_17_11   normalized_ratio_17_78  -1.2222222222222221e+00
    w_17_11   full_original_Gini_268  -5.3702380952380953e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.1126768299943331e-02
    x_17_12   product_lb_66  -0.040634019704234
    x_17_12   product_ub_67  -1.0756819054947372e-01
    x_17_12   onehot_17_76  1
    x_17_12   stock_lb_208  12
    x_17_12   stock_ub_209  12
    x_17_12   parent_nonstrict_scope_210  4.2253536599886628e-02
    x_17_12   unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_66  1
    w_17_12   product_ub_67  1
    w_17_12   normalized_mass_17_77  1
    w_17_12   normalized_ratio_17_78  -1.3333333333333333e+00
    w_17_12   full_original_Gini_268  -6.7035714285714256e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -0.00704225609998111
    x_17_13   product_lb_68  -0.040634019704234
    x_17_13   product_ub_69  -1.0756819054947372e-01
    x_17_13   onehot_17_76  1
    x_17_13   stock_lb_208  13
    x_17_13   stock_ub_209  13
    x_17_13   parent_nonstrict_scope_210  5.6338048799848849e-02
    x_17_13   unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_68  1
    w_17_13   product_ub_69  1
    w_17_13   normalized_mass_17_77  1
    w_17_13   normalized_ratio_17_78  -1.4444444444444444e+00
    w_17_13   full_original_Gini_268  -8.0369047619047631e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       7.0422560999810757e-03
    x_17_14   product_lb_70  -0.040634019704234
    x_17_14   product_ub_71  -1.0756819054947372e-01
    x_17_14   onehot_17_76  1
    x_17_14   stock_lb_208  14
    x_17_14   stock_ub_209  14
    x_17_14   parent_nonstrict_scope_210  7.0422560999811035e-02
    x_17_14   unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_70  1
    w_17_14   product_ub_71  1
    w_17_14   normalized_mass_17_77  1
    w_17_14   normalized_ratio_17_78  -1.5555555555555554e+00
    w_17_14   full_original_Gini_268  -9.3702380952380935e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.1126768299943297e-02
    x_17_15   product_lb_72  -0.040634019704234
    x_17_15   product_ub_73  -1.0756819054947372e-01
    x_17_15   onehot_17_76  1
    x_17_15   stock_lb_208  15
    x_17_15   stock_ub_209  15
    x_17_15   parent_nonstrict_scope_210  8.4507073199773255e-02
    x_17_15   unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_72  1
    w_17_15   product_ub_73  1
    w_17_15   normalized_mass_17_77  1
    w_17_15   normalized_ratio_17_78  -1.6666666666666665e+00
    w_17_15   full_original_Gini_268  -1.0703571428571424e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.5211280499905517e-02
    x_17_16   product_lb_74  -0.040634019704234
    x_17_16   product_ub_75  -1.0756819054947372e-01
    x_17_16   onehot_17_76  1
    x_17_16   stock_lb_208  16
    x_17_16   stock_ub_209  16
    x_17_16   parent_nonstrict_scope_210  9.8591585399735476e-02
    x_17_16   unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_74  1
    w_17_16   product_ub_75  1
    w_17_16   normalized_mass_17_77  1
    w_17_16   normalized_ratio_17_78  -1.7777777777777777e+00
    w_17_16   full_original_Gini_268  -1.2036904761904765e+01
    rho_17    normalized_ratio_17_78  1
    rho_17    block_pair_pos_219  1
    rho_17    block_pair_neg_220  -1
    rho_17    block_pair_pos_233  -1
    rho_17    block_pair_neg_234  1
    rho_17    block_pair_pos_235  -1
    rho_17    block_pair_neg_236  1
    rho_17    block_pair_pos_237  -1
    rho_17    block_pair_neg_238  1
    rho_17    block_pair_pos_239  -1
    rho_17    block_pair_neg_240  1
    rho_17    block_pair_pos_241  -1
    rho_17    block_pair_neg_242  1
    rho_17    block_pair_pos_251  1
    rho_17    block_pair_neg_252  -1
    rho_17    normalization_267  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       6.3380304899829966e-03
    x_16_0    product_lb_79  -0.040634019704234
    x_16_0    product_ub_80  -1.0756819054947372e-01
    x_16_0    onehot_16_85  1
    x_16_0    parent_nonstrict_scope_210  1.2676060979965993e-02
    x_16_0    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_79  1
    w_16_0    product_ub_80  1
    w_16_0    normalized_mass_16_86  1
    w_16_0    full_original_Gini_268  -9.29642857142857
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       -6.3380304899829966e-03
    x_16_1    product_lb_81  -0.040634019704234
    x_16_1    product_ub_82  -1.0756819054947372e-01
    x_16_1    onehot_16_85  1
    x_16_1    stock_lb_208  1
    x_16_1    stock_ub_209  1
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_81  1
    w_16_1    product_ub_82  1
    w_16_1    normalized_mass_16_86  1
    w_16_1    normalized_ratio_16_87  -1
    w_16_1    full_original_Gini_268  -2.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       6.3380304899829966e-03
    x_16_2    product_lb_83  -0.040634019704234
    x_16_2    product_ub_84  -1.0756819054947372e-01
    x_16_2    onehot_16_85  1
    x_16_2    stock_lb_208  2
    x_16_2    stock_ub_209  2
    x_16_2    parent_nonstrict_scope_210  1.2676060979965993e-02
    x_16_2    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_83  1
    w_16_2    product_ub_84  1
    w_16_2    normalized_mass_16_86  1
    w_16_2    normalized_ratio_16_87  -2
    w_16_2    full_original_Gini_268  -1.4703571428571429e+01
    rho_16    normalized_ratio_16_87  1
    rho_16    block_pair_pos_217  1
    rho_16    block_pair_neg_218  -1
    rho_16    block_pair_pos_225  -1
    rho_16    block_pair_neg_226  1
    rho_16    block_pair_pos_227  -1
    rho_16    block_pair_neg_228  1
    rho_16    block_pair_pos_229  -1
    rho_16    block_pair_neg_230  1
    rho_16    block_pair_pos_231  -1
    rho_16    block_pair_neg_232  1
    rho_16    block_pair_pos_237  1
    rho_16    block_pair_neg_238  -1
    rho_16    block_pair_pos_249  1
    rho_16    block_pair_neg_250  -1
    rho_16    normalization_267  1
    MARKER    'MARKER'                 'INTORG'
    x_20_0    OBJ       5.0078236648368350e-02
    x_20_0    product_lb_88  -0.040634019704234
    x_20_0    product_ub_89  -1.0756819054947372e-01
    x_20_0    onehot_20_120  1
    x_20_0    parent_nonstrict_scope_210  1.0015647329673670e-01
    x_20_0    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_0    product_lb_88  1
    w_20_0    product_ub_89  1
    w_20_0    normalized_mass_20_121  1
    w_20_0    full_original_Gini_268  -9.29642857142857
    MARKER    'MARKER'                 'INTORG'
    x_20_1    OBJ       3.7558677486276261e-02
    x_20_1    product_lb_90  -0.040634019704234
    x_20_1    product_ub_91  -1.0756819054947372e-01
    x_20_1    onehot_20_120  1
    x_20_1    stock_lb_208  1
    x_20_1    stock_ub_209  1
    x_20_1    parent_nonstrict_scope_210  8.7636914134644611e-02
    x_20_1    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_1    product_lb_90  1
    w_20_1    product_ub_91  1
    w_20_1    normalized_mass_20_121  1
    w_20_1    normalized_ratio_20_122  -0.125
    w_20_1    full_original_Gini_268  -8.29642857142857
    MARKER    'MARKER'                 'INTORG'
    x_20_2    OBJ       2.5039118324184172e-02
    x_20_2    product_lb_92  -0.040634019704234
    x_20_2    product_ub_93  -1.0756819054947372e-01
    x_20_2    onehot_20_120  1
    x_20_2    stock_lb_208  2
    x_20_2    stock_ub_209  2
    x_20_2    parent_nonstrict_scope_210  7.5117354972552522e-02
    x_20_2    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_2    product_lb_92  1
    w_20_2    product_ub_93  1
    w_20_2    normalized_mass_20_121  1
    w_20_2    normalized_ratio_20_122  -0.25
    w_20_2    full_original_Gini_268  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_3    OBJ       1.2519559162092082e-02
    x_20_3    product_lb_94  -0.040634019704234
    x_20_3    product_ub_95  -1.0756819054947372e-01
    x_20_3    onehot_20_120  1
    x_20_3    stock_lb_208  3
    x_20_3    stock_ub_209  3
    x_20_3    parent_nonstrict_scope_210  6.2597795810460433e-02
    x_20_3    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_3    product_lb_94  1
    w_20_3    product_ub_95  1
    w_20_3    normalized_mass_20_121  1
    w_20_3    normalized_ratio_20_122  -0.375
    w_20_3    full_original_Gini_268  -6.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_4    product_lb_96  -0.040634019704234
    x_20_4    product_ub_97  -1.0756819054947372e-01
    x_20_4    onehot_20_120  1
    x_20_4    stock_lb_208  4
    x_20_4    stock_ub_209  4
    x_20_4    parent_nonstrict_scope_210  5.0078236648368350e-02
    x_20_4    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_4    product_lb_96  1
    w_20_4    product_ub_97  1
    w_20_4    normalized_mass_20_121  1
    w_20_4    normalized_ratio_20_122  -0.5
    w_20_4    full_original_Gini_268  -5.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_5    OBJ       -1.2519559162092089e-02
    x_20_5    product_lb_98  -0.040634019704234
    x_20_5    product_ub_99  -1.0756819054947372e-01
    x_20_5    onehot_20_120  1
    x_20_5    stock_lb_208  5
    x_20_5    stock_ub_209  5
    x_20_5    parent_nonstrict_scope_210  3.7558677486276261e-02
    x_20_5    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_5    product_lb_98  1
    w_20_5    product_ub_99  1
    w_20_5    normalized_mass_20_121  1
    w_20_5    normalized_ratio_20_122  -0.625
    w_20_5    full_original_Gini_268  -4.4535714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_6    OBJ       -2.5039118324184175e-02
    x_20_6    product_lb_100  -0.040634019704234
    x_20_6    product_ub_101  -1.0756819054947372e-01
    x_20_6    onehot_20_120  1
    x_20_6    stock_lb_208  6
    x_20_6    stock_ub_209  6
    x_20_6    parent_nonstrict_scope_210  2.5039118324184175e-02
    x_20_6    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_6    product_lb_100  1
    w_20_6    product_ub_101  1
    w_20_6    normalized_mass_20_121  1
    w_20_6    normalized_ratio_20_122  -0.75
    w_20_6    full_original_Gini_268  -3.9535714285714287e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_7    OBJ       -3.7558677486276261e-02
    x_20_7    product_lb_102  -0.040634019704234
    x_20_7    product_ub_103  -1.0756819054947372e-01
    x_20_7    onehot_20_120  1
    x_20_7    stock_lb_208  7
    x_20_7    stock_ub_209  7
    x_20_7    parent_nonstrict_scope_210  1.2519559162092088e-02
    x_20_7    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_7    product_lb_102  1
    w_20_7    product_ub_103  1
    w_20_7    normalized_mass_20_121  1
    w_20_7    normalized_ratio_20_122  -0.875
    w_20_7    full_original_Gini_268  -3.4535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_8    OBJ       -5.0078236648368350e-02
    x_20_8    product_lb_104  -0.040634019704234
    x_20_8    product_ub_105  -1.0756819054947372e-01
    x_20_8    onehot_20_120  1
    x_20_8    stock_lb_208  8
    x_20_8    stock_ub_209  8
    x_20_8    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_8    product_lb_104  1
    w_20_8    product_ub_105  1
    w_20_8    normalized_mass_20_121  1
    w_20_8    normalized_ratio_20_122  -1
    w_20_8    full_original_Gini_268  -2.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_9    OBJ       -3.7558677486276261e-02
    x_20_9    product_lb_106  -0.040634019704234
    x_20_9    product_ub_107  -1.0756819054947372e-01
    x_20_9    onehot_20_120  1
    x_20_9    stock_lb_208  9
    x_20_9    stock_ub_209  9
    x_20_9    parent_nonstrict_scope_210  1.2519559162092088e-02
    x_20_9    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_9    product_lb_106  1
    w_20_9    product_ub_107  1
    w_20_9    normalized_mass_20_121  1
    w_20_9    normalized_ratio_20_122  -1.125
    w_20_9    full_original_Gini_268  -4.2035714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_10   OBJ       -2.5039118324184175e-02
    x_20_10   product_lb_108  -0.040634019704234
    x_20_10   product_ub_109  -1.0756819054947372e-01
    x_20_10   onehot_20_120  1
    x_20_10   stock_lb_208  10
    x_20_10   stock_ub_209  10
    x_20_10   parent_nonstrict_scope_210  2.5039118324184175e-02
    x_20_10   unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_10   product_lb_108  1
    w_20_10   product_ub_109  1
    w_20_10   normalized_mass_20_121  1
    w_20_10   normalized_ratio_20_122  -1.25
    w_20_10   full_original_Gini_268  -5.7035714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_11   OBJ       -1.2519559162092089e-02
    x_20_11   product_lb_110  -0.040634019704234
    x_20_11   product_ub_111  -1.0756819054947372e-01
    x_20_11   onehot_20_120  1
    x_20_11   stock_lb_208  11
    x_20_11   stock_ub_209  11
    x_20_11   parent_nonstrict_scope_210  3.7558677486276261e-02
    x_20_11   unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_11   product_lb_110  1
    w_20_11   product_ub_111  1
    w_20_11   normalized_mass_20_121  1
    w_20_11   normalized_ratio_20_122  -1.375
    w_20_11   full_original_Gini_268  -7.2035714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_12   product_lb_112  -0.040634019704234
    x_20_12   product_ub_113  -1.0756819054947372e-01
    x_20_12   onehot_20_120  1
    x_20_12   stock_lb_208  12
    x_20_12   stock_ub_209  12
    x_20_12   parent_nonstrict_scope_210  5.0078236648368350e-02
    MARKER    'MARKER'                 'INTEND'
    w_20_12   product_lb_112  1
    w_20_12   product_ub_113  1
    w_20_12   normalized_mass_20_121  1
    w_20_12   normalized_ratio_20_122  -1.5
    w_20_12   full_original_Gini_268  -8.70357142857143
    MARKER    'MARKER'                 'INTORG'
    x_20_13   OBJ       1.2519559162092082e-02
    x_20_13   product_lb_114  -0.040634019704234
    x_20_13   product_ub_115  -1.0756819054947372e-01
    x_20_13   onehot_20_120  1
    x_20_13   stock_lb_208  13
    x_20_13   stock_ub_209  13
    x_20_13   parent_nonstrict_scope_210  6.2597795810460433e-02
    x_20_13   unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_13   product_lb_114  1
    w_20_13   product_ub_115  1
    w_20_13   normalized_mass_20_121  1
    w_20_13   normalized_ratio_20_122  -1.625
    w_20_13   full_original_Gini_268  -1.0203571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_14   OBJ       2.5039118324184172e-02
    x_20_14   product_lb_116  -0.040634019704234
    x_20_14   product_ub_117  -1.0756819054947372e-01
    x_20_14   onehot_20_120  1
    x_20_14   stock_lb_208  14
    x_20_14   stock_ub_209  14
    x_20_14   parent_nonstrict_scope_210  7.5117354972552522e-02
    x_20_14   unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_14   product_lb_116  1
    w_20_14   product_ub_117  1
    w_20_14   normalized_mass_20_121  1
    w_20_14   normalized_ratio_20_122  -1.75
    w_20_14   full_original_Gini_268  -1.1703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_15   OBJ       3.7558677486276261e-02
    x_20_15   product_lb_118  -0.040634019704234
    x_20_15   product_ub_119  -1.0756819054947372e-01
    x_20_15   onehot_20_120  1
    x_20_15   stock_lb_208  15
    x_20_15   stock_ub_209  15
    x_20_15   parent_nonstrict_scope_210  8.7636914134644611e-02
    x_20_15   unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_15   product_lb_118  1
    w_20_15   product_ub_119  1
    w_20_15   normalized_mass_20_121  1
    w_20_15   normalized_ratio_20_122  -1.875
    w_20_15   full_original_Gini_268  -1.3203571428571429e+01
    rho_20    normalized_ratio_20_122  1
    rho_20    block_pair_pos_223  1
    rho_20    block_pair_neg_224  -1
    rho_20    block_pair_pos_231  1
    rho_20    block_pair_neg_232  -1
    rho_20    block_pair_pos_241  1
    rho_20    block_pair_neg_242  -1
    rho_20    block_pair_pos_255  1
    rho_20    block_pair_neg_256  -1
    rho_20    block_pair_pos_261  -1
    rho_20    block_pair_neg_262  1
    rho_20    block_pair_pos_263  -1
    rho_20    block_pair_neg_264  1
    rho_20    block_pair_pos_265  -1
    rho_20    block_pair_neg_266  1
    rho_20    normalization_267  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       3.1690152449914983e-03
    x_19_0    product_lb_123  -0.040634019704234
    x_19_0    product_ub_124  -1.0756819054947372e-01
    x_19_0    onehot_19_135  1
    x_19_0    parent_nonstrict_scope_210  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_123  1
    w_19_0    product_ub_124  1
    w_19_0    normalized_mass_19_136  1
    w_19_0    full_original_Gini_268  -9.29642857142857
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       -3.1690152449914983e-03
    x_19_1    product_lb_125  -0.040634019704234
    x_19_1    product_ub_126  -1.0756819054947372e-01
    x_19_1    onehot_19_135  1
    x_19_1    stock_lb_208  1
    x_19_1    stock_ub_209  1
    x_19_1    parent_nonstrict_scope_210  6.3380304899829966e-03
    x_19_1    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_125  1
    w_19_1    product_ub_126  1
    w_19_1    normalized_mass_19_136  1
    w_19_1    normalized_ratio_19_137  -0.5
    w_19_1    full_original_Gini_268  -5.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_2    OBJ       -9.5070457349744949e-03
    x_19_2    product_lb_127  -0.040634019704234
    x_19_2    product_ub_128  -1.0756819054947372e-01
    x_19_2    onehot_19_135  1
    x_19_2    stock_lb_208  2
    x_19_2    stock_ub_209  2
    x_19_2    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_127  1
    w_19_2    product_ub_128  1
    w_19_2    normalized_mass_19_136  1
    w_19_2    normalized_ratio_19_137  -1
    w_19_2    full_original_Gini_268  -2.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -3.1690152449914983e-03
    x_19_3    product_lb_129  -0.040634019704234
    x_19_3    product_ub_130  -1.0756819054947372e-01
    x_19_3    onehot_19_135  1
    x_19_3    stock_lb_208  3
    x_19_3    stock_ub_209  3
    x_19_3    parent_nonstrict_scope_210  6.3380304899829966e-03
    x_19_3    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_129  1
    w_19_3    product_ub_130  1
    w_19_3    normalized_mass_19_136  1
    w_19_3    normalized_ratio_19_137  -1.5
    w_19_3    full_original_Gini_268  -8.70357142857143
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       3.1690152449914983e-03
    x_19_4    product_lb_131  -0.040634019704234
    x_19_4    product_ub_132  -1.0756819054947372e-01
    x_19_4    onehot_19_135  1
    x_19_4    stock_lb_208  4
    x_19_4    stock_ub_209  4
    x_19_4    parent_nonstrict_scope_210  1.2676060979965993e-02
    x_19_4    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_131  1
    w_19_4    product_ub_132  1
    w_19_4    normalized_mass_19_136  1
    w_19_4    normalized_ratio_19_137  -2
    w_19_4    full_original_Gini_268  -1.4703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       9.5070457349744949e-03
    x_19_5    product_lb_133  -0.040634019704234
    x_19_5    product_ub_134  -1.0756819054947372e-01
    x_19_5    onehot_19_135  1
    x_19_5    stock_lb_208  5
    x_19_5    stock_ub_209  5
    x_19_5    parent_nonstrict_scope_210  1.9014091469948990e-02
    x_19_5    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_133  1
    w_19_5    product_ub_134  1
    w_19_5    normalized_mass_19_136  1
    w_19_5    normalized_ratio_19_137  -2.5
    w_19_5    full_original_Gini_268  -2.0703571428571429e+01
    rho_19    normalized_ratio_19_137  1
    rho_19    block_pair_pos_221  1
    rho_19    block_pair_neg_222  -1
    rho_19    block_pair_pos_229  1
    rho_19    block_pair_neg_230  -1
    rho_19    block_pair_pos_239  1
    rho_19    block_pair_neg_240  -1
    rho_19    block_pair_pos_253  1
    rho_19    block_pair_neg_254  -1
    rho_19    block_pair_pos_257  -1
    rho_19    block_pair_neg_258  1
    rho_19    block_pair_pos_259  -1
    rho_19    block_pair_neg_260  1
    rho_19    block_pair_pos_265  1
    rho_19    block_pair_neg_266  -1
    rho_19    normalization_267  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       5.0078236648368350e-02
    x_11_0    product_lb_138  -0.040634019704234
    x_11_0    product_ub_139  -1.0756819054947372e-01
    x_11_0    onehot_11_170  1
    x_11_0    parent_nonstrict_scope_210  1.0015647329673670e-01
    x_11_0    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_138  1
    w_11_0    product_ub_139  1
    w_11_0    normalized_mass_11_171  1
    w_11_0    full_original_Gini_268  -9.29642857142857
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7558677486276261e-02
    x_11_1    product_lb_140  -0.040634019704234
    x_11_1    product_ub_141  -1.0756819054947372e-01
    x_11_1    onehot_11_170  1
    x_11_1    stock_lb_208  1
    x_11_1    stock_ub_209  1
    x_11_1    parent_nonstrict_scope_210  8.7636914134644611e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_140  1
    w_11_1    product_ub_141  1
    w_11_1    normalized_mass_11_171  1
    w_11_1    normalized_ratio_11_172  -0.125
    w_11_1    full_original_Gini_268  -8.29642857142857
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       2.5039118324184172e-02
    x_11_2    product_lb_142  -0.040634019704234
    x_11_2    product_ub_143  -1.0756819054947372e-01
    x_11_2    onehot_11_170  1
    x_11_2    stock_lb_208  2
    x_11_2    stock_ub_209  2
    x_11_2    parent_nonstrict_scope_210  7.5117354972552522e-02
    x_11_2    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_142  1
    w_11_2    product_ub_143  1
    w_11_2    normalized_mass_11_171  1
    w_11_2    normalized_ratio_11_172  -0.25
    w_11_2    full_original_Gini_268  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       1.2519559162092082e-02
    x_11_3    product_lb_144  -0.040634019704234
    x_11_3    product_ub_145  -1.0756819054947372e-01
    x_11_3    onehot_11_170  1
    x_11_3    stock_lb_208  3
    x_11_3    stock_ub_209  3
    x_11_3    parent_nonstrict_scope_210  6.2597795810460433e-02
    x_11_3    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_144  1
    w_11_3    product_ub_145  1
    w_11_3    normalized_mass_11_171  1
    w_11_3    normalized_ratio_11_172  -0.375
    w_11_3    full_original_Gini_268  -6.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    product_lb_146  -0.040634019704234
    x_11_4    product_ub_147  -1.0756819054947372e-01
    x_11_4    onehot_11_170  1
    x_11_4    stock_lb_208  4
    x_11_4    stock_ub_209  4
    x_11_4    parent_nonstrict_scope_210  5.0078236648368350e-02
    x_11_4    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_146  1
    w_11_4    product_ub_147  1
    w_11_4    normalized_mass_11_171  1
    w_11_4    normalized_ratio_11_172  -0.5
    w_11_4    full_original_Gini_268  -5.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -1.2519559162092089e-02
    x_11_5    product_lb_148  -0.040634019704234
    x_11_5    product_ub_149  -1.0756819054947372e-01
    x_11_5    onehot_11_170  1
    x_11_5    stock_lb_208  5
    x_11_5    stock_ub_209  5
    x_11_5    parent_nonstrict_scope_210  3.7558677486276261e-02
    x_11_5    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_148  1
    w_11_5    product_ub_149  1
    w_11_5    normalized_mass_11_171  1
    w_11_5    normalized_ratio_11_172  -0.625
    w_11_5    full_original_Gini_268  -4.4535714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -2.5039118324184175e-02
    x_11_6    product_lb_150  -0.040634019704234
    x_11_6    product_ub_151  -1.0756819054947372e-01
    x_11_6    onehot_11_170  1
    x_11_6    stock_lb_208  6
    x_11_6    stock_ub_209  6
    x_11_6    parent_nonstrict_scope_210  2.5039118324184175e-02
    x_11_6    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_150  1
    w_11_6    product_ub_151  1
    w_11_6    normalized_mass_11_171  1
    w_11_6    normalized_ratio_11_172  -0.75
    w_11_6    full_original_Gini_268  -3.9535714285714287e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -3.7558677486276261e-02
    x_11_7    product_lb_152  -0.040634019704234
    x_11_7    product_ub_153  -1.0756819054947372e-01
    x_11_7    onehot_11_170  1
    x_11_7    stock_lb_208  7
    x_11_7    stock_ub_209  7
    x_11_7    parent_nonstrict_scope_210  1.2519559162092088e-02
    x_11_7    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_152  1
    w_11_7    product_ub_153  1
    w_11_7    normalized_mass_11_171  1
    w_11_7    normalized_ratio_11_172  -0.875
    w_11_7    full_original_Gini_268  -3.4535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -5.0078236648368350e-02
    x_11_8    product_lb_154  -0.040634019704234
    x_11_8    product_ub_155  -1.0756819054947372e-01
    x_11_8    onehot_11_170  1
    x_11_8    stock_lb_208  8
    x_11_8    stock_ub_209  8
    x_11_8    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_154  1
    w_11_8    product_ub_155  1
    w_11_8    normalized_mass_11_171  1
    w_11_8    normalized_ratio_11_172  -1
    w_11_8    full_original_Gini_268  -2.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       -3.7558677486276261e-02
    x_11_9    product_lb_156  -0.040634019704234
    x_11_9    product_ub_157  -1.0756819054947372e-01
    x_11_9    onehot_11_170  1
    x_11_9    stock_lb_208  9
    x_11_9    stock_ub_209  9
    x_11_9    parent_nonstrict_scope_210  1.2519559162092088e-02
    x_11_9    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_156  1
    w_11_9    product_ub_157  1
    w_11_9    normalized_mass_11_171  1
    w_11_9    normalized_ratio_11_172  -1.125
    w_11_9    full_original_Gini_268  -4.2035714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       -2.5039118324184175e-02
    x_11_10   product_lb_158  -0.040634019704234
    x_11_10   product_ub_159  -1.0756819054947372e-01
    x_11_10   onehot_11_170  1
    x_11_10   stock_lb_208  10
    x_11_10   stock_ub_209  10
    x_11_10   parent_nonstrict_scope_210  2.5039118324184175e-02
    x_11_10   unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_158  1
    w_11_10   product_ub_159  1
    w_11_10   normalized_mass_11_171  1
    w_11_10   normalized_ratio_11_172  -1.25
    w_11_10   full_original_Gini_268  -5.7035714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       -1.2519559162092089e-02
    x_11_11   product_lb_160  -0.040634019704234
    x_11_11   product_ub_161  -1.0756819054947372e-01
    x_11_11   onehot_11_170  1
    x_11_11   stock_lb_208  11
    x_11_11   stock_ub_209  11
    x_11_11   parent_nonstrict_scope_210  3.7558677486276261e-02
    x_11_11   unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_160  1
    w_11_11   product_ub_161  1
    w_11_11   normalized_mass_11_171  1
    w_11_11   normalized_ratio_11_172  -1.375
    w_11_11   full_original_Gini_268  -7.2035714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_12   product_lb_162  -0.040634019704234
    x_11_12   product_ub_163  -1.0756819054947372e-01
    x_11_12   onehot_11_170  1
    x_11_12   stock_lb_208  12
    x_11_12   stock_ub_209  12
    x_11_12   parent_nonstrict_scope_210  5.0078236648368350e-02
    x_11_12   unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_162  1
    w_11_12   product_ub_163  1
    w_11_12   normalized_mass_11_171  1
    w_11_12   normalized_ratio_11_172  -1.5
    w_11_12   full_original_Gini_268  -8.70357142857143
    MARKER    'MARKER'                 'INTORG'
    x_11_13   OBJ       1.2519559162092082e-02
    x_11_13   product_lb_164  -0.040634019704234
    x_11_13   product_ub_165  -1.0756819054947372e-01
    x_11_13   onehot_11_170  1
    x_11_13   stock_lb_208  13
    x_11_13   stock_ub_209  13
    x_11_13   parent_nonstrict_scope_210  6.2597795810460433e-02
    x_11_13   unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_13   product_lb_164  1
    w_11_13   product_ub_165  1
    w_11_13   normalized_mass_11_171  1
    w_11_13   normalized_ratio_11_172  -1.625
    w_11_13   full_original_Gini_268  -1.0203571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_14   OBJ       2.5039118324184172e-02
    x_11_14   product_lb_166  -0.040634019704234
    x_11_14   product_ub_167  -1.0756819054947372e-01
    x_11_14   onehot_11_170  1
    x_11_14   stock_lb_208  14
    x_11_14   stock_ub_209  14
    x_11_14   parent_nonstrict_scope_210  7.5117354972552522e-02
    x_11_14   unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_14   product_lb_166  1
    w_11_14   product_ub_167  1
    w_11_14   normalized_mass_11_171  1
    w_11_14   normalized_ratio_11_172  -1.75
    w_11_14   full_original_Gini_268  -1.1703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_15   OBJ       3.7558677486276261e-02
    x_11_15   product_lb_168  -0.040634019704234
    x_11_15   product_ub_169  -1.0756819054947372e-01
    x_11_15   onehot_11_170  1
    x_11_15   stock_lb_208  15
    x_11_15   stock_ub_209  15
    x_11_15   parent_nonstrict_scope_210  8.7636914134644611e-02
    x_11_15   unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_15   product_lb_168  1
    w_11_15   product_ub_169  1
    w_11_15   normalized_mass_11_171  1
    w_11_15   normalized_ratio_11_172  -1.875
    w_11_15   full_original_Gini_268  -1.3203571428571429e+01
    rho_11    normalized_ratio_11_172  1
    rho_11    block_pair_pos_211  -1
    rho_11    block_pair_neg_212  1
    rho_11    block_pair_pos_213  1
    rho_11    block_pair_neg_214  -1
    rho_11    block_pair_pos_225  1
    rho_11    block_pair_neg_226  -1
    rho_11    block_pair_pos_233  1
    rho_11    block_pair_neg_234  -1
    rho_11    block_pair_pos_243  1
    rho_11    block_pair_neg_244  -1
    rho_11    block_pair_pos_257  1
    rho_11    block_pair_neg_258  -1
    rho_11    block_pair_pos_261  1
    rho_11    block_pair_neg_262  -1
    rho_11    normalization_267  1
    MARKER    'MARKER'                 'INTORG'
    x_12_0    OBJ       3.2863847044708572e-02
    x_12_0    product_lb_173  -0.040634019704234
    x_12_0    product_ub_174  -1.0756819054947372e-01
    x_12_0    onehot_12_205  1
    x_12_0    parent_nonstrict_scope_210  7.6682309770986667e-02
    x_12_0    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_0    product_lb_173  1
    w_12_0    product_ub_174  1
    w_12_0    normalized_mass_12_206  1
    w_12_0    full_original_Gini_268  -9.29642857142857
    MARKER    'MARKER'                 'INTORG'
    x_12_1    OBJ       2.1909231363139048e-02
    x_12_1    product_lb_175  -0.040634019704234
    x_12_1    product_ub_176  -1.0756819054947372e-01
    x_12_1    onehot_12_205  1
    x_12_1    stock_lb_208  1
    x_12_1    stock_ub_209  1
    x_12_1    parent_nonstrict_scope_210  6.5727694089417144e-02
    x_12_1    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_1    product_lb_175  1
    w_12_1    product_ub_176  1
    w_12_1    normalized_mass_12_206  1
    w_12_1    normalized_ratio_12_207  -1.4285714285714285e-01
    w_12_1    full_original_Gini_268  -8.15357142857143
    MARKER    'MARKER'                 'INTORG'
    x_12_2    OBJ       1.0954615681569524e-02
    x_12_2    product_lb_177  -0.040634019704234
    x_12_2    product_ub_178  -1.0756819054947372e-01
    x_12_2    onehot_12_205  1
    x_12_2    stock_lb_208  2
    x_12_2    stock_ub_209  2
    x_12_2    parent_nonstrict_scope_210  5.4773078407847620e-02
    x_12_2    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_2    product_lb_177  1
    w_12_2    product_ub_178  1
    w_12_2    normalized_mass_12_206  1
    w_12_2    normalized_ratio_12_207  -2.8571428571428570e-01
    w_12_2    full_original_Gini_268  -7.0107142857142870e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_3    product_lb_179  -0.040634019704234
    x_12_3    product_ub_180  -1.0756819054947372e-01
    x_12_3    onehot_12_205  1
    x_12_3    stock_lb_208  3
    x_12_3    stock_ub_209  3
    x_12_3    parent_nonstrict_scope_210  4.3818462726278096e-02
    x_12_3    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_3    product_lb_179  1
    w_12_3    product_ub_180  1
    w_12_3    normalized_mass_12_206  1
    w_12_3    normalized_ratio_12_207  -4.2857142857142855e-01
    w_12_3    full_original_Gini_268  -5.8678571428571420e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_4    OBJ       -1.0954615681569524e-02
    x_12_4    product_lb_181  -0.040634019704234
    x_12_4    product_ub_182  -1.0756819054947372e-01
    x_12_4    onehot_12_205  1
    x_12_4    stock_lb_208  4
    x_12_4    stock_ub_209  4
    x_12_4    parent_nonstrict_scope_210  3.2863847044708572e-02
    x_12_4    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_4    product_lb_181  1
    w_12_4    product_ub_182  1
    w_12_4    normalized_mass_12_206  1
    w_12_4    normalized_ratio_12_207  -5.7142857142857140e-01
    w_12_4    full_original_Gini_268  -4.7250000000000005e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_5    OBJ       -2.1909231363139041e-02
    x_12_5    product_lb_183  -0.040634019704234
    x_12_5    product_ub_184  -1.0756819054947372e-01
    x_12_5    onehot_12_205  1
    x_12_5    stock_lb_208  5
    x_12_5    stock_ub_209  5
    x_12_5    parent_nonstrict_scope_210  2.1909231363139055e-02
    x_12_5    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_5    product_lb_183  1
    w_12_5    product_ub_184  1
    w_12_5    normalized_mass_12_206  1
    w_12_5    normalized_ratio_12_207  -7.1428571428571419e-01
    w_12_5    full_original_Gini_268  -4.0964285714285706e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_6    OBJ       -3.2863847044708572e-02
    x_12_6    product_lb_185  -0.040634019704234
    x_12_6    product_ub_186  -1.0756819054947372e-01
    x_12_6    onehot_12_205  1
    x_12_6    stock_lb_208  6
    x_12_6    stock_ub_209  6
    x_12_6    parent_nonstrict_scope_210  1.0954615681569527e-02
    x_12_6    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_6    product_lb_185  1
    w_12_6    product_ub_186  1
    w_12_6    normalized_mass_12_206  1
    w_12_6    normalized_ratio_12_207  -8.5714285714285710e-01
    w_12_6    full_original_Gini_268  -3.5249999999999995e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_7    OBJ       -4.3818462726278096e-02
    x_12_7    product_lb_187  -0.040634019704234
    x_12_7    product_ub_188  -1.0756819054947372e-01
    x_12_7    onehot_12_205  1
    x_12_7    stock_lb_208  7
    x_12_7    stock_ub_209  7
    x_12_7    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_7    product_lb_187  1
    w_12_7    product_ub_188  1
    w_12_7    normalized_mass_12_206  1
    w_12_7    normalized_ratio_12_207  -1
    w_12_7    full_original_Gini_268  -2.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_8    OBJ       -3.2863847044708579e-02
    x_12_8    product_lb_189  -0.040634019704234
    x_12_8    product_ub_190  -1.0756819054947372e-01
    x_12_8    onehot_12_205  1
    x_12_8    stock_lb_208  8
    x_12_8    stock_ub_209  8
    x_12_8    parent_nonstrict_scope_210  1.0954615681569519e-02
    x_12_8    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_8    product_lb_189  1
    w_12_8    product_ub_190  1
    w_12_8    normalized_mass_12_206  1
    w_12_8    normalized_ratio_12_207  -1.1428571428571428e+00
    w_12_8    full_original_Gini_268  -4.4178571428571409e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_9    OBJ       -2.1909231363139058e-02
    x_12_9    product_lb_191  -0.040634019704234
    x_12_9    product_ub_192  -1.0756819054947372e-01
    x_12_9    onehot_12_205  1
    x_12_9    stock_lb_208  9
    x_12_9    stock_ub_209  9
    x_12_9    parent_nonstrict_scope_210  2.1909231363139037e-02
    x_12_9    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_9    product_lb_191  1
    w_12_9    product_ub_192  1
    w_12_9    normalized_mass_12_206  1
    w_12_9    normalized_ratio_12_207  -1.2857142857142856e+00
    w_12_9    full_original_Gini_268  -6.1321428571428562e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_10   OBJ       -1.0954615681569538e-02
    x_12_10   product_lb_193  -0.040634019704234
    x_12_10   product_ub_194  -1.0756819054947372e-01
    x_12_10   onehot_12_205  1
    x_12_10   stock_lb_208  10
    x_12_10   stock_ub_209  10
    x_12_10   parent_nonstrict_scope_210  3.2863847044708558e-02
    x_12_10   unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_10   product_lb_193  1
    w_12_10   product_ub_194  1
    w_12_10   normalized_mass_12_206  1
    w_12_10   normalized_ratio_12_207  -1.4285714285714284e+00
    w_12_10   full_original_Gini_268  -7.8464285714285715e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_11   product_lb_195  -0.040634019704234
    x_12_11   product_ub_196  -1.0756819054947372e-01
    x_12_11   onehot_12_205  1
    x_12_11   stock_lb_208  11
    x_12_11   stock_ub_209  11
    x_12_11   parent_nonstrict_scope_210  4.3818462726278096e-02
    MARKER    'MARKER'                 'INTEND'
    w_12_11   product_lb_195  1
    w_12_11   product_ub_196  1
    w_12_11   normalized_mass_12_206  1
    w_12_11   normalized_ratio_12_207  -1.5714285714285714e+00
    w_12_11   full_original_Gini_268  -9.5607142857142833e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_12   OBJ       1.0954615681569517e-02
    x_12_12   product_lb_197  -0.040634019704234
    x_12_12   product_ub_198  -1.0756819054947372e-01
    x_12_12   onehot_12_205  1
    x_12_12   stock_lb_208  12
    x_12_12   stock_ub_209  12
    x_12_12   parent_nonstrict_scope_210  5.4773078407847613e-02
    x_12_12   unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_12   product_lb_197  1
    w_12_12   product_ub_198  1
    w_12_12   normalized_mass_12_206  1
    w_12_12   normalized_ratio_12_207  -1.7142857142857142e+00
    w_12_12   full_original_Gini_268  -1.1274999999999997e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_13   OBJ       2.1909231363139034e-02
    x_12_13   product_lb_199  -0.040634019704234
    x_12_13   product_ub_200  -1.0756819054947372e-01
    x_12_13   onehot_12_205  1
    x_12_13   stock_lb_208  13
    x_12_13   stock_ub_209  13
    x_12_13   parent_nonstrict_scope_210  6.5727694089417130e-02
    x_12_13   unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_13   product_lb_199  1
    w_12_13   product_ub_200  1
    w_12_13   normalized_mass_12_206  1
    w_12_13   normalized_ratio_12_207  -1.8571428571428570e+00
    w_12_13   full_original_Gini_268  -1.2989285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_14   OBJ       3.2863847044708572e-02
    x_12_14   product_lb_201  -0.040634019704234
    x_12_14   product_ub_202  -1.0756819054947372e-01
    x_12_14   onehot_12_205  1
    x_12_14   stock_lb_208  14
    x_12_14   stock_ub_209  14
    x_12_14   parent_nonstrict_scope_210  7.6682309770986667e-02
    x_12_14   unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_14   product_lb_201  1
    w_12_14   product_ub_202  1
    w_12_14   normalized_mass_12_206  1
    w_12_14   normalized_ratio_12_207  -2
    w_12_14   full_original_Gini_268  -1.4703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_15   OBJ       4.3818462726278096e-02
    x_12_15   product_lb_203  -0.040634019704234
    x_12_15   product_ub_204  -1.0756819054947372e-01
    x_12_15   onehot_12_205  1
    x_12_15   stock_lb_208  15
    x_12_15   stock_ub_209  15
    x_12_15   parent_nonstrict_scope_210  8.7636925452556191e-02
    x_12_15   unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_15   product_lb_203  1
    w_12_15   product_ub_204  1
    w_12_15   normalized_mass_12_206  1
    w_12_15   normalized_ratio_12_207  -2.1428571428571428e+00
    w_12_15   full_original_Gini_268  -1.6417857142857141e+01
    rho_12    normalized_ratio_12_207  1
    rho_12    block_pair_pos_211  1
    rho_12    block_pair_neg_212  -1
    rho_12    block_pair_pos_215  1
    rho_12    block_pair_neg_216  -1
    rho_12    block_pair_pos_227  1
    rho_12    block_pair_neg_228  -1
    rho_12    block_pair_pos_235  1
    rho_12    block_pair_neg_236  -1
    rho_12    block_pair_pos_245  1
    rho_12    block_pair_neg_246  -1
    rho_12    block_pair_pos_259  1
    rho_12    block_pair_neg_260  -1
    rho_12    block_pair_pos_263  1
    rho_12    block_pair_neg_264  -1
    rho_12    normalization_267  1
    a_18_15   block_pair_pos_247  1
    a_18_15   block_pair_neg_248  1
    a_18_15   full_original_Gini_268  -1
    a_18_17   block_pair_pos_251  1
    a_18_17   block_pair_neg_252  1
    a_18_17   full_original_Gini_268  -1
    a_18_16   block_pair_pos_249  1
    a_18_16   block_pair_neg_250  1
    a_18_16   full_original_Gini_268  -1
    a_18_20   block_pair_pos_255  1
    a_18_20   block_pair_neg_256  1
    a_18_20   full_original_Gini_268  -1
    a_18_19   block_pair_pos_253  1
    a_18_19   block_pair_neg_254  1
    a_18_19   full_original_Gini_268  -1
    a_18_11   block_pair_pos_243  1
    a_18_11   block_pair_neg_244  1
    a_18_11   full_original_Gini_268  -1
    a_18_12   block_pair_pos_245  1
    a_18_12   block_pair_neg_246  1
    a_18_12   full_original_Gini_268  -1
    a_15_17   block_pair_pos_219  1
    a_15_17   block_pair_neg_220  1
    a_15_17   full_original_Gini_268  -1
    a_15_16   block_pair_pos_217  1
    a_15_16   block_pair_neg_218  1
    a_15_16   full_original_Gini_268  -1
    a_15_20   block_pair_pos_223  1
    a_15_20   block_pair_neg_224  1
    a_15_20   full_original_Gini_268  -1
    a_15_19   block_pair_pos_221  1
    a_15_19   block_pair_neg_222  1
    a_15_19   full_original_Gini_268  -1
    a_15_11   block_pair_pos_213  1
    a_15_11   block_pair_neg_214  1
    a_15_11   full_original_Gini_268  -1
    a_15_12   block_pair_pos_215  1
    a_15_12   block_pair_neg_216  1
    a_15_12   full_original_Gini_268  -1
    a_17_16   block_pair_pos_237  1
    a_17_16   block_pair_neg_238  1
    a_17_16   full_original_Gini_268  -1
    a_17_20   block_pair_pos_241  1
    a_17_20   block_pair_neg_242  1
    a_17_20   full_original_Gini_268  -1
    a_17_19   block_pair_pos_239  1
    a_17_19   block_pair_neg_240  1
    a_17_19   full_original_Gini_268  -1
    a_17_11   block_pair_pos_233  1
    a_17_11   block_pair_neg_234  1
    a_17_11   full_original_Gini_268  -1
    a_17_12   block_pair_pos_235  1
    a_17_12   block_pair_neg_236  1
    a_17_12   full_original_Gini_268  -1
    a_16_20   block_pair_pos_231  1
    a_16_20   block_pair_neg_232  1
    a_16_20   full_original_Gini_268  -1
    a_16_19   block_pair_pos_229  1
    a_16_19   block_pair_neg_230  1
    a_16_19   full_original_Gini_268  -1
    a_16_11   block_pair_pos_225  1
    a_16_11   block_pair_neg_226  1
    a_16_11   full_original_Gini_268  -1
    a_16_12   block_pair_pos_227  1
    a_16_12   block_pair_neg_228  1
    a_16_12   full_original_Gini_268  -1
    a_20_19   block_pair_pos_265  1
    a_20_19   block_pair_neg_266  1
    a_20_19   full_original_Gini_268  -1
    a_20_11   block_pair_pos_261  1
    a_20_11   block_pair_neg_262  1
    a_20_11   full_original_Gini_268  -1
    a_20_12   block_pair_pos_263  1
    a_20_12   block_pair_neg_264  1
    a_20_12   full_original_Gini_268  -1
    a_19_11   block_pair_pos_257  1
    a_19_11   block_pair_neg_258  1
    a_19_11   full_original_Gini_268  -1
    a_19_12   block_pair_pos_259  1
    a_19_12   block_pair_neg_260  1
    a_19_12   full_original_Gini_268  -1
    a_11_12   block_pair_pos_211  1
    a_11_12   block_pair_neg_212  1
    a_11_12   full_original_Gini_268  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_18_1  unique_nonzero_owner_269  1
    service_0_18_1  service_visit_def_794  1
    service_0_18_1  free_load_conservation_795  1
    service_0_18_2  unique_nonzero_owner_270  1
    service_0_18_2  service_visit_def_794  1
    service_0_18_2  free_load_conservation_795  2
    service_0_18_3  unique_nonzero_owner_271  1
    service_0_18_3  service_visit_def_794  1
    service_0_18_3  free_load_conservation_795  3
    service_0_18_4  unique_nonzero_owner_272  1
    service_0_18_4  service_visit_def_794  1
    service_0_18_4  free_load_conservation_795  4
    service_0_18_5  unique_nonzero_owner_273  1
    service_0_18_5  service_visit_def_794  1
    service_0_18_5  free_load_conservation_795  5
    service_0_18_6  unique_nonzero_owner_274  1
    service_0_18_6  service_visit_def_794  1
    service_0_18_6  free_load_conservation_795  6
    service_0_18_7  unique_nonzero_owner_275  1
    service_0_18_7  service_visit_def_794  1
    service_0_18_7  free_load_conservation_795  7
    service_0_18_8  unique_nonzero_owner_276  1
    service_0_18_8  service_visit_def_794  1
    service_0_18_8  free_load_conservation_795  8
    service_0_18_9  unique_nonzero_owner_277  1
    service_0_18_9  service_visit_def_794  1
    service_0_18_9  free_load_conservation_795  9
    service_0_18_10  unique_nonzero_owner_278  1
    service_0_18_10  service_visit_def_794  1
    service_0_18_10  free_load_conservation_795  10
    service_0_18_11  unique_nonzero_owner_279  1
    service_0_18_11  service_visit_def_794  1
    service_0_18_11  free_load_conservation_795  11
    service_0_18_12  unique_nonzero_owner_280  1
    service_0_18_12  service_visit_def_794  1
    service_0_18_12  free_load_conservation_795  12
    service_0_18_13  unique_nonzero_owner_281  1
    service_0_18_13  service_visit_def_794  1
    service_0_18_13  free_load_conservation_795  13
    service_0_18_14  unique_nonzero_owner_282  1
    service_0_18_14  service_visit_def_794  1
    service_0_18_14  free_load_conservation_795  14
    service_0_18_15  unique_nonzero_owner_283  1
    service_0_18_15  service_visit_def_794  1
    service_0_18_15  free_load_conservation_795  15
    service_1_18_1  unique_nonzero_owner_269  1
    service_1_18_1  service_visit_def_1167  1
    service_1_18_1  free_load_conservation_1168  1
    service_1_18_2  unique_nonzero_owner_270  1
    service_1_18_2  service_visit_def_1167  1
    service_1_18_2  free_load_conservation_1168  2
    service_1_18_3  unique_nonzero_owner_271  1
    service_1_18_3  service_visit_def_1167  1
    service_1_18_3  free_load_conservation_1168  3
    service_1_18_4  unique_nonzero_owner_272  1
    service_1_18_4  service_visit_def_1167  1
    service_1_18_4  free_load_conservation_1168  4
    service_1_18_5  unique_nonzero_owner_273  1
    service_1_18_5  service_visit_def_1167  1
    service_1_18_5  free_load_conservation_1168  5
    service_1_18_6  unique_nonzero_owner_274  1
    service_1_18_6  service_visit_def_1167  1
    service_1_18_6  free_load_conservation_1168  6
    service_1_18_7  unique_nonzero_owner_275  1
    service_1_18_7  service_visit_def_1167  1
    service_1_18_7  free_load_conservation_1168  7
    service_1_18_8  unique_nonzero_owner_276  1
    service_1_18_8  service_visit_def_1167  1
    service_1_18_8  free_load_conservation_1168  8
    service_1_18_9  unique_nonzero_owner_277  1
    service_1_18_9  service_visit_def_1167  1
    service_1_18_9  free_load_conservation_1168  9
    service_1_18_10  unique_nonzero_owner_278  1
    service_1_18_10  service_visit_def_1167  1
    service_1_18_10  free_load_conservation_1168  10
    service_1_18_11  unique_nonzero_owner_279  1
    service_1_18_11  service_visit_def_1167  1
    service_1_18_11  free_load_conservation_1168  11
    service_1_18_12  unique_nonzero_owner_280  1
    service_1_18_12  service_visit_def_1167  1
    service_1_18_12  free_load_conservation_1168  12
    service_1_18_13  unique_nonzero_owner_281  1
    service_1_18_13  service_visit_def_1167  1
    service_1_18_13  free_load_conservation_1168  13
    service_1_18_14  unique_nonzero_owner_282  1
    service_1_18_14  service_visit_def_1167  1
    service_1_18_14  free_load_conservation_1168  14
    service_1_18_15  unique_nonzero_owner_283  1
    service_1_18_15  service_visit_def_1167  1
    service_1_18_15  free_load_conservation_1168  15
    service_0_15_1  unique_nonzero_owner_284  1
    service_0_15_1  service_visit_def_800  1
    service_0_15_1  free_load_conservation_801  1
    service_1_15_1  unique_nonzero_owner_284  1
    service_1_15_1  service_visit_def_1173  1
    service_1_15_1  free_load_conservation_1174  1
    service_0_17_0  unique_nonzero_owner_285  1
    service_0_17_0  service_visit_def_806  1
    service_0_17_0  free_load_conservation_807  -3
    service_0_17_0  original_T_including_depot_unload_843  360
    service_0_17_1  unique_nonzero_owner_286  1
    service_0_17_1  service_visit_def_806  1
    service_0_17_1  free_load_conservation_807  -2
    service_0_17_1  original_T_including_depot_unload_843  240
    service_0_17_2  unique_nonzero_owner_287  1
    service_0_17_2  service_visit_def_806  1
    service_0_17_2  free_load_conservation_807  -1
    service_0_17_2  original_T_including_depot_unload_843  120
    service_0_17_4  unique_nonzero_owner_288  1
    service_0_17_4  service_visit_def_806  1
    service_0_17_4  free_load_conservation_807  1
    service_0_17_5  unique_nonzero_owner_289  1
    service_0_17_5  service_visit_def_806  1
    service_0_17_5  free_load_conservation_807  2
    service_0_17_6  unique_nonzero_owner_290  1
    service_0_17_6  service_visit_def_806  1
    service_0_17_6  free_load_conservation_807  3
    service_0_17_7  unique_nonzero_owner_291  1
    service_0_17_7  service_visit_def_806  1
    service_0_17_7  free_load_conservation_807  4
    service_0_17_8  unique_nonzero_owner_292  1
    service_0_17_8  service_visit_def_806  1
    service_0_17_8  free_load_conservation_807  5
    service_0_17_9  unique_nonzero_owner_293  1
    service_0_17_9  service_visit_def_806  1
    service_0_17_9  free_load_conservation_807  6
    service_0_17_10  unique_nonzero_owner_294  1
    service_0_17_10  service_visit_def_806  1
    service_0_17_10  free_load_conservation_807  7
    service_0_17_11  unique_nonzero_owner_295  1
    service_0_17_11  service_visit_def_806  1
    service_0_17_11  free_load_conservation_807  8
    service_0_17_12  unique_nonzero_owner_296  1
    service_0_17_12  service_visit_def_806  1
    service_0_17_12  free_load_conservation_807  9
    service_0_17_13  unique_nonzero_owner_297  1
    service_0_17_13  service_visit_def_806  1
    service_0_17_13  free_load_conservation_807  10
    service_0_17_14  unique_nonzero_owner_298  1
    service_0_17_14  service_visit_def_806  1
    service_0_17_14  free_load_conservation_807  11
    service_0_17_15  unique_nonzero_owner_299  1
    service_0_17_15  service_visit_def_806  1
    service_0_17_15  free_load_conservation_807  12
    service_0_17_16  unique_nonzero_owner_300  1
    service_0_17_16  service_visit_def_806  1
    service_0_17_16  free_load_conservation_807  13
    service_1_17_0  unique_nonzero_owner_285  1
    service_1_17_0  service_visit_def_1179  1
    service_1_17_0  free_load_conservation_1180  -3
    service_1_17_0  original_T_including_depot_unload_1214  360
    service_1_17_1  unique_nonzero_owner_286  1
    service_1_17_1  service_visit_def_1179  1
    service_1_17_1  free_load_conservation_1180  -2
    service_1_17_1  original_T_including_depot_unload_1214  240
    service_1_17_2  unique_nonzero_owner_287  1
    service_1_17_2  service_visit_def_1179  1
    service_1_17_2  free_load_conservation_1180  -1
    service_1_17_2  original_T_including_depot_unload_1214  120
    service_1_17_4  unique_nonzero_owner_288  1
    service_1_17_4  service_visit_def_1179  1
    service_1_17_4  free_load_conservation_1180  1
    service_1_17_5  unique_nonzero_owner_289  1
    service_1_17_5  service_visit_def_1179  1
    service_1_17_5  free_load_conservation_1180  2
    service_1_17_6  unique_nonzero_owner_290  1
    service_1_17_6  service_visit_def_1179  1
    service_1_17_6  free_load_conservation_1180  3
    service_1_17_7  unique_nonzero_owner_291  1
    service_1_17_7  service_visit_def_1179  1
    service_1_17_7  free_load_conservation_1180  4
    service_1_17_8  unique_nonzero_owner_292  1
    service_1_17_8  service_visit_def_1179  1
    service_1_17_8  free_load_conservation_1180  5
    service_1_17_9  unique_nonzero_owner_293  1
    service_1_17_9  service_visit_def_1179  1
    service_1_17_9  free_load_conservation_1180  6
    service_1_17_10  unique_nonzero_owner_294  1
    service_1_17_10  service_visit_def_1179  1
    service_1_17_10  free_load_conservation_1180  7
    service_1_17_11  unique_nonzero_owner_295  1
    service_1_17_11  service_visit_def_1179  1
    service_1_17_11  free_load_conservation_1180  8
    service_1_17_12  unique_nonzero_owner_296  1
    service_1_17_12  service_visit_def_1179  1
    service_1_17_12  free_load_conservation_1180  9
    service_1_17_13  unique_nonzero_owner_297  1
    service_1_17_13  service_visit_def_1179  1
    service_1_17_13  free_load_conservation_1180  10
    service_1_17_14  unique_nonzero_owner_298  1
    service_1_17_14  service_visit_def_1179  1
    service_1_17_14  free_load_conservation_1180  11
    service_1_17_15  unique_nonzero_owner_299  1
    service_1_17_15  service_visit_def_1179  1
    service_1_17_15  free_load_conservation_1180  12
    service_1_17_16  unique_nonzero_owner_300  1
    service_1_17_16  service_visit_def_1179  1
    service_1_17_16  free_load_conservation_1180  13
    service_0_16_0  unique_nonzero_owner_301  1
    service_0_16_0  service_visit_def_812  1
    service_0_16_0  free_load_conservation_813  -1
    service_0_16_0  original_T_including_depot_unload_843  120
    service_0_16_2  unique_nonzero_owner_302  1
    service_0_16_2  service_visit_def_812  1
    service_0_16_2  free_load_conservation_813  1
    service_1_16_0  unique_nonzero_owner_301  1
    service_1_16_0  service_visit_def_1185  1
    service_1_16_0  free_load_conservation_1186  -1
    service_1_16_0  original_T_including_depot_unload_1214  120
    service_1_16_2  unique_nonzero_owner_302  1
    service_1_16_2  service_visit_def_1185  1
    service_1_16_2  free_load_conservation_1186  1
    service_0_20_0  unique_nonzero_owner_303  1
    service_0_20_0  service_visit_def_818  1
    service_0_20_0  free_load_conservation_819  -12
    service_0_20_0  original_T_including_depot_unload_843  1440
    service_0_20_1  unique_nonzero_owner_304  1
    service_0_20_1  service_visit_def_818  1
    service_0_20_1  free_load_conservation_819  -11
    service_0_20_1  original_T_including_depot_unload_843  1320
    service_0_20_2  unique_nonzero_owner_305  1
    service_0_20_2  service_visit_def_818  1
    service_0_20_2  free_load_conservation_819  -10
    service_0_20_2  original_T_including_depot_unload_843  1200
    service_0_20_3  unique_nonzero_owner_306  1
    service_0_20_3  service_visit_def_818  1
    service_0_20_3  free_load_conservation_819  -9
    service_0_20_3  original_T_including_depot_unload_843  1080
    service_0_20_4  unique_nonzero_owner_307  1
    service_0_20_4  service_visit_def_818  1
    service_0_20_4  free_load_conservation_819  -8
    service_0_20_4  original_T_including_depot_unload_843  960
    service_0_20_5  unique_nonzero_owner_308  1
    service_0_20_5  service_visit_def_818  1
    service_0_20_5  free_load_conservation_819  -7
    service_0_20_5  original_T_including_depot_unload_843  840
    service_0_20_6  unique_nonzero_owner_309  1
    service_0_20_6  service_visit_def_818  1
    service_0_20_6  free_load_conservation_819  -6
    service_0_20_6  original_T_including_depot_unload_843  720
    service_0_20_7  unique_nonzero_owner_310  1
    service_0_20_7  service_visit_def_818  1
    service_0_20_7  free_load_conservation_819  -5
    service_0_20_7  original_T_including_depot_unload_843  600
    service_0_20_8  unique_nonzero_owner_311  1
    service_0_20_8  service_visit_def_818  1
    service_0_20_8  free_load_conservation_819  -4
    service_0_20_8  original_T_including_depot_unload_843  480
    service_0_20_9  unique_nonzero_owner_312  1
    service_0_20_9  service_visit_def_818  1
    service_0_20_9  free_load_conservation_819  -3
    service_0_20_9  original_T_including_depot_unload_843  360
    service_0_20_10  unique_nonzero_owner_313  1
    service_0_20_10  service_visit_def_818  1
    service_0_20_10  free_load_conservation_819  -2
    service_0_20_10  original_T_including_depot_unload_843  240
    service_0_20_11  unique_nonzero_owner_314  1
    service_0_20_11  service_visit_def_818  1
    service_0_20_11  free_load_conservation_819  -1
    service_0_20_11  original_T_including_depot_unload_843  120
    service_0_20_13  unique_nonzero_owner_315  1
    service_0_20_13  service_visit_def_818  1
    service_0_20_13  free_load_conservation_819  1
    service_0_20_14  unique_nonzero_owner_316  1
    service_0_20_14  service_visit_def_818  1
    service_0_20_14  free_load_conservation_819  2
    service_0_20_15  unique_nonzero_owner_317  1
    service_0_20_15  service_visit_def_818  1
    service_0_20_15  free_load_conservation_819  3
    service_1_20_0  unique_nonzero_owner_303  1
    service_1_20_0  service_visit_def_1191  1
    service_1_20_0  free_load_conservation_1192  -12
    service_1_20_0  original_T_including_depot_unload_1214  1440
    service_1_20_1  unique_nonzero_owner_304  1
    service_1_20_1  service_visit_def_1191  1
    service_1_20_1  free_load_conservation_1192  -11
    service_1_20_1  original_T_including_depot_unload_1214  1320
    service_1_20_2  unique_nonzero_owner_305  1
    service_1_20_2  service_visit_def_1191  1
    service_1_20_2  free_load_conservation_1192  -10
    service_1_20_2  original_T_including_depot_unload_1214  1200
    service_1_20_3  unique_nonzero_owner_306  1
    service_1_20_3  service_visit_def_1191  1
    service_1_20_3  free_load_conservation_1192  -9
    service_1_20_3  original_T_including_depot_unload_1214  1080
    service_1_20_4  unique_nonzero_owner_307  1
    service_1_20_4  service_visit_def_1191  1
    service_1_20_4  free_load_conservation_1192  -8
    service_1_20_4  original_T_including_depot_unload_1214  960
    service_1_20_5  unique_nonzero_owner_308  1
    service_1_20_5  service_visit_def_1191  1
    service_1_20_5  free_load_conservation_1192  -7
    service_1_20_5  original_T_including_depot_unload_1214  840
    service_1_20_6  unique_nonzero_owner_309  1
    service_1_20_6  service_visit_def_1191  1
    service_1_20_6  free_load_conservation_1192  -6
    service_1_20_6  original_T_including_depot_unload_1214  720
    service_1_20_7  unique_nonzero_owner_310  1
    service_1_20_7  service_visit_def_1191  1
    service_1_20_7  free_load_conservation_1192  -5
    service_1_20_7  original_T_including_depot_unload_1214  600
    service_1_20_8  unique_nonzero_owner_311  1
    service_1_20_8  service_visit_def_1191  1
    service_1_20_8  free_load_conservation_1192  -4
    service_1_20_8  original_T_including_depot_unload_1214  480
    service_1_20_9  unique_nonzero_owner_312  1
    service_1_20_9  service_visit_def_1191  1
    service_1_20_9  free_load_conservation_1192  -3
    service_1_20_9  original_T_including_depot_unload_1214  360
    service_1_20_10  unique_nonzero_owner_313  1
    service_1_20_10  service_visit_def_1191  1
    service_1_20_10  free_load_conservation_1192  -2
    service_1_20_10  original_T_including_depot_unload_1214  240
    service_1_20_11  unique_nonzero_owner_314  1
    service_1_20_11  service_visit_def_1191  1
    service_1_20_11  free_load_conservation_1192  -1
    service_1_20_11  original_T_including_depot_unload_1214  120
    service_1_20_13  unique_nonzero_owner_315  1
    service_1_20_13  service_visit_def_1191  1
    service_1_20_13  free_load_conservation_1192  1
    service_1_20_14  unique_nonzero_owner_316  1
    service_1_20_14  service_visit_def_1191  1
    service_1_20_14  free_load_conservation_1192  2
    service_1_20_15  unique_nonzero_owner_317  1
    service_1_20_15  service_visit_def_1191  1
    service_1_20_15  free_load_conservation_1192  3
    service_0_19_1  unique_nonzero_owner_318  1
    service_0_19_1  service_visit_def_824  1
    service_0_19_1  free_load_conservation_825  1
    service_0_19_2  unique_nonzero_owner_319  1
    service_0_19_2  service_visit_def_824  1
    service_0_19_2  free_load_conservation_825  2
    service_0_19_3  unique_nonzero_owner_320  1
    service_0_19_3  service_visit_def_824  1
    service_0_19_3  free_load_conservation_825  3
    service_0_19_4  unique_nonzero_owner_321  1
    service_0_19_4  service_visit_def_824  1
    service_0_19_4  free_load_conservation_825  4
    service_0_19_5  unique_nonzero_owner_322  1
    service_0_19_5  service_visit_def_824  1
    service_0_19_5  free_load_conservation_825  5
    service_1_19_1  unique_nonzero_owner_318  1
    service_1_19_1  service_visit_def_1197  1
    service_1_19_1  free_load_conservation_1198  1
    service_1_19_2  unique_nonzero_owner_319  1
    service_1_19_2  service_visit_def_1197  1
    service_1_19_2  free_load_conservation_1198  2
    service_1_19_3  unique_nonzero_owner_320  1
    service_1_19_3  service_visit_def_1197  1
    service_1_19_3  free_load_conservation_1198  3
    service_1_19_4  unique_nonzero_owner_321  1
    service_1_19_4  service_visit_def_1197  1
    service_1_19_4  free_load_conservation_1198  4
    service_1_19_5  unique_nonzero_owner_322  1
    service_1_19_5  service_visit_def_1197  1
    service_1_19_5  free_load_conservation_1198  5
    service_0_11_0  unique_nonzero_owner_323  1
    service_0_11_0  service_visit_def_830  1
    service_0_11_0  free_load_conservation_831  -1
    service_0_11_0  original_T_including_depot_unload_843  120
    service_0_11_2  unique_nonzero_owner_324  1
    service_0_11_2  service_visit_def_830  1
    service_0_11_2  free_load_conservation_831  1
    service_0_11_3  unique_nonzero_owner_325  1
    service_0_11_3  service_visit_def_830  1
    service_0_11_3  free_load_conservation_831  2
    service_0_11_4  unique_nonzero_owner_326  1
    service_0_11_4  service_visit_def_830  1
    service_0_11_4  free_load_conservation_831  3
    service_0_11_5  unique_nonzero_owner_327  1
    service_0_11_5  service_visit_def_830  1
    service_0_11_5  free_load_conservation_831  4
    service_0_11_6  unique_nonzero_owner_328  1
    service_0_11_6  service_visit_def_830  1
    service_0_11_6  free_load_conservation_831  5
    service_0_11_7  unique_nonzero_owner_329  1
    service_0_11_7  service_visit_def_830  1
    service_0_11_7  free_load_conservation_831  6
    service_0_11_8  unique_nonzero_owner_330  1
    service_0_11_8  service_visit_def_830  1
    service_0_11_8  free_load_conservation_831  7
    service_0_11_9  unique_nonzero_owner_331  1
    service_0_11_9  service_visit_def_830  1
    service_0_11_9  free_load_conservation_831  8
    service_0_11_10  unique_nonzero_owner_332  1
    service_0_11_10  service_visit_def_830  1
    service_0_11_10  free_load_conservation_831  9
    service_0_11_11  unique_nonzero_owner_333  1
    service_0_11_11  service_visit_def_830  1
    service_0_11_11  free_load_conservation_831  10
    service_0_11_12  unique_nonzero_owner_334  1
    service_0_11_12  service_visit_def_830  1
    service_0_11_12  free_load_conservation_831  11
    service_0_11_13  unique_nonzero_owner_335  1
    service_0_11_13  service_visit_def_830  1
    service_0_11_13  free_load_conservation_831  12
    service_0_11_14  unique_nonzero_owner_336  1
    service_0_11_14  service_visit_def_830  1
    service_0_11_14  free_load_conservation_831  13
    service_0_11_15  unique_nonzero_owner_337  1
    service_0_11_15  service_visit_def_830  1
    service_0_11_15  free_load_conservation_831  14
    service_1_11_0  unique_nonzero_owner_323  1
    service_1_11_0  service_visit_def_1203  1
    service_1_11_0  free_load_conservation_1204  -1
    service_1_11_0  original_T_including_depot_unload_1214  120
    service_1_11_2  unique_nonzero_owner_324  1
    service_1_11_2  service_visit_def_1203  1
    service_1_11_2  free_load_conservation_1204  1
    service_1_11_3  unique_nonzero_owner_325  1
    service_1_11_3  service_visit_def_1203  1
    service_1_11_3  free_load_conservation_1204  2
    service_1_11_4  unique_nonzero_owner_326  1
    service_1_11_4  service_visit_def_1203  1
    service_1_11_4  free_load_conservation_1204  3
    service_1_11_5  unique_nonzero_owner_327  1
    service_1_11_5  service_visit_def_1203  1
    service_1_11_5  free_load_conservation_1204  4
    service_1_11_6  unique_nonzero_owner_328  1
    service_1_11_6  service_visit_def_1203  1
    service_1_11_6  free_load_conservation_1204  5
    service_1_11_7  unique_nonzero_owner_329  1
    service_1_11_7  service_visit_def_1203  1
    service_1_11_7  free_load_conservation_1204  6
    service_1_11_8  unique_nonzero_owner_330  1
    service_1_11_8  service_visit_def_1203  1
    service_1_11_8  free_load_conservation_1204  7
    service_1_11_9  unique_nonzero_owner_331  1
    service_1_11_9  service_visit_def_1203  1
    service_1_11_9  free_load_conservation_1204  8
    service_1_11_10  unique_nonzero_owner_332  1
    service_1_11_10  service_visit_def_1203  1
    service_1_11_10  free_load_conservation_1204  9
    service_1_11_11  unique_nonzero_owner_333  1
    service_1_11_11  service_visit_def_1203  1
    service_1_11_11  free_load_conservation_1204  10
    service_1_11_12  unique_nonzero_owner_334  1
    service_1_11_12  service_visit_def_1203  1
    service_1_11_12  free_load_conservation_1204  11
    service_1_11_13  unique_nonzero_owner_335  1
    service_1_11_13  service_visit_def_1203  1
    service_1_11_13  free_load_conservation_1204  12
    service_1_11_14  unique_nonzero_owner_336  1
    service_1_11_14  service_visit_def_1203  1
    service_1_11_14  free_load_conservation_1204  13
    service_1_11_15  unique_nonzero_owner_337  1
    service_1_11_15  service_visit_def_1203  1
    service_1_11_15  free_load_conservation_1204  14
    service_0_12_0  unique_nonzero_owner_338  1
    service_0_12_0  service_visit_def_836  1
    service_0_12_0  free_load_conservation_837  -11
    service_0_12_0  original_T_including_depot_unload_843  1320
    service_0_12_1  unique_nonzero_owner_339  1
    service_0_12_1  service_visit_def_836  1
    service_0_12_1  free_load_conservation_837  -10
    service_0_12_1  original_T_including_depot_unload_843  1200
    service_0_12_2  unique_nonzero_owner_340  1
    service_0_12_2  service_visit_def_836  1
    service_0_12_2  free_load_conservation_837  -9
    service_0_12_2  original_T_including_depot_unload_843  1080
    service_0_12_3  unique_nonzero_owner_341  1
    service_0_12_3  service_visit_def_836  1
    service_0_12_3  free_load_conservation_837  -8
    service_0_12_3  original_T_including_depot_unload_843  960
    service_0_12_4  unique_nonzero_owner_342  1
    service_0_12_4  service_visit_def_836  1
    service_0_12_4  free_load_conservation_837  -7
    service_0_12_4  original_T_including_depot_unload_843  840
    service_0_12_5  unique_nonzero_owner_343  1
    service_0_12_5  service_visit_def_836  1
    service_0_12_5  free_load_conservation_837  -6
    service_0_12_5  original_T_including_depot_unload_843  720
    service_0_12_6  unique_nonzero_owner_344  1
    service_0_12_6  service_visit_def_836  1
    service_0_12_6  free_load_conservation_837  -5
    service_0_12_6  original_T_including_depot_unload_843  600
    service_0_12_7  unique_nonzero_owner_345  1
    service_0_12_7  service_visit_def_836  1
    service_0_12_7  free_load_conservation_837  -4
    service_0_12_7  original_T_including_depot_unload_843  480
    service_0_12_8  unique_nonzero_owner_346  1
    service_0_12_8  service_visit_def_836  1
    service_0_12_8  free_load_conservation_837  -3
    service_0_12_8  original_T_including_depot_unload_843  360
    service_0_12_9  unique_nonzero_owner_347  1
    service_0_12_9  service_visit_def_836  1
    service_0_12_9  free_load_conservation_837  -2
    service_0_12_9  original_T_including_depot_unload_843  240
    service_0_12_10  unique_nonzero_owner_348  1
    service_0_12_10  service_visit_def_836  1
    service_0_12_10  free_load_conservation_837  -1
    service_0_12_10  original_T_including_depot_unload_843  120
    service_0_12_12  unique_nonzero_owner_349  1
    service_0_12_12  service_visit_def_836  1
    service_0_12_12  free_load_conservation_837  1
    service_0_12_13  unique_nonzero_owner_350  1
    service_0_12_13  service_visit_def_836  1
    service_0_12_13  free_load_conservation_837  2
    service_0_12_14  unique_nonzero_owner_351  1
    service_0_12_14  service_visit_def_836  1
    service_0_12_14  free_load_conservation_837  3
    service_0_12_15  unique_nonzero_owner_352  1
    service_0_12_15  service_visit_def_836  1
    service_0_12_15  free_load_conservation_837  4
    service_1_12_0  unique_nonzero_owner_338  1
    service_1_12_0  service_visit_def_1209  1
    service_1_12_0  free_load_conservation_1210  -11
    service_1_12_0  original_T_including_depot_unload_1214  1320
    service_1_12_1  unique_nonzero_owner_339  1
    service_1_12_1  service_visit_def_1209  1
    service_1_12_1  free_load_conservation_1210  -10
    service_1_12_1  original_T_including_depot_unload_1214  1200
    service_1_12_2  unique_nonzero_owner_340  1
    service_1_12_2  service_visit_def_1209  1
    service_1_12_2  free_load_conservation_1210  -9
    service_1_12_2  original_T_including_depot_unload_1214  1080
    service_1_12_3  unique_nonzero_owner_341  1
    service_1_12_3  service_visit_def_1209  1
    service_1_12_3  free_load_conservation_1210  -8
    service_1_12_3  original_T_including_depot_unload_1214  960
    service_1_12_4  unique_nonzero_owner_342  1
    service_1_12_4  service_visit_def_1209  1
    service_1_12_4  free_load_conservation_1210  -7
    service_1_12_4  original_T_including_depot_unload_1214  840
    service_1_12_5  unique_nonzero_owner_343  1
    service_1_12_5  service_visit_def_1209  1
    service_1_12_5  free_load_conservation_1210  -6
    service_1_12_5  original_T_including_depot_unload_1214  720
    service_1_12_6  unique_nonzero_owner_344  1
    service_1_12_6  service_visit_def_1209  1
    service_1_12_6  free_load_conservation_1210  -5
    service_1_12_6  original_T_including_depot_unload_1214  600
    service_1_12_7  unique_nonzero_owner_345  1
    service_1_12_7  service_visit_def_1209  1
    service_1_12_7  free_load_conservation_1210  -4
    service_1_12_7  original_T_including_depot_unload_1214  480
    service_1_12_8  unique_nonzero_owner_346  1
    service_1_12_8  service_visit_def_1209  1
    service_1_12_8  free_load_conservation_1210  -3
    service_1_12_8  original_T_including_depot_unload_1214  360
    service_1_12_9  unique_nonzero_owner_347  1
    service_1_12_9  service_visit_def_1209  1
    service_1_12_9  free_load_conservation_1210  -2
    service_1_12_9  original_T_including_depot_unload_1214  240
    service_1_12_10  unique_nonzero_owner_348  1
    service_1_12_10  service_visit_def_1209  1
    service_1_12_10  free_load_conservation_1210  -1
    service_1_12_10  original_T_including_depot_unload_1214  120
    service_1_12_12  unique_nonzero_owner_349  1
    service_1_12_12  service_visit_def_1209  1
    service_1_12_12  free_load_conservation_1210  1
    service_1_12_13  unique_nonzero_owner_350  1
    service_1_12_13  service_visit_def_1209  1
    service_1_12_13  free_load_conservation_1210  2
    service_1_12_14  unique_nonzero_owner_351  1
    service_1_12_14  service_visit_def_1209  1
    service_1_12_14  free_load_conservation_1210  3
    service_1_12_15  unique_nonzero_owner_352  1
    service_1_12_15  service_visit_def_1209  1
    service_1_12_15  free_load_conservation_1210  4
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_748  -1
    visit_0_1  in_degree_749  -1
    visit_0_1  order_active_lb_750  -1
    visit_0_1  order_active_ub_751  -14
    order_0_1  connected_order_arc_370  -1
    order_0_1  connected_order_arc_372  -1
    order_0_1  connected_order_arc_374  -1
    order_0_1  connected_order_arc_376  -1
    order_0_1  connected_order_arc_378  -1
    order_0_1  connected_order_arc_380  -1
    order_0_1  connected_order_arc_382  -1
    order_0_1  connected_order_arc_384  -1
    order_0_1  connected_order_arc_386  -1
    order_0_1  connected_order_arc_388  -1
    order_0_1  connected_order_arc_390  -1
    order_0_1  connected_order_arc_392  -1
    order_0_1  connected_order_arc_394  -1
    order_0_1  connected_order_arc_397  1
    order_0_1  connected_order_arc_424  1
    order_0_1  connected_order_arc_451  1
    order_0_1  connected_order_arc_478  1
    order_0_1  connected_order_arc_505  1
    order_0_1  connected_order_arc_532  1
    order_0_1  connected_order_arc_559  1
    order_0_1  connected_order_arc_586  1
    order_0_1  connected_order_arc_613  1
    order_0_1  connected_order_arc_640  1
    order_0_1  connected_order_arc_667  1
    order_0_1  connected_order_arc_694  1
    order_0_1  connected_order_arc_721  1
    order_0_1  order_active_lb_750  1
    order_0_1  order_active_ub_751  1
    order_0_1  fixed_segment_relative_order_838  -1
    visit_0_2  out_degree_755  -1
    visit_0_2  in_degree_756  -1
    visit_0_2  order_active_lb_757  -1
    visit_0_2  order_active_ub_758  -14
    order_0_2  connected_order_arc_370  1
    order_0_2  connected_order_arc_397  -1
    order_0_2  connected_order_arc_399  -1
    order_0_2  connected_order_arc_401  -1
    order_0_2  connected_order_arc_403  -1
    order_0_2  connected_order_arc_405  -1
    order_0_2  connected_order_arc_407  -1
    order_0_2  connected_order_arc_409  -1
    order_0_2  connected_order_arc_411  -1
    order_0_2  connected_order_arc_413  -1
    order_0_2  connected_order_arc_415  -1
    order_0_2  connected_order_arc_417  -1
    order_0_2  connected_order_arc_419  -1
    order_0_2  connected_order_arc_421  -1
    order_0_2  connected_order_arc_426  1
    order_0_2  connected_order_arc_453  1
    order_0_2  connected_order_arc_480  1
    order_0_2  connected_order_arc_507  1
    order_0_2  connected_order_arc_534  1
    order_0_2  connected_order_arc_561  1
    order_0_2  connected_order_arc_588  1
    order_0_2  connected_order_arc_615  1
    order_0_2  connected_order_arc_642  1
    order_0_2  connected_order_arc_669  1
    order_0_2  connected_order_arc_696  1
    order_0_2  connected_order_arc_723  1
    order_0_2  order_active_lb_757  1
    order_0_2  order_active_ub_758  1
    order_0_2  fixed_segment_relative_order_838  1
    order_0_2  fixed_segment_relative_order_839  -1
    visit_0_3  out_degree_762  -1
    visit_0_3  in_degree_763  -1
    visit_0_3  order_active_lb_764  -1
    visit_0_3  order_active_ub_765  -14
    order_0_3  connected_order_arc_372  1
    order_0_3  connected_order_arc_399  1
    order_0_3  connected_order_arc_424  -1
    order_0_3  connected_order_arc_426  -1
    order_0_3  connected_order_arc_428  -1
    order_0_3  connected_order_arc_430  -1
    order_0_3  connected_order_arc_432  -1
    order_0_3  connected_order_arc_434  -1
    order_0_3  connected_order_arc_436  -1
    order_0_3  connected_order_arc_438  -1
    order_0_3  connected_order_arc_440  -1
    order_0_3  connected_order_arc_442  -1
    order_0_3  connected_order_arc_444  -1
    order_0_3  connected_order_arc_446  -1
    order_0_3  connected_order_arc_448  -1
    order_0_3  connected_order_arc_455  1
    order_0_3  connected_order_arc_482  1
    order_0_3  connected_order_arc_509  1
    order_0_3  connected_order_arc_536  1
    order_0_3  connected_order_arc_563  1
    order_0_3  connected_order_arc_590  1
    order_0_3  connected_order_arc_617  1
    order_0_3  connected_order_arc_644  1
    order_0_3  connected_order_arc_671  1
    order_0_3  connected_order_arc_698  1
    order_0_3  connected_order_arc_725  1
    order_0_3  order_active_lb_764  1
    order_0_3  order_active_ub_765  1
    order_0_3  fixed_segment_relative_order_839  1
    order_0_3  fixed_segment_relative_order_840  -1
    visit_0_4  out_degree_769  -1
    visit_0_4  in_degree_770  -1
    visit_0_4  order_active_lb_771  -1
    visit_0_4  order_active_ub_772  -14
    order_0_4  connected_order_arc_374  1
    order_0_4  connected_order_arc_401  1
    order_0_4  connected_order_arc_428  1
    order_0_4  connected_order_arc_451  -1
    order_0_4  connected_order_arc_453  -1
    order_0_4  connected_order_arc_455  -1
    order_0_4  connected_order_arc_457  -1
    order_0_4  connected_order_arc_459  -1
    order_0_4  connected_order_arc_461  -1
    order_0_4  connected_order_arc_463  -1
    order_0_4  connected_order_arc_465  -1
    order_0_4  connected_order_arc_467  -1
    order_0_4  connected_order_arc_469  -1
    order_0_4  connected_order_arc_471  -1
    order_0_4  connected_order_arc_473  -1
    order_0_4  connected_order_arc_475  -1
    order_0_4  connected_order_arc_484  1
    order_0_4  connected_order_arc_511  1
    order_0_4  connected_order_arc_538  1
    order_0_4  connected_order_arc_565  1
    order_0_4  connected_order_arc_592  1
    order_0_4  connected_order_arc_619  1
    order_0_4  connected_order_arc_646  1
    order_0_4  connected_order_arc_673  1
    order_0_4  connected_order_arc_700  1
    order_0_4  connected_order_arc_727  1
    order_0_4  order_active_lb_771  1
    order_0_4  order_active_ub_772  1
    order_0_4  fixed_segment_relative_order_840  1
    order_0_4  fixed_segment_relative_order_841  -1
    visit_0_5  out_degree_776  -1
    visit_0_5  in_degree_777  -1
    visit_0_5  order_active_lb_778  -1
    visit_0_5  order_active_ub_779  -14
    order_0_5  connected_order_arc_376  1
    order_0_5  connected_order_arc_403  1
    order_0_5  connected_order_arc_430  1
    order_0_5  connected_order_arc_457  1
    order_0_5  connected_order_arc_478  -1
    order_0_5  connected_order_arc_480  -1
    order_0_5  connected_order_arc_482  -1
    order_0_5  connected_order_arc_484  -1
    order_0_5  connected_order_arc_486  -1
    order_0_5  connected_order_arc_488  -1
    order_0_5  connected_order_arc_490  -1
    order_0_5  connected_order_arc_492  -1
    order_0_5  connected_order_arc_494  -1
    order_0_5  connected_order_arc_496  -1
    order_0_5  connected_order_arc_498  -1
    order_0_5  connected_order_arc_500  -1
    order_0_5  connected_order_arc_502  -1
    order_0_5  connected_order_arc_513  1
    order_0_5  connected_order_arc_540  1
    order_0_5  connected_order_arc_567  1
    order_0_5  connected_order_arc_594  1
    order_0_5  connected_order_arc_621  1
    order_0_5  connected_order_arc_648  1
    order_0_5  connected_order_arc_675  1
    order_0_5  connected_order_arc_702  1
    order_0_5  connected_order_arc_729  1
    order_0_5  order_active_lb_778  1
    order_0_5  order_active_ub_779  1
    order_0_5  fixed_segment_relative_order_841  1
    order_0_5  fixed_segment_relative_order_842  -1
    visit_0_6  out_degree_783  -1
    visit_0_6  in_degree_784  -1
    visit_0_6  order_active_lb_785  -1
    visit_0_6  order_active_ub_786  -14
    order_0_6  connected_order_arc_378  1
    order_0_6  connected_order_arc_405  1
    order_0_6  connected_order_arc_432  1
    order_0_6  connected_order_arc_459  1
    order_0_6  connected_order_arc_486  1
    order_0_6  connected_order_arc_505  -1
    order_0_6  connected_order_arc_507  -1
    order_0_6  connected_order_arc_509  -1
    order_0_6  connected_order_arc_511  -1
    order_0_6  connected_order_arc_513  -1
    order_0_6  connected_order_arc_515  -1
    order_0_6  connected_order_arc_517  -1
    order_0_6  connected_order_arc_519  -1
    order_0_6  connected_order_arc_521  -1
    order_0_6  connected_order_arc_523  -1
    order_0_6  connected_order_arc_525  -1
    order_0_6  connected_order_arc_527  -1
    order_0_6  connected_order_arc_529  -1
    order_0_6  connected_order_arc_542  1
    order_0_6  connected_order_arc_569  1
    order_0_6  connected_order_arc_596  1
    order_0_6  connected_order_arc_623  1
    order_0_6  connected_order_arc_650  1
    order_0_6  connected_order_arc_677  1
    order_0_6  connected_order_arc_704  1
    order_0_6  connected_order_arc_731  1
    order_0_6  order_active_lb_785  1
    order_0_6  order_active_ub_786  1
    order_0_6  fixed_segment_relative_order_842  1
    visit_0_11  out_degree_790  -1
    visit_0_11  in_degree_791  -1
    visit_0_11  order_active_lb_792  -1
    visit_0_11  order_active_ub_793  -14
    visit_0_11  service_visit_def_794  -1
    order_0_11  connected_order_arc_380  1
    order_0_11  connected_order_arc_407  1
    order_0_11  connected_order_arc_434  1
    order_0_11  connected_order_arc_461  1
    order_0_11  connected_order_arc_488  1
    order_0_11  connected_order_arc_515  1
    order_0_11  connected_order_arc_532  -1
    order_0_11  connected_order_arc_534  -1
    order_0_11  connected_order_arc_536  -1
    order_0_11  connected_order_arc_538  -1
    order_0_11  connected_order_arc_540  -1
    order_0_11  connected_order_arc_542  -1
    order_0_11  connected_order_arc_544  -1
    order_0_11  connected_order_arc_546  -1
    order_0_11  connected_order_arc_548  -1
    order_0_11  connected_order_arc_550  -1
    order_0_11  connected_order_arc_552  -1
    order_0_11  connected_order_arc_554  -1
    order_0_11  connected_order_arc_556  -1
    order_0_11  connected_order_arc_571  1
    order_0_11  connected_order_arc_598  1
    order_0_11  connected_order_arc_625  1
    order_0_11  connected_order_arc_652  1
    order_0_11  connected_order_arc_679  1
    order_0_11  connected_order_arc_706  1
    order_0_11  connected_order_arc_733  1
    order_0_11  order_active_lb_792  1
    order_0_11  order_active_ub_793  1
    visit_0_12  out_degree_796  -1
    visit_0_12  in_degree_797  -1
    visit_0_12  order_active_lb_798  -1
    visit_0_12  order_active_ub_799  -14
    visit_0_12  service_visit_def_800  -1
    order_0_12  connected_order_arc_382  1
    order_0_12  connected_order_arc_409  1
    order_0_12  connected_order_arc_436  1
    order_0_12  connected_order_arc_463  1
    order_0_12  connected_order_arc_490  1
    order_0_12  connected_order_arc_517  1
    order_0_12  connected_order_arc_544  1
    order_0_12  connected_order_arc_559  -1
    order_0_12  connected_order_arc_561  -1
    order_0_12  connected_order_arc_563  -1
    order_0_12  connected_order_arc_565  -1
    order_0_12  connected_order_arc_567  -1
    order_0_12  connected_order_arc_569  -1
    order_0_12  connected_order_arc_571  -1
    order_0_12  connected_order_arc_573  -1
    order_0_12  connected_order_arc_575  -1
    order_0_12  connected_order_arc_577  -1
    order_0_12  connected_order_arc_579  -1
    order_0_12  connected_order_arc_581  -1
    order_0_12  connected_order_arc_583  -1
    order_0_12  connected_order_arc_600  1
    order_0_12  connected_order_arc_627  1
    order_0_12  connected_order_arc_654  1
    order_0_12  connected_order_arc_681  1
    order_0_12  connected_order_arc_708  1
    order_0_12  connected_order_arc_735  1
    order_0_12  order_active_lb_798  1
    order_0_12  order_active_ub_799  1
    visit_0_13  out_degree_802  -1
    visit_0_13  in_degree_803  -1
    visit_0_13  order_active_lb_804  -1
    visit_0_13  order_active_ub_805  -14
    visit_0_13  service_visit_def_806  -1
    order_0_13  connected_order_arc_384  1
    order_0_13  connected_order_arc_411  1
    order_0_13  connected_order_arc_438  1
    order_0_13  connected_order_arc_465  1
    order_0_13  connected_order_arc_492  1
    order_0_13  connected_order_arc_519  1
    order_0_13  connected_order_arc_546  1
    order_0_13  connected_order_arc_573  1
    order_0_13  connected_order_arc_586  -1
    order_0_13  connected_order_arc_588  -1
    order_0_13  connected_order_arc_590  -1
    order_0_13  connected_order_arc_592  -1
    order_0_13  connected_order_arc_594  -1
    order_0_13  connected_order_arc_596  -1
    order_0_13  connected_order_arc_598  -1
    order_0_13  connected_order_arc_600  -1
    order_0_13  connected_order_arc_602  -1
    order_0_13  connected_order_arc_604  -1
    order_0_13  connected_order_arc_606  -1
    order_0_13  connected_order_arc_608  -1
    order_0_13  connected_order_arc_610  -1
    order_0_13  connected_order_arc_629  1
    order_0_13  connected_order_arc_656  1
    order_0_13  connected_order_arc_683  1
    order_0_13  connected_order_arc_710  1
    order_0_13  connected_order_arc_737  1
    order_0_13  order_active_lb_804  1
    order_0_13  order_active_ub_805  1
    visit_0_14  out_degree_808  -1
    visit_0_14  in_degree_809  -1
    visit_0_14  order_active_lb_810  -1
    visit_0_14  order_active_ub_811  -14
    visit_0_14  service_visit_def_812  -1
    order_0_14  connected_order_arc_386  1
    order_0_14  connected_order_arc_413  1
    order_0_14  connected_order_arc_440  1
    order_0_14  connected_order_arc_467  1
    order_0_14  connected_order_arc_494  1
    order_0_14  connected_order_arc_521  1
    order_0_14  connected_order_arc_548  1
    order_0_14  connected_order_arc_575  1
    order_0_14  connected_order_arc_602  1
    order_0_14  connected_order_arc_613  -1
    order_0_14  connected_order_arc_615  -1
    order_0_14  connected_order_arc_617  -1
    order_0_14  connected_order_arc_619  -1
    order_0_14  connected_order_arc_621  -1
    order_0_14  connected_order_arc_623  -1
    order_0_14  connected_order_arc_625  -1
    order_0_14  connected_order_arc_627  -1
    order_0_14  connected_order_arc_629  -1
    order_0_14  connected_order_arc_631  -1
    order_0_14  connected_order_arc_633  -1
    order_0_14  connected_order_arc_635  -1
    order_0_14  connected_order_arc_637  -1
    order_0_14  connected_order_arc_658  1
    order_0_14  connected_order_arc_685  1
    order_0_14  connected_order_arc_712  1
    order_0_14  connected_order_arc_739  1
    order_0_14  order_active_lb_810  1
    order_0_14  order_active_ub_811  1
    visit_0_15  out_degree_814  -1
    visit_0_15  in_degree_815  -1
    visit_0_15  order_active_lb_816  -1
    visit_0_15  order_active_ub_817  -14
    visit_0_15  service_visit_def_818  -1
    order_0_15  connected_order_arc_388  1
    order_0_15  connected_order_arc_415  1
    order_0_15  connected_order_arc_442  1
    order_0_15  connected_order_arc_469  1
    order_0_15  connected_order_arc_496  1
    order_0_15  connected_order_arc_523  1
    order_0_15  connected_order_arc_550  1
    order_0_15  connected_order_arc_577  1
    order_0_15  connected_order_arc_604  1
    order_0_15  connected_order_arc_631  1
    order_0_15  connected_order_arc_640  -1
    order_0_15  connected_order_arc_642  -1
    order_0_15  connected_order_arc_644  -1
    order_0_15  connected_order_arc_646  -1
    order_0_15  connected_order_arc_648  -1
    order_0_15  connected_order_arc_650  -1
    order_0_15  connected_order_arc_652  -1
    order_0_15  connected_order_arc_654  -1
    order_0_15  connected_order_arc_656  -1
    order_0_15  connected_order_arc_658  -1
    order_0_15  connected_order_arc_660  -1
    order_0_15  connected_order_arc_662  -1
    order_0_15  connected_order_arc_664  -1
    order_0_15  connected_order_arc_687  1
    order_0_15  connected_order_arc_714  1
    order_0_15  connected_order_arc_741  1
    order_0_15  order_active_lb_816  1
    order_0_15  order_active_ub_817  1
    visit_0_16  out_degree_820  -1
    visit_0_16  in_degree_821  -1
    visit_0_16  order_active_lb_822  -1
    visit_0_16  order_active_ub_823  -14
    visit_0_16  service_visit_def_824  -1
    order_0_16  connected_order_arc_390  1
    order_0_16  connected_order_arc_417  1
    order_0_16  connected_order_arc_444  1
    order_0_16  connected_order_arc_471  1
    order_0_16  connected_order_arc_498  1
    order_0_16  connected_order_arc_525  1
    order_0_16  connected_order_arc_552  1
    order_0_16  connected_order_arc_579  1
    order_0_16  connected_order_arc_606  1
    order_0_16  connected_order_arc_633  1
    order_0_16  connected_order_arc_660  1
    order_0_16  connected_order_arc_667  -1
    order_0_16  connected_order_arc_669  -1
    order_0_16  connected_order_arc_671  -1
    order_0_16  connected_order_arc_673  -1
    order_0_16  connected_order_arc_675  -1
    order_0_16  connected_order_arc_677  -1
    order_0_16  connected_order_arc_679  -1
    order_0_16  connected_order_arc_681  -1
    order_0_16  connected_order_arc_683  -1
    order_0_16  connected_order_arc_685  -1
    order_0_16  connected_order_arc_687  -1
    order_0_16  connected_order_arc_689  -1
    order_0_16  connected_order_arc_691  -1
    order_0_16  connected_order_arc_716  1
    order_0_16  connected_order_arc_743  1
    order_0_16  order_active_lb_822  1
    order_0_16  order_active_ub_823  1
    visit_0_17  out_degree_826  -1
    visit_0_17  in_degree_827  -1
    visit_0_17  order_active_lb_828  -1
    visit_0_17  order_active_ub_829  -14
    visit_0_17  service_visit_def_830  -1
    order_0_17  connected_order_arc_392  1
    order_0_17  connected_order_arc_419  1
    order_0_17  connected_order_arc_446  1
    order_0_17  connected_order_arc_473  1
    order_0_17  connected_order_arc_500  1
    order_0_17  connected_order_arc_527  1
    order_0_17  connected_order_arc_554  1
    order_0_17  connected_order_arc_581  1
    order_0_17  connected_order_arc_608  1
    order_0_17  connected_order_arc_635  1
    order_0_17  connected_order_arc_662  1
    order_0_17  connected_order_arc_689  1
    order_0_17  connected_order_arc_694  -1
    order_0_17  connected_order_arc_696  -1
    order_0_17  connected_order_arc_698  -1
    order_0_17  connected_order_arc_700  -1
    order_0_17  connected_order_arc_702  -1
    order_0_17  connected_order_arc_704  -1
    order_0_17  connected_order_arc_706  -1
    order_0_17  connected_order_arc_708  -1
    order_0_17  connected_order_arc_710  -1
    order_0_17  connected_order_arc_712  -1
    order_0_17  connected_order_arc_714  -1
    order_0_17  connected_order_arc_716  -1
    order_0_17  connected_order_arc_718  -1
    order_0_17  connected_order_arc_745  1
    order_0_17  order_active_lb_828  1
    order_0_17  order_active_ub_829  1
    visit_0_18  out_degree_832  -1
    visit_0_18  in_degree_833  -1
    visit_0_18  order_active_lb_834  -1
    visit_0_18  order_active_ub_835  -14
    visit_0_18  service_visit_def_836  -1
    order_0_18  connected_order_arc_394  1
    order_0_18  connected_order_arc_421  1
    order_0_18  connected_order_arc_448  1
    order_0_18  connected_order_arc_475  1
    order_0_18  connected_order_arc_502  1
    order_0_18  connected_order_arc_529  1
    order_0_18  connected_order_arc_556  1
    order_0_18  connected_order_arc_583  1
    order_0_18  connected_order_arc_610  1
    order_0_18  connected_order_arc_637  1
    order_0_18  connected_order_arc_664  1
    order_0_18  connected_order_arc_691  1
    order_0_18  connected_order_arc_718  1
    order_0_18  connected_order_arc_721  -1
    order_0_18  connected_order_arc_723  -1
    order_0_18  connected_order_arc_725  -1
    order_0_18  connected_order_arc_727  -1
    order_0_18  connected_order_arc_729  -1
    order_0_18  connected_order_arc_731  -1
    order_0_18  connected_order_arc_733  -1
    order_0_18  connected_order_arc_735  -1
    order_0_18  connected_order_arc_737  -1
    order_0_18  connected_order_arc_739  -1
    order_0_18  connected_order_arc_741  -1
    order_0_18  connected_order_arc_743  -1
    order_0_18  connected_order_arc_745  -1
    order_0_18  order_active_lb_834  1
    order_0_18  order_active_ub_835  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_353  -30
    arc_0_0_0  depot_departure_or_bypass_746  1
    arc_0_0_0  depot_return_or_bypass_747  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_353  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_354  -30
    arc_0_0_1  depot_departure_or_bypass_746  1
    arc_0_0_1  in_degree_749  1
    arc_0_0_1  original_T_including_depot_unload_843  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_354  1
    load_0_0_1  segment_load_conservation_752  -1
    load_0_0_1  segment_prefix_lb_753  1
    load_0_0_1  segment_prefix_ub_754  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_355  -30
    arc_0_0_2  depot_departure_or_bypass_746  1
    arc_0_0_2  in_degree_756  1
    arc_0_0_2  original_T_including_depot_unload_843  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_355  1
    load_0_0_2  segment_load_conservation_759  -1
    load_0_0_2  segment_prefix_lb_760  1
    load_0_0_2  segment_prefix_ub_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_356  -30
    arc_0_0_3  depot_departure_or_bypass_746  1
    arc_0_0_3  in_degree_763  1
    arc_0_0_3  original_T_including_depot_unload_843  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_356  1
    load_0_0_3  segment_load_conservation_766  -1
    load_0_0_3  segment_prefix_lb_767  1
    load_0_0_3  segment_prefix_ub_768  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_357  -30
    arc_0_0_4  depot_departure_or_bypass_746  1
    arc_0_0_4  in_degree_770  1
    arc_0_0_4  original_T_including_depot_unload_843  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_357  1
    load_0_0_4  segment_load_conservation_773  -1
    load_0_0_4  segment_prefix_lb_774  1
    load_0_0_4  segment_prefix_ub_775  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_358  -30
    arc_0_0_5  depot_departure_or_bypass_746  1
    arc_0_0_5  in_degree_777  1
    arc_0_0_5  original_T_including_depot_unload_843  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_358  1
    load_0_0_5  segment_load_conservation_780  -1
    load_0_0_5  segment_prefix_lb_781  1
    load_0_0_5  segment_prefix_ub_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_359  -30
    arc_0_0_6  depot_departure_or_bypass_746  1
    arc_0_0_6  in_degree_784  1
    arc_0_0_6  original_T_including_depot_unload_843  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_359  1
    load_0_0_6  segment_load_conservation_787  -1
    load_0_0_6  segment_prefix_lb_788  1
    load_0_0_6  segment_prefix_ub_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_11  arc_capacity_360  -30
    arc_0_0_11  depot_departure_or_bypass_746  1
    arc_0_0_11  in_degree_791  1
    arc_0_0_11  original_T_including_depot_unload_843  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_11  arc_capacity_360  1
    load_0_0_11  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_361  -30
    arc_0_0_12  depot_departure_or_bypass_746  1
    arc_0_0_12  in_degree_797  1
    arc_0_0_12  original_T_including_depot_unload_843  2.2779423489344404e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_361  1
    load_0_0_12  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_362  -30
    arc_0_0_13  depot_departure_or_bypass_746  1
    arc_0_0_13  in_degree_803  1
    arc_0_0_13  original_T_including_depot_unload_843  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_362  1
    load_0_0_13  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_363  -30
    arc_0_0_14  depot_departure_or_bypass_746  1
    arc_0_0_14  in_degree_809  1
    arc_0_0_14  original_T_including_depot_unload_843  2.2058800397347450e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_363  1
    load_0_0_14  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_364  -30
    arc_0_0_15  depot_departure_or_bypass_746  1
    arc_0_0_15  in_degree_815  1
    arc_0_0_15  original_T_including_depot_unload_843  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_364  1
    load_0_0_15  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_365  -30
    arc_0_0_16  depot_departure_or_bypass_746  1
    arc_0_0_16  in_degree_821  1
    arc_0_0_16  original_T_including_depot_unload_843  2.4985877836350596e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_365  1
    load_0_0_16  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_366  -30
    arc_0_0_17  depot_departure_or_bypass_746  1
    arc_0_0_17  in_degree_827  1
    arc_0_0_17  original_T_including_depot_unload_843  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_366  1
    load_0_0_17  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_367  -30
    arc_0_0_18  depot_departure_or_bypass_746  1
    arc_0_0_18  in_degree_833  1
    arc_0_0_18  original_T_including_depot_unload_843  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_367  1
    load_0_0_18  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_368  -30
    arc_0_1_0  depot_return_or_bypass_747  1
    arc_0_1_0  out_degree_748  1
    arc_0_1_0  original_T_including_depot_unload_843  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_368  1
    load_0_1_0  segment_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_369  -30
    arc_0_1_2  connected_order_arc_370  -15
    arc_0_1_2  out_degree_748  1
    arc_0_1_2  in_degree_756  1
    arc_0_1_2  original_T_including_depot_unload_843  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_369  1
    load_0_1_2  segment_load_conservation_752  1
    load_0_1_2  segment_load_conservation_759  -1
    load_0_1_2  segment_prefix_lb_760  1
    load_0_1_2  segment_prefix_ub_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_371  -30
    arc_0_1_3  connected_order_arc_372  -15
    arc_0_1_3  out_degree_748  1
    arc_0_1_3  in_degree_763  1
    arc_0_1_3  original_T_including_depot_unload_843  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_371  1
    load_0_1_3  segment_load_conservation_752  1
    load_0_1_3  segment_load_conservation_766  -1
    load_0_1_3  segment_prefix_lb_767  1
    load_0_1_3  segment_prefix_ub_768  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_373  -30
    arc_0_1_4  connected_order_arc_374  -15
    arc_0_1_4  out_degree_748  1
    arc_0_1_4  in_degree_770  1
    arc_0_1_4  original_T_including_depot_unload_843  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_373  1
    load_0_1_4  segment_load_conservation_752  1
    load_0_1_4  segment_load_conservation_773  -1
    load_0_1_4  segment_prefix_lb_774  1
    load_0_1_4  segment_prefix_ub_775  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_375  -30
    arc_0_1_5  connected_order_arc_376  -15
    arc_0_1_5  out_degree_748  1
    arc_0_1_5  in_degree_777  1
    arc_0_1_5  original_T_including_depot_unload_843  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_375  1
    load_0_1_5  segment_load_conservation_752  1
    load_0_1_5  segment_load_conservation_780  -1
    load_0_1_5  segment_prefix_lb_781  1
    load_0_1_5  segment_prefix_ub_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_377  -30
    arc_0_1_6  connected_order_arc_378  -15
    arc_0_1_6  out_degree_748  1
    arc_0_1_6  in_degree_784  1
    arc_0_1_6  original_T_including_depot_unload_843  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_377  1
    load_0_1_6  segment_load_conservation_752  1
    load_0_1_6  segment_load_conservation_787  -1
    load_0_1_6  segment_prefix_lb_788  1
    load_0_1_6  segment_prefix_ub_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_11  arc_capacity_379  -30
    arc_0_1_11  connected_order_arc_380  -15
    arc_0_1_11  out_degree_748  1
    arc_0_1_11  in_degree_791  1
    arc_0_1_11  original_T_including_depot_unload_843  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_11  arc_capacity_379  1
    load_0_1_11  segment_load_conservation_752  1
    load_0_1_11  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_381  -30
    arc_0_1_12  connected_order_arc_382  -15
    arc_0_1_12  out_degree_748  1
    arc_0_1_12  in_degree_797  1
    arc_0_1_12  original_T_including_depot_unload_843  2.8096824480964965e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_381  1
    load_0_1_12  segment_load_conservation_752  1
    load_0_1_12  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_383  -30
    arc_0_1_13  connected_order_arc_384  -15
    arc_0_1_13  out_degree_748  1
    arc_0_1_13  in_degree_803  1
    arc_0_1_13  original_T_including_depot_unload_843  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_383  1
    load_0_1_13  segment_load_conservation_752  1
    load_0_1_13  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_385  -30
    arc_0_1_14  connected_order_arc_386  -15
    arc_0_1_14  out_degree_748  1
    arc_0_1_14  in_degree_809  1
    arc_0_1_14  original_T_including_depot_unload_843  2.8077756945368888e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_385  1
    load_0_1_14  segment_load_conservation_752  1
    load_0_1_14  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_387  -30
    arc_0_1_15  connected_order_arc_388  -15
    arc_0_1_15  out_degree_748  1
    arc_0_1_15  in_degree_815  1
    arc_0_1_15  original_T_including_depot_unload_843  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_387  1
    load_0_1_15  segment_load_conservation_752  1
    load_0_1_15  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_389  -30
    arc_0_1_16  connected_order_arc_390  -15
    arc_0_1_16  out_degree_748  1
    arc_0_1_16  in_degree_821  1
    arc_0_1_16  original_T_including_depot_unload_843  2.9992588346691123e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_389  1
    load_0_1_16  segment_load_conservation_752  1
    load_0_1_16  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_391  -30
    arc_0_1_17  connected_order_arc_392  -15
    arc_0_1_17  out_degree_748  1
    arc_0_1_17  in_degree_827  1
    arc_0_1_17  original_T_including_depot_unload_843  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_391  1
    load_0_1_17  segment_load_conservation_752  1
    load_0_1_17  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_393  -30
    arc_0_1_18  connected_order_arc_394  -15
    arc_0_1_18  out_degree_748  1
    arc_0_1_18  in_degree_833  1
    arc_0_1_18  original_T_including_depot_unload_843  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_393  1
    load_0_1_18  segment_load_conservation_752  1
    load_0_1_18  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_395  -30
    arc_0_2_0  depot_return_or_bypass_747  1
    arc_0_2_0  out_degree_755  1
    arc_0_2_0  original_T_including_depot_unload_843  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_395  1
    load_0_2_0  segment_load_conservation_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_396  -30
    arc_0_2_1  connected_order_arc_397  -15
    arc_0_2_1  in_degree_749  1
    arc_0_2_1  out_degree_755  1
    arc_0_2_1  original_T_including_depot_unload_843  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_396  1
    load_0_2_1  segment_load_conservation_752  -1
    load_0_2_1  segment_prefix_lb_753  1
    load_0_2_1  segment_prefix_ub_754  1
    load_0_2_1  segment_load_conservation_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_398  -30
    arc_0_2_3  connected_order_arc_399  -15
    arc_0_2_3  out_degree_755  1
    arc_0_2_3  in_degree_763  1
    arc_0_2_3  original_T_including_depot_unload_843  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_398  1
    load_0_2_3  segment_load_conservation_759  1
    load_0_2_3  segment_load_conservation_766  -1
    load_0_2_3  segment_prefix_lb_767  1
    load_0_2_3  segment_prefix_ub_768  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_400  -30
    arc_0_2_4  connected_order_arc_401  -15
    arc_0_2_4  out_degree_755  1
    arc_0_2_4  in_degree_770  1
    arc_0_2_4  original_T_including_depot_unload_843  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_400  1
    load_0_2_4  segment_load_conservation_759  1
    load_0_2_4  segment_load_conservation_773  -1
    load_0_2_4  segment_prefix_lb_774  1
    load_0_2_4  segment_prefix_ub_775  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_402  -30
    arc_0_2_5  connected_order_arc_403  -15
    arc_0_2_5  out_degree_755  1
    arc_0_2_5  in_degree_777  1
    arc_0_2_5  original_T_including_depot_unload_843  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_402  1
    load_0_2_5  segment_load_conservation_759  1
    load_0_2_5  segment_load_conservation_780  -1
    load_0_2_5  segment_prefix_lb_781  1
    load_0_2_5  segment_prefix_ub_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_404  -30
    arc_0_2_6  connected_order_arc_405  -15
    arc_0_2_6  out_degree_755  1
    arc_0_2_6  in_degree_784  1
    arc_0_2_6  original_T_including_depot_unload_843  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_404  1
    load_0_2_6  segment_load_conservation_759  1
    load_0_2_6  segment_load_conservation_787  -1
    load_0_2_6  segment_prefix_lb_788  1
    load_0_2_6  segment_prefix_ub_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_11  arc_capacity_406  -30
    arc_0_2_11  connected_order_arc_407  -15
    arc_0_2_11  out_degree_755  1
    arc_0_2_11  in_degree_791  1
    arc_0_2_11  original_T_including_depot_unload_843  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_11  arc_capacity_406  1
    load_0_2_11  segment_load_conservation_759  1
    load_0_2_11  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_408  -30
    arc_0_2_12  connected_order_arc_409  -15
    arc_0_2_12  out_degree_755  1
    arc_0_2_12  in_degree_797  1
    arc_0_2_12  original_T_including_depot_unload_843  2.9012357973868689e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_408  1
    load_0_2_12  segment_load_conservation_759  1
    load_0_2_12  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_410  -30
    arc_0_2_13  connected_order_arc_411  -15
    arc_0_2_13  out_degree_755  1
    arc_0_2_13  in_degree_803  1
    arc_0_2_13  original_T_including_depot_unload_843  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_410  1
    load_0_2_13  segment_load_conservation_759  1
    load_0_2_13  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_412  -30
    arc_0_2_14  connected_order_arc_413  -15
    arc_0_2_14  out_degree_755  1
    arc_0_2_14  in_degree_809  1
    arc_0_2_14  original_T_including_depot_unload_843  2.9361273497784791e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_412  1
    load_0_2_14  segment_load_conservation_759  1
    load_0_2_14  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_414  -30
    arc_0_2_15  connected_order_arc_415  -15
    arc_0_2_15  out_degree_755  1
    arc_0_2_15  in_degree_815  1
    arc_0_2_15  original_T_including_depot_unload_843  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_414  1
    load_0_2_15  segment_load_conservation_759  1
    load_0_2_15  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_416  -30
    arc_0_2_16  connected_order_arc_417  -15
    arc_0_2_16  out_degree_755  1
    arc_0_2_16  in_degree_821  1
    arc_0_2_16  original_T_including_depot_unload_843  3.0706942101225172e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_416  1
    load_0_2_16  segment_load_conservation_759  1
    load_0_2_16  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_418  -30
    arc_0_2_17  connected_order_arc_419  -15
    arc_0_2_17  out_degree_755  1
    arc_0_2_17  in_degree_827  1
    arc_0_2_17  original_T_including_depot_unload_843  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_418  1
    load_0_2_17  segment_load_conservation_759  1
    load_0_2_17  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_420  -30
    arc_0_2_18  connected_order_arc_421  -15
    arc_0_2_18  out_degree_755  1
    arc_0_2_18  in_degree_833  1
    arc_0_2_18  original_T_including_depot_unload_843  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_420  1
    load_0_2_18  segment_load_conservation_759  1
    load_0_2_18  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_422  -30
    arc_0_3_0  depot_return_or_bypass_747  1
    arc_0_3_0  out_degree_762  1
    arc_0_3_0  original_T_including_depot_unload_843  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_422  1
    load_0_3_0  segment_load_conservation_766  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_423  -30
    arc_0_3_1  connected_order_arc_424  -15
    arc_0_3_1  in_degree_749  1
    arc_0_3_1  out_degree_762  1
    arc_0_3_1  original_T_including_depot_unload_843  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_423  1
    load_0_3_1  segment_load_conservation_752  -1
    load_0_3_1  segment_prefix_lb_753  1
    load_0_3_1  segment_prefix_ub_754  1
    load_0_3_1  segment_load_conservation_766  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_425  -30
    arc_0_3_2  connected_order_arc_426  -15
    arc_0_3_2  in_degree_756  1
    arc_0_3_2  out_degree_762  1
    arc_0_3_2  original_T_including_depot_unload_843  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_425  1
    load_0_3_2  segment_load_conservation_759  -1
    load_0_3_2  segment_prefix_lb_760  1
    load_0_3_2  segment_prefix_ub_761  1
    load_0_3_2  segment_load_conservation_766  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_427  -30
    arc_0_3_4  connected_order_arc_428  -15
    arc_0_3_4  out_degree_762  1
    arc_0_3_4  in_degree_770  1
    arc_0_3_4  original_T_including_depot_unload_843  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_427  1
    load_0_3_4  segment_load_conservation_766  1
    load_0_3_4  segment_load_conservation_773  -1
    load_0_3_4  segment_prefix_lb_774  1
    load_0_3_4  segment_prefix_ub_775  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_429  -30
    arc_0_3_5  connected_order_arc_430  -15
    arc_0_3_5  out_degree_762  1
    arc_0_3_5  in_degree_777  1
    arc_0_3_5  original_T_including_depot_unload_843  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_429  1
    load_0_3_5  segment_load_conservation_766  1
    load_0_3_5  segment_load_conservation_780  -1
    load_0_3_5  segment_prefix_lb_781  1
    load_0_3_5  segment_prefix_ub_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_431  -30
    arc_0_3_6  connected_order_arc_432  -15
    arc_0_3_6  out_degree_762  1
    arc_0_3_6  in_degree_784  1
    arc_0_3_6  original_T_including_depot_unload_843  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_431  1
    load_0_3_6  segment_load_conservation_766  1
    load_0_3_6  segment_load_conservation_787  -1
    load_0_3_6  segment_prefix_lb_788  1
    load_0_3_6  segment_prefix_ub_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_11  arc_capacity_433  -30
    arc_0_3_11  connected_order_arc_434  -15
    arc_0_3_11  out_degree_762  1
    arc_0_3_11  in_degree_791  1
    arc_0_3_11  original_T_including_depot_unload_843  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_11  arc_capacity_433  1
    load_0_3_11  segment_load_conservation_766  1
    load_0_3_11  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_435  -30
    arc_0_3_12  connected_order_arc_436  -15
    arc_0_3_12  out_degree_762  1
    arc_0_3_12  in_degree_797  1
    arc_0_3_12  original_T_including_depot_unload_843  3.2308847977395667e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_435  1
    load_0_3_12  segment_load_conservation_766  1
    load_0_3_12  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_437  -30
    arc_0_3_13  connected_order_arc_438  -15
    arc_0_3_13  out_degree_762  1
    arc_0_3_13  in_degree_803  1
    arc_0_3_13  original_T_including_depot_unload_843  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_437  1
    load_0_3_13  segment_load_conservation_766  1
    load_0_3_13  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_439  -30
    arc_0_3_14  connected_order_arc_440  -15
    arc_0_3_14  out_degree_762  1
    arc_0_3_14  in_degree_809  1
    arc_0_3_14  original_T_including_depot_unload_843  3.2360258354135326e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_439  1
    load_0_3_14  segment_load_conservation_766  1
    load_0_3_14  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_441  -30
    arc_0_3_15  connected_order_arc_442  -15
    arc_0_3_15  out_degree_762  1
    arc_0_3_15  in_degree_815  1
    arc_0_3_15  original_T_including_depot_unload_843  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_441  1
    load_0_3_15  segment_load_conservation_766  1
    load_0_3_15  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_443  -30
    arc_0_3_16  connected_order_arc_444  -15
    arc_0_3_16  out_degree_762  1
    arc_0_3_16  in_degree_821  1
    arc_0_3_16  original_T_including_depot_unload_843  3.4153410343469327e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_443  1
    load_0_3_16  segment_load_conservation_766  1
    load_0_3_16  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_445  -30
    arc_0_3_17  connected_order_arc_446  -15
    arc_0_3_17  out_degree_762  1
    arc_0_3_17  in_degree_827  1
    arc_0_3_17  original_T_including_depot_unload_843  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_445  1
    load_0_3_17  segment_load_conservation_766  1
    load_0_3_17  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_447  -30
    arc_0_3_18  connected_order_arc_448  -15
    arc_0_3_18  out_degree_762  1
    arc_0_3_18  in_degree_833  1
    arc_0_3_18  original_T_including_depot_unload_843  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_447  1
    load_0_3_18  segment_load_conservation_766  1
    load_0_3_18  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_449  -30
    arc_0_4_0  depot_return_or_bypass_747  1
    arc_0_4_0  out_degree_769  1
    arc_0_4_0  original_T_including_depot_unload_843  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_449  1
    load_0_4_0  segment_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_450  -30
    arc_0_4_1  connected_order_arc_451  -15
    arc_0_4_1  in_degree_749  1
    arc_0_4_1  out_degree_769  1
    arc_0_4_1  original_T_including_depot_unload_843  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_450  1
    load_0_4_1  segment_load_conservation_752  -1
    load_0_4_1  segment_prefix_lb_753  1
    load_0_4_1  segment_prefix_ub_754  1
    load_0_4_1  segment_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_452  -30
    arc_0_4_2  connected_order_arc_453  -15
    arc_0_4_2  in_degree_756  1
    arc_0_4_2  out_degree_769  1
    arc_0_4_2  original_T_including_depot_unload_843  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_452  1
    load_0_4_2  segment_load_conservation_759  -1
    load_0_4_2  segment_prefix_lb_760  1
    load_0_4_2  segment_prefix_ub_761  1
    load_0_4_2  segment_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_454  -30
    arc_0_4_3  connected_order_arc_455  -15
    arc_0_4_3  in_degree_763  1
    arc_0_4_3  out_degree_769  1
    arc_0_4_3  original_T_including_depot_unload_843  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_454  1
    load_0_4_3  segment_load_conservation_766  -1
    load_0_4_3  segment_prefix_lb_767  1
    load_0_4_3  segment_prefix_ub_768  1
    load_0_4_3  segment_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_456  -30
    arc_0_4_5  connected_order_arc_457  -15
    arc_0_4_5  out_degree_769  1
    arc_0_4_5  in_degree_777  1
    arc_0_4_5  original_T_including_depot_unload_843  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_456  1
    load_0_4_5  segment_load_conservation_773  1
    load_0_4_5  segment_load_conservation_780  -1
    load_0_4_5  segment_prefix_lb_781  1
    load_0_4_5  segment_prefix_ub_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_458  -30
    arc_0_4_6  connected_order_arc_459  -15
    arc_0_4_6  out_degree_769  1
    arc_0_4_6  in_degree_784  1
    arc_0_4_6  original_T_including_depot_unload_843  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_458  1
    load_0_4_6  segment_load_conservation_773  1
    load_0_4_6  segment_load_conservation_787  -1
    load_0_4_6  segment_prefix_lb_788  1
    load_0_4_6  segment_prefix_ub_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_11  arc_capacity_460  -30
    arc_0_4_11  connected_order_arc_461  -15
    arc_0_4_11  out_degree_769  1
    arc_0_4_11  in_degree_791  1
    arc_0_4_11  original_T_including_depot_unload_843  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_11  arc_capacity_460  1
    load_0_4_11  segment_load_conservation_773  1
    load_0_4_11  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_462  -30
    arc_0_4_12  connected_order_arc_463  -15
    arc_0_4_12  out_degree_769  1
    arc_0_4_12  in_degree_797  1
    arc_0_4_12  original_T_including_depot_unload_843  3.0014740451067628e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_462  1
    load_0_4_12  segment_load_conservation_773  1
    load_0_4_12  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_464  -30
    arc_0_4_13  connected_order_arc_465  -15
    arc_0_4_13  out_degree_769  1
    arc_0_4_13  in_degree_803  1
    arc_0_4_13  original_T_including_depot_unload_843  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_464  1
    load_0_4_13  segment_load_conservation_773  1
    load_0_4_13  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_466  -30
    arc_0_4_14  connected_order_arc_467  -15
    arc_0_4_14  out_degree_769  1
    arc_0_4_14  in_degree_809  1
    arc_0_4_14  original_T_including_depot_unload_843  2.9919713471999544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_466  1
    load_0_4_14  segment_load_conservation_773  1
    load_0_4_14  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_468  -30
    arc_0_4_15  connected_order_arc_469  -15
    arc_0_4_15  out_degree_769  1
    arc_0_4_15  in_degree_815  1
    arc_0_4_15  original_T_including_depot_unload_843  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_468  1
    load_0_4_15  segment_load_conservation_773  1
    load_0_4_15  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_470  -30
    arc_0_4_16  connected_order_arc_471  -15
    arc_0_4_16  out_degree_769  1
    arc_0_4_16  in_degree_821  1
    arc_0_4_16  original_T_including_depot_unload_843  3.1940365421146048e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_470  1
    load_0_4_16  segment_load_conservation_773  1
    load_0_4_16  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_472  -30
    arc_0_4_17  connected_order_arc_473  -15
    arc_0_4_17  out_degree_769  1
    arc_0_4_17  in_degree_827  1
    arc_0_4_17  original_T_including_depot_unload_843  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_472  1
    load_0_4_17  segment_load_conservation_773  1
    load_0_4_17  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_474  -30
    arc_0_4_18  connected_order_arc_475  -15
    arc_0_4_18  out_degree_769  1
    arc_0_4_18  in_degree_833  1
    arc_0_4_18  original_T_including_depot_unload_843  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_474  1
    load_0_4_18  segment_load_conservation_773  1
    load_0_4_18  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_476  -30
    arc_0_5_0  depot_return_or_bypass_747  1
    arc_0_5_0  out_degree_776  1
    arc_0_5_0  original_T_including_depot_unload_843  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_476  1
    load_0_5_0  segment_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_477  -30
    arc_0_5_1  connected_order_arc_478  -15
    arc_0_5_1  in_degree_749  1
    arc_0_5_1  out_degree_776  1
    arc_0_5_1  original_T_including_depot_unload_843  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_477  1
    load_0_5_1  segment_load_conservation_752  -1
    load_0_5_1  segment_prefix_lb_753  1
    load_0_5_1  segment_prefix_ub_754  1
    load_0_5_1  segment_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_479  -30
    arc_0_5_2  connected_order_arc_480  -15
    arc_0_5_2  in_degree_756  1
    arc_0_5_2  out_degree_776  1
    arc_0_5_2  original_T_including_depot_unload_843  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_479  1
    load_0_5_2  segment_load_conservation_759  -1
    load_0_5_2  segment_prefix_lb_760  1
    load_0_5_2  segment_prefix_ub_761  1
    load_0_5_2  segment_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_481  -30
    arc_0_5_3  connected_order_arc_482  -15
    arc_0_5_3  in_degree_763  1
    arc_0_5_3  out_degree_776  1
    arc_0_5_3  original_T_including_depot_unload_843  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_481  1
    load_0_5_3  segment_load_conservation_766  -1
    load_0_5_3  segment_prefix_lb_767  1
    load_0_5_3  segment_prefix_ub_768  1
    load_0_5_3  segment_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_483  -30
    arc_0_5_4  connected_order_arc_484  -15
    arc_0_5_4  in_degree_770  1
    arc_0_5_4  out_degree_776  1
    arc_0_5_4  original_T_including_depot_unload_843  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_483  1
    load_0_5_4  segment_load_conservation_773  -1
    load_0_5_4  segment_prefix_lb_774  1
    load_0_5_4  segment_prefix_ub_775  1
    load_0_5_4  segment_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_485  -30
    arc_0_5_6  connected_order_arc_486  -15
    arc_0_5_6  out_degree_776  1
    arc_0_5_6  in_degree_784  1
    arc_0_5_6  original_T_including_depot_unload_843  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_485  1
    load_0_5_6  segment_load_conservation_780  1
    load_0_5_6  segment_load_conservation_787  -1
    load_0_5_6  segment_prefix_lb_788  1
    load_0_5_6  segment_prefix_ub_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_11  arc_capacity_487  -30
    arc_0_5_11  connected_order_arc_488  -15
    arc_0_5_11  out_degree_776  1
    arc_0_5_11  in_degree_791  1
    arc_0_5_11  original_T_including_depot_unload_843  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_11  arc_capacity_487  1
    load_0_5_11  segment_load_conservation_780  1
    load_0_5_11  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_12  arc_capacity_489  -30
    arc_0_5_12  connected_order_arc_490  -15
    arc_0_5_12  out_degree_776  1
    arc_0_5_12  in_degree_797  1
    arc_0_5_12  original_T_including_depot_unload_843  2.8118819084250831e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_12  arc_capacity_489  1
    load_0_5_12  segment_load_conservation_780  1
    load_0_5_12  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_491  -30
    arc_0_5_13  connected_order_arc_492  -15
    arc_0_5_13  out_degree_776  1
    arc_0_5_13  in_degree_803  1
    arc_0_5_13  original_T_including_depot_unload_843  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_491  1
    load_0_5_13  segment_load_conservation_780  1
    load_0_5_13  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_493  -30
    arc_0_5_14  connected_order_arc_494  -15
    arc_0_5_14  out_degree_776  1
    arc_0_5_14  in_degree_809  1
    arc_0_5_14  original_T_including_depot_unload_843  2.7966160677056928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_493  1
    load_0_5_14  segment_load_conservation_780  1
    load_0_5_14  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_495  -30
    arc_0_5_15  connected_order_arc_496  -15
    arc_0_5_15  out_degree_776  1
    arc_0_5_15  in_degree_815  1
    arc_0_5_15  original_T_including_depot_unload_843  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_495  1
    load_0_5_15  segment_load_conservation_780  1
    load_0_5_15  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_497  -30
    arc_0_5_16  connected_order_arc_498  -15
    arc_0_5_16  out_degree_776  1
    arc_0_5_16  in_degree_821  1
    arc_0_5_16  original_T_including_depot_unload_843  3.0078695794061259e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_497  1
    load_0_5_16  segment_load_conservation_780  1
    load_0_5_16  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_499  -30
    arc_0_5_17  connected_order_arc_500  -15
    arc_0_5_17  out_degree_776  1
    arc_0_5_17  in_degree_827  1
    arc_0_5_17  original_T_including_depot_unload_843  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_499  1
    load_0_5_17  segment_load_conservation_780  1
    load_0_5_17  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_501  -30
    arc_0_5_18  connected_order_arc_502  -15
    arc_0_5_18  out_degree_776  1
    arc_0_5_18  in_degree_833  1
    arc_0_5_18  original_T_including_depot_unload_843  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_501  1
    load_0_5_18  segment_load_conservation_780  1
    load_0_5_18  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_503  -30
    arc_0_6_0  depot_return_or_bypass_747  1
    arc_0_6_0  out_degree_783  1
    arc_0_6_0  original_T_including_depot_unload_843  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_503  1
    load_0_6_0  segment_load_conservation_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_504  -30
    arc_0_6_1  connected_order_arc_505  -15
    arc_0_6_1  in_degree_749  1
    arc_0_6_1  out_degree_783  1
    arc_0_6_1  original_T_including_depot_unload_843  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_504  1
    load_0_6_1  segment_load_conservation_752  -1
    load_0_6_1  segment_prefix_lb_753  1
    load_0_6_1  segment_prefix_ub_754  1
    load_0_6_1  segment_load_conservation_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_506  -30
    arc_0_6_2  connected_order_arc_507  -15
    arc_0_6_2  in_degree_756  1
    arc_0_6_2  out_degree_783  1
    arc_0_6_2  original_T_including_depot_unload_843  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_506  1
    load_0_6_2  segment_load_conservation_759  -1
    load_0_6_2  segment_prefix_lb_760  1
    load_0_6_2  segment_prefix_ub_761  1
    load_0_6_2  segment_load_conservation_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_508  -30
    arc_0_6_3  connected_order_arc_509  -15
    arc_0_6_3  in_degree_763  1
    arc_0_6_3  out_degree_783  1
    arc_0_6_3  original_T_including_depot_unload_843  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_508  1
    load_0_6_3  segment_load_conservation_766  -1
    load_0_6_3  segment_prefix_lb_767  1
    load_0_6_3  segment_prefix_ub_768  1
    load_0_6_3  segment_load_conservation_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_510  -30
    arc_0_6_4  connected_order_arc_511  -15
    arc_0_6_4  in_degree_770  1
    arc_0_6_4  out_degree_783  1
    arc_0_6_4  original_T_including_depot_unload_843  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_510  1
    load_0_6_4  segment_load_conservation_773  -1
    load_0_6_4  segment_prefix_lb_774  1
    load_0_6_4  segment_prefix_ub_775  1
    load_0_6_4  segment_load_conservation_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_512  -30
    arc_0_6_5  connected_order_arc_513  -15
    arc_0_6_5  in_degree_777  1
    arc_0_6_5  out_degree_783  1
    arc_0_6_5  original_T_including_depot_unload_843  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_512  1
    load_0_6_5  segment_load_conservation_780  -1
    load_0_6_5  segment_prefix_lb_781  1
    load_0_6_5  segment_prefix_ub_782  1
    load_0_6_5  segment_load_conservation_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_11  arc_capacity_514  -30
    arc_0_6_11  connected_order_arc_515  -15
    arc_0_6_11  out_degree_783  1
    arc_0_6_11  in_degree_791  1
    arc_0_6_11  original_T_including_depot_unload_843  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_11  arc_capacity_514  1
    load_0_6_11  segment_load_conservation_787  1
    load_0_6_11  free_load_conservation_795  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_12  arc_capacity_516  -30
    arc_0_6_12  connected_order_arc_517  -15
    arc_0_6_12  out_degree_783  1
    arc_0_6_12  in_degree_797  1
    arc_0_6_12  original_T_including_depot_unload_843  2.7275263449800736e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_12  arc_capacity_516  1
    load_0_6_12  segment_load_conservation_787  1
    load_0_6_12  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_13  arc_capacity_518  -30
    arc_0_6_13  connected_order_arc_519  -15
    arc_0_6_13  out_degree_783  1
    arc_0_6_13  in_degree_803  1
    arc_0_6_13  original_T_including_depot_unload_843  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_13  arc_capacity_518  1
    load_0_6_13  segment_load_conservation_787  1
    load_0_6_13  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_14  arc_capacity_520  -30
    arc_0_6_14  connected_order_arc_521  -15
    arc_0_6_14  out_degree_783  1
    arc_0_6_14  in_degree_809  1
    arc_0_6_14  original_T_including_depot_unload_843  2.6985861397772510e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_14  arc_capacity_520  1
    load_0_6_14  segment_load_conservation_787  1
    load_0_6_14  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_522  -30
    arc_0_6_15  connected_order_arc_523  -15
    arc_0_6_15  out_degree_783  1
    arc_0_6_15  in_degree_815  1
    arc_0_6_15  original_T_including_depot_unload_843  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_522  1
    load_0_6_15  segment_load_conservation_787  1
    load_0_6_15  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_524  -30
    arc_0_6_16  connected_order_arc_525  -15
    arc_0_6_16  out_degree_783  1
    arc_0_6_16  in_degree_821  1
    arc_0_6_16  original_T_including_depot_unload_843  2.9299952981117208e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_524  1
    load_0_6_16  segment_load_conservation_787  1
    load_0_6_16  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_17  arc_capacity_526  -30
    arc_0_6_17  connected_order_arc_527  -15
    arc_0_6_17  out_degree_783  1
    arc_0_6_17  in_degree_827  1
    arc_0_6_17  original_T_including_depot_unload_843  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_17  arc_capacity_526  1
    load_0_6_17  segment_load_conservation_787  1
    load_0_6_17  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_18  arc_capacity_528  -30
    arc_0_6_18  connected_order_arc_529  -15
    arc_0_6_18  out_degree_783  1
    arc_0_6_18  in_degree_833  1
    arc_0_6_18  original_T_including_depot_unload_843  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_18  arc_capacity_528  1
    load_0_6_18  segment_load_conservation_787  1
    load_0_6_18  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_0  arc_capacity_530  -30
    arc_0_11_0  depot_return_or_bypass_747  1
    arc_0_11_0  out_degree_790  1
    arc_0_11_0  original_T_including_depot_unload_843  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_0  arc_capacity_530  1
    load_0_11_0  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_1  arc_capacity_531  -30
    arc_0_11_1  connected_order_arc_532  -15
    arc_0_11_1  in_degree_749  1
    arc_0_11_1  out_degree_790  1
    arc_0_11_1  original_T_including_depot_unload_843  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_1  arc_capacity_531  1
    load_0_11_1  segment_load_conservation_752  -1
    load_0_11_1  segment_prefix_lb_753  1
    load_0_11_1  segment_prefix_ub_754  1
    load_0_11_1  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_2  arc_capacity_533  -30
    arc_0_11_2  connected_order_arc_534  -15
    arc_0_11_2  in_degree_756  1
    arc_0_11_2  out_degree_790  1
    arc_0_11_2  original_T_including_depot_unload_843  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_2  arc_capacity_533  1
    load_0_11_2  segment_load_conservation_759  -1
    load_0_11_2  segment_prefix_lb_760  1
    load_0_11_2  segment_prefix_ub_761  1
    load_0_11_2  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_3  arc_capacity_535  -30
    arc_0_11_3  connected_order_arc_536  -15
    arc_0_11_3  in_degree_763  1
    arc_0_11_3  out_degree_790  1
    arc_0_11_3  original_T_including_depot_unload_843  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_3  arc_capacity_535  1
    load_0_11_3  segment_load_conservation_766  -1
    load_0_11_3  segment_prefix_lb_767  1
    load_0_11_3  segment_prefix_ub_768  1
    load_0_11_3  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_4  arc_capacity_537  -30
    arc_0_11_4  connected_order_arc_538  -15
    arc_0_11_4  in_degree_770  1
    arc_0_11_4  out_degree_790  1
    arc_0_11_4  original_T_including_depot_unload_843  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_4  arc_capacity_537  1
    load_0_11_4  segment_load_conservation_773  -1
    load_0_11_4  segment_prefix_lb_774  1
    load_0_11_4  segment_prefix_ub_775  1
    load_0_11_4  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_5  arc_capacity_539  -30
    arc_0_11_5  connected_order_arc_540  -15
    arc_0_11_5  in_degree_777  1
    arc_0_11_5  out_degree_790  1
    arc_0_11_5  original_T_including_depot_unload_843  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_5  arc_capacity_539  1
    load_0_11_5  segment_load_conservation_780  -1
    load_0_11_5  segment_prefix_lb_781  1
    load_0_11_5  segment_prefix_ub_782  1
    load_0_11_5  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_6  arc_capacity_541  -30
    arc_0_11_6  connected_order_arc_542  -15
    arc_0_11_6  in_degree_784  1
    arc_0_11_6  out_degree_790  1
    arc_0_11_6  original_T_including_depot_unload_843  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_6  arc_capacity_541  1
    load_0_11_6  segment_load_conservation_787  -1
    load_0_11_6  segment_prefix_lb_788  1
    load_0_11_6  segment_prefix_ub_789  1
    load_0_11_6  free_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_12  arc_capacity_543  -30
    arc_0_11_12  connected_order_arc_544  -15
    arc_0_11_12  out_degree_790  1
    arc_0_11_12  in_degree_797  1
    arc_0_11_12  original_T_including_depot_unload_843  1.3126604801096047e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_12  arc_capacity_543  1
    load_0_11_12  free_load_conservation_795  1
    load_0_11_12  free_load_conservation_801  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_13  arc_capacity_545  -30
    arc_0_11_13  connected_order_arc_546  -15
    arc_0_11_13  out_degree_790  1
    arc_0_11_13  in_degree_803  1
    arc_0_11_13  original_T_including_depot_unload_843  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_13  arc_capacity_545  1
    load_0_11_13  free_load_conservation_795  1
    load_0_11_13  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_14  arc_capacity_547  -30
    arc_0_11_14  connected_order_arc_548  -15
    arc_0_11_14  out_degree_790  1
    arc_0_11_14  in_degree_809  1
    arc_0_11_14  original_T_including_depot_unload_843  2.0591198250504166e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_14  arc_capacity_547  1
    load_0_11_14  free_load_conservation_795  1
    load_0_11_14  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_15  arc_capacity_549  -30
    arc_0_11_15  connected_order_arc_550  -15
    arc_0_11_15  out_degree_790  1
    arc_0_11_15  in_degree_815  1
    arc_0_11_15  original_T_including_depot_unload_843  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_15  arc_capacity_549  1
    load_0_11_15  free_load_conservation_795  1
    load_0_11_15  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_16  arc_capacity_551  -30
    arc_0_11_16  connected_order_arc_552  -15
    arc_0_11_16  out_degree_790  1
    arc_0_11_16  in_degree_821  1
    arc_0_11_16  original_T_including_depot_unload_843  2.8958539392642757e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_16  arc_capacity_551  1
    load_0_11_16  free_load_conservation_795  1
    load_0_11_16  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_17  arc_capacity_553  -30
    arc_0_11_17  connected_order_arc_554  -15
    arc_0_11_17  out_degree_790  1
    arc_0_11_17  in_degree_827  1
    arc_0_11_17  original_T_including_depot_unload_843  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_17  arc_capacity_553  1
    load_0_11_17  free_load_conservation_795  1
    load_0_11_17  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_18  arc_capacity_555  -30
    arc_0_11_18  connected_order_arc_556  -15
    arc_0_11_18  out_degree_790  1
    arc_0_11_18  in_degree_833  1
    arc_0_11_18  original_T_including_depot_unload_843  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_18  arc_capacity_555  1
    load_0_11_18  free_load_conservation_795  1
    load_0_11_18  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_557  -30
    arc_0_12_0  depot_return_or_bypass_747  1
    arc_0_12_0  out_degree_796  1
    arc_0_12_0  original_T_including_depot_unload_843  2.2779423489344404e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_557  1
    load_0_12_0  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_558  -30
    arc_0_12_1  connected_order_arc_559  -15
    arc_0_12_1  in_degree_749  1
    arc_0_12_1  out_degree_796  1
    arc_0_12_1  original_T_including_depot_unload_843  2.8096824480964965e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_558  1
    load_0_12_1  segment_load_conservation_752  -1
    load_0_12_1  segment_prefix_lb_753  1
    load_0_12_1  segment_prefix_ub_754  1
    load_0_12_1  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_560  -30
    arc_0_12_2  connected_order_arc_561  -15
    arc_0_12_2  in_degree_756  1
    arc_0_12_2  out_degree_796  1
    arc_0_12_2  original_T_including_depot_unload_843  2.9012357973868689e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_560  1
    load_0_12_2  segment_load_conservation_759  -1
    load_0_12_2  segment_prefix_lb_760  1
    load_0_12_2  segment_prefix_ub_761  1
    load_0_12_2  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_562  -30
    arc_0_12_3  connected_order_arc_563  -15
    arc_0_12_3  in_degree_763  1
    arc_0_12_3  out_degree_796  1
    arc_0_12_3  original_T_including_depot_unload_843  3.2308847977395667e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_562  1
    load_0_12_3  segment_load_conservation_766  -1
    load_0_12_3  segment_prefix_lb_767  1
    load_0_12_3  segment_prefix_ub_768  1
    load_0_12_3  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_564  -30
    arc_0_12_4  connected_order_arc_565  -15
    arc_0_12_4  in_degree_770  1
    arc_0_12_4  out_degree_796  1
    arc_0_12_4  original_T_including_depot_unload_843  3.0014740451067628e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_564  1
    load_0_12_4  segment_load_conservation_773  -1
    load_0_12_4  segment_prefix_lb_774  1
    load_0_12_4  segment_prefix_ub_775  1
    load_0_12_4  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_5  arc_capacity_566  -30
    arc_0_12_5  connected_order_arc_567  -15
    arc_0_12_5  in_degree_777  1
    arc_0_12_5  out_degree_796  1
    arc_0_12_5  original_T_including_depot_unload_843  2.8118819084250831e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_5  arc_capacity_566  1
    load_0_12_5  segment_load_conservation_780  -1
    load_0_12_5  segment_prefix_lb_781  1
    load_0_12_5  segment_prefix_ub_782  1
    load_0_12_5  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_6  arc_capacity_568  -30
    arc_0_12_6  connected_order_arc_569  -15
    arc_0_12_6  in_degree_784  1
    arc_0_12_6  out_degree_796  1
    arc_0_12_6  original_T_including_depot_unload_843  2.7275263449800736e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_6  arc_capacity_568  1
    load_0_12_6  segment_load_conservation_787  -1
    load_0_12_6  segment_prefix_lb_788  1
    load_0_12_6  segment_prefix_ub_789  1
    load_0_12_6  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_11  arc_capacity_570  -30
    arc_0_12_11  connected_order_arc_571  -15
    arc_0_12_11  in_degree_791  1
    arc_0_12_11  out_degree_796  1
    arc_0_12_11  original_T_including_depot_unload_843  1.3126604801096047e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_11  arc_capacity_570  1
    load_0_12_11  free_load_conservation_795  -1
    load_0_12_11  free_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_572  -30
    arc_0_12_13  connected_order_arc_573  -15
    arc_0_12_13  out_degree_796  1
    arc_0_12_13  in_degree_803  1
    arc_0_12_13  original_T_including_depot_unload_843  4.1781804970479707e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_572  1
    load_0_12_13  free_load_conservation_801  1
    load_0_12_13  free_load_conservation_807  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_574  -30
    arc_0_12_14  connected_order_arc_575  -15
    arc_0_12_14  out_degree_796  1
    arc_0_12_14  in_degree_809  1
    arc_0_12_14  original_T_including_depot_unload_843  2.9613729621393293e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_574  1
    load_0_12_14  free_load_conservation_801  1
    load_0_12_14  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_576  -30
    arc_0_12_15  connected_order_arc_577  -15
    arc_0_12_15  out_degree_796  1
    arc_0_12_15  in_degree_815  1
    arc_0_12_15  original_T_including_depot_unload_843  2.6300071929095179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_576  1
    load_0_12_15  free_load_conservation_801  1
    load_0_12_15  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_578  -30
    arc_0_12_16  connected_order_arc_579  -15
    arc_0_12_16  out_degree_796  1
    arc_0_12_16  in_degree_821  1
    arc_0_12_16  original_T_including_depot_unload_843  2.4254234166891203e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_578  1
    load_0_12_16  free_load_conservation_801  1
    load_0_12_16  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_17  arc_capacity_580  -30
    arc_0_12_17  connected_order_arc_581  -15
    arc_0_12_17  out_degree_796  1
    arc_0_12_17  in_degree_827  1
    arc_0_12_17  original_T_including_depot_unload_843  2.6166334544495612e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_17  arc_capacity_580  1
    load_0_12_17  free_load_conservation_801  1
    load_0_12_17  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_18  arc_capacity_582  -30
    arc_0_12_18  connected_order_arc_583  -15
    arc_0_12_18  out_degree_796  1
    arc_0_12_18  in_degree_833  1
    arc_0_12_18  original_T_including_depot_unload_843  2389.0890755213
    MARKER    'MARKER'                 'INTEND'
    load_0_12_18  arc_capacity_582  1
    load_0_12_18  free_load_conservation_801  1
    load_0_12_18  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_584  -30
    arc_0_13_0  depot_return_or_bypass_747  1
    arc_0_13_0  out_degree_802  1
    arc_0_13_0  original_T_including_depot_unload_843  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_584  1
    load_0_13_0  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_585  -30
    arc_0_13_1  connected_order_arc_586  -15
    arc_0_13_1  in_degree_749  1
    arc_0_13_1  out_degree_802  1
    arc_0_13_1  original_T_including_depot_unload_843  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_585  1
    load_0_13_1  segment_load_conservation_752  -1
    load_0_13_1  segment_prefix_lb_753  1
    load_0_13_1  segment_prefix_ub_754  1
    load_0_13_1  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_587  -30
    arc_0_13_2  connected_order_arc_588  -15
    arc_0_13_2  in_degree_756  1
    arc_0_13_2  out_degree_802  1
    arc_0_13_2  original_T_including_depot_unload_843  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_587  1
    load_0_13_2  segment_load_conservation_759  -1
    load_0_13_2  segment_prefix_lb_760  1
    load_0_13_2  segment_prefix_ub_761  1
    load_0_13_2  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_589  -30
    arc_0_13_3  connected_order_arc_590  -15
    arc_0_13_3  in_degree_763  1
    arc_0_13_3  out_degree_802  1
    arc_0_13_3  original_T_including_depot_unload_843  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_589  1
    load_0_13_3  segment_load_conservation_766  -1
    load_0_13_3  segment_prefix_lb_767  1
    load_0_13_3  segment_prefix_ub_768  1
    load_0_13_3  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_591  -30
    arc_0_13_4  connected_order_arc_592  -15
    arc_0_13_4  in_degree_770  1
    arc_0_13_4  out_degree_802  1
    arc_0_13_4  original_T_including_depot_unload_843  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_591  1
    load_0_13_4  segment_load_conservation_773  -1
    load_0_13_4  segment_prefix_lb_774  1
    load_0_13_4  segment_prefix_ub_775  1
    load_0_13_4  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_593  -30
    arc_0_13_5  connected_order_arc_594  -15
    arc_0_13_5  in_degree_777  1
    arc_0_13_5  out_degree_802  1
    arc_0_13_5  original_T_including_depot_unload_843  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_593  1
    load_0_13_5  segment_load_conservation_780  -1
    load_0_13_5  segment_prefix_lb_781  1
    load_0_13_5  segment_prefix_ub_782  1
    load_0_13_5  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_6  arc_capacity_595  -30
    arc_0_13_6  connected_order_arc_596  -15
    arc_0_13_6  in_degree_784  1
    arc_0_13_6  out_degree_802  1
    arc_0_13_6  original_T_including_depot_unload_843  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_6  arc_capacity_595  1
    load_0_13_6  segment_load_conservation_787  -1
    load_0_13_6  segment_prefix_lb_788  1
    load_0_13_6  segment_prefix_ub_789  1
    load_0_13_6  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_11  arc_capacity_597  -30
    arc_0_13_11  connected_order_arc_598  -15
    arc_0_13_11  in_degree_791  1
    arc_0_13_11  out_degree_802  1
    arc_0_13_11  original_T_including_depot_unload_843  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_11  arc_capacity_597  1
    load_0_13_11  free_load_conservation_795  -1
    load_0_13_11  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_599  -30
    arc_0_13_12  connected_order_arc_600  -15
    arc_0_13_12  in_degree_797  1
    arc_0_13_12  out_degree_802  1
    arc_0_13_12  original_T_including_depot_unload_843  4.1781804970479707e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_599  1
    load_0_13_12  free_load_conservation_801  -1
    load_0_13_12  free_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_601  -30
    arc_0_13_14  connected_order_arc_602  -15
    arc_0_13_14  out_degree_802  1
    arc_0_13_14  in_degree_809  1
    arc_0_13_14  original_T_including_depot_unload_843  3.9880377227050253e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_601  1
    load_0_13_14  free_load_conservation_807  1
    load_0_13_14  free_load_conservation_813  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_603  -30
    arc_0_13_15  connected_order_arc_604  -15
    arc_0_13_15  out_degree_802  1
    arc_0_13_15  in_degree_815  1
    arc_0_13_15  original_T_including_depot_unload_843  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_603  1
    load_0_13_15  free_load_conservation_807  1
    load_0_13_15  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_605  -30
    arc_0_13_16  connected_order_arc_606  -15
    arc_0_13_16  out_degree_802  1
    arc_0_13_16  in_degree_821  1
    arc_0_13_16  original_T_including_depot_unload_843  4.4205864351455948e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_605  1
    load_0_13_16  free_load_conservation_807  1
    load_0_13_16  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_607  -30
    arc_0_13_17  connected_order_arc_608  -15
    arc_0_13_17  out_degree_802  1
    arc_0_13_17  in_degree_827  1
    arc_0_13_17  original_T_including_depot_unload_843  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_607  1
    load_0_13_17  free_load_conservation_807  1
    load_0_13_17  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_609  -30
    arc_0_13_18  connected_order_arc_610  -15
    arc_0_13_18  out_degree_802  1
    arc_0_13_18  in_degree_833  1
    arc_0_13_18  original_T_including_depot_unload_843  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_609  1
    load_0_13_18  free_load_conservation_807  1
    load_0_13_18  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_611  -30
    arc_0_14_0  depot_return_or_bypass_747  1
    arc_0_14_0  out_degree_808  1
    arc_0_14_0  original_T_including_depot_unload_843  2.2058800397347450e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_611  1
    load_0_14_0  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_612  -30
    arc_0_14_1  connected_order_arc_613  -15
    arc_0_14_1  in_degree_749  1
    arc_0_14_1  out_degree_808  1
    arc_0_14_1  original_T_including_depot_unload_843  2.8077756945368888e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_612  1
    load_0_14_1  segment_load_conservation_752  -1
    load_0_14_1  segment_prefix_lb_753  1
    load_0_14_1  segment_prefix_ub_754  1
    load_0_14_1  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_614  -30
    arc_0_14_2  connected_order_arc_615  -15
    arc_0_14_2  in_degree_756  1
    arc_0_14_2  out_degree_808  1
    arc_0_14_2  original_T_including_depot_unload_843  2.9361273497784791e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_614  1
    load_0_14_2  segment_load_conservation_759  -1
    load_0_14_2  segment_prefix_lb_760  1
    load_0_14_2  segment_prefix_ub_761  1
    load_0_14_2  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_616  -30
    arc_0_14_3  connected_order_arc_617  -15
    arc_0_14_3  in_degree_763  1
    arc_0_14_3  out_degree_808  1
    arc_0_14_3  original_T_including_depot_unload_843  3.2360258354135326e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_616  1
    load_0_14_3  segment_load_conservation_766  -1
    load_0_14_3  segment_prefix_lb_767  1
    load_0_14_3  segment_prefix_ub_768  1
    load_0_14_3  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_618  -30
    arc_0_14_4  connected_order_arc_619  -15
    arc_0_14_4  in_degree_770  1
    arc_0_14_4  out_degree_808  1
    arc_0_14_4  original_T_including_depot_unload_843  2.9919713471999544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_618  1
    load_0_14_4  segment_load_conservation_773  -1
    load_0_14_4  segment_prefix_lb_774  1
    load_0_14_4  segment_prefix_ub_775  1
    load_0_14_4  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_620  -30
    arc_0_14_5  connected_order_arc_621  -15
    arc_0_14_5  in_degree_777  1
    arc_0_14_5  out_degree_808  1
    arc_0_14_5  original_T_including_depot_unload_843  2.7966160677056928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_620  1
    load_0_14_5  segment_load_conservation_780  -1
    load_0_14_5  segment_prefix_lb_781  1
    load_0_14_5  segment_prefix_ub_782  1
    load_0_14_5  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_6  arc_capacity_622  -30
    arc_0_14_6  connected_order_arc_623  -15
    arc_0_14_6  in_degree_784  1
    arc_0_14_6  out_degree_808  1
    arc_0_14_6  original_T_including_depot_unload_843  2.6985861397772510e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_6  arc_capacity_622  1
    load_0_14_6  segment_load_conservation_787  -1
    load_0_14_6  segment_prefix_lb_788  1
    load_0_14_6  segment_prefix_ub_789  1
    load_0_14_6  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_11  arc_capacity_624  -30
    arc_0_14_11  connected_order_arc_625  -15
    arc_0_14_11  in_degree_791  1
    arc_0_14_11  out_degree_808  1
    arc_0_14_11  original_T_including_depot_unload_843  2.0591198250504166e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_11  arc_capacity_624  1
    load_0_14_11  free_load_conservation_795  -1
    load_0_14_11  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_626  -30
    arc_0_14_12  connected_order_arc_627  -15
    arc_0_14_12  in_degree_797  1
    arc_0_14_12  out_degree_808  1
    arc_0_14_12  original_T_including_depot_unload_843  2.9613729621393293e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_626  1
    load_0_14_12  free_load_conservation_801  -1
    load_0_14_12  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_628  -30
    arc_0_14_13  connected_order_arc_629  -15
    arc_0_14_13  in_degree_803  1
    arc_0_14_13  out_degree_808  1
    arc_0_14_13  original_T_including_depot_unload_843  3.9880377227050253e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_628  1
    load_0_14_13  free_load_conservation_807  -1
    load_0_14_13  free_load_conservation_813  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_630  -30
    arc_0_14_15  connected_order_arc_631  -15
    arc_0_14_15  out_degree_808  1
    arc_0_14_15  in_degree_815  1
    arc_0_14_15  original_T_including_depot_unload_843  2.3631048359201741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_630  1
    load_0_14_15  free_load_conservation_813  1
    load_0_14_15  free_load_conservation_819  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_632  -30
    arc_0_14_16  connected_order_arc_633  -15
    arc_0_14_16  out_degree_808  1
    arc_0_14_16  in_degree_821  1
    arc_0_14_16  original_T_including_depot_unload_843  4.9538322318613183e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_632  1
    load_0_14_16  free_load_conservation_813  1
    load_0_14_16  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_634  -30
    arc_0_14_17  connected_order_arc_635  -15
    arc_0_14_17  out_degree_808  1
    arc_0_14_17  in_degree_827  1
    arc_0_14_17  original_T_including_depot_unload_843  2.5694031842490126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_634  1
    load_0_14_17  free_load_conservation_813  1
    load_0_14_17  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_636  -30
    arc_0_14_18  connected_order_arc_637  -15
    arc_0_14_18  out_degree_808  1
    arc_0_14_18  in_degree_833  1
    arc_0_14_18  original_T_including_depot_unload_843  2.2742677293115130e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_636  1
    load_0_14_18  free_load_conservation_813  1
    load_0_14_18  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_638  -30
    arc_0_15_0  depot_return_or_bypass_747  1
    arc_0_15_0  out_degree_814  1
    arc_0_15_0  original_T_including_depot_unload_843  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_638  1
    load_0_15_0  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_639  -30
    arc_0_15_1  connected_order_arc_640  -15
    arc_0_15_1  in_degree_749  1
    arc_0_15_1  out_degree_814  1
    arc_0_15_1  original_T_including_depot_unload_843  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_639  1
    load_0_15_1  segment_load_conservation_752  -1
    load_0_15_1  segment_prefix_lb_753  1
    load_0_15_1  segment_prefix_ub_754  1
    load_0_15_1  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_641  -30
    arc_0_15_2  connected_order_arc_642  -15
    arc_0_15_2  in_degree_756  1
    arc_0_15_2  out_degree_814  1
    arc_0_15_2  original_T_including_depot_unload_843  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_641  1
    load_0_15_2  segment_load_conservation_759  -1
    load_0_15_2  segment_prefix_lb_760  1
    load_0_15_2  segment_prefix_ub_761  1
    load_0_15_2  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_643  -30
    arc_0_15_3  connected_order_arc_644  -15
    arc_0_15_3  in_degree_763  1
    arc_0_15_3  out_degree_814  1
    arc_0_15_3  original_T_including_depot_unload_843  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_643  1
    load_0_15_3  segment_load_conservation_766  -1
    load_0_15_3  segment_prefix_lb_767  1
    load_0_15_3  segment_prefix_ub_768  1
    load_0_15_3  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_645  -30
    arc_0_15_4  connected_order_arc_646  -15
    arc_0_15_4  in_degree_770  1
    arc_0_15_4  out_degree_814  1
    arc_0_15_4  original_T_including_depot_unload_843  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_645  1
    load_0_15_4  segment_load_conservation_773  -1
    load_0_15_4  segment_prefix_lb_774  1
    load_0_15_4  segment_prefix_ub_775  1
    load_0_15_4  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_647  -30
    arc_0_15_5  connected_order_arc_648  -15
    arc_0_15_5  in_degree_777  1
    arc_0_15_5  out_degree_814  1
    arc_0_15_5  original_T_including_depot_unload_843  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_647  1
    load_0_15_5  segment_load_conservation_780  -1
    load_0_15_5  segment_prefix_lb_781  1
    load_0_15_5  segment_prefix_ub_782  1
    load_0_15_5  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_649  -30
    arc_0_15_6  connected_order_arc_650  -15
    arc_0_15_6  in_degree_784  1
    arc_0_15_6  out_degree_814  1
    arc_0_15_6  original_T_including_depot_unload_843  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_649  1
    load_0_15_6  segment_load_conservation_787  -1
    load_0_15_6  segment_prefix_lb_788  1
    load_0_15_6  segment_prefix_ub_789  1
    load_0_15_6  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_11  arc_capacity_651  -30
    arc_0_15_11  connected_order_arc_652  -15
    arc_0_15_11  in_degree_791  1
    arc_0_15_11  out_degree_814  1
    arc_0_15_11  original_T_including_depot_unload_843  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_11  arc_capacity_651  1
    load_0_15_11  free_load_conservation_795  -1
    load_0_15_11  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_653  -30
    arc_0_15_12  connected_order_arc_654  -15
    arc_0_15_12  in_degree_797  1
    arc_0_15_12  out_degree_814  1
    arc_0_15_12  original_T_including_depot_unload_843  2.6300071929095179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_653  1
    load_0_15_12  free_load_conservation_801  -1
    load_0_15_12  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_655  -30
    arc_0_15_13  connected_order_arc_656  -15
    arc_0_15_13  in_degree_803  1
    arc_0_15_13  out_degree_814  1
    arc_0_15_13  original_T_including_depot_unload_843  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_655  1
    load_0_15_13  free_load_conservation_807  -1
    load_0_15_13  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_657  -30
    arc_0_15_14  connected_order_arc_658  -15
    arc_0_15_14  in_degree_809  1
    arc_0_15_14  out_degree_814  1
    arc_0_15_14  original_T_including_depot_unload_843  2.3631048359201741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_657  1
    load_0_15_14  free_load_conservation_813  -1
    load_0_15_14  free_load_conservation_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_659  -30
    arc_0_15_16  connected_order_arc_660  -15
    arc_0_15_16  out_degree_814  1
    arc_0_15_16  in_degree_821  1
    arc_0_15_16  original_T_including_depot_unload_843  2.8559472795328161e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_659  1
    load_0_15_16  free_load_conservation_819  1
    load_0_15_16  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_661  -30
    arc_0_15_17  connected_order_arc_662  -15
    arc_0_15_17  out_degree_814  1
    arc_0_15_17  in_degree_827  1
    arc_0_15_17  original_T_including_depot_unload_843  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_661  1
    load_0_15_17  free_load_conservation_819  1
    load_0_15_17  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_663  -30
    arc_0_15_18  connected_order_arc_664  -15
    arc_0_15_18  out_degree_814  1
    arc_0_15_18  in_degree_833  1
    arc_0_15_18  original_T_including_depot_unload_843  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_663  1
    load_0_15_18  free_load_conservation_819  1
    load_0_15_18  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_665  -30
    arc_0_16_0  depot_return_or_bypass_747  1
    arc_0_16_0  out_degree_820  1
    arc_0_16_0  original_T_including_depot_unload_843  2.4985877836350596e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_665  1
    load_0_16_0  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_666  -30
    arc_0_16_1  connected_order_arc_667  -15
    arc_0_16_1  in_degree_749  1
    arc_0_16_1  out_degree_820  1
    arc_0_16_1  original_T_including_depot_unload_843  2.9992588346691123e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_666  1
    load_0_16_1  segment_load_conservation_752  -1
    load_0_16_1  segment_prefix_lb_753  1
    load_0_16_1  segment_prefix_ub_754  1
    load_0_16_1  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_668  -30
    arc_0_16_2  connected_order_arc_669  -15
    arc_0_16_2  in_degree_756  1
    arc_0_16_2  out_degree_820  1
    arc_0_16_2  original_T_including_depot_unload_843  3.0706942101225172e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_668  1
    load_0_16_2  segment_load_conservation_759  -1
    load_0_16_2  segment_prefix_lb_760  1
    load_0_16_2  segment_prefix_ub_761  1
    load_0_16_2  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_670  -30
    arc_0_16_3  connected_order_arc_671  -15
    arc_0_16_3  in_degree_763  1
    arc_0_16_3  out_degree_820  1
    arc_0_16_3  original_T_including_depot_unload_843  3.4153410343469327e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_670  1
    load_0_16_3  segment_load_conservation_766  -1
    load_0_16_3  segment_prefix_lb_767  1
    load_0_16_3  segment_prefix_ub_768  1
    load_0_16_3  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_672  -30
    arc_0_16_4  connected_order_arc_673  -15
    arc_0_16_4  in_degree_770  1
    arc_0_16_4  out_degree_820  1
    arc_0_16_4  original_T_including_depot_unload_843  3.1940365421146048e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_672  1
    load_0_16_4  segment_load_conservation_773  -1
    load_0_16_4  segment_prefix_lb_774  1
    load_0_16_4  segment_prefix_ub_775  1
    load_0_16_4  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_674  -30
    arc_0_16_5  connected_order_arc_675  -15
    arc_0_16_5  in_degree_777  1
    arc_0_16_5  out_degree_820  1
    arc_0_16_5  original_T_including_depot_unload_843  3.0078695794061259e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_674  1
    load_0_16_5  segment_load_conservation_780  -1
    load_0_16_5  segment_prefix_lb_781  1
    load_0_16_5  segment_prefix_ub_782  1
    load_0_16_5  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_676  -30
    arc_0_16_6  connected_order_arc_677  -15
    arc_0_16_6  in_degree_784  1
    arc_0_16_6  out_degree_820  1
    arc_0_16_6  original_T_including_depot_unload_843  2.9299952981117208e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_676  1
    load_0_16_6  segment_load_conservation_787  -1
    load_0_16_6  segment_prefix_lb_788  1
    load_0_16_6  segment_prefix_ub_789  1
    load_0_16_6  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_11  arc_capacity_678  -30
    arc_0_16_11  connected_order_arc_679  -15
    arc_0_16_11  in_degree_791  1
    arc_0_16_11  out_degree_820  1
    arc_0_16_11  original_T_including_depot_unload_843  2.8958539392642757e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_11  arc_capacity_678  1
    load_0_16_11  free_load_conservation_795  -1
    load_0_16_11  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_680  -30
    arc_0_16_12  connected_order_arc_681  -15
    arc_0_16_12  in_degree_797  1
    arc_0_16_12  out_degree_820  1
    arc_0_16_12  original_T_including_depot_unload_843  2.4254234166891203e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_680  1
    load_0_16_12  free_load_conservation_801  -1
    load_0_16_12  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_682  -30
    arc_0_16_13  connected_order_arc_683  -15
    arc_0_16_13  in_degree_803  1
    arc_0_16_13  out_degree_820  1
    arc_0_16_13  original_T_including_depot_unload_843  4.4205864351455948e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_682  1
    load_0_16_13  free_load_conservation_807  -1
    load_0_16_13  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_684  -30
    arc_0_16_14  connected_order_arc_685  -15
    arc_0_16_14  in_degree_809  1
    arc_0_16_14  out_degree_820  1
    arc_0_16_14  original_T_including_depot_unload_843  4.9538322318613183e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_684  1
    load_0_16_14  free_load_conservation_813  -1
    load_0_16_14  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_686  -30
    arc_0_16_15  connected_order_arc_687  -15
    arc_0_16_15  in_degree_815  1
    arc_0_16_15  out_degree_820  1
    arc_0_16_15  original_T_including_depot_unload_843  2.8559472795328161e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_686  1
    load_0_16_15  free_load_conservation_819  -1
    load_0_16_15  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_688  -30
    arc_0_16_17  connected_order_arc_689  -15
    arc_0_16_17  out_degree_820  1
    arc_0_16_17  in_degree_827  1
    arc_0_16_17  original_T_including_depot_unload_843  2.8270830664529126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_688  1
    load_0_16_17  free_load_conservation_825  1
    load_0_16_17  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_690  -30
    arc_0_16_18  connected_order_arc_691  -15
    arc_0_16_18  out_degree_820  1
    arc_0_16_18  in_degree_833  1
    arc_0_16_18  original_T_including_depot_unload_843  2.6215712372467274e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_690  1
    load_0_16_18  free_load_conservation_825  1
    load_0_16_18  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_692  -30
    arc_0_17_0  depot_return_or_bypass_747  1
    arc_0_17_0  out_degree_826  1
    arc_0_17_0  original_T_including_depot_unload_843  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_692  1
    load_0_17_0  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_693  -30
    arc_0_17_1  connected_order_arc_694  -15
    arc_0_17_1  in_degree_749  1
    arc_0_17_1  out_degree_826  1
    arc_0_17_1  original_T_including_depot_unload_843  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_693  1
    load_0_17_1  segment_load_conservation_752  -1
    load_0_17_1  segment_prefix_lb_753  1
    load_0_17_1  segment_prefix_ub_754  1
    load_0_17_1  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_695  -30
    arc_0_17_2  connected_order_arc_696  -15
    arc_0_17_2  in_degree_756  1
    arc_0_17_2  out_degree_826  1
    arc_0_17_2  original_T_including_depot_unload_843  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_695  1
    load_0_17_2  segment_load_conservation_759  -1
    load_0_17_2  segment_prefix_lb_760  1
    load_0_17_2  segment_prefix_ub_761  1
    load_0_17_2  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_697  -30
    arc_0_17_3  connected_order_arc_698  -15
    arc_0_17_3  in_degree_763  1
    arc_0_17_3  out_degree_826  1
    arc_0_17_3  original_T_including_depot_unload_843  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_697  1
    load_0_17_3  segment_load_conservation_766  -1
    load_0_17_3  segment_prefix_lb_767  1
    load_0_17_3  segment_prefix_ub_768  1
    load_0_17_3  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_699  -30
    arc_0_17_4  connected_order_arc_700  -15
    arc_0_17_4  in_degree_770  1
    arc_0_17_4  out_degree_826  1
    arc_0_17_4  original_T_including_depot_unload_843  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_699  1
    load_0_17_4  segment_load_conservation_773  -1
    load_0_17_4  segment_prefix_lb_774  1
    load_0_17_4  segment_prefix_ub_775  1
    load_0_17_4  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_701  -30
    arc_0_17_5  connected_order_arc_702  -15
    arc_0_17_5  in_degree_777  1
    arc_0_17_5  out_degree_826  1
    arc_0_17_5  original_T_including_depot_unload_843  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_701  1
    load_0_17_5  segment_load_conservation_780  -1
    load_0_17_5  segment_prefix_lb_781  1
    load_0_17_5  segment_prefix_ub_782  1
    load_0_17_5  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_6  arc_capacity_703  -30
    arc_0_17_6  connected_order_arc_704  -15
    arc_0_17_6  in_degree_784  1
    arc_0_17_6  out_degree_826  1
    arc_0_17_6  original_T_including_depot_unload_843  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_6  arc_capacity_703  1
    load_0_17_6  segment_load_conservation_787  -1
    load_0_17_6  segment_prefix_lb_788  1
    load_0_17_6  segment_prefix_ub_789  1
    load_0_17_6  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_11  arc_capacity_705  -30
    arc_0_17_11  connected_order_arc_706  -15
    arc_0_17_11  in_degree_791  1
    arc_0_17_11  out_degree_826  1
    arc_0_17_11  original_T_including_depot_unload_843  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_11  arc_capacity_705  1
    load_0_17_11  free_load_conservation_795  -1
    load_0_17_11  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_12  arc_capacity_707  -30
    arc_0_17_12  connected_order_arc_708  -15
    arc_0_17_12  in_degree_797  1
    arc_0_17_12  out_degree_826  1
    arc_0_17_12  original_T_including_depot_unload_843  2.6166334544495612e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_12  arc_capacity_707  1
    load_0_17_12  free_load_conservation_801  -1
    load_0_17_12  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_709  -30
    arc_0_17_13  connected_order_arc_710  -15
    arc_0_17_13  in_degree_803  1
    arc_0_17_13  out_degree_826  1
    arc_0_17_13  original_T_including_depot_unload_843  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_709  1
    load_0_17_13  free_load_conservation_807  -1
    load_0_17_13  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_711  -30
    arc_0_17_14  connected_order_arc_712  -15
    arc_0_17_14  in_degree_809  1
    arc_0_17_14  out_degree_826  1
    arc_0_17_14  original_T_including_depot_unload_843  2.5694031842490126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_711  1
    load_0_17_14  free_load_conservation_813  -1
    load_0_17_14  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_713  -30
    arc_0_17_15  connected_order_arc_714  -15
    arc_0_17_15  in_degree_815  1
    arc_0_17_15  out_degree_826  1
    arc_0_17_15  original_T_including_depot_unload_843  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_713  1
    load_0_17_15  free_load_conservation_819  -1
    load_0_17_15  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_715  -30
    arc_0_17_16  connected_order_arc_716  -15
    arc_0_17_16  in_degree_821  1
    arc_0_17_16  out_degree_826  1
    arc_0_17_16  original_T_including_depot_unload_843  2.8270830664529126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_715  1
    load_0_17_16  free_load_conservation_825  -1
    load_0_17_16  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_717  -30
    arc_0_17_18  connected_order_arc_718  -15
    arc_0_17_18  out_degree_826  1
    arc_0_17_18  in_degree_833  1
    arc_0_17_18  original_T_including_depot_unload_843  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_717  1
    load_0_17_18  free_load_conservation_831  1
    load_0_17_18  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_719  -30
    arc_0_18_0  depot_return_or_bypass_747  1
    arc_0_18_0  out_degree_832  1
    arc_0_18_0  original_T_including_depot_unload_843  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_719  1
    load_0_18_0  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_720  -30
    arc_0_18_1  connected_order_arc_721  -15
    arc_0_18_1  in_degree_749  1
    arc_0_18_1  out_degree_832  1
    arc_0_18_1  original_T_including_depot_unload_843  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_720  1
    load_0_18_1  segment_load_conservation_752  -1
    load_0_18_1  segment_prefix_lb_753  1
    load_0_18_1  segment_prefix_ub_754  1
    load_0_18_1  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_722  -30
    arc_0_18_2  connected_order_arc_723  -15
    arc_0_18_2  in_degree_756  1
    arc_0_18_2  out_degree_832  1
    arc_0_18_2  original_T_including_depot_unload_843  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_722  1
    load_0_18_2  segment_load_conservation_759  -1
    load_0_18_2  segment_prefix_lb_760  1
    load_0_18_2  segment_prefix_ub_761  1
    load_0_18_2  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_724  -30
    arc_0_18_3  connected_order_arc_725  -15
    arc_0_18_3  in_degree_763  1
    arc_0_18_3  out_degree_832  1
    arc_0_18_3  original_T_including_depot_unload_843  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_724  1
    load_0_18_3  segment_load_conservation_766  -1
    load_0_18_3  segment_prefix_lb_767  1
    load_0_18_3  segment_prefix_ub_768  1
    load_0_18_3  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_726  -30
    arc_0_18_4  connected_order_arc_727  -15
    arc_0_18_4  in_degree_770  1
    arc_0_18_4  out_degree_832  1
    arc_0_18_4  original_T_including_depot_unload_843  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_726  1
    load_0_18_4  segment_load_conservation_773  -1
    load_0_18_4  segment_prefix_lb_774  1
    load_0_18_4  segment_prefix_ub_775  1
    load_0_18_4  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_728  -30
    arc_0_18_5  connected_order_arc_729  -15
    arc_0_18_5  in_degree_777  1
    arc_0_18_5  out_degree_832  1
    arc_0_18_5  original_T_including_depot_unload_843  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_728  1
    load_0_18_5  segment_load_conservation_780  -1
    load_0_18_5  segment_prefix_lb_781  1
    load_0_18_5  segment_prefix_ub_782  1
    load_0_18_5  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_6  arc_capacity_730  -30
    arc_0_18_6  connected_order_arc_731  -15
    arc_0_18_6  in_degree_784  1
    arc_0_18_6  out_degree_832  1
    arc_0_18_6  original_T_including_depot_unload_843  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_6  arc_capacity_730  1
    load_0_18_6  segment_load_conservation_787  -1
    load_0_18_6  segment_prefix_lb_788  1
    load_0_18_6  segment_prefix_ub_789  1
    load_0_18_6  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_11  arc_capacity_732  -30
    arc_0_18_11  connected_order_arc_733  -15
    arc_0_18_11  in_degree_791  1
    arc_0_18_11  out_degree_832  1
    arc_0_18_11  original_T_including_depot_unload_843  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_11  arc_capacity_732  1
    load_0_18_11  free_load_conservation_795  -1
    load_0_18_11  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_12  arc_capacity_734  -30
    arc_0_18_12  connected_order_arc_735  -15
    arc_0_18_12  in_degree_797  1
    arc_0_18_12  out_degree_832  1
    arc_0_18_12  original_T_including_depot_unload_843  2389.0890755213
    MARKER    'MARKER'                 'INTEND'
    load_0_18_12  arc_capacity_734  1
    load_0_18_12  free_load_conservation_801  -1
    load_0_18_12  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_736  -30
    arc_0_18_13  connected_order_arc_737  -15
    arc_0_18_13  in_degree_803  1
    arc_0_18_13  out_degree_832  1
    arc_0_18_13  original_T_including_depot_unload_843  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_736  1
    load_0_18_13  free_load_conservation_807  -1
    load_0_18_13  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_738  -30
    arc_0_18_14  connected_order_arc_739  -15
    arc_0_18_14  in_degree_809  1
    arc_0_18_14  out_degree_832  1
    arc_0_18_14  original_T_including_depot_unload_843  2.2742677293115130e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_738  1
    load_0_18_14  free_load_conservation_813  -1
    load_0_18_14  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_740  -30
    arc_0_18_15  connected_order_arc_741  -15
    arc_0_18_15  in_degree_815  1
    arc_0_18_15  out_degree_832  1
    arc_0_18_15  original_T_including_depot_unload_843  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_740  1
    load_0_18_15  free_load_conservation_819  -1
    load_0_18_15  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_742  -30
    arc_0_18_16  connected_order_arc_743  -15
    arc_0_18_16  in_degree_821  1
    arc_0_18_16  out_degree_832  1
    arc_0_18_16  original_T_including_depot_unload_843  2.6215712372467274e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_742  1
    load_0_18_16  free_load_conservation_825  -1
    load_0_18_16  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_744  -30
    arc_0_18_17  connected_order_arc_745  -15
    arc_0_18_17  in_degree_827  1
    arc_0_18_17  out_degree_832  1
    arc_0_18_17  original_T_including_depot_unload_843  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_744  1
    load_0_18_17  free_load_conservation_831  -1
    load_0_18_17  free_load_conservation_837  1
    visit_1_7  out_degree_1135  -1
    visit_1_7  in_degree_1136  -1
    visit_1_7  order_active_lb_1137  -1
    visit_1_7  order_active_ub_1138  -12
    order_1_7  connected_order_arc_859  -1
    order_1_7  connected_order_arc_861  -1
    order_1_7  connected_order_arc_863  -1
    order_1_7  connected_order_arc_865  -1
    order_1_7  connected_order_arc_867  -1
    order_1_7  connected_order_arc_869  -1
    order_1_7  connected_order_arc_871  -1
    order_1_7  connected_order_arc_873  -1
    order_1_7  connected_order_arc_875  -1
    order_1_7  connected_order_arc_877  -1
    order_1_7  connected_order_arc_879  -1
    order_1_7  connected_order_arc_882  1
    order_1_7  connected_order_arc_905  1
    order_1_7  connected_order_arc_928  1
    order_1_7  connected_order_arc_951  1
    order_1_7  connected_order_arc_974  1
    order_1_7  connected_order_arc_997  1
    order_1_7  connected_order_arc_1020  1
    order_1_7  connected_order_arc_1043  1
    order_1_7  connected_order_arc_1066  1
    order_1_7  connected_order_arc_1089  1
    order_1_7  connected_order_arc_1112  1
    order_1_7  order_active_lb_1137  1
    order_1_7  order_active_ub_1138  1
    order_1_7  fixed_segment_relative_order_1211  -1
    visit_1_8  out_degree_1142  -1
    visit_1_8  in_degree_1143  -1
    visit_1_8  order_active_lb_1144  -1
    visit_1_8  order_active_ub_1145  -12
    order_1_8  connected_order_arc_859  1
    order_1_8  connected_order_arc_882  -1
    order_1_8  connected_order_arc_884  -1
    order_1_8  connected_order_arc_886  -1
    order_1_8  connected_order_arc_888  -1
    order_1_8  connected_order_arc_890  -1
    order_1_8  connected_order_arc_892  -1
    order_1_8  connected_order_arc_894  -1
    order_1_8  connected_order_arc_896  -1
    order_1_8  connected_order_arc_898  -1
    order_1_8  connected_order_arc_900  -1
    order_1_8  connected_order_arc_902  -1
    order_1_8  connected_order_arc_907  1
    order_1_8  connected_order_arc_930  1
    order_1_8  connected_order_arc_953  1
    order_1_8  connected_order_arc_976  1
    order_1_8  connected_order_arc_999  1
    order_1_8  connected_order_arc_1022  1
    order_1_8  connected_order_arc_1045  1
    order_1_8  connected_order_arc_1068  1
    order_1_8  connected_order_arc_1091  1
    order_1_8  connected_order_arc_1114  1
    order_1_8  order_active_lb_1144  1
    order_1_8  order_active_ub_1145  1
    order_1_8  fixed_segment_relative_order_1211  1
    order_1_8  fixed_segment_relative_order_1212  -1
    visit_1_9  out_degree_1149  -1
    visit_1_9  in_degree_1150  -1
    visit_1_9  order_active_lb_1151  -1
    visit_1_9  order_active_ub_1152  -12
    order_1_9  connected_order_arc_861  1
    order_1_9  connected_order_arc_884  1
    order_1_9  connected_order_arc_905  -1
    order_1_9  connected_order_arc_907  -1
    order_1_9  connected_order_arc_909  -1
    order_1_9  connected_order_arc_911  -1
    order_1_9  connected_order_arc_913  -1
    order_1_9  connected_order_arc_915  -1
    order_1_9  connected_order_arc_917  -1
    order_1_9  connected_order_arc_919  -1
    order_1_9  connected_order_arc_921  -1
    order_1_9  connected_order_arc_923  -1
    order_1_9  connected_order_arc_925  -1
    order_1_9  connected_order_arc_932  1
    order_1_9  connected_order_arc_955  1
    order_1_9  connected_order_arc_978  1
    order_1_9  connected_order_arc_1001  1
    order_1_9  connected_order_arc_1024  1
    order_1_9  connected_order_arc_1047  1
    order_1_9  connected_order_arc_1070  1
    order_1_9  connected_order_arc_1093  1
    order_1_9  connected_order_arc_1116  1
    order_1_9  order_active_lb_1151  1
    order_1_9  order_active_ub_1152  1
    order_1_9  fixed_segment_relative_order_1212  1
    order_1_9  fixed_segment_relative_order_1213  -1
    visit_1_10  out_degree_1156  -1
    visit_1_10  in_degree_1157  -1
    visit_1_10  order_active_lb_1158  -1
    visit_1_10  order_active_ub_1159  -12
    order_1_10  connected_order_arc_863  1
    order_1_10  connected_order_arc_886  1
    order_1_10  connected_order_arc_909  1
    order_1_10  connected_order_arc_928  -1
    order_1_10  connected_order_arc_930  -1
    order_1_10  connected_order_arc_932  -1
    order_1_10  connected_order_arc_934  -1
    order_1_10  connected_order_arc_936  -1
    order_1_10  connected_order_arc_938  -1
    order_1_10  connected_order_arc_940  -1
    order_1_10  connected_order_arc_942  -1
    order_1_10  connected_order_arc_944  -1
    order_1_10  connected_order_arc_946  -1
    order_1_10  connected_order_arc_948  -1
    order_1_10  connected_order_arc_957  1
    order_1_10  connected_order_arc_980  1
    order_1_10  connected_order_arc_1003  1
    order_1_10  connected_order_arc_1026  1
    order_1_10  connected_order_arc_1049  1
    order_1_10  connected_order_arc_1072  1
    order_1_10  connected_order_arc_1095  1
    order_1_10  connected_order_arc_1118  1
    order_1_10  order_active_lb_1158  1
    order_1_10  order_active_ub_1159  1
    order_1_10  fixed_segment_relative_order_1213  1
    visit_1_11  out_degree_1163  -1
    visit_1_11  in_degree_1164  -1
    visit_1_11  order_active_lb_1165  -1
    visit_1_11  order_active_ub_1166  -12
    visit_1_11  service_visit_def_1167  -1
    order_1_11  connected_order_arc_865  1
    order_1_11  connected_order_arc_888  1
    order_1_11  connected_order_arc_911  1
    order_1_11  connected_order_arc_934  1
    order_1_11  connected_order_arc_951  -1
    order_1_11  connected_order_arc_953  -1
    order_1_11  connected_order_arc_955  -1
    order_1_11  connected_order_arc_957  -1
    order_1_11  connected_order_arc_959  -1
    order_1_11  connected_order_arc_961  -1
    order_1_11  connected_order_arc_963  -1
    order_1_11  connected_order_arc_965  -1
    order_1_11  connected_order_arc_967  -1
    order_1_11  connected_order_arc_969  -1
    order_1_11  connected_order_arc_971  -1
    order_1_11  connected_order_arc_982  1
    order_1_11  connected_order_arc_1005  1
    order_1_11  connected_order_arc_1028  1
    order_1_11  connected_order_arc_1051  1
    order_1_11  connected_order_arc_1074  1
    order_1_11  connected_order_arc_1097  1
    order_1_11  connected_order_arc_1120  1
    order_1_11  order_active_lb_1165  1
    order_1_11  order_active_ub_1166  1
    visit_1_12  out_degree_1169  -1
    visit_1_12  in_degree_1170  -1
    visit_1_12  order_active_lb_1171  -1
    visit_1_12  order_active_ub_1172  -12
    visit_1_12  service_visit_def_1173  -1
    order_1_12  connected_order_arc_867  1
    order_1_12  connected_order_arc_890  1
    order_1_12  connected_order_arc_913  1
    order_1_12  connected_order_arc_936  1
    order_1_12  connected_order_arc_959  1
    order_1_12  connected_order_arc_974  -1
    order_1_12  connected_order_arc_976  -1
    order_1_12  connected_order_arc_978  -1
    order_1_12  connected_order_arc_980  -1
    order_1_12  connected_order_arc_982  -1
    order_1_12  connected_order_arc_984  -1
    order_1_12  connected_order_arc_986  -1
    order_1_12  connected_order_arc_988  -1
    order_1_12  connected_order_arc_990  -1
    order_1_12  connected_order_arc_992  -1
    order_1_12  connected_order_arc_994  -1
    order_1_12  connected_order_arc_1007  1
    order_1_12  connected_order_arc_1030  1
    order_1_12  connected_order_arc_1053  1
    order_1_12  connected_order_arc_1076  1
    order_1_12  connected_order_arc_1099  1
    order_1_12  connected_order_arc_1122  1
    order_1_12  order_active_lb_1171  1
    order_1_12  order_active_ub_1172  1
    visit_1_13  out_degree_1175  -1
    visit_1_13  in_degree_1176  -1
    visit_1_13  order_active_lb_1177  -1
    visit_1_13  order_active_ub_1178  -12
    visit_1_13  service_visit_def_1179  -1
    order_1_13  connected_order_arc_869  1
    order_1_13  connected_order_arc_892  1
    order_1_13  connected_order_arc_915  1
    order_1_13  connected_order_arc_938  1
    order_1_13  connected_order_arc_961  1
    order_1_13  connected_order_arc_984  1
    order_1_13  connected_order_arc_997  -1
    order_1_13  connected_order_arc_999  -1
    order_1_13  connected_order_arc_1001  -1
    order_1_13  connected_order_arc_1003  -1
    order_1_13  connected_order_arc_1005  -1
    order_1_13  connected_order_arc_1007  -1
    order_1_13  connected_order_arc_1009  -1
    order_1_13  connected_order_arc_1011  -1
    order_1_13  connected_order_arc_1013  -1
    order_1_13  connected_order_arc_1015  -1
    order_1_13  connected_order_arc_1017  -1
    order_1_13  connected_order_arc_1032  1
    order_1_13  connected_order_arc_1055  1
    order_1_13  connected_order_arc_1078  1
    order_1_13  connected_order_arc_1101  1
    order_1_13  connected_order_arc_1124  1
    order_1_13  order_active_lb_1177  1
    order_1_13  order_active_ub_1178  1
    visit_1_14  out_degree_1181  -1
    visit_1_14  in_degree_1182  -1
    visit_1_14  order_active_lb_1183  -1
    visit_1_14  order_active_ub_1184  -12
    visit_1_14  service_visit_def_1185  -1
    order_1_14  connected_order_arc_871  1
    order_1_14  connected_order_arc_894  1
    order_1_14  connected_order_arc_917  1
    order_1_14  connected_order_arc_940  1
    order_1_14  connected_order_arc_963  1
    order_1_14  connected_order_arc_986  1
    order_1_14  connected_order_arc_1009  1
    order_1_14  connected_order_arc_1020  -1
    order_1_14  connected_order_arc_1022  -1
    order_1_14  connected_order_arc_1024  -1
    order_1_14  connected_order_arc_1026  -1
    order_1_14  connected_order_arc_1028  -1
    order_1_14  connected_order_arc_1030  -1
    order_1_14  connected_order_arc_1032  -1
    order_1_14  connected_order_arc_1034  -1
    order_1_14  connected_order_arc_1036  -1
    order_1_14  connected_order_arc_1038  -1
    order_1_14  connected_order_arc_1040  -1
    order_1_14  connected_order_arc_1057  1
    order_1_14  connected_order_arc_1080  1
    order_1_14  connected_order_arc_1103  1
    order_1_14  connected_order_arc_1126  1
    order_1_14  order_active_lb_1183  1
    order_1_14  order_active_ub_1184  1
    visit_1_15  out_degree_1187  -1
    visit_1_15  in_degree_1188  -1
    visit_1_15  order_active_lb_1189  -1
    visit_1_15  order_active_ub_1190  -12
    visit_1_15  service_visit_def_1191  -1
    order_1_15  connected_order_arc_873  1
    order_1_15  connected_order_arc_896  1
    order_1_15  connected_order_arc_919  1
    order_1_15  connected_order_arc_942  1
    order_1_15  connected_order_arc_965  1
    order_1_15  connected_order_arc_988  1
    order_1_15  connected_order_arc_1011  1
    order_1_15  connected_order_arc_1034  1
    order_1_15  connected_order_arc_1043  -1
    order_1_15  connected_order_arc_1045  -1
    order_1_15  connected_order_arc_1047  -1
    order_1_15  connected_order_arc_1049  -1
    order_1_15  connected_order_arc_1051  -1
    order_1_15  connected_order_arc_1053  -1
    order_1_15  connected_order_arc_1055  -1
    order_1_15  connected_order_arc_1057  -1
    order_1_15  connected_order_arc_1059  -1
    order_1_15  connected_order_arc_1061  -1
    order_1_15  connected_order_arc_1063  -1
    order_1_15  connected_order_arc_1082  1
    order_1_15  connected_order_arc_1105  1
    order_1_15  connected_order_arc_1128  1
    order_1_15  order_active_lb_1189  1
    order_1_15  order_active_ub_1190  1
    visit_1_16  out_degree_1193  -1
    visit_1_16  in_degree_1194  -1
    visit_1_16  order_active_lb_1195  -1
    visit_1_16  order_active_ub_1196  -12
    visit_1_16  service_visit_def_1197  -1
    order_1_16  connected_order_arc_875  1
    order_1_16  connected_order_arc_898  1
    order_1_16  connected_order_arc_921  1
    order_1_16  connected_order_arc_944  1
    order_1_16  connected_order_arc_967  1
    order_1_16  connected_order_arc_990  1
    order_1_16  connected_order_arc_1013  1
    order_1_16  connected_order_arc_1036  1
    order_1_16  connected_order_arc_1059  1
    order_1_16  connected_order_arc_1066  -1
    order_1_16  connected_order_arc_1068  -1
    order_1_16  connected_order_arc_1070  -1
    order_1_16  connected_order_arc_1072  -1
    order_1_16  connected_order_arc_1074  -1
    order_1_16  connected_order_arc_1076  -1
    order_1_16  connected_order_arc_1078  -1
    order_1_16  connected_order_arc_1080  -1
    order_1_16  connected_order_arc_1082  -1
    order_1_16  connected_order_arc_1084  -1
    order_1_16  connected_order_arc_1086  -1
    order_1_16  connected_order_arc_1107  1
    order_1_16  connected_order_arc_1130  1
    order_1_16  order_active_lb_1195  1
    order_1_16  order_active_ub_1196  1
    visit_1_17  out_degree_1199  -1
    visit_1_17  in_degree_1200  -1
    visit_1_17  order_active_lb_1201  -1
    visit_1_17  order_active_ub_1202  -12
    visit_1_17  service_visit_def_1203  -1
    order_1_17  connected_order_arc_877  1
    order_1_17  connected_order_arc_900  1
    order_1_17  connected_order_arc_923  1
    order_1_17  connected_order_arc_946  1
    order_1_17  connected_order_arc_969  1
    order_1_17  connected_order_arc_992  1
    order_1_17  connected_order_arc_1015  1
    order_1_17  connected_order_arc_1038  1
    order_1_17  connected_order_arc_1061  1
    order_1_17  connected_order_arc_1084  1
    order_1_17  connected_order_arc_1089  -1
    order_1_17  connected_order_arc_1091  -1
    order_1_17  connected_order_arc_1093  -1
    order_1_17  connected_order_arc_1095  -1
    order_1_17  connected_order_arc_1097  -1
    order_1_17  connected_order_arc_1099  -1
    order_1_17  connected_order_arc_1101  -1
    order_1_17  connected_order_arc_1103  -1
    order_1_17  connected_order_arc_1105  -1
    order_1_17  connected_order_arc_1107  -1
    order_1_17  connected_order_arc_1109  -1
    order_1_17  connected_order_arc_1132  1
    order_1_17  order_active_lb_1201  1
    order_1_17  order_active_ub_1202  1
    visit_1_18  out_degree_1205  -1
    visit_1_18  in_degree_1206  -1
    visit_1_18  order_active_lb_1207  -1
    visit_1_18  order_active_ub_1208  -12
    visit_1_18  service_visit_def_1209  -1
    order_1_18  connected_order_arc_879  1
    order_1_18  connected_order_arc_902  1
    order_1_18  connected_order_arc_925  1
    order_1_18  connected_order_arc_948  1
    order_1_18  connected_order_arc_971  1
    order_1_18  connected_order_arc_994  1
    order_1_18  connected_order_arc_1017  1
    order_1_18  connected_order_arc_1040  1
    order_1_18  connected_order_arc_1063  1
    order_1_18  connected_order_arc_1086  1
    order_1_18  connected_order_arc_1109  1
    order_1_18  connected_order_arc_1112  -1
    order_1_18  connected_order_arc_1114  -1
    order_1_18  connected_order_arc_1116  -1
    order_1_18  connected_order_arc_1118  -1
    order_1_18  connected_order_arc_1120  -1
    order_1_18  connected_order_arc_1122  -1
    order_1_18  connected_order_arc_1124  -1
    order_1_18  connected_order_arc_1126  -1
    order_1_18  connected_order_arc_1128  -1
    order_1_18  connected_order_arc_1130  -1
    order_1_18  connected_order_arc_1132  -1
    order_1_18  order_active_lb_1207  1
    order_1_18  order_active_ub_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_844  -30
    arc_1_0_0  depot_departure_or_bypass_1133  1
    arc_1_0_0  depot_return_or_bypass_1134  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_844  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_845  -30
    arc_1_0_7  depot_departure_or_bypass_1133  1
    arc_1_0_7  in_degree_1136  1
    arc_1_0_7  original_T_including_depot_unload_1214  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_845  1
    load_1_0_7  segment_load_conservation_1139  -1
    load_1_0_7  segment_prefix_lb_1140  1
    load_1_0_7  segment_prefix_ub_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_846  -30
    arc_1_0_8  depot_departure_or_bypass_1133  1
    arc_1_0_8  in_degree_1143  1
    arc_1_0_8  original_T_including_depot_unload_1214  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_846  1
    load_1_0_8  segment_load_conservation_1146  -1
    load_1_0_8  segment_prefix_lb_1147  1
    load_1_0_8  segment_prefix_ub_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_847  -30
    arc_1_0_9  depot_departure_or_bypass_1133  1
    arc_1_0_9  in_degree_1150  1
    arc_1_0_9  original_T_including_depot_unload_1214  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_847  1
    load_1_0_9  segment_load_conservation_1153  -1
    load_1_0_9  segment_prefix_lb_1154  1
    load_1_0_9  segment_prefix_ub_1155  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_848  -30
    arc_1_0_10  depot_departure_or_bypass_1133  1
    arc_1_0_10  in_degree_1157  1
    arc_1_0_10  original_T_including_depot_unload_1214  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_848  1
    load_1_0_10  segment_load_conservation_1160  -1
    load_1_0_10  segment_prefix_lb_1161  1
    load_1_0_10  segment_prefix_ub_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_849  -30
    arc_1_0_11  depot_departure_or_bypass_1133  1
    arc_1_0_11  in_degree_1164  1
    arc_1_0_11  original_T_including_depot_unload_1214  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_849  1
    load_1_0_11  free_load_conservation_1168  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_850  -30
    arc_1_0_12  depot_departure_or_bypass_1133  1
    arc_1_0_12  in_degree_1170  1
    arc_1_0_12  original_T_including_depot_unload_1214  2.2779423489344404e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_850  1
    load_1_0_12  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_851  -30
    arc_1_0_13  depot_departure_or_bypass_1133  1
    arc_1_0_13  in_degree_1176  1
    arc_1_0_13  original_T_including_depot_unload_1214  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_851  1
    load_1_0_13  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_852  -30
    arc_1_0_14  depot_departure_or_bypass_1133  1
    arc_1_0_14  in_degree_1182  1
    arc_1_0_14  original_T_including_depot_unload_1214  2.2058800397347450e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_852  1
    load_1_0_14  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_853  -30
    arc_1_0_15  depot_departure_or_bypass_1133  1
    arc_1_0_15  in_degree_1188  1
    arc_1_0_15  original_T_including_depot_unload_1214  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_853  1
    load_1_0_15  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_854  -30
    arc_1_0_16  depot_departure_or_bypass_1133  1
    arc_1_0_16  in_degree_1194  1
    arc_1_0_16  original_T_including_depot_unload_1214  2.4985877836350596e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_854  1
    load_1_0_16  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_855  -30
    arc_1_0_17  depot_departure_or_bypass_1133  1
    arc_1_0_17  in_degree_1200  1
    arc_1_0_17  original_T_including_depot_unload_1214  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_855  1
    load_1_0_17  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_856  -30
    arc_1_0_18  depot_departure_or_bypass_1133  1
    arc_1_0_18  in_degree_1206  1
    arc_1_0_18  original_T_including_depot_unload_1214  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_856  1
    load_1_0_18  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_857  -30
    arc_1_7_0  depot_return_or_bypass_1134  1
    arc_1_7_0  out_degree_1135  1
    arc_1_7_0  original_T_including_depot_unload_1214  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_857  1
    load_1_7_0  segment_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_858  -30
    arc_1_7_8  connected_order_arc_859  -13
    arc_1_7_8  out_degree_1135  1
    arc_1_7_8  in_degree_1143  1
    arc_1_7_8  original_T_including_depot_unload_1214  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_858  1
    load_1_7_8  segment_load_conservation_1139  1
    load_1_7_8  segment_load_conservation_1146  -1
    load_1_7_8  segment_prefix_lb_1147  1
    load_1_7_8  segment_prefix_ub_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_860  -30
    arc_1_7_9  connected_order_arc_861  -13
    arc_1_7_9  out_degree_1135  1
    arc_1_7_9  in_degree_1150  1
    arc_1_7_9  original_T_including_depot_unload_1214  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_860  1
    load_1_7_9  segment_load_conservation_1139  1
    load_1_7_9  segment_load_conservation_1153  -1
    load_1_7_9  segment_prefix_lb_1154  1
    load_1_7_9  segment_prefix_ub_1155  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_862  -30
    arc_1_7_10  connected_order_arc_863  -13
    arc_1_7_10  out_degree_1135  1
    arc_1_7_10  in_degree_1157  1
    arc_1_7_10  original_T_including_depot_unload_1214  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_862  1
    load_1_7_10  segment_load_conservation_1139  1
    load_1_7_10  segment_load_conservation_1160  -1
    load_1_7_10  segment_prefix_lb_1161  1
    load_1_7_10  segment_prefix_ub_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_11  arc_capacity_864  -30
    arc_1_7_11  connected_order_arc_865  -13
    arc_1_7_11  out_degree_1135  1
    arc_1_7_11  in_degree_1164  1
    arc_1_7_11  original_T_including_depot_unload_1214  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_11  arc_capacity_864  1
    load_1_7_11  segment_load_conservation_1139  1
    load_1_7_11  free_load_conservation_1168  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_866  -30
    arc_1_7_12  connected_order_arc_867  -13
    arc_1_7_12  out_degree_1135  1
    arc_1_7_12  in_degree_1170  1
    arc_1_7_12  original_T_including_depot_unload_1214  3.8248940301741582e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_866  1
    load_1_7_12  segment_load_conservation_1139  1
    load_1_7_12  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_868  -30
    arc_1_7_13  connected_order_arc_869  -13
    arc_1_7_13  out_degree_1135  1
    arc_1_7_13  in_degree_1176  1
    arc_1_7_13  original_T_including_depot_unload_1214  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_868  1
    load_1_7_13  segment_load_conservation_1139  1
    load_1_7_13  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_870  -30
    arc_1_7_14  connected_order_arc_871  -13
    arc_1_7_14  out_degree_1135  1
    arc_1_7_14  in_degree_1182  1
    arc_1_7_14  original_T_including_depot_unload_1214  3.6590564985322576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_870  1
    load_1_7_14  segment_load_conservation_1139  1
    load_1_7_14  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_872  -30
    arc_1_7_15  connected_order_arc_873  -13
    arc_1_7_15  out_degree_1135  1
    arc_1_7_15  in_degree_1188  1
    arc_1_7_15  original_T_including_depot_unload_1214  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_872  1
    load_1_7_15  segment_load_conservation_1139  1
    load_1_7_15  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_874  -30
    arc_1_7_16  connected_order_arc_875  -13
    arc_1_7_16  out_degree_1135  1
    arc_1_7_16  in_degree_1194  1
    arc_1_7_16  original_T_including_depot_unload_1214  4.0654406432457854e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_874  1
    load_1_7_16  segment_load_conservation_1139  1
    load_1_7_16  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_876  -30
    arc_1_7_17  connected_order_arc_877  -13
    arc_1_7_17  out_degree_1135  1
    arc_1_7_17  in_degree_1200  1
    arc_1_7_17  original_T_including_depot_unload_1214  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_876  1
    load_1_7_17  segment_load_conservation_1139  1
    load_1_7_17  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_878  -30
    arc_1_7_18  connected_order_arc_879  -13
    arc_1_7_18  out_degree_1135  1
    arc_1_7_18  in_degree_1206  1
    arc_1_7_18  original_T_including_depot_unload_1214  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_878  1
    load_1_7_18  segment_load_conservation_1139  1
    load_1_7_18  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_880  -30
    arc_1_8_0  depot_return_or_bypass_1134  1
    arc_1_8_0  out_degree_1142  1
    arc_1_8_0  original_T_including_depot_unload_1214  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_880  1
    load_1_8_0  segment_load_conservation_1146  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_881  -30
    arc_1_8_7  connected_order_arc_882  -13
    arc_1_8_7  in_degree_1136  1
    arc_1_8_7  out_degree_1142  1
    arc_1_8_7  original_T_including_depot_unload_1214  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_881  1
    load_1_8_7  segment_load_conservation_1139  -1
    load_1_8_7  segment_prefix_lb_1140  1
    load_1_8_7  segment_prefix_ub_1141  1
    load_1_8_7  segment_load_conservation_1146  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_883  -30
    arc_1_8_9  connected_order_arc_884  -13
    arc_1_8_9  out_degree_1142  1
    arc_1_8_9  in_degree_1150  1
    arc_1_8_9  original_T_including_depot_unload_1214  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_883  1
    load_1_8_9  segment_load_conservation_1146  1
    load_1_8_9  segment_load_conservation_1153  -1
    load_1_8_9  segment_prefix_lb_1154  1
    load_1_8_9  segment_prefix_ub_1155  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_885  -30
    arc_1_8_10  connected_order_arc_886  -13
    arc_1_8_10  out_degree_1142  1
    arc_1_8_10  in_degree_1157  1
    arc_1_8_10  original_T_including_depot_unload_1214  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_885  1
    load_1_8_10  segment_load_conservation_1146  1
    load_1_8_10  segment_load_conservation_1160  -1
    load_1_8_10  segment_prefix_lb_1161  1
    load_1_8_10  segment_prefix_ub_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_11  arc_capacity_887  -30
    arc_1_8_11  connected_order_arc_888  -13
    arc_1_8_11  out_degree_1142  1
    arc_1_8_11  in_degree_1164  1
    arc_1_8_11  original_T_including_depot_unload_1214  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_11  arc_capacity_887  1
    load_1_8_11  segment_load_conservation_1146  1
    load_1_8_11  free_load_conservation_1168  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_889  -30
    arc_1_8_12  connected_order_arc_890  -13
    arc_1_8_12  out_degree_1142  1
    arc_1_8_12  in_degree_1170  1
    arc_1_8_12  original_T_including_depot_unload_1214  3.7172787566213742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_889  1
    load_1_8_12  segment_load_conservation_1146  1
    load_1_8_12  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_891  -30
    arc_1_8_13  connected_order_arc_892  -13
    arc_1_8_13  out_degree_1142  1
    arc_1_8_13  in_degree_1176  1
    arc_1_8_13  original_T_including_depot_unload_1214  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_891  1
    load_1_8_13  segment_load_conservation_1146  1
    load_1_8_13  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_893  -30
    arc_1_8_14  connected_order_arc_894  -13
    arc_1_8_14  out_degree_1142  1
    arc_1_8_14  in_degree_1182  1
    arc_1_8_14  original_T_including_depot_unload_1214  3.5467090952179333e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_893  1
    load_1_8_14  segment_load_conservation_1146  1
    load_1_8_14  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_895  -30
    arc_1_8_15  connected_order_arc_896  -13
    arc_1_8_15  out_degree_1142  1
    arc_1_8_15  in_degree_1188  1
    arc_1_8_15  original_T_including_depot_unload_1214  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_895  1
    load_1_8_15  segment_load_conservation_1146  1
    load_1_8_15  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_897  -30
    arc_1_8_16  connected_order_arc_898  -13
    arc_1_8_16  out_degree_1142  1
    arc_1_8_16  in_degree_1194  1
    arc_1_8_16  original_T_including_depot_unload_1214  3.9583831508648805e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_897  1
    load_1_8_16  segment_load_conservation_1146  1
    load_1_8_16  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_899  -30
    arc_1_8_17  connected_order_arc_900  -13
    arc_1_8_17  out_degree_1142  1
    arc_1_8_17  in_degree_1200  1
    arc_1_8_17  original_T_including_depot_unload_1214  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_899  1
    load_1_8_17  segment_load_conservation_1146  1
    load_1_8_17  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_901  -30
    arc_1_8_18  connected_order_arc_902  -13
    arc_1_8_18  out_degree_1142  1
    arc_1_8_18  in_degree_1206  1
    arc_1_8_18  original_T_including_depot_unload_1214  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_901  1
    load_1_8_18  segment_load_conservation_1146  1
    load_1_8_18  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_903  -30
    arc_1_9_0  depot_return_or_bypass_1134  1
    arc_1_9_0  out_degree_1149  1
    arc_1_9_0  original_T_including_depot_unload_1214  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_903  1
    load_1_9_0  segment_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_904  -30
    arc_1_9_7  connected_order_arc_905  -13
    arc_1_9_7  in_degree_1136  1
    arc_1_9_7  out_degree_1149  1
    arc_1_9_7  original_T_including_depot_unload_1214  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_904  1
    load_1_9_7  segment_load_conservation_1139  -1
    load_1_9_7  segment_prefix_lb_1140  1
    load_1_9_7  segment_prefix_ub_1141  1
    load_1_9_7  segment_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_906  -30
    arc_1_9_8  connected_order_arc_907  -13
    arc_1_9_8  in_degree_1143  1
    arc_1_9_8  out_degree_1149  1
    arc_1_9_8  original_T_including_depot_unload_1214  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_906  1
    load_1_9_8  segment_load_conservation_1146  -1
    load_1_9_8  segment_prefix_lb_1147  1
    load_1_9_8  segment_prefix_ub_1148  1
    load_1_9_8  segment_load_conservation_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_908  -30
    arc_1_9_10  connected_order_arc_909  -13
    arc_1_9_10  out_degree_1149  1
    arc_1_9_10  in_degree_1157  1
    arc_1_9_10  original_T_including_depot_unload_1214  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_908  1
    load_1_9_10  segment_load_conservation_1153  1
    load_1_9_10  segment_load_conservation_1160  -1
    load_1_9_10  segment_prefix_lb_1161  1
    load_1_9_10  segment_prefix_ub_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_910  -30
    arc_1_9_11  connected_order_arc_911  -13
    arc_1_9_11  out_degree_1149  1
    arc_1_9_11  in_degree_1164  1
    arc_1_9_11  original_T_including_depot_unload_1214  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_910  1
    load_1_9_11  segment_load_conservation_1153  1
    load_1_9_11  free_load_conservation_1168  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_12  arc_capacity_912  -30
    arc_1_9_12  connected_order_arc_913  -13
    arc_1_9_12  out_degree_1149  1
    arc_1_9_12  in_degree_1170  1
    arc_1_9_12  original_T_including_depot_unload_1214  2.7384186870432241e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_12  arc_capacity_912  1
    load_1_9_12  segment_load_conservation_1153  1
    load_1_9_12  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_914  -30
    arc_1_9_13  connected_order_arc_915  -13
    arc_1_9_13  out_degree_1149  1
    arc_1_9_13  in_degree_1176  1
    arc_1_9_13  original_T_including_depot_unload_1214  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_914  1
    load_1_9_13  segment_load_conservation_1153  1
    load_1_9_13  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_916  -30
    arc_1_9_14  connected_order_arc_917  -13
    arc_1_9_14  out_degree_1149  1
    arc_1_9_14  in_degree_1182  1
    arc_1_9_14  original_T_including_depot_unload_1214  2.6934497586971770e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_916  1
    load_1_9_14  segment_load_conservation_1153  1
    load_1_9_14  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_918  -30
    arc_1_9_15  connected_order_arc_919  -13
    arc_1_9_15  out_degree_1149  1
    arc_1_9_15  in_degree_1188  1
    arc_1_9_15  original_T_including_depot_unload_1214  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_918  1
    load_1_9_15  segment_load_conservation_1153  1
    load_1_9_15  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_920  -30
    arc_1_9_16  connected_order_arc_921  -13
    arc_1_9_16  out_degree_1149  1
    arc_1_9_16  in_degree_1194  1
    arc_1_9_16  original_T_including_depot_unload_1214  2.9475580354409412e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_920  1
    load_1_9_16  segment_load_conservation_1153  1
    load_1_9_16  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_922  -30
    arc_1_9_17  connected_order_arc_923  -13
    arc_1_9_17  out_degree_1149  1
    arc_1_9_17  in_degree_1200  1
    arc_1_9_17  original_T_including_depot_unload_1214  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_922  1
    load_1_9_17  segment_load_conservation_1153  1
    load_1_9_17  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_924  -30
    arc_1_9_18  connected_order_arc_925  -13
    arc_1_9_18  out_degree_1149  1
    arc_1_9_18  in_degree_1206  1
    arc_1_9_18  original_T_including_depot_unload_1214  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_924  1
    load_1_9_18  segment_load_conservation_1153  1
    load_1_9_18  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_926  -30
    arc_1_10_0  depot_return_or_bypass_1134  1
    arc_1_10_0  out_degree_1156  1
    arc_1_10_0  original_T_including_depot_unload_1214  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_926  1
    load_1_10_0  segment_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_927  -30
    arc_1_10_7  connected_order_arc_928  -13
    arc_1_10_7  in_degree_1136  1
    arc_1_10_7  out_degree_1156  1
    arc_1_10_7  original_T_including_depot_unload_1214  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_927  1
    load_1_10_7  segment_load_conservation_1139  -1
    load_1_10_7  segment_prefix_lb_1140  1
    load_1_10_7  segment_prefix_ub_1141  1
    load_1_10_7  segment_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_929  -30
    arc_1_10_8  connected_order_arc_930  -13
    arc_1_10_8  in_degree_1143  1
    arc_1_10_8  out_degree_1156  1
    arc_1_10_8  original_T_including_depot_unload_1214  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_929  1
    load_1_10_8  segment_load_conservation_1146  -1
    load_1_10_8  segment_prefix_lb_1147  1
    load_1_10_8  segment_prefix_ub_1148  1
    load_1_10_8  segment_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_931  -30
    arc_1_10_9  connected_order_arc_932  -13
    arc_1_10_9  in_degree_1150  1
    arc_1_10_9  out_degree_1156  1
    arc_1_10_9  original_T_including_depot_unload_1214  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_931  1
    load_1_10_9  segment_load_conservation_1153  -1
    load_1_10_9  segment_prefix_lb_1154  1
    load_1_10_9  segment_prefix_ub_1155  1
    load_1_10_9  segment_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_933  -30
    arc_1_10_11  connected_order_arc_934  -13
    arc_1_10_11  out_degree_1156  1
    arc_1_10_11  in_degree_1164  1
    arc_1_10_11  original_T_including_depot_unload_1214  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_933  1
    load_1_10_11  segment_load_conservation_1160  1
    load_1_10_11  free_load_conservation_1168  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_12  arc_capacity_935  -30
    arc_1_10_12  connected_order_arc_936  -13
    arc_1_10_12  out_degree_1156  1
    arc_1_10_12  in_degree_1170  1
    arc_1_10_12  original_T_including_depot_unload_1214  2.5026151120907321e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_12  arc_capacity_935  1
    load_1_10_12  segment_load_conservation_1160  1
    load_1_10_12  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_13  arc_capacity_937  -30
    arc_1_10_13  connected_order_arc_938  -13
    arc_1_10_13  out_degree_1156  1
    arc_1_10_13  in_degree_1176  1
    arc_1_10_13  original_T_including_depot_unload_1214  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_13  arc_capacity_937  1
    load_1_10_13  segment_load_conservation_1160  1
    load_1_10_13  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_939  -30
    arc_1_10_14  connected_order_arc_940  -13
    arc_1_10_14  out_degree_1156  1
    arc_1_10_14  in_degree_1182  1
    arc_1_10_14  original_T_including_depot_unload_1214  2.4719804203198282e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_939  1
    load_1_10_14  segment_load_conservation_1160  1
    load_1_10_14  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_941  -30
    arc_1_10_15  connected_order_arc_942  -13
    arc_1_10_15  out_degree_1156  1
    arc_1_10_15  in_degree_1188  1
    arc_1_10_15  original_T_including_depot_unload_1214  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_941  1
    load_1_10_15  segment_load_conservation_1160  1
    load_1_10_15  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_943  -30
    arc_1_10_16  connected_order_arc_944  -13
    arc_1_10_16  out_degree_1156  1
    arc_1_10_16  in_degree_1194  1
    arc_1_10_16  original_T_including_depot_unload_1214  2.7067041301428726e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_943  1
    load_1_10_16  segment_load_conservation_1160  1
    load_1_10_16  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_945  -30
    arc_1_10_17  connected_order_arc_946  -13
    arc_1_10_17  out_degree_1156  1
    arc_1_10_17  in_degree_1200  1
    arc_1_10_17  original_T_including_depot_unload_1214  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_945  1
    load_1_10_17  segment_load_conservation_1160  1
    load_1_10_17  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_947  -30
    arc_1_10_18  connected_order_arc_948  -13
    arc_1_10_18  out_degree_1156  1
    arc_1_10_18  in_degree_1206  1
    arc_1_10_18  original_T_including_depot_unload_1214  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_947  1
    load_1_10_18  segment_load_conservation_1160  1
    load_1_10_18  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_949  -30
    arc_1_11_0  depot_return_or_bypass_1134  1
    arc_1_11_0  out_degree_1163  1
    arc_1_11_0  original_T_including_depot_unload_1214  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_949  1
    load_1_11_0  free_load_conservation_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_7  arc_capacity_950  -30
    arc_1_11_7  connected_order_arc_951  -13
    arc_1_11_7  in_degree_1136  1
    arc_1_11_7  out_degree_1163  1
    arc_1_11_7  original_T_including_depot_unload_1214  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_7  arc_capacity_950  1
    load_1_11_7  segment_load_conservation_1139  -1
    load_1_11_7  segment_prefix_lb_1140  1
    load_1_11_7  segment_prefix_ub_1141  1
    load_1_11_7  free_load_conservation_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_8  arc_capacity_952  -30
    arc_1_11_8  connected_order_arc_953  -13
    arc_1_11_8  in_degree_1143  1
    arc_1_11_8  out_degree_1163  1
    arc_1_11_8  original_T_including_depot_unload_1214  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_8  arc_capacity_952  1
    load_1_11_8  segment_load_conservation_1146  -1
    load_1_11_8  segment_prefix_lb_1147  1
    load_1_11_8  segment_prefix_ub_1148  1
    load_1_11_8  free_load_conservation_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_954  -30
    arc_1_11_9  connected_order_arc_955  -13
    arc_1_11_9  in_degree_1150  1
    arc_1_11_9  out_degree_1163  1
    arc_1_11_9  original_T_including_depot_unload_1214  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_954  1
    load_1_11_9  segment_load_conservation_1153  -1
    load_1_11_9  segment_prefix_lb_1154  1
    load_1_11_9  segment_prefix_ub_1155  1
    load_1_11_9  free_load_conservation_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_956  -30
    arc_1_11_10  connected_order_arc_957  -13
    arc_1_11_10  in_degree_1157  1
    arc_1_11_10  out_degree_1163  1
    arc_1_11_10  original_T_including_depot_unload_1214  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_956  1
    load_1_11_10  segment_load_conservation_1160  -1
    load_1_11_10  segment_prefix_lb_1161  1
    load_1_11_10  segment_prefix_ub_1162  1
    load_1_11_10  free_load_conservation_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_12  arc_capacity_958  -30
    arc_1_11_12  connected_order_arc_959  -13
    arc_1_11_12  out_degree_1163  1
    arc_1_11_12  in_degree_1170  1
    arc_1_11_12  original_T_including_depot_unload_1214  1.3126604801096047e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_12  arc_capacity_958  1
    load_1_11_12  free_load_conservation_1168  1
    load_1_11_12  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_13  arc_capacity_960  -30
    arc_1_11_13  connected_order_arc_961  -13
    arc_1_11_13  out_degree_1163  1
    arc_1_11_13  in_degree_1176  1
    arc_1_11_13  original_T_including_depot_unload_1214  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_13  arc_capacity_960  1
    load_1_11_13  free_load_conservation_1168  1
    load_1_11_13  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_14  arc_capacity_962  -30
    arc_1_11_14  connected_order_arc_963  -13
    arc_1_11_14  out_degree_1163  1
    arc_1_11_14  in_degree_1182  1
    arc_1_11_14  original_T_including_depot_unload_1214  2.0591198250504166e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_14  arc_capacity_962  1
    load_1_11_14  free_load_conservation_1168  1
    load_1_11_14  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_15  arc_capacity_964  -30
    arc_1_11_15  connected_order_arc_965  -13
    arc_1_11_15  out_degree_1163  1
    arc_1_11_15  in_degree_1188  1
    arc_1_11_15  original_T_including_depot_unload_1214  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_15  arc_capacity_964  1
    load_1_11_15  free_load_conservation_1168  1
    load_1_11_15  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_16  arc_capacity_966  -30
    arc_1_11_16  connected_order_arc_967  -13
    arc_1_11_16  out_degree_1163  1
    arc_1_11_16  in_degree_1194  1
    arc_1_11_16  original_T_including_depot_unload_1214  2.8958539392642757e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_16  arc_capacity_966  1
    load_1_11_16  free_load_conservation_1168  1
    load_1_11_16  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_17  arc_capacity_968  -30
    arc_1_11_17  connected_order_arc_969  -13
    arc_1_11_17  out_degree_1163  1
    arc_1_11_17  in_degree_1200  1
    arc_1_11_17  original_T_including_depot_unload_1214  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_17  arc_capacity_968  1
    load_1_11_17  free_load_conservation_1168  1
    load_1_11_17  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_18  arc_capacity_970  -30
    arc_1_11_18  connected_order_arc_971  -13
    arc_1_11_18  out_degree_1163  1
    arc_1_11_18  in_degree_1206  1
    arc_1_11_18  original_T_including_depot_unload_1214  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_18  arc_capacity_970  1
    load_1_11_18  free_load_conservation_1168  1
    load_1_11_18  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_972  -30
    arc_1_12_0  depot_return_or_bypass_1134  1
    arc_1_12_0  out_degree_1169  1
    arc_1_12_0  original_T_including_depot_unload_1214  2.2779423489344404e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_972  1
    load_1_12_0  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_973  -30
    arc_1_12_7  connected_order_arc_974  -13
    arc_1_12_7  in_degree_1136  1
    arc_1_12_7  out_degree_1169  1
    arc_1_12_7  original_T_including_depot_unload_1214  3.8248940301741582e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_973  1
    load_1_12_7  segment_load_conservation_1139  -1
    load_1_12_7  segment_prefix_lb_1140  1
    load_1_12_7  segment_prefix_ub_1141  1
    load_1_12_7  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_975  -30
    arc_1_12_8  connected_order_arc_976  -13
    arc_1_12_8  in_degree_1143  1
    arc_1_12_8  out_degree_1169  1
    arc_1_12_8  original_T_including_depot_unload_1214  3.7172787566213742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_975  1
    load_1_12_8  segment_load_conservation_1146  -1
    load_1_12_8  segment_prefix_lb_1147  1
    load_1_12_8  segment_prefix_ub_1148  1
    load_1_12_8  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_9  arc_capacity_977  -30
    arc_1_12_9  connected_order_arc_978  -13
    arc_1_12_9  in_degree_1150  1
    arc_1_12_9  out_degree_1169  1
    arc_1_12_9  original_T_including_depot_unload_1214  2.7384186870432241e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_9  arc_capacity_977  1
    load_1_12_9  segment_load_conservation_1153  -1
    load_1_12_9  segment_prefix_lb_1154  1
    load_1_12_9  segment_prefix_ub_1155  1
    load_1_12_9  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_10  arc_capacity_979  -30
    arc_1_12_10  connected_order_arc_980  -13
    arc_1_12_10  in_degree_1157  1
    arc_1_12_10  out_degree_1169  1
    arc_1_12_10  original_T_including_depot_unload_1214  2.5026151120907321e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_10  arc_capacity_979  1
    load_1_12_10  segment_load_conservation_1160  -1
    load_1_12_10  segment_prefix_lb_1161  1
    load_1_12_10  segment_prefix_ub_1162  1
    load_1_12_10  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_11  arc_capacity_981  -30
    arc_1_12_11  connected_order_arc_982  -13
    arc_1_12_11  in_degree_1164  1
    arc_1_12_11  out_degree_1169  1
    arc_1_12_11  original_T_including_depot_unload_1214  1.3126604801096047e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_11  arc_capacity_981  1
    load_1_12_11  free_load_conservation_1168  -1
    load_1_12_11  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_983  -30
    arc_1_12_13  connected_order_arc_984  -13
    arc_1_12_13  out_degree_1169  1
    arc_1_12_13  in_degree_1176  1
    arc_1_12_13  original_T_including_depot_unload_1214  4.1781804970479707e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_983  1
    load_1_12_13  free_load_conservation_1174  1
    load_1_12_13  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_985  -30
    arc_1_12_14  connected_order_arc_986  -13
    arc_1_12_14  out_degree_1169  1
    arc_1_12_14  in_degree_1182  1
    arc_1_12_14  original_T_including_depot_unload_1214  2.9613729621393293e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_985  1
    load_1_12_14  free_load_conservation_1174  1
    load_1_12_14  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_987  -30
    arc_1_12_15  connected_order_arc_988  -13
    arc_1_12_15  out_degree_1169  1
    arc_1_12_15  in_degree_1188  1
    arc_1_12_15  original_T_including_depot_unload_1214  2.6300071929095179e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_987  1
    load_1_12_15  free_load_conservation_1174  1
    load_1_12_15  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_989  -30
    arc_1_12_16  connected_order_arc_990  -13
    arc_1_12_16  out_degree_1169  1
    arc_1_12_16  in_degree_1194  1
    arc_1_12_16  original_T_including_depot_unload_1214  2.4254234166891203e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_989  1
    load_1_12_16  free_load_conservation_1174  1
    load_1_12_16  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_17  arc_capacity_991  -30
    arc_1_12_17  connected_order_arc_992  -13
    arc_1_12_17  out_degree_1169  1
    arc_1_12_17  in_degree_1200  1
    arc_1_12_17  original_T_including_depot_unload_1214  2.6166334544495612e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_17  arc_capacity_991  1
    load_1_12_17  free_load_conservation_1174  1
    load_1_12_17  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_18  arc_capacity_993  -30
    arc_1_12_18  connected_order_arc_994  -13
    arc_1_12_18  out_degree_1169  1
    arc_1_12_18  in_degree_1206  1
    arc_1_12_18  original_T_including_depot_unload_1214  2389.0890755213
    MARKER    'MARKER'                 'INTEND'
    load_1_12_18  arc_capacity_993  1
    load_1_12_18  free_load_conservation_1174  1
    load_1_12_18  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_995  -30
    arc_1_13_0  depot_return_or_bypass_1134  1
    arc_1_13_0  out_degree_1175  1
    arc_1_13_0  original_T_including_depot_unload_1214  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_995  1
    load_1_13_0  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_996  -30
    arc_1_13_7  connected_order_arc_997  -13
    arc_1_13_7  in_degree_1136  1
    arc_1_13_7  out_degree_1175  1
    arc_1_13_7  original_T_including_depot_unload_1214  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_996  1
    load_1_13_7  segment_load_conservation_1139  -1
    load_1_13_7  segment_prefix_lb_1140  1
    load_1_13_7  segment_prefix_ub_1141  1
    load_1_13_7  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_998  -30
    arc_1_13_8  connected_order_arc_999  -13
    arc_1_13_8  in_degree_1143  1
    arc_1_13_8  out_degree_1175  1
    arc_1_13_8  original_T_including_depot_unload_1214  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_998  1
    load_1_13_8  segment_load_conservation_1146  -1
    load_1_13_8  segment_prefix_lb_1147  1
    load_1_13_8  segment_prefix_ub_1148  1
    load_1_13_8  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_1000  -30
    arc_1_13_9  connected_order_arc_1001  -13
    arc_1_13_9  in_degree_1150  1
    arc_1_13_9  out_degree_1175  1
    arc_1_13_9  original_T_including_depot_unload_1214  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_1000  1
    load_1_13_9  segment_load_conservation_1153  -1
    load_1_13_9  segment_prefix_lb_1154  1
    load_1_13_9  segment_prefix_ub_1155  1
    load_1_13_9  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_10  arc_capacity_1002  -30
    arc_1_13_10  connected_order_arc_1003  -13
    arc_1_13_10  in_degree_1157  1
    arc_1_13_10  out_degree_1175  1
    arc_1_13_10  original_T_including_depot_unload_1214  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_10  arc_capacity_1002  1
    load_1_13_10  segment_load_conservation_1160  -1
    load_1_13_10  segment_prefix_lb_1161  1
    load_1_13_10  segment_prefix_ub_1162  1
    load_1_13_10  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_11  arc_capacity_1004  -30
    arc_1_13_11  connected_order_arc_1005  -13
    arc_1_13_11  in_degree_1164  1
    arc_1_13_11  out_degree_1175  1
    arc_1_13_11  original_T_including_depot_unload_1214  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_11  arc_capacity_1004  1
    load_1_13_11  free_load_conservation_1168  -1
    load_1_13_11  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_1006  -30
    arc_1_13_12  connected_order_arc_1007  -13
    arc_1_13_12  in_degree_1170  1
    arc_1_13_12  out_degree_1175  1
    arc_1_13_12  original_T_including_depot_unload_1214  4.1781804970479707e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_1006  1
    load_1_13_12  free_load_conservation_1174  -1
    load_1_13_12  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_1008  -30
    arc_1_13_14  connected_order_arc_1009  -13
    arc_1_13_14  out_degree_1175  1
    arc_1_13_14  in_degree_1182  1
    arc_1_13_14  original_T_including_depot_unload_1214  3.9880377227050253e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_1008  1
    load_1_13_14  free_load_conservation_1180  1
    load_1_13_14  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_1010  -30
    arc_1_13_15  connected_order_arc_1011  -13
    arc_1_13_15  out_degree_1175  1
    arc_1_13_15  in_degree_1188  1
    arc_1_13_15  original_T_including_depot_unload_1214  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_1010  1
    load_1_13_15  free_load_conservation_1180  1
    load_1_13_15  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_1012  -30
    arc_1_13_16  connected_order_arc_1013  -13
    arc_1_13_16  out_degree_1175  1
    arc_1_13_16  in_degree_1194  1
    arc_1_13_16  original_T_including_depot_unload_1214  4.4205864351455948e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_1012  1
    load_1_13_16  free_load_conservation_1180  1
    load_1_13_16  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_1014  -30
    arc_1_13_17  connected_order_arc_1015  -13
    arc_1_13_17  out_degree_1175  1
    arc_1_13_17  in_degree_1200  1
    arc_1_13_17  original_T_including_depot_unload_1214  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_1014  1
    load_1_13_17  free_load_conservation_1180  1
    load_1_13_17  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_1016  -30
    arc_1_13_18  connected_order_arc_1017  -13
    arc_1_13_18  out_degree_1175  1
    arc_1_13_18  in_degree_1206  1
    arc_1_13_18  original_T_including_depot_unload_1214  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_1016  1
    load_1_13_18  free_load_conservation_1180  1
    load_1_13_18  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1018  -30
    arc_1_14_0  depot_return_or_bypass_1134  1
    arc_1_14_0  out_degree_1181  1
    arc_1_14_0  original_T_including_depot_unload_1214  2.2058800397347450e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1018  1
    load_1_14_0  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_1019  -30
    arc_1_14_7  connected_order_arc_1020  -13
    arc_1_14_7  in_degree_1136  1
    arc_1_14_7  out_degree_1181  1
    arc_1_14_7  original_T_including_depot_unload_1214  3.6590564985322576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_1019  1
    load_1_14_7  segment_load_conservation_1139  -1
    load_1_14_7  segment_prefix_lb_1140  1
    load_1_14_7  segment_prefix_ub_1141  1
    load_1_14_7  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_1021  -30
    arc_1_14_8  connected_order_arc_1022  -13
    arc_1_14_8  in_degree_1143  1
    arc_1_14_8  out_degree_1181  1
    arc_1_14_8  original_T_including_depot_unload_1214  3.5467090952179333e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_1021  1
    load_1_14_8  segment_load_conservation_1146  -1
    load_1_14_8  segment_prefix_lb_1147  1
    load_1_14_8  segment_prefix_ub_1148  1
    load_1_14_8  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1023  -30
    arc_1_14_9  connected_order_arc_1024  -13
    arc_1_14_9  in_degree_1150  1
    arc_1_14_9  out_degree_1181  1
    arc_1_14_9  original_T_including_depot_unload_1214  2.6934497586971770e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1023  1
    load_1_14_9  segment_load_conservation_1153  -1
    load_1_14_9  segment_prefix_lb_1154  1
    load_1_14_9  segment_prefix_ub_1155  1
    load_1_14_9  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_1025  -30
    arc_1_14_10  connected_order_arc_1026  -13
    arc_1_14_10  in_degree_1157  1
    arc_1_14_10  out_degree_1181  1
    arc_1_14_10  original_T_including_depot_unload_1214  2.4719804203198282e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_1025  1
    load_1_14_10  segment_load_conservation_1160  -1
    load_1_14_10  segment_prefix_lb_1161  1
    load_1_14_10  segment_prefix_ub_1162  1
    load_1_14_10  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_11  arc_capacity_1027  -30
    arc_1_14_11  connected_order_arc_1028  -13
    arc_1_14_11  in_degree_1164  1
    arc_1_14_11  out_degree_1181  1
    arc_1_14_11  original_T_including_depot_unload_1214  2.0591198250504166e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_11  arc_capacity_1027  1
    load_1_14_11  free_load_conservation_1168  -1
    load_1_14_11  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_1029  -30
    arc_1_14_12  connected_order_arc_1030  -13
    arc_1_14_12  in_degree_1170  1
    arc_1_14_12  out_degree_1181  1
    arc_1_14_12  original_T_including_depot_unload_1214  2.9613729621393293e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_1029  1
    load_1_14_12  free_load_conservation_1174  -1
    load_1_14_12  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_1031  -30
    arc_1_14_13  connected_order_arc_1032  -13
    arc_1_14_13  in_degree_1176  1
    arc_1_14_13  out_degree_1181  1
    arc_1_14_13  original_T_including_depot_unload_1214  3.9880377227050253e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_1031  1
    load_1_14_13  free_load_conservation_1180  -1
    load_1_14_13  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1033  -30
    arc_1_14_15  connected_order_arc_1034  -13
    arc_1_14_15  out_degree_1181  1
    arc_1_14_15  in_degree_1188  1
    arc_1_14_15  original_T_including_depot_unload_1214  2.3631048359201741e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1033  1
    load_1_14_15  free_load_conservation_1186  1
    load_1_14_15  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1035  -30
    arc_1_14_16  connected_order_arc_1036  -13
    arc_1_14_16  out_degree_1181  1
    arc_1_14_16  in_degree_1194  1
    arc_1_14_16  original_T_including_depot_unload_1214  4.9538322318613183e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1035  1
    load_1_14_16  free_load_conservation_1186  1
    load_1_14_16  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_1037  -30
    arc_1_14_17  connected_order_arc_1038  -13
    arc_1_14_17  out_degree_1181  1
    arc_1_14_17  in_degree_1200  1
    arc_1_14_17  original_T_including_depot_unload_1214  2.5694031842490126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_1037  1
    load_1_14_17  free_load_conservation_1186  1
    load_1_14_17  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_1039  -30
    arc_1_14_18  connected_order_arc_1040  -13
    arc_1_14_18  out_degree_1181  1
    arc_1_14_18  in_degree_1206  1
    arc_1_14_18  original_T_including_depot_unload_1214  2.2742677293115130e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_1039  1
    load_1_14_18  free_load_conservation_1186  1
    load_1_14_18  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1041  -30
    arc_1_15_0  depot_return_or_bypass_1134  1
    arc_1_15_0  out_degree_1187  1
    arc_1_15_0  original_T_including_depot_unload_1214  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1041  1
    load_1_15_0  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1042  -30
    arc_1_15_7  connected_order_arc_1043  -13
    arc_1_15_7  in_degree_1136  1
    arc_1_15_7  out_degree_1187  1
    arc_1_15_7  original_T_including_depot_unload_1214  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1042  1
    load_1_15_7  segment_load_conservation_1139  -1
    load_1_15_7  segment_prefix_lb_1140  1
    load_1_15_7  segment_prefix_ub_1141  1
    load_1_15_7  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1044  -30
    arc_1_15_8  connected_order_arc_1045  -13
    arc_1_15_8  in_degree_1143  1
    arc_1_15_8  out_degree_1187  1
    arc_1_15_8  original_T_including_depot_unload_1214  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1044  1
    load_1_15_8  segment_load_conservation_1146  -1
    load_1_15_8  segment_prefix_lb_1147  1
    load_1_15_8  segment_prefix_ub_1148  1
    load_1_15_8  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1046  -30
    arc_1_15_9  connected_order_arc_1047  -13
    arc_1_15_9  in_degree_1150  1
    arc_1_15_9  out_degree_1187  1
    arc_1_15_9  original_T_including_depot_unload_1214  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1046  1
    load_1_15_9  segment_load_conservation_1153  -1
    load_1_15_9  segment_prefix_lb_1154  1
    load_1_15_9  segment_prefix_ub_1155  1
    load_1_15_9  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1048  -30
    arc_1_15_10  connected_order_arc_1049  -13
    arc_1_15_10  in_degree_1157  1
    arc_1_15_10  out_degree_1187  1
    arc_1_15_10  original_T_including_depot_unload_1214  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1048  1
    load_1_15_10  segment_load_conservation_1160  -1
    load_1_15_10  segment_prefix_lb_1161  1
    load_1_15_10  segment_prefix_ub_1162  1
    load_1_15_10  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_11  arc_capacity_1050  -30
    arc_1_15_11  connected_order_arc_1051  -13
    arc_1_15_11  in_degree_1164  1
    arc_1_15_11  out_degree_1187  1
    arc_1_15_11  original_T_including_depot_unload_1214  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_11  arc_capacity_1050  1
    load_1_15_11  free_load_conservation_1168  -1
    load_1_15_11  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_1052  -30
    arc_1_15_12  connected_order_arc_1053  -13
    arc_1_15_12  in_degree_1170  1
    arc_1_15_12  out_degree_1187  1
    arc_1_15_12  original_T_including_depot_unload_1214  2.6300071929095179e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_1052  1
    load_1_15_12  free_load_conservation_1174  -1
    load_1_15_12  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_1054  -30
    arc_1_15_13  connected_order_arc_1055  -13
    arc_1_15_13  in_degree_1176  1
    arc_1_15_13  out_degree_1187  1
    arc_1_15_13  original_T_including_depot_unload_1214  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_1054  1
    load_1_15_13  free_load_conservation_1180  -1
    load_1_15_13  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1056  -30
    arc_1_15_14  connected_order_arc_1057  -13
    arc_1_15_14  in_degree_1182  1
    arc_1_15_14  out_degree_1187  1
    arc_1_15_14  original_T_including_depot_unload_1214  2.3631048359201741e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1056  1
    load_1_15_14  free_load_conservation_1186  -1
    load_1_15_14  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1058  -30
    arc_1_15_16  connected_order_arc_1059  -13
    arc_1_15_16  out_degree_1187  1
    arc_1_15_16  in_degree_1194  1
    arc_1_15_16  original_T_including_depot_unload_1214  2.8559472795328161e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1058  1
    load_1_15_16  free_load_conservation_1192  1
    load_1_15_16  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1060  -30
    arc_1_15_17  connected_order_arc_1061  -13
    arc_1_15_17  out_degree_1187  1
    arc_1_15_17  in_degree_1200  1
    arc_1_15_17  original_T_including_depot_unload_1214  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1060  1
    load_1_15_17  free_load_conservation_1192  1
    load_1_15_17  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1062  -30
    arc_1_15_18  connected_order_arc_1063  -13
    arc_1_15_18  out_degree_1187  1
    arc_1_15_18  in_degree_1206  1
    arc_1_15_18  original_T_including_depot_unload_1214  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1062  1
    load_1_15_18  free_load_conservation_1192  1
    load_1_15_18  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1064  -30
    arc_1_16_0  depot_return_or_bypass_1134  1
    arc_1_16_0  out_degree_1193  1
    arc_1_16_0  original_T_including_depot_unload_1214  2.4985877836350596e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1064  1
    load_1_16_0  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1065  -30
    arc_1_16_7  connected_order_arc_1066  -13
    arc_1_16_7  in_degree_1136  1
    arc_1_16_7  out_degree_1193  1
    arc_1_16_7  original_T_including_depot_unload_1214  4.0654406432457854e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1065  1
    load_1_16_7  segment_load_conservation_1139  -1
    load_1_16_7  segment_prefix_lb_1140  1
    load_1_16_7  segment_prefix_ub_1141  1
    load_1_16_7  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1067  -30
    arc_1_16_8  connected_order_arc_1068  -13
    arc_1_16_8  in_degree_1143  1
    arc_1_16_8  out_degree_1193  1
    arc_1_16_8  original_T_including_depot_unload_1214  3.9583831508648805e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1067  1
    load_1_16_8  segment_load_conservation_1146  -1
    load_1_16_8  segment_prefix_lb_1147  1
    load_1_16_8  segment_prefix_ub_1148  1
    load_1_16_8  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1069  -30
    arc_1_16_9  connected_order_arc_1070  -13
    arc_1_16_9  in_degree_1150  1
    arc_1_16_9  out_degree_1193  1
    arc_1_16_9  original_T_including_depot_unload_1214  2.9475580354409412e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1069  1
    load_1_16_9  segment_load_conservation_1153  -1
    load_1_16_9  segment_prefix_lb_1154  1
    load_1_16_9  segment_prefix_ub_1155  1
    load_1_16_9  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1071  -30
    arc_1_16_10  connected_order_arc_1072  -13
    arc_1_16_10  in_degree_1157  1
    arc_1_16_10  out_degree_1193  1
    arc_1_16_10  original_T_including_depot_unload_1214  2.7067041301428726e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1071  1
    load_1_16_10  segment_load_conservation_1160  -1
    load_1_16_10  segment_prefix_lb_1161  1
    load_1_16_10  segment_prefix_ub_1162  1
    load_1_16_10  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_11  arc_capacity_1073  -30
    arc_1_16_11  connected_order_arc_1074  -13
    arc_1_16_11  in_degree_1164  1
    arc_1_16_11  out_degree_1193  1
    arc_1_16_11  original_T_including_depot_unload_1214  2.8958539392642757e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_11  arc_capacity_1073  1
    load_1_16_11  free_load_conservation_1168  -1
    load_1_16_11  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_1075  -30
    arc_1_16_12  connected_order_arc_1076  -13
    arc_1_16_12  in_degree_1170  1
    arc_1_16_12  out_degree_1193  1
    arc_1_16_12  original_T_including_depot_unload_1214  2.4254234166891203e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_1075  1
    load_1_16_12  free_load_conservation_1174  -1
    load_1_16_12  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1077  -30
    arc_1_16_13  connected_order_arc_1078  -13
    arc_1_16_13  in_degree_1176  1
    arc_1_16_13  out_degree_1193  1
    arc_1_16_13  original_T_including_depot_unload_1214  4.4205864351455948e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1077  1
    load_1_16_13  free_load_conservation_1180  -1
    load_1_16_13  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1079  -30
    arc_1_16_14  connected_order_arc_1080  -13
    arc_1_16_14  in_degree_1182  1
    arc_1_16_14  out_degree_1193  1
    arc_1_16_14  original_T_including_depot_unload_1214  4.9538322318613183e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1079  1
    load_1_16_14  free_load_conservation_1186  -1
    load_1_16_14  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1081  -30
    arc_1_16_15  connected_order_arc_1082  -13
    arc_1_16_15  in_degree_1188  1
    arc_1_16_15  out_degree_1193  1
    arc_1_16_15  original_T_including_depot_unload_1214  2.8559472795328161e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1081  1
    load_1_16_15  free_load_conservation_1192  -1
    load_1_16_15  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1083  -30
    arc_1_16_17  connected_order_arc_1084  -13
    arc_1_16_17  out_degree_1193  1
    arc_1_16_17  in_degree_1200  1
    arc_1_16_17  original_T_including_depot_unload_1214  2.8270830664529126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1083  1
    load_1_16_17  free_load_conservation_1198  1
    load_1_16_17  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1085  -30
    arc_1_16_18  connected_order_arc_1086  -13
    arc_1_16_18  out_degree_1193  1
    arc_1_16_18  in_degree_1206  1
    arc_1_16_18  original_T_including_depot_unload_1214  2.6215712372467274e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1085  1
    load_1_16_18  free_load_conservation_1198  1
    load_1_16_18  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1087  -30
    arc_1_17_0  depot_return_or_bypass_1134  1
    arc_1_17_0  out_degree_1199  1
    arc_1_17_0  original_T_including_depot_unload_1214  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1087  1
    load_1_17_0  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1088  -30
    arc_1_17_7  connected_order_arc_1089  -13
    arc_1_17_7  in_degree_1136  1
    arc_1_17_7  out_degree_1199  1
    arc_1_17_7  original_T_including_depot_unload_1214  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1088  1
    load_1_17_7  segment_load_conservation_1139  -1
    load_1_17_7  segment_prefix_lb_1140  1
    load_1_17_7  segment_prefix_ub_1141  1
    load_1_17_7  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1090  -30
    arc_1_17_8  connected_order_arc_1091  -13
    arc_1_17_8  in_degree_1143  1
    arc_1_17_8  out_degree_1199  1
    arc_1_17_8  original_T_including_depot_unload_1214  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1090  1
    load_1_17_8  segment_load_conservation_1146  -1
    load_1_17_8  segment_prefix_lb_1147  1
    load_1_17_8  segment_prefix_ub_1148  1
    load_1_17_8  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1092  -30
    arc_1_17_9  connected_order_arc_1093  -13
    arc_1_17_9  in_degree_1150  1
    arc_1_17_9  out_degree_1199  1
    arc_1_17_9  original_T_including_depot_unload_1214  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1092  1
    load_1_17_9  segment_load_conservation_1153  -1
    load_1_17_9  segment_prefix_lb_1154  1
    load_1_17_9  segment_prefix_ub_1155  1
    load_1_17_9  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1094  -30
    arc_1_17_10  connected_order_arc_1095  -13
    arc_1_17_10  in_degree_1157  1
    arc_1_17_10  out_degree_1199  1
    arc_1_17_10  original_T_including_depot_unload_1214  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1094  1
    load_1_17_10  segment_load_conservation_1160  -1
    load_1_17_10  segment_prefix_lb_1161  1
    load_1_17_10  segment_prefix_ub_1162  1
    load_1_17_10  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_11  arc_capacity_1096  -30
    arc_1_17_11  connected_order_arc_1097  -13
    arc_1_17_11  in_degree_1164  1
    arc_1_17_11  out_degree_1199  1
    arc_1_17_11  original_T_including_depot_unload_1214  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_11  arc_capacity_1096  1
    load_1_17_11  free_load_conservation_1168  -1
    load_1_17_11  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_12  arc_capacity_1098  -30
    arc_1_17_12  connected_order_arc_1099  -13
    arc_1_17_12  in_degree_1170  1
    arc_1_17_12  out_degree_1199  1
    arc_1_17_12  original_T_including_depot_unload_1214  2.6166334544495612e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_12  arc_capacity_1098  1
    load_1_17_12  free_load_conservation_1174  -1
    load_1_17_12  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_1100  -30
    arc_1_17_13  connected_order_arc_1101  -13
    arc_1_17_13  in_degree_1176  1
    arc_1_17_13  out_degree_1199  1
    arc_1_17_13  original_T_including_depot_unload_1214  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_1100  1
    load_1_17_13  free_load_conservation_1180  -1
    load_1_17_13  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1102  -30
    arc_1_17_14  connected_order_arc_1103  -13
    arc_1_17_14  in_degree_1182  1
    arc_1_17_14  out_degree_1199  1
    arc_1_17_14  original_T_including_depot_unload_1214  2.5694031842490126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1102  1
    load_1_17_14  free_load_conservation_1186  -1
    load_1_17_14  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1104  -30
    arc_1_17_15  connected_order_arc_1105  -13
    arc_1_17_15  in_degree_1188  1
    arc_1_17_15  out_degree_1199  1
    arc_1_17_15  original_T_including_depot_unload_1214  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1104  1
    load_1_17_15  free_load_conservation_1192  -1
    load_1_17_15  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1106  -30
    arc_1_17_16  connected_order_arc_1107  -13
    arc_1_17_16  in_degree_1194  1
    arc_1_17_16  out_degree_1199  1
    arc_1_17_16  original_T_including_depot_unload_1214  2.8270830664529126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1106  1
    load_1_17_16  free_load_conservation_1198  -1
    load_1_17_16  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1108  -30
    arc_1_17_18  connected_order_arc_1109  -13
    arc_1_17_18  out_degree_1199  1
    arc_1_17_18  in_degree_1206  1
    arc_1_17_18  original_T_including_depot_unload_1214  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1108  1
    load_1_17_18  free_load_conservation_1204  1
    load_1_17_18  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1110  -30
    arc_1_18_0  depot_return_or_bypass_1134  1
    arc_1_18_0  out_degree_1205  1
    arc_1_18_0  original_T_including_depot_unload_1214  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1110  1
    load_1_18_0  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1111  -30
    arc_1_18_7  connected_order_arc_1112  -13
    arc_1_18_7  in_degree_1136  1
    arc_1_18_7  out_degree_1205  1
    arc_1_18_7  original_T_including_depot_unload_1214  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1111  1
    load_1_18_7  segment_load_conservation_1139  -1
    load_1_18_7  segment_prefix_lb_1140  1
    load_1_18_7  segment_prefix_ub_1141  1
    load_1_18_7  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1113  -30
    arc_1_18_8  connected_order_arc_1114  -13
    arc_1_18_8  in_degree_1143  1
    arc_1_18_8  out_degree_1205  1
    arc_1_18_8  original_T_including_depot_unload_1214  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1113  1
    load_1_18_8  segment_load_conservation_1146  -1
    load_1_18_8  segment_prefix_lb_1147  1
    load_1_18_8  segment_prefix_ub_1148  1
    load_1_18_8  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1115  -30
    arc_1_18_9  connected_order_arc_1116  -13
    arc_1_18_9  in_degree_1150  1
    arc_1_18_9  out_degree_1205  1
    arc_1_18_9  original_T_including_depot_unload_1214  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1115  1
    load_1_18_9  segment_load_conservation_1153  -1
    load_1_18_9  segment_prefix_lb_1154  1
    load_1_18_9  segment_prefix_ub_1155  1
    load_1_18_9  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1117  -30
    arc_1_18_10  connected_order_arc_1118  -13
    arc_1_18_10  in_degree_1157  1
    arc_1_18_10  out_degree_1205  1
    arc_1_18_10  original_T_including_depot_unload_1214  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1117  1
    load_1_18_10  segment_load_conservation_1160  -1
    load_1_18_10  segment_prefix_lb_1161  1
    load_1_18_10  segment_prefix_ub_1162  1
    load_1_18_10  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_11  arc_capacity_1119  -30
    arc_1_18_11  connected_order_arc_1120  -13
    arc_1_18_11  in_degree_1164  1
    arc_1_18_11  out_degree_1205  1
    arc_1_18_11  original_T_including_depot_unload_1214  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_11  arc_capacity_1119  1
    load_1_18_11  free_load_conservation_1168  -1
    load_1_18_11  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_12  arc_capacity_1121  -30
    arc_1_18_12  connected_order_arc_1122  -13
    arc_1_18_12  in_degree_1170  1
    arc_1_18_12  out_degree_1205  1
    arc_1_18_12  original_T_including_depot_unload_1214  2389.0890755213
    MARKER    'MARKER'                 'INTEND'
    load_1_18_12  arc_capacity_1121  1
    load_1_18_12  free_load_conservation_1174  -1
    load_1_18_12  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1123  -30
    arc_1_18_13  connected_order_arc_1124  -13
    arc_1_18_13  in_degree_1176  1
    arc_1_18_13  out_degree_1205  1
    arc_1_18_13  original_T_including_depot_unload_1214  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1123  1
    load_1_18_13  free_load_conservation_1180  -1
    load_1_18_13  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1125  -30
    arc_1_18_14  connected_order_arc_1126  -13
    arc_1_18_14  in_degree_1182  1
    arc_1_18_14  out_degree_1205  1
    arc_1_18_14  original_T_including_depot_unload_1214  2.2742677293115130e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1125  1
    load_1_18_14  free_load_conservation_1186  -1
    load_1_18_14  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1127  -30
    arc_1_18_15  connected_order_arc_1128  -13
    arc_1_18_15  in_degree_1188  1
    arc_1_18_15  out_degree_1205  1
    arc_1_18_15  original_T_including_depot_unload_1214  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1127  1
    load_1_18_15  free_load_conservation_1192  -1
    load_1_18_15  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1129  -30
    arc_1_18_16  connected_order_arc_1130  -13
    arc_1_18_16  in_degree_1194  1
    arc_1_18_16  out_degree_1205  1
    arc_1_18_16  original_T_including_depot_unload_1214  2.6215712372467274e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1129  1
    load_1_18_16  free_load_conservation_1198  -1
    load_1_18_16  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1131  -30
    arc_1_18_17  connected_order_arc_1132  -13
    arc_1_18_17  in_degree_1200  1
    arc_1_18_17  out_degree_1205  1
    arc_1_18_17  original_T_including_depot_unload_1214  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1131  1
    load_1_18_17  free_load_conservation_1204  -1
    load_1_18_17  free_load_conservation_1210  1
RHS
    RHS1      OBJ       -3.5974179778271065e-01
    RHS1      onehot_18_32  1
    RHS1      onehot_15_39  1
    RHS1      onehot_17_76  1
    RHS1      onehot_16_85  1
    RHS1      onehot_20_120  1
    RHS1      onehot_19_135  1
    RHS1      onehot_11_170  1
    RHS1      onehot_12_205  1
    RHS1      stock_ub_209  29
    RHS1      parent_nonstrict_scope_210  6.6666894067103466e-01
    RHS1      normalization_267  1
    RHS1      connected_order_arc_370  -14
    RHS1      connected_order_arc_372  -14
    RHS1      connected_order_arc_374  -14
    RHS1      connected_order_arc_376  -14
    RHS1      connected_order_arc_378  -14
    RHS1      connected_order_arc_380  -14
    RHS1      connected_order_arc_382  -14
    RHS1      connected_order_arc_384  -14
    RHS1      connected_order_arc_386  -14
    RHS1      connected_order_arc_388  -14
    RHS1      connected_order_arc_390  -14
    RHS1      connected_order_arc_392  -14
    RHS1      connected_order_arc_394  -14
    RHS1      connected_order_arc_397  -14
    RHS1      connected_order_arc_399  -14
    RHS1      connected_order_arc_401  -14
    RHS1      connected_order_arc_403  -14
    RHS1      connected_order_arc_405  -14
    RHS1      connected_order_arc_407  -14
    RHS1      connected_order_arc_409  -14
    RHS1      connected_order_arc_411  -14
    RHS1      connected_order_arc_413  -14
    RHS1      connected_order_arc_415  -14
    RHS1      connected_order_arc_417  -14
    RHS1      connected_order_arc_419  -14
    RHS1      connected_order_arc_421  -14
    RHS1      connected_order_arc_424  -14
    RHS1      connected_order_arc_426  -14
    RHS1      connected_order_arc_428  -14
    RHS1      connected_order_arc_430  -14
    RHS1      connected_order_arc_432  -14
    RHS1      connected_order_arc_434  -14
    RHS1      connected_order_arc_436  -14
    RHS1      connected_order_arc_438  -14
    RHS1      connected_order_arc_440  -14
    RHS1      connected_order_arc_442  -14
    RHS1      connected_order_arc_444  -14
    RHS1      connected_order_arc_446  -14
    RHS1      connected_order_arc_448  -14
    RHS1      connected_order_arc_451  -14
    RHS1      connected_order_arc_453  -14
    RHS1      connected_order_arc_455  -14
    RHS1      connected_order_arc_457  -14
    RHS1      connected_order_arc_459  -14
    RHS1      connected_order_arc_461  -14
    RHS1      connected_order_arc_463  -14
    RHS1      connected_order_arc_465  -14
    RHS1      connected_order_arc_467  -14
    RHS1      connected_order_arc_469  -14
    RHS1      connected_order_arc_471  -14
    RHS1      connected_order_arc_473  -14
    RHS1      connected_order_arc_475  -14
    RHS1      connected_order_arc_478  -14
    RHS1      connected_order_arc_480  -14
    RHS1      connected_order_arc_482  -14
    RHS1      connected_order_arc_484  -14
    RHS1      connected_order_arc_486  -14
    RHS1      connected_order_arc_488  -14
    RHS1      connected_order_arc_490  -14
    RHS1      connected_order_arc_492  -14
    RHS1      connected_order_arc_494  -14
    RHS1      connected_order_arc_496  -14
    RHS1      connected_order_arc_498  -14
    RHS1      connected_order_arc_500  -14
    RHS1      connected_order_arc_502  -14
    RHS1      connected_order_arc_505  -14
    RHS1      connected_order_arc_507  -14
    RHS1      connected_order_arc_509  -14
    RHS1      connected_order_arc_511  -14
    RHS1      connected_order_arc_513  -14
    RHS1      connected_order_arc_515  -14
    RHS1      connected_order_arc_517  -14
    RHS1      connected_order_arc_519  -14
    RHS1      connected_order_arc_521  -14
    RHS1      connected_order_arc_523  -14
    RHS1      connected_order_arc_525  -14
    RHS1      connected_order_arc_527  -14
    RHS1      connected_order_arc_529  -14
    RHS1      connected_order_arc_532  -14
    RHS1      connected_order_arc_534  -14
    RHS1      connected_order_arc_536  -14
    RHS1      connected_order_arc_538  -14
    RHS1      connected_order_arc_540  -14
    RHS1      connected_order_arc_542  -14
    RHS1      connected_order_arc_544  -14
    RHS1      connected_order_arc_546  -14
    RHS1      connected_order_arc_548  -14
    RHS1      connected_order_arc_550  -14
    RHS1      connected_order_arc_552  -14
    RHS1      connected_order_arc_554  -14
    RHS1      connected_order_arc_556  -14
    RHS1      connected_order_arc_559  -14
    RHS1      connected_order_arc_561  -14
    RHS1      connected_order_arc_563  -14
    RHS1      connected_order_arc_565  -14
    RHS1      connected_order_arc_567  -14
    RHS1      connected_order_arc_569  -14
    RHS1      connected_order_arc_571  -14
    RHS1      connected_order_arc_573  -14
    RHS1      connected_order_arc_575  -14
    RHS1      connected_order_arc_577  -14
    RHS1      connected_order_arc_579  -14
    RHS1      connected_order_arc_581  -14
    RHS1      connected_order_arc_583  -14
    RHS1      connected_order_arc_586  -14
    RHS1      connected_order_arc_588  -14
    RHS1      connected_order_arc_590  -14
    RHS1      connected_order_arc_592  -14
    RHS1      connected_order_arc_594  -14
    RHS1      connected_order_arc_596  -14
    RHS1      connected_order_arc_598  -14
    RHS1      connected_order_arc_600  -14
    RHS1      connected_order_arc_602  -14
    RHS1      connected_order_arc_604  -14
    RHS1      connected_order_arc_606  -14
    RHS1      connected_order_arc_608  -14
    RHS1      connected_order_arc_610  -14
    RHS1      connected_order_arc_613  -14
    RHS1      connected_order_arc_615  -14
    RHS1      connected_order_arc_617  -14
    RHS1      connected_order_arc_619  -14
    RHS1      connected_order_arc_621  -14
    RHS1      connected_order_arc_623  -14
    RHS1      connected_order_arc_625  -14
    RHS1      connected_order_arc_627  -14
    RHS1      connected_order_arc_629  -14
    RHS1      connected_order_arc_631  -14
    RHS1      connected_order_arc_633  -14
    RHS1      connected_order_arc_635  -14
    RHS1      connected_order_arc_637  -14
    RHS1      connected_order_arc_640  -14
    RHS1      connected_order_arc_642  -14
    RHS1      connected_order_arc_644  -14
    RHS1      connected_order_arc_646  -14
    RHS1      connected_order_arc_648  -14
    RHS1      connected_order_arc_650  -14
    RHS1      connected_order_arc_652  -14
    RHS1      connected_order_arc_654  -14
    RHS1      connected_order_arc_656  -14
    RHS1      connected_order_arc_658  -14
    RHS1      connected_order_arc_660  -14
    RHS1      connected_order_arc_662  -14
    RHS1      connected_order_arc_664  -14
    RHS1      connected_order_arc_667  -14
    RHS1      connected_order_arc_669  -14
    RHS1      connected_order_arc_671  -14
    RHS1      connected_order_arc_673  -14
    RHS1      connected_order_arc_675  -14
    RHS1      connected_order_arc_677  -14
    RHS1      connected_order_arc_679  -14
    RHS1      connected_order_arc_681  -14
    RHS1      connected_order_arc_683  -14
    RHS1      connected_order_arc_685  -14
    RHS1      connected_order_arc_687  -14
    RHS1      connected_order_arc_689  -14
    RHS1      connected_order_arc_691  -14
    RHS1      connected_order_arc_694  -14
    RHS1      connected_order_arc_696  -14
    RHS1      connected_order_arc_698  -14
    RHS1      connected_order_arc_700  -14
    RHS1      connected_order_arc_702  -14
    RHS1      connected_order_arc_704  -14
    RHS1      connected_order_arc_706  -14
    RHS1      connected_order_arc_708  -14
    RHS1      connected_order_arc_710  -14
    RHS1      connected_order_arc_712  -14
    RHS1      connected_order_arc_714  -14
    RHS1      connected_order_arc_716  -14
    RHS1      connected_order_arc_718  -14
    RHS1      connected_order_arc_721  -14
    RHS1      connected_order_arc_723  -14
    RHS1      connected_order_arc_725  -14
    RHS1      connected_order_arc_727  -14
    RHS1      connected_order_arc_729  -14
    RHS1      connected_order_arc_731  -14
    RHS1      connected_order_arc_733  -14
    RHS1      connected_order_arc_735  -14
    RHS1      connected_order_arc_737  -14
    RHS1      connected_order_arc_739  -14
    RHS1      connected_order_arc_741  -14
    RHS1      connected_order_arc_743  -14
    RHS1      connected_order_arc_745  -14
    RHS1      depot_departure_or_bypass_746  1
    RHS1      depot_return_or_bypass_747  1
    RHS1      segment_load_conservation_752  3
    RHS1      segment_prefix_ub_754  27
    RHS1      segment_load_conservation_759  -3
    RHS1      segment_prefix_lb_760  3
    RHS1      segment_prefix_ub_761  30
    RHS1      segment_load_conservation_766  4
    RHS1      segment_prefix_ub_768  26
    RHS1      segment_load_conservation_773  -1
    RHS1      segment_prefix_lb_774  1
    RHS1      segment_prefix_ub_775  30
    RHS1      segment_load_conservation_780  -1
    RHS1      segment_prefix_lb_781  1
    RHS1      segment_prefix_ub_782  30
    RHS1      segment_load_conservation_787  -2
    RHS1      segment_prefix_lb_788  2
    RHS1      segment_prefix_ub_789  30
    RHS1      fixed_segment_relative_order_838  1
    RHS1      fixed_segment_relative_order_839  1
    RHS1      fixed_segment_relative_order_840  1
    RHS1      fixed_segment_relative_order_841  1
    RHS1      fixed_segment_relative_order_842  1
    RHS1      original_T_including_depot_unload_843  3960
    RHS1      connected_order_arc_859  -12
    RHS1      connected_order_arc_861  -12
    RHS1      connected_order_arc_863  -12
    RHS1      connected_order_arc_865  -12
    RHS1      connected_order_arc_867  -12
    RHS1      connected_order_arc_869  -12
    RHS1      connected_order_arc_871  -12
    RHS1      connected_order_arc_873  -12
    RHS1      connected_order_arc_875  -12
    RHS1      connected_order_arc_877  -12
    RHS1      connected_order_arc_879  -12
    RHS1      connected_order_arc_882  -12
    RHS1      connected_order_arc_884  -12
    RHS1      connected_order_arc_886  -12
    RHS1      connected_order_arc_888  -12
    RHS1      connected_order_arc_890  -12
    RHS1      connected_order_arc_892  -12
    RHS1      connected_order_arc_894  -12
    RHS1      connected_order_arc_896  -12
    RHS1      connected_order_arc_898  -12
    RHS1      connected_order_arc_900  -12
    RHS1      connected_order_arc_902  -12
    RHS1      connected_order_arc_905  -12
    RHS1      connected_order_arc_907  -12
    RHS1      connected_order_arc_909  -12
    RHS1      connected_order_arc_911  -12
    RHS1      connected_order_arc_913  -12
    RHS1      connected_order_arc_915  -12
    RHS1      connected_order_arc_917  -12
    RHS1      connected_order_arc_919  -12
    RHS1      connected_order_arc_921  -12
    RHS1      connected_order_arc_923  -12
    RHS1      connected_order_arc_925  -12
    RHS1      connected_order_arc_928  -12
    RHS1      connected_order_arc_930  -12
    RHS1      connected_order_arc_932  -12
    RHS1      connected_order_arc_934  -12
    RHS1      connected_order_arc_936  -12
    RHS1      connected_order_arc_938  -12
    RHS1      connected_order_arc_940  -12
    RHS1      connected_order_arc_942  -12
    RHS1      connected_order_arc_944  -12
    RHS1      connected_order_arc_946  -12
    RHS1      connected_order_arc_948  -12
    RHS1      connected_order_arc_951  -12
    RHS1      connected_order_arc_953  -12
    RHS1      connected_order_arc_955  -12
    RHS1      connected_order_arc_957  -12
    RHS1      connected_order_arc_959  -12
    RHS1      connected_order_arc_961  -12
    RHS1      connected_order_arc_963  -12
    RHS1      connected_order_arc_965  -12
    RHS1      connected_order_arc_967  -12
    RHS1      connected_order_arc_969  -12
    RHS1      connected_order_arc_971  -12
    RHS1      connected_order_arc_974  -12
    RHS1      connected_order_arc_976  -12
    RHS1      connected_order_arc_978  -12
    RHS1      connected_order_arc_980  -12
    RHS1      connected_order_arc_982  -12
    RHS1      connected_order_arc_984  -12
    RHS1      connected_order_arc_986  -12
    RHS1      connected_order_arc_988  -12
    RHS1      connected_order_arc_990  -12
    RHS1      connected_order_arc_992  -12
    RHS1      connected_order_arc_994  -12
    RHS1      connected_order_arc_997  -12
    RHS1      connected_order_arc_999  -12
    RHS1      connected_order_arc_1001  -12
    RHS1      connected_order_arc_1003  -12
    RHS1      connected_order_arc_1005  -12
    RHS1      connected_order_arc_1007  -12
    RHS1      connected_order_arc_1009  -12
    RHS1      connected_order_arc_1011  -12
    RHS1      connected_order_arc_1013  -12
    RHS1      connected_order_arc_1015  -12
    RHS1      connected_order_arc_1017  -12
    RHS1      connected_order_arc_1020  -12
    RHS1      connected_order_arc_1022  -12
    RHS1      connected_order_arc_1024  -12
    RHS1      connected_order_arc_1026  -12
    RHS1      connected_order_arc_1028  -12
    RHS1      connected_order_arc_1030  -12
    RHS1      connected_order_arc_1032  -12
    RHS1      connected_order_arc_1034  -12
    RHS1      connected_order_arc_1036  -12
    RHS1      connected_order_arc_1038  -12
    RHS1      connected_order_arc_1040  -12
    RHS1      connected_order_arc_1043  -12
    RHS1      connected_order_arc_1045  -12
    RHS1      connected_order_arc_1047  -12
    RHS1      connected_order_arc_1049  -12
    RHS1      connected_order_arc_1051  -12
    RHS1      connected_order_arc_1053  -12
    RHS1      connected_order_arc_1055  -12
    RHS1      connected_order_arc_1057  -12
    RHS1      connected_order_arc_1059  -12
    RHS1      connected_order_arc_1061  -12
    RHS1      connected_order_arc_1063  -12
    RHS1      connected_order_arc_1066  -12
    RHS1      connected_order_arc_1068  -12
    RHS1      connected_order_arc_1070  -12
    RHS1      connected_order_arc_1072  -12
    RHS1      connected_order_arc_1074  -12
    RHS1      connected_order_arc_1076  -12
    RHS1      connected_order_arc_1078  -12
    RHS1      connected_order_arc_1080  -12
    RHS1      connected_order_arc_1082  -12
    RHS1      connected_order_arc_1084  -12
    RHS1      connected_order_arc_1086  -12
    RHS1      connected_order_arc_1089  -12
    RHS1      connected_order_arc_1091  -12
    RHS1      connected_order_arc_1093  -12
    RHS1      connected_order_arc_1095  -12
    RHS1      connected_order_arc_1097  -12
    RHS1      connected_order_arc_1099  -12
    RHS1      connected_order_arc_1101  -12
    RHS1      connected_order_arc_1103  -12
    RHS1      connected_order_arc_1105  -12
    RHS1      connected_order_arc_1107  -12
    RHS1      connected_order_arc_1109  -12
    RHS1      connected_order_arc_1112  -12
    RHS1      connected_order_arc_1114  -12
    RHS1      connected_order_arc_1116  -12
    RHS1      connected_order_arc_1118  -12
    RHS1      connected_order_arc_1120  -12
    RHS1      connected_order_arc_1122  -12
    RHS1      connected_order_arc_1124  -12
    RHS1      connected_order_arc_1126  -12
    RHS1      connected_order_arc_1128  -12
    RHS1      connected_order_arc_1130  -12
    RHS1      connected_order_arc_1132  -12
    RHS1      depot_departure_or_bypass_1133  1
    RHS1      depot_return_or_bypass_1134  1
    RHS1      segment_load_conservation_1139  4
    RHS1      segment_prefix_ub_1141  26
    RHS1      segment_load_conservation_1146  -1
    RHS1      segment_prefix_lb_1147  1
    RHS1      segment_prefix_ub_1148  30
    RHS1      segment_load_conservation_1153  -1
    RHS1      segment_prefix_lb_1154  1
    RHS1      segment_prefix_ub_1155  30
    RHS1      segment_load_conservation_1160  -1
    RHS1      segment_prefix_lb_1161  1
    RHS1      segment_prefix_ub_1162  30
    RHS1      fixed_segment_relative_order_1211  1
    RHS1      fixed_segment_relative_order_1212  1
    RHS1      fixed_segment_relative_order_1213  1
    RHS1      original_T_including_depot_unload_1214  4320
BOUNDS
 LO BND1      t         0.040634019704234
 UP BND1      t         1.0756819054947372e-01
 UP BND1      q         0.753053928089682
 BV BND1      x_18_0  
 UP BND1      w_18_0    1.0756819054947372e-01
 BV BND1      x_18_1  
 UP BND1      w_18_1    1.0756819054947372e-01
 BV BND1      x_18_2  
 UP BND1      w_18_2    1.0756819054947372e-01
 BV BND1      x_18_3  
 UP BND1      w_18_3    1.0756819054947372e-01
 BV BND1      x_18_4  
 UP BND1      w_18_4    1.0756819054947372e-01
 BV BND1      x_18_5  
 UP BND1      w_18_5    1.0756819054947372e-01
 BV BND1      x_18_6  
 UP BND1      w_18_6    1.0756819054947372e-01
 BV BND1      x_18_7  
 UP BND1      w_18_7    1.0756819054947372e-01
 BV BND1      x_18_8  
 UP BND1      w_18_8    1.0756819054947372e-01
 BV BND1      x_18_9  
 UP BND1      w_18_9    1.0756819054947372e-01
 BV BND1      x_18_10 
 UP BND1      w_18_10   1.0756819054947372e-01
 BV BND1      x_18_11 
 UP BND1      w_18_11   1.0756819054947372e-01
 BV BND1      x_18_12 
 UP BND1      w_18_12   1.0756819054947372e-01
 BV BND1      x_18_13 
 UP BND1      w_18_13   1.0756819054947372e-01
 BV BND1      x_18_14 
 UP BND1      w_18_14   1.0756819054947372e-01
 BV BND1      x_18_15 
 UP BND1      w_18_15   1.0756819054947372e-01
 UP BND1      rho_18    1
 BV BND1      x_15_0  
 UP BND1      w_15_0    1.0756819054947372e-01
 BV BND1      x_15_1  
 UP BND1      w_15_1    1.0756819054947372e-01
 UP BND1      rho_15    1
 BV BND1      x_17_0  
 UP BND1      w_17_0    1.0756819054947372e-01
 BV BND1      x_17_1  
 UP BND1      w_17_1    1.0756819054947372e-01
 BV BND1      x_17_2  
 UP BND1      w_17_2    1.0756819054947372e-01
 BV BND1      x_17_3  
 UP BND1      w_17_3    1.0756819054947372e-01
 BV BND1      x_17_4  
 UP BND1      w_17_4    1.0756819054947372e-01
 BV BND1      x_17_5  
 UP BND1      w_17_5    1.0756819054947372e-01
 BV BND1      x_17_6  
 UP BND1      w_17_6    1.0756819054947372e-01
 BV BND1      x_17_7  
 UP BND1      w_17_7    1.0756819054947372e-01
 BV BND1      x_17_8  
 UP BND1      w_17_8    1.0756819054947372e-01
 BV BND1      x_17_9  
 UP BND1      w_17_9    1.0756819054947372e-01
 BV BND1      x_17_10 
 UP BND1      w_17_10   1.0756819054947372e-01
 BV BND1      x_17_11 
 UP BND1      w_17_11   1.0756819054947372e-01
 BV BND1      x_17_12 
 UP BND1      w_17_12   1.0756819054947372e-01
 BV BND1      x_17_13 
 UP BND1      w_17_13   1.0756819054947372e-01
 BV BND1      x_17_14 
 UP BND1      w_17_14   1.0756819054947372e-01
 BV BND1      x_17_15 
 UP BND1      w_17_15   1.0756819054947372e-01
 BV BND1      x_17_16 
 UP BND1      w_17_16   1.0756819054947372e-01
 UP BND1      rho_17    1
 BV BND1      x_16_0  
 UP BND1      w_16_0    1.0756819054947372e-01
 BV BND1      x_16_1  
 UP BND1      w_16_1    1.0756819054947372e-01
 BV BND1      x_16_2  
 UP BND1      w_16_2    1.0756819054947372e-01
 UP BND1      rho_16    1
 BV BND1      x_20_0  
 UP BND1      w_20_0    1.0756819054947372e-01
 BV BND1      x_20_1  
 UP BND1      w_20_1    1.0756819054947372e-01
 BV BND1      x_20_2  
 UP BND1      w_20_2    1.0756819054947372e-01
 BV BND1      x_20_3  
 UP BND1      w_20_3    1.0756819054947372e-01
 BV BND1      x_20_4  
 UP BND1      w_20_4    1.0756819054947372e-01
 BV BND1      x_20_5  
 UP BND1      w_20_5    1.0756819054947372e-01
 BV BND1      x_20_6  
 UP BND1      w_20_6    1.0756819054947372e-01
 BV BND1      x_20_7  
 UP BND1      w_20_7    1.0756819054947372e-01
 BV BND1      x_20_8  
 UP BND1      w_20_8    1.0756819054947372e-01
 BV BND1      x_20_9  
 UP BND1      w_20_9    1.0756819054947372e-01
 BV BND1      x_20_10 
 UP BND1      w_20_10   1.0756819054947372e-01
 BV BND1      x_20_11 
 UP BND1      w_20_11   1.0756819054947372e-01
 BV BND1      x_20_12 
 UP BND1      w_20_12   1.0756819054947372e-01
 BV BND1      x_20_13 
 UP BND1      w_20_13   1.0756819054947372e-01
 BV BND1      x_20_14 
 UP BND1      w_20_14   1.0756819054947372e-01
 BV BND1      x_20_15 
 UP BND1      w_20_15   1.0756819054947372e-01
 UP BND1      rho_20    1
 BV BND1      x_19_0  
 UP BND1      w_19_0    1.0756819054947372e-01
 BV BND1      x_19_1  
 UP BND1      w_19_1    1.0756819054947372e-01
 BV BND1      x_19_2  
 UP BND1      w_19_2    1.0756819054947372e-01
 BV BND1      x_19_3  
 UP BND1      w_19_3    1.0756819054947372e-01
 BV BND1      x_19_4  
 UP BND1      w_19_4    1.0756819054947372e-01
 BV BND1      x_19_5  
 UP BND1      w_19_5    1.0756819054947372e-01
 UP BND1      rho_19    1
 BV BND1      x_11_0  
 UP BND1      w_11_0    1.0756819054947372e-01
 BV BND1      x_11_1  
 UP BND1      w_11_1    1.0756819054947372e-01
 BV BND1      x_11_2  
 UP BND1      w_11_2    1.0756819054947372e-01
 BV BND1      x_11_3  
 UP BND1      w_11_3    1.0756819054947372e-01
 BV BND1      x_11_4  
 UP BND1      w_11_4    1.0756819054947372e-01
 BV BND1      x_11_5  
 UP BND1      w_11_5    1.0756819054947372e-01
 BV BND1      x_11_6  
 UP BND1      w_11_6    1.0756819054947372e-01
 BV BND1      x_11_7  
 UP BND1      w_11_7    1.0756819054947372e-01
 BV BND1      x_11_8  
 UP BND1      w_11_8    1.0756819054947372e-01
 BV BND1      x_11_9  
 UP BND1      w_11_9    1.0756819054947372e-01
 BV BND1      x_11_10 
 UP BND1      w_11_10   1.0756819054947372e-01
 BV BND1      x_11_11 
 UP BND1      w_11_11   1.0756819054947372e-01
 BV BND1      x_11_12 
 UP BND1      w_11_12   1.0756819054947372e-01
 BV BND1      x_11_13 
 UP BND1      w_11_13   1.0756819054947372e-01
 BV BND1      x_11_14 
 UP BND1      w_11_14   1.0756819054947372e-01
 BV BND1      x_11_15 
 UP BND1      w_11_15   1.0756819054947372e-01
 UP BND1      rho_11    1
 BV BND1      x_12_0  
 UP BND1      w_12_0    1.0756819054947372e-01
 BV BND1      x_12_1  
 UP BND1      w_12_1    1.0756819054947372e-01
 BV BND1      x_12_2  
 UP BND1      w_12_2    1.0756819054947372e-01
 BV BND1      x_12_3  
 UP BND1      w_12_3    1.0756819054947372e-01
 BV BND1      x_12_4  
 UP BND1      w_12_4    1.0756819054947372e-01
 BV BND1      x_12_5  
 UP BND1      w_12_5    1.0756819054947372e-01
 BV BND1      x_12_6  
 UP BND1      w_12_6    1.0756819054947372e-01
 BV BND1      x_12_7  
 UP BND1      w_12_7    1.0756819054947372e-01
 BV BND1      x_12_8  
 UP BND1      w_12_8    1.0756819054947372e-01
 BV BND1      x_12_9  
 UP BND1      w_12_9    1.0756819054947372e-01
 BV BND1      x_12_10 
 UP BND1      w_12_10   1.0756819054947372e-01
 BV BND1      x_12_11 
 UP BND1      w_12_11   1.0756819054947372e-01
 BV BND1      x_12_12 
 UP BND1      w_12_12   1.0756819054947372e-01
 BV BND1      x_12_13 
 UP BND1      w_12_13   1.0756819054947372e-01
 BV BND1      x_12_14 
 UP BND1      w_12_14   1.0756819054947372e-01
 BV BND1      x_12_15 
 UP BND1      w_12_15   1.0756819054947372e-01
 UP BND1      rho_12    1
 UP BND1      a_18_15   1
 UP BND1      a_18_17   1
 UP BND1      a_18_16   1
 UP BND1      a_18_20   1
 UP BND1      a_18_19   1
 UP BND1      a_18_11   1
 UP BND1      a_18_12   1
 UP BND1      a_15_17   1
 UP BND1      a_15_16   1
 UP BND1      a_15_20   1
 UP BND1      a_15_19   1
 UP BND1      a_15_11   1
 UP BND1      a_15_12   1
 UP BND1      a_17_16   1
 UP BND1      a_17_20   1
 UP BND1      a_17_19   1
 UP BND1      a_17_11   1
 UP BND1      a_17_12   1
 UP BND1      a_16_20   1
 UP BND1      a_16_19   1
 UP BND1      a_16_11   1
 UP BND1      a_16_12   1
 UP BND1      a_20_19   1
 UP BND1      a_20_11   1
 UP BND1      a_20_12   1
 UP BND1      a_19_11   1
 UP BND1      a_19_12   1
 UP BND1      a_11_12   1
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_8
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_0_18_11
 BV BND1      service_0_18_12
 BV BND1      service_0_18_13
 BV BND1      service_0_18_14
 BV BND1      service_0_18_15
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_8
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_1_18_11
 BV BND1      service_1_18_12
 BV BND1      service_1_18_13
 BV BND1      service_1_18_14
 BV BND1      service_1_18_15
 BV BND1      service_0_15_1
 BV BND1      service_1_15_1
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_0_20_0
 BV BND1      service_0_20_1
 BV BND1      service_0_20_2
 BV BND1      service_0_20_3
 BV BND1      service_0_20_4
 BV BND1      service_0_20_5
 BV BND1      service_0_20_6
 BV BND1      service_0_20_7
 BV BND1      service_0_20_8
 BV BND1      service_0_20_9
 BV BND1      service_0_20_10
 BV BND1      service_0_20_11
 BV BND1      service_0_20_13
 BV BND1      service_0_20_14
 BV BND1      service_0_20_15
 BV BND1      service_1_20_0
 BV BND1      service_1_20_1
 BV BND1      service_1_20_2
 BV BND1      service_1_20_3
 BV BND1      service_1_20_4
 BV BND1      service_1_20_5
 BV BND1      service_1_20_6
 BV BND1      service_1_20_7
 BV BND1      service_1_20_8
 BV BND1      service_1_20_9
 BV BND1      service_1_20_10
 BV BND1      service_1_20_11
 BV BND1      service_1_20_13
 BV BND1      service_1_20_14
 BV BND1      service_1_20_15
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_0_11_0
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_7
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_0_11_13
 BV BND1      service_0_11_14
 BV BND1      service_0_11_15
 BV BND1      service_1_11_0
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_7
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_1_11_13
 BV BND1      service_1_11_14
 BV BND1      service_1_11_15
 BV BND1      service_0_12_0
 BV BND1      service_0_12_1
 BV BND1      service_0_12_2
 BV BND1      service_0_12_3
 BV BND1      service_0_12_4
 BV BND1      service_0_12_5
 BV BND1      service_0_12_6
 BV BND1      service_0_12_7
 BV BND1      service_0_12_8
 BV BND1      service_0_12_9
 BV BND1      service_0_12_10
 BV BND1      service_0_12_12
 BV BND1      service_0_12_13
 BV BND1      service_0_12_14
 BV BND1      service_0_12_15
 BV BND1      service_1_12_0
 BV BND1      service_1_12_1
 BV BND1      service_1_12_2
 BV BND1      service_1_12_3
 BV BND1      service_1_12_4
 BV BND1      service_1_12_5
 BV BND1      service_1_12_6
 BV BND1      service_1_12_7
 BV BND1      service_1_12_8
 BV BND1      service_1_12_9
 BV BND1      service_1_12_10
 BV BND1      service_1_12_12
 BV BND1      service_1_12_13
 BV BND1      service_1_12_14
 BV BND1      service_1_12_15
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_11  1
 UP BND1      order_0_11  14
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  14
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  14
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  14
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  14
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  14
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  14
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_11
 FX BND1      load_0_0_11  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  30
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  30
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  30
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  30
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  30
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  30
 BV BND1      arc_0_1_11
 UP BND1      load_0_1_11  30
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  30
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  30
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  30
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  30
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  30
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  30
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  30
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  30
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  30
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  30
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  30
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  30
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  30
 BV BND1      arc_0_2_11
 UP BND1      load_0_2_11  30
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  30
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  30
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  30
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  30
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  30
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  30
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  30
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  30
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  30
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  30
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  30
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  30
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  30
 BV BND1      arc_0_3_11
 UP BND1      load_0_3_11  30
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  30
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  30
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  30
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  30
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  30
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  30
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  30
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  30
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  30
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  30
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  30
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  30
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  30
 BV BND1      arc_0_4_11
 UP BND1      load_0_4_11  30
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  30
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  30
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  30
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  30
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  30
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  30
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  30
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  30
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  30
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  30
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  30
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  30
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  30
 BV BND1      arc_0_5_11
 UP BND1      load_0_5_11  30
 BV BND1      arc_0_5_12
 UP BND1      load_0_5_12  30
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  30
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  30
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  30
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  30
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  30
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  30
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  30
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  30
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  30
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  30
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  30
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  30
 BV BND1      arc_0_6_11
 UP BND1      load_0_6_11  30
 BV BND1      arc_0_6_12
 UP BND1      load_0_6_12  30
 BV BND1      arc_0_6_13
 UP BND1      load_0_6_13  30
 BV BND1      arc_0_6_14
 UP BND1      load_0_6_14  30
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  30
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  30
 BV BND1      arc_0_6_17
 UP BND1      load_0_6_17  30
 BV BND1      arc_0_6_18
 UP BND1      load_0_6_18  30
 BV BND1      arc_0_11_0
 UP BND1      load_0_11_0  30
 BV BND1      arc_0_11_1
 UP BND1      load_0_11_1  30
 BV BND1      arc_0_11_2
 UP BND1      load_0_11_2  30
 BV BND1      arc_0_11_3
 UP BND1      load_0_11_3  30
 BV BND1      arc_0_11_4
 UP BND1      load_0_11_4  30
 BV BND1      arc_0_11_5
 UP BND1      load_0_11_5  30
 BV BND1      arc_0_11_6
 UP BND1      load_0_11_6  30
 BV BND1      arc_0_11_12
 UP BND1      load_0_11_12  30
 BV BND1      arc_0_11_13
 UP BND1      load_0_11_13  30
 BV BND1      arc_0_11_14
 UP BND1      load_0_11_14  30
 BV BND1      arc_0_11_15
 UP BND1      load_0_11_15  30
 BV BND1      arc_0_11_16
 UP BND1      load_0_11_16  30
 BV BND1      arc_0_11_17
 UP BND1      load_0_11_17  30
 BV BND1      arc_0_11_18
 UP BND1      load_0_11_18  30
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  30
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  30
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  30
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  30
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  30
 BV BND1      arc_0_12_5
 UP BND1      load_0_12_5  30
 BV BND1      arc_0_12_6
 UP BND1      load_0_12_6  30
 BV BND1      arc_0_12_11
 UP BND1      load_0_12_11  30
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  30
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  30
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  30
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  30
 BV BND1      arc_0_12_17
 UP BND1      load_0_12_17  30
 BV BND1      arc_0_12_18
 UP BND1      load_0_12_18  30
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  30
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  30
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  30
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  30
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  30
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  30
 BV BND1      arc_0_13_6
 UP BND1      load_0_13_6  30
 BV BND1      arc_0_13_11
 UP BND1      load_0_13_11  30
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  30
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  30
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  30
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  30
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  30
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  30
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  30
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  30
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  30
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  30
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  30
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  30
 BV BND1      arc_0_14_6
 UP BND1      load_0_14_6  30
 BV BND1      arc_0_14_11
 UP BND1      load_0_14_11  30
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  30
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  30
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  30
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  30
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  30
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  30
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  30
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  30
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  30
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  30
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  30
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  30
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  30
 BV BND1      arc_0_15_11
 UP BND1      load_0_15_11  30
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  30
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  30
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  30
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  30
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  30
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  30
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  30
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  30
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  30
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  30
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  30
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  30
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  30
 BV BND1      arc_0_16_11
 UP BND1      load_0_16_11  30
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  30
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  30
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  30
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  30
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  30
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  30
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  30
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  30
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  30
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  30
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  30
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  30
 BV BND1      arc_0_17_6
 UP BND1      load_0_17_6  30
 BV BND1      arc_0_17_11
 UP BND1      load_0_17_11  30
 BV BND1      arc_0_17_12
 UP BND1      load_0_17_12  30
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  30
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  30
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  30
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  30
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  30
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  30
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  30
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  30
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  30
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  30
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  30
 BV BND1      arc_0_18_6
 UP BND1      load_0_18_6  30
 BV BND1      arc_0_18_11
 UP BND1      load_0_18_11  30
 BV BND1      arc_0_18_12
 UP BND1      load_0_18_12  30
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  30
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  30
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  30
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  30
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  30
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  12
 UP BND1      visit_1_11  1
 UP BND1      order_1_11  12
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  30
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  30
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  30
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  30
 BV BND1      arc_1_7_11
 UP BND1      load_1_7_11  30
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  30
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  30
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  30
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  30
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  30
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  30
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  30
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  30
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  30
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  30
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  30
 BV BND1      arc_1_8_11
 UP BND1      load_1_8_11  30
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  30
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  30
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  30
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  30
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  30
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  30
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  30
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  30
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  30
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  30
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  30
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  30
 BV BND1      arc_1_9_12
 UP BND1      load_1_9_12  30
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  30
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  30
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  30
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  30
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  30
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  30
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  30
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  30
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  30
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  30
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  30
 BV BND1      arc_1_10_12
 UP BND1      load_1_10_12  30
 BV BND1      arc_1_10_13
 UP BND1      load_1_10_13  30
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  30
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  30
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  30
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  30
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  30
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  30
 BV BND1      arc_1_11_7
 UP BND1      load_1_11_7  30
 BV BND1      arc_1_11_8
 UP BND1      load_1_11_8  30
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  30
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  30
 BV BND1      arc_1_11_12
 UP BND1      load_1_11_12  30
 BV BND1      arc_1_11_13
 UP BND1      load_1_11_13  30
 BV BND1      arc_1_11_14
 UP BND1      load_1_11_14  30
 BV BND1      arc_1_11_15
 UP BND1      load_1_11_15  30
 BV BND1      arc_1_11_16
 UP BND1      load_1_11_16  30
 BV BND1      arc_1_11_17
 UP BND1      load_1_11_17  30
 BV BND1      arc_1_11_18
 UP BND1      load_1_11_18  30
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  30
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  30
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  30
 BV BND1      arc_1_12_9
 UP BND1      load_1_12_9  30
 BV BND1      arc_1_12_10
 UP BND1      load_1_12_10  30
 BV BND1      arc_1_12_11
 UP BND1      load_1_12_11  30
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  30
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  30
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  30
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  30
 BV BND1      arc_1_12_17
 UP BND1      load_1_12_17  30
 BV BND1      arc_1_12_18
 UP BND1      load_1_12_18  30
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  30
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  30
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  30
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  30
 BV BND1      arc_1_13_10
 UP BND1      load_1_13_10  30
 BV BND1      arc_1_13_11
 UP BND1      load_1_13_11  30
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  30
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  30
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  30
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  30
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  30
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  30
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  30
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  30
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  30
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  30
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  30
 BV BND1      arc_1_14_11
 UP BND1      load_1_14_11  30
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  30
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  30
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  30
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  30
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  30
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  30
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  30
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  30
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  30
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  30
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  30
 BV BND1      arc_1_15_11
 UP BND1      load_1_15_11  30
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  30
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  30
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  30
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  30
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  30
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  30
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  30
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  30
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  30
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  30
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  30
 BV BND1      arc_1_16_11
 UP BND1      load_1_16_11  30
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  30
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  30
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  30
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  30
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  30
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  30
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  30
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  30
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  30
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  30
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  30
 BV BND1      arc_1_17_11
 UP BND1      load_1_17_11  30
 BV BND1      arc_1_17_12
 UP BND1      load_1_17_12  30
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  30
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  30
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  30
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  30
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  30
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  30
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  30
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  30
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  30
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  30
 BV BND1      arc_1_18_11
 UP BND1      load_1_18_11  30
 BV BND1      arc_1_18_12
 UP BND1      load_1_18_12  30
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  30
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  30
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  30
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  30
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  30
ENDATA
