* Signature: 0xf5307223ecd02f9a
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  mass_1  
 G  w_lb_1_0
 L  w_ub_1_0
 G  w_lb_1_1
 L  w_ub_1_1
 G  w_lb_1_2
 L  w_ub_1_2
 G  w_lb_1_3
 L  w_ub_1_3
 G  w_lb_1_4
 L  w_ub_1_4
 G  w_lb_1_5
 L  w_ub_1_5
 G  w_lb_1_6
 L  w_ub_1_6
 G  w_lb_1_7
 L  w_ub_1_7
 G  w_lb_1_8
 L  w_ub_1_8
 G  w_lb_1_9
 L  w_ub_1_9
 G  w_lb_1_10
 L  w_ub_1_10
 G  w_lb_1_11
 L  w_ub_1_11
 G  w_lb_1_12
 L  w_ub_1_12
 G  w_lb_1_13
 L  w_ub_1_13
 G  w_lb_1_14
 L  w_ub_1_14
 G  w_lb_1_15
 L  w_ub_1_15
 G  w_lb_1_16
 L  w_ub_1_16
 G  w_lb_1_17
 L  w_ub_1_17
 G  w_lb_1_18
 L  w_ub_1_18
 G  w_lb_1_19
 L  w_ub_1_19
 E  normalized_inventory_1
 E  normalized_ratio_1
 E  onehot_2
 E  mass_2  
 G  w_lb_2_0
 L  w_ub_2_0
 G  w_lb_2_1
 L  w_ub_2_1
 G  w_lb_2_2
 L  w_ub_2_2
 G  w_lb_2_3
 L  w_ub_2_3
 G  w_lb_2_4
 L  w_ub_2_4
 G  w_lb_2_5
 L  w_ub_2_5
 G  w_lb_2_6
 L  w_ub_2_6
 G  w_lb_2_7
 L  w_ub_2_7
 G  w_lb_2_8
 L  w_ub_2_8
 G  w_lb_2_9
 L  w_ub_2_9
 G  w_lb_2_10
 L  w_ub_2_10
 G  w_lb_2_11
 L  w_ub_2_11
 G  w_lb_2_12
 L  w_ub_2_12
 G  w_lb_2_13
 L  w_ub_2_13
 G  w_lb_2_14
 L  w_ub_2_14
 G  w_lb_2_15
 L  w_ub_2_15
 E  normalized_inventory_2
 E  normalized_ratio_2
 E  onehot_3
 E  mass_3  
 G  w_lb_3_0
 L  w_ub_3_0
 G  w_lb_3_1
 L  w_ub_3_1
 G  w_lb_3_2
 L  w_ub_3_2
 G  w_lb_3_3
 L  w_ub_3_3
 G  w_lb_3_4
 L  w_ub_3_4
 G  w_lb_3_5
 L  w_ub_3_5
 G  w_lb_3_6
 L  w_ub_3_6
 G  w_lb_3_7
 L  w_ub_3_7
 G  w_lb_3_8
 L  w_ub_3_8
 G  w_lb_3_9
 L  w_ub_3_9
 G  w_lb_3_10
 L  w_ub_3_10
 G  w_lb_3_11
 L  w_ub_3_11
 G  w_lb_3_12
 L  w_ub_3_12
 G  w_lb_3_13
 L  w_ub_3_13
 G  w_lb_3_14
 L  w_ub_3_14
 G  w_lb_3_15
 L  w_ub_3_15
 G  w_lb_3_16
 L  w_ub_3_16
 G  w_lb_3_17
 L  w_ub_3_17
 E  normalized_inventory_3
 E  normalized_ratio_3
 E  onehot_4
 E  mass_4  
 G  w_lb_4_0
 L  w_ub_4_0
 G  w_lb_4_1
 L  w_ub_4_1
 G  w_lb_4_2
 L  w_ub_4_2
 G  w_lb_4_3
 L  w_ub_4_3
 G  w_lb_4_4
 L  w_ub_4_4
 G  w_lb_4_5
 L  w_ub_4_5
 G  w_lb_4_6
 L  w_ub_4_6
 G  w_lb_4_7
 L  w_ub_4_7
 G  w_lb_4_8
 L  w_ub_4_8
 G  w_lb_4_9
 L  w_ub_4_9
 G  w_lb_4_10
 L  w_ub_4_10
 G  w_lb_4_11
 L  w_ub_4_11
 G  w_lb_4_12
 L  w_ub_4_12
 G  w_lb_4_13
 L  w_ub_4_13
 G  w_lb_4_14
 L  w_ub_4_14
 G  w_lb_4_15
 L  w_ub_4_15
 E  normalized_inventory_4
 E  normalized_ratio_4
 E  onehot_5
 E  mass_5  
 G  w_lb_5_0
 L  w_ub_5_0
 G  w_lb_5_1
 L  w_ub_5_1
 G  w_lb_5_2
 L  w_ub_5_2
 G  w_lb_5_3
 L  w_ub_5_3
 G  w_lb_5_4
 L  w_ub_5_4
 G  w_lb_5_5
 L  w_ub_5_5
 G  w_lb_5_6
 L  w_ub_5_6
 G  w_lb_5_7
 L  w_ub_5_7
 G  w_lb_5_8
 L  w_ub_5_8
 G  w_lb_5_9
 L  w_ub_5_9
 G  w_lb_5_10
 L  w_ub_5_10
 G  w_lb_5_11
 L  w_ub_5_11
 G  w_lb_5_12
 L  w_ub_5_12
 G  w_lb_5_13
 L  w_ub_5_13
 G  w_lb_5_14
 L  w_ub_5_14
 G  w_lb_5_15
 L  w_ub_5_15
 G  w_lb_5_16
 L  w_ub_5_16
 E  normalized_inventory_5
 E  normalized_ratio_5
 E  onehot_6
 E  mass_6  
 G  w_lb_6_0
 L  w_ub_6_0
 G  w_lb_6_1
 L  w_ub_6_1
 G  w_lb_6_2
 L  w_ub_6_2
 G  w_lb_6_3
 L  w_ub_6_3
 G  w_lb_6_4
 L  w_ub_6_4
 G  w_lb_6_5
 L  w_ub_6_5
 G  w_lb_6_6
 L  w_ub_6_6
 G  w_lb_6_7
 L  w_ub_6_7
 G  w_lb_6_8
 L  w_ub_6_8
 G  w_lb_6_9
 L  w_ub_6_9
 G  w_lb_6_10
 L  w_ub_6_10
 E  normalized_inventory_6
 E  normalized_ratio_6
 E  onehot_7
 E  mass_7  
 G  w_lb_7_0
 L  w_ub_7_0
 G  w_lb_7_1
 L  w_ub_7_1
 G  w_lb_7_2
 L  w_ub_7_2
 G  w_lb_7_3
 L  w_ub_7_3
 G  w_lb_7_4
 L  w_ub_7_4
 G  w_lb_7_5
 L  w_ub_7_5
 G  w_lb_7_6
 L  w_ub_7_6
 G  w_lb_7_7
 L  w_ub_7_7
 G  w_lb_7_8
 L  w_ub_7_8
 G  w_lb_7_9
 L  w_ub_7_9
 G  w_lb_7_10
 L  w_ub_7_10
 G  w_lb_7_11
 L  w_ub_7_11
 G  w_lb_7_12
 L  w_ub_7_12
 G  w_lb_7_13
 L  w_ub_7_13
 G  w_lb_7_14
 L  w_ub_7_14
 G  w_lb_7_15
 L  w_ub_7_15
 G  w_lb_7_16
 L  w_ub_7_16
 G  w_lb_7_17
 L  w_ub_7_17
 E  normalized_inventory_7
 E  normalized_ratio_7
 E  onehot_8
 E  mass_8  
 G  w_lb_8_0
 L  w_ub_8_0
 G  w_lb_8_1
 L  w_ub_8_1
 G  w_lb_8_2
 L  w_ub_8_2
 G  w_lb_8_3
 L  w_ub_8_3
 G  w_lb_8_4
 L  w_ub_8_4
 G  w_lb_8_5
 L  w_ub_8_5
 G  w_lb_8_6
 L  w_ub_8_6
 G  w_lb_8_7
 L  w_ub_8_7
 G  w_lb_8_8
 L  w_ub_8_8
 G  w_lb_8_9
 L  w_ub_8_9
 G  w_lb_8_10
 L  w_ub_8_10
 G  w_lb_8_11
 L  w_ub_8_11
 G  w_lb_8_12
 L  w_ub_8_12
 G  w_lb_8_13
 L  w_ub_8_13
 G  w_lb_8_14
 L  w_ub_8_14
 G  w_lb_8_15
 L  w_ub_8_15
 G  w_lb_8_16
 L  w_ub_8_16
 G  w_lb_8_17
 L  w_ub_8_17
 G  w_lb_8_18
 L  w_ub_8_18
 G  w_lb_8_19
 L  w_ub_8_19
 G  w_lb_8_20
 L  w_ub_8_20
 G  w_lb_8_21
 L  w_ub_8_21
 E  normalized_inventory_8
 E  normalized_ratio_8
 E  onehot_9
 E  mass_9  
 G  w_lb_9_0
 L  w_ub_9_0
 G  w_lb_9_1
 L  w_ub_9_1
 G  w_lb_9_2
 L  w_ub_9_2
 G  w_lb_9_3
 L  w_ub_9_3
 G  w_lb_9_4
 L  w_ub_9_4
 G  w_lb_9_5
 L  w_ub_9_5
 G  w_lb_9_6
 L  w_ub_9_6
 G  w_lb_9_7
 L  w_ub_9_7
 G  w_lb_9_8
 L  w_ub_9_8
 G  w_lb_9_9
 L  w_ub_9_9
 G  w_lb_9_10
 L  w_ub_9_10
 G  w_lb_9_11
 L  w_ub_9_11
 G  w_lb_9_12
 L  w_ub_9_12
 E  normalized_inventory_9
 E  normalized_ratio_9
 E  onehot_10
 E  mass_10 
 G  w_lb_10_0
 L  w_ub_10_0
 G  w_lb_10_1
 L  w_ub_10_1
 G  w_lb_10_2
 L  w_ub_10_2
 G  w_lb_10_3
 L  w_ub_10_3
 G  w_lb_10_4
 L  w_ub_10_4
 G  w_lb_10_5
 L  w_ub_10_5
 G  w_lb_10_6
 L  w_ub_10_6
 G  w_lb_10_7
 L  w_ub_10_7
 G  w_lb_10_8
 L  w_ub_10_8
 G  w_lb_10_9
 L  w_ub_10_9
 G  w_lb_10_10
 L  w_ub_10_10
 G  w_lb_10_11
 L  w_ub_10_11
 G  w_lb_10_12
 L  w_ub_10_12
 G  w_lb_10_13
 L  w_ub_10_13
 G  w_lb_10_14
 L  w_ub_10_14
 G  w_lb_10_15
 L  w_ub_10_15
 G  w_lb_10_16
 L  w_ub_10_16
 G  w_lb_10_17
 L  w_ub_10_17
 G  w_lb_10_18
 L  w_ub_10_18
 G  w_lb_10_19
 L  w_ub_10_19
 E  normalized_inventory_10
 E  normalized_ratio_10
 E  onehot_11
 E  mass_11 
 G  w_lb_11_0
 L  w_ub_11_0
 G  w_lb_11_1
 L  w_ub_11_1
 G  w_lb_11_2
 L  w_ub_11_2
 G  w_lb_11_3
 L  w_ub_11_3
 G  w_lb_11_4
 L  w_ub_11_4
 G  w_lb_11_5
 L  w_ub_11_5
 G  w_lb_11_6
 L  w_ub_11_6
 G  w_lb_11_7
 L  w_ub_11_7
 G  w_lb_11_8
 L  w_ub_11_8
 G  w_lb_11_9
 L  w_ub_11_9
 G  w_lb_11_10
 L  w_ub_11_10
 G  w_lb_11_11
 L  w_ub_11_11
 G  w_lb_11_12
 L  w_ub_11_12
 E  normalized_inventory_11
 E  normalized_ratio_11
 E  onehot_12
 E  mass_12 
 G  w_lb_12_0
 L  w_ub_12_0
 G  w_lb_12_1
 L  w_ub_12_1
 G  w_lb_12_2
 L  w_ub_12_2
 G  w_lb_12_3
 L  w_ub_12_3
 G  w_lb_12_4
 L  w_ub_12_4
 G  w_lb_12_5
 L  w_ub_12_5
 G  w_lb_12_6
 L  w_ub_12_6
 G  w_lb_12_7
 L  w_ub_12_7
 G  w_lb_12_8
 L  w_ub_12_8
 G  w_lb_12_9
 L  w_ub_12_9
 G  w_lb_12_10
 L  w_ub_12_10
 G  w_lb_12_11
 L  w_ub_12_11
 G  w_lb_12_12
 L  w_ub_12_12
 G  w_lb_12_13
 L  w_ub_12_13
 G  w_lb_12_14
 L  w_ub_12_14
 G  w_lb_12_15
 L  w_ub_12_15
 E  normalized_inventory_12
 E  normalized_ratio_12
 E  onehot_13
 E  mass_13 
 G  w_lb_13_0
 L  w_ub_13_0
 G  w_lb_13_1
 L  w_ub_13_1
 G  w_lb_13_2
 L  w_ub_13_2
 G  w_lb_13_3
 L  w_ub_13_3
 G  w_lb_13_4
 L  w_ub_13_4
 G  w_lb_13_5
 L  w_ub_13_5
 G  w_lb_13_6
 L  w_ub_13_6
 G  w_lb_13_7
 L  w_ub_13_7
 G  w_lb_13_8
 L  w_ub_13_8
 G  w_lb_13_9
 L  w_ub_13_9
 G  w_lb_13_10
 L  w_ub_13_10
 G  w_lb_13_11
 L  w_ub_13_11
 G  w_lb_13_12
 L  w_ub_13_12
 G  w_lb_13_13
 L  w_ub_13_13
 G  w_lb_13_14
 L  w_ub_13_14
 G  w_lb_13_15
 L  w_ub_13_15
 G  w_lb_13_16
 L  w_ub_13_16
 G  w_lb_13_17
 L  w_ub_13_17
 G  w_lb_13_18
 L  w_ub_13_18
 G  w_lb_13_19
 L  w_ub_13_19
 E  normalized_inventory_13
 E  normalized_ratio_13
 E  onehot_14
 E  mass_14 
 G  w_lb_14_0
 L  w_ub_14_0
 G  w_lb_14_1
 L  w_ub_14_1
 G  w_lb_14_2
 L  w_ub_14_2
 G  w_lb_14_3
 L  w_ub_14_3
 G  w_lb_14_4
 L  w_ub_14_4
 G  w_lb_14_5
 L  w_ub_14_5
 G  w_lb_14_6
 L  w_ub_14_6
 G  w_lb_14_7
 L  w_ub_14_7
 G  w_lb_14_8
 L  w_ub_14_8
 G  w_lb_14_9
 L  w_ub_14_9
 G  w_lb_14_10
 L  w_ub_14_10
 G  w_lb_14_11
 L  w_ub_14_11
 G  w_lb_14_12
 L  w_ub_14_12
 G  w_lb_14_13
 L  w_ub_14_13
 G  w_lb_14_14
 L  w_ub_14_14
 G  w_lb_14_15
 L  w_ub_14_15
 E  normalized_inventory_14
 E  normalized_ratio_14
 E  onehot_15
 E  mass_15 
 G  w_lb_15_0
 L  w_ub_15_0
 G  w_lb_15_1
 L  w_ub_15_1
 G  w_lb_15_2
 L  w_ub_15_2
 G  w_lb_15_3
 L  w_ub_15_3
 G  w_lb_15_4
 L  w_ub_15_4
 G  w_lb_15_5
 L  w_ub_15_5
 G  w_lb_15_6
 L  w_ub_15_6
 G  w_lb_15_7
 L  w_ub_15_7
 G  w_lb_15_8
 L  w_ub_15_8
 G  w_lb_15_9
 L  w_ub_15_9
 G  w_lb_15_10
 L  w_ub_15_10
 G  w_lb_15_11
 L  w_ub_15_11
 G  w_lb_15_12
 L  w_ub_15_12
 G  w_lb_15_13
 L  w_ub_15_13
 G  w_lb_15_14
 L  w_ub_15_14
 G  w_lb_15_15
 L  w_ub_15_15
 G  w_lb_15_16
 L  w_ub_15_16
 E  normalized_inventory_15
 E  normalized_ratio_15
 E  onehot_16
 E  mass_16 
 G  w_lb_16_0
 L  w_ub_16_0
 G  w_lb_16_1
 L  w_ub_16_1
 G  w_lb_16_2
 L  w_ub_16_2
 G  w_lb_16_3
 L  w_ub_16_3
 G  w_lb_16_4
 L  w_ub_16_4
 G  w_lb_16_5
 L  w_ub_16_5
 G  w_lb_16_6
 L  w_ub_16_6
 G  w_lb_16_7
 L  w_ub_16_7
 G  w_lb_16_8
 L  w_ub_16_8
 G  w_lb_16_9
 L  w_ub_16_9
 G  w_lb_16_10
 L  w_ub_16_10
 G  w_lb_16_11
 L  w_ub_16_11
 G  w_lb_16_12
 L  w_ub_16_12
 E  normalized_inventory_16
 E  normalized_ratio_16
 E  onehot_17
 E  mass_17 
 G  w_lb_17_0
 L  w_ub_17_0
 G  w_lb_17_1
 L  w_ub_17_1
 G  w_lb_17_2
 L  w_ub_17_2
 G  w_lb_17_3
 L  w_ub_17_3
 G  w_lb_17_4
 L  w_ub_17_4
 G  w_lb_17_5
 L  w_ub_17_5
 G  w_lb_17_6
 L  w_ub_17_6
 G  w_lb_17_7
 L  w_ub_17_7
 G  w_lb_17_8
 L  w_ub_17_8
 G  w_lb_17_9
 L  w_ub_17_9
 G  w_lb_17_10
 L  w_ub_17_10
 G  w_lb_17_11
 L  w_ub_17_11
 G  w_lb_17_12
 L  w_ub_17_12
 G  w_lb_17_13
 L  w_ub_17_13
 G  w_lb_17_14
 L  w_ub_17_14
 G  w_lb_17_15
 L  w_ub_17_15
 G  w_lb_17_16
 L  w_ub_17_16
 E  normalized_inventory_17
 E  normalized_ratio_17
 E  onehot_18
 E  mass_18 
 G  w_lb_18_0
 L  w_ub_18_0
 G  w_lb_18_1
 L  w_ub_18_1
 G  w_lb_18_2
 L  w_ub_18_2
 G  w_lb_18_3
 L  w_ub_18_3
 G  w_lb_18_4
 L  w_ub_18_4
 G  w_lb_18_5
 L  w_ub_18_5
 G  w_lb_18_6
 L  w_ub_18_6
 G  w_lb_18_7
 L  w_ub_18_7
 G  w_lb_18_8
 L  w_ub_18_8
 G  w_lb_18_9
 L  w_ub_18_9
 G  w_lb_18_10
 L  w_ub_18_10
 G  w_lb_18_11
 L  w_ub_18_11
 G  w_lb_18_12
 L  w_ub_18_12
 G  w_lb_18_13
 L  w_ub_18_13
 G  w_lb_18_14
 L  w_ub_18_14
 G  w_lb_18_15
 L  w_ub_18_15
 G  w_lb_18_16
 L  w_ub_18_16
 G  w_lb_18_17
 L  w_ub_18_17
 E  normalized_inventory_18
 E  normalized_ratio_18
 E  onehot_19
 E  mass_19 
 G  w_lb_19_0
 L  w_ub_19_0
 G  w_lb_19_1
 L  w_ub_19_1
 G  w_lb_19_2
 L  w_ub_19_2
 G  w_lb_19_3
 L  w_ub_19_3
 G  w_lb_19_4
 L  w_ub_19_4
 G  w_lb_19_5
 L  w_ub_19_5
 G  w_lb_19_6
 L  w_ub_19_6
 G  w_lb_19_7
 L  w_ub_19_7
 G  w_lb_19_8
 L  w_ub_19_8
 E  normalized_inventory_19
 E  normalized_ratio_19
 E  onehot_20
 E  mass_20 
 G  w_lb_20_0
 L  w_ub_20_0
 G  w_lb_20_1
 L  w_ub_20_1
 G  w_lb_20_2
 L  w_ub_20_2
 G  w_lb_20_3
 L  w_ub_20_3
 G  w_lb_20_4
 L  w_ub_20_4
 G  w_lb_20_5
 L  w_ub_20_5
 G  w_lb_20_6
 L  w_ub_20_6
 G  w_lb_20_7
 L  w_ub_20_7
 G  w_lb_20_8
 L  w_ub_20_8
 G  w_lb_20_9
 L  w_ub_20_9
 G  w_lb_20_10
 L  w_ub_20_10
 G  w_lb_20_11
 L  w_ub_20_11
 G  w_lb_20_12
 L  w_ub_20_12
 E  normalized_inventory_20
 E  normalized_ratio_20
 E  onehot_21
 E  mass_21 
 G  w_lb_21_0
 L  w_ub_21_0
 G  w_lb_21_1
 L  w_ub_21_1
 G  w_lb_21_2
 L  w_ub_21_2
 G  w_lb_21_3
 L  w_ub_21_3
 G  w_lb_21_4
 L  w_ub_21_4
 G  w_lb_21_5
 L  w_ub_21_5
 G  w_lb_21_6
 L  w_ub_21_6
 G  w_lb_21_7
 L  w_ub_21_7
 G  w_lb_21_8
 L  w_ub_21_8
 G  w_lb_21_9
 L  w_ub_21_9
 G  w_lb_21_10
 L  w_ub_21_10
 G  w_lb_21_11
 L  w_ub_21_11
 G  w_lb_21_12
 L  w_ub_21_12
 G  w_lb_21_13
 L  w_ub_21_13
 G  w_lb_21_14
 L  w_ub_21_14
 G  w_lb_21_15
 L  w_ub_21_15
 E  normalized_inventory_21
 E  normalized_ratio_21
 E  onehot_22
 E  mass_22 
 G  w_lb_22_0
 L  w_ub_22_0
 G  w_lb_22_1
 L  w_ub_22_1
 G  w_lb_22_2
 L  w_ub_22_2
 G  w_lb_22_3
 L  w_ub_22_3
 G  w_lb_22_4
 L  w_ub_22_4
 G  w_lb_22_5
 L  w_ub_22_5
 G  w_lb_22_6
 L  w_ub_22_6
 G  w_lb_22_7
 L  w_ub_22_7
 G  w_lb_22_8
 L  w_ub_22_8
 G  w_lb_22_9
 L  w_ub_22_9
 G  w_lb_22_10
 L  w_ub_22_10
 G  w_lb_22_11
 L  w_ub_22_11
 G  w_lb_22_12
 L  w_ub_22_12
 E  normalized_inventory_22
 E  normalized_ratio_22
 E  onehot_23
 E  mass_23 
 G  w_lb_23_0
 L  w_ub_23_0
 G  w_lb_23_1
 L  w_ub_23_1
 G  w_lb_23_2
 L  w_ub_23_2
 G  w_lb_23_3
 L  w_ub_23_3
 G  w_lb_23_4
 L  w_ub_23_4
 G  w_lb_23_5
 L  w_ub_23_5
 G  w_lb_23_6
 L  w_ub_23_6
 G  w_lb_23_7
 L  w_ub_23_7
 G  w_lb_23_8
 L  w_ub_23_8
 G  w_lb_23_9
 L  w_ub_23_9
 G  w_lb_23_10
 L  w_ub_23_10
 G  w_lb_23_11
 L  w_ub_23_11
 E  normalized_inventory_23
 E  normalized_ratio_23
 E  onehot_24
 E  mass_24 
 G  w_lb_24_0
 L  w_ub_24_0
 G  w_lb_24_1
 L  w_ub_24_1
 G  w_lb_24_2
 L  w_ub_24_2
 G  w_lb_24_3
 L  w_ub_24_3
 G  w_lb_24_4
 L  w_ub_24_4
 G  w_lb_24_5
 L  w_ub_24_5
 G  w_lb_24_6
 L  w_ub_24_6
 G  w_lb_24_7
 L  w_ub_24_7
 G  w_lb_24_8
 L  w_ub_24_8
 G  w_lb_24_9
 L  w_ub_24_9
 G  w_lb_24_10
 L  w_ub_24_10
 G  w_lb_24_11
 L  w_ub_24_11
 G  w_lb_24_12
 L  w_ub_24_12
 G  w_lb_24_13
 L  w_ub_24_13
 G  w_lb_24_14
 L  w_ub_24_14
 G  w_lb_24_15
 L  w_ub_24_15
 E  normalized_inventory_24
 E  normalized_ratio_24
 E  onehot_25
 E  mass_25 
 G  w_lb_25_0
 L  w_ub_25_0
 G  w_lb_25_1
 L  w_ub_25_1
 G  w_lb_25_2
 L  w_ub_25_2
 G  w_lb_25_3
 L  w_ub_25_3
 G  w_lb_25_4
 L  w_ub_25_4
 G  w_lb_25_5
 L  w_ub_25_5
 G  w_lb_25_6
 L  w_ub_25_6
 G  w_lb_25_7
 L  w_ub_25_7
 G  w_lb_25_8
 L  w_ub_25_8
 G  w_lb_25_9
 L  w_ub_25_9
 G  w_lb_25_10
 L  w_ub_25_10
 G  w_lb_25_11
 L  w_ub_25_11
 G  w_lb_25_12
 L  w_ub_25_12
 G  w_lb_25_13
 L  w_ub_25_13
 G  w_lb_25_14
 L  w_ub_25_14
 G  w_lb_25_15
 L  w_ub_25_15
 E  normalized_inventory_25
 E  normalized_ratio_25
 E  onehot_26
 E  mass_26 
 G  w_lb_26_0
 L  w_ub_26_0
 G  w_lb_26_1
 L  w_ub_26_1
 G  w_lb_26_2
 L  w_ub_26_2
 G  w_lb_26_3
 L  w_ub_26_3
 G  w_lb_26_4
 L  w_ub_26_4
 G  w_lb_26_5
 L  w_ub_26_5
 G  w_lb_26_6
 L  w_ub_26_6
 G  w_lb_26_7
 L  w_ub_26_7
 G  w_lb_26_8
 L  w_ub_26_8
 E  normalized_inventory_26
 E  normalized_ratio_26
 E  onehot_27
 E  mass_27 
 G  w_lb_27_0
 L  w_ub_27_0
 G  w_lb_27_1
 L  w_ub_27_1
 G  w_lb_27_2
 L  w_ub_27_2
 G  w_lb_27_3
 L  w_ub_27_3
 G  w_lb_27_4
 L  w_ub_27_4
 G  w_lb_27_5
 L  w_ub_27_5
 G  w_lb_27_6
 L  w_ub_27_6
 G  w_lb_27_7
 L  w_ub_27_7
 G  w_lb_27_8
 L  w_ub_27_8
 G  w_lb_27_9
 L  w_ub_27_9
 G  w_lb_27_10
 L  w_ub_27_10
 G  w_lb_27_11
 L  w_ub_27_11
 G  w_lb_27_12
 L  w_ub_27_12
 G  w_lb_27_13
 L  w_ub_27_13
 G  w_lb_27_14
 L  w_ub_27_14
 G  w_lb_27_15
 L  w_ub_27_15
 E  normalized_inventory_27
 E  normalized_ratio_27
 E  onehot_28
 E  mass_28 
 G  w_lb_28_0
 L  w_ub_28_0
 G  w_lb_28_1
 L  w_ub_28_1
 G  w_lb_28_2
 L  w_ub_28_2
 G  w_lb_28_3
 L  w_ub_28_3
 G  w_lb_28_4
 L  w_ub_28_4
 G  w_lb_28_5
 L  w_ub_28_5
 G  w_lb_28_6
 L  w_ub_28_6
 G  w_lb_28_7
 L  w_ub_28_7
 G  w_lb_28_8
 L  w_ub_28_8
 G  w_lb_28_9
 L  w_ub_28_9
 G  w_lb_28_10
 L  w_ub_28_10
 G  w_lb_28_11
 L  w_ub_28_11
 G  w_lb_28_12
 L  w_ub_28_12
 G  w_lb_28_13
 L  w_ub_28_13
 G  w_lb_28_14
 L  w_ub_28_14
 G  w_lb_28_15
 L  w_ub_28_15
 G  w_lb_28_16
 L  w_ub_28_16
 G  w_lb_28_17
 L  w_ub_28_17
 G  w_lb_28_18
 L  w_ub_28_18
 G  w_lb_28_19
 L  w_ub_28_19
 E  normalized_inventory_28
 E  normalized_ratio_28
 E  onehot_29
 E  mass_29 
 G  w_lb_29_0
 L  w_ub_29_0
 G  w_lb_29_1
 L  w_ub_29_1
 G  w_lb_29_2
 L  w_ub_29_2
 G  w_lb_29_3
 L  w_ub_29_3
 G  w_lb_29_4
 L  w_ub_29_4
 G  w_lb_29_5
 L  w_ub_29_5
 G  w_lb_29_6
 L  w_ub_29_6
 G  w_lb_29_7
 L  w_ub_29_7
 G  w_lb_29_8
 L  w_ub_29_8
 G  w_lb_29_9
 L  w_ub_29_9
 G  w_lb_29_10
 L  w_ub_29_10
 G  w_lb_29_11
 L  w_ub_29_11
 G  w_lb_29_12
 L  w_ub_29_12
 G  w_lb_29_13
 L  w_ub_29_13
 G  w_lb_29_14
 L  w_ub_29_14
 G  w_lb_29_15
 L  w_ub_29_15
 E  normalized_inventory_29
 E  normalized_ratio_29
 E  onehot_30
 E  mass_30 
 G  w_lb_30_0
 L  w_ub_30_0
 G  w_lb_30_1
 L  w_ub_30_1
 G  w_lb_30_2
 L  w_ub_30_2
 G  w_lb_30_3
 L  w_ub_30_3
 G  w_lb_30_4
 L  w_ub_30_4
 G  w_lb_30_5
 L  w_ub_30_5
 G  w_lb_30_6
 L  w_ub_30_6
 G  w_lb_30_7
 L  w_ub_30_7
 G  w_lb_30_8
 L  w_ub_30_8
 E  normalized_inventory_30
 E  normalized_ratio_30
 E  onehot_31
 E  mass_31 
 G  w_lb_31_0
 L  w_ub_31_0
 G  w_lb_31_1
 L  w_ub_31_1
 G  w_lb_31_2
 L  w_ub_31_2
 G  w_lb_31_3
 L  w_ub_31_3
 G  w_lb_31_4
 L  w_ub_31_4
 G  w_lb_31_5
 L  w_ub_31_5
 G  w_lb_31_6
 L  w_ub_31_6
 G  w_lb_31_7
 L  w_ub_31_7
 G  w_lb_31_8
 L  w_ub_31_8
 G  w_lb_31_9
 L  w_ub_31_9
 G  w_lb_31_10
 L  w_ub_31_10
 G  w_lb_31_11
 L  w_ub_31_11
 G  w_lb_31_12
 L  w_ub_31_12
 E  normalized_inventory_31
 E  normalized_ratio_31
 E  onehot_32
 E  mass_32 
 G  w_lb_32_0
 L  w_ub_32_0
 G  w_lb_32_1
 L  w_ub_32_1
 G  w_lb_32_2
 L  w_ub_32_2
 G  w_lb_32_3
 L  w_ub_32_3
 G  w_lb_32_4
 L  w_ub_32_4
 G  w_lb_32_5
 L  w_ub_32_5
 G  w_lb_32_6
 L  w_ub_32_6
 G  w_lb_32_7
 L  w_ub_32_7
 G  w_lb_32_8
 L  w_ub_32_8
 G  w_lb_32_9
 L  w_ub_32_9
 G  w_lb_32_10
 L  w_ub_32_10
 G  w_lb_32_11
 L  w_ub_32_11
 G  w_lb_32_12
 L  w_ub_32_12
 E  normalized_inventory_32
 E  normalized_ratio_32
 E  onehot_33
 E  mass_33 
 G  w_lb_33_0
 L  w_ub_33_0
 G  w_lb_33_1
 L  w_ub_33_1
 G  w_lb_33_2
 L  w_ub_33_2
 G  w_lb_33_3
 L  w_ub_33_3
 G  w_lb_33_4
 L  w_ub_33_4
 G  w_lb_33_5
 L  w_ub_33_5
 G  w_lb_33_6
 L  w_ub_33_6
 G  w_lb_33_7
 L  w_ub_33_7
 G  w_lb_33_8
 L  w_ub_33_8
 G  w_lb_33_9
 L  w_ub_33_9
 G  w_lb_33_10
 L  w_ub_33_10
 G  w_lb_33_11
 L  w_ub_33_11
 G  w_lb_33_12
 L  w_ub_33_12
 G  w_lb_33_13
 L  w_ub_33_13
 G  w_lb_33_14
 L  w_ub_33_14
 G  w_lb_33_15
 L  w_ub_33_15
 G  w_lb_33_16
 L  w_ub_33_16
 E  normalized_inventory_33
 E  normalized_ratio_33
 E  onehot_34
 E  mass_34 
 G  w_lb_34_0
 L  w_ub_34_0
 G  w_lb_34_1
 L  w_ub_34_1
 G  w_lb_34_2
 L  w_ub_34_2
 G  w_lb_34_3
 L  w_ub_34_3
 G  w_lb_34_4
 L  w_ub_34_4
 G  w_lb_34_5
 L  w_ub_34_5
 G  w_lb_34_6
 L  w_ub_34_6
 G  w_lb_34_7
 L  w_ub_34_7
 G  w_lb_34_8
 L  w_ub_34_8
 G  w_lb_34_9
 L  w_ub_34_9
 G  w_lb_34_10
 L  w_ub_34_10
 G  w_lb_34_11
 L  w_ub_34_11
 E  normalized_inventory_34
 E  normalized_ratio_34
 E  onehot_35
 E  mass_35 
 G  w_lb_35_0
 L  w_ub_35_0
 G  w_lb_35_1
 L  w_ub_35_1
 G  w_lb_35_2
 L  w_ub_35_2
 G  w_lb_35_3
 L  w_ub_35_3
 G  w_lb_35_4
 L  w_ub_35_4
 G  w_lb_35_5
 L  w_ub_35_5
 G  w_lb_35_6
 L  w_ub_35_6
 G  w_lb_35_7
 L  w_ub_35_7
 G  w_lb_35_8
 L  w_ub_35_8
 G  w_lb_35_9
 L  w_ub_35_9
 G  w_lb_35_10
 L  w_ub_35_10
 G  w_lb_35_11
 L  w_ub_35_11
 G  w_lb_35_12
 L  w_ub_35_12
 G  w_lb_35_13
 L  w_ub_35_13
 G  w_lb_35_14
 L  w_ub_35_14
 G  w_lb_35_15
 L  w_ub_35_15
 E  normalized_inventory_35
 E  normalized_ratio_35
 G  hard_lower
 L  hard_upper
 E  normalization
 G  scaled_stock_lower
 L  scaled_stock_upper
 G  abs_p_1_2
 G  abs_m_1_2
 G  abs_p_1_3
 G  abs_m_1_3
 G  abs_p_1_4
 G  abs_m_1_4
 G  abs_p_1_5
 G  abs_m_1_5
 G  abs_p_1_6
 G  abs_m_1_6
 G  abs_p_1_7
 G  abs_m_1_7
 G  abs_p_1_8
 G  abs_m_1_8
 G  abs_p_1_9
 G  abs_m_1_9
 G  abs_p_1_10
 G  abs_m_1_10
 G  abs_p_1_11
 G  abs_m_1_11
 G  abs_p_1_12
 G  abs_m_1_12
 G  abs_p_1_13
 G  abs_m_1_13
 G  abs_p_1_14
 G  abs_m_1_14
 G  abs_p_1_15
 G  abs_m_1_15
 G  abs_p_1_16
 G  abs_m_1_16
 G  abs_p_1_17
 G  abs_m_1_17
 G  abs_p_1_18
 G  abs_m_1_18
 G  abs_p_1_19
 G  abs_m_1_19
 G  abs_p_1_20
 G  abs_m_1_20
 G  abs_p_1_21
 G  abs_m_1_21
 G  abs_p_1_22
 G  abs_m_1_22
 G  abs_p_1_23
 G  abs_m_1_23
 G  abs_p_1_24
 G  abs_m_1_24
 G  abs_p_1_25
 G  abs_m_1_25
 G  abs_p_1_26
 G  abs_m_1_26
 G  abs_p_1_27
 G  abs_m_1_27
 G  abs_p_1_28
 G  abs_m_1_28
 G  abs_p_1_29
 G  abs_m_1_29
 G  abs_p_1_30
 G  abs_m_1_30
 G  abs_p_1_31
 G  abs_m_1_31
 G  abs_p_1_32
 G  abs_m_1_32
 G  abs_p_1_33
 G  abs_m_1_33
 G  abs_p_1_34
 G  abs_m_1_34
 G  abs_p_1_35
 G  abs_m_1_35
 G  abs_p_2_3
 G  abs_m_2_3
 G  abs_p_2_4
 G  abs_m_2_4
 G  abs_p_2_5
 G  abs_m_2_5
 G  abs_p_2_6
 G  abs_m_2_6
 G  abs_p_2_7
 G  abs_m_2_7
 G  abs_p_2_8
 G  abs_m_2_8
 G  abs_p_2_9
 G  abs_m_2_9
 G  abs_p_2_10
 G  abs_m_2_10
 G  abs_p_2_11
 G  abs_m_2_11
 G  abs_p_2_12
 G  abs_m_2_12
 G  abs_p_2_13
 G  abs_m_2_13
 G  abs_p_2_14
 G  abs_m_2_14
 G  abs_p_2_15
 G  abs_m_2_15
 G  abs_p_2_16
 G  abs_m_2_16
 G  abs_p_2_17
 G  abs_m_2_17
 G  abs_p_2_18
 G  abs_m_2_18
 G  abs_p_2_19
 G  abs_m_2_19
 G  abs_p_2_20
 G  abs_m_2_20
 G  abs_p_2_21
 G  abs_m_2_21
 G  abs_p_2_22
 G  abs_m_2_22
 G  abs_p_2_23
 G  abs_m_2_23
 G  abs_p_2_24
 G  abs_m_2_24
 G  abs_p_2_25
 G  abs_m_2_25
 G  abs_p_2_26
 G  abs_m_2_26
 G  abs_p_2_27
 G  abs_m_2_27
 G  abs_p_2_28
 G  abs_m_2_28
 G  abs_p_2_29
 G  abs_m_2_29
 G  abs_p_2_30
 G  abs_m_2_30
 G  abs_p_2_31
 G  abs_m_2_31
 G  abs_p_2_32
 G  abs_m_2_32
 G  abs_p_2_33
 G  abs_m_2_33
 G  abs_p_2_34
 G  abs_m_2_34
 G  abs_p_2_35
 G  abs_m_2_35
 G  abs_p_3_4
 G  abs_m_3_4
 G  abs_p_3_5
 G  abs_m_3_5
 G  abs_p_3_6
 G  abs_m_3_6
 G  abs_p_3_7
 G  abs_m_3_7
 G  abs_p_3_8
 G  abs_m_3_8
 G  abs_p_3_9
 G  abs_m_3_9
 G  abs_p_3_10
 G  abs_m_3_10
 G  abs_p_3_11
 G  abs_m_3_11
 G  abs_p_3_12
 G  abs_m_3_12
 G  abs_p_3_13
 G  abs_m_3_13
 G  abs_p_3_14
 G  abs_m_3_14
 G  abs_p_3_15
 G  abs_m_3_15
 G  abs_p_3_16
 G  abs_m_3_16
 G  abs_p_3_17
 G  abs_m_3_17
 G  abs_p_3_18
 G  abs_m_3_18
 G  abs_p_3_19
 G  abs_m_3_19
 G  abs_p_3_20
 G  abs_m_3_20
 G  abs_p_3_21
 G  abs_m_3_21
 G  abs_p_3_22
 G  abs_m_3_22
 G  abs_p_3_23
 G  abs_m_3_23
 G  abs_p_3_24
 G  abs_m_3_24
 G  abs_p_3_25
 G  abs_m_3_25
 G  abs_p_3_26
 G  abs_m_3_26
 G  abs_p_3_27
 G  abs_m_3_27
 G  abs_p_3_28
 G  abs_m_3_28
 G  abs_p_3_29
 G  abs_m_3_29
 G  abs_p_3_30
 G  abs_m_3_30
 G  abs_p_3_31
 G  abs_m_3_31
 G  abs_p_3_32
 G  abs_m_3_32
 G  abs_p_3_33
 G  abs_m_3_33
 G  abs_p_3_34
 G  abs_m_3_34
 G  abs_p_3_35
 G  abs_m_3_35
 G  abs_p_4_5
 G  abs_m_4_5
 G  abs_p_4_6
 G  abs_m_4_6
 G  abs_p_4_7
 G  abs_m_4_7
 G  abs_p_4_8
 G  abs_m_4_8
 G  abs_p_4_9
 G  abs_m_4_9
 G  abs_p_4_10
 G  abs_m_4_10
 G  abs_p_4_11
 G  abs_m_4_11
 G  abs_p_4_12
 G  abs_m_4_12
 G  abs_p_4_13
 G  abs_m_4_13
 G  abs_p_4_14
 G  abs_m_4_14
 G  abs_p_4_15
 G  abs_m_4_15
 G  abs_p_4_16
 G  abs_m_4_16
 G  abs_p_4_17
 G  abs_m_4_17
 G  abs_p_4_18
 G  abs_m_4_18
 G  abs_p_4_19
 G  abs_m_4_19
 G  abs_p_4_20
 G  abs_m_4_20
 G  abs_p_4_21
 G  abs_m_4_21
 G  abs_p_4_22
 G  abs_m_4_22
 G  abs_p_4_23
 G  abs_m_4_23
 G  abs_p_4_24
 G  abs_m_4_24
 G  abs_p_4_25
 G  abs_m_4_25
 G  abs_p_4_26
 G  abs_m_4_26
 G  abs_p_4_27
 G  abs_m_4_27
 G  abs_p_4_28
 G  abs_m_4_28
 G  abs_p_4_29
 G  abs_m_4_29
 G  abs_p_4_30
 G  abs_m_4_30
 G  abs_p_4_31
 G  abs_m_4_31
 G  abs_p_4_32
 G  abs_m_4_32
 G  abs_p_4_33
 G  abs_m_4_33
 G  abs_p_4_34
 G  abs_m_4_34
 G  abs_p_4_35
 G  abs_m_4_35
 G  abs_p_5_6
 G  abs_m_5_6
 G  abs_p_5_7
 G  abs_m_5_7
 G  abs_p_5_8
 G  abs_m_5_8
 G  abs_p_5_9
 G  abs_m_5_9
 G  abs_p_5_10
 G  abs_m_5_10
 G  abs_p_5_11
 G  abs_m_5_11
 G  abs_p_5_12
 G  abs_m_5_12
 G  abs_p_5_13
 G  abs_m_5_13
 G  abs_p_5_14
 G  abs_m_5_14
 G  abs_p_5_15
 G  abs_m_5_15
 G  abs_p_5_16
 G  abs_m_5_16
 G  abs_p_5_17
 G  abs_m_5_17
 G  abs_p_5_18
 G  abs_m_5_18
 G  abs_p_5_19
 G  abs_m_5_19
 G  abs_p_5_20
 G  abs_m_5_20
 G  abs_p_5_21
 G  abs_m_5_21
 G  abs_p_5_22
 G  abs_m_5_22
 G  abs_p_5_23
 G  abs_m_5_23
 G  abs_p_5_24
 G  abs_m_5_24
 G  abs_p_5_25
 G  abs_m_5_25
 G  abs_p_5_26
 G  abs_m_5_26
 G  abs_p_5_27
 G  abs_m_5_27
 G  abs_p_5_28
 G  abs_m_5_28
 G  abs_p_5_29
 G  abs_m_5_29
 G  abs_p_5_30
 G  abs_m_5_30
 G  abs_p_5_31
 G  abs_m_5_31
 G  abs_p_5_32
 G  abs_m_5_32
 G  abs_p_5_33
 G  abs_m_5_33
 G  abs_p_5_34
 G  abs_m_5_34
 G  abs_p_5_35
 G  abs_m_5_35
 G  abs_p_6_7
 G  abs_m_6_7
 G  abs_p_6_8
 G  abs_m_6_8
 G  abs_p_6_9
 G  abs_m_6_9
 G  abs_p_6_10
 G  abs_m_6_10
 G  abs_p_6_11
 G  abs_m_6_11
 G  abs_p_6_12
 G  abs_m_6_12
 G  abs_p_6_13
 G  abs_m_6_13
 G  abs_p_6_14
 G  abs_m_6_14
 G  abs_p_6_15
 G  abs_m_6_15
 G  abs_p_6_16
 G  abs_m_6_16
 G  abs_p_6_17
 G  abs_m_6_17
 G  abs_p_6_18
 G  abs_m_6_18
 G  abs_p_6_19
 G  abs_m_6_19
 G  abs_p_6_20
 G  abs_m_6_20
 G  abs_p_6_21
 G  abs_m_6_21
 G  abs_p_6_22
 G  abs_m_6_22
 G  abs_p_6_23
 G  abs_m_6_23
 G  abs_p_6_24
 G  abs_m_6_24
 G  abs_p_6_25
 G  abs_m_6_25
 G  abs_p_6_26
 G  abs_m_6_26
 G  abs_p_6_27
 G  abs_m_6_27
 G  abs_p_6_28
 G  abs_m_6_28
 G  abs_p_6_29
 G  abs_m_6_29
 G  abs_p_6_30
 G  abs_m_6_30
 G  abs_p_6_31
 G  abs_m_6_31
 G  abs_p_6_32
 G  abs_m_6_32
 G  abs_p_6_33
 G  abs_m_6_33
 G  abs_p_6_34
 G  abs_m_6_34
 G  abs_p_6_35
 G  abs_m_6_35
 G  abs_p_7_8
 G  abs_m_7_8
 G  abs_p_7_9
 G  abs_m_7_9
 G  abs_p_7_10
 G  abs_m_7_10
 G  abs_p_7_11
 G  abs_m_7_11
 G  abs_p_7_12
 G  abs_m_7_12
 G  abs_p_7_13
 G  abs_m_7_13
 G  abs_p_7_14
 G  abs_m_7_14
 G  abs_p_7_15
 G  abs_m_7_15
 G  abs_p_7_16
 G  abs_m_7_16
 G  abs_p_7_17
 G  abs_m_7_17
 G  abs_p_7_18
 G  abs_m_7_18
 G  abs_p_7_19
 G  abs_m_7_19
 G  abs_p_7_20
 G  abs_m_7_20
 G  abs_p_7_21
 G  abs_m_7_21
 G  abs_p_7_22
 G  abs_m_7_22
 G  abs_p_7_23
 G  abs_m_7_23
 G  abs_p_7_24
 G  abs_m_7_24
 G  abs_p_7_25
 G  abs_m_7_25
 G  abs_p_7_26
 G  abs_m_7_26
 G  abs_p_7_27
 G  abs_m_7_27
 G  abs_p_7_28
 G  abs_m_7_28
 G  abs_p_7_29
 G  abs_m_7_29
 G  abs_p_7_30
 G  abs_m_7_30
 G  abs_p_7_31
 G  abs_m_7_31
 G  abs_p_7_32
 G  abs_m_7_32
 G  abs_p_7_33
 G  abs_m_7_33
 G  abs_p_7_34
 G  abs_m_7_34
 G  abs_p_7_35
 G  abs_m_7_35
 G  abs_p_8_9
 G  abs_m_8_9
 G  abs_p_8_10
 G  abs_m_8_10
 G  abs_p_8_11
 G  abs_m_8_11
 G  abs_p_8_12
 G  abs_m_8_12
 G  abs_p_8_13
 G  abs_m_8_13
 G  abs_p_8_14
 G  abs_m_8_14
 G  abs_p_8_15
 G  abs_m_8_15
 G  abs_p_8_16
 G  abs_m_8_16
 G  abs_p_8_17
 G  abs_m_8_17
 G  abs_p_8_18
 G  abs_m_8_18
 G  abs_p_8_19
 G  abs_m_8_19
 G  abs_p_8_20
 G  abs_m_8_20
 G  abs_p_8_21
 G  abs_m_8_21
 G  abs_p_8_22
 G  abs_m_8_22
 G  abs_p_8_23
 G  abs_m_8_23
 G  abs_p_8_24
 G  abs_m_8_24
 G  abs_p_8_25
 G  abs_m_8_25
 G  abs_p_8_26
 G  abs_m_8_26
 G  abs_p_8_27
 G  abs_m_8_27
 G  abs_p_8_28
 G  abs_m_8_28
 G  abs_p_8_29
 G  abs_m_8_29
 G  abs_p_8_30
 G  abs_m_8_30
 G  abs_p_8_31
 G  abs_m_8_31
 G  abs_p_8_32
 G  abs_m_8_32
 G  abs_p_8_33
 G  abs_m_8_33
 G  abs_p_8_34
 G  abs_m_8_34
 G  abs_p_8_35
 G  abs_m_8_35
 G  abs_p_9_10
 G  abs_m_9_10
 G  abs_p_9_11
 G  abs_m_9_11
 G  abs_p_9_12
 G  abs_m_9_12
 G  abs_p_9_13
 G  abs_m_9_13
 G  abs_p_9_14
 G  abs_m_9_14
 G  abs_p_9_15
 G  abs_m_9_15
 G  abs_p_9_16
 G  abs_m_9_16
 G  abs_p_9_17
 G  abs_m_9_17
 G  abs_p_9_18
 G  abs_m_9_18
 G  abs_p_9_19
 G  abs_m_9_19
 G  abs_p_9_20
 G  abs_m_9_20
 G  abs_p_9_21
 G  abs_m_9_21
 G  abs_p_9_22
 G  abs_m_9_22
 G  abs_p_9_23
 G  abs_m_9_23
 G  abs_p_9_24
 G  abs_m_9_24
 G  abs_p_9_25
 G  abs_m_9_25
 G  abs_p_9_26
 G  abs_m_9_26
 G  abs_p_9_27
 G  abs_m_9_27
 G  abs_p_9_28
 G  abs_m_9_28
 G  abs_p_9_29
 G  abs_m_9_29
 G  abs_p_9_30
 G  abs_m_9_30
 G  abs_p_9_31
 G  abs_m_9_31
 G  abs_p_9_32
 G  abs_m_9_32
 G  abs_p_9_33
 G  abs_m_9_33
 G  abs_p_9_34
 G  abs_m_9_34
 G  abs_p_9_35
 G  abs_m_9_35
 G  abs_p_10_11
 G  abs_m_10_11
 G  abs_p_10_12
 G  abs_m_10_12
 G  abs_p_10_13
 G  abs_m_10_13
 G  abs_p_10_14
 G  abs_m_10_14
 G  abs_p_10_15
 G  abs_m_10_15
 G  abs_p_10_16
 G  abs_m_10_16
 G  abs_p_10_17
 G  abs_m_10_17
 G  abs_p_10_18
 G  abs_m_10_18
 G  abs_p_10_19
 G  abs_m_10_19
 G  abs_p_10_20
 G  abs_m_10_20
 G  abs_p_10_21
 G  abs_m_10_21
 G  abs_p_10_22
 G  abs_m_10_22
 G  abs_p_10_23
 G  abs_m_10_23
 G  abs_p_10_24
 G  abs_m_10_24
 G  abs_p_10_25
 G  abs_m_10_25
 G  abs_p_10_26
 G  abs_m_10_26
 G  abs_p_10_27
 G  abs_m_10_27
 G  abs_p_10_28
 G  abs_m_10_28
 G  abs_p_10_29
 G  abs_m_10_29
 G  abs_p_10_30
 G  abs_m_10_30
 G  abs_p_10_31
 G  abs_m_10_31
 G  abs_p_10_32
 G  abs_m_10_32
 G  abs_p_10_33
 G  abs_m_10_33
 G  abs_p_10_34
 G  abs_m_10_34
 G  abs_p_10_35
 G  abs_m_10_35
 G  abs_p_11_12
 G  abs_m_11_12
 G  abs_p_11_13
 G  abs_m_11_13
 G  abs_p_11_14
 G  abs_m_11_14
 G  abs_p_11_15
 G  abs_m_11_15
 G  abs_p_11_16
 G  abs_m_11_16
 G  abs_p_11_17
 G  abs_m_11_17
 G  abs_p_11_18
 G  abs_m_11_18
 G  abs_p_11_19
 G  abs_m_11_19
 G  abs_p_11_20
 G  abs_m_11_20
 G  abs_p_11_21
 G  abs_m_11_21
 G  abs_p_11_22
 G  abs_m_11_22
 G  abs_p_11_23
 G  abs_m_11_23
 G  abs_p_11_24
 G  abs_m_11_24
 G  abs_p_11_25
 G  abs_m_11_25
 G  abs_p_11_26
 G  abs_m_11_26
 G  abs_p_11_27
 G  abs_m_11_27
 G  abs_p_11_28
 G  abs_m_11_28
 G  abs_p_11_29
 G  abs_m_11_29
 G  abs_p_11_30
 G  abs_m_11_30
 G  abs_p_11_31
 G  abs_m_11_31
 G  abs_p_11_32
 G  abs_m_11_32
 G  abs_p_11_33
 G  abs_m_11_33
 G  abs_p_11_34
 G  abs_m_11_34
 G  abs_p_11_35
 G  abs_m_11_35
 G  abs_p_12_13
 G  abs_m_12_13
 G  abs_p_12_14
 G  abs_m_12_14
 G  abs_p_12_15
 G  abs_m_12_15
 G  abs_p_12_16
 G  abs_m_12_16
 G  abs_p_12_17
 G  abs_m_12_17
 G  abs_p_12_18
 G  abs_m_12_18
 G  abs_p_12_19
 G  abs_m_12_19
 G  abs_p_12_20
 G  abs_m_12_20
 G  abs_p_12_21
 G  abs_m_12_21
 G  abs_p_12_22
 G  abs_m_12_22
 G  abs_p_12_23
 G  abs_m_12_23
 G  abs_p_12_24
 G  abs_m_12_24
 G  abs_p_12_25
 G  abs_m_12_25
 G  abs_p_12_26
 G  abs_m_12_26
 G  abs_p_12_27
 G  abs_m_12_27
 G  abs_p_12_28
 G  abs_m_12_28
 G  abs_p_12_29
 G  abs_m_12_29
 G  abs_p_12_30
 G  abs_m_12_30
 G  abs_p_12_31
 G  abs_m_12_31
 G  abs_p_12_32
 G  abs_m_12_32
 G  abs_p_12_33
 G  abs_m_12_33
 G  abs_p_12_34
 G  abs_m_12_34
 G  abs_p_12_35
 G  abs_m_12_35
 G  abs_p_13_14
 G  abs_m_13_14
 G  abs_p_13_15
 G  abs_m_13_15
 G  abs_p_13_16
 G  abs_m_13_16
 G  abs_p_13_17
 G  abs_m_13_17
 G  abs_p_13_18
 G  abs_m_13_18
 G  abs_p_13_19
 G  abs_m_13_19
 G  abs_p_13_20
 G  abs_m_13_20
 G  abs_p_13_21
 G  abs_m_13_21
 G  abs_p_13_22
 G  abs_m_13_22
 G  abs_p_13_23
 G  abs_m_13_23
 G  abs_p_13_24
 G  abs_m_13_24
 G  abs_p_13_25
 G  abs_m_13_25
 G  abs_p_13_26
 G  abs_m_13_26
 G  abs_p_13_27
 G  abs_m_13_27
 G  abs_p_13_28
 G  abs_m_13_28
 G  abs_p_13_29
 G  abs_m_13_29
 G  abs_p_13_30
 G  abs_m_13_30
 G  abs_p_13_31
 G  abs_m_13_31
 G  abs_p_13_32
 G  abs_m_13_32
 G  abs_p_13_33
 G  abs_m_13_33
 G  abs_p_13_34
 G  abs_m_13_34
 G  abs_p_13_35
 G  abs_m_13_35
 G  abs_p_14_15
 G  abs_m_14_15
 G  abs_p_14_16
 G  abs_m_14_16
 G  abs_p_14_17
 G  abs_m_14_17
 G  abs_p_14_18
 G  abs_m_14_18
 G  abs_p_14_19
 G  abs_m_14_19
 G  abs_p_14_20
 G  abs_m_14_20
 G  abs_p_14_21
 G  abs_m_14_21
 G  abs_p_14_22
 G  abs_m_14_22
 G  abs_p_14_23
 G  abs_m_14_23
 G  abs_p_14_24
 G  abs_m_14_24
 G  abs_p_14_25
 G  abs_m_14_25
 G  abs_p_14_26
 G  abs_m_14_26
 G  abs_p_14_27
 G  abs_m_14_27
 G  abs_p_14_28
 G  abs_m_14_28
 G  abs_p_14_29
 G  abs_m_14_29
 G  abs_p_14_30
 G  abs_m_14_30
 G  abs_p_14_31
 G  abs_m_14_31
 G  abs_p_14_32
 G  abs_m_14_32
 G  abs_p_14_33
 G  abs_m_14_33
 G  abs_p_14_34
 G  abs_m_14_34
 G  abs_p_14_35
 G  abs_m_14_35
 G  abs_p_15_16
 G  abs_m_15_16
 G  abs_p_15_17
 G  abs_m_15_17
 G  abs_p_15_18
 G  abs_m_15_18
 G  abs_p_15_19
 G  abs_m_15_19
 G  abs_p_15_20
 G  abs_m_15_20
 G  abs_p_15_21
 G  abs_m_15_21
 G  abs_p_15_22
 G  abs_m_15_22
 G  abs_p_15_23
 G  abs_m_15_23
 G  abs_p_15_24
 G  abs_m_15_24
 G  abs_p_15_25
 G  abs_m_15_25
 G  abs_p_15_26
 G  abs_m_15_26
 G  abs_p_15_27
 G  abs_m_15_27
 G  abs_p_15_28
 G  abs_m_15_28
 G  abs_p_15_29
 G  abs_m_15_29
 G  abs_p_15_30
 G  abs_m_15_30
 G  abs_p_15_31
 G  abs_m_15_31
 G  abs_p_15_32
 G  abs_m_15_32
 G  abs_p_15_33
 G  abs_m_15_33
 G  abs_p_15_34
 G  abs_m_15_34
 G  abs_p_15_35
 G  abs_m_15_35
 G  abs_p_16_17
 G  abs_m_16_17
 G  abs_p_16_18
 G  abs_m_16_18
 G  abs_p_16_19
 G  abs_m_16_19
 G  abs_p_16_20
 G  abs_m_16_20
 G  abs_p_16_21
 G  abs_m_16_21
 G  abs_p_16_22
 G  abs_m_16_22
 G  abs_p_16_23
 G  abs_m_16_23
 G  abs_p_16_24
 G  abs_m_16_24
 G  abs_p_16_25
 G  abs_m_16_25
 G  abs_p_16_26
 G  abs_m_16_26
 G  abs_p_16_27
 G  abs_m_16_27
 G  abs_p_16_28
 G  abs_m_16_28
 G  abs_p_16_29
 G  abs_m_16_29
 G  abs_p_16_30
 G  abs_m_16_30
 G  abs_p_16_31
 G  abs_m_16_31
 G  abs_p_16_32
 G  abs_m_16_32
 G  abs_p_16_33
 G  abs_m_16_33
 G  abs_p_16_34
 G  abs_m_16_34
 G  abs_p_16_35
 G  abs_m_16_35
 G  abs_p_17_18
 G  abs_m_17_18
 G  abs_p_17_19
 G  abs_m_17_19
 G  abs_p_17_20
 G  abs_m_17_20
 G  abs_p_17_21
 G  abs_m_17_21
 G  abs_p_17_22
 G  abs_m_17_22
 G  abs_p_17_23
 G  abs_m_17_23
 G  abs_p_17_24
 G  abs_m_17_24
 G  abs_p_17_25
 G  abs_m_17_25
 G  abs_p_17_26
 G  abs_m_17_26
 G  abs_p_17_27
 G  abs_m_17_27
 G  abs_p_17_28
 G  abs_m_17_28
 G  abs_p_17_29
 G  abs_m_17_29
 G  abs_p_17_30
 G  abs_m_17_30
 G  abs_p_17_31
 G  abs_m_17_31
 G  abs_p_17_32
 G  abs_m_17_32
 G  abs_p_17_33
 G  abs_m_17_33
 G  abs_p_17_34
 G  abs_m_17_34
 G  abs_p_17_35
 G  abs_m_17_35
 G  abs_p_18_19
 G  abs_m_18_19
 G  abs_p_18_20
 G  abs_m_18_20
 G  abs_p_18_21
 G  abs_m_18_21
 G  abs_p_18_22
 G  abs_m_18_22
 G  abs_p_18_23
 G  abs_m_18_23
 G  abs_p_18_24
 G  abs_m_18_24
 G  abs_p_18_25
 G  abs_m_18_25
 G  abs_p_18_26
 G  abs_m_18_26
 G  abs_p_18_27
 G  abs_m_18_27
 G  abs_p_18_28
 G  abs_m_18_28
 G  abs_p_18_29
 G  abs_m_18_29
 G  abs_p_18_30
 G  abs_m_18_30
 G  abs_p_18_31
 G  abs_m_18_31
 G  abs_p_18_32
 G  abs_m_18_32
 G  abs_p_18_33
 G  abs_m_18_33
 G  abs_p_18_34
 G  abs_m_18_34
 G  abs_p_18_35
 G  abs_m_18_35
 G  abs_p_19_20
 G  abs_m_19_20
 G  abs_p_19_21
 G  abs_m_19_21
 G  abs_p_19_22
 G  abs_m_19_22
 G  abs_p_19_23
 G  abs_m_19_23
 G  abs_p_19_24
 G  abs_m_19_24
 G  abs_p_19_25
 G  abs_m_19_25
 G  abs_p_19_26
 G  abs_m_19_26
 G  abs_p_19_27
 G  abs_m_19_27
 G  abs_p_19_28
 G  abs_m_19_28
 G  abs_p_19_29
 G  abs_m_19_29
 G  abs_p_19_30
 G  abs_m_19_30
 G  abs_p_19_31
 G  abs_m_19_31
 G  abs_p_19_32
 G  abs_m_19_32
 G  abs_p_19_33
 G  abs_m_19_33
 G  abs_p_19_34
 G  abs_m_19_34
 G  abs_p_19_35
 G  abs_m_19_35
 G  abs_p_20_21
 G  abs_m_20_21
 G  abs_p_20_22
 G  abs_m_20_22
 G  abs_p_20_23
 G  abs_m_20_23
 G  abs_p_20_24
 G  abs_m_20_24
 G  abs_p_20_25
 G  abs_m_20_25
 G  abs_p_20_26
 G  abs_m_20_26
 G  abs_p_20_27
 G  abs_m_20_27
 G  abs_p_20_28
 G  abs_m_20_28
 G  abs_p_20_29
 G  abs_m_20_29
 G  abs_p_20_30
 G  abs_m_20_30
 G  abs_p_20_31
 G  abs_m_20_31
 G  abs_p_20_32
 G  abs_m_20_32
 G  abs_p_20_33
 G  abs_m_20_33
 G  abs_p_20_34
 G  abs_m_20_34
 G  abs_p_20_35
 G  abs_m_20_35
 G  abs_p_21_22
 G  abs_m_21_22
 G  abs_p_21_23
 G  abs_m_21_23
 G  abs_p_21_24
 G  abs_m_21_24
 G  abs_p_21_25
 G  abs_m_21_25
 G  abs_p_21_26
 G  abs_m_21_26
 G  abs_p_21_27
 G  abs_m_21_27
 G  abs_p_21_28
 G  abs_m_21_28
 G  abs_p_21_29
 G  abs_m_21_29
 G  abs_p_21_30
 G  abs_m_21_30
 G  abs_p_21_31
 G  abs_m_21_31
 G  abs_p_21_32
 G  abs_m_21_32
 G  abs_p_21_33
 G  abs_m_21_33
 G  abs_p_21_34
 G  abs_m_21_34
 G  abs_p_21_35
 G  abs_m_21_35
 G  abs_p_22_23
 G  abs_m_22_23
 G  abs_p_22_24
 G  abs_m_22_24
 G  abs_p_22_25
 G  abs_m_22_25
 G  abs_p_22_26
 G  abs_m_22_26
 G  abs_p_22_27
 G  abs_m_22_27
 G  abs_p_22_28
 G  abs_m_22_28
 G  abs_p_22_29
 G  abs_m_22_29
 G  abs_p_22_30
 G  abs_m_22_30
 G  abs_p_22_31
 G  abs_m_22_31
 G  abs_p_22_32
 G  abs_m_22_32
 G  abs_p_22_33
 G  abs_m_22_33
 G  abs_p_22_34
 G  abs_m_22_34
 G  abs_p_22_35
 G  abs_m_22_35
 G  abs_p_23_24
 G  abs_m_23_24
 G  abs_p_23_25
 G  abs_m_23_25
 G  abs_p_23_26
 G  abs_m_23_26
 G  abs_p_23_27
 G  abs_m_23_27
 G  abs_p_23_28
 G  abs_m_23_28
 G  abs_p_23_29
 G  abs_m_23_29
 G  abs_p_23_30
 G  abs_m_23_30
 G  abs_p_23_31
 G  abs_m_23_31
 G  abs_p_23_32
 G  abs_m_23_32
 G  abs_p_23_33
 G  abs_m_23_33
 G  abs_p_23_34
 G  abs_m_23_34
 G  abs_p_23_35
 G  abs_m_23_35
 G  abs_p_24_25
 G  abs_m_24_25
 G  abs_p_24_26
 G  abs_m_24_26
 G  abs_p_24_27
 G  abs_m_24_27
 G  abs_p_24_28
 G  abs_m_24_28
 G  abs_p_24_29
 G  abs_m_24_29
 G  abs_p_24_30
 G  abs_m_24_30
 G  abs_p_24_31
 G  abs_m_24_31
 G  abs_p_24_32
 G  abs_m_24_32
 G  abs_p_24_33
 G  abs_m_24_33
 G  abs_p_24_34
 G  abs_m_24_34
 G  abs_p_24_35
 G  abs_m_24_35
 G  abs_p_25_26
 G  abs_m_25_26
 G  abs_p_25_27
 G  abs_m_25_27
 G  abs_p_25_28
 G  abs_m_25_28
 G  abs_p_25_29
 G  abs_m_25_29
 G  abs_p_25_30
 G  abs_m_25_30
 G  abs_p_25_31
 G  abs_m_25_31
 G  abs_p_25_32
 G  abs_m_25_32
 G  abs_p_25_33
 G  abs_m_25_33
 G  abs_p_25_34
 G  abs_m_25_34
 G  abs_p_25_35
 G  abs_m_25_35
 G  abs_p_26_27
 G  abs_m_26_27
 G  abs_p_26_28
 G  abs_m_26_28
 G  abs_p_26_29
 G  abs_m_26_29
 G  abs_p_26_30
 G  abs_m_26_30
 G  abs_p_26_31
 G  abs_m_26_31
 G  abs_p_26_32
 G  abs_m_26_32
 G  abs_p_26_33
 G  abs_m_26_33
 G  abs_p_26_34
 G  abs_m_26_34
 G  abs_p_26_35
 G  abs_m_26_35
 G  abs_p_27_28
 G  abs_m_27_28
 G  abs_p_27_29
 G  abs_m_27_29
 G  abs_p_27_30
 G  abs_m_27_30
 G  abs_p_27_31
 G  abs_m_27_31
 G  abs_p_27_32
 G  abs_m_27_32
 G  abs_p_27_33
 G  abs_m_27_33
 G  abs_p_27_34
 G  abs_m_27_34
 G  abs_p_27_35
 G  abs_m_27_35
 G  abs_p_28_29
 G  abs_m_28_29
 G  abs_p_28_30
 G  abs_m_28_30
 G  abs_p_28_31
 G  abs_m_28_31
 G  abs_p_28_32
 G  abs_m_28_32
 G  abs_p_28_33
 G  abs_m_28_33
 G  abs_p_28_34
 G  abs_m_28_34
 G  abs_p_28_35
 G  abs_m_28_35
 G  abs_p_29_30
 G  abs_m_29_30
 G  abs_p_29_31
 G  abs_m_29_31
 G  abs_p_29_32
 G  abs_m_29_32
 G  abs_p_29_33
 G  abs_m_29_33
 G  abs_p_29_34
 G  abs_m_29_34
 G  abs_p_29_35
 G  abs_m_29_35
 G  abs_p_30_31
 G  abs_m_30_31
 G  abs_p_30_32
 G  abs_m_30_32
 G  abs_p_30_33
 G  abs_m_30_33
 G  abs_p_30_34
 G  abs_m_30_34
 G  abs_p_30_35
 G  abs_m_30_35
 G  abs_p_31_32
 G  abs_m_31_32
 G  abs_p_31_33
 G  abs_m_31_33
 G  abs_p_31_34
 G  abs_m_31_34
 G  abs_p_31_35
 G  abs_m_31_35
 G  abs_p_32_33
 G  abs_m_32_33
 G  abs_p_32_34
 G  abs_m_32_34
 G  abs_p_32_35
 G  abs_m_32_35
 G  abs_p_33_34
 G  abs_m_33_34
 G  abs_p_33_35
 G  abs_m_33_35
 G  abs_p_34_35
 G  abs_m_34_35
 L  true_G_epigraph
 L  physical_G_upper
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,0]    OBJ       5.2386790756565734e-03
    x[1,0]    onehot_1  1
    x[1,0]    w_lb_1_0  -2.6697177726926005e-02
    x[1,0]    w_ub_1_0  -6.7365269461077862e-02
    x[1,1]    OBJ       5.2386790756565734e-03
    x[1,1]    onehot_1  1
    x[1,1]    w_lb_1_1  -2.6697177726926005e-02
    x[1,1]    w_ub_1_1  -6.7365269461077862e-02
    x[1,1]    hard_lower  1
    x[1,1]    hard_upper  1
    x[1,2]    OBJ       -2.2648747425861294e-03
    x[1,2]    onehot_1  1
    x[1,2]    w_lb_1_2  -2.6697177726926005e-02
    x[1,2]    w_ub_1_2  -6.7365269461077862e-02
    x[1,2]    hard_lower  2
    x[1,2]    hard_upper  2
    x[1,3]    OBJ       5.2386790756565734e-03
    x[1,3]    onehot_1  1
    x[1,3]    w_lb_1_3  -2.6697177726926005e-02
    x[1,3]    w_ub_1_3  -6.7365269461077862e-02
    x[1,3]    hard_lower  3
    x[1,3]    hard_upper  3
    x[1,4]    OBJ       5.2386790756565734e-03
    x[1,4]    onehot_1  1
    x[1,4]    w_lb_1_4  -2.6697177726926005e-02
    x[1,4]    w_ub_1_4  -6.7365269461077862e-02
    x[1,4]    hard_lower  4
    x[1,4]    hard_upper  4
    x[1,5]    OBJ       1.6020872813513965e-04
    x[1,5]    onehot_1  1
    x[1,5]    w_lb_1_5  -2.6697177726926005e-02
    x[1,5]    w_ub_1_5  -6.7365269461077862e-02
    x[1,5]    hard_lower  5
    x[1,5]    hard_upper  5
    x[1,6]    OBJ       5.2386790756565734e-03
    x[1,6]    onehot_1  1
    x[1,6]    w_lb_1_6  -2.6697177726926005e-02
    x[1,6]    w_ub_1_6  -6.7365269461077862e-02
    x[1,6]    hard_lower  6
    x[1,6]    hard_upper  6
    x[1,7]    OBJ       1.1307483343403056e-02
    x[1,7]    onehot_1  1
    x[1,7]    w_lb_1_7  -2.6697177726926005e-02
    x[1,7]    w_ub_1_7  -6.7365269461077862e-02
    x[1,7]    hard_lower  7
    x[1,7]    hard_upper  7
    x[1,8]    OBJ       -6.0399739059974243e-04
    x[1,8]    onehot_1  1
    x[1,8]    w_lb_1_8  -2.6697177726926005e-02
    x[1,8]    w_ub_1_8  -6.7365269461077862e-02
    x[1,8]    hard_lower  8
    x[1,8]    hard_upper  8
    x[1,9]    OBJ       5.2386790756565734e-03
    x[1,9]    onehot_1  1
    x[1,9]    w_lb_1_9  -2.6697177726926005e-02
    x[1,9]    w_ub_1_9  -6.7365269461077862e-02
    x[1,9]    hard_lower  9
    x[1,9]    hard_upper  9
    x[1,10]   OBJ       1.2334695879144138e-03
    x[1,10]   onehot_1  1
    x[1,10]   w_lb_1_10  -2.6697177726926005e-02
    x[1,10]   w_ub_1_10  -6.7365269461077862e-02
    x[1,10]   hard_lower  10
    x[1,10]   hard_upper  10
    x[1,11]   OBJ       8.7809180423633840e-03
    x[1,11]   onehot_1  1
    x[1,11]   w_lb_1_11  -2.6697177726926005e-02
    x[1,11]   w_ub_1_11  -6.7365269461077862e-02
    x[1,11]   hard_lower  11
    x[1,11]   hard_upper  11
    x[1,12]   OBJ       -1.1307483343403058e-02
    x[1,12]   onehot_1  1
    x[1,12]   w_lb_1_12  -2.6697177726926005e-02
    x[1,12]   w_ub_1_12  -6.7365269461077862e-02
    x[1,12]   hard_lower  12
    x[1,12]   hard_upper  12
    x[1,13]   OBJ       -3.7600348889540833e-03
    x[1,13]   onehot_1  1
    x[1,13]   w_lb_1_13  -2.6697177726926005e-02
    x[1,13]   w_ub_1_13  -6.7365269461077862e-02
    x[1,13]   hard_lower  13
    x[1,13]   hard_upper  13
    x[1,14]   OBJ       3.7874135654948865e-03
    x[1,14]   onehot_1  1
    x[1,14]   w_lb_1_14  -2.6697177726926005e-02
    x[1,14]   w_ub_1_14  -6.7365269461077862e-02
    x[1,14]   hard_lower  14
    x[1,14]   hard_upper  14
    x[1,15]   OBJ       -1.8593010442586157e-04
    x[1,15]   onehot_1  1
    x[1,15]   w_lb_1_15  -2.6697177726926005e-02
    x[1,15]   w_ub_1_15  -6.7365269461077862e-02
    x[1,15]   hard_lower  15
    x[1,15]   hard_upper  15
    x[1,16]   OBJ       -4.1085911430202406e-03
    x[1,16]   onehot_1  1
    x[1,16]   w_lb_1_16  -2.6697177726926005e-02
    x[1,16]   w_ub_1_16  -6.7365269461077862e-02
    x[1,16]   hard_lower  16
    x[1,16]   hard_upper  16
    x[1,17]   OBJ       -1.1112044530966059e-02
    x[1,17]   onehot_1  1
    x[1,17]   w_lb_1_17  -2.6697177726926005e-02
    x[1,17]   w_ub_1_17  -6.7365269461077862e-02
    x[1,17]   hard_lower  17
    x[1,17]   hard_upper  17
    x[1,18]   OBJ       -3.5645960765170914e-03
    x[1,18]   onehot_1  1
    x[1,18]   w_lb_1_18  -2.6697177726926005e-02
    x[1,18]   w_ub_1_18  -6.7365269461077862e-02
    x[1,18]   hard_lower  18
    x[1,18]   hard_upper  18
    x[1,19]   OBJ       -5.3318558411881893e-03
    x[1,19]   onehot_1  1
    x[1,19]   w_lb_1_19  -2.6697177726926005e-02
    x[1,19]   w_ub_1_19  -6.7365269461077862e-02
    x[1,19]   hard_lower  19
    x[1,19]   hard_upper  19
    x[2,0]    OBJ       1.4501350691522438e-03
    x[2,0]    onehot_2  1
    x[2,0]    w_lb_2_0  -2.6697177726926005e-02
    x[2,0]    w_ub_2_0  -6.7365269461077862e-02
    x[2,1]    OBJ       0.002915732935279
    x[2,1]    onehot_2  1
    x[2,1]    w_lb_2_1  -2.6697177726926005e-02
    x[2,1]    w_ub_2_1  -6.7365269461077862e-02
    x[2,1]    hard_lower  1
    x[2,1]    hard_upper  1
    x[2,2]    OBJ       4.3813308014057631e-03
    x[2,2]    onehot_2  1
    x[2,2]    w_lb_2_2  -2.6697177726926005e-02
    x[2,2]    w_ub_2_2  -6.7365269461077862e-02
    x[2,2]    hard_lower  2
    x[2,2]    hard_upper  2
    x[2,3]    OBJ       0.00449060739475903
    x[2,3]    onehot_2  1
    x[2,3]    w_lb_2_3  -2.6697177726926005e-02
    x[2,3]    w_ub_2_3  -6.7365269461077862e-02
    x[2,3]    hard_lower  3
    x[2,3]    hard_upper  3
    x[2,4]    OBJ       7.3125265336592788e-03
    x[2,4]    onehot_2  1
    x[2,4]    w_lb_2_4  -2.6697177726926005e-02
    x[2,4]    w_ub_2_4  -6.7365269461077862e-02
    x[2,4]    hard_lower  4
    x[2,4]    hard_upper  4
    x[2,5]    OBJ       0.00877812439978607
    x[2,5]    onehot_2  1
    x[2,5]    w_lb_2_5  -2.6697177726926005e-02
    x[2,5]    w_ub_2_5  -6.7365269461077862e-02
    x[2,5]    hard_lower  5
    x[2,5]    hard_upper  5
    x[2,6]    OBJ       1.0243722265912818e-02
    x[2,6]    onehot_2  1
    x[2,6]    w_lb_2_6  -2.6697177726926005e-02
    x[2,6]    w_ub_2_6  -6.7365269461077862e-02
    x[2,6]    hard_lower  6
    x[2,6]    hard_upper  6
    x[2,7]    OBJ       1.0516489073258858e-02
    x[2,7]    onehot_2  1
    x[2,7]    w_lb_2_7  -2.6697177726926005e-02
    x[2,7]    w_ub_2_7  -6.7365269461077862e-02
    x[2,7]    hard_lower  7
    x[2,7]    hard_upper  7
    x[2,8]    OBJ       -8.0244437840924655e-03
    x[2,8]    onehot_2  1
    x[2,8]    w_lb_2_8  -2.6697177726926005e-02
    x[2,8]    w_ub_2_8  -6.7365269461077862e-02
    x[2,8]    hard_lower  8
    x[2,8]    hard_upper  8
    x[2,9]    OBJ       8.4844949385983869e-04
    x[2,9]    onehot_2  1
    x[2,9]    w_lb_2_9  -2.6697177726926005e-02
    x[2,9]    w_ub_2_9  -6.7365269461077862e-02
    x[2,9]    hard_lower  9
    x[2,9]    hard_upper  9
    x[2,10]   OBJ       9.7213427718121446e-03
    x[2,10]   onehot_2  1
    x[2,10]   w_lb_2_10  -2.6697177726926005e-02
    x[2,10]   w_ub_2_10  -6.7365269461077862e-02
    x[2,10]   hard_lower  10
    x[2,10]   hard_upper  10
    x[2,11]   OBJ       7.0734439253947552e-03
    x[2,11]   onehot_2  1
    x[2,11]   w_lb_2_11  -2.6697177726926005e-02
    x[2,11]   w_ub_2_11  -6.7365269461077862e-02
    x[2,11]   hard_lower  11
    x[2,11]   hard_upper  11
    x[2,12]   OBJ       -1.0074674132091078e-02
    x[2,12]   onehot_2  1
    x[2,12]   w_lb_2_12  -2.6697177726926005e-02
    x[2,12]   w_ub_2_12  -6.7365269461077862e-02
    x[2,12]   hard_lower  12
    x[2,12]   hard_upper  12
    x[2,13]   OBJ       -1.0516489073258859e-02
    x[2,13]   onehot_2  1
    x[2,13]   w_lb_2_13  -2.6697177726926005e-02
    x[2,13]   w_ub_2_13  -6.7365269461077862e-02
    x[2,13]   hard_lower  13
    x[2,13]   hard_upper  13
    x[2,14]   OBJ       -1.6435957953065449e-03
    x[2,14]   onehot_2  1
    x[2,14]   w_lb_2_14  -2.6697177726926005e-02
    x[2,14]   w_ub_2_14  -6.7365269461077862e-02
    x[2,14]   hard_lower  14
    x[2,14]   hard_upper  14
    x[2,15]   OBJ       4.0296736966316674e-03
    x[2,15]   onehot_2  1
    x[2,15]   w_lb_2_15  -2.6697177726926005e-02
    x[2,15]   w_ub_2_15  -6.7365269461077862e-02
    x[2,15]   hard_lower  15
    x[2,15]   hard_upper  15
    x[3,0]    OBJ       5.9391992522193279e-03
    x[3,0]    onehot_3  1
    x[3,0]    w_lb_3_0  -2.6697177726926005e-02
    x[3,0]    w_ub_3_0  -6.7365269461077862e-02
    x[3,1]    OBJ       5.9047971183460793e-03
    x[3,1]    onehot_3  1
    x[3,1]    w_lb_3_1  -2.6697177726926005e-02
    x[3,1]    w_ub_3_1  -6.7365269461077862e-02
    x[3,1]    hard_lower  1
    x[3,1]    hard_upper  1
    x[3,2]    OBJ       5.8703949844728376e-03
    x[3,2]    onehot_3  1
    x[3,2]    w_lb_3_2  -2.6697177726926005e-02
    x[3,2]    w_ub_3_2  -6.7365269461077862e-02
    x[3,2]    hard_lower  2
    x[3,2]    hard_upper  2
    x[3,3]    OBJ       5.0123711162556525e-03
    x[3,3]    onehot_3  1
    x[3,3]    w_lb_3_3  -2.6697177726926005e-02
    x[3,3]    w_ub_3_3  -6.7365269461077862e-02
    x[3,3]    hard_lower  3
    x[3,3]    hard_upper  3
    x[3,4]    OBJ       -3.5425598493582892e-03
    x[3,4]    onehot_3  1
    x[3,4]    w_lb_3_4  -2.6697177726926005e-02
    x[3,4]    w_ub_3_4  -6.7365269461077862e-02
    x[3,4]    hard_lower  4
    x[3,4]    hard_upper  4
    x[3,5]    OBJ       5.7671885828531168e-03
    x[3,5]    onehot_3  1
    x[3,5]    w_lb_3_5  -2.6697177726926005e-02
    x[3,5]    w_ub_3_5  -6.7365269461077862e-02
    x[3,5]    hard_lower  5
    x[3,5]    hard_upper  5
    x[3,6]    OBJ       5.4834248858160392e-03
    x[3,6]    onehot_3  1
    x[3,6]    w_lb_3_6  -2.6697177726926005e-02
    x[3,6]    w_ub_3_6  -6.7365269461077862e-02
    x[3,6]    hard_lower  6
    x[3,6]    hard_upper  6
    x[3,7]    OBJ       5.6983843151066334e-03
    x[3,7]    onehot_3  1
    x[3,7]    w_lb_3_7  -2.6697177726926005e-02
    x[3,7]    w_ub_3_7  -6.7365269461077862e-02
    x[3,7]    hard_lower  7
    x[3,7]    hard_upper  7
    x[3,8]    OBJ       4.4680110551787887e-03
    x[3,8]    onehot_3  1
    x[3,8]    w_lb_3_8  -2.6697177726926005e-02
    x[3,8]    w_ub_3_8  -6.7365269461077862e-02
    x[3,8]    hard_lower  8
    x[3,8]    hard_upper  8
    x[3,9]    OBJ       -3.7575459231823649e-03
    x[3,9]    onehot_3  1
    x[3,9]    w_lb_3_9  -2.6697177726926005e-02
    x[3,9]    w_ub_3_9  -6.7365269461077862e-02
    x[3,9]    hard_lower  9
    x[3,9]    hard_upper  9
    x[3,10]   OBJ       -6.0805183392818839e-03
    x[3,10]   onehot_3  1
    x[3,10]   w_lb_3_10  -2.6697177726926005e-02
    x[3,10]   w_ub_3_10  -6.7365269461077862e-02
    x[3,10]   hard_lower  10
    x[3,10]   hard_upper  10
    x[3,11]   OBJ       2.3505599975026450e-03
    x[3,11]   onehot_3  1
    x[3,11]   w_lb_3_11  -2.6697177726926005e-02
    x[3,11]   w_ub_3_11  -6.7365269461077862e-02
    x[3,11]   hard_lower  11
    x[3,11]   hard_upper  11
    x[3,12]   OBJ       1.0781638334287177e-02
    x[3,12]   onehot_3  1
    x[3,12]   w_lb_3_12  -2.6697177726926005e-02
    x[3,12]   w_ub_3_12  -6.7365269461077862e-02
    x[3,12]   hard_lower  12
    x[3,12]   hard_upper  12
    x[3,13]   OBJ       -0.00901437856961606
    x[3,13]   onehot_3  1
    x[3,13]   w_lb_3_13  -2.6697177726926005e-02
    x[3,13]   w_ub_3_13  -6.7365269461077862e-02
    x[3,13]   hard_lower  13
    x[3,13]   hard_upper  13
    x[3,14]   OBJ       -9.8980084519516148e-03
    x[3,14]   onehot_3  1
    x[3,14]   w_lb_3_14  -2.6697177726926005e-02
    x[3,14]   w_ub_3_14  -6.7365269461077862e-02
    x[3,14]   hard_lower  14
    x[3,14]   hard_upper  14
    x[3,15]   OBJ       -1.0781638334287177e-02
    x[3,15]   onehot_3  1
    x[3,15]   w_lb_3_15  -2.6697177726926005e-02
    x[3,15]   w_ub_3_15  -6.7365269461077862e-02
    x[3,15]   hard_lower  15
    x[3,15]   hard_upper  15
    x[3,16]   OBJ       -5.5501837835167326e-03
    x[3,16]   onehot_3  1
    x[3,16]   w_lb_3_16  -2.6697177726926005e-02
    x[3,16]   w_ub_3_16  -6.7365269461077862e-02
    x[3,16]   hard_lower  16
    x[3,16]   hard_upper  16
    x[3,17]   OBJ       0.0028808945532678
    x[3,17]   onehot_3  1
    x[3,17]   w_lb_3_17  -2.6697177726926005e-02
    x[3,17]   w_ub_3_17  -6.7365269461077862e-02
    x[3,17]   hard_lower  17
    x[3,17]   hard_upper  17
    x[4,0]    OBJ       8.5371953976189248e-04
    x[4,0]    onehot_4  1
    x[4,0]    w_lb_4_0  -2.6697177726926005e-02
    x[4,0]    w_ub_4_0  -6.7365269461077862e-02
    x[4,1]    OBJ       2.3193174058886486e-03
    x[4,1]    onehot_4  1
    x[4,1]    w_lb_4_1  -2.6697177726926005e-02
    x[4,1]    w_ub_4_1  -6.7365269461077862e-02
    x[4,1]    hard_lower  1
    x[4,1]    hard_upper  1
    x[4,2]    OBJ       3.7849152720154117e-03
    x[4,2]    onehot_4  1
    x[4,2]    w_lb_4_2  -2.6697177726926005e-02
    x[4,2]    w_ub_4_2  -6.7365269461077862e-02
    x[4,2]    hard_lower  2
    x[4,2]    hard_upper  2
    x[4,3]    OBJ       2.0964913128107433e-03
    x[4,3]    onehot_4  1
    x[4,3]    w_lb_4_3  -2.6697177726926005e-02
    x[4,3]    w_ub_4_3  -6.7365269461077862e-02
    x[4,3]    hard_lower  3
    x[4,3]    hard_upper  3
    x[4,4]    OBJ       -1.8199644018169359e-03
    x[4,4]    onehot_4  1
    x[4,4]    w_lb_4_4  -2.6697177726926005e-02
    x[4,4]    w_ub_4_4  -6.7365269461077862e-02
    x[4,4]    hard_lower  4
    x[4,4]    hard_upper  4
    x[4,5]    OBJ       7.6082891411376665e-03
    x[4,5]    onehot_4  1
    x[4,5]    w_lb_4_5  -2.6697177726926005e-02
    x[4,5]    w_ub_4_5  -6.7365269461077862e-02
    x[4,5]    hard_lower  5
    x[4,5]    hard_upper  5
    x[4,6]    OBJ       0.00964730673652245
    x[4,6]    onehot_4  1
    x[4,6]    w_lb_4_6  -2.6697177726926005e-02
    x[4,6]    w_ub_4_6  -6.7365269461077862e-02
    x[4,6]    hard_lower  6
    x[4,6]    hard_upper  6
    x[4,7]    OBJ       1.1112904602649210e-02
    x[4,7]    onehot_4  1
    x[4,7]    w_lb_4_7  -2.6697177726926005e-02
    x[4,7]    w_ub_4_7  -6.7365269461077862e-02
    x[4,7]    hard_lower  7
    x[4,7]    hard_upper  7
    x[4,8]    OBJ       -8.6208593134828159e-03
    x[4,8]    onehot_4  1
    x[4,8]    w_lb_4_8  -2.6697177726926005e-02
    x[4,8]    w_ub_4_8  -6.7365269461077862e-02
    x[4,8]    hard_lower  8
    x[4,8]    hard_upper  8
    x[4,9]    OBJ       2.5203396446948738e-04
    x[4,9]    onehot_4  1
    x[4,9]    w_lb_4_9  -2.6697177726926005e-02
    x[4,9]    w_ub_4_9  -6.7365269461077862e-02
    x[4,9]    hard_lower  9
    x[4,9]    hard_upper  9
    x[4,10]   OBJ       9.1249272424217941e-03
    x[4,10]   onehot_4  1
    x[4,10]   w_lb_4_10  -2.6697177726926005e-02
    x[4,10]   w_ub_4_10  -6.7365269461077862e-02
    x[4,10]   hard_lower  10
    x[4,10]   hard_upper  10
    x[4,11]   OBJ       6.4770283960044039e-03
    x[4,11]   onehot_4  1
    x[4,11]   w_lb_4_11  -2.6697177726926005e-02
    x[4,11]   w_ub_4_11  -6.7365269461077862e-02
    x[4,11]   hard_lower  11
    x[4,11]   hard_upper  11
    x[4,12]   OBJ       -1.0671089661481429e-02
    x[4,12]   onehot_4  1
    x[4,12]   w_lb_4_12  -2.6697177726926005e-02
    x[4,12]   w_ub_4_12  -6.7365269461077862e-02
    x[4,12]   hard_lower  12
    x[4,12]   hard_upper  12
    x[4,13]   OBJ       -1.1112904602649210e-02
    x[4,13]   onehot_4  1
    x[4,13]   w_lb_4_13  -2.6697177726926005e-02
    x[4,13]   w_ub_4_13  -6.7365269461077862e-02
    x[4,13]   hard_lower  13
    x[4,13]   hard_upper  13
    x[4,14]   OBJ       -2.2400113246968962e-03
    x[4,14]   onehot_4  1
    x[4,14]   w_lb_4_14  -2.6697177726926005e-02
    x[4,14]   w_ub_4_14  -6.7365269461077862e-02
    x[4,14]   hard_lower  14
    x[4,14]   hard_upper  14
    x[4,15]   OBJ       3.4332581672413161e-03
    x[4,15]   onehot_4  1
    x[4,15]   w_lb_4_15  -2.6697177726926005e-02
    x[4,15]   w_ub_4_15  -6.7365269461077862e-02
    x[4,15]   hard_lower  15
    x[4,15]   hard_upper  15
    x[5,0]    OBJ       5.9391992522193193e-03
    x[5,0]    onehot_5  1
    x[5,0]    w_lb_5_0  -2.6697177726926005e-02
    x[5,0]    w_ub_5_0  -6.7365269461077862e-02
    x[5,1]    OBJ       5.9047971183460706e-03
    x[5,1]    onehot_5  1
    x[5,1]    w_lb_5_1  -2.6697177726926005e-02
    x[5,1]    w_ub_5_1  -6.7365269461077862e-02
    x[5,1]    hard_lower  1
    x[5,1]    hard_upper  1
    x[5,2]    OBJ       1.5973060654478309e-03
    x[5,2]    onehot_5  1
    x[5,2]    w_lb_5_2  -2.6697177726926005e-02
    x[5,2]    w_ub_5_2  -6.7365269461077862e-02
    x[5,2]    hard_lower  2
    x[5,2]    hard_upper  2
    x[5,3]    OBJ       5.8359928505995941e-03
    x[5,3]    onehot_5  1
    x[5,3]    w_lb_5_3  -2.6697177726926005e-02
    x[5,3]    w_ub_5_3  -6.7365269461077862e-02
    x[5,3]    hard_lower  3
    x[5,3]    hard_upper  3
    x[5,4]    OBJ       -4.0617353096380950e-03
    x[5,4]    onehot_5  1
    x[5,4]    w_lb_5_4  -2.6697177726926005e-02
    x[5,4]    w_ub_5_4  -6.7365269461077862e-02
    x[5,4]    hard_lower  4
    x[5,4]    hard_upper  4
    x[5,5]    OBJ       5.7671885828531107e-03
    x[5,5]    onehot_5  1
    x[5,5]    w_lb_5_5  -2.6697177726926005e-02
    x[5,5]    w_ub_5_5  -6.7365269461077862e-02
    x[5,5]    hard_lower  5
    x[5,5]    hard_upper  5
    x[5,6]    OBJ       5.7327864489798760e-03
    x[5,6]    onehot_5  1
    x[5,6]    w_lb_5_6  -2.6697177726926005e-02
    x[5,6]    w_ub_5_6  -6.7365269461077862e-02
    x[5,6]    hard_lower  6
    x[5,6]    hard_upper  6
    x[5,7]    OBJ       5.6983843151066282e-03
    x[5,7]    onehot_5  1
    x[5,7]    w_lb_5_7  -2.6697177726926005e-02
    x[5,7]    w_ub_5_7  -6.7365269461077862e-02
    x[5,7]    hard_lower  7
    x[5,7]    hard_upper  7
    x[5,8]    OBJ       3.7812436724157968e-03
    x[5,8]    onehot_5  1
    x[5,8]    w_lb_5_8  -2.6697177726926005e-02
    x[5,8]    w_ub_5_8  -6.7365269461077862e-02
    x[5,8]    hard_lower  8
    x[5,8]    hard_upper  8
    x[5,9]    OBJ       -3.7575459231823666e-03
    x[5,9]    onehot_5  1
    x[5,9]    w_lb_5_9  -2.6697177726926005e-02
    x[5,9]    w_ub_5_9  -6.7365269461077862e-02
    x[5,9]    hard_lower  9
    x[5,9]    hard_upper  9
    x[5,10]   OBJ       -6.0805183392818787e-03
    x[5,10]   onehot_5  1
    x[5,10]   w_lb_5_10  -2.6697177726926005e-02
    x[5,10]   w_ub_5_10  -6.7365269461077862e-02
    x[5,10]   hard_lower  10
    x[5,10]   hard_upper  10
    x[5,11]   OBJ       2.3505599975026433e-03
    x[5,11]   onehot_5  1
    x[5,11]   w_lb_5_11  -2.6697177726926005e-02
    x[5,11]   w_ub_5_11  -6.7365269461077862e-02
    x[5,11]   hard_lower  11
    x[5,11]   hard_upper  11
    x[5,12]   OBJ       1.0781638334287169e-02
    x[5,12]   onehot_5  1
    x[5,12]   w_lb_5_12  -2.6697177726926005e-02
    x[5,12]   w_ub_5_12  -6.7365269461077862e-02
    x[5,12]   hard_lower  12
    x[5,12]   hard_upper  12
    x[5,13]   OBJ       -0.00901437856961605
    x[5,13]   onehot_5  1
    x[5,13]   w_lb_5_13  -2.6697177726926005e-02
    x[5,13]   w_ub_5_13  -6.7365269461077862e-02
    x[5,13]   hard_lower  13
    x[5,13]   hard_upper  13
    x[5,14]   OBJ       -9.8980084519516131e-03
    x[5,14]   onehot_5  1
    x[5,14]   w_lb_5_14  -2.6697177726926005e-02
    x[5,14]   w_ub_5_14  -6.7365269461077862e-02
    x[5,14]   hard_lower  14
    x[5,14]   hard_upper  14
    x[5,15]   OBJ       -1.0781638334287169e-02
    x[5,15]   onehot_5  1
    x[5,15]   w_lb_5_15  -2.6697177726926005e-02
    x[5,15]   w_ub_5_15  -6.7365269461077862e-02
    x[5,15]   hard_lower  15
    x[5,15]   hard_upper  15
    x[5,16]   OBJ       -5.5501837835167274e-03
    x[5,16]   onehot_5  1
    x[5,16]   w_lb_5_16  -2.6697177726926005e-02
    x[5,16]   w_ub_5_16  -6.7365269461077862e-02
    x[5,16]   hard_lower  16
    x[5,16]   hard_upper  16
    x[6,0]    OBJ       -1.2707289495730131e-02
    x[6,0]    onehot_6  1
    x[6,0]    w_lb_6_0  -2.6697177726926005e-02
    x[6,0]    w_ub_6_0  -6.7365269461077862e-02
    x[6,1]    OBJ       -7.4179931183355682e-04
    x[6,1]    onehot_6  1
    x[6,1]    w_lb_6_1  -2.6697177726926005e-02
    x[6,1]    w_ub_6_1  -6.7365269461077862e-02
    x[6,1]    hard_lower  1
    x[6,1]    hard_upper  1
    x[6,2]    OBJ       -2.9531245097240092e-03
    x[6,2]    onehot_6  1
    x[6,2]    w_lb_6_2  -2.6697177726926005e-02
    x[6,2]    w_ub_6_2  -6.7365269461077862e-02
    x[6,2]    hard_lower  2
    x[6,2]    hard_upper  2
    x[6,3]    OBJ       -9.1213462912490689e-04
    x[6,3]    onehot_6  1
    x[6,3]    w_lb_6_3  -2.6697177726926005e-02
    x[6,3]    w_ub_6_3  -6.7365269461077862e-02
    x[6,3]    hard_lower  3
    x[6,3]    hard_upper  3
    x[6,4]    OBJ       1.2707289495730131e-02
    x[6,4]    onehot_6  1
    x[6,4]    w_lb_6_4  -2.6697177726926005e-02
    x[6,4]    w_ub_6_4  -6.7365269461077862e-02
    x[6,4]    hard_lower  4
    x[6,4]    hard_upper  4
    x[6,5]    OBJ       8.2789834428829909e-03
    x[6,5]    onehot_6  1
    x[6,5]    w_lb_6_5  -2.6697177726926005e-02
    x[6,5]    w_ub_6_5  -6.7365269461077862e-02
    x[6,5]    hard_lower  5
    x[6,5]    hard_upper  5
    x[6,6]    OBJ       -1.6772466719395702e-03
    x[6,6]    onehot_6  1
    x[6,6]    w_lb_6_6  -2.6697177726926005e-02
    x[6,6]    w_ub_6_6  -6.7365269461077862e-02
    x[6,6]    hard_lower  6
    x[6,6]    hard_upper  6
    x[6,7]    OBJ       -1.2707289495730131e-02
    x[6,7]    onehot_6  1
    x[6,7]    w_lb_6_7  -2.6697177726926005e-02
    x[6,7]    w_ub_6_7  -6.7365269461077862e-02
    x[6,7]    hard_lower  7
    x[6,7]    hard_upper  7
    x[6,8]    OBJ       -1.2707289495730131e-02
    x[6,8]    onehot_6  1
    x[6,8]    w_lb_6_8  -2.6697177726926005e-02
    x[6,8]    w_ub_6_8  -6.7365269461077862e-02
    x[6,8]    hard_lower  8
    x[6,8]    hard_upper  8
    x[6,9]    OBJ       -1.2707289495730131e-02
    x[6,9]    onehot_6  1
    x[6,9]    w_lb_6_9  -2.6697177726926005e-02
    x[6,9]    w_ub_6_9  -6.7365269461077862e-02
    x[6,9]    hard_lower  9
    x[6,9]    hard_upper  9
    x[6,10]   OBJ       -1.2707289495730131e-02
    x[6,10]   onehot_6  1
    x[6,10]   w_lb_6_10  -2.6697177726926005e-02
    x[6,10]   w_ub_6_10  -6.7365269461077862e-02
    x[6,10]   hard_lower  10
    x[6,10]   hard_upper  10
    x[7,0]    OBJ       5.9391992522193071e-03
    x[7,0]    onehot_7  1
    x[7,0]    w_lb_7_0  -2.6697177726926005e-02
    x[7,0]    w_ub_7_0  -6.7365269461077862e-02
    x[7,1]    OBJ       5.9047971183460585e-03
    x[7,1]    onehot_7  1
    x[7,1]    w_lb_7_1  -2.6697177726926005e-02
    x[7,1]    w_ub_7_1  -6.7365269461077862e-02
    x[7,1]    hard_lower  1
    x[7,1]    hard_upper  1
    x[7,2]    OBJ       5.8703949844728237e-03
    x[7,2]    onehot_7  1
    x[7,2]    w_lb_7_2  -2.6697177726926005e-02
    x[7,2]    w_ub_7_2  -6.7365269461077862e-02
    x[7,2]    hard_lower  2
    x[7,2]    hard_upper  2
    x[7,3]    OBJ       5.8359928505995820e-03
    x[7,3]    onehot_7  1
    x[7,3]    w_lb_7_3  -2.6697177726926005e-02
    x[7,3]    w_ub_7_3  -6.7365269461077862e-02
    x[7,3]    hard_lower  3
    x[7,3]    hard_upper  3
    x[7,4]    OBJ       5.8015907167263472e-03
    x[7,4]    onehot_7  1
    x[7,4]    w_lb_7_4  -2.6697177726926005e-02
    x[7,4]    w_ub_7_4  -6.7365269461077862e-02
    x[7,4]    hard_lower  4
    x[7,4]    hard_upper  4
    x[7,5]    OBJ       0.00466449032349839
    x[7,5]    onehot_7  1
    x[7,5]    w_lb_7_5  -2.6697177726926005e-02
    x[7,5]    w_ub_7_5  -6.7365269461077862e-02
    x[7,5]    hard_lower  5
    x[7,5]    hard_upper  5
    x[7,6]    OBJ       3.4902352349229274e-03
    x[7,6]    onehot_7  1
    x[7,6]    w_lb_7_6  -2.6697177726926005e-02
    x[7,6]    w_ub_7_6  -6.7365269461077862e-02
    x[7,6]    hard_lower  6
    x[7,6]    hard_upper  6
    x[7,7]    OBJ       5.8807815443936385e-03
    x[7,7]    onehot_7  1
    x[7,7]    w_lb_7_7  -2.6697177726926005e-02
    x[7,7]    w_ub_7_7  -6.7365269461077862e-02
    x[7,7]    hard_lower  7
    x[7,7]    hard_upper  7
    x[7,8]    OBJ       5.6639821812333865e-03
    x[7,8]    onehot_7  1
    x[7,8]    w_lb_7_8  -2.6697177726926005e-02
    x[7,8]    w_ub_7_8  -6.7365269461077862e-02
    x[7,8]    hard_lower  8
    x[7,8]    hard_upper  8
    x[7,9]    OBJ       -3.7575459231823718e-03
    x[7,9]    onehot_7  1
    x[7,9]    w_lb_7_9  -2.6697177726926005e-02
    x[7,9]    w_ub_7_9  -6.7365269461077862e-02
    x[7,9]    hard_lower  9
    x[7,9]    hard_upper  9
    x[7,10]   OBJ       -6.0805183392818839e-03
    x[7,10]   onehot_7  1
    x[7,10]   w_lb_7_10  -2.6697177726926005e-02
    x[7,10]   w_ub_7_10  -6.7365269461077862e-02
    x[7,10]   hard_lower  10
    x[7,10]   hard_upper  10
    x[7,11]   OBJ       2.3505599975026450e-03
    x[7,11]   onehot_7  1
    x[7,11]   w_lb_7_11  -2.6697177726926005e-02
    x[7,11]   w_ub_7_11  -6.7365269461077862e-02
    x[7,11]   hard_lower  11
    x[7,11]   hard_upper  11
    x[7,12]   OBJ       1.0781638334287170e-02
    x[7,12]   onehot_7  1
    x[7,12]   w_lb_7_12  -2.6697177726926005e-02
    x[7,12]   w_ub_7_12  -6.7365269461077862e-02
    x[7,12]   hard_lower  12
    x[7,12]   hard_upper  12
    x[7,13]   OBJ       -0.00901437856961606
    x[7,13]   onehot_7  1
    x[7,13]   w_lb_7_13  -2.6697177726926005e-02
    x[7,13]   w_ub_7_13  -6.7365269461077862e-02
    x[7,13]   hard_lower  13
    x[7,13]   hard_upper  13
    x[7,14]   OBJ       -9.8980084519516148e-03
    x[7,14]   onehot_7  1
    x[7,14]   w_lb_7_14  -2.6697177726926005e-02
    x[7,14]   w_ub_7_14  -6.7365269461077862e-02
    x[7,14]   hard_lower  14
    x[7,14]   hard_upper  14
    x[7,15]   OBJ       -1.0781638334287170e-02
    x[7,15]   onehot_7  1
    x[7,15]   w_lb_7_15  -2.6697177726926005e-02
    x[7,15]   w_ub_7_15  -6.7365269461077862e-02
    x[7,15]   hard_lower  15
    x[7,15]   hard_upper  15
    x[7,16]   OBJ       -5.5501837835167257e-03
    x[7,16]   onehot_7  1
    x[7,16]   w_lb_7_16  -2.6697177726926005e-02
    x[7,16]   w_ub_7_16  -6.7365269461077862e-02
    x[7,16]   hard_lower  16
    x[7,16]   hard_upper  16
    x[7,17]   OBJ       2.8808945532678067e-03
    x[7,17]   onehot_7  1
    x[7,17]   w_lb_7_17  -2.6697177726926005e-02
    x[7,17]   w_ub_7_17  -6.7365269461077862e-02
    x[7,17]   hard_lower  17
    x[7,17]   hard_upper  17
    x[8,0]    OBJ       -1.7180848798712543e-02
    x[8,0]    onehot_8  1
    x[8,0]    w_lb_8_0  -2.6697177726926005e-02
    x[8,0]    w_ub_8_0  -6.7365269461077862e-02
    x[8,1]    OBJ       -1.7180848798712543e-02
    x[8,1]    onehot_8  1
    x[8,1]    w_lb_8_1  -2.6697177726926005e-02
    x[8,1]    w_ub_8_1  -6.7365269461077862e-02
    x[8,1]    hard_lower  1
    x[8,1]    hard_upper  1
    x[8,2]    OBJ       -1.7180848798712543e-02
    x[8,2]    onehot_8  1
    x[8,2]    w_lb_8_2  -2.6697177726926005e-02
    x[8,2]    w_ub_8_2  -6.7365269461077862e-02
    x[8,2]    hard_lower  2
    x[8,2]    hard_upper  2
    x[8,3]    OBJ       1.7376287611149534e-02
    x[8,3]    onehot_8  1
    x[8,3]    w_lb_8_3  -2.6697177726926005e-02
    x[8,3]    w_ub_8_3  -6.7365269461077862e-02
    x[8,3]    hard_lower  3
    x[8,3]    hard_upper  3
    x[8,4]    OBJ       1.4341885477276299e-02
    x[8,4]    onehot_8  1
    x[8,4]    w_lb_8_4  -2.6697177726926005e-02
    x[8,4]    w_ub_8_4  -6.7365269461077862e-02
    x[8,4]    hard_lower  4
    x[8,4]    hard_upper  4
    x[8,5]    OBJ       -1.8679396630617287e-03
    x[8,5]    onehot_8  1
    x[8,5]    w_lb_8_5  -2.6697177726926005e-02
    x[8,5]    w_ub_8_5  -6.7365269461077862e-02
    x[8,5]    hard_lower  5
    x[8,5]    hard_upper  5
    x[8,6]    OBJ       8.2730812095298135e-03
    x[8,6]    onehot_8  1
    x[8,6]    w_lb_8_6  -2.6697177726926005e-02
    x[8,6]    w_ub_8_6  -6.7365269461077862e-02
    x[8,6]    hard_lower  6
    x[8,6]    hard_upper  6
    x[8,7]    OBJ       5.0319584994110286e-03
    x[8,7]    onehot_8  1
    x[8,7]    w_lb_8_7  -2.6697177726926005e-02
    x[8,7]    w_ub_8_7  -6.7365269461077862e-02
    x[8,7]    hard_lower  7
    x[8,7]    hard_upper  7
    x[8,8]    OBJ       2.2042769417833360e-03
    x[8,8]    onehot_8  1
    x[8,8]    w_lb_8_8  -2.6697177726926005e-02
    x[8,8]    w_ub_8_8  -6.7365269461077862e-02
    x[8,8]    hard_lower  8
    x[8,8]    hard_upper  8
    x[8,9]    OBJ       -8.3012519208990835e-04
    x[8,9]    onehot_8  1
    x[8,9]    w_lb_8_9  -2.6697177726926005e-02
    x[8,9]    w_ub_8_9  -6.7365269461077862e-02
    x[8,9]    hard_lower  9
    x[8,9]    hard_upper  9
    x[8,10]   OBJ       -4.8353346798320684e-03
    x[8,10]   onehot_8  1
    x[8,10]   w_lb_8_10  -2.6697177726926005e-02
    x[8,10]   w_ub_8_10  -6.7365269461077862e-02
    x[8,10]   hard_lower  10
    x[8,10]   hard_upper  10
    x[8,11]   OBJ       -1.7180848798712543e-02
    x[8,11]   onehot_8  1
    x[8,11]   w_lb_8_11  -2.6697177726926005e-02
    x[8,11]   w_ub_8_11  -6.7365269461077862e-02
    x[8,11]   hard_lower  11
    x[8,11]   hard_upper  11
    x[8,12]   OBJ       -1.7376287611149538e-02
    x[8,12]   onehot_8  1
    x[8,12]   w_lb_8_12  -2.6697177726926005e-02
    x[8,12]   w_ub_8_12  -6.7365269461077862e-02
    x[8,12]   hard_lower  12
    x[8,12]   hard_upper  12
    x[8,13]   OBJ       -9.8288391567005664e-03
    x[8,13]   onehot_8  1
    x[8,13]   w_lb_8_13  -2.6697177726926005e-02
    x[8,13]   w_ub_8_13  -6.7365269461077862e-02
    x[8,13]   hard_lower  13
    x[8,13]   hard_upper  13
    x[8,14]   OBJ       -1.7180848798712543e-02
    x[8,14]   onehot_8  1
    x[8,14]   w_lb_8_14  -2.6697177726926005e-02
    x[8,14]   w_ub_8_14  -6.7365269461077862e-02
    x[8,14]   hard_lower  14
    x[8,14]   hard_upper  14
    x[8,15]   OBJ       -1.7180848798712543e-02
    x[8,15]   onehot_8  1
    x[8,15]   w_lb_8_15  -2.6697177726926005e-02
    x[8,15]   w_ub_8_15  -6.7365269461077862e-02
    x[8,15]   hard_lower  15
    x[8,15]   hard_upper  15
    x[8,16]   OBJ       -1.7180848798712543e-02
    x[8,16]   onehot_8  1
    x[8,16]   w_lb_8_16  -2.6697177726926005e-02
    x[8,16]   w_ub_8_16  -6.7365269461077862e-02
    x[8,16]   hard_lower  16
    x[8,16]   hard_upper  16
    x[8,17]   OBJ       -1.7180848798712543e-02
    x[8,17]   onehot_8  1
    x[8,17]   w_lb_8_17  -2.6697177726926005e-02
    x[8,17]   w_ub_8_17  -6.7365269461077862e-02
    x[8,17]   hard_lower  17
    x[8,17]   hard_upper  17
    x[8,18]   OBJ       -1.7180848798712543e-02
    x[8,18]   onehot_8  1
    x[8,18]   w_lb_8_18  -2.6697177726926005e-02
    x[8,18]   w_ub_8_18  -6.7365269461077862e-02
    x[8,18]   hard_lower  18
    x[8,18]   hard_upper  18
    x[8,19]   OBJ       -1.1400660108934693e-02
    x[8,19]   onehot_8  1
    x[8,19]   w_lb_8_19  -2.6697177726926005e-02
    x[8,19]   w_ub_8_19  -6.7365269461077862e-02
    x[8,19]   hard_lower  19
    x[8,19]   hard_upper  19
    x[8,20]   OBJ       -0.00705283544049982
    x[8,20]   onehot_8  1
    x[8,20]   w_lb_8_20  -2.6697177726926005e-02
    x[8,20]   w_ub_8_20  -6.7365269461077862e-02
    x[8,20]   hard_lower  20
    x[8,20]   hard_upper  20
    x[8,21]   OBJ       4.9461301394917220e-04
    x[8,21]   onehot_8  1
    x[8,21]   w_lb_8_21  -2.6697177726926005e-02
    x[8,21]   w_ub_8_21  -6.7365269461077862e-02
    x[8,21]   hard_lower  21
    x[8,21]   hard_upper  21
    x[9,0]    OBJ       -5.4088055029832844e-03
    x[9,0]    onehot_9  1
    x[9,0]    w_lb_9_0  -2.6697177726926005e-02
    x[9,0]    w_ub_9_0  -6.7365269461077862e-02
    x[9,1]    OBJ       -9.4320763685652731e-04
    x[9,1]    onehot_9  1
    x[9,1]    w_lb_9_1  -2.6697177726926005e-02
    x[9,1]    w_ub_9_1  -6.7365269461077862e-02
    x[9,1]    hard_lower  1
    x[9,1]    hard_upper  1
    x[9,2]    OBJ       2.5064506213025983e-03
    x[9,2]    onehot_9  1
    x[9,2]    w_lb_9_2  -2.6697177726926005e-02
    x[9,2]    w_ub_9_2  -6.7365269461077862e-02
    x[9,2]    hard_lower  2
    x[9,2]    hard_upper  2
    x[9,3]    OBJ       7.9879880953969921e-03
    x[9,3]    onehot_9  1
    x[9,3]    w_lb_9_3  -2.6697177726926005e-02
    x[9,3]    w_ub_9_3  -6.7365269461077862e-02
    x[9,3]    hard_lower  3
    x[9,3]    hard_upper  3
    x[9,4]    OBJ       1.2960993029936528e-02
    x[9,4]    onehot_9  1
    x[9,4]    w_lb_9_4  -2.6697177726926005e-02
    x[9,4]    w_ub_9_4  -6.7365269461077862e-02
    x[9,4]    hard_lower  4
    x[9,4]    hard_upper  4
    x[9,5]    OBJ       1.1275512392756528e-02
    x[9,5]    onehot_9  1
    x[9,5]    w_lb_9_5  -2.6697177726926005e-02
    x[9,5]    w_ub_9_5  -6.7365269461077862e-02
    x[9,5]    hard_lower  5
    x[9,5]    hard_upper  5
    x[9,6]    OBJ       -1.9309502061459691e-03
    x[9,6]    onehot_9  1
    x[9,6]    w_lb_9_6  -2.6697177726926005e-02
    x[9,6]    w_ub_9_6  -6.7365269461077862e-02
    x[9,6]    hard_lower  6
    x[9,6]    hard_upper  6
    x[9,7]    OBJ       0.00782557295414189
    x[9,7]    onehot_9  1
    x[9,7]    w_lb_9_7  -2.6697177726926005e-02
    x[9,7]    w_ub_9_7  -6.7365269461077862e-02
    x[9,7]    hard_lower  7
    x[9,7]    hard_upper  7
    x[9,8]    OBJ       -5.4088055029832844e-03
    x[9,8]    onehot_9  1
    x[9,8]    w_lb_9_8  -2.6697177726926005e-02
    x[9,8]    w_ub_9_8  -6.7365269461077862e-02
    x[9,8]    hard_lower  8
    x[9,8]    hard_upper  8
    x[9,9]    OBJ       -1.0203184185090223e-02
    x[9,9]    onehot_9  1
    x[9,9]    w_lb_9_9  -2.6697177726926005e-02
    x[9,9]    w_ub_9_9  -6.7365269461077862e-02
    x[9,9]    hard_lower  9
    x[9,9]    hard_upper  9
    x[9,10]   OBJ       -1.2960993029936528e-02
    x[9,10]   onehot_9  1
    x[9,10]   w_lb_9_10  -2.6697177726926005e-02
    x[9,10]   w_ub_9_10  -6.7365269461077862e-02
    x[9,10]   hard_lower  10
    x[9,10]   hard_upper  10
    x[9,11]   OBJ       -3.2044698696486722e-03
    x[9,11]   onehot_9  1
    x[9,11]   w_lb_9_11  -2.6697177726926005e-02
    x[9,11]   w_ub_9_11  -6.7365269461077862e-02
    x[9,11]   hard_lower  11
    x[9,11]   hard_upper  11
    x[9,12]   OBJ       6.5520532906391780e-03
    x[9,12]   onehot_9  1
    x[9,12]   w_lb_9_12  -2.6697177726926005e-02
    x[9,12]   w_ub_9_12  -6.7365269461077862e-02
    x[9,12]   hard_lower  12
    x[9,12]   hard_upper  12
    x[10,0]   OBJ       3.7808995864388861e-03
    x[10,0]   onehot_10  1
    x[10,0]   w_lb_10_0  -2.6697177726926005e-02
    x[10,0]   w_ub_10_0  -6.7365269461077862e-02
    x[10,1]   OBJ       3.7808995864388861e-03
    x[10,1]   onehot_10  1
    x[10,1]   w_lb_10_1  -2.6697177726926005e-02
    x[10,1]   w_ub_10_1  -6.7365269461077862e-02
    x[10,1]   hard_lower  1
    x[10,1]   hard_upper  1
    x[10,2]   OBJ       3.7808995864388861e-03
    x[10,2]   onehot_10  1
    x[10,2]   w_lb_10_2  -2.6697177726926005e-02
    x[10,2]   w_ub_10_2  -6.7365269461077862e-02
    x[10,2]   hard_lower  2
    x[10,2]   hard_upper  2
    x[10,3]   OBJ       3.7808995864388861e-03
    x[10,3]   onehot_10  1
    x[10,3]   w_lb_10_3  -2.6697177726926005e-02
    x[10,3]   w_ub_10_3  -6.7365269461077862e-02
    x[10,3]   hard_lower  3
    x[10,3]   hard_upper  3
    x[10,4]   OBJ       1.8144970695817102e-04
    x[10,4]   onehot_10  1
    x[10,4]   w_lb_10_4  -2.6697177726926005e-02
    x[10,4]   w_ub_10_4  -6.7365269461077862e-02
    x[10,4]   hard_lower  4
    x[10,4]   hard_upper  4
    x[10,5]   OBJ       2.0081946250070759e-02
    x[10,5]   onehot_10  1
    x[10,5]   w_lb_10_5  -2.6697177726926005e-02
    x[10,5]   w_ub_10_5  -6.7365269461077862e-02
    x[10,5]   hard_lower  5
    x[10,5]   hard_upper  5
    x[10,6]   OBJ       6.4814143008897190e-03
    x[10,6]   onehot_10  1
    x[10,6]   w_lb_10_6  -2.6697177726926005e-02
    x[10,6]   w_ub_10_6  -6.7365269461077862e-02
    x[10,6]   hard_lower  6
    x[10,6]   hard_upper  6
    x[10,7]   OBJ       -5.4151866721490905e-03
    x[10,7]   onehot_10  1
    x[10,7]   w_lb_10_7  -2.6697177726926005e-02
    x[10,7]   w_ub_10_7  -6.7365269461077862e-02
    x[10,7]   hard_lower  7
    x[10,7]   hard_upper  7
    x[10,8]   OBJ       2.9478730969539815e-03
    x[10,8]   onehot_10  1
    x[10,8]   w_lb_10_8  -2.6697177726926005e-02
    x[10,8]   w_ub_10_8  -6.7365269461077862e-02
    x[10,8]   hard_lower  8
    x[10,8]   hard_upper  8
    x[10,9]   OBJ       7.9443377145777972e-03
    x[10,9]   onehot_10  1
    x[10,9]   w_lb_10_9  -2.6697177726926005e-02
    x[10,9]   w_ub_10_9  -6.7365269461077862e-02
    x[10,9]   hard_lower  9
    x[10,9]   hard_upper  9
    x[10,10]  OBJ       3.9391282268356424e-03
    x[10,10]  onehot_10  1
    x[10,10]  w_lb_10_10  -2.6697177726926005e-02
    x[10,10]  w_ub_10_10  -6.7365269461077862e-02
    x[10,10]  hard_lower  10
    x[10,10]  hard_upper  10
    x[10,11]  OBJ       1.1486576681284616e-02
    x[10,11]  onehot_10  1
    x[10,11]  w_lb_10_11  -2.6697177726926005e-02
    x[10,11]  w_ub_10_11  -6.7365269461077862e-02
    x[10,11]  hard_lower  11
    x[10,11]  hard_upper  11
    x[10,12]  OBJ       -8.6018247044818245e-03
    x[10,12]  onehot_10  1
    x[10,12]  w_lb_10_12  -2.6697177726926005e-02
    x[10,12]  w_ub_10_12  -6.7365269461077862e-02
    x[10,12]  hard_lower  12
    x[10,12]  hard_upper  12
    x[10,13]  OBJ       -1.0543762500328565e-03
    x[10,13]  onehot_10  1
    x[10,13]  w_lb_10_13  -2.6697177726926005e-02
    x[10,13]  w_ub_10_13  -6.7365269461077862e-02
    x[10,13]  hard_lower  13
    x[10,13]  hard_upper  13
    x[10,14]  OBJ       6.4930722044161168e-03
    x[10,14]  onehot_10  1
    x[10,14]  w_lb_10_14  -2.6697177726926005e-02
    x[10,14]  w_ub_10_14  -6.7365269461077862e-02
    x[10,14]  hard_lower  14
    x[10,14]  hard_upper  14
    x[10,15]  OBJ       2.5197285344953687e-03
    x[10,15]  onehot_10  1
    x[10,15]  w_lb_10_15  -2.6697177726926005e-02
    x[10,15]  w_ub_10_15  -6.7365269461077862e-02
    x[10,15]  hard_lower  15
    x[10,15]  hard_upper  15
    x[10,16]  OBJ       -1.4029325040990168e-03
    x[10,16]  onehot_10  1
    x[10,16]  w_lb_10_16  -2.6697177726926005e-02
    x[10,16]  w_ub_10_16  -6.7365269461077862e-02
    x[10,16]  hard_lower  16
    x[10,16]  hard_upper  16
    x[10,17]  OBJ       -8.4063858920448119e-03
    x[10,17]  onehot_10  1
    x[10,17]  w_lb_10_17  -2.6697177726926005e-02
    x[10,17]  w_ub_10_17  -6.7365269461077862e-02
    x[10,17]  hard_lower  17
    x[10,17]  hard_upper  17
    x[10,18]  OBJ       -8.5893743759571893e-04
    x[10,18]  onehot_10  1
    x[10,18]  w_lb_10_18  -2.6697177726926005e-02
    x[10,18]  w_ub_10_18  -6.7365269461077862e-02
    x[10,18]  hard_lower  18
    x[10,18]  hard_upper  18
    x[10,19]  OBJ       -2.0081946250070763e-02
    x[10,19]  onehot_10  1
    x[10,19]  w_lb_10_19  -2.6697177726926005e-02
    x[10,19]  w_ub_10_19  -6.7365269461077862e-02
    x[10,19]  hard_lower  19
    x[10,19]  hard_upper  19
    x[11,0]   OBJ       -0.00650392389684858
    x[11,0]   onehot_11  1
    x[11,0]   w_lb_11_0  -2.6697177726926005e-02
    x[11,0]   w_ub_11_0  -6.7365269461077862e-02
    x[11,1]   OBJ       -0.00650392389684858
    x[11,1]   onehot_11  1
    x[11,1]   w_lb_11_1  -2.6697177726926005e-02
    x[11,1]   w_ub_11_1  -6.7365269461077862e-02
    x[11,1]   hard_lower  1
    x[11,1]   hard_upper  1
    x[11,2]   OBJ       2.4272718354049396e-03
    x[11,2]   onehot_11  1
    x[11,2]   w_lb_11_2  -2.6697177726926005e-02
    x[11,2]   w_ub_11_2  -6.7365269461077862e-02
    x[11,2]   hard_lower  2
    x[11,2]   hard_upper  2
    x[11,3]   OBJ       6.8928697015316984e-03
    x[11,3]   onehot_11  1
    x[11,3]   w_lb_11_3  -2.6697177726926005e-02
    x[11,3]   w_ub_11_3  -6.7365269461077862e-02
    x[11,3]   hard_lower  3
    x[11,3]   hard_upper  3
    x[11,4]   OBJ       1.1358467567658462e-02
    x[11,4]   onehot_11  1
    x[11,4]   w_lb_11_4  -2.6697177726926005e-02
    x[11,4]   w_ub_11_4  -6.7365269461077862e-02
    x[11,4]   hard_lower  4
    x[11,4]   hard_upper  4
    x[11,5]   OBJ       1.4056111423801795e-02
    x[11,5]   onehot_11  1
    x[11,5]   w_lb_11_5  -2.6697177726926005e-02
    x[11,5]   w_ub_11_5  -6.7365269461077862e-02
    x[11,5]   hard_lower  5
    x[11,5]   hard_upper  5
    x[11,6]   OBJ       -3.0260686000112436e-03
    x[11,6]   onehot_11  1
    x[11,6]   w_lb_11_6  -2.6697177726926005e-02
    x[11,6]   w_ub_11_6  -6.7365269461077862e-02
    x[11,6]   hard_lower  6
    x[11,6]   hard_upper  6
    x[11,7]   OBJ       -0.00650392389684858
    x[11,7]   onehot_11  1
    x[11,7]   w_lb_11_7  -2.6697177726926005e-02
    x[11,7]   w_ub_11_7  -6.7365269461077862e-02
    x[11,7]   hard_lower  7
    x[11,7]   hard_upper  7
    x[11,8]   OBJ       -0.00650392389684858
    x[11,8]   onehot_11  1
    x[11,8]   w_lb_11_8  -2.6697177726926005e-02
    x[11,8]   w_ub_11_8  -6.7365269461077862e-02
    x[11,8]   hard_lower  8
    x[11,8]   hard_upper  8
    x[11,9]   OBJ       -1.1298302578955484e-02
    x[11,9]   onehot_11  1
    x[11,9]   w_lb_11_9  -2.6697177726926005e-02
    x[11,9]   w_ub_11_9  -6.7365269461077862e-02
    x[11,9]   hard_lower  9
    x[11,9]   hard_upper  9
    x[11,10]  OBJ       -1.4056111423801795e-02
    x[11,10]  onehot_11  1
    x[11,10]  w_lb_11_10  -2.6697177726926005e-02
    x[11,10]  w_ub_11_10  -6.7365269461077862e-02
    x[11,10]  hard_lower  10
    x[11,10]  hard_upper  10
    x[11,11]  OBJ       -4.2995882635139329e-03
    x[11,11]  onehot_11  1
    x[11,11]  w_lb_11_11  -2.6697177726926005e-02
    x[11,11]  w_ub_11_11  -6.7365269461077862e-02
    x[11,11]  hard_lower  11
    x[11,11]  hard_upper  11
    x[11,12]  OBJ       5.4569348967739312e-03
    x[11,12]  onehot_11  1
    x[11,12]  w_lb_11_12  -2.6697177726926005e-02
    x[11,12]  w_ub_11_12  -6.7365269461077862e-02
    x[11,12]  hard_lower  12
    x[11,12]  hard_upper  12
    x[12,0]   OBJ       -2.9246440711662575e-03
    x[12,0]   onehot_12  1
    x[12,0]   w_lb_12_0  -2.6697177726926005e-02
    x[12,0]   w_ub_12_0  -6.7365269461077862e-02
    x[12,1]   OBJ       1.3034425861785208e-03
    x[12,1]   onehot_12  1
    x[12,1]   w_lb_12_1  -2.6697177726926005e-02
    x[12,1]   w_ub_12_1  -6.7365269461077862e-02
    x[12,1]   hard_lower  1
    x[12,1]   hard_upper  1
    x[12,2]   OBJ       2.7690404523052839e-03
    x[12,2]   onehot_12  1
    x[12,2]   w_lb_12_2  -2.6697177726926005e-02
    x[12,2]   w_ub_12_2  -6.7365269461077862e-02
    x[12,2]   hard_lower  2
    x[12,2]   hard_upper  2
    x[12,3]   OBJ       1.0264469519038859e-03
    x[12,3]   onehot_12  1
    x[12,3]   w_lb_12_3  -2.6697177726926005e-02
    x[12,3]   w_ub_12_3  -6.7365269461077862e-02
    x[12,3]   hard_lower  3
    x[12,3]   hard_upper  3
    x[12,4]   OBJ       2.9010242493047282e-03
    x[12,4]   onehot_12  1
    x[12,4]   w_lb_12_4  -2.6697177726926005e-02
    x[12,4]   w_ub_12_4  -6.7365269461077862e-02
    x[12,4]   hard_lower  4
    x[12,4]   hard_upper  4
    x[12,5]   OBJ       5.5804375268702945e-03
    x[12,5]   onehot_12  1
    x[12,5]   w_lb_12_5  -2.6697177726926005e-02
    x[12,5]   w_ub_12_5  -6.7365269461077862e-02
    x[12,5]   hard_lower  5
    x[12,5]   hard_upper  5
    x[12,6]   OBJ       1.2128779422359338e-02
    x[12,6]   onehot_12  1
    x[12,6]   w_lb_12_6  -2.6697177726926005e-02
    x[12,6]   w_ub_12_6  -6.7365269461077862e-02
    x[12,6]   hard_lower  6
    x[12,6]   hard_upper  6
    x[12,7]   OBJ       1.0097029782939086e-02
    x[12,7]   onehot_12  1
    x[12,7]   w_lb_12_7  -2.6697177726926005e-02
    x[12,7]   w_ub_12_7  -6.7365269461077862e-02
    x[12,7]   hard_lower  7
    x[12,7]   hard_upper  7
    x[12,8]   OBJ       -9.6367341331929438e-03
    x[12,8]   onehot_12  1
    x[12,8]   w_lb_12_8  -2.6697177726926005e-02
    x[12,8]   w_ub_12_8  -6.7365269461077862e-02
    x[12,8]   hard_lower  8
    x[12,8]   hard_upper  8
    x[12,9]   OBJ       -7.6384085524064047e-04
    x[12,9]   onehot_12  1
    x[12,9]   w_lb_12_9  -2.6697177726926005e-02
    x[12,9]   w_ub_12_9  -6.7365269461077862e-02
    x[12,9]   hard_lower  9
    x[12,9]   hard_upper  9
    x[12,10]  OBJ       8.1090524227116663e-03
    x[12,10]  onehot_12  1
    x[12,10]  w_lb_12_10  -2.6697177726926005e-02
    x[12,10]  w_ub_12_10  -6.7365269461077862e-02
    x[12,10]  hard_lower  10
    x[12,10]  hard_upper  10
    x[12,11]  OBJ       5.4611535762942760e-03
    x[12,11]  onehot_12  1
    x[12,11]  w_lb_12_11  -2.6697177726926005e-02
    x[12,11]  w_ub_12_11  -6.7365269461077862e-02
    x[12,11]  hard_lower  11
    x[12,11]  hard_upper  11
    x[12,12]  OBJ       -1.1686964481191555e-02
    x[12,12]  onehot_12  1
    x[12,12]  w_lb_12_12  -2.6697177726926005e-02
    x[12,12]  w_ub_12_12  -6.7365269461077862e-02
    x[12,12]  hard_lower  12
    x[12,12]  hard_upper  12
    x[12,13]  OBJ       -1.2128779422359338e-02
    x[12,13]  onehot_12  1
    x[12,13]  w_lb_12_13  -2.6697177726926005e-02
    x[12,13]  w_ub_12_13  -6.7365269461077862e-02
    x[12,13]  hard_lower  13
    x[12,13]  hard_upper  13
    x[12,14]  OBJ       -3.2558861444070240e-03
    x[12,14]  onehot_12  1
    x[12,14]  w_lb_12_14  -2.6697177726926005e-02
    x[12,14]  w_ub_12_14  -6.7365269461077862e-02
    x[12,14]  hard_lower  14
    x[12,14]  hard_upper  14
    x[12,15]  OBJ       2.4173833475311882e-03
    x[12,15]  onehot_12  1
    x[12,15]  w_lb_12_15  -2.6697177726926005e-02
    x[12,15]  w_ub_12_15  -6.7365269461077862e-02
    x[12,15]  hard_lower  15
    x[12,15]  hard_upper  15
    x[13,0]   OBJ       1.4584928059445173e-03
    x[13,0]   onehot_13  1
    x[13,0]   w_lb_13_0  -2.6697177726926005e-02
    x[13,0]   w_ub_13_0  -6.7365269461077862e-02
    x[13,1]   OBJ       1.4240906720712687e-03
    x[13,1]   onehot_13  1
    x[13,1]   w_lb_13_1  -2.6697177726926005e-02
    x[13,1]   w_ub_13_1  -6.7365269461077862e-02
    x[13,1]   hard_lower  1
    x[13,1]   hard_upper  1
    x[13,2]   OBJ       1.3896885381980270e-03
    x[13,2]   onehot_13  1
    x[13,2]   w_lb_13_2  -2.6697177726926005e-02
    x[13,2]   w_ub_13_2  -6.7365269461077862e-02
    x[13,2]   hard_lower  2
    x[13,2]   hard_upper  2
    x[13,3]   OBJ       1.3552864043247922e-03
    x[13,3]   onehot_13  1
    x[13,3]   w_lb_13_3  -2.6697177726926005e-02
    x[13,3]   w_ub_13_3  -6.7365269461077862e-02
    x[13,3]   hard_lower  3
    x[13,3]   hard_upper  3
    x[13,4]   OBJ       1.3208842704515436e-03
    x[13,4]   onehot_13  1
    x[13,4]   w_lb_13_4  -2.6697177726926005e-02
    x[13,4]   w_ub_13_4  -6.7365269461077862e-02
    x[13,4]   hard_lower  4
    x[13,4]   hard_upper  4
    x[13,5]   OBJ       1.2864821365783053e-03
    x[13,5]   onehot_13  1
    x[13,5]   w_lb_13_5  -2.6697177726926005e-02
    x[13,5]   w_ub_13_5  -6.7365269461077862e-02
    x[13,5]   hard_lower  5
    x[13,5]   hard_upper  5
    x[13,6]   OBJ       -2.2398495974368382e-04
    x[13,6]   onehot_13  1
    x[13,6]   w_lb_13_6  -2.6697177726926005e-02
    x[13,6]   w_ub_13_6  -6.7365269461077862e-02
    x[13,6]   hard_lower  6
    x[13,6]   hard_upper  6
    x[13,7]   OBJ       1.2176778688318185e-03
    x[13,7]   onehot_13  1
    x[13,7]   w_lb_13_7  -2.6697177726926005e-02
    x[13,7]   w_ub_13_7  -6.7365269461077862e-02
    x[13,7]   hard_lower  7
    x[13,7]   hard_upper  7
    x[13,8]   OBJ       -2.8106616468779946e-03
    x[13,8]   onehot_13  1
    x[13,8]   w_lb_13_8  -2.6697177726926005e-02
    x[13,8]   w_ub_13_8  -6.7365269461077862e-02
    x[13,8]   hard_lower  8
    x[13,8]   hard_upper  8
    x[13,9]   OBJ       -8.2382523694571833e-03
    x[13,9]   onehot_13  1
    x[13,9]   w_lb_13_9  -2.6697177726926005e-02
    x[13,9]   w_ub_13_9  -6.7365269461077862e-02
    x[13,9]   hard_lower  9
    x[13,9]   hard_upper  9
    x[13,10]  OBJ       -1.0561224785556702e-02
    x[13,10]  onehot_13  1
    x[13,10]  w_lb_13_10  -2.6697177726926005e-02
    x[13,10]  w_ub_13_10  -6.7365269461077862e-02
    x[13,10]  hard_lower  10
    x[13,10]  hard_upper  10
    x[13,11]  OBJ       -2.1301464487721794e-03
    x[13,11]  onehot_13  1
    x[13,11]  w_lb_13_11  -2.6697177726926005e-02
    x[13,11]  w_ub_13_11  -6.7365269461077862e-02
    x[13,11]  hard_lower  11
    x[13,11]  hard_upper  11
    x[13,12]  OBJ       6.3009318880123530e-03
    x[13,12]  onehot_13  1
    x[13,12]  w_lb_13_12  -2.6697177726926005e-02
    x[13,12]  w_ub_13_12  -6.7365269461077862e-02
    x[13,12]  hard_lower  12
    x[13,12]  hard_upper  12
    x[13,13]  OBJ       -1.3495085015890874e-02
    x[13,13]  onehot_13  1
    x[13,13]  w_lb_13_13  -2.6697177726926005e-02
    x[13,13]  w_ub_13_13  -6.7365269461077862e-02
    x[13,13]  hard_lower  13
    x[13,13]  hard_upper  13
    x[13,14]  OBJ       -1.4378714898226437e-02
    x[13,14]  onehot_13  1
    x[13,14]  w_lb_13_14  -2.6697177726926005e-02
    x[13,14]  w_ub_13_14  -6.7365269461077862e-02
    x[13,14]  hard_lower  14
    x[13,14]  hard_upper  14
    x[13,15]  OBJ       -1.5262344780562006e-02
    x[13,15]  onehot_13  1
    x[13,15]  w_lb_13_15  -2.6697177726926005e-02
    x[13,15]  w_ub_13_15  -6.7365269461077862e-02
    x[13,15]  hard_lower  15
    x[13,15]  hard_upper  15
    x[13,16]  OBJ       -1.0030890229791558e-02
    x[13,16]  onehot_13  1
    x[13,16]  w_lb_13_16  -2.6697177726926005e-02
    x[13,16]  w_ub_13_16  -6.7365269461077862e-02
    x[13,16]  hard_lower  16
    x[13,16]  hard_upper  16
    x[13,17]  OBJ       -1.5998118930070316e-03
    x[13,17]  onehot_13  1
    x[13,17]  w_lb_13_17  -2.6697177726926005e-02
    x[13,17]  w_ub_13_17  -6.7365269461077862e-02
    x[13,17]  hard_lower  17
    x[13,17]  hard_upper  17
    x[13,18]  OBJ       6.8312664437775008e-03
    x[13,18]  onehot_13  1
    x[13,18]  w_lb_13_18  -2.6697177726926005e-02
    x[13,18]  w_ub_13_18  -6.7365269461077862e-02
    x[13,18]  hard_lower  18
    x[13,18]  hard_upper  18
    x[13,19]  OBJ       1.5262344780562005e-02
    x[13,19]  onehot_13  1
    x[13,19]  w_lb_13_19  -2.6697177726926005e-02
    x[13,19]  w_ub_13_19  -6.7365269461077862e-02
    x[13,19]  hard_lower  19
    x[13,19]  hard_upper  19
    x[14,0]   OBJ       5.9391992522193071e-03
    x[14,0]   onehot_14  1
    x[14,0]   w_lb_14_0  -2.6697177726926005e-02
    x[14,0]   w_ub_14_0  -6.7365269461077862e-02
    x[14,1]   OBJ       5.9047971183460585e-03
    x[14,1]   onehot_14  1
    x[14,1]   w_lb_14_1  -2.6697177726926005e-02
    x[14,1]   w_ub_14_1  -6.7365269461077862e-02
    x[14,1]   hard_lower  1
    x[14,1]   hard_upper  1
    x[14,2]   OBJ       -4.7284131889110629e-03
    x[14,2]   onehot_14  1
    x[14,2]   w_lb_14_2  -2.6697177726926005e-02
    x[14,2]   w_ub_14_2  -6.7365269461077862e-02
    x[14,2]   hard_lower  2
    x[14,2]   hard_upper  2
    x[14,3]   OBJ       5.8359928505995820e-03
    x[14,3]   onehot_14  1
    x[14,3]   w_lb_14_3  -2.6697177726926005e-02
    x[14,3]   w_ub_14_3  -6.7365269461077862e-02
    x[14,3]   hard_lower  3
    x[14,3]   hard_upper  3
    x[14,4]   OBJ       5.8015907167263472e-03
    x[14,4]   onehot_14  1
    x[14,4]   w_lb_14_4  -2.6697177726926005e-02
    x[14,4]   w_ub_14_4  -6.7365269461077862e-02
    x[14,4]   hard_lower  4
    x[14,4]   hard_upper  4
    x[14,5]   OBJ       5.7671885828531073e-03
    x[14,5]   onehot_14  1
    x[14,5]   w_lb_14_5  -2.6697177726926005e-02
    x[14,5]   w_ub_14_5  -6.7365269461077862e-02
    x[14,5]   hard_lower  5
    x[14,5]   hard_upper  5
    x[14,6]   OBJ       5.7327864489798638e-03
    x[14,6]   onehot_14  1
    x[14,6]   w_lb_14_6  -2.6697177726926005e-02
    x[14,6]   w_ub_14_6  -6.7365269461077862e-02
    x[14,6]   hard_lower  6
    x[14,6]   hard_upper  6
    x[14,7]   OBJ       5.6983843151066273e-03
    x[14,7]   onehot_14  1
    x[14,7]   w_lb_14_7  -2.6697177726926005e-02
    x[14,7]   w_ub_14_7  -6.7365269461077862e-02
    x[14,7]   hard_lower  7
    x[14,7]   hard_upper  7
    x[14,8]   OBJ       5.6639821812333874e-03
    x[14,8]   onehot_14  1
    x[14,8]   w_lb_14_8  -2.6697177726926005e-02
    x[14,8]   w_ub_14_8  -6.7365269461077862e-02
    x[14,8]   hard_lower  8
    x[14,8]   hard_upper  8
    x[14,9]   OBJ       -3.7575459231823718e-03
    x[14,9]   onehot_14  1
    x[14,9]   w_lb_14_9  -2.6697177726926005e-02
    x[14,9]   w_ub_14_9  -6.7365269461077862e-02
    x[14,9]   hard_lower  9
    x[14,9]   hard_upper  9
    x[14,10]  OBJ       -6.0805183392818839e-03
    x[14,10]  onehot_14  1
    x[14,10]  w_lb_14_10  -2.6697177726926005e-02
    x[14,10]  w_ub_14_10  -6.7365269461077862e-02
    x[14,10]  hard_lower  10
    x[14,10]  hard_upper  10
    x[14,11]  OBJ       2.3505599975026450e-03
    x[14,11]  onehot_14  1
    x[14,11]  w_lb_14_11  -2.6697177726926005e-02
    x[14,11]  w_ub_14_11  -6.7365269461077862e-02
    x[14,11]  hard_lower  11
    x[14,11]  hard_upper  11
    x[14,12]  OBJ       1.0781638334287170e-02
    x[14,12]  onehot_14  1
    x[14,12]  w_lb_14_12  -2.6697177726926005e-02
    x[14,12]  w_ub_14_12  -6.7365269461077862e-02
    x[14,12]  hard_lower  12
    x[14,12]  hard_upper  12
    x[14,13]  OBJ       -0.00901437856961606
    x[14,13]  onehot_14  1
    x[14,13]  w_lb_14_13  -2.6697177726926005e-02
    x[14,13]  w_ub_14_13  -6.7365269461077862e-02
    x[14,13]  hard_lower  13
    x[14,13]  hard_upper  13
    x[14,14]  OBJ       -9.8980084519516148e-03
    x[14,14]  onehot_14  1
    x[14,14]  w_lb_14_14  -2.6697177726926005e-02
    x[14,14]  w_ub_14_14  -6.7365269461077862e-02
    x[14,14]  hard_lower  14
    x[14,14]  hard_upper  14
    x[14,15]  OBJ       -1.0781638334287170e-02
    x[14,15]  onehot_14  1
    x[14,15]  w_lb_14_15  -2.6697177726926005e-02
    x[14,15]  w_ub_14_15  -6.7365269461077862e-02
    x[14,15]  hard_lower  15
    x[14,15]  hard_upper  15
    x[15,0]   OBJ       -7.4176823942069311e-03
    x[15,0]   onehot_15  1
    x[15,0]   w_lb_15_0  -2.6697177726926005e-02
    x[15,0]   w_ub_15_0  -6.7365269461077862e-02
    x[15,1]   OBJ       -7.4176823942069311e-03
    x[15,1]   onehot_15  1
    x[15,1]   w_lb_15_1  -2.6697177726926005e-02
    x[15,1]   w_ub_15_1  -6.7365269461077862e-02
    x[15,1]   hard_lower  1
    x[15,1]   hard_upper  1
    x[15,2]   OBJ       1.1684472669981750e-02
    x[15,2]   onehot_15  1
    x[15,2]   w_lb_15_2  -2.6697177726926005e-02
    x[15,2]   w_ub_15_2  -6.7365269461077862e-02
    x[15,2]   hard_lower  2
    x[15,2]   hard_upper  2
    x[15,3]   OBJ       -3.3544097006113979e-03
    x[15,3]   onehot_15  1
    x[15,3]   w_lb_15_3  -2.6697177726926005e-02
    x[15,3]   w_ub_15_3  -6.7365269461077862e-02
    x[15,3]   hard_lower  3
    x[15,3]   hard_upper  3
    x[15,4]   OBJ       -7.4176823942069311e-03
    x[15,4]   onehot_15  1
    x[15,4]   w_lb_15_4  -2.6697177726926005e-02
    x[15,4]   w_ub_15_4  -6.7365269461077862e-02
    x[15,4]   hard_lower  4
    x[15,4]   hard_upper  4
    x[15,5]   OBJ       -0.00111895053055713
    x[15,5]   onehot_15  1
    x[15,5]   w_lb_15_5  -2.6697177726926005e-02
    x[15,5]   w_ub_15_5  -6.7365269461077862e-02
    x[15,5]   hard_lower  5
    x[15,5]   hard_upper  5
    x[15,6]   OBJ       5.5468641344887989e-03
    x[15,6]   onehot_15  1
    x[15,6]   w_lb_15_6  -2.6697177726926005e-02
    x[15,6]   w_ub_15_6  -6.7365269461077862e-02
    x[15,6]   hard_lower  6
    x[15,6]   hard_upper  6
    x[15,7]   OBJ       4.0124620006155593e-03
    x[15,7]   onehot_15  1
    x[15,7]   w_lb_15_7  -2.6697177726926005e-02
    x[15,7]   w_ub_15_7  -6.7365269461077862e-02
    x[15,7]   hard_lower  7
    x[15,7]   hard_upper  7
    x[15,8]   OBJ       2.4780598667423197e-03
    x[15,8]   onehot_15  1
    x[15,8]   w_lb_15_8  -2.6697177726926005e-02
    x[15,8]   w_ub_15_8  -6.7365269461077862e-02
    x[15,8]   hard_lower  8
    x[15,8]   hard_upper  8
    x[15,9]   OBJ       9.4365773286908018e-04
    x[15,9]   onehot_15  1
    x[15,9]   w_lb_15_9  -2.6697177726926005e-02
    x[15,9]   w_ub_15_9  -6.7365269461077862e-02
    x[15,9]   hard_lower  9
    x[15,9]   hard_upper  9
    x[15,10]  OBJ       -7.4176823942069311e-03
    x[15,10]  onehot_15  1
    x[15,10]  w_lb_15_10  -2.6697177726926005e-02
    x[15,10]  w_ub_15_10  -6.7365269461077862e-02
    x[15,10]  hard_lower  10
    x[15,10]  hard_upper  10
    x[15,11]  OBJ       -1.1684472669981750e-02
    x[15,11]  onehot_15  1
    x[15,11]  w_lb_15_11  -2.6697177726926005e-02
    x[15,11]  w_ub_15_11  -6.7365269461077862e-02
    x[15,11]  hard_lower  11
    x[15,11]  hard_upper  11
    x[15,12]  OBJ       -7.4176823942069311e-03
    x[15,12]  onehot_15  1
    x[15,12]  w_lb_15_12  -2.6697177726926005e-02
    x[15,12]  w_ub_15_12  -6.7365269461077862e-02
    x[15,12]  hard_lower  12
    x[15,12]  hard_upper  12
    x[15,13]  OBJ       4.2940541212517416e-03
    x[15,13]  onehot_15  1
    x[15,13]  w_lb_15_13  -2.6697177726926005e-02
    x[15,13]  w_ub_15_13  -6.7365269461077862e-02
    x[15,13]  hard_lower  13
    x[15,13]  hard_upper  13
    x[15,14]  OBJ       7.6252539249878522e-04
    x[15,14]  onehot_15  1
    x[15,14]  w_lb_15_14  -2.6697177726926005e-02
    x[15,14]  w_ub_15_14  -6.7365269461077862e-02
    x[15,14]  hard_lower  14
    x[15,14]  hard_upper  14
    x[15,15]  OBJ       -7.9545143282025079e-03
    x[15,15]  onehot_15  1
    x[15,15]  w_lb_15_15  -2.6697177726926005e-02
    x[15,15]  w_ub_15_15  -6.7365269461077862e-02
    x[15,15]  hard_lower  15
    x[15,15]  hard_upper  15
    x[15,16]  OBJ       -9.2799591517058588e-03
    x[15,16]  onehot_15  1
    x[15,16]  w_lb_15_16  -2.6697177726926005e-02
    x[15,16]  w_ub_15_16  -6.7365269461077862e-02
    x[15,16]  hard_lower  16
    x[15,16]  hard_upper  16
    x[16,0]   OBJ       4.1089393741360579e-03
    x[16,0]   onehot_16  1
    x[16,0]   w_lb_16_0  -2.6697177726926005e-02
    x[16,0]   w_ub_16_0  -6.7365269461077862e-02
    x[16,1]   OBJ       0.00490944032648509
    x[16,1]   onehot_16  1
    x[16,1]   w_lb_16_1  -2.6697177726926005e-02
    x[16,1]   w_ub_16_1  -6.7365269461077862e-02
    x[16,1]   hard_lower  1
    x[16,1]   hard_upper  1
    x[16,2]   OBJ       -2.0718261066301046e-02
    x[16,2]   onehot_16  1
    x[16,2]   w_lb_16_2  -2.6697177726926005e-02
    x[16,2]   w_ub_16_2  -6.7365269461077862e-02
    x[16,2]   hard_lower  2
    x[16,2]   hard_upper  2
    x[16,3]   OBJ       1.4787065334047528e-02
    x[16,3]   onehot_16  1
    x[16,3]   w_lb_16_3  -2.6697177726926005e-02
    x[16,3]   w_ub_16_3  -6.7365269461077862e-02
    x[16,3]   hard_lower  3
    x[16,3]   hard_upper  3
    x[16,4]   OBJ       1.7752663200174285e-02
    x[16,4]   onehot_16  1
    x[16,4]   w_lb_16_4  -2.6697177726926005e-02
    x[16,4]   w_ub_16_4  -6.7365269461077862e-02
    x[16,4]   hard_lower  4
    x[16,4]   hard_upper  4
    x[16,5]   OBJ       2.0718261066301046e-02
    x[16,5]   onehot_16  1
    x[16,5]   w_lb_16_5  -2.6697177726926005e-02
    x[16,5]   w_ub_16_5  -6.7365269461077862e-02
    x[16,5]   hard_lower  5
    x[16,5]   hard_upper  5
    x[16,6]   OBJ       1.4071178032105478e-02
    x[16,6]   onehot_16  1
    x[16,6]   w_lb_16_6  -2.6697177726926005e-02
    x[16,6]   w_ub_16_6  -6.7365269461077862e-02
    x[16,6]   hard_lower  6
    x[16,6]   hard_upper  6
    x[16,7]   OBJ       4.1089393741360579e-03
    x[16,7]   onehot_16  1
    x[16,7]   w_lb_16_7  -2.6697177726926005e-02
    x[16,7]   w_ub_16_7  -6.7365269461077862e-02
    x[16,7]   hard_lower  7
    x[16,7]   hard_upper  7
    x[16,8]   OBJ       4.1089393741360579e-03
    x[16,8]   onehot_16  1
    x[16,8]   w_lb_16_8  -2.6697177726926005e-02
    x[16,8]   w_ub_16_8  -6.7365269461077862e-02
    x[16,8]   hard_lower  8
    x[16,8]   hard_upper  8
    x[16,9]   OBJ       4.1089393741360579e-03
    x[16,9]   onehot_16  1
    x[16,9]   w_lb_16_9  -2.6697177726926005e-02
    x[16,9]   w_ub_16_9  -6.7365269461077862e-02
    x[16,9]   hard_lower  9
    x[16,9]   hard_upper  9
    x[16,10]  OBJ       4.1089393741360579e-03
    x[16,10]  onehot_16  1
    x[16,10]  w_lb_16_10  -2.6697177726926005e-02
    x[16,10]  w_ub_16_10  -6.7365269461077862e-02
    x[16,10]  hard_lower  10
    x[16,10]  hard_upper  10
    x[16,11]  OBJ       4.1089393741360579e-03
    x[16,11]  onehot_16  1
    x[16,11]  w_lb_16_11  -2.6697177726926005e-02
    x[16,11]  w_ub_16_11  -6.7365269461077862e-02
    x[16,11]  hard_lower  11
    x[16,11]  hard_upper  11
    x[16,12]  OBJ       4.1089393741360579e-03
    x[16,12]  onehot_16  1
    x[16,12]  w_lb_16_12  -2.6697177726926005e-02
    x[16,12]  w_ub_16_12  -6.7365269461077862e-02
    x[16,12]  hard_lower  12
    x[16,12]  hard_upper  12
    x[17,0]   OBJ       -9.7907563126183889e-03
    x[17,0]   onehot_17  1
    x[17,0]   w_lb_17_0  -2.6697177726926005e-02
    x[17,0]   w_ub_17_0  -6.7365269461077862e-02
    x[17,1]   OBJ       1.2451673736918375e-02
    x[17,1]   onehot_17  1
    x[17,1]   w_lb_17_1  -2.6697177726926005e-02
    x[17,1]   w_ub_17_1  -6.7365269461077862e-02
    x[17,1]   hard_lower  1
    x[17,1]   hard_upper  1
    x[17,2]   OBJ       1.0917271603045139e-02
    x[17,2]   onehot_17  1
    x[17,2]   w_lb_17_2  -2.6697177726926005e-02
    x[17,2]   w_ub_17_2  -6.7365269461077862e-02
    x[17,2]   hard_lower  2
    x[17,2]   hard_upper  2
    x[17,3]   OBJ       -6.0301952363243146e-03
    x[17,3]   onehot_17  1
    x[17,3]   w_lb_17_3  -2.6697177726926005e-02
    x[17,3]   w_ub_17_3  -6.7365269461077862e-02
    x[17,3]   hard_lower  3
    x[17,3]   hard_upper  3
    x[17,4]   OBJ       -9.7907563126183889e-03
    x[17,4]   onehot_17  1
    x[17,4]   w_lb_17_4  -2.6697177726926005e-02
    x[17,4]   w_ub_17_4  -6.7365269461077862e-02
    x[17,4]   hard_lower  4
    x[17,4]   hard_upper  4
    x[17,5]   OBJ       -9.7907563126183889e-03
    x[17,5]   onehot_17  1
    x[17,5]   w_lb_17_5  -2.6697177726926005e-02
    x[17,5]   w_ub_17_5  -6.7365269461077862e-02
    x[17,5]   hard_lower  5
    x[17,5]   hard_upper  5
    x[17,6]   OBJ       -9.7907563126183889e-03
    x[17,6]   onehot_17  1
    x[17,6]   w_lb_17_6  -2.6697177726926005e-02
    x[17,6]   w_ub_17_6  -6.7365269461077862e-02
    x[17,6]   hard_lower  6
    x[17,6]   hard_upper  6
    x[17,7]   OBJ       -3.7692651199940138e-03
    x[17,7]   onehot_17  1
    x[17,7]   w_lb_17_7  -2.6697177726926005e-02
    x[17,7]   w_ub_17_7  -6.7365269461077862e-02
    x[17,7]   hard_lower  7
    x[17,7]   hard_upper  7
    x[17,8]   OBJ       1.7108587998057017e-03
    x[17,8]   onehot_17  1
    x[17,8]   w_lb_17_8  -2.6697177726926005e-02
    x[17,8]   w_ub_17_8  -6.7365269461077862e-02
    x[17,8]   hard_lower  8
    x[17,8]   hard_upper  8
    x[17,9]   OBJ       1.7645666593245866e-04
    x[17,9]   onehot_17  1
    x[17,9]   w_lb_17_9  -2.6697177726926005e-02
    x[17,9]   w_ub_17_9  -6.7365269461077862e-02
    x[17,9]   hard_lower  9
    x[17,9]   hard_upper  9
    x[17,10]  OBJ       7.1949127076802854e-03
    x[17,10]  onehot_17  1
    x[17,10]  w_lb_17_10  -2.6697177726926005e-02
    x[17,10]  w_ub_17_10  -6.7365269461077862e-02
    x[17,10]  hard_lower  10
    x[17,10]  hard_upper  10
    x[17,11]  OBJ       -1.2451673736918375e-02
    x[17,11]  onehot_17  1
    x[17,11]  w_lb_17_11  -2.6697177726926005e-02
    x[17,11]  w_ub_17_11  -6.7365269461077862e-02
    x[17,11]  hard_lower  11
    x[17,11]  hard_upper  11
    x[17,12]  OBJ       -4.4624103413016310e-03
    x[17,12]  onehot_17  1
    x[17,12]  w_lb_17_12  -2.6697177726926005e-02
    x[17,12]  w_ub_17_12  -6.7365269461077862e-02
    x[17,12]  hard_lower  12
    x[17,12]  hard_upper  12
    x[17,13]  OBJ       3.5268530543151166e-03
    x[17,13]  onehot_17  1
    x[17,13]  w_lb_17_13  -2.6697177726926005e-02
    x[17,13]  w_ub_17_13  -6.7365269461077862e-02
    x[17,13]  hard_lower  13
    x[17,13]  hard_upper  13
    x[17,14]  OBJ       -4.6756744378467080e-06
    x[17,14]  onehot_17  1
    x[17,14]  w_lb_17_14  -2.6697177726926005e-02
    x[17,14]  w_ub_17_14  -6.7365269461077862e-02
    x[17,14]  hard_lower  14
    x[17,14]  hard_upper  14
    x[17,15]  OBJ       -0.00872171539513914
    x[17,15]  onehot_17  1
    x[17,15]  w_lb_17_15  -2.6697177726926005e-02
    x[17,15]  w_ub_17_15  -6.7365269461077862e-02
    x[17,15]  hard_lower  15
    x[17,15]  hard_upper  15
    x[17,16]  OBJ       -1.0047160218642480e-02
    x[17,16]  onehot_17  1
    x[17,16]  w_lb_17_16  -2.6697177726926005e-02
    x[17,16]  w_ub_17_16  -6.7365269461077862e-02
    x[17,16]  hard_lower  16
    x[17,16]  hard_upper  16
    x[18,0]   OBJ       -1.3367584106010043e-02
    x[18,0]   onehot_18  1
    x[18,0]   w_lb_18_0  -2.6697177726926005e-02
    x[18,0]   w_ub_18_0  -6.7365269461077862e-02
    x[18,1]   OBJ       1.3367584106010043e-02
    x[18,1]   onehot_18  1
    x[18,1]   w_lb_18_1  -2.6697177726926005e-02
    x[18,1]   w_ub_18_1  -6.7365269461077862e-02
    x[18,1]   hard_lower  1
    x[18,1]   hard_upper  1
    x[18,2]   OBJ       -1.2764213134167857e-02
    x[18,2]   onehot_18  1
    x[18,2]   w_lb_18_2  -2.6697177726926005e-02
    x[18,2]   w_ub_18_2  -6.7365269461077862e-02
    x[18,2]   hard_lower  2
    x[18,2]   hard_upper  2
    x[18,3]   OBJ       1.0298779838263564e-02
    x[18,3]   onehot_18  1
    x[18,3]   w_lb_18_3  -2.6697177726926005e-02
    x[18,3]   w_ub_18_3  -6.7365269461077862e-02
    x[18,3]   hard_lower  3
    x[18,3]   hard_upper  3
    x[18,4]   OBJ       -0.00395577997070014
    x[18,4]   onehot_18  1
    x[18,4]   w_lb_18_4  -2.6697177726926005e-02
    x[18,4]   w_ub_18_4  -6.7365269461077862e-02
    x[18,4]   hard_lower  4
    x[18,4]   hard_upper  4
    x[18,5]   OBJ       2.5805821600791284e-03
    x[18,5]   onehot_18  1
    x[18,5]   w_lb_18_5  -2.6697177726926005e-02
    x[18,5]   w_ub_18_5  -6.7365269461077862e-02
    x[18,5]   hard_lower  5
    x[18,5]   hard_upper  5
    x[18,6]   OBJ       -3.4843375571919424e-04
    x[18,6]   onehot_18  1
    x[18,6]   w_lb_18_6  -2.6697177726926005e-02
    x[18,6]   w_ub_18_6  -6.7365269461077862e-02
    x[18,6]   hard_lower  6
    x[18,6]   hard_upper  6
    x[18,7]   OBJ       3.4842610673185836e-06
    x[18,7]   onehot_18  1
    x[18,7]   w_lb_18_7  -2.6697177726926005e-02
    x[18,7]   w_ub_18_7  -6.7365269461077862e-02
    x[18,7]   hard_lower  7
    x[18,7]   hard_upper  7
    x[18,8]   OBJ       2.6267691688973693e-03
    x[18,8]   onehot_18  1
    x[18,8]   w_lb_18_8  -2.6697177726926005e-02
    x[18,8]   w_ub_18_8  -6.7365269461077862e-02
    x[18,8]   hard_lower  8
    x[18,8]   hard_upper  8
    x[18,9]   OBJ       1.0923670350241263e-03
    x[18,9]   onehot_18  1
    x[18,9]   w_lb_18_9  -2.6697177726926005e-02
    x[18,9]   w_ub_18_9  -6.7365269461077862e-02
    x[18,9]   hard_lower  9
    x[18,9]   hard_upper  9
    x[18,10]  OBJ       8.1108230767719530e-03
    x[18,10]  onehot_18  1
    x[18,10]  w_lb_18_10  -2.6697177726926005e-02
    x[18,10]  w_ub_18_10  -6.7365269461077862e-02
    x[18,10]  hard_lower  10
    x[18,10]  hard_upper  10
    x[18,11]  OBJ       -1.1535763367826708e-02
    x[18,11]  onehot_18  1
    x[18,11]  w_lb_18_11  -2.6697177726926005e-02
    x[18,11]  w_ub_18_11  -6.7365269461077862e-02
    x[18,11]  hard_lower  11
    x[18,11]  hard_upper  11
    x[18,12]  OBJ       -3.5464999722099634e-03
    x[18,12]  onehot_18  1
    x[18,12]  w_lb_18_12  -2.6697177726926005e-02
    x[18,12]  w_ub_18_12  -6.7365269461077862e-02
    x[18,12]  hard_lower  12
    x[18,12]  hard_upper  12
    x[18,13]  OBJ       4.4427634234067842e-03
    x[18,13]  onehot_18  1
    x[18,13]  w_lb_18_13  -2.6697177726926005e-02
    x[18,13]  w_ub_18_13  -6.7365269461077862e-02
    x[18,13]  hard_lower  13
    x[18,13]  hard_upper  13
    x[18,14]  OBJ       9.1123469465382093e-04
    x[18,14]  onehot_18  1
    x[18,14]  w_lb_18_14  -2.6697177726926005e-02
    x[18,14]  w_ub_18_14  -6.7365269461077862e-02
    x[18,14]  hard_lower  14
    x[18,14]  hard_upper  14
    x[18,15]  OBJ       -7.8058050260474722e-03
    x[18,15]  onehot_18  1
    x[18,15]  w_lb_18_15  -2.6697177726926005e-02
    x[18,15]  w_ub_18_15  -6.7365269461077862e-02
    x[18,15]  hard_lower  15
    x[18,15]  hard_upper  15
    x[18,16]  OBJ       -9.1312498495508126e-03
    x[18,16]  onehot_18  1
    x[18,16]  w_lb_18_16  -2.6697177726926005e-02
    x[18,16]  w_ub_18_16  -6.7365269461077862e-02
    x[18,16]  hard_lower  16
    x[18,16]  hard_upper  16
    x[18,17]  OBJ       -1.0456694673054146e-02
    x[18,17]  onehot_18  1
    x[18,17]  w_lb_18_17  -2.6697177726926005e-02
    x[18,17]  w_ub_18_17  -6.7365269461077862e-02
    x[18,17]  hard_lower  17
    x[18,17]  hard_upper  17
    x[19,0]   OBJ       -2.7109605152790444e-03
    x[19,0]   onehot_19  1
    x[19,0]   w_lb_19_0  -2.6697177726926005e-02
    x[19,0]   w_ub_19_0  -6.7365269461077862e-02
    x[19,1]   OBJ       3.6823210010576120e-03
    x[19,1]   onehot_19  1
    x[19,1]   w_lb_19_1  -2.6697177726926005e-02
    x[19,1]   w_ub_19_1  -6.7365269461077862e-02
    x[19,1]   hard_lower  1
    x[19,1]   hard_upper  1
    x[19,2]   OBJ       0.00964791886718437
    x[19,2]   onehot_19  1
    x[19,2]   w_lb_19_2  -2.6697177726926005e-02
    x[19,2]   w_ub_19_2  -6.7365269461077862e-02
    x[19,2]   hard_lower  2
    x[19,2]   hard_upper  2
    x[19,3]   OBJ       1.6290325653765887e-02
    x[19,3]   onehot_19  1
    x[19,3]   w_lb_19_3  -2.6697177726926005e-02
    x[19,3]   w_ub_19_3  -6.7365269461077862e-02
    x[19,3]   hard_lower  3
    x[19,3]   hard_upper  3
    x[19,4]   OBJ       1.6026057847356147e-02
    x[19,4]   onehot_19  1
    x[19,4]   w_lb_19_4  -2.6697177726926005e-02
    x[19,4]   w_ub_19_4  -6.7365269461077862e-02
    x[19,4]   hard_lower  4
    x[19,4]   hard_upper  4
    x[19,5]   OBJ       3.1707955068091967e-03
    x[19,5]   onehot_19  1
    x[19,5]   w_lb_19_5  -2.6697177726926005e-02
    x[19,5]   w_ub_19_5  -6.7365269461077862e-02
    x[19,5]   hard_lower  5
    x[19,5]   hard_upper  5
    x[19,6]   OBJ       1.3369133608264841e-02
    x[19,6]   onehot_19  1
    x[19,6]   w_lb_19_6  -2.6697177726926005e-02
    x[19,6]   w_ub_19_6  -6.7365269461077862e-02
    x[19,6]   hard_lower  6
    x[19,6]   hard_upper  6
    x[19,7]   OBJ       -1.3974331750087351e-02
    x[19,7]   onehot_19  1
    x[19,7]   w_lb_19_7  -2.6697177726926005e-02
    x[19,7]   w_ub_19_7  -6.7365269461077862e-02
    x[19,7]   hard_lower  7
    x[19,7]   hard_upper  7
    x[19,8]   OBJ       -1.6290325653765890e-02
    x[19,8]   onehot_19  1
    x[19,8]   w_lb_19_8  -2.6697177726926005e-02
    x[19,8]   w_ub_19_8  -6.7365269461077862e-02
    x[19,8]   hard_lower  8
    x[19,8]   hard_upper  8
    x[20,0]   OBJ       -6.5233284845513141e-03
    x[20,0]   onehot_20  1
    x[20,0]   w_lb_20_0  -2.6697177726926005e-02
    x[20,0]   w_ub_20_0  -6.7365269461077862e-02
    x[20,1]   OBJ       -3.5577306184245532e-03
    x[20,1]   onehot_20  1
    x[20,1]   w_lb_20_1  -2.6697177726926005e-02
    x[20,1]   w_ub_20_1  -6.7365269461077862e-02
    x[20,1]   hard_lower  1
    x[20,1]   hard_upper  1
    x[20,2]   OBJ       -5.9213275229779566e-04
    x[20,2]   onehot_20  1
    x[20,2]   w_lb_20_2  -2.6697177726926005e-02
    x[20,2]   w_ub_20_2  -6.7365269461077862e-02
    x[20,2]   hard_lower  2
    x[20,2]   hard_upper  2
    x[20,3]   OBJ       1.8812027645747458e-03
    x[20,3]   onehot_20  1
    x[20,3]   w_lb_20_3  -2.6697177726926005e-02
    x[20,3]   w_ub_20_3  -6.7365269461077862e-02
    x[20,3]   hard_lower  3
    x[20,3]   hard_upper  3
    x[20,4]   OBJ       5.3390629799557263e-03
    x[20,4]   onehot_20  1
    x[20,4]   w_lb_20_4  -2.6697177726926005e-02
    x[20,4]   w_ub_20_4  -6.7365269461077862e-02
    x[20,4]   hard_lower  4
    x[20,4]   hard_upper  4
    x[20,5]   OBJ       8.3046608460824942e-03
    x[20,5]   onehot_20  1
    x[20,5]   w_lb_20_5  -2.6697177726926005e-02
    x[20,5]   w_ub_20_5  -6.7365269461077862e-02
    x[20,5]   hard_lower  5
    x[20,5]   hard_upper  5
    x[20,6]   OBJ       7.2692703498391277e-03
    x[20,6]   onehot_20  1
    x[20,6]   w_lb_20_6  -2.6697177726926005e-02
    x[20,6]   w_ub_20_6  -6.7365269461077862e-02
    x[20,6]   hard_lower  6
    x[20,6]   hard_upper  6
    x[20,7]   OBJ       -8.0216902627550241e-03
    x[20,7]   onehot_20  1
    x[20,7]   w_lb_20_7  -2.6697177726926005e-02
    x[20,7]   w_ub_20_7  -6.7365269461077862e-02
    x[20,7]   hard_lower  7
    x[20,7]   hard_upper  7
    x[20,8]   OBJ       1.2930179563650918e-03
    x[20,8]   onehot_20  1
    x[20,8]   w_lb_20_8  -2.6697177726926005e-02
    x[20,8]   w_ub_20_8  -6.7365269461077862e-02
    x[20,8]   hard_lower  8
    x[20,8]   hard_upper  8
    x[20,9]   OBJ       -6.5233284845513141e-03
    x[20,9]   onehot_20  1
    x[20,9]   w_lb_20_9  -2.6697177726926005e-02
    x[20,9]   w_ub_20_9  -6.7365269461077862e-02
    x[20,9]   hard_lower  9
    x[20,9]   hard_upper  9
    x[20,10]  OBJ       -8.3046608460824942e-03
    x[20,10]  onehot_20  1
    x[20,10]  w_lb_20_10  -2.6697177726926005e-02
    x[20,10]  w_ub_20_10  -6.7365269461077862e-02
    x[20,10]  hard_lower  10
    x[20,10]  hard_upper  10
    x[20,11]  OBJ       -0.00830466084608248
    x[20,11]  onehot_20  1
    x[20,11]  w_lb_20_11  -2.6697177726926005e-02
    x[20,11]  w_ub_20_11  -6.7365269461077862e-02
    x[20,11]  hard_lower  11
    x[20,11]  hard_upper  11
    x[20,12]  OBJ       -8.3046608460824942e-03
    x[20,12]  onehot_20  1
    x[20,12]  w_lb_20_12  -2.6697177726926005e-02
    x[20,12]  w_ub_20_12  -6.7365269461077862e-02
    x[20,12]  hard_lower  12
    x[20,12]  hard_upper  12
    x[21,0]   OBJ       5.9391992522193418e-03
    x[21,0]   onehot_21  1
    x[21,0]   w_lb_21_0  -2.6697177726926005e-02
    x[21,0]   w_ub_21_0  -6.7365269461077862e-02
    x[21,1]   OBJ       5.3039439425590917e-05
    x[21,1]   onehot_21  1
    x[21,1]   w_lb_21_1  -2.6697177726926005e-02
    x[21,1]   w_ub_21_1  -6.7365269461077862e-02
    x[21,1]   hard_lower  1
    x[21,1]   hard_upper  1
    x[21,2]   OBJ       5.8703949844728515e-03
    x[21,2]   onehot_21  1
    x[21,2]   w_lb_21_2  -2.6697177726926005e-02
    x[21,2]   w_ub_21_2  -6.7365269461077862e-02
    x[21,2]   hard_lower  2
    x[21,2]   hard_upper  2
    x[21,3]   OBJ       5.8359928505996167e-03
    x[21,3]   onehot_21  1
    x[21,3]   w_lb_21_3  -2.6697177726926005e-02
    x[21,3]   w_ub_21_3  -6.7365269461077862e-02
    x[21,3]   hard_lower  3
    x[21,3]   hard_upper  3
    x[21,4]   OBJ       3.7397896849999772e-04
    x[21,4]   onehot_21  1
    x[21,4]   w_lb_21_4  -2.6697177726926005e-02
    x[21,4]   w_ub_21_4  -6.7365269461077862e-02
    x[21,4]   hard_lower  4
    x[21,4]   hard_upper  4
    x[21,5]   OBJ       3.4507315325983273e-03
    x[21,5]   onehot_21  1
    x[21,5]   w_lb_21_5  -2.6697177726926005e-02
    x[21,5]   w_ub_21_5  -6.7365269461077862e-02
    x[21,5]   hard_lower  5
    x[21,5]   hard_upper  5
    x[21,6]   OBJ       2.8062186440300238e-03
    x[21,6]   onehot_21  1
    x[21,6]   w_lb_21_6  -2.6697177726926005e-02
    x[21,6]   w_ub_21_6  -6.7365269461077862e-02
    x[21,6]   hard_lower  6
    x[21,6]   hard_upper  6
    x[21,7]   OBJ       5.6983843151066464e-03
    x[21,7]   onehot_21  1
    x[21,7]   w_lb_21_7  -2.6697177726926005e-02
    x[21,7]   w_ub_21_7  -6.7365269461077862e-02
    x[21,7]   hard_lower  7
    x[21,7]   hard_upper  7
    x[21,8]   OBJ       5.6639821812334038e-03
    x[21,8]   onehot_21  1
    x[21,8]   w_lb_21_8  -2.6697177726926005e-02
    x[21,8]   w_ub_21_8  -6.7365269461077862e-02
    x[21,8]   hard_lower  8
    x[21,8]   hard_upper  8
    x[21,9]   OBJ       -3.7575459231823580e-03
    x[21,9]   onehot_21  1
    x[21,9]   w_lb_21_9  -2.6697177726926005e-02
    x[21,9]   w_ub_21_9  -6.7365269461077862e-02
    x[21,9]   hard_lower  9
    x[21,9]   hard_upper  9
    x[21,10]  OBJ       -6.0805183392818769e-03
    x[21,10]  onehot_21  1
    x[21,10]  w_lb_21_10  -2.6697177726926005e-02
    x[21,10]  w_ub_21_10  -6.7365269461077862e-02
    x[21,10]  hard_lower  10
    x[21,10]  hard_upper  10
    x[21,11]  OBJ       2.3505599975026450e-03
    x[21,11]  onehot_21  1
    x[21,11]  w_lb_21_11  -2.6697177726926005e-02
    x[21,11]  w_ub_21_11  -6.7365269461077862e-02
    x[21,11]  hard_lower  11
    x[21,11]  hard_upper  11
    x[21,12]  OBJ       1.0781638334287177e-02
    x[21,12]  onehot_21  1
    x[21,12]  w_lb_21_12  -2.6697177726926005e-02
    x[21,12]  w_ub_21_12  -6.7365269461077862e-02
    x[21,12]  hard_lower  12
    x[21,12]  hard_upper  12
    x[21,13]  OBJ       -9.0143785696160522e-03
    x[21,13]  onehot_21  1
    x[21,13]  w_lb_21_13  -2.6697177726926005e-02
    x[21,13]  w_ub_21_13  -6.7365269461077862e-02
    x[21,13]  hard_lower  13
    x[21,13]  hard_upper  13
    x[21,14]  OBJ       -9.8980084519516148e-03
    x[21,14]  onehot_21  1
    x[21,14]  w_lb_21_14  -2.6697177726926005e-02
    x[21,14]  w_ub_21_14  -6.7365269461077862e-02
    x[21,14]  hard_lower  14
    x[21,14]  hard_upper  14
    x[21,15]  OBJ       -1.0781638334287177e-02
    x[21,15]  onehot_21  1
    x[21,15]  w_lb_21_15  -2.6697177726926005e-02
    x[21,15]  w_ub_21_15  -6.7365269461077862e-02
    x[21,15]  hard_lower  15
    x[21,15]  hard_upper  15
    x[22,0]   OBJ       -9.0628920132444519e-03
    x[22,0]   onehot_22  1
    x[22,0]   w_lb_22_0  -2.6697177726926005e-02
    x[22,0]   w_ub_22_0  -6.7365269461077862e-02
    x[22,1]   OBJ       -9.0628920132444519e-03
    x[22,1]   onehot_22  1
    x[22,1]   w_lb_22_1  -2.6697177726926005e-02
    x[22,1]   w_ub_22_1  -6.7365269461077862e-02
    x[22,1]   hard_lower  1
    x[22,1]   hard_upper  1
    x[22,2]   OBJ       -1.3503639194597360e-03
    x[22,2]   onehot_22  1
    x[22,2]   w_lb_22_2  -2.6697177726926005e-02
    x[22,2]   w_ub_22_2  -6.7365269461077862e-02
    x[22,2]   hard_lower  2
    x[22,2]   hard_upper  2
    x[22,3]   OBJ       -1.2199984286793628e-04
    x[22,3]   onehot_22  1
    x[22,3]   w_lb_22_3  -2.6697177726926005e-02
    x[22,3]   w_ub_22_3  -6.7365269461077862e-02
    x[22,3]   hard_lower  3
    x[22,3]   hard_upper  3
    x[22,4]   OBJ       4.5808318127937807e-03
    x[22,4]   onehot_22  1
    x[22,4]   w_lb_22_4  -2.6697177726926005e-02
    x[22,4]   w_ub_22_4  -6.7365269461077862e-02
    x[22,4]   hard_lower  4
    x[22,4]   hard_upper  4
    x[22,5]   OBJ       0.00754642967892054
    x[22,5]   onehot_22  1
    x[22,5]   w_lb_22_5  -2.6697177726926005e-02
    x[22,5]   w_ub_22_5  -6.7365269461077862e-02
    x[22,5]   hard_lower  5
    x[22,5]   hard_upper  5
    x[22,6]   OBJ       9.0628920132444519e-03
    x[22,6]   onehot_22  1
    x[22,6]   w_lb_22_6  -2.6697177726926005e-02
    x[22,6]   w_ub_22_6  -6.7365269461077862e-02
    x[22,6]   hard_lower  6
    x[22,6]   hard_upper  6
    x[22,7]   OBJ       -9.0628920132444519e-03
    x[22,7]   onehot_22  1
    x[22,7]   w_lb_22_7  -2.6697177726926005e-02
    x[22,7]   w_ub_22_7  -6.7365269461077862e-02
    x[22,7]   hard_lower  7
    x[22,7]   hard_upper  7
    x[22,8]   OBJ       -9.0628920132444519e-03
    x[22,8]   onehot_22  1
    x[22,8]   w_lb_22_8  -2.6697177726926005e-02
    x[22,8]   w_ub_22_8  -6.7365269461077862e-02
    x[22,8]   hard_lower  8
    x[22,8]   hard_upper  8
    x[22,9]   OBJ       -9.0628920132444519e-03
    x[22,9]   onehot_22  1
    x[22,9]   w_lb_22_9  -2.6697177726926005e-02
    x[22,9]   w_ub_22_9  -6.7365269461077862e-02
    x[22,9]   hard_lower  9
    x[22,9]   hard_upper  9
    x[22,10]  OBJ       -9.0628920132444519e-03
    x[22,10]  onehot_22  1
    x[22,10]  w_lb_22_10  -2.6697177726926005e-02
    x[22,10]  w_ub_22_10  -6.7365269461077862e-02
    x[22,10]  hard_lower  10
    x[22,10]  hard_upper  10
    x[22,11]  OBJ       -9.0628920132444519e-03
    x[22,11]  onehot_22  1
    x[22,11]  w_lb_22_11  -2.6697177726926005e-02
    x[22,11]  w_ub_22_11  -6.7365269461077862e-02
    x[22,11]  hard_lower  11
    x[22,11]  hard_upper  11
    x[22,12]  OBJ       -9.0628920132444519e-03
    x[22,12]  onehot_22  1
    x[22,12]  w_lb_22_12  -2.6697177726926005e-02
    x[22,12]  w_ub_22_12  -6.7365269461077862e-02
    x[22,12]  hard_lower  12
    x[22,12]  hard_upper  12
    x[23,0]   OBJ       -5.6609789540080432e-03
    x[23,0]   onehot_23  1
    x[23,0]   w_lb_23_0  -2.6697177726926005e-02
    x[23,0]   w_ub_23_0  -6.7365269461077862e-02
    x[23,1]   OBJ       -5.6609789540080432e-03
    x[23,1]   onehot_23  1
    x[23,1]   w_lb_23_1  -2.6697177726926005e-02
    x[23,1]   w_ub_23_1  -6.7365269461077862e-02
    x[23,1]   hard_lower  1
    x[23,1]   hard_upper  1
    x[23,2]   OBJ       -5.2860049997477954e-03
    x[23,2]   onehot_23  1
    x[23,2]   w_lb_23_2  -2.6697177726926005e-02
    x[23,2]   w_ub_23_2  -6.7365269461077862e-02
    x[23,2]   hard_lower  2
    x[23,2]   hard_upper  2
    x[23,3]   OBJ       7.7358146443722332e-03
    x[23,3]   onehot_23  1
    x[23,3]   w_lb_23_3  -2.6697177726926005e-02
    x[23,3]   w_ub_23_3  -6.7365269461077862e-02
    x[23,3]   hard_lower  3
    x[23,3]   hard_upper  3
    x[23,4]   OBJ       1.3213166480961273e-02
    x[23,4]   onehot_23  1
    x[23,4]   w_lb_23_4  -2.6697177726926005e-02
    x[23,4]   w_ub_23_4  -6.7365269461077862e-02
    x[23,4]   hard_lower  4
    x[23,4]   hard_upper  4
    x[23,5]   OBJ       1.1720163274741832e-02
    x[23,5]   onehot_23  1
    x[23,5]   w_lb_23_5  -2.6697177726926005e-02
    x[23,5]   w_ub_23_5  -6.7365269461077862e-02
    x[23,5]   hard_lower  5
    x[23,5]   hard_upper  5
    x[23,6]   OBJ       -5.6609789540080432e-03
    x[23,6]   onehot_23  1
    x[23,6]   w_lb_23_6  -2.6697177726926005e-02
    x[23,6]   w_ub_23_6  -6.7365269461077862e-02
    x[23,6]   hard_lower  6
    x[23,6]   hard_upper  6
    x[23,7]   OBJ       -5.6609789540080432e-03
    x[23,7]   onehot_23  1
    x[23,7]   w_lb_23_7  -2.6697177726926005e-02
    x[23,7]   w_ub_23_7  -6.7365269461077862e-02
    x[23,7]   hard_lower  7
    x[23,7]   hard_upper  7
    x[23,8]   OBJ       -5.6609789540080432e-03
    x[23,8]   onehot_23  1
    x[23,8]   w_lb_23_8  -2.6697177726926005e-02
    x[23,8]   w_ub_23_8  -6.7365269461077862e-02
    x[23,8]   hard_lower  8
    x[23,8]   hard_upper  8
    x[23,9]   OBJ       -1.0455357636114866e-02
    x[23,9]   onehot_23  1
    x[23,9]   w_lb_23_9  -2.6697177726926005e-02
    x[23,9]   w_ub_23_9  -6.7365269461077862e-02
    x[23,9]   hard_lower  9
    x[23,9]   hard_upper  9
    x[23,10]  OBJ       -1.3213166480961273e-02
    x[23,10]  onehot_23  1
    x[23,10]  w_lb_23_10  -2.6697177726926005e-02
    x[23,10]  w_ub_23_10  -6.7365269461077862e-02
    x[23,10]  hard_lower  10
    x[23,10]  hard_upper  10
    x[23,11]  OBJ       -3.4566433206728378e-03
    x[23,11]  onehot_23  1
    x[23,11]  w_lb_23_11  -2.6697177726926005e-02
    x[23,11]  w_ub_23_11  -6.7365269461077862e-02
    x[23,11]  hard_lower  11
    x[23,11]  hard_upper  11
    x[24,0]   OBJ       5.9391992522193279e-03
    x[24,0]   onehot_24  1
    x[24,0]   w_lb_24_0  -2.6697177726926005e-02
    x[24,0]   w_ub_24_0  -6.7365269461077862e-02
    x[24,1]   OBJ       5.9047971183460793e-03
    x[24,1]   onehot_24  1
    x[24,1]   w_lb_24_1  -2.6697177726926005e-02
    x[24,1]   w_ub_24_1  -6.7365269461077862e-02
    x[24,1]   hard_lower  1
    x[24,1]   hard_upper  1
    x[24,2]   OBJ       5.8703949844728376e-03
    x[24,2]   onehot_24  1
    x[24,2]   w_lb_24_2  -2.6697177726926005e-02
    x[24,2]   w_ub_24_2  -6.7365269461077862e-02
    x[24,2]   hard_lower  2
    x[24,2]   hard_upper  2
    x[24,3]   OBJ       5.8359928505996028e-03
    x[24,3]   onehot_24  1
    x[24,3]   w_lb_24_3  -2.6697177726926005e-02
    x[24,3]   w_ub_24_3  -6.7365269461077862e-02
    x[24,3]   hard_lower  3
    x[24,3]   hard_upper  3
    x[24,4]   OBJ       0.00580159071672636
    x[24,4]   onehot_24  1
    x[24,4]   w_lb_24_4  -2.6697177726926005e-02
    x[24,4]   w_ub_24_4  -6.7365269461077862e-02
    x[24,4]   hard_lower  4
    x[24,4]   hard_upper  4
    x[24,5]   OBJ       -7.1947226971697149e-04
    x[24,5]   onehot_24  1
    x[24,5]   w_lb_24_5  -2.6697177726926005e-02
    x[24,5]   w_ub_24_5  -6.7365269461077862e-02
    x[24,5]   hard_lower  5
    x[24,5]   hard_upper  5
    x[24,6]   OBJ       2.2067602043616668e-03
    x[24,6]   onehot_24  1
    x[24,6]   w_lb_24_6  -2.6697177726926005e-02
    x[24,6]   w_ub_24_6  -6.7365269461077862e-02
    x[24,6]   hard_lower  6
    x[24,6]   hard_upper  6
    x[24,7]   OBJ       5.6983843151066343e-03
    x[24,7]   onehot_24  1
    x[24,7]   w_lb_24_7  -2.6697177726926005e-02
    x[24,7]   w_ub_24_7  -6.7365269461077862e-02
    x[24,7]   hard_lower  7
    x[24,7]   hard_upper  7
    x[24,8]   OBJ       5.6639821812333926e-03
    x[24,8]   onehot_24  1
    x[24,8]   w_lb_24_8  -2.6697177726926005e-02
    x[24,8]   w_ub_24_8  -6.7365269461077862e-02
    x[24,8]   hard_lower  8
    x[24,8]   hard_upper  8
    x[24,9]   OBJ       -3.7575459231823649e-03
    x[24,9]   onehot_24  1
    x[24,9]   w_lb_24_9  -2.6697177726926005e-02
    x[24,9]   w_ub_24_9  -6.7365269461077862e-02
    x[24,9]   hard_lower  9
    x[24,9]   hard_upper  9
    x[24,10]  OBJ       -6.0805183392818839e-03
    x[24,10]  onehot_24  1
    x[24,10]  w_lb_24_10  -2.6697177726926005e-02
    x[24,10]  w_ub_24_10  -6.7365269461077862e-02
    x[24,10]  hard_lower  10
    x[24,10]  hard_upper  10
    x[24,11]  OBJ       2.3505599975026450e-03
    x[24,11]  onehot_24  1
    x[24,11]  w_lb_24_11  -2.6697177726926005e-02
    x[24,11]  w_ub_24_11  -6.7365269461077862e-02
    x[24,11]  hard_lower  11
    x[24,11]  hard_upper  11
    x[24,12]  OBJ       1.0781638334287177e-02
    x[24,12]  onehot_24  1
    x[24,12]  w_lb_24_12  -2.6697177726926005e-02
    x[24,12]  w_ub_24_12  -6.7365269461077862e-02
    x[24,12]  hard_lower  12
    x[24,12]  hard_upper  12
    x[24,13]  OBJ       -0.00901437856961606
    x[24,13]  onehot_24  1
    x[24,13]  w_lb_24_13  -2.6697177726926005e-02
    x[24,13]  w_ub_24_13  -6.7365269461077862e-02
    x[24,13]  hard_lower  13
    x[24,13]  hard_upper  13
    x[24,14]  OBJ       -9.8980084519516148e-03
    x[24,14]  onehot_24  1
    x[24,14]  w_lb_24_14  -2.6697177726926005e-02
    x[24,14]  w_ub_24_14  -6.7365269461077862e-02
    x[24,14]  hard_lower  14
    x[24,14]  hard_upper  14
    x[24,15]  OBJ       -1.0781638334287177e-02
    x[24,15]  onehot_24  1
    x[24,15]  w_lb_24_15  -2.6697177726926005e-02
    x[24,15]  w_ub_24_15  -6.7365269461077862e-02
    x[24,15]  hard_lower  15
    x[24,15]  hard_upper  15
    x[25,0]   OBJ       8.8128273905681547e-04
    x[25,0]   onehot_25  1
    x[25,0]   w_lb_25_0  -2.6697177726926005e-02
    x[25,0]   w_ub_25_0  -6.7365269461077862e-02
    x[25,1]   OBJ       -0.00719271060774515
    x[25,1]   onehot_25  1
    x[25,1]   w_lb_25_1  -2.6697177726926005e-02
    x[25,1]   w_ub_25_1  -6.7365269461077862e-02
    x[25,1]   hard_lower  1
    x[25,1]   hard_upper  1
    x[25,2]   OBJ       3.8124784713103382e-03
    x[25,2]   onehot_25  1
    x[25,2]   w_lb_25_2  -2.6697177726926005e-02
    x[25,2]   w_ub_25_2  -6.7365269461077862e-02
    x[25,2]   hard_lower  2
    x[25,2]   hard_upper  2
    x[25,3]   OBJ       5.2780763374370978e-03
    x[25,3]   onehot_25  1
    x[25,3]   w_lb_25_3  -2.6697177726926005e-02
    x[25,3]   w_ub_25_3  -6.7365269461077862e-02
    x[25,3]   hard_lower  3
    x[25,3]   hard_upper  3
    x[25,4]   OBJ       6.7436742035638627e-03
    x[25,4]   onehot_25  1
    x[25,4]   w_lb_25_4  -2.6697177726926005e-02
    x[25,4]   w_ub_25_4  -6.7365269461077862e-02
    x[25,4]   hard_lower  4
    x[25,4]   hard_upper  4
    x[25,5]   OBJ       8.2092720696906232e-03
    x[25,5]   onehot_25  1
    x[25,5]   w_lb_25_5  -2.6697177726926005e-02
    x[25,5]   w_ub_25_5  -6.7365269461077862e-02
    x[25,5]   hard_lower  5
    x[25,5]   hard_upper  5
    x[25,6]   OBJ       9.6748699358173863e-03
    x[25,6]   onehot_25  1
    x[25,6]   w_lb_25_6  -2.6697177726926005e-02
    x[25,6]   w_ub_25_6  -6.7365269461077862e-02
    x[25,6]   hard_lower  6
    x[25,6]   hard_upper  6
    x[25,7]   OBJ       1.1085341403354258e-02
    x[25,7]   onehot_25  1
    x[25,7]   w_lb_25_7  -2.6697177726926005e-02
    x[25,7]   w_ub_25_7  -6.7365269461077862e-02
    x[25,7]   hard_lower  7
    x[25,7]   hard_upper  7
    x[25,8]   OBJ       -0.00859329611418788
    x[25,8]   onehot_25  1
    x[25,8]   w_lb_25_8  -2.6697177726926005e-02
    x[25,8]   w_ub_25_8  -6.7365269461077862e-02
    x[25,8]   hard_lower  8
    x[25,8]   hard_upper  8
    x[25,9]   OBJ       2.7959716376443119e-04
    x[25,9]   onehot_25  1
    x[25,9]   w_lb_25_9  -2.6697177726926005e-02
    x[25,9]   w_ub_25_9  -6.7365269461077862e-02
    x[25,9]   hard_lower  9
    x[25,9]   hard_upper  9
    x[25,10]  OBJ       9.1524904417167440e-03
    x[25,10]  onehot_25  1
    x[25,10]  w_lb_25_10  -2.6697177726926005e-02
    x[25,10]  w_ub_25_10  -6.7365269461077862e-02
    x[25,10]  hard_lower  10
    x[25,10]  hard_upper  10
    x[25,11]  OBJ       6.5045915952993407e-03
    x[25,11]  onehot_25  1
    x[25,11]  w_lb_25_11  -2.6697177726926005e-02
    x[25,11]  w_ub_25_11  -6.7365269461077862e-02
    x[25,11]  hard_lower  11
    x[25,11]  hard_upper  11
    x[25,12]  OBJ       -1.0643526462186486e-02
    x[25,12]  onehot_25  1
    x[25,12]  w_lb_25_12  -2.6697177726926005e-02
    x[25,12]  w_ub_25_12  -6.7365269461077862e-02
    x[25,12]  hard_lower  12
    x[25,12]  hard_upper  12
    x[25,13]  OBJ       -1.1085341403354260e-02
    x[25,13]  onehot_25  1
    x[25,13]  w_lb_25_13  -2.6697177726926005e-02
    x[25,13]  w_ub_25_13  -6.7365269461077862e-02
    x[25,13]  hard_lower  13
    x[25,13]  hard_upper  13
    x[25,14]  OBJ       -2.2124481254019593e-03
    x[25,14]  onehot_25  1
    x[25,14]  w_lb_25_14  -2.6697177726926005e-02
    x[25,14]  w_ub_25_14  -6.7365269461077862e-02
    x[25,14]  hard_lower  14
    x[25,14]  hard_upper  14
    x[25,15]  OBJ       3.4608213665362668e-03
    x[25,15]  onehot_25  1
    x[25,15]  w_lb_25_15  -2.6697177726926005e-02
    x[25,15]  w_ub_25_15  -6.7365269461077862e-02
    x[25,15]  hard_lower  15
    x[25,15]  hard_upper  15
    x[26,0]   OBJ       -4.0737545516971296e-03
    x[26,0]   onehot_26  1
    x[26,0]   w_lb_26_0  -2.6697177726926005e-02
    x[26,0]   w_ub_26_0  -6.7365269461077862e-02
    x[26,1]   OBJ       3.2374594181720159e-03
    x[26,1]   onehot_26  1
    x[26,1]   w_lb_26_1  -2.6697177726926005e-02
    x[26,1]   w_ub_26_1  -6.7365269461077862e-02
    x[26,1]   hard_lower  1
    x[26,1]   hard_upper  1
    x[26,2]   OBJ       9.2030572842987744e-03
    x[26,2]   onehot_26  1
    x[26,2]   w_lb_26_2  -2.6697177726926005e-02
    x[26,2]   w_ub_26_2  -6.7365269461077862e-02
    x[26,2]   hard_lower  2
    x[26,2]   hard_upper  2
    x[26,3]   OBJ       1.5940911020602317e-02
    x[26,3]   onehot_26  1
    x[26,3]   w_lb_26_3  -2.6697177726926005e-02
    x[26,3]   w_ub_26_3  -6.7365269461077862e-02
    x[26,3]   hard_lower  3
    x[26,3]   hard_upper  3
    x[26,4]   OBJ       1.6735187236651475e-02
    x[26,4]   onehot_26  1
    x[26,4]   w_lb_26_4  -2.6697177726926005e-02
    x[26,4]   w_ub_26_4  -6.7365269461077862e-02
    x[26,4]   hard_lower  4
    x[26,4]   hard_upper  4
    x[26,5]   OBJ       2.7259339239235989e-03
    x[26,5]   onehot_26  1
    x[26,5]   w_lb_26_5  -2.6697177726926005e-02
    x[26,5]   w_ub_26_5  -6.7365269461077862e-02
    x[26,5]   hard_lower  5
    x[26,5]   hard_upper  5
    x[26,6]   OBJ       1.2924272025379246e-02
    x[26,6]   onehot_26  1
    x[26,6]   w_lb_26_6  -2.6697177726926005e-02
    x[26,6]   w_ub_26_6  -6.7365269461077862e-02
    x[26,6]   hard_lower  6
    x[26,6]   hard_upper  6
    x[26,7]   OBJ       -1.4419193332972946e-02
    x[26,7]   onehot_26  1
    x[26,7]   w_lb_26_7  -2.6697177726926005e-02
    x[26,7]   w_ub_26_7  -6.7365269461077862e-02
    x[26,7]   hard_lower  7
    x[26,7]   hard_upper  7
    x[26,8]   OBJ       -1.6735187236651478e-02
    x[26,8]   onehot_26  1
    x[26,8]   w_lb_26_8  -2.6697177726926005e-02
    x[26,8]   w_ub_26_8  -6.7365269461077862e-02
    x[26,8]   hard_lower  8
    x[26,8]   hard_upper  8
    x[27,0]   OBJ       1.5865184728252740e-03
    x[27,0]   onehot_27  1
    x[27,0]   w_lb_27_0  -2.6697177726926005e-02
    x[27,0]   w_ub_27_0  -6.7365269461077862e-02
    x[27,1]   OBJ       0.00305211633895203
    x[27,1]   onehot_27  1
    x[27,1]   w_lb_27_1  -2.6697177726926005e-02
    x[27,1]   w_ub_27_1  -6.7365269461077862e-02
    x[27,1]   hard_lower  1
    x[27,1]   hard_upper  1
    x[27,2]   OBJ       4.5177142050787933e-03
    x[27,2]   onehot_27  1
    x[27,2]   w_lb_27_2  -2.6697177726926005e-02
    x[27,2]   w_ub_27_2  -6.7365269461077862e-02
    x[27,2]   hard_lower  2
    x[27,2]   hard_upper  2
    x[27,3]   OBJ       -1.6562950095163503e-03
    x[27,3]   onehot_27  1
    x[27,3]   w_lb_27_3  -2.6697177726926005e-02
    x[27,3]   w_ub_27_3  -6.7365269461077862e-02
    x[27,3]   hard_lower  3
    x[27,3]   hard_upper  3
    x[27,4]   OBJ       7.4489099373323195e-03
    x[27,4]   onehot_27  1
    x[27,4]   w_lb_27_4  -2.6697177726926005e-02
    x[27,4]   w_ub_27_4  -6.7365269461077862e-02
    x[27,4]   hard_lower  4
    x[27,4]   hard_upper  4
    x[27,5]   OBJ       8.5524148730120528e-03
    x[27,5]   onehot_27  1
    x[27,5]   w_lb_27_5  -2.6697177726926005e-02
    x[27,5]   w_ub_27_5  -6.7365269461077862e-02
    x[27,5]   hard_lower  5
    x[27,5]   hard_upper  5
    x[27,6]   OBJ       1.0380105669585828e-02
    x[27,6]   onehot_27  1
    x[27,6]   w_lb_27_6  -2.6697177726926005e-02
    x[27,6]   w_ub_27_6  -6.7365269461077862e-02
    x[27,6]   hard_lower  6
    x[27,6]   hard_upper  6
    x[27,7]   OBJ       8.0057739412663156e-03
    x[27,7]   onehot_27  1
    x[27,7]   w_lb_27_7  -2.6697177726926005e-02
    x[27,7]   w_ub_27_7  -6.7365269461077862e-02
    x[27,7]   hard_lower  7
    x[27,7]   hard_upper  7
    x[27,8]   OBJ       -7.8880603804194344e-03
    x[27,8]   onehot_27  1
    x[27,8]   w_lb_27_8  -2.6697177726926005e-02
    x[27,8]   w_ub_27_8  -6.7365269461077862e-02
    x[27,8]   hard_lower  8
    x[27,8]   hard_upper  8
    x[27,9]   OBJ       0.000984832897532869
    x[27,9]   onehot_27  1
    x[27,9]   w_lb_27_9  -2.6697177726926005e-02
    x[27,9]   w_ub_27_9  -6.7365269461077862e-02
    x[27,9]   hard_lower  9
    x[27,9]   hard_upper  9
    x[27,10]  OBJ       9.8577261754851757e-03
    x[27,10]  onehot_27  1
    x[27,10]  w_lb_27_10  -2.6697177726926005e-02
    x[27,10]  w_ub_27_10  -6.7365269461077862e-02
    x[27,10]  hard_lower  10
    x[27,10]  hard_upper  10
    x[27,11]  OBJ       7.2098273290677854e-03
    x[27,11]  onehot_27  1
    x[27,11]  w_lb_27_11  -2.6697177726926005e-02
    x[27,11]  w_ub_27_11  -6.7365269461077862e-02
    x[27,11]  hard_lower  11
    x[27,11]  hard_upper  11
    x[27,12]  OBJ       -9.9382907284180470e-03
    x[27,12]  onehot_27  1
    x[27,12]  w_lb_27_12  -2.6697177726926005e-02
    x[27,12]  w_ub_27_12  -6.7365269461077862e-02
    x[27,12]  hard_lower  12
    x[27,12]  hard_upper  12
    x[27,13]  OBJ       -1.0380105669585828e-02
    x[27,13]  onehot_27  1
    x[27,13]  w_lb_27_13  -2.6697177726926005e-02
    x[27,13]  w_ub_27_13  -6.7365269461077862e-02
    x[27,13]  hard_lower  13
    x[27,13]  hard_upper  13
    x[27,14]  OBJ       -1.5072123916335146e-03
    x[27,14]  onehot_27  1
    x[27,14]  w_lb_27_14  -2.6697177726926005e-02
    x[27,14]  w_ub_27_14  -6.7365269461077862e-02
    x[27,14]  hard_lower  14
    x[27,14]  hard_upper  14
    x[27,15]  OBJ       4.1660571003046976e-03
    x[27,15]  onehot_27  1
    x[27,15]  w_lb_27_15  -2.6697177726926005e-02
    x[27,15]  w_ub_27_15  -6.7365269461077862e-02
    x[27,15]  hard_lower  15
    x[27,15]  hard_upper  15
    x[28,0]   OBJ       1.4584928059445173e-03
    x[28,0]   onehot_28  1
    x[28,0]   w_lb_28_0  -2.6697177726926005e-02
    x[28,0]   w_ub_28_0  -6.7365269461077862e-02
    x[28,1]   OBJ       1.4240906720712687e-03
    x[28,1]   onehot_28  1
    x[28,1]   w_lb_28_1  -2.6697177726926005e-02
    x[28,1]   w_ub_28_1  -6.7365269461077862e-02
    x[28,1]   hard_lower  1
    x[28,1]   hard_upper  1
    x[28,2]   OBJ       1.3896885381980270e-03
    x[28,2]   onehot_28  1
    x[28,2]   w_lb_28_2  -2.6697177726926005e-02
    x[28,2]   w_ub_28_2  -6.7365269461077862e-02
    x[28,2]   hard_lower  2
    x[28,2]   hard_upper  2
    x[28,3]   OBJ       1.3552864043247922e-03
    x[28,3]   onehot_28  1
    x[28,3]   w_lb_28_3  -2.6697177726926005e-02
    x[28,3]   w_ub_28_3  -6.7365269461077862e-02
    x[28,3]   hard_lower  3
    x[28,3]   hard_upper  3
    x[28,4]   OBJ       -1.0572110110662154e-03
    x[28,4]   onehot_28  1
    x[28,4]   w_lb_28_4  -2.6697177726926005e-02
    x[28,4]   w_ub_28_4  -6.7365269461077862e-02
    x[28,4]   hard_lower  4
    x[28,4]   hard_upper  4
    x[28,5]   OBJ       -5.0681994421850054e-03
    x[28,5]   onehot_28  1
    x[28,5]   w_lb_28_5  -2.6697177726926005e-02
    x[28,5]   w_ub_28_5  -6.7365269461077862e-02
    x[28,5]   hard_lower  5
    x[28,5]   hard_upper  5
    x[28,6]   OBJ       -1.0196114242220925e-03
    x[28,6]   onehot_28  1
    x[28,6]   w_lb_28_6  -2.6697177726926005e-02
    x[28,6]   w_ub_28_6  -6.7365269461077862e-02
    x[28,6]   hard_lower  6
    x[28,6]   hard_upper  6
    x[28,7]   OBJ       1.2176778688318185e-03
    x[28,7]   onehot_28  1
    x[28,7]   w_lb_28_7  -2.6697177726926005e-02
    x[28,7]   w_ub_28_7  -6.7365269461077862e-02
    x[28,7]   hard_lower  7
    x[28,7]   hard_upper  7
    x[28,8]   OBJ       1.1832757349585768e-03
    x[28,8]   onehot_28  1
    x[28,8]   w_lb_28_8  -2.6697177726926005e-02
    x[28,8]   w_ub_28_8  -6.7365269461077862e-02
    x[28,8]   hard_lower  8
    x[28,8]   hard_upper  8
    x[28,9]   OBJ       -8.2382523694571833e-03
    x[28,9]   onehot_28  1
    x[28,9]   w_lb_28_9  -2.6697177726926005e-02
    x[28,9]   w_ub_28_9  -6.7365269461077862e-02
    x[28,9]   hard_lower  9
    x[28,9]   hard_upper  9
    x[28,10]  OBJ       -1.0561224785556702e-02
    x[28,10]  onehot_28  1
    x[28,10]  w_lb_28_10  -2.6697177726926005e-02
    x[28,10]  w_ub_28_10  -6.7365269461077862e-02
    x[28,10]  hard_lower  10
    x[28,10]  hard_upper  10
    x[28,11]  OBJ       -2.1301464487721794e-03
    x[28,11]  onehot_28  1
    x[28,11]  w_lb_28_11  -2.6697177726926005e-02
    x[28,11]  w_ub_28_11  -6.7365269461077862e-02
    x[28,11]  hard_lower  11
    x[28,11]  hard_upper  11
    x[28,12]  OBJ       6.3009318880123530e-03
    x[28,12]  onehot_28  1
    x[28,12]  w_lb_28_12  -2.6697177726926005e-02
    x[28,12]  w_ub_28_12  -6.7365269461077862e-02
    x[28,12]  hard_lower  12
    x[28,12]  hard_upper  12
    x[28,13]  OBJ       -1.3495085015890874e-02
    x[28,13]  onehot_28  1
    x[28,13]  w_lb_28_13  -2.6697177726926005e-02
    x[28,13]  w_ub_28_13  -6.7365269461077862e-02
    x[28,13]  hard_lower  13
    x[28,13]  hard_upper  13
    x[28,14]  OBJ       -1.4378714898226437e-02
    x[28,14]  onehot_28  1
    x[28,14]  w_lb_28_14  -2.6697177726926005e-02
    x[28,14]  w_ub_28_14  -6.7365269461077862e-02
    x[28,14]  hard_lower  14
    x[28,14]  hard_upper  14
    x[28,15]  OBJ       -1.5262344780562006e-02
    x[28,15]  onehot_28  1
    x[28,15]  w_lb_28_15  -2.6697177726926005e-02
    x[28,15]  w_ub_28_15  -6.7365269461077862e-02
    x[28,15]  hard_lower  15
    x[28,15]  hard_upper  15
    x[28,16]  OBJ       -1.0030890229791558e-02
    x[28,16]  onehot_28  1
    x[28,16]  w_lb_28_16  -2.6697177726926005e-02
    x[28,16]  w_ub_28_16  -6.7365269461077862e-02
    x[28,16]  hard_lower  16
    x[28,16]  hard_upper  16
    x[28,17]  OBJ       -1.5998118930070316e-03
    x[28,17]  onehot_28  1
    x[28,17]  w_lb_28_17  -2.6697177726926005e-02
    x[28,17]  w_ub_28_17  -6.7365269461077862e-02
    x[28,17]  hard_lower  17
    x[28,17]  hard_upper  17
    x[28,18]  OBJ       6.8312664437775008e-03
    x[28,18]  onehot_28  1
    x[28,18]  w_lb_28_18  -2.6697177726926005e-02
    x[28,18]  w_ub_28_18  -6.7365269461077862e-02
    x[28,18]  hard_lower  18
    x[28,18]  hard_upper  18
    x[28,19]  OBJ       1.5262344780562005e-02
    x[28,19]  onehot_28  1
    x[28,19]  w_lb_28_19  -2.6697177726926005e-02
    x[28,19]  w_ub_28_19  -6.7365269461077862e-02
    x[28,19]  hard_lower  19
    x[28,19]  hard_upper  19
    x[29,0]   OBJ       5.9391992522193279e-03
    x[29,0]   onehot_29  1
    x[29,0]   w_lb_29_0  -2.6697177726926005e-02
    x[29,0]   w_ub_29_0  -6.7365269461077862e-02
    x[29,1]   OBJ       5.9047971183460793e-03
    x[29,1]   onehot_29  1
    x[29,1]   w_lb_29_1  -2.6697177726926005e-02
    x[29,1]   w_ub_29_1  -6.7365269461077862e-02
    x[29,1]   hard_lower  1
    x[29,1]   hard_upper  1
    x[29,2]   OBJ       5.8703949844728376e-03
    x[29,2]   onehot_29  1
    x[29,2]   w_lb_29_2  -2.6697177726926005e-02
    x[29,2]   w_ub_29_2  -6.7365269461077862e-02
    x[29,2]   hard_lower  2
    x[29,2]   hard_upper  2
    x[29,3]   OBJ       5.8359928505996028e-03
    x[29,3]   onehot_29  1
    x[29,3]   w_lb_29_3  -2.6697177726926005e-02
    x[29,3]   w_ub_29_3  -6.7365269461077862e-02
    x[29,3]   hard_lower  3
    x[29,3]   hard_upper  3
    x[29,4]   OBJ       5.8015907167263681e-03
    x[29,4]   onehot_29  1
    x[29,4]   w_lb_29_4  -2.6697177726926005e-02
    x[29,4]   w_ub_29_4  -6.7365269461077862e-02
    x[29,4]   hard_lower  4
    x[29,4]   hard_upper  4
    x[29,5]   OBJ       2.0280318094747151e-03
    x[29,5]   onehot_29  1
    x[29,5]   w_lb_29_5  -2.6697177726926005e-02
    x[29,5]   w_ub_29_5  -6.7365269461077862e-02
    x[29,5]   hard_lower  5
    x[29,5]   hard_upper  5
    x[29,6]   OBJ       2.8794474662311494e-03
    x[29,6]   onehot_29  1
    x[29,6]   w_lb_29_6  -2.6697177726926005e-02
    x[29,6]   w_ub_29_6  -6.7365269461077862e-02
    x[29,6]   hard_lower  6
    x[29,6]   hard_upper  6
    x[29,7]   OBJ       5.6983843151066360e-03
    x[29,7]   onehot_29  1
    x[29,7]   w_lb_29_7  -2.6697177726926005e-02
    x[29,7]   w_ub_29_7  -6.7365269461077862e-02
    x[29,7]   hard_lower  7
    x[29,7]   hard_upper  7
    x[29,8]   OBJ       1.9928281368028523e-03
    x[29,8]   onehot_29  1
    x[29,8]   w_lb_29_8  -2.6697177726926005e-02
    x[29,8]   w_ub_29_8  -6.7365269461077862e-02
    x[29,8]   hard_lower  8
    x[29,8]   hard_upper  8
    x[29,9]   OBJ       -3.7575459231823649e-03
    x[29,9]   onehot_29  1
    x[29,9]   w_lb_29_9  -2.6697177726926005e-02
    x[29,9]   w_ub_29_9  -6.7365269461077862e-02
    x[29,9]   hard_lower  9
    x[29,9]   hard_upper  9
    x[29,10]  OBJ       -6.0805183392818839e-03
    x[29,10]  onehot_29  1
    x[29,10]  w_lb_29_10  -2.6697177726926005e-02
    x[29,10]  w_ub_29_10  -6.7365269461077862e-02
    x[29,10]  hard_lower  10
    x[29,10]  hard_upper  10
    x[29,11]  OBJ       2.3505599975026450e-03
    x[29,11]  onehot_29  1
    x[29,11]  w_lb_29_11  -2.6697177726926005e-02
    x[29,11]  w_ub_29_11  -6.7365269461077862e-02
    x[29,11]  hard_lower  11
    x[29,11]  hard_upper  11
    x[29,12]  OBJ       1.0781638334287177e-02
    x[29,12]  onehot_29  1
    x[29,12]  w_lb_29_12  -2.6697177726926005e-02
    x[29,12]  w_ub_29_12  -6.7365269461077862e-02
    x[29,12]  hard_lower  12
    x[29,12]  hard_upper  12
    x[29,13]  OBJ       -0.00901437856961606
    x[29,13]  onehot_29  1
    x[29,13]  w_lb_29_13  -2.6697177726926005e-02
    x[29,13]  w_ub_29_13  -6.7365269461077862e-02
    x[29,13]  hard_lower  13
    x[29,13]  hard_upper  13
    x[29,14]  OBJ       -9.8980084519516148e-03
    x[29,14]  onehot_29  1
    x[29,14]  w_lb_29_14  -2.6697177726926005e-02
    x[29,14]  w_ub_29_14  -6.7365269461077862e-02
    x[29,14]  hard_lower  14
    x[29,14]  hard_upper  14
    x[29,15]  OBJ       -1.0781638334287177e-02
    x[29,15]  onehot_29  1
    x[29,15]  w_lb_29_15  -2.6697177726926005e-02
    x[29,15]  w_ub_29_15  -6.7365269461077862e-02
    x[29,15]  hard_lower  15
    x[29,15]  hard_upper  15
    x[30,0]   OBJ       -2.5524956404125226e-03
    x[30,0]   onehot_30  1
    x[30,0]   w_lb_30_0  -2.6697177726926005e-02
    x[30,0]   w_ub_30_0  -6.7365269461077862e-02
    x[30,1]   OBJ       -2.5524956404125226e-03
    x[30,1]   onehot_30  1
    x[30,1]   w_lb_30_1  -2.6697177726926005e-02
    x[30,1]   w_ub_30_1  -6.7365269461077862e-02
    x[30,1]   hard_lower  1
    x[30,1]   hard_upper  1
    x[30,2]   OBJ       9.3787000918409968e-03
    x[30,2]   onehot_30  1
    x[30,2]   w_lb_30_2  -2.6697177726926005e-02
    x[30,2]   w_ub_30_2  -6.7365269461077862e-02
    x[30,2]   hard_lower  2
    x[30,2]   hard_upper  2
    x[30,3]   OBJ       1.6559544429109251e-02
    x[30,3]   onehot_30  1
    x[30,3]   w_lb_30_3  -2.6697177726926005e-02
    x[30,3]   w_ub_30_3  -6.7365269461077862e-02
    x[30,3]   hard_lower  3
    x[30,3]   hard_upper  3
    x[30,4]   OBJ       1.1894306102121794e-02
    x[30,4]   onehot_30  1
    x[30,4]   w_lb_30_4  -2.6697177726926005e-02
    x[30,4]   w_ub_30_4  -6.7365269461077862e-02
    x[30,4]   hard_lower  4
    x[30,4]   hard_upper  4
    x[30,5]   OBJ       2.9015767314658309e-03
    x[30,5]   onehot_30  1
    x[30,5]   w_lb_30_5  -2.6697177726926005e-02
    x[30,5]   w_ub_30_5  -6.7365269461077862e-02
    x[30,5]   hard_lower  5
    x[30,5]   hard_upper  5
    x[30,6]   OBJ       1.3099914832921472e-02
    x[30,6]   onehot_30  1
    x[30,6]   w_lb_30_6  -2.6697177726926005e-02
    x[30,6]   w_ub_30_6  -6.7365269461077862e-02
    x[30,6]   hard_lower  6
    x[30,6]   hard_upper  6
    x[30,7]   OBJ       -1.4243550525430720e-02
    x[30,7]   onehot_30  1
    x[30,7]   w_lb_30_7  -2.6697177726926005e-02
    x[30,7]   w_ub_30_7  -6.7365269461077862e-02
    x[30,7]   hard_lower  7
    x[30,7]   hard_upper  7
    x[30,8]   OBJ       -1.6559544429109254e-02
    x[30,8]   onehot_30  1
    x[30,8]   w_lb_30_8  -2.6697177726926005e-02
    x[30,8]   w_ub_30_8  -6.7365269461077862e-02
    x[30,8]   hard_lower  8
    x[30,8]   hard_upper  8
    x[31,0]   OBJ       1.3656110022413730e-03
    x[31,0]   onehot_31  1
    x[31,0]   w_lb_31_0  -2.6697177726926005e-02
    x[31,0]   w_ub_31_0  -6.7365269461077862e-02
    x[31,1]   OBJ       2.8312088683681291e-03
    x[31,1]   onehot_31  1
    x[31,1]   w_lb_31_1  -2.6697177726926005e-02
    x[31,1]   w_ub_31_1  -6.7365269461077862e-02
    x[31,1]   hard_lower  1
    x[31,1]   hard_upper  1
    x[31,2]   OBJ       -9.5770586121556034e-03
    x[31,2]   onehot_31  1
    x[31,2]   w_lb_31_2  -2.6697177726926005e-02
    x[31,2]   w_ub_31_2  -6.7365269461077862e-02
    x[31,2]   hard_lower  2
    x[31,2]   hard_upper  2
    x[31,3]   OBJ       5.7624046006216553e-03
    x[31,3]   onehot_31  1
    x[31,3]   w_lb_31_3  -2.6697177726926005e-02
    x[31,3]   w_ub_31_3  -6.7365269461077862e-02
    x[31,3]   hard_lower  3
    x[31,3]   hard_upper  3
    x[31,4]   OBJ       7.2280024667484150e-03
    x[31,4]   onehot_31  1
    x[31,4]   w_lb_31_4  -2.6697177726926005e-02
    x[31,4]   w_ub_31_4  -6.7365269461077862e-02
    x[31,4]   hard_lower  4
    x[31,4]   hard_upper  4
    x[31,5]   OBJ       8.6936003328751746e-03
    x[31,5]   onehot_31  1
    x[31,5]   w_lb_31_5  -2.6697177726926005e-02
    x[31,5]   w_ub_31_5  -6.7365269461077862e-02
    x[31,5]   hard_lower  5
    x[31,5]   hard_upper  5
    x[31,6]   OBJ       1.0159198199001934e-02
    x[31,6]   onehot_31  1
    x[31,6]   w_lb_31_6  -2.6697177726926005e-02
    x[31,6]   w_ub_31_6  -6.7365269461077862e-02
    x[31,6]   hard_lower  6
    x[31,6]   hard_upper  6
    x[31,7]   OBJ       3.8612427520422193e-03
    x[31,7]   onehot_31  1
    x[31,7]   w_lb_31_7  -2.6697177726926005e-02
    x[31,7]   w_ub_31_7  -6.7365269461077862e-02
    x[31,7]   hard_lower  7
    x[31,7]   hard_upper  7
    x[31,8]   OBJ       -8.1089678510033285e-03
    x[31,8]   onehot_31  1
    x[31,8]   w_lb_31_8  -2.6697177726926005e-02
    x[31,8]   w_ub_31_8  -6.7365269461077862e-02
    x[31,8]   hard_lower  8
    x[31,8]   hard_upper  8
    x[31,9]   OBJ       7.6392542694898175e-04
    x[31,9]   onehot_31  1
    x[31,9]   w_lb_31_9  -2.6697177726926005e-02
    x[31,9]   w_ub_31_9  -6.7365269461077862e-02
    x[31,9]   hard_lower  9
    x[31,9]   hard_upper  9
    x[31,10]  OBJ       9.6368187049012885e-03
    x[31,10]  onehot_31  1
    x[31,10]  w_lb_31_10  -2.6697177726926005e-02
    x[31,10]  w_ub_31_10  -6.7365269461077862e-02
    x[31,10]  hard_lower  10
    x[31,10]  hard_upper  10
    x[31,11]  OBJ       6.9889198584838844e-03
    x[31,11]  onehot_31  1
    x[31,11]  w_lb_31_11  -2.6697177726926005e-02
    x[31,11]  w_ub_31_11  -6.7365269461077862e-02
    x[31,11]  hard_lower  11
    x[31,11]  hard_upper  11
    x[31,12]  OBJ       -1.0159198199001934e-02
    x[31,12]  onehot_31  1
    x[31,12]  w_lb_31_12  -2.6697177726926005e-02
    x[31,12]  w_ub_31_12  -6.7365269461077862e-02
    x[31,12]  hard_lower  12
    x[31,12]  hard_upper  12
    x[32,0]   OBJ       -1.3026293140293820e-02
    x[32,0]   onehot_32  1
    x[32,0]   w_lb_32_0  -2.6697177726926005e-02
    x[32,0]   w_ub_32_0  -6.7365269461077862e-02
    x[32,1]   OBJ       -1.3026293140293820e-02
    x[32,1]   onehot_32  1
    x[32,1]   w_lb_32_1  -2.6697177726926005e-02
    x[32,1]   w_ub_32_1  -6.7365269461077862e-02
    x[32,1]   hard_lower  1
    x[32,1]   hard_upper  1
    x[32,2]   OBJ       1.6406115207799402e-03
    x[32,2]   onehot_32  1
    x[32,2]   w_lb_32_2  -2.6697177726926005e-02
    x[32,2]   w_ub_32_2  -6.7365269461077862e-02
    x[32,2]   hard_lower  2
    x[32,2]   hard_upper  2
    x[32,3]   OBJ       8.1892485925074282e-03
    x[32,3]   onehot_32  1
    x[32,3]   w_lb_32_3  -2.6697177726926005e-02
    x[32,3]   w_ub_32_3  -6.7365269461077862e-02
    x[32,3]   hard_lower  3
    x[32,3]   hard_upper  3
    x[32,4]   OBJ       1.3026293140293820e-02
    x[32,4]   onehot_32  1
    x[32,4]   w_lb_32_4  -2.6697177726926005e-02
    x[32,4]   w_ub_32_4  -6.7365269461077862e-02
    x[32,4]   hard_lower  4
    x[32,4]   hard_upper  4
    x[32,5]   OBJ       1.2020561498335722e-02
    x[32,5]   onehot_32  1
    x[32,5]   w_lb_32_5  -2.6697177726926005e-02
    x[32,5]   w_ub_32_5  -6.7365269461077862e-02
    x[32,5]   hard_lower  5
    x[32,5]   hard_upper  5
    x[32,6]   OBJ       -1.7296897090355173e-03
    x[32,6]   onehot_32  1
    x[32,6]   w_lb_32_6  -2.6697177726926005e-02
    x[32,6]   w_ub_32_6  -6.7365269461077862e-02
    x[32,6]   hard_lower  6
    x[32,6]   hard_upper  6
    x[32,7]   OBJ       -1.3026293140293820e-02
    x[32,7]   onehot_32  1
    x[32,7]   w_lb_32_7  -2.6697177726926005e-02
    x[32,7]   w_ub_32_7  -6.7365269461077862e-02
    x[32,7]   hard_lower  7
    x[32,7]   hard_upper  7
    x[32,8]   OBJ       -5.2075450058728587e-03
    x[32,8]   onehot_32  1
    x[32,8]   w_lb_32_8  -2.6697177726926005e-02
    x[32,8]   w_ub_32_8  -6.7365269461077862e-02
    x[32,8]   hard_lower  8
    x[32,8]   hard_upper  8
    x[32,9]   OBJ       -1.0001923687979766e-02
    x[32,9]   onehot_32  1
    x[32,9]   w_lb_32_9  -2.6697177726926005e-02
    x[32,9]   w_ub_32_9  -6.7365269461077862e-02
    x[32,9]   hard_lower  9
    x[32,9]   hard_upper  9
    x[32,10]  OBJ       -1.3026293140293820e-02
    x[32,10]  onehot_32  1
    x[32,10]  w_lb_32_10  -2.6697177726926005e-02
    x[32,10]  w_ub_32_10  -6.7365269461077862e-02
    x[32,10]  hard_lower  10
    x[32,10]  hard_upper  10
    x[32,11]  OBJ       -3.0032093725382170e-03
    x[32,11]  onehot_32  1
    x[32,11]  w_lb_32_11  -2.6697177726926005e-02
    x[32,11]  w_ub_32_11  -6.7365269461077862e-02
    x[32,11]  hard_lower  11
    x[32,11]  hard_upper  11
    x[32,12]  OBJ       6.7533137877496541e-03
    x[32,12]  onehot_32  1
    x[32,12]  w_lb_32_12  -2.6697177726926005e-02
    x[32,12]  w_ub_32_12  -6.7365269461077862e-02
    x[32,12]  hard_lower  12
    x[32,12]  hard_upper  12
    x[33,0]   OBJ       2.5709611848968947e-04
    x[33,0]   onehot_33  1
    x[33,0]   w_lb_33_0  -2.6697177726926005e-02
    x[33,0]   w_ub_33_0  -6.7365269461077862e-02
    x[33,1]   OBJ       -8.2043318764754465e-03
    x[33,1]   onehot_33  1
    x[33,1]   w_lb_33_1  -2.6697177726926005e-02
    x[33,1]   w_ub_33_1  -6.7365269461077862e-02
    x[33,1]   hard_lower  1
    x[33,1]   hard_upper  1
    x[33,2]   OBJ       3.1882918507432087e-03
    x[33,2]   onehot_33  1
    x[33,2]   w_lb_33_2  -2.6697177726926005e-02
    x[33,2]   w_ub_33_2  -6.7365269461077862e-02
    x[33,2]   hard_lower  2
    x[33,2]   hard_upper  2
    x[33,3]   OBJ       4.6538897168699666e-03
    x[33,3]   onehot_33  1
    x[33,3]   w_lb_33_3  -2.6697177726926005e-02
    x[33,3]   w_ub_33_3  -6.7365269461077862e-02
    x[33,3]   hard_lower  3
    x[33,3]   hard_upper  3
    x[33,4]   OBJ       1.8183743952350168e-03
    x[33,4]   onehot_33  1
    x[33,4]   w_lb_33_4  -2.6697177726926005e-02
    x[33,4]   w_ub_33_4  -6.7365269461077862e-02
    x[33,4]   hard_lower  4
    x[33,4]   hard_upper  4
    x[33,5]   OBJ       7.5850854491234946e-03
    x[33,5]   onehot_33  1
    x[33,5]   w_lb_33_5  -2.6697177726926005e-02
    x[33,5]   w_ub_33_5  -6.7365269461077862e-02
    x[33,5]   hard_lower  5
    x[33,5]   hard_upper  5
    x[33,6]   OBJ       9.3720102088185372e-03
    x[33,6]   onehot_33  1
    x[33,6]   w_lb_33_6  -2.6697177726926005e-02
    x[33,6]   w_ub_33_6  -6.7365269461077862e-02
    x[33,6]   hard_lower  6
    x[33,6]   hard_upper  6
    x[33,7]   OBJ       5.0392810041864694e-03
    x[33,7]   onehot_33  1
    x[33,7]   w_lb_33_7  -2.6697177726926005e-02
    x[33,7]   w_ub_33_7  -6.7365269461077862e-02
    x[33,7]   hard_lower  7
    x[33,7]   hard_upper  7
    x[33,8]   OBJ       -0.00921748273475502
    x[33,8]   onehot_33  1
    x[33,8]   w_lb_33_8  -2.6697177726926005e-02
    x[33,8]   w_ub_33_8  -6.7365269461077862e-02
    x[33,8]   hard_lower  8
    x[33,8]   hard_upper  8
    x[33,9]   OBJ       -3.4458945680271563e-04
    x[33,9]   onehot_33  1
    x[33,9]   w_lb_33_9  -2.6697177726926005e-02
    x[33,9]   w_ub_33_9  -6.7365269461077862e-02
    x[33,9]   hard_lower  9
    x[33,9]   hard_upper  9
    x[33,10]  OBJ       0.00852830382114959
    x[33,10]  onehot_33  1
    x[33,10]  w_lb_33_10  -2.6697177726926005e-02
    x[33,10]  w_ub_33_10  -6.7365269461077862e-02
    x[33,10]  hard_lower  10
    x[33,10]  hard_upper  10
    x[33,11]  OBJ       5.8804049747322009e-03
    x[33,11]  onehot_33  1
    x[33,11]  w_lb_33_11  -2.6697177726926005e-02
    x[33,11]  w_ub_33_11  -6.7365269461077862e-02
    x[33,11]  hard_lower  11
    x[33,11]  hard_upper  11
    x[33,12]  OBJ       -1.1267713082753632e-02
    x[33,12]  onehot_33  1
    x[33,12]  w_lb_33_12  -2.6697177726926005e-02
    x[33,12]  w_ub_33_12  -6.7365269461077862e-02
    x[33,12]  hard_lower  12
    x[33,12]  hard_upper  12
    x[33,13]  OBJ       -1.1709528023921414e-02
    x[33,13]  onehot_33  1
    x[33,13]  w_lb_33_13  -2.6697177726926005e-02
    x[33,13]  w_ub_33_13  -6.7365269461077862e-02
    x[33,13]  hard_lower  13
    x[33,13]  hard_upper  13
    x[33,14]  OBJ       -2.8366347459690992e-03
    x[33,14]  onehot_33  1
    x[33,14]  w_lb_33_14  -2.6697177726926005e-02
    x[33,14]  w_ub_33_14  -6.7365269461077862e-02
    x[33,14]  hard_lower  14
    x[33,14]  hard_upper  14
    x[33,15]  OBJ       2.8366347459691131e-03
    x[33,15]  onehot_33  1
    x[33,15]  w_lb_33_15  -2.6697177726926005e-02
    x[33,15]  w_ub_33_15  -6.7365269461077862e-02
    x[33,15]  hard_lower  15
    x[33,15]  hard_upper  15
    x[33,16]  OBJ       1.1709528023921412e-02
    x[33,16]  onehot_33  1
    x[33,16]  w_lb_33_16  -2.6697177726926005e-02
    x[33,16]  w_ub_33_16  -6.7365269461077862e-02
    x[33,16]  hard_lower  16
    x[33,16]  hard_upper  16
    x[34,0]   OBJ       -5.1551019687769116e-03
    x[34,0]   onehot_34  1
    x[34,0]   w_lb_34_0  -2.6697177726926005e-02
    x[34,0]   w_ub_34_0  -6.7365269461077862e-02
    x[34,1]   OBJ       -1.1058949104391308e-03
    x[34,1]   onehot_34  1
    x[34,1]   w_lb_34_1  -2.6697177726926005e-02
    x[34,1]   w_ub_34_1  -6.7365269461077862e-02
    x[34,1]   hard_lower  1
    x[34,1]   hard_upper  1
    x[34,2]   OBJ       -0.00797909323972647
    x[34,2]   onehot_34  1
    x[34,2]   w_lb_34_2  -2.6697177726926005e-02
    x[34,2]   w_ub_34_2  -6.7365269461077862e-02
    x[34,2]   hard_lower  2
    x[34,2]   hard_upper  2
    x[34,3]   OBJ       7.3665139591687946e-03
    x[34,3]   onehot_34  1
    x[34,3]   w_lb_34_3  -2.6697177726926005e-02
    x[34,3]   w_ub_34_3  -6.7365269461077862e-02
    x[34,3]   hard_lower  3
    x[34,3]   hard_upper  3
    x[34,4]   OBJ       1.2707289495730127e-02
    x[34,4]   onehot_34  1
    x[34,4]   w_lb_34_4  -2.6697177726926005e-02
    x[34,4]   w_ub_34_4  -6.7365269461077862e-02
    x[34,4]   hard_lower  4
    x[34,4]   hard_upper  4
    x[34,5]   OBJ       1.1950265789306219e-02
    x[34,5]   onehot_34  1
    x[34,5]   w_lb_34_5  -2.6697177726926005e-02
    x[34,5]   w_ub_34_5  -6.7365269461077862e-02
    x[34,5]   hard_lower  5
    x[34,5]   hard_upper  5
    x[34,6]   OBJ       -1.6772466719395755e-03
    x[34,6]   onehot_34  1
    x[34,6]   w_lb_34_6  -2.6697177726926005e-02
    x[34,6]   w_ub_34_6  -6.7365269461077862e-02
    x[34,6]   hard_lower  6
    x[34,6]   hard_upper  6
    x[34,7]   OBJ       8.0792764883482870e-03
    x[34,7]   onehot_34  1
    x[34,7]   w_lb_34_7  -2.6697177726926005e-02
    x[34,7]   w_ub_34_7  -6.7365269461077862e-02
    x[34,7]   hard_lower  7
    x[34,7]   hard_upper  7
    x[34,8]   OBJ       -5.1551019687769116e-03
    x[34,8]   onehot_34  1
    x[34,8]   w_lb_34_8  -2.6697177726926005e-02
    x[34,8]   w_ub_34_8  -6.7365269461077862e-02
    x[34,8]   hard_lower  8
    x[34,8]   hard_upper  8
    x[34,9]   OBJ       -9.9494806508838227e-03
    x[34,9]   onehot_34  1
    x[34,9]   w_lb_34_9  -2.6697177726926005e-02
    x[34,9]   w_ub_34_9  -6.7365269461077862e-02
    x[34,9]   hard_lower  9
    x[34,9]   hard_upper  9
    x[34,10]  OBJ       -1.2707289495730127e-02
    x[34,10]  onehot_34  1
    x[34,10]  w_lb_34_10  -2.6697177726926005e-02
    x[34,10]  w_ub_34_10  -6.7365269461077862e-02
    x[34,10]  hard_lower  10
    x[34,10]  hard_upper  10
    x[34,11]  OBJ       -2.9507663354422717e-03
    x[34,11]  onehot_34  1
    x[34,11]  w_lb_34_11  -2.6697177726926005e-02
    x[34,11]  w_ub_34_11  -6.7365269461077862e-02
    x[34,11]  hard_lower  11
    x[34,11]  hard_upper  11
    x[35,0]   OBJ       5.9391992522193193e-03
    x[35,0]   onehot_35  1
    x[35,0]   w_lb_35_0  -2.6697177726926005e-02
    x[35,0]   w_ub_35_0  -6.7365269461077862e-02
    x[35,1]   OBJ       5.9047971183460706e-03
    x[35,1]   onehot_35  1
    x[35,1]   w_lb_35_1  -2.6697177726926005e-02
    x[35,1]   w_ub_35_1  -6.7365269461077862e-02
    x[35,1]   hard_lower  1
    x[35,1]   hard_upper  1
    x[35,2]   OBJ       5.8703949844728289e-03
    x[35,2]   onehot_35  1
    x[35,2]   w_lb_35_2  -2.6697177726926005e-02
    x[35,2]   w_ub_35_2  -6.7365269461077862e-02
    x[35,2]   hard_lower  2
    x[35,2]   hard_upper  2
    x[35,3]   OBJ       5.8359928505995941e-03
    x[35,3]   onehot_35  1
    x[35,3]   w_lb_35_3  -2.6697177726926005e-02
    x[35,3]   w_ub_35_3  -6.7365269461077862e-02
    x[35,3]   hard_lower  3
    x[35,3]   hard_upper  3
    x[35,4]   OBJ       -3.9531163882544421e-03
    x[35,4]   onehot_35  1
    x[35,4]   w_lb_35_4  -2.6697177726926005e-02
    x[35,4]   w_ub_35_4  -6.7365269461077862e-02
    x[35,4]   hard_lower  4
    x[35,4]   hard_upper  4
    x[35,5]   OBJ       -1.3977219033382508e-03
    x[35,5]   onehot_35  1
    x[35,5]   w_lb_35_5  -2.6697177726926005e-02
    x[35,5]   w_ub_35_5  -6.7365269461077862e-02
    x[35,5]   hard_lower  5
    x[35,5]   hard_upper  5
    x[35,6]   OBJ       5.2762626838704684e-03
    x[35,6]   onehot_35  1
    x[35,6]   w_lb_35_6  -2.6697177726926005e-02
    x[35,6]   w_ub_35_6  -6.7365269461077862e-02
    x[35,6]   hard_lower  6
    x[35,6]   hard_upper  6
    x[35,7]   OBJ       5.6983843151066308e-03
    x[35,7]   onehot_35  1
    x[35,7]   w_lb_35_7  -2.6697177726926005e-02
    x[35,7]   w_ub_35_7  -6.7365269461077862e-02
    x[35,7]   hard_lower  7
    x[35,7]   hard_upper  7
    x[35,8]   OBJ       5.6639821812333926e-03
    x[35,8]   onehot_35  1
    x[35,8]   w_lb_35_8  -2.6697177726926005e-02
    x[35,8]   w_ub_35_8  -6.7365269461077862e-02
    x[35,8]   hard_lower  8
    x[35,8]   hard_upper  8
    x[35,9]   OBJ       -3.7575459231823649e-03
    x[35,9]   onehot_35  1
    x[35,9]   w_lb_35_9  -2.6697177726926005e-02
    x[35,9]   w_ub_35_9  -6.7365269461077862e-02
    x[35,9]   hard_lower  9
    x[35,9]   hard_upper  9
    x[35,10]  OBJ       -6.0805183392818787e-03
    x[35,10]  onehot_35  1
    x[35,10]  w_lb_35_10  -2.6697177726926005e-02
    x[35,10]  w_ub_35_10  -6.7365269461077862e-02
    x[35,10]  hard_lower  10
    x[35,10]  hard_upper  10
    x[35,11]  OBJ       2.3505599975026433e-03
    x[35,11]  onehot_35  1
    x[35,11]  w_lb_35_11  -2.6697177726926005e-02
    x[35,11]  w_ub_35_11  -6.7365269461077862e-02
    x[35,11]  hard_lower  11
    x[35,11]  hard_upper  11
    x[35,12]  OBJ       1.0781638334287169e-02
    x[35,12]  onehot_35  1
    x[35,12]  w_lb_35_12  -2.6697177726926005e-02
    x[35,12]  w_ub_35_12  -6.7365269461077862e-02
    x[35,12]  hard_lower  12
    x[35,12]  hard_upper  12
    x[35,13]  OBJ       -0.00901437856961605
    x[35,13]  onehot_35  1
    x[35,13]  w_lb_35_13  -2.6697177726926005e-02
    x[35,13]  w_ub_35_13  -6.7365269461077862e-02
    x[35,13]  hard_lower  13
    x[35,13]  hard_upper  13
    x[35,14]  OBJ       -9.8980084519516131e-03
    x[35,14]  onehot_35  1
    x[35,14]  w_lb_35_14  -2.6697177726926005e-02
    x[35,14]  w_ub_35_14  -6.7365269461077862e-02
    x[35,14]  hard_lower  14
    x[35,14]  hard_upper  14
    x[35,15]  OBJ       -1.0781638334287169e-02
    x[35,15]  onehot_35  1
    x[35,15]  w_lb_35_15  -2.6697177726926005e-02
    x[35,15]  w_ub_35_15  -6.7365269461077862e-02
    x[35,15]  hard_lower  15
    x[35,15]  hard_upper  15
    MARKER    'MARKER'                 'INTEND'
    w[1,0]    mass_1    1
    w[1,0]    w_lb_1_0  1
    w[1,0]    w_ub_1_0  1
    w[1,1]    mass_1    1
    w[1,1]    w_lb_1_1  1
    w[1,1]    w_ub_1_1  1
    w[1,1]    normalized_inventory_1  -1
    w[1,2]    mass_1    1
    w[1,2]    w_lb_1_2  1
    w[1,2]    w_ub_1_2  1
    w[1,2]    normalized_inventory_1  -2
    w[1,3]    mass_1    1
    w[1,3]    w_lb_1_3  1
    w[1,3]    w_ub_1_3  1
    w[1,3]    normalized_inventory_1  -3
    w[1,4]    mass_1    1
    w[1,4]    w_lb_1_4  1
    w[1,4]    w_ub_1_4  1
    w[1,4]    normalized_inventory_1  -4
    w[1,5]    mass_1    1
    w[1,5]    w_lb_1_5  1
    w[1,5]    w_ub_1_5  1
    w[1,5]    normalized_inventory_1  -5
    w[1,6]    mass_1    1
    w[1,6]    w_lb_1_6  1
    w[1,6]    w_ub_1_6  1
    w[1,6]    normalized_inventory_1  -6
    w[1,7]    mass_1    1
    w[1,7]    w_lb_1_7  1
    w[1,7]    w_ub_1_7  1
    w[1,7]    normalized_inventory_1  -7
    w[1,8]    mass_1    1
    w[1,8]    w_lb_1_8  1
    w[1,8]    w_ub_1_8  1
    w[1,8]    normalized_inventory_1  -8
    w[1,9]    mass_1    1
    w[1,9]    w_lb_1_9  1
    w[1,9]    w_ub_1_9  1
    w[1,9]    normalized_inventory_1  -9
    w[1,10]   mass_1    1
    w[1,10]   w_lb_1_10  1
    w[1,10]   w_ub_1_10  1
    w[1,10]   normalized_inventory_1  -10
    w[1,11]   mass_1    1
    w[1,11]   w_lb_1_11  1
    w[1,11]   w_ub_1_11  1
    w[1,11]   normalized_inventory_1  -11
    w[1,12]   mass_1    1
    w[1,12]   w_lb_1_12  1
    w[1,12]   w_ub_1_12  1
    w[1,12]   normalized_inventory_1  -12
    w[1,13]   mass_1    1
    w[1,13]   w_lb_1_13  1
    w[1,13]   w_ub_1_13  1
    w[1,13]   normalized_inventory_1  -13
    w[1,14]   mass_1    1
    w[1,14]   w_lb_1_14  1
    w[1,14]   w_ub_1_14  1
    w[1,14]   normalized_inventory_1  -14
    w[1,15]   mass_1    1
    w[1,15]   w_lb_1_15  1
    w[1,15]   w_ub_1_15  1
    w[1,15]   normalized_inventory_1  -15
    w[1,16]   mass_1    1
    w[1,16]   w_lb_1_16  1
    w[1,16]   w_ub_1_16  1
    w[1,16]   normalized_inventory_1  -16
    w[1,17]   mass_1    1
    w[1,17]   w_lb_1_17  1
    w[1,17]   w_ub_1_17  1
    w[1,17]   normalized_inventory_1  -17
    w[1,18]   mass_1    1
    w[1,18]   w_lb_1_18  1
    w[1,18]   w_ub_1_18  1
    w[1,18]   normalized_inventory_1  -18
    w[1,19]   mass_1    1
    w[1,19]   w_lb_1_19  1
    w[1,19]   w_ub_1_19  1
    w[1,19]   normalized_inventory_1  -19
    w[2,0]    mass_2    1
    w[2,0]    w_lb_2_0  1
    w[2,0]    w_ub_2_0  1
    w[2,1]    mass_2    1
    w[2,1]    w_lb_2_1  1
    w[2,1]    w_ub_2_1  1
    w[2,1]    normalized_inventory_2  -1
    w[2,2]    mass_2    1
    w[2,2]    w_lb_2_2  1
    w[2,2]    w_ub_2_2  1
    w[2,2]    normalized_inventory_2  -2
    w[2,3]    mass_2    1
    w[2,3]    w_lb_2_3  1
    w[2,3]    w_ub_2_3  1
    w[2,3]    normalized_inventory_2  -3
    w[2,4]    mass_2    1
    w[2,4]    w_lb_2_4  1
    w[2,4]    w_ub_2_4  1
    w[2,4]    normalized_inventory_2  -4
    w[2,5]    mass_2    1
    w[2,5]    w_lb_2_5  1
    w[2,5]    w_ub_2_5  1
    w[2,5]    normalized_inventory_2  -5
    w[2,6]    mass_2    1
    w[2,6]    w_lb_2_6  1
    w[2,6]    w_ub_2_6  1
    w[2,6]    normalized_inventory_2  -6
    w[2,7]    mass_2    1
    w[2,7]    w_lb_2_7  1
    w[2,7]    w_ub_2_7  1
    w[2,7]    normalized_inventory_2  -7
    w[2,8]    mass_2    1
    w[2,8]    w_lb_2_8  1
    w[2,8]    w_ub_2_8  1
    w[2,8]    normalized_inventory_2  -8
    w[2,9]    mass_2    1
    w[2,9]    w_lb_2_9  1
    w[2,9]    w_ub_2_9  1
    w[2,9]    normalized_inventory_2  -9
    w[2,10]   mass_2    1
    w[2,10]   w_lb_2_10  1
    w[2,10]   w_ub_2_10  1
    w[2,10]   normalized_inventory_2  -10
    w[2,11]   mass_2    1
    w[2,11]   w_lb_2_11  1
    w[2,11]   w_ub_2_11  1
    w[2,11]   normalized_inventory_2  -11
    w[2,12]   mass_2    1
    w[2,12]   w_lb_2_12  1
    w[2,12]   w_ub_2_12  1
    w[2,12]   normalized_inventory_2  -12
    w[2,13]   mass_2    1
    w[2,13]   w_lb_2_13  1
    w[2,13]   w_ub_2_13  1
    w[2,13]   normalized_inventory_2  -13
    w[2,14]   mass_2    1
    w[2,14]   w_lb_2_14  1
    w[2,14]   w_ub_2_14  1
    w[2,14]   normalized_inventory_2  -14
    w[2,15]   mass_2    1
    w[2,15]   w_lb_2_15  1
    w[2,15]   w_ub_2_15  1
    w[2,15]   normalized_inventory_2  -15
    w[3,0]    mass_3    1
    w[3,0]    w_lb_3_0  1
    w[3,0]    w_ub_3_0  1
    w[3,1]    mass_3    1
    w[3,1]    w_lb_3_1  1
    w[3,1]    w_ub_3_1  1
    w[3,1]    normalized_inventory_3  -1
    w[3,2]    mass_3    1
    w[3,2]    w_lb_3_2  1
    w[3,2]    w_ub_3_2  1
    w[3,2]    normalized_inventory_3  -2
    w[3,3]    mass_3    1
    w[3,3]    w_lb_3_3  1
    w[3,3]    w_ub_3_3  1
    w[3,3]    normalized_inventory_3  -3
    w[3,4]    mass_3    1
    w[3,4]    w_lb_3_4  1
    w[3,4]    w_ub_3_4  1
    w[3,4]    normalized_inventory_3  -4
    w[3,5]    mass_3    1
    w[3,5]    w_lb_3_5  1
    w[3,5]    w_ub_3_5  1
    w[3,5]    normalized_inventory_3  -5
    w[3,6]    mass_3    1
    w[3,6]    w_lb_3_6  1
    w[3,6]    w_ub_3_6  1
    w[3,6]    normalized_inventory_3  -6
    w[3,7]    mass_3    1
    w[3,7]    w_lb_3_7  1
    w[3,7]    w_ub_3_7  1
    w[3,7]    normalized_inventory_3  -7
    w[3,8]    mass_3    1
    w[3,8]    w_lb_3_8  1
    w[3,8]    w_ub_3_8  1
    w[3,8]    normalized_inventory_3  -8
    w[3,9]    mass_3    1
    w[3,9]    w_lb_3_9  1
    w[3,9]    w_ub_3_9  1
    w[3,9]    normalized_inventory_3  -9
    w[3,10]   mass_3    1
    w[3,10]   w_lb_3_10  1
    w[3,10]   w_ub_3_10  1
    w[3,10]   normalized_inventory_3  -10
    w[3,11]   mass_3    1
    w[3,11]   w_lb_3_11  1
    w[3,11]   w_ub_3_11  1
    w[3,11]   normalized_inventory_3  -11
    w[3,12]   mass_3    1
    w[3,12]   w_lb_3_12  1
    w[3,12]   w_ub_3_12  1
    w[3,12]   normalized_inventory_3  -12
    w[3,13]   mass_3    1
    w[3,13]   w_lb_3_13  1
    w[3,13]   w_ub_3_13  1
    w[3,13]   normalized_inventory_3  -13
    w[3,14]   mass_3    1
    w[3,14]   w_lb_3_14  1
    w[3,14]   w_ub_3_14  1
    w[3,14]   normalized_inventory_3  -14
    w[3,15]   mass_3    1
    w[3,15]   w_lb_3_15  1
    w[3,15]   w_ub_3_15  1
    w[3,15]   normalized_inventory_3  -15
    w[3,16]   mass_3    1
    w[3,16]   w_lb_3_16  1
    w[3,16]   w_ub_3_16  1
    w[3,16]   normalized_inventory_3  -16
    w[3,17]   mass_3    1
    w[3,17]   w_lb_3_17  1
    w[3,17]   w_ub_3_17  1
    w[3,17]   normalized_inventory_3  -17
    w[4,0]    mass_4    1
    w[4,0]    w_lb_4_0  1
    w[4,0]    w_ub_4_0  1
    w[4,1]    mass_4    1
    w[4,1]    w_lb_4_1  1
    w[4,1]    w_ub_4_1  1
    w[4,1]    normalized_inventory_4  -1
    w[4,2]    mass_4    1
    w[4,2]    w_lb_4_2  1
    w[4,2]    w_ub_4_2  1
    w[4,2]    normalized_inventory_4  -2
    w[4,3]    mass_4    1
    w[4,3]    w_lb_4_3  1
    w[4,3]    w_ub_4_3  1
    w[4,3]    normalized_inventory_4  -3
    w[4,4]    mass_4    1
    w[4,4]    w_lb_4_4  1
    w[4,4]    w_ub_4_4  1
    w[4,4]    normalized_inventory_4  -4
    w[4,5]    mass_4    1
    w[4,5]    w_lb_4_5  1
    w[4,5]    w_ub_4_5  1
    w[4,5]    normalized_inventory_4  -5
    w[4,6]    mass_4    1
    w[4,6]    w_lb_4_6  1
    w[4,6]    w_ub_4_6  1
    w[4,6]    normalized_inventory_4  -6
    w[4,7]    mass_4    1
    w[4,7]    w_lb_4_7  1
    w[4,7]    w_ub_4_7  1
    w[4,7]    normalized_inventory_4  -7
    w[4,8]    mass_4    1
    w[4,8]    w_lb_4_8  1
    w[4,8]    w_ub_4_8  1
    w[4,8]    normalized_inventory_4  -8
    w[4,9]    mass_4    1
    w[4,9]    w_lb_4_9  1
    w[4,9]    w_ub_4_9  1
    w[4,9]    normalized_inventory_4  -9
    w[4,10]   mass_4    1
    w[4,10]   w_lb_4_10  1
    w[4,10]   w_ub_4_10  1
    w[4,10]   normalized_inventory_4  -10
    w[4,11]   mass_4    1
    w[4,11]   w_lb_4_11  1
    w[4,11]   w_ub_4_11  1
    w[4,11]   normalized_inventory_4  -11
    w[4,12]   mass_4    1
    w[4,12]   w_lb_4_12  1
    w[4,12]   w_ub_4_12  1
    w[4,12]   normalized_inventory_4  -12
    w[4,13]   mass_4    1
    w[4,13]   w_lb_4_13  1
    w[4,13]   w_ub_4_13  1
    w[4,13]   normalized_inventory_4  -13
    w[4,14]   mass_4    1
    w[4,14]   w_lb_4_14  1
    w[4,14]   w_ub_4_14  1
    w[4,14]   normalized_inventory_4  -14
    w[4,15]   mass_4    1
    w[4,15]   w_lb_4_15  1
    w[4,15]   w_ub_4_15  1
    w[4,15]   normalized_inventory_4  -15
    w[5,0]    mass_5    1
    w[5,0]    w_lb_5_0  1
    w[5,0]    w_ub_5_0  1
    w[5,1]    mass_5    1
    w[5,1]    w_lb_5_1  1
    w[5,1]    w_ub_5_1  1
    w[5,1]    normalized_inventory_5  -1
    w[5,2]    mass_5    1
    w[5,2]    w_lb_5_2  1
    w[5,2]    w_ub_5_2  1
    w[5,2]    normalized_inventory_5  -2
    w[5,3]    mass_5    1
    w[5,3]    w_lb_5_3  1
    w[5,3]    w_ub_5_3  1
    w[5,3]    normalized_inventory_5  -3
    w[5,4]    mass_5    1
    w[5,4]    w_lb_5_4  1
    w[5,4]    w_ub_5_4  1
    w[5,4]    normalized_inventory_5  -4
    w[5,5]    mass_5    1
    w[5,5]    w_lb_5_5  1
    w[5,5]    w_ub_5_5  1
    w[5,5]    normalized_inventory_5  -5
    w[5,6]    mass_5    1
    w[5,6]    w_lb_5_6  1
    w[5,6]    w_ub_5_6  1
    w[5,6]    normalized_inventory_5  -6
    w[5,7]    mass_5    1
    w[5,7]    w_lb_5_7  1
    w[5,7]    w_ub_5_7  1
    w[5,7]    normalized_inventory_5  -7
    w[5,8]    mass_5    1
    w[5,8]    w_lb_5_8  1
    w[5,8]    w_ub_5_8  1
    w[5,8]    normalized_inventory_5  -8
    w[5,9]    mass_5    1
    w[5,9]    w_lb_5_9  1
    w[5,9]    w_ub_5_9  1
    w[5,9]    normalized_inventory_5  -9
    w[5,10]   mass_5    1
    w[5,10]   w_lb_5_10  1
    w[5,10]   w_ub_5_10  1
    w[5,10]   normalized_inventory_5  -10
    w[5,11]   mass_5    1
    w[5,11]   w_lb_5_11  1
    w[5,11]   w_ub_5_11  1
    w[5,11]   normalized_inventory_5  -11
    w[5,12]   mass_5    1
    w[5,12]   w_lb_5_12  1
    w[5,12]   w_ub_5_12  1
    w[5,12]   normalized_inventory_5  -12
    w[5,13]   mass_5    1
    w[5,13]   w_lb_5_13  1
    w[5,13]   w_ub_5_13  1
    w[5,13]   normalized_inventory_5  -13
    w[5,14]   mass_5    1
    w[5,14]   w_lb_5_14  1
    w[5,14]   w_ub_5_14  1
    w[5,14]   normalized_inventory_5  -14
    w[5,15]   mass_5    1
    w[5,15]   w_lb_5_15  1
    w[5,15]   w_ub_5_15  1
    w[5,15]   normalized_inventory_5  -15
    w[5,16]   mass_5    1
    w[5,16]   w_lb_5_16  1
    w[5,16]   w_ub_5_16  1
    w[5,16]   normalized_inventory_5  -16
    w[6,0]    mass_6    1
    w[6,0]    w_lb_6_0  1
    w[6,0]    w_ub_6_0  1
    w[6,1]    mass_6    1
    w[6,1]    w_lb_6_1  1
    w[6,1]    w_ub_6_1  1
    w[6,1]    normalized_inventory_6  -1
    w[6,2]    mass_6    1
    w[6,2]    w_lb_6_2  1
    w[6,2]    w_ub_6_2  1
    w[6,2]    normalized_inventory_6  -2
    w[6,3]    mass_6    1
    w[6,3]    w_lb_6_3  1
    w[6,3]    w_ub_6_3  1
    w[6,3]    normalized_inventory_6  -3
    w[6,4]    mass_6    1
    w[6,4]    w_lb_6_4  1
    w[6,4]    w_ub_6_4  1
    w[6,4]    normalized_inventory_6  -4
    w[6,5]    mass_6    1
    w[6,5]    w_lb_6_5  1
    w[6,5]    w_ub_6_5  1
    w[6,5]    normalized_inventory_6  -5
    w[6,6]    mass_6    1
    w[6,6]    w_lb_6_6  1
    w[6,6]    w_ub_6_6  1
    w[6,6]    normalized_inventory_6  -6
    w[6,7]    mass_6    1
    w[6,7]    w_lb_6_7  1
    w[6,7]    w_ub_6_7  1
    w[6,7]    normalized_inventory_6  -7
    w[6,8]    mass_6    1
    w[6,8]    w_lb_6_8  1
    w[6,8]    w_ub_6_8  1
    w[6,8]    normalized_inventory_6  -8
    w[6,9]    mass_6    1
    w[6,9]    w_lb_6_9  1
    w[6,9]    w_ub_6_9  1
    w[6,9]    normalized_inventory_6  -9
    w[6,10]   mass_6    1
    w[6,10]   w_lb_6_10  1
    w[6,10]   w_ub_6_10  1
    w[6,10]   normalized_inventory_6  -10
    w[7,0]    mass_7    1
    w[7,0]    w_lb_7_0  1
    w[7,0]    w_ub_7_0  1
    w[7,1]    mass_7    1
    w[7,1]    w_lb_7_1  1
    w[7,1]    w_ub_7_1  1
    w[7,1]    normalized_inventory_7  -1
    w[7,2]    mass_7    1
    w[7,2]    w_lb_7_2  1
    w[7,2]    w_ub_7_2  1
    w[7,2]    normalized_inventory_7  -2
    w[7,3]    mass_7    1
    w[7,3]    w_lb_7_3  1
    w[7,3]    w_ub_7_3  1
    w[7,3]    normalized_inventory_7  -3
    w[7,4]    mass_7    1
    w[7,4]    w_lb_7_4  1
    w[7,4]    w_ub_7_4  1
    w[7,4]    normalized_inventory_7  -4
    w[7,5]    mass_7    1
    w[7,5]    w_lb_7_5  1
    w[7,5]    w_ub_7_5  1
    w[7,5]    normalized_inventory_7  -5
    w[7,6]    mass_7    1
    w[7,6]    w_lb_7_6  1
    w[7,6]    w_ub_7_6  1
    w[7,6]    normalized_inventory_7  -6
    w[7,7]    mass_7    1
    w[7,7]    w_lb_7_7  1
    w[7,7]    w_ub_7_7  1
    w[7,7]    normalized_inventory_7  -7
    w[7,8]    mass_7    1
    w[7,8]    w_lb_7_8  1
    w[7,8]    w_ub_7_8  1
    w[7,8]    normalized_inventory_7  -8
    w[7,9]    mass_7    1
    w[7,9]    w_lb_7_9  1
    w[7,9]    w_ub_7_9  1
    w[7,9]    normalized_inventory_7  -9
    w[7,10]   mass_7    1
    w[7,10]   w_lb_7_10  1
    w[7,10]   w_ub_7_10  1
    w[7,10]   normalized_inventory_7  -10
    w[7,11]   mass_7    1
    w[7,11]   w_lb_7_11  1
    w[7,11]   w_ub_7_11  1
    w[7,11]   normalized_inventory_7  -11
    w[7,12]   mass_7    1
    w[7,12]   w_lb_7_12  1
    w[7,12]   w_ub_7_12  1
    w[7,12]   normalized_inventory_7  -12
    w[7,13]   mass_7    1
    w[7,13]   w_lb_7_13  1
    w[7,13]   w_ub_7_13  1
    w[7,13]   normalized_inventory_7  -13
    w[7,14]   mass_7    1
    w[7,14]   w_lb_7_14  1
    w[7,14]   w_ub_7_14  1
    w[7,14]   normalized_inventory_7  -14
    w[7,15]   mass_7    1
    w[7,15]   w_lb_7_15  1
    w[7,15]   w_ub_7_15  1
    w[7,15]   normalized_inventory_7  -15
    w[7,16]   mass_7    1
    w[7,16]   w_lb_7_16  1
    w[7,16]   w_ub_7_16  1
    w[7,16]   normalized_inventory_7  -16
    w[7,17]   mass_7    1
    w[7,17]   w_lb_7_17  1
    w[7,17]   w_ub_7_17  1
    w[7,17]   normalized_inventory_7  -17
    w[8,0]    mass_8    1
    w[8,0]    w_lb_8_0  1
    w[8,0]    w_ub_8_0  1
    w[8,1]    mass_8    1
    w[8,1]    w_lb_8_1  1
    w[8,1]    w_ub_8_1  1
    w[8,1]    normalized_inventory_8  -1
    w[8,2]    mass_8    1
    w[8,2]    w_lb_8_2  1
    w[8,2]    w_ub_8_2  1
    w[8,2]    normalized_inventory_8  -2
    w[8,3]    mass_8    1
    w[8,3]    w_lb_8_3  1
    w[8,3]    w_ub_8_3  1
    w[8,3]    normalized_inventory_8  -3
    w[8,4]    mass_8    1
    w[8,4]    w_lb_8_4  1
    w[8,4]    w_ub_8_4  1
    w[8,4]    normalized_inventory_8  -4
    w[8,5]    mass_8    1
    w[8,5]    w_lb_8_5  1
    w[8,5]    w_ub_8_5  1
    w[8,5]    normalized_inventory_8  -5
    w[8,6]    mass_8    1
    w[8,6]    w_lb_8_6  1
    w[8,6]    w_ub_8_6  1
    w[8,6]    normalized_inventory_8  -6
    w[8,7]    mass_8    1
    w[8,7]    w_lb_8_7  1
    w[8,7]    w_ub_8_7  1
    w[8,7]    normalized_inventory_8  -7
    w[8,8]    mass_8    1
    w[8,8]    w_lb_8_8  1
    w[8,8]    w_ub_8_8  1
    w[8,8]    normalized_inventory_8  -8
    w[8,9]    mass_8    1
    w[8,9]    w_lb_8_9  1
    w[8,9]    w_ub_8_9  1
    w[8,9]    normalized_inventory_8  -9
    w[8,10]   mass_8    1
    w[8,10]   w_lb_8_10  1
    w[8,10]   w_ub_8_10  1
    w[8,10]   normalized_inventory_8  -10
    w[8,11]   mass_8    1
    w[8,11]   w_lb_8_11  1
    w[8,11]   w_ub_8_11  1
    w[8,11]   normalized_inventory_8  -11
    w[8,12]   mass_8    1
    w[8,12]   w_lb_8_12  1
    w[8,12]   w_ub_8_12  1
    w[8,12]   normalized_inventory_8  -12
    w[8,13]   mass_8    1
    w[8,13]   w_lb_8_13  1
    w[8,13]   w_ub_8_13  1
    w[8,13]   normalized_inventory_8  -13
    w[8,14]   mass_8    1
    w[8,14]   w_lb_8_14  1
    w[8,14]   w_ub_8_14  1
    w[8,14]   normalized_inventory_8  -14
    w[8,15]   mass_8    1
    w[8,15]   w_lb_8_15  1
    w[8,15]   w_ub_8_15  1
    w[8,15]   normalized_inventory_8  -15
    w[8,16]   mass_8    1
    w[8,16]   w_lb_8_16  1
    w[8,16]   w_ub_8_16  1
    w[8,16]   normalized_inventory_8  -16
    w[8,17]   mass_8    1
    w[8,17]   w_lb_8_17  1
    w[8,17]   w_ub_8_17  1
    w[8,17]   normalized_inventory_8  -17
    w[8,18]   mass_8    1
    w[8,18]   w_lb_8_18  1
    w[8,18]   w_ub_8_18  1
    w[8,18]   normalized_inventory_8  -18
    w[8,19]   mass_8    1
    w[8,19]   w_lb_8_19  1
    w[8,19]   w_ub_8_19  1
    w[8,19]   normalized_inventory_8  -19
    w[8,20]   mass_8    1
    w[8,20]   w_lb_8_20  1
    w[8,20]   w_ub_8_20  1
    w[8,20]   normalized_inventory_8  -20
    w[8,21]   mass_8    1
    w[8,21]   w_lb_8_21  1
    w[8,21]   w_ub_8_21  1
    w[8,21]   normalized_inventory_8  -21
    w[9,0]    mass_9    1
    w[9,0]    w_lb_9_0  1
    w[9,0]    w_ub_9_0  1
    w[9,1]    mass_9    1
    w[9,1]    w_lb_9_1  1
    w[9,1]    w_ub_9_1  1
    w[9,1]    normalized_inventory_9  -1
    w[9,2]    mass_9    1
    w[9,2]    w_lb_9_2  1
    w[9,2]    w_ub_9_2  1
    w[9,2]    normalized_inventory_9  -2
    w[9,3]    mass_9    1
    w[9,3]    w_lb_9_3  1
    w[9,3]    w_ub_9_3  1
    w[9,3]    normalized_inventory_9  -3
    w[9,4]    mass_9    1
    w[9,4]    w_lb_9_4  1
    w[9,4]    w_ub_9_4  1
    w[9,4]    normalized_inventory_9  -4
    w[9,5]    mass_9    1
    w[9,5]    w_lb_9_5  1
    w[9,5]    w_ub_9_5  1
    w[9,5]    normalized_inventory_9  -5
    w[9,6]    mass_9    1
    w[9,6]    w_lb_9_6  1
    w[9,6]    w_ub_9_6  1
    w[9,6]    normalized_inventory_9  -6
    w[9,7]    mass_9    1
    w[9,7]    w_lb_9_7  1
    w[9,7]    w_ub_9_7  1
    w[9,7]    normalized_inventory_9  -7
    w[9,8]    mass_9    1
    w[9,8]    w_lb_9_8  1
    w[9,8]    w_ub_9_8  1
    w[9,8]    normalized_inventory_9  -8
    w[9,9]    mass_9    1
    w[9,9]    w_lb_9_9  1
    w[9,9]    w_ub_9_9  1
    w[9,9]    normalized_inventory_9  -9
    w[9,10]   mass_9    1
    w[9,10]   w_lb_9_10  1
    w[9,10]   w_ub_9_10  1
    w[9,10]   normalized_inventory_9  -10
    w[9,11]   mass_9    1
    w[9,11]   w_lb_9_11  1
    w[9,11]   w_ub_9_11  1
    w[9,11]   normalized_inventory_9  -11
    w[9,12]   mass_9    1
    w[9,12]   w_lb_9_12  1
    w[9,12]   w_ub_9_12  1
    w[9,12]   normalized_inventory_9  -12
    w[10,0]   mass_10   1
    w[10,0]   w_lb_10_0  1
    w[10,0]   w_ub_10_0  1
    w[10,1]   mass_10   1
    w[10,1]   w_lb_10_1  1
    w[10,1]   w_ub_10_1  1
    w[10,1]   normalized_inventory_10  -1
    w[10,2]   mass_10   1
    w[10,2]   w_lb_10_2  1
    w[10,2]   w_ub_10_2  1
    w[10,2]   normalized_inventory_10  -2
    w[10,3]   mass_10   1
    w[10,3]   w_lb_10_3  1
    w[10,3]   w_ub_10_3  1
    w[10,3]   normalized_inventory_10  -3
    w[10,4]   mass_10   1
    w[10,4]   w_lb_10_4  1
    w[10,4]   w_ub_10_4  1
    w[10,4]   normalized_inventory_10  -4
    w[10,5]   mass_10   1
    w[10,5]   w_lb_10_5  1
    w[10,5]   w_ub_10_5  1
    w[10,5]   normalized_inventory_10  -5
    w[10,6]   mass_10   1
    w[10,6]   w_lb_10_6  1
    w[10,6]   w_ub_10_6  1
    w[10,6]   normalized_inventory_10  -6
    w[10,7]   mass_10   1
    w[10,7]   w_lb_10_7  1
    w[10,7]   w_ub_10_7  1
    w[10,7]   normalized_inventory_10  -7
    w[10,8]   mass_10   1
    w[10,8]   w_lb_10_8  1
    w[10,8]   w_ub_10_8  1
    w[10,8]   normalized_inventory_10  -8
    w[10,9]   mass_10   1
    w[10,9]   w_lb_10_9  1
    w[10,9]   w_ub_10_9  1
    w[10,9]   normalized_inventory_10  -9
    w[10,10]  mass_10   1
    w[10,10]  w_lb_10_10  1
    w[10,10]  w_ub_10_10  1
    w[10,10]  normalized_inventory_10  -10
    w[10,11]  mass_10   1
    w[10,11]  w_lb_10_11  1
    w[10,11]  w_ub_10_11  1
    w[10,11]  normalized_inventory_10  -11
    w[10,12]  mass_10   1
    w[10,12]  w_lb_10_12  1
    w[10,12]  w_ub_10_12  1
    w[10,12]  normalized_inventory_10  -12
    w[10,13]  mass_10   1
    w[10,13]  w_lb_10_13  1
    w[10,13]  w_ub_10_13  1
    w[10,13]  normalized_inventory_10  -13
    w[10,14]  mass_10   1
    w[10,14]  w_lb_10_14  1
    w[10,14]  w_ub_10_14  1
    w[10,14]  normalized_inventory_10  -14
    w[10,15]  mass_10   1
    w[10,15]  w_lb_10_15  1
    w[10,15]  w_ub_10_15  1
    w[10,15]  normalized_inventory_10  -15
    w[10,16]  mass_10   1
    w[10,16]  w_lb_10_16  1
    w[10,16]  w_ub_10_16  1
    w[10,16]  normalized_inventory_10  -16
    w[10,17]  mass_10   1
    w[10,17]  w_lb_10_17  1
    w[10,17]  w_ub_10_17  1
    w[10,17]  normalized_inventory_10  -17
    w[10,18]  mass_10   1
    w[10,18]  w_lb_10_18  1
    w[10,18]  w_ub_10_18  1
    w[10,18]  normalized_inventory_10  -18
    w[10,19]  mass_10   1
    w[10,19]  w_lb_10_19  1
    w[10,19]  w_ub_10_19  1
    w[10,19]  normalized_inventory_10  -19
    w[11,0]   mass_11   1
    w[11,0]   w_lb_11_0  1
    w[11,0]   w_ub_11_0  1
    w[11,1]   mass_11   1
    w[11,1]   w_lb_11_1  1
    w[11,1]   w_ub_11_1  1
    w[11,1]   normalized_inventory_11  -1
    w[11,2]   mass_11   1
    w[11,2]   w_lb_11_2  1
    w[11,2]   w_ub_11_2  1
    w[11,2]   normalized_inventory_11  -2
    w[11,3]   mass_11   1
    w[11,3]   w_lb_11_3  1
    w[11,3]   w_ub_11_3  1
    w[11,3]   normalized_inventory_11  -3
    w[11,4]   mass_11   1
    w[11,4]   w_lb_11_4  1
    w[11,4]   w_ub_11_4  1
    w[11,4]   normalized_inventory_11  -4
    w[11,5]   mass_11   1
    w[11,5]   w_lb_11_5  1
    w[11,5]   w_ub_11_5  1
    w[11,5]   normalized_inventory_11  -5
    w[11,6]   mass_11   1
    w[11,6]   w_lb_11_6  1
    w[11,6]   w_ub_11_6  1
    w[11,6]   normalized_inventory_11  -6
    w[11,7]   mass_11   1
    w[11,7]   w_lb_11_7  1
    w[11,7]   w_ub_11_7  1
    w[11,7]   normalized_inventory_11  -7
    w[11,8]   mass_11   1
    w[11,8]   w_lb_11_8  1
    w[11,8]   w_ub_11_8  1
    w[11,8]   normalized_inventory_11  -8
    w[11,9]   mass_11   1
    w[11,9]   w_lb_11_9  1
    w[11,9]   w_ub_11_9  1
    w[11,9]   normalized_inventory_11  -9
    w[11,10]  mass_11   1
    w[11,10]  w_lb_11_10  1
    w[11,10]  w_ub_11_10  1
    w[11,10]  normalized_inventory_11  -10
    w[11,11]  mass_11   1
    w[11,11]  w_lb_11_11  1
    w[11,11]  w_ub_11_11  1
    w[11,11]  normalized_inventory_11  -11
    w[11,12]  mass_11   1
    w[11,12]  w_lb_11_12  1
    w[11,12]  w_ub_11_12  1
    w[11,12]  normalized_inventory_11  -12
    w[12,0]   mass_12   1
    w[12,0]   w_lb_12_0  1
    w[12,0]   w_ub_12_0  1
    w[12,1]   mass_12   1
    w[12,1]   w_lb_12_1  1
    w[12,1]   w_ub_12_1  1
    w[12,1]   normalized_inventory_12  -1
    w[12,2]   mass_12   1
    w[12,2]   w_lb_12_2  1
    w[12,2]   w_ub_12_2  1
    w[12,2]   normalized_inventory_12  -2
    w[12,3]   mass_12   1
    w[12,3]   w_lb_12_3  1
    w[12,3]   w_ub_12_3  1
    w[12,3]   normalized_inventory_12  -3
    w[12,4]   mass_12   1
    w[12,4]   w_lb_12_4  1
    w[12,4]   w_ub_12_4  1
    w[12,4]   normalized_inventory_12  -4
    w[12,5]   mass_12   1
    w[12,5]   w_lb_12_5  1
    w[12,5]   w_ub_12_5  1
    w[12,5]   normalized_inventory_12  -5
    w[12,6]   mass_12   1
    w[12,6]   w_lb_12_6  1
    w[12,6]   w_ub_12_6  1
    w[12,6]   normalized_inventory_12  -6
    w[12,7]   mass_12   1
    w[12,7]   w_lb_12_7  1
    w[12,7]   w_ub_12_7  1
    w[12,7]   normalized_inventory_12  -7
    w[12,8]   mass_12   1
    w[12,8]   w_lb_12_8  1
    w[12,8]   w_ub_12_8  1
    w[12,8]   normalized_inventory_12  -8
    w[12,9]   mass_12   1
    w[12,9]   w_lb_12_9  1
    w[12,9]   w_ub_12_9  1
    w[12,9]   normalized_inventory_12  -9
    w[12,10]  mass_12   1
    w[12,10]  w_lb_12_10  1
    w[12,10]  w_ub_12_10  1
    w[12,10]  normalized_inventory_12  -10
    w[12,11]  mass_12   1
    w[12,11]  w_lb_12_11  1
    w[12,11]  w_ub_12_11  1
    w[12,11]  normalized_inventory_12  -11
    w[12,12]  mass_12   1
    w[12,12]  w_lb_12_12  1
    w[12,12]  w_ub_12_12  1
    w[12,12]  normalized_inventory_12  -12
    w[12,13]  mass_12   1
    w[12,13]  w_lb_12_13  1
    w[12,13]  w_ub_12_13  1
    w[12,13]  normalized_inventory_12  -13
    w[12,14]  mass_12   1
    w[12,14]  w_lb_12_14  1
    w[12,14]  w_ub_12_14  1
    w[12,14]  normalized_inventory_12  -14
    w[12,15]  mass_12   1
    w[12,15]  w_lb_12_15  1
    w[12,15]  w_ub_12_15  1
    w[12,15]  normalized_inventory_12  -15
    w[13,0]   mass_13   1
    w[13,0]   w_lb_13_0  1
    w[13,0]   w_ub_13_0  1
    w[13,1]   mass_13   1
    w[13,1]   w_lb_13_1  1
    w[13,1]   w_ub_13_1  1
    w[13,1]   normalized_inventory_13  -1
    w[13,2]   mass_13   1
    w[13,2]   w_lb_13_2  1
    w[13,2]   w_ub_13_2  1
    w[13,2]   normalized_inventory_13  -2
    w[13,3]   mass_13   1
    w[13,3]   w_lb_13_3  1
    w[13,3]   w_ub_13_3  1
    w[13,3]   normalized_inventory_13  -3
    w[13,4]   mass_13   1
    w[13,4]   w_lb_13_4  1
    w[13,4]   w_ub_13_4  1
    w[13,4]   normalized_inventory_13  -4
    w[13,5]   mass_13   1
    w[13,5]   w_lb_13_5  1
    w[13,5]   w_ub_13_5  1
    w[13,5]   normalized_inventory_13  -5
    w[13,6]   mass_13   1
    w[13,6]   w_lb_13_6  1
    w[13,6]   w_ub_13_6  1
    w[13,6]   normalized_inventory_13  -6
    w[13,7]   mass_13   1
    w[13,7]   w_lb_13_7  1
    w[13,7]   w_ub_13_7  1
    w[13,7]   normalized_inventory_13  -7
    w[13,8]   mass_13   1
    w[13,8]   w_lb_13_8  1
    w[13,8]   w_ub_13_8  1
    w[13,8]   normalized_inventory_13  -8
    w[13,9]   mass_13   1
    w[13,9]   w_lb_13_9  1
    w[13,9]   w_ub_13_9  1
    w[13,9]   normalized_inventory_13  -9
    w[13,10]  mass_13   1
    w[13,10]  w_lb_13_10  1
    w[13,10]  w_ub_13_10  1
    w[13,10]  normalized_inventory_13  -10
    w[13,11]  mass_13   1
    w[13,11]  w_lb_13_11  1
    w[13,11]  w_ub_13_11  1
    w[13,11]  normalized_inventory_13  -11
    w[13,12]  mass_13   1
    w[13,12]  w_lb_13_12  1
    w[13,12]  w_ub_13_12  1
    w[13,12]  normalized_inventory_13  -12
    w[13,13]  mass_13   1
    w[13,13]  w_lb_13_13  1
    w[13,13]  w_ub_13_13  1
    w[13,13]  normalized_inventory_13  -13
    w[13,14]  mass_13   1
    w[13,14]  w_lb_13_14  1
    w[13,14]  w_ub_13_14  1
    w[13,14]  normalized_inventory_13  -14
    w[13,15]  mass_13   1
    w[13,15]  w_lb_13_15  1
    w[13,15]  w_ub_13_15  1
    w[13,15]  normalized_inventory_13  -15
    w[13,16]  mass_13   1
    w[13,16]  w_lb_13_16  1
    w[13,16]  w_ub_13_16  1
    w[13,16]  normalized_inventory_13  -16
    w[13,17]  mass_13   1
    w[13,17]  w_lb_13_17  1
    w[13,17]  w_ub_13_17  1
    w[13,17]  normalized_inventory_13  -17
    w[13,18]  mass_13   1
    w[13,18]  w_lb_13_18  1
    w[13,18]  w_ub_13_18  1
    w[13,18]  normalized_inventory_13  -18
    w[13,19]  mass_13   1
    w[13,19]  w_lb_13_19  1
    w[13,19]  w_ub_13_19  1
    w[13,19]  normalized_inventory_13  -19
    w[14,0]   mass_14   1
    w[14,0]   w_lb_14_0  1
    w[14,0]   w_ub_14_0  1
    w[14,1]   mass_14   1
    w[14,1]   w_lb_14_1  1
    w[14,1]   w_ub_14_1  1
    w[14,1]   normalized_inventory_14  -1
    w[14,2]   mass_14   1
    w[14,2]   w_lb_14_2  1
    w[14,2]   w_ub_14_2  1
    w[14,2]   normalized_inventory_14  -2
    w[14,3]   mass_14   1
    w[14,3]   w_lb_14_3  1
    w[14,3]   w_ub_14_3  1
    w[14,3]   normalized_inventory_14  -3
    w[14,4]   mass_14   1
    w[14,4]   w_lb_14_4  1
    w[14,4]   w_ub_14_4  1
    w[14,4]   normalized_inventory_14  -4
    w[14,5]   mass_14   1
    w[14,5]   w_lb_14_5  1
    w[14,5]   w_ub_14_5  1
    w[14,5]   normalized_inventory_14  -5
    w[14,6]   mass_14   1
    w[14,6]   w_lb_14_6  1
    w[14,6]   w_ub_14_6  1
    w[14,6]   normalized_inventory_14  -6
    w[14,7]   mass_14   1
    w[14,7]   w_lb_14_7  1
    w[14,7]   w_ub_14_7  1
    w[14,7]   normalized_inventory_14  -7
    w[14,8]   mass_14   1
    w[14,8]   w_lb_14_8  1
    w[14,8]   w_ub_14_8  1
    w[14,8]   normalized_inventory_14  -8
    w[14,9]   mass_14   1
    w[14,9]   w_lb_14_9  1
    w[14,9]   w_ub_14_9  1
    w[14,9]   normalized_inventory_14  -9
    w[14,10]  mass_14   1
    w[14,10]  w_lb_14_10  1
    w[14,10]  w_ub_14_10  1
    w[14,10]  normalized_inventory_14  -10
    w[14,11]  mass_14   1
    w[14,11]  w_lb_14_11  1
    w[14,11]  w_ub_14_11  1
    w[14,11]  normalized_inventory_14  -11
    w[14,12]  mass_14   1
    w[14,12]  w_lb_14_12  1
    w[14,12]  w_ub_14_12  1
    w[14,12]  normalized_inventory_14  -12
    w[14,13]  mass_14   1
    w[14,13]  w_lb_14_13  1
    w[14,13]  w_ub_14_13  1
    w[14,13]  normalized_inventory_14  -13
    w[14,14]  mass_14   1
    w[14,14]  w_lb_14_14  1
    w[14,14]  w_ub_14_14  1
    w[14,14]  normalized_inventory_14  -14
    w[14,15]  mass_14   1
    w[14,15]  w_lb_14_15  1
    w[14,15]  w_ub_14_15  1
    w[14,15]  normalized_inventory_14  -15
    w[15,0]   mass_15   1
    w[15,0]   w_lb_15_0  1
    w[15,0]   w_ub_15_0  1
    w[15,1]   mass_15   1
    w[15,1]   w_lb_15_1  1
    w[15,1]   w_ub_15_1  1
    w[15,1]   normalized_inventory_15  -1
    w[15,2]   mass_15   1
    w[15,2]   w_lb_15_2  1
    w[15,2]   w_ub_15_2  1
    w[15,2]   normalized_inventory_15  -2
    w[15,3]   mass_15   1
    w[15,3]   w_lb_15_3  1
    w[15,3]   w_ub_15_3  1
    w[15,3]   normalized_inventory_15  -3
    w[15,4]   mass_15   1
    w[15,4]   w_lb_15_4  1
    w[15,4]   w_ub_15_4  1
    w[15,4]   normalized_inventory_15  -4
    w[15,5]   mass_15   1
    w[15,5]   w_lb_15_5  1
    w[15,5]   w_ub_15_5  1
    w[15,5]   normalized_inventory_15  -5
    w[15,6]   mass_15   1
    w[15,6]   w_lb_15_6  1
    w[15,6]   w_ub_15_6  1
    w[15,6]   normalized_inventory_15  -6
    w[15,7]   mass_15   1
    w[15,7]   w_lb_15_7  1
    w[15,7]   w_ub_15_7  1
    w[15,7]   normalized_inventory_15  -7
    w[15,8]   mass_15   1
    w[15,8]   w_lb_15_8  1
    w[15,8]   w_ub_15_8  1
    w[15,8]   normalized_inventory_15  -8
    w[15,9]   mass_15   1
    w[15,9]   w_lb_15_9  1
    w[15,9]   w_ub_15_9  1
    w[15,9]   normalized_inventory_15  -9
    w[15,10]  mass_15   1
    w[15,10]  w_lb_15_10  1
    w[15,10]  w_ub_15_10  1
    w[15,10]  normalized_inventory_15  -10
    w[15,11]  mass_15   1
    w[15,11]  w_lb_15_11  1
    w[15,11]  w_ub_15_11  1
    w[15,11]  normalized_inventory_15  -11
    w[15,12]  mass_15   1
    w[15,12]  w_lb_15_12  1
    w[15,12]  w_ub_15_12  1
    w[15,12]  normalized_inventory_15  -12
    w[15,13]  mass_15   1
    w[15,13]  w_lb_15_13  1
    w[15,13]  w_ub_15_13  1
    w[15,13]  normalized_inventory_15  -13
    w[15,14]  mass_15   1
    w[15,14]  w_lb_15_14  1
    w[15,14]  w_ub_15_14  1
    w[15,14]  normalized_inventory_15  -14
    w[15,15]  mass_15   1
    w[15,15]  w_lb_15_15  1
    w[15,15]  w_ub_15_15  1
    w[15,15]  normalized_inventory_15  -15
    w[15,16]  mass_15   1
    w[15,16]  w_lb_15_16  1
    w[15,16]  w_ub_15_16  1
    w[15,16]  normalized_inventory_15  -16
    w[16,0]   mass_16   1
    w[16,0]   w_lb_16_0  1
    w[16,0]   w_ub_16_0  1
    w[16,1]   mass_16   1
    w[16,1]   w_lb_16_1  1
    w[16,1]   w_ub_16_1  1
    w[16,1]   normalized_inventory_16  -1
    w[16,2]   mass_16   1
    w[16,2]   w_lb_16_2  1
    w[16,2]   w_ub_16_2  1
    w[16,2]   normalized_inventory_16  -2
    w[16,3]   mass_16   1
    w[16,3]   w_lb_16_3  1
    w[16,3]   w_ub_16_3  1
    w[16,3]   normalized_inventory_16  -3
    w[16,4]   mass_16   1
    w[16,4]   w_lb_16_4  1
    w[16,4]   w_ub_16_4  1
    w[16,4]   normalized_inventory_16  -4
    w[16,5]   mass_16   1
    w[16,5]   w_lb_16_5  1
    w[16,5]   w_ub_16_5  1
    w[16,5]   normalized_inventory_16  -5
    w[16,6]   mass_16   1
    w[16,6]   w_lb_16_6  1
    w[16,6]   w_ub_16_6  1
    w[16,6]   normalized_inventory_16  -6
    w[16,7]   mass_16   1
    w[16,7]   w_lb_16_7  1
    w[16,7]   w_ub_16_7  1
    w[16,7]   normalized_inventory_16  -7
    w[16,8]   mass_16   1
    w[16,8]   w_lb_16_8  1
    w[16,8]   w_ub_16_8  1
    w[16,8]   normalized_inventory_16  -8
    w[16,9]   mass_16   1
    w[16,9]   w_lb_16_9  1
    w[16,9]   w_ub_16_9  1
    w[16,9]   normalized_inventory_16  -9
    w[16,10]  mass_16   1
    w[16,10]  w_lb_16_10  1
    w[16,10]  w_ub_16_10  1
    w[16,10]  normalized_inventory_16  -10
    w[16,11]  mass_16   1
    w[16,11]  w_lb_16_11  1
    w[16,11]  w_ub_16_11  1
    w[16,11]  normalized_inventory_16  -11
    w[16,12]  mass_16   1
    w[16,12]  w_lb_16_12  1
    w[16,12]  w_ub_16_12  1
    w[16,12]  normalized_inventory_16  -12
    w[17,0]   mass_17   1
    w[17,0]   w_lb_17_0  1
    w[17,0]   w_ub_17_0  1
    w[17,1]   mass_17   1
    w[17,1]   w_lb_17_1  1
    w[17,1]   w_ub_17_1  1
    w[17,1]   normalized_inventory_17  -1
    w[17,2]   mass_17   1
    w[17,2]   w_lb_17_2  1
    w[17,2]   w_ub_17_2  1
    w[17,2]   normalized_inventory_17  -2
    w[17,3]   mass_17   1
    w[17,3]   w_lb_17_3  1
    w[17,3]   w_ub_17_3  1
    w[17,3]   normalized_inventory_17  -3
    w[17,4]   mass_17   1
    w[17,4]   w_lb_17_4  1
    w[17,4]   w_ub_17_4  1
    w[17,4]   normalized_inventory_17  -4
    w[17,5]   mass_17   1
    w[17,5]   w_lb_17_5  1
    w[17,5]   w_ub_17_5  1
    w[17,5]   normalized_inventory_17  -5
    w[17,6]   mass_17   1
    w[17,6]   w_lb_17_6  1
    w[17,6]   w_ub_17_6  1
    w[17,6]   normalized_inventory_17  -6
    w[17,7]   mass_17   1
    w[17,7]   w_lb_17_7  1
    w[17,7]   w_ub_17_7  1
    w[17,7]   normalized_inventory_17  -7
    w[17,8]   mass_17   1
    w[17,8]   w_lb_17_8  1
    w[17,8]   w_ub_17_8  1
    w[17,8]   normalized_inventory_17  -8
    w[17,9]   mass_17   1
    w[17,9]   w_lb_17_9  1
    w[17,9]   w_ub_17_9  1
    w[17,9]   normalized_inventory_17  -9
    w[17,10]  mass_17   1
    w[17,10]  w_lb_17_10  1
    w[17,10]  w_ub_17_10  1
    w[17,10]  normalized_inventory_17  -10
    w[17,11]  mass_17   1
    w[17,11]  w_lb_17_11  1
    w[17,11]  w_ub_17_11  1
    w[17,11]  normalized_inventory_17  -11
    w[17,12]  mass_17   1
    w[17,12]  w_lb_17_12  1
    w[17,12]  w_ub_17_12  1
    w[17,12]  normalized_inventory_17  -12
    w[17,13]  mass_17   1
    w[17,13]  w_lb_17_13  1
    w[17,13]  w_ub_17_13  1
    w[17,13]  normalized_inventory_17  -13
    w[17,14]  mass_17   1
    w[17,14]  w_lb_17_14  1
    w[17,14]  w_ub_17_14  1
    w[17,14]  normalized_inventory_17  -14
    w[17,15]  mass_17   1
    w[17,15]  w_lb_17_15  1
    w[17,15]  w_ub_17_15  1
    w[17,15]  normalized_inventory_17  -15
    w[17,16]  mass_17   1
    w[17,16]  w_lb_17_16  1
    w[17,16]  w_ub_17_16  1
    w[17,16]  normalized_inventory_17  -16
    w[18,0]   mass_18   1
    w[18,0]   w_lb_18_0  1
    w[18,0]   w_ub_18_0  1
    w[18,1]   mass_18   1
    w[18,1]   w_lb_18_1  1
    w[18,1]   w_ub_18_1  1
    w[18,1]   normalized_inventory_18  -1
    w[18,2]   mass_18   1
    w[18,2]   w_lb_18_2  1
    w[18,2]   w_ub_18_2  1
    w[18,2]   normalized_inventory_18  -2
    w[18,3]   mass_18   1
    w[18,3]   w_lb_18_3  1
    w[18,3]   w_ub_18_3  1
    w[18,3]   normalized_inventory_18  -3
    w[18,4]   mass_18   1
    w[18,4]   w_lb_18_4  1
    w[18,4]   w_ub_18_4  1
    w[18,4]   normalized_inventory_18  -4
    w[18,5]   mass_18   1
    w[18,5]   w_lb_18_5  1
    w[18,5]   w_ub_18_5  1
    w[18,5]   normalized_inventory_18  -5
    w[18,6]   mass_18   1
    w[18,6]   w_lb_18_6  1
    w[18,6]   w_ub_18_6  1
    w[18,6]   normalized_inventory_18  -6
    w[18,7]   mass_18   1
    w[18,7]   w_lb_18_7  1
    w[18,7]   w_ub_18_7  1
    w[18,7]   normalized_inventory_18  -7
    w[18,8]   mass_18   1
    w[18,8]   w_lb_18_8  1
    w[18,8]   w_ub_18_8  1
    w[18,8]   normalized_inventory_18  -8
    w[18,9]   mass_18   1
    w[18,9]   w_lb_18_9  1
    w[18,9]   w_ub_18_9  1
    w[18,9]   normalized_inventory_18  -9
    w[18,10]  mass_18   1
    w[18,10]  w_lb_18_10  1
    w[18,10]  w_ub_18_10  1
    w[18,10]  normalized_inventory_18  -10
    w[18,11]  mass_18   1
    w[18,11]  w_lb_18_11  1
    w[18,11]  w_ub_18_11  1
    w[18,11]  normalized_inventory_18  -11
    w[18,12]  mass_18   1
    w[18,12]  w_lb_18_12  1
    w[18,12]  w_ub_18_12  1
    w[18,12]  normalized_inventory_18  -12
    w[18,13]  mass_18   1
    w[18,13]  w_lb_18_13  1
    w[18,13]  w_ub_18_13  1
    w[18,13]  normalized_inventory_18  -13
    w[18,14]  mass_18   1
    w[18,14]  w_lb_18_14  1
    w[18,14]  w_ub_18_14  1
    w[18,14]  normalized_inventory_18  -14
    w[18,15]  mass_18   1
    w[18,15]  w_lb_18_15  1
    w[18,15]  w_ub_18_15  1
    w[18,15]  normalized_inventory_18  -15
    w[18,16]  mass_18   1
    w[18,16]  w_lb_18_16  1
    w[18,16]  w_ub_18_16  1
    w[18,16]  normalized_inventory_18  -16
    w[18,17]  mass_18   1
    w[18,17]  w_lb_18_17  1
    w[18,17]  w_ub_18_17  1
    w[18,17]  normalized_inventory_18  -17
    w[19,0]   mass_19   1
    w[19,0]   w_lb_19_0  1
    w[19,0]   w_ub_19_0  1
    w[19,1]   mass_19   1
    w[19,1]   w_lb_19_1  1
    w[19,1]   w_ub_19_1  1
    w[19,1]   normalized_inventory_19  -1
    w[19,2]   mass_19   1
    w[19,2]   w_lb_19_2  1
    w[19,2]   w_ub_19_2  1
    w[19,2]   normalized_inventory_19  -2
    w[19,3]   mass_19   1
    w[19,3]   w_lb_19_3  1
    w[19,3]   w_ub_19_3  1
    w[19,3]   normalized_inventory_19  -3
    w[19,4]   mass_19   1
    w[19,4]   w_lb_19_4  1
    w[19,4]   w_ub_19_4  1
    w[19,4]   normalized_inventory_19  -4
    w[19,5]   mass_19   1
    w[19,5]   w_lb_19_5  1
    w[19,5]   w_ub_19_5  1
    w[19,5]   normalized_inventory_19  -5
    w[19,6]   mass_19   1
    w[19,6]   w_lb_19_6  1
    w[19,6]   w_ub_19_6  1
    w[19,6]   normalized_inventory_19  -6
    w[19,7]   mass_19   1
    w[19,7]   w_lb_19_7  1
    w[19,7]   w_ub_19_7  1
    w[19,7]   normalized_inventory_19  -7
    w[19,8]   mass_19   1
    w[19,8]   w_lb_19_8  1
    w[19,8]   w_ub_19_8  1
    w[19,8]   normalized_inventory_19  -8
    w[20,0]   mass_20   1
    w[20,0]   w_lb_20_0  1
    w[20,0]   w_ub_20_0  1
    w[20,1]   mass_20   1
    w[20,1]   w_lb_20_1  1
    w[20,1]   w_ub_20_1  1
    w[20,1]   normalized_inventory_20  -1
    w[20,2]   mass_20   1
    w[20,2]   w_lb_20_2  1
    w[20,2]   w_ub_20_2  1
    w[20,2]   normalized_inventory_20  -2
    w[20,3]   mass_20   1
    w[20,3]   w_lb_20_3  1
    w[20,3]   w_ub_20_3  1
    w[20,3]   normalized_inventory_20  -3
    w[20,4]   mass_20   1
    w[20,4]   w_lb_20_4  1
    w[20,4]   w_ub_20_4  1
    w[20,4]   normalized_inventory_20  -4
    w[20,5]   mass_20   1
    w[20,5]   w_lb_20_5  1
    w[20,5]   w_ub_20_5  1
    w[20,5]   normalized_inventory_20  -5
    w[20,6]   mass_20   1
    w[20,6]   w_lb_20_6  1
    w[20,6]   w_ub_20_6  1
    w[20,6]   normalized_inventory_20  -6
    w[20,7]   mass_20   1
    w[20,7]   w_lb_20_7  1
    w[20,7]   w_ub_20_7  1
    w[20,7]   normalized_inventory_20  -7
    w[20,8]   mass_20   1
    w[20,8]   w_lb_20_8  1
    w[20,8]   w_ub_20_8  1
    w[20,8]   normalized_inventory_20  -8
    w[20,9]   mass_20   1
    w[20,9]   w_lb_20_9  1
    w[20,9]   w_ub_20_9  1
    w[20,9]   normalized_inventory_20  -9
    w[20,10]  mass_20   1
    w[20,10]  w_lb_20_10  1
    w[20,10]  w_ub_20_10  1
    w[20,10]  normalized_inventory_20  -10
    w[20,11]  mass_20   1
    w[20,11]  w_lb_20_11  1
    w[20,11]  w_ub_20_11  1
    w[20,11]  normalized_inventory_20  -11
    w[20,12]  mass_20   1
    w[20,12]  w_lb_20_12  1
    w[20,12]  w_ub_20_12  1
    w[20,12]  normalized_inventory_20  -12
    w[21,0]   mass_21   1
    w[21,0]   w_lb_21_0  1
    w[21,0]   w_ub_21_0  1
    w[21,1]   mass_21   1
    w[21,1]   w_lb_21_1  1
    w[21,1]   w_ub_21_1  1
    w[21,1]   normalized_inventory_21  -1
    w[21,2]   mass_21   1
    w[21,2]   w_lb_21_2  1
    w[21,2]   w_ub_21_2  1
    w[21,2]   normalized_inventory_21  -2
    w[21,3]   mass_21   1
    w[21,3]   w_lb_21_3  1
    w[21,3]   w_ub_21_3  1
    w[21,3]   normalized_inventory_21  -3
    w[21,4]   mass_21   1
    w[21,4]   w_lb_21_4  1
    w[21,4]   w_ub_21_4  1
    w[21,4]   normalized_inventory_21  -4
    w[21,5]   mass_21   1
    w[21,5]   w_lb_21_5  1
    w[21,5]   w_ub_21_5  1
    w[21,5]   normalized_inventory_21  -5
    w[21,6]   mass_21   1
    w[21,6]   w_lb_21_6  1
    w[21,6]   w_ub_21_6  1
    w[21,6]   normalized_inventory_21  -6
    w[21,7]   mass_21   1
    w[21,7]   w_lb_21_7  1
    w[21,7]   w_ub_21_7  1
    w[21,7]   normalized_inventory_21  -7
    w[21,8]   mass_21   1
    w[21,8]   w_lb_21_8  1
    w[21,8]   w_ub_21_8  1
    w[21,8]   normalized_inventory_21  -8
    w[21,9]   mass_21   1
    w[21,9]   w_lb_21_9  1
    w[21,9]   w_ub_21_9  1
    w[21,9]   normalized_inventory_21  -9
    w[21,10]  mass_21   1
    w[21,10]  w_lb_21_10  1
    w[21,10]  w_ub_21_10  1
    w[21,10]  normalized_inventory_21  -10
    w[21,11]  mass_21   1
    w[21,11]  w_lb_21_11  1
    w[21,11]  w_ub_21_11  1
    w[21,11]  normalized_inventory_21  -11
    w[21,12]  mass_21   1
    w[21,12]  w_lb_21_12  1
    w[21,12]  w_ub_21_12  1
    w[21,12]  normalized_inventory_21  -12
    w[21,13]  mass_21   1
    w[21,13]  w_lb_21_13  1
    w[21,13]  w_ub_21_13  1
    w[21,13]  normalized_inventory_21  -13
    w[21,14]  mass_21   1
    w[21,14]  w_lb_21_14  1
    w[21,14]  w_ub_21_14  1
    w[21,14]  normalized_inventory_21  -14
    w[21,15]  mass_21   1
    w[21,15]  w_lb_21_15  1
    w[21,15]  w_ub_21_15  1
    w[21,15]  normalized_inventory_21  -15
    w[22,0]   mass_22   1
    w[22,0]   w_lb_22_0  1
    w[22,0]   w_ub_22_0  1
    w[22,1]   mass_22   1
    w[22,1]   w_lb_22_1  1
    w[22,1]   w_ub_22_1  1
    w[22,1]   normalized_inventory_22  -1
    w[22,2]   mass_22   1
    w[22,2]   w_lb_22_2  1
    w[22,2]   w_ub_22_2  1
    w[22,2]   normalized_inventory_22  -2
    w[22,3]   mass_22   1
    w[22,3]   w_lb_22_3  1
    w[22,3]   w_ub_22_3  1
    w[22,3]   normalized_inventory_22  -3
    w[22,4]   mass_22   1
    w[22,4]   w_lb_22_4  1
    w[22,4]   w_ub_22_4  1
    w[22,4]   normalized_inventory_22  -4
    w[22,5]   mass_22   1
    w[22,5]   w_lb_22_5  1
    w[22,5]   w_ub_22_5  1
    w[22,5]   normalized_inventory_22  -5
    w[22,6]   mass_22   1
    w[22,6]   w_lb_22_6  1
    w[22,6]   w_ub_22_6  1
    w[22,6]   normalized_inventory_22  -6
    w[22,7]   mass_22   1
    w[22,7]   w_lb_22_7  1
    w[22,7]   w_ub_22_7  1
    w[22,7]   normalized_inventory_22  -7
    w[22,8]   mass_22   1
    w[22,8]   w_lb_22_8  1
    w[22,8]   w_ub_22_8  1
    w[22,8]   normalized_inventory_22  -8
    w[22,9]   mass_22   1
    w[22,9]   w_lb_22_9  1
    w[22,9]   w_ub_22_9  1
    w[22,9]   normalized_inventory_22  -9
    w[22,10]  mass_22   1
    w[22,10]  w_lb_22_10  1
    w[22,10]  w_ub_22_10  1
    w[22,10]  normalized_inventory_22  -10
    w[22,11]  mass_22   1
    w[22,11]  w_lb_22_11  1
    w[22,11]  w_ub_22_11  1
    w[22,11]  normalized_inventory_22  -11
    w[22,12]  mass_22   1
    w[22,12]  w_lb_22_12  1
    w[22,12]  w_ub_22_12  1
    w[22,12]  normalized_inventory_22  -12
    w[23,0]   mass_23   1
    w[23,0]   w_lb_23_0  1
    w[23,0]   w_ub_23_0  1
    w[23,1]   mass_23   1
    w[23,1]   w_lb_23_1  1
    w[23,1]   w_ub_23_1  1
    w[23,1]   normalized_inventory_23  -1
    w[23,2]   mass_23   1
    w[23,2]   w_lb_23_2  1
    w[23,2]   w_ub_23_2  1
    w[23,2]   normalized_inventory_23  -2
    w[23,3]   mass_23   1
    w[23,3]   w_lb_23_3  1
    w[23,3]   w_ub_23_3  1
    w[23,3]   normalized_inventory_23  -3
    w[23,4]   mass_23   1
    w[23,4]   w_lb_23_4  1
    w[23,4]   w_ub_23_4  1
    w[23,4]   normalized_inventory_23  -4
    w[23,5]   mass_23   1
    w[23,5]   w_lb_23_5  1
    w[23,5]   w_ub_23_5  1
    w[23,5]   normalized_inventory_23  -5
    w[23,6]   mass_23   1
    w[23,6]   w_lb_23_6  1
    w[23,6]   w_ub_23_6  1
    w[23,6]   normalized_inventory_23  -6
    w[23,7]   mass_23   1
    w[23,7]   w_lb_23_7  1
    w[23,7]   w_ub_23_7  1
    w[23,7]   normalized_inventory_23  -7
    w[23,8]   mass_23   1
    w[23,8]   w_lb_23_8  1
    w[23,8]   w_ub_23_8  1
    w[23,8]   normalized_inventory_23  -8
    w[23,9]   mass_23   1
    w[23,9]   w_lb_23_9  1
    w[23,9]   w_ub_23_9  1
    w[23,9]   normalized_inventory_23  -9
    w[23,10]  mass_23   1
    w[23,10]  w_lb_23_10  1
    w[23,10]  w_ub_23_10  1
    w[23,10]  normalized_inventory_23  -10
    w[23,11]  mass_23   1
    w[23,11]  w_lb_23_11  1
    w[23,11]  w_ub_23_11  1
    w[23,11]  normalized_inventory_23  -11
    w[24,0]   mass_24   1
    w[24,0]   w_lb_24_0  1
    w[24,0]   w_ub_24_0  1
    w[24,1]   mass_24   1
    w[24,1]   w_lb_24_1  1
    w[24,1]   w_ub_24_1  1
    w[24,1]   normalized_inventory_24  -1
    w[24,2]   mass_24   1
    w[24,2]   w_lb_24_2  1
    w[24,2]   w_ub_24_2  1
    w[24,2]   normalized_inventory_24  -2
    w[24,3]   mass_24   1
    w[24,3]   w_lb_24_3  1
    w[24,3]   w_ub_24_3  1
    w[24,3]   normalized_inventory_24  -3
    w[24,4]   mass_24   1
    w[24,4]   w_lb_24_4  1
    w[24,4]   w_ub_24_4  1
    w[24,4]   normalized_inventory_24  -4
    w[24,5]   mass_24   1
    w[24,5]   w_lb_24_5  1
    w[24,5]   w_ub_24_5  1
    w[24,5]   normalized_inventory_24  -5
    w[24,6]   mass_24   1
    w[24,6]   w_lb_24_6  1
    w[24,6]   w_ub_24_6  1
    w[24,6]   normalized_inventory_24  -6
    w[24,7]   mass_24   1
    w[24,7]   w_lb_24_7  1
    w[24,7]   w_ub_24_7  1
    w[24,7]   normalized_inventory_24  -7
    w[24,8]   mass_24   1
    w[24,8]   w_lb_24_8  1
    w[24,8]   w_ub_24_8  1
    w[24,8]   normalized_inventory_24  -8
    w[24,9]   mass_24   1
    w[24,9]   w_lb_24_9  1
    w[24,9]   w_ub_24_9  1
    w[24,9]   normalized_inventory_24  -9
    w[24,10]  mass_24   1
    w[24,10]  w_lb_24_10  1
    w[24,10]  w_ub_24_10  1
    w[24,10]  normalized_inventory_24  -10
    w[24,11]  mass_24   1
    w[24,11]  w_lb_24_11  1
    w[24,11]  w_ub_24_11  1
    w[24,11]  normalized_inventory_24  -11
    w[24,12]  mass_24   1
    w[24,12]  w_lb_24_12  1
    w[24,12]  w_ub_24_12  1
    w[24,12]  normalized_inventory_24  -12
    w[24,13]  mass_24   1
    w[24,13]  w_lb_24_13  1
    w[24,13]  w_ub_24_13  1
    w[24,13]  normalized_inventory_24  -13
    w[24,14]  mass_24   1
    w[24,14]  w_lb_24_14  1
    w[24,14]  w_ub_24_14  1
    w[24,14]  normalized_inventory_24  -14
    w[24,15]  mass_24   1
    w[24,15]  w_lb_24_15  1
    w[24,15]  w_ub_24_15  1
    w[24,15]  normalized_inventory_24  -15
    w[25,0]   mass_25   1
    w[25,0]   w_lb_25_0  1
    w[25,0]   w_ub_25_0  1
    w[25,1]   mass_25   1
    w[25,1]   w_lb_25_1  1
    w[25,1]   w_ub_25_1  1
    w[25,1]   normalized_inventory_25  -1
    w[25,2]   mass_25   1
    w[25,2]   w_lb_25_2  1
    w[25,2]   w_ub_25_2  1
    w[25,2]   normalized_inventory_25  -2
    w[25,3]   mass_25   1
    w[25,3]   w_lb_25_3  1
    w[25,3]   w_ub_25_3  1
    w[25,3]   normalized_inventory_25  -3
    w[25,4]   mass_25   1
    w[25,4]   w_lb_25_4  1
    w[25,4]   w_ub_25_4  1
    w[25,4]   normalized_inventory_25  -4
    w[25,5]   mass_25   1
    w[25,5]   w_lb_25_5  1
    w[25,5]   w_ub_25_5  1
    w[25,5]   normalized_inventory_25  -5
    w[25,6]   mass_25   1
    w[25,6]   w_lb_25_6  1
    w[25,6]   w_ub_25_6  1
    w[25,6]   normalized_inventory_25  -6
    w[25,7]   mass_25   1
    w[25,7]   w_lb_25_7  1
    w[25,7]   w_ub_25_7  1
    w[25,7]   normalized_inventory_25  -7
    w[25,8]   mass_25   1
    w[25,8]   w_lb_25_8  1
    w[25,8]   w_ub_25_8  1
    w[25,8]   normalized_inventory_25  -8
    w[25,9]   mass_25   1
    w[25,9]   w_lb_25_9  1
    w[25,9]   w_ub_25_9  1
    w[25,9]   normalized_inventory_25  -9
    w[25,10]  mass_25   1
    w[25,10]  w_lb_25_10  1
    w[25,10]  w_ub_25_10  1
    w[25,10]  normalized_inventory_25  -10
    w[25,11]  mass_25   1
    w[25,11]  w_lb_25_11  1
    w[25,11]  w_ub_25_11  1
    w[25,11]  normalized_inventory_25  -11
    w[25,12]  mass_25   1
    w[25,12]  w_lb_25_12  1
    w[25,12]  w_ub_25_12  1
    w[25,12]  normalized_inventory_25  -12
    w[25,13]  mass_25   1
    w[25,13]  w_lb_25_13  1
    w[25,13]  w_ub_25_13  1
    w[25,13]  normalized_inventory_25  -13
    w[25,14]  mass_25   1
    w[25,14]  w_lb_25_14  1
    w[25,14]  w_ub_25_14  1
    w[25,14]  normalized_inventory_25  -14
    w[25,15]  mass_25   1
    w[25,15]  w_lb_25_15  1
    w[25,15]  w_ub_25_15  1
    w[25,15]  normalized_inventory_25  -15
    w[26,0]   mass_26   1
    w[26,0]   w_lb_26_0  1
    w[26,0]   w_ub_26_0  1
    w[26,1]   mass_26   1
    w[26,1]   w_lb_26_1  1
    w[26,1]   w_ub_26_1  1
    w[26,1]   normalized_inventory_26  -1
    w[26,2]   mass_26   1
    w[26,2]   w_lb_26_2  1
    w[26,2]   w_ub_26_2  1
    w[26,2]   normalized_inventory_26  -2
    w[26,3]   mass_26   1
    w[26,3]   w_lb_26_3  1
    w[26,3]   w_ub_26_3  1
    w[26,3]   normalized_inventory_26  -3
    w[26,4]   mass_26   1
    w[26,4]   w_lb_26_4  1
    w[26,4]   w_ub_26_4  1
    w[26,4]   normalized_inventory_26  -4
    w[26,5]   mass_26   1
    w[26,5]   w_lb_26_5  1
    w[26,5]   w_ub_26_5  1
    w[26,5]   normalized_inventory_26  -5
    w[26,6]   mass_26   1
    w[26,6]   w_lb_26_6  1
    w[26,6]   w_ub_26_6  1
    w[26,6]   normalized_inventory_26  -6
    w[26,7]   mass_26   1
    w[26,7]   w_lb_26_7  1
    w[26,7]   w_ub_26_7  1
    w[26,7]   normalized_inventory_26  -7
    w[26,8]   mass_26   1
    w[26,8]   w_lb_26_8  1
    w[26,8]   w_ub_26_8  1
    w[26,8]   normalized_inventory_26  -8
    w[27,0]   mass_27   1
    w[27,0]   w_lb_27_0  1
    w[27,0]   w_ub_27_0  1
    w[27,1]   mass_27   1
    w[27,1]   w_lb_27_1  1
    w[27,1]   w_ub_27_1  1
    w[27,1]   normalized_inventory_27  -1
    w[27,2]   mass_27   1
    w[27,2]   w_lb_27_2  1
    w[27,2]   w_ub_27_2  1
    w[27,2]   normalized_inventory_27  -2
    w[27,3]   mass_27   1
    w[27,3]   w_lb_27_3  1
    w[27,3]   w_ub_27_3  1
    w[27,3]   normalized_inventory_27  -3
    w[27,4]   mass_27   1
    w[27,4]   w_lb_27_4  1
    w[27,4]   w_ub_27_4  1
    w[27,4]   normalized_inventory_27  -4
    w[27,5]   mass_27   1
    w[27,5]   w_lb_27_5  1
    w[27,5]   w_ub_27_5  1
    w[27,5]   normalized_inventory_27  -5
    w[27,6]   mass_27   1
    w[27,6]   w_lb_27_6  1
    w[27,6]   w_ub_27_6  1
    w[27,6]   normalized_inventory_27  -6
    w[27,7]   mass_27   1
    w[27,7]   w_lb_27_7  1
    w[27,7]   w_ub_27_7  1
    w[27,7]   normalized_inventory_27  -7
    w[27,8]   mass_27   1
    w[27,8]   w_lb_27_8  1
    w[27,8]   w_ub_27_8  1
    w[27,8]   normalized_inventory_27  -8
    w[27,9]   mass_27   1
    w[27,9]   w_lb_27_9  1
    w[27,9]   w_ub_27_9  1
    w[27,9]   normalized_inventory_27  -9
    w[27,10]  mass_27   1
    w[27,10]  w_lb_27_10  1
    w[27,10]  w_ub_27_10  1
    w[27,10]  normalized_inventory_27  -10
    w[27,11]  mass_27   1
    w[27,11]  w_lb_27_11  1
    w[27,11]  w_ub_27_11  1
    w[27,11]  normalized_inventory_27  -11
    w[27,12]  mass_27   1
    w[27,12]  w_lb_27_12  1
    w[27,12]  w_ub_27_12  1
    w[27,12]  normalized_inventory_27  -12
    w[27,13]  mass_27   1
    w[27,13]  w_lb_27_13  1
    w[27,13]  w_ub_27_13  1
    w[27,13]  normalized_inventory_27  -13
    w[27,14]  mass_27   1
    w[27,14]  w_lb_27_14  1
    w[27,14]  w_ub_27_14  1
    w[27,14]  normalized_inventory_27  -14
    w[27,15]  mass_27   1
    w[27,15]  w_lb_27_15  1
    w[27,15]  w_ub_27_15  1
    w[27,15]  normalized_inventory_27  -15
    w[28,0]   mass_28   1
    w[28,0]   w_lb_28_0  1
    w[28,0]   w_ub_28_0  1
    w[28,1]   mass_28   1
    w[28,1]   w_lb_28_1  1
    w[28,1]   w_ub_28_1  1
    w[28,1]   normalized_inventory_28  -1
    w[28,2]   mass_28   1
    w[28,2]   w_lb_28_2  1
    w[28,2]   w_ub_28_2  1
    w[28,2]   normalized_inventory_28  -2
    w[28,3]   mass_28   1
    w[28,3]   w_lb_28_3  1
    w[28,3]   w_ub_28_3  1
    w[28,3]   normalized_inventory_28  -3
    w[28,4]   mass_28   1
    w[28,4]   w_lb_28_4  1
    w[28,4]   w_ub_28_4  1
    w[28,4]   normalized_inventory_28  -4
    w[28,5]   mass_28   1
    w[28,5]   w_lb_28_5  1
    w[28,5]   w_ub_28_5  1
    w[28,5]   normalized_inventory_28  -5
    w[28,6]   mass_28   1
    w[28,6]   w_lb_28_6  1
    w[28,6]   w_ub_28_6  1
    w[28,6]   normalized_inventory_28  -6
    w[28,7]   mass_28   1
    w[28,7]   w_lb_28_7  1
    w[28,7]   w_ub_28_7  1
    w[28,7]   normalized_inventory_28  -7
    w[28,8]   mass_28   1
    w[28,8]   w_lb_28_8  1
    w[28,8]   w_ub_28_8  1
    w[28,8]   normalized_inventory_28  -8
    w[28,9]   mass_28   1
    w[28,9]   w_lb_28_9  1
    w[28,9]   w_ub_28_9  1
    w[28,9]   normalized_inventory_28  -9
    w[28,10]  mass_28   1
    w[28,10]  w_lb_28_10  1
    w[28,10]  w_ub_28_10  1
    w[28,10]  normalized_inventory_28  -10
    w[28,11]  mass_28   1
    w[28,11]  w_lb_28_11  1
    w[28,11]  w_ub_28_11  1
    w[28,11]  normalized_inventory_28  -11
    w[28,12]  mass_28   1
    w[28,12]  w_lb_28_12  1
    w[28,12]  w_ub_28_12  1
    w[28,12]  normalized_inventory_28  -12
    w[28,13]  mass_28   1
    w[28,13]  w_lb_28_13  1
    w[28,13]  w_ub_28_13  1
    w[28,13]  normalized_inventory_28  -13
    w[28,14]  mass_28   1
    w[28,14]  w_lb_28_14  1
    w[28,14]  w_ub_28_14  1
    w[28,14]  normalized_inventory_28  -14
    w[28,15]  mass_28   1
    w[28,15]  w_lb_28_15  1
    w[28,15]  w_ub_28_15  1
    w[28,15]  normalized_inventory_28  -15
    w[28,16]  mass_28   1
    w[28,16]  w_lb_28_16  1
    w[28,16]  w_ub_28_16  1
    w[28,16]  normalized_inventory_28  -16
    w[28,17]  mass_28   1
    w[28,17]  w_lb_28_17  1
    w[28,17]  w_ub_28_17  1
    w[28,17]  normalized_inventory_28  -17
    w[28,18]  mass_28   1
    w[28,18]  w_lb_28_18  1
    w[28,18]  w_ub_28_18  1
    w[28,18]  normalized_inventory_28  -18
    w[28,19]  mass_28   1
    w[28,19]  w_lb_28_19  1
    w[28,19]  w_ub_28_19  1
    w[28,19]  normalized_inventory_28  -19
    w[29,0]   mass_29   1
    w[29,0]   w_lb_29_0  1
    w[29,0]   w_ub_29_0  1
    w[29,1]   mass_29   1
    w[29,1]   w_lb_29_1  1
    w[29,1]   w_ub_29_1  1
    w[29,1]   normalized_inventory_29  -1
    w[29,2]   mass_29   1
    w[29,2]   w_lb_29_2  1
    w[29,2]   w_ub_29_2  1
    w[29,2]   normalized_inventory_29  -2
    w[29,3]   mass_29   1
    w[29,3]   w_lb_29_3  1
    w[29,3]   w_ub_29_3  1
    w[29,3]   normalized_inventory_29  -3
    w[29,4]   mass_29   1
    w[29,4]   w_lb_29_4  1
    w[29,4]   w_ub_29_4  1
    w[29,4]   normalized_inventory_29  -4
    w[29,5]   mass_29   1
    w[29,5]   w_lb_29_5  1
    w[29,5]   w_ub_29_5  1
    w[29,5]   normalized_inventory_29  -5
    w[29,6]   mass_29   1
    w[29,6]   w_lb_29_6  1
    w[29,6]   w_ub_29_6  1
    w[29,6]   normalized_inventory_29  -6
    w[29,7]   mass_29   1
    w[29,7]   w_lb_29_7  1
    w[29,7]   w_ub_29_7  1
    w[29,7]   normalized_inventory_29  -7
    w[29,8]   mass_29   1
    w[29,8]   w_lb_29_8  1
    w[29,8]   w_ub_29_8  1
    w[29,8]   normalized_inventory_29  -8
    w[29,9]   mass_29   1
    w[29,9]   w_lb_29_9  1
    w[29,9]   w_ub_29_9  1
    w[29,9]   normalized_inventory_29  -9
    w[29,10]  mass_29   1
    w[29,10]  w_lb_29_10  1
    w[29,10]  w_ub_29_10  1
    w[29,10]  normalized_inventory_29  -10
    w[29,11]  mass_29   1
    w[29,11]  w_lb_29_11  1
    w[29,11]  w_ub_29_11  1
    w[29,11]  normalized_inventory_29  -11
    w[29,12]  mass_29   1
    w[29,12]  w_lb_29_12  1
    w[29,12]  w_ub_29_12  1
    w[29,12]  normalized_inventory_29  -12
    w[29,13]  mass_29   1
    w[29,13]  w_lb_29_13  1
    w[29,13]  w_ub_29_13  1
    w[29,13]  normalized_inventory_29  -13
    w[29,14]  mass_29   1
    w[29,14]  w_lb_29_14  1
    w[29,14]  w_ub_29_14  1
    w[29,14]  normalized_inventory_29  -14
    w[29,15]  mass_29   1
    w[29,15]  w_lb_29_15  1
    w[29,15]  w_ub_29_15  1
    w[29,15]  normalized_inventory_29  -15
    w[30,0]   mass_30   1
    w[30,0]   w_lb_30_0  1
    w[30,0]   w_ub_30_0  1
    w[30,1]   mass_30   1
    w[30,1]   w_lb_30_1  1
    w[30,1]   w_ub_30_1  1
    w[30,1]   normalized_inventory_30  -1
    w[30,2]   mass_30   1
    w[30,2]   w_lb_30_2  1
    w[30,2]   w_ub_30_2  1
    w[30,2]   normalized_inventory_30  -2
    w[30,3]   mass_30   1
    w[30,3]   w_lb_30_3  1
    w[30,3]   w_ub_30_3  1
    w[30,3]   normalized_inventory_30  -3
    w[30,4]   mass_30   1
    w[30,4]   w_lb_30_4  1
    w[30,4]   w_ub_30_4  1
    w[30,4]   normalized_inventory_30  -4
    w[30,5]   mass_30   1
    w[30,5]   w_lb_30_5  1
    w[30,5]   w_ub_30_5  1
    w[30,5]   normalized_inventory_30  -5
    w[30,6]   mass_30   1
    w[30,6]   w_lb_30_6  1
    w[30,6]   w_ub_30_6  1
    w[30,6]   normalized_inventory_30  -6
    w[30,7]   mass_30   1
    w[30,7]   w_lb_30_7  1
    w[30,7]   w_ub_30_7  1
    w[30,7]   normalized_inventory_30  -7
    w[30,8]   mass_30   1
    w[30,8]   w_lb_30_8  1
    w[30,8]   w_ub_30_8  1
    w[30,8]   normalized_inventory_30  -8
    w[31,0]   mass_31   1
    w[31,0]   w_lb_31_0  1
    w[31,0]   w_ub_31_0  1
    w[31,1]   mass_31   1
    w[31,1]   w_lb_31_1  1
    w[31,1]   w_ub_31_1  1
    w[31,1]   normalized_inventory_31  -1
    w[31,2]   mass_31   1
    w[31,2]   w_lb_31_2  1
    w[31,2]   w_ub_31_2  1
    w[31,2]   normalized_inventory_31  -2
    w[31,3]   mass_31   1
    w[31,3]   w_lb_31_3  1
    w[31,3]   w_ub_31_3  1
    w[31,3]   normalized_inventory_31  -3
    w[31,4]   mass_31   1
    w[31,4]   w_lb_31_4  1
    w[31,4]   w_ub_31_4  1
    w[31,4]   normalized_inventory_31  -4
    w[31,5]   mass_31   1
    w[31,5]   w_lb_31_5  1
    w[31,5]   w_ub_31_5  1
    w[31,5]   normalized_inventory_31  -5
    w[31,6]   mass_31   1
    w[31,6]   w_lb_31_6  1
    w[31,6]   w_ub_31_6  1
    w[31,6]   normalized_inventory_31  -6
    w[31,7]   mass_31   1
    w[31,7]   w_lb_31_7  1
    w[31,7]   w_ub_31_7  1
    w[31,7]   normalized_inventory_31  -7
    w[31,8]   mass_31   1
    w[31,8]   w_lb_31_8  1
    w[31,8]   w_ub_31_8  1
    w[31,8]   normalized_inventory_31  -8
    w[31,9]   mass_31   1
    w[31,9]   w_lb_31_9  1
    w[31,9]   w_ub_31_9  1
    w[31,9]   normalized_inventory_31  -9
    w[31,10]  mass_31   1
    w[31,10]  w_lb_31_10  1
    w[31,10]  w_ub_31_10  1
    w[31,10]  normalized_inventory_31  -10
    w[31,11]  mass_31   1
    w[31,11]  w_lb_31_11  1
    w[31,11]  w_ub_31_11  1
    w[31,11]  normalized_inventory_31  -11
    w[31,12]  mass_31   1
    w[31,12]  w_lb_31_12  1
    w[31,12]  w_ub_31_12  1
    w[31,12]  normalized_inventory_31  -12
    w[32,0]   mass_32   1
    w[32,0]   w_lb_32_0  1
    w[32,0]   w_ub_32_0  1
    w[32,1]   mass_32   1
    w[32,1]   w_lb_32_1  1
    w[32,1]   w_ub_32_1  1
    w[32,1]   normalized_inventory_32  -1
    w[32,2]   mass_32   1
    w[32,2]   w_lb_32_2  1
    w[32,2]   w_ub_32_2  1
    w[32,2]   normalized_inventory_32  -2
    w[32,3]   mass_32   1
    w[32,3]   w_lb_32_3  1
    w[32,3]   w_ub_32_3  1
    w[32,3]   normalized_inventory_32  -3
    w[32,4]   mass_32   1
    w[32,4]   w_lb_32_4  1
    w[32,4]   w_ub_32_4  1
    w[32,4]   normalized_inventory_32  -4
    w[32,5]   mass_32   1
    w[32,5]   w_lb_32_5  1
    w[32,5]   w_ub_32_5  1
    w[32,5]   normalized_inventory_32  -5
    w[32,6]   mass_32   1
    w[32,6]   w_lb_32_6  1
    w[32,6]   w_ub_32_6  1
    w[32,6]   normalized_inventory_32  -6
    w[32,7]   mass_32   1
    w[32,7]   w_lb_32_7  1
    w[32,7]   w_ub_32_7  1
    w[32,7]   normalized_inventory_32  -7
    w[32,8]   mass_32   1
    w[32,8]   w_lb_32_8  1
    w[32,8]   w_ub_32_8  1
    w[32,8]   normalized_inventory_32  -8
    w[32,9]   mass_32   1
    w[32,9]   w_lb_32_9  1
    w[32,9]   w_ub_32_9  1
    w[32,9]   normalized_inventory_32  -9
    w[32,10]  mass_32   1
    w[32,10]  w_lb_32_10  1
    w[32,10]  w_ub_32_10  1
    w[32,10]  normalized_inventory_32  -10
    w[32,11]  mass_32   1
    w[32,11]  w_lb_32_11  1
    w[32,11]  w_ub_32_11  1
    w[32,11]  normalized_inventory_32  -11
    w[32,12]  mass_32   1
    w[32,12]  w_lb_32_12  1
    w[32,12]  w_ub_32_12  1
    w[32,12]  normalized_inventory_32  -12
    w[33,0]   mass_33   1
    w[33,0]   w_lb_33_0  1
    w[33,0]   w_ub_33_0  1
    w[33,1]   mass_33   1
    w[33,1]   w_lb_33_1  1
    w[33,1]   w_ub_33_1  1
    w[33,1]   normalized_inventory_33  -1
    w[33,2]   mass_33   1
    w[33,2]   w_lb_33_2  1
    w[33,2]   w_ub_33_2  1
    w[33,2]   normalized_inventory_33  -2
    w[33,3]   mass_33   1
    w[33,3]   w_lb_33_3  1
    w[33,3]   w_ub_33_3  1
    w[33,3]   normalized_inventory_33  -3
    w[33,4]   mass_33   1
    w[33,4]   w_lb_33_4  1
    w[33,4]   w_ub_33_4  1
    w[33,4]   normalized_inventory_33  -4
    w[33,5]   mass_33   1
    w[33,5]   w_lb_33_5  1
    w[33,5]   w_ub_33_5  1
    w[33,5]   normalized_inventory_33  -5
    w[33,6]   mass_33   1
    w[33,6]   w_lb_33_6  1
    w[33,6]   w_ub_33_6  1
    w[33,6]   normalized_inventory_33  -6
    w[33,7]   mass_33   1
    w[33,7]   w_lb_33_7  1
    w[33,7]   w_ub_33_7  1
    w[33,7]   normalized_inventory_33  -7
    w[33,8]   mass_33   1
    w[33,8]   w_lb_33_8  1
    w[33,8]   w_ub_33_8  1
    w[33,8]   normalized_inventory_33  -8
    w[33,9]   mass_33   1
    w[33,9]   w_lb_33_9  1
    w[33,9]   w_ub_33_9  1
    w[33,9]   normalized_inventory_33  -9
    w[33,10]  mass_33   1
    w[33,10]  w_lb_33_10  1
    w[33,10]  w_ub_33_10  1
    w[33,10]  normalized_inventory_33  -10
    w[33,11]  mass_33   1
    w[33,11]  w_lb_33_11  1
    w[33,11]  w_ub_33_11  1
    w[33,11]  normalized_inventory_33  -11
    w[33,12]  mass_33   1
    w[33,12]  w_lb_33_12  1
    w[33,12]  w_ub_33_12  1
    w[33,12]  normalized_inventory_33  -12
    w[33,13]  mass_33   1
    w[33,13]  w_lb_33_13  1
    w[33,13]  w_ub_33_13  1
    w[33,13]  normalized_inventory_33  -13
    w[33,14]  mass_33   1
    w[33,14]  w_lb_33_14  1
    w[33,14]  w_ub_33_14  1
    w[33,14]  normalized_inventory_33  -14
    w[33,15]  mass_33   1
    w[33,15]  w_lb_33_15  1
    w[33,15]  w_ub_33_15  1
    w[33,15]  normalized_inventory_33  -15
    w[33,16]  mass_33   1
    w[33,16]  w_lb_33_16  1
    w[33,16]  w_ub_33_16  1
    w[33,16]  normalized_inventory_33  -16
    w[34,0]   mass_34   1
    w[34,0]   w_lb_34_0  1
    w[34,0]   w_ub_34_0  1
    w[34,1]   mass_34   1
    w[34,1]   w_lb_34_1  1
    w[34,1]   w_ub_34_1  1
    w[34,1]   normalized_inventory_34  -1
    w[34,2]   mass_34   1
    w[34,2]   w_lb_34_2  1
    w[34,2]   w_ub_34_2  1
    w[34,2]   normalized_inventory_34  -2
    w[34,3]   mass_34   1
    w[34,3]   w_lb_34_3  1
    w[34,3]   w_ub_34_3  1
    w[34,3]   normalized_inventory_34  -3
    w[34,4]   mass_34   1
    w[34,4]   w_lb_34_4  1
    w[34,4]   w_ub_34_4  1
    w[34,4]   normalized_inventory_34  -4
    w[34,5]   mass_34   1
    w[34,5]   w_lb_34_5  1
    w[34,5]   w_ub_34_5  1
    w[34,5]   normalized_inventory_34  -5
    w[34,6]   mass_34   1
    w[34,6]   w_lb_34_6  1
    w[34,6]   w_ub_34_6  1
    w[34,6]   normalized_inventory_34  -6
    w[34,7]   mass_34   1
    w[34,7]   w_lb_34_7  1
    w[34,7]   w_ub_34_7  1
    w[34,7]   normalized_inventory_34  -7
    w[34,8]   mass_34   1
    w[34,8]   w_lb_34_8  1
    w[34,8]   w_ub_34_8  1
    w[34,8]   normalized_inventory_34  -8
    w[34,9]   mass_34   1
    w[34,9]   w_lb_34_9  1
    w[34,9]   w_ub_34_9  1
    w[34,9]   normalized_inventory_34  -9
    w[34,10]  mass_34   1
    w[34,10]  w_lb_34_10  1
    w[34,10]  w_ub_34_10  1
    w[34,10]  normalized_inventory_34  -10
    w[34,11]  mass_34   1
    w[34,11]  w_lb_34_11  1
    w[34,11]  w_ub_34_11  1
    w[34,11]  normalized_inventory_34  -11
    w[35,0]   mass_35   1
    w[35,0]   w_lb_35_0  1
    w[35,0]   w_ub_35_0  1
    w[35,1]   mass_35   1
    w[35,1]   w_lb_35_1  1
    w[35,1]   w_ub_35_1  1
    w[35,1]   normalized_inventory_35  -1
    w[35,2]   mass_35   1
    w[35,2]   w_lb_35_2  1
    w[35,2]   w_ub_35_2  1
    w[35,2]   normalized_inventory_35  -2
    w[35,3]   mass_35   1
    w[35,3]   w_lb_35_3  1
    w[35,3]   w_ub_35_3  1
    w[35,3]   normalized_inventory_35  -3
    w[35,4]   mass_35   1
    w[35,4]   w_lb_35_4  1
    w[35,4]   w_ub_35_4  1
    w[35,4]   normalized_inventory_35  -4
    w[35,5]   mass_35   1
    w[35,5]   w_lb_35_5  1
    w[35,5]   w_ub_35_5  1
    w[35,5]   normalized_inventory_35  -5
    w[35,6]   mass_35   1
    w[35,6]   w_lb_35_6  1
    w[35,6]   w_ub_35_6  1
    w[35,6]   normalized_inventory_35  -6
    w[35,7]   mass_35   1
    w[35,7]   w_lb_35_7  1
    w[35,7]   w_ub_35_7  1
    w[35,7]   normalized_inventory_35  -7
    w[35,8]   mass_35   1
    w[35,8]   w_lb_35_8  1
    w[35,8]   w_ub_35_8  1
    w[35,8]   normalized_inventory_35  -8
    w[35,9]   mass_35   1
    w[35,9]   w_lb_35_9  1
    w[35,9]   w_ub_35_9  1
    w[35,9]   normalized_inventory_35  -9
    w[35,10]  mass_35   1
    w[35,10]  w_lb_35_10  1
    w[35,10]  w_ub_35_10  1
    w[35,10]  normalized_inventory_35  -10
    w[35,11]  mass_35   1
    w[35,11]  w_lb_35_11  1
    w[35,11]  w_ub_35_11  1
    w[35,11]  normalized_inventory_35  -11
    w[35,12]  mass_35   1
    w[35,12]  w_lb_35_12  1
    w[35,12]  w_ub_35_12  1
    w[35,12]  normalized_inventory_35  -12
    w[35,13]  mass_35   1
    w[35,13]  w_lb_35_13  1
    w[35,13]  w_ub_35_13  1
    w[35,13]  normalized_inventory_35  -13
    w[35,14]  mass_35   1
    w[35,14]  w_lb_35_14  1
    w[35,14]  w_ub_35_14  1
    w[35,14]  normalized_inventory_35  -14
    w[35,15]  mass_35   1
    w[35,15]  w_lb_35_15  1
    w[35,15]  w_ub_35_15  1
    w[35,15]  normalized_inventory_35  -15
    t         mass_1    -1
    t         mass_2    -1
    t         mass_3    -1
    t         mass_4    -1
    t         mass_5    -1
    t         mass_6    -1
    t         mass_7    -1
    t         mass_8    -1
    t         mass_9    -1
    t         mass_10   -1
    t         mass_11   -1
    t         mass_12   -1
    t         mass_13   -1
    t         mass_14   -1
    t         mass_15   -1
    t         mass_16   -1
    t         mass_17   -1
    t         mass_18   -1
    t         mass_19   -1
    t         mass_20   -1
    t         mass_21   -1
    t         mass_22   -1
    t         mass_23   -1
    t         mass_24   -1
    t         mass_25   -1
    t         mass_26   -1
    t         mass_27   -1
    t         mass_28   -1
    t         mass_29   -1
    t         mass_30   -1
    t         mass_31   -1
    t         mass_32   -1
    t         mass_33   -1
    t         mass_34   -1
    t         mass_35   -1
    t         scaled_stock_lower  -136
    t         scaled_stock_upper  -211
    z[1]      normalized_inventory_1  1
    z[1]      normalized_ratio_1  -0.1
    z[1]      scaled_stock_lower  1
    z[1]      scaled_stock_upper  1
    z[2]      normalized_inventory_2  1
    z[2]      normalized_ratio_2  -1.4285714285714285e-01
    z[2]      scaled_stock_lower  1
    z[2]      scaled_stock_upper  1
    z[3]      normalized_inventory_3  1
    z[3]      normalized_ratio_3  -0.125
    z[3]      scaled_stock_lower  1
    z[3]      scaled_stock_upper  1
    z[4]      normalized_inventory_4  1
    z[4]      normalized_ratio_4  -1.4285714285714285e-01
    z[4]      scaled_stock_lower  1
    z[4]      scaled_stock_upper  1
    z[5]      normalized_inventory_5  1
    z[5]      normalized_ratio_5  -0.125
    z[5]      scaled_stock_lower  1
    z[5]      scaled_stock_upper  1
    z[6]      normalized_inventory_6  1
    z[6]      normalized_ratio_6  -0.2
    z[6]      scaled_stock_lower  1
    z[6]      scaled_stock_upper  1
    z[7]      normalized_inventory_7  1
    z[7]      normalized_ratio_7  -0.125
    z[7]      scaled_stock_lower  1
    z[7]      scaled_stock_upper  1
    z[8]      normalized_inventory_8  1
    z[8]      normalized_ratio_8  -0.1
    z[8]      scaled_stock_lower  1
    z[8]      scaled_stock_upper  1
    z[9]      normalized_inventory_9  1
    z[9]      normalized_ratio_9  -0.2
    z[9]      scaled_stock_lower  1
    z[9]      scaled_stock_upper  1
    z[10]     normalized_inventory_10  1
    z[10]     normalized_ratio_10  -0.1
    z[10]     scaled_stock_lower  1
    z[10]     scaled_stock_upper  1
    z[11]     normalized_inventory_11  1
    z[11]     normalized_ratio_11  -0.2
    z[11]     scaled_stock_lower  1
    z[11]     scaled_stock_upper  1
    z[12]     normalized_inventory_12  1
    z[12]     normalized_ratio_12  -1.4285714285714285e-01
    z[12]     scaled_stock_lower  1
    z[12]     scaled_stock_upper  1
    z[13]     normalized_inventory_13  1
    z[13]     normalized_ratio_13  -0.125
    z[13]     scaled_stock_lower  1
    z[13]     scaled_stock_upper  1
    z[14]     normalized_inventory_14  1
    z[14]     normalized_ratio_14  -0.125
    z[14]     scaled_stock_lower  1
    z[14]     scaled_stock_upper  1
    z[15]     normalized_inventory_15  1
    z[15]     normalized_ratio_15  -1.1111111111111110e-01
    z[15]     scaled_stock_lower  1
    z[15]     scaled_stock_upper  1
    z[16]     normalized_inventory_16  1
    z[16]     normalized_ratio_16  -1.6666666666666666e-01
    z[16]     scaled_stock_lower  1
    z[16]     scaled_stock_upper  1
    z[17]     normalized_inventory_17  1
    z[17]     normalized_ratio_17  -1.1111111111111110e-01
    z[17]     scaled_stock_lower  1
    z[17]     scaled_stock_upper  1
    z[18]     normalized_inventory_18  1
    z[18]     normalized_ratio_18  -1.1111111111111110e-01
    z[18]     scaled_stock_lower  1
    z[18]     scaled_stock_upper  1
    z[19]     normalized_inventory_19  1
    z[19]     normalized_ratio_19  -0.25
    z[19]     scaled_stock_lower  1
    z[19]     scaled_stock_upper  1
    z[20]     normalized_inventory_20  1
    z[20]     normalized_ratio_20  -1.6666666666666666e-01
    z[20]     scaled_stock_lower  1
    z[20]     scaled_stock_upper  1
    z[21]     normalized_inventory_21  1
    z[21]     normalized_ratio_21  -0.125
    z[21]     scaled_stock_lower  1
    z[21]     scaled_stock_upper  1
    z[22]     normalized_inventory_22  1
    z[22]     normalized_ratio_22  -1.6666666666666666e-01
    z[22]     scaled_stock_lower  1
    z[22]     scaled_stock_upper  1
    z[23]     normalized_inventory_23  1
    z[23]     normalized_ratio_23  -0.2
    z[23]     scaled_stock_lower  1
    z[23]     scaled_stock_upper  1
    z[24]     normalized_inventory_24  1
    z[24]     normalized_ratio_24  -0.125
    z[24]     scaled_stock_lower  1
    z[24]     scaled_stock_upper  1
    z[25]     normalized_inventory_25  1
    z[25]     normalized_ratio_25  -1.4285714285714285e-01
    z[25]     scaled_stock_lower  1
    z[25]     scaled_stock_upper  1
    z[26]     normalized_inventory_26  1
    z[26]     normalized_ratio_26  -0.25
    z[26]     scaled_stock_lower  1
    z[26]     scaled_stock_upper  1
    z[27]     normalized_inventory_27  1
    z[27]     normalized_ratio_27  -1.4285714285714285e-01
    z[27]     scaled_stock_lower  1
    z[27]     scaled_stock_upper  1
    z[28]     normalized_inventory_28  1
    z[28]     normalized_ratio_28  -0.125
    z[28]     scaled_stock_lower  1
    z[28]     scaled_stock_upper  1
    z[29]     normalized_inventory_29  1
    z[29]     normalized_ratio_29  -0.125
    z[29]     scaled_stock_lower  1
    z[29]     scaled_stock_upper  1
    z[30]     normalized_inventory_30  1
    z[30]     normalized_ratio_30  -0.25
    z[30]     scaled_stock_lower  1
    z[30]     scaled_stock_upper  1
    z[31]     normalized_inventory_31  1
    z[31]     normalized_ratio_31  -1.4285714285714285e-01
    z[31]     scaled_stock_lower  1
    z[31]     scaled_stock_upper  1
    z[32]     normalized_inventory_32  1
    z[32]     normalized_ratio_32  -0.2
    z[32]     scaled_stock_lower  1
    z[32]     scaled_stock_upper  1
    z[33]     normalized_inventory_33  1
    z[33]     normalized_ratio_33  -1.4285714285714285e-01
    z[33]     scaled_stock_lower  1
    z[33]     scaled_stock_upper  1
    z[34]     normalized_inventory_34  1
    z[34]     normalized_ratio_34  -0.2
    z[34]     scaled_stock_lower  1
    z[34]     scaled_stock_upper  1
    z[35]     normalized_inventory_35  1
    z[35]     normalized_ratio_35  -0.125
    z[35]     scaled_stock_lower  1
    z[35]     scaled_stock_upper  1
    r[1]      normalized_ratio_1  1
    r[1]      normalization  1
    r[1]      abs_p_1_2  -1
    r[1]      abs_m_1_2  1
    r[1]      abs_p_1_3  -1
    r[1]      abs_m_1_3  1
    r[1]      abs_p_1_4  -1
    r[1]      abs_m_1_4  1
    r[1]      abs_p_1_5  -1
    r[1]      abs_m_1_5  1
    r[1]      abs_p_1_6  -1
    r[1]      abs_m_1_6  1
    r[1]      abs_p_1_7  -1
    r[1]      abs_m_1_7  1
    r[1]      abs_p_1_8  -1
    r[1]      abs_m_1_8  1
    r[1]      abs_p_1_9  -1
    r[1]      abs_m_1_9  1
    r[1]      abs_p_1_10  -1
    r[1]      abs_m_1_10  1
    r[1]      abs_p_1_11  -1
    r[1]      abs_m_1_11  1
    r[1]      abs_p_1_12  -1
    r[1]      abs_m_1_12  1
    r[1]      abs_p_1_13  -1
    r[1]      abs_m_1_13  1
    r[1]      abs_p_1_14  -1
    r[1]      abs_m_1_14  1
    r[1]      abs_p_1_15  -1
    r[1]      abs_m_1_15  1
    r[1]      abs_p_1_16  -1
    r[1]      abs_m_1_16  1
    r[1]      abs_p_1_17  -1
    r[1]      abs_m_1_17  1
    r[1]      abs_p_1_18  -1
    r[1]      abs_m_1_18  1
    r[1]      abs_p_1_19  -1
    r[1]      abs_m_1_19  1
    r[1]      abs_p_1_20  -1
    r[1]      abs_m_1_20  1
    r[1]      abs_p_1_21  -1
    r[1]      abs_m_1_21  1
    r[1]      abs_p_1_22  -1
    r[1]      abs_m_1_22  1
    r[1]      abs_p_1_23  -1
    r[1]      abs_m_1_23  1
    r[1]      abs_p_1_24  -1
    r[1]      abs_m_1_24  1
    r[1]      abs_p_1_25  -1
    r[1]      abs_m_1_25  1
    r[1]      abs_p_1_26  -1
    r[1]      abs_m_1_26  1
    r[1]      abs_p_1_27  -1
    r[1]      abs_m_1_27  1
    r[1]      abs_p_1_28  -1
    r[1]      abs_m_1_28  1
    r[1]      abs_p_1_29  -1
    r[1]      abs_m_1_29  1
    r[1]      abs_p_1_30  -1
    r[1]      abs_m_1_30  1
    r[1]      abs_p_1_31  -1
    r[1]      abs_m_1_31  1
    r[1]      abs_p_1_32  -1
    r[1]      abs_m_1_32  1
    r[1]      abs_p_1_33  -1
    r[1]      abs_m_1_33  1
    r[1]      abs_p_1_34  -1
    r[1]      abs_m_1_34  1
    r[1]      abs_p_1_35  -1
    r[1]      abs_m_1_35  1
    r[2]      normalized_ratio_2  1
    r[2]      normalization  1
    r[2]      abs_p_1_2  1
    r[2]      abs_m_1_2  -1
    r[2]      abs_p_2_3  -1
    r[2]      abs_m_2_3  1
    r[2]      abs_p_2_4  -1
    r[2]      abs_m_2_4  1
    r[2]      abs_p_2_5  -1
    r[2]      abs_m_2_5  1
    r[2]      abs_p_2_6  -1
    r[2]      abs_m_2_6  1
    r[2]      abs_p_2_7  -1
    r[2]      abs_m_2_7  1
    r[2]      abs_p_2_8  -1
    r[2]      abs_m_2_8  1
    r[2]      abs_p_2_9  -1
    r[2]      abs_m_2_9  1
    r[2]      abs_p_2_10  -1
    r[2]      abs_m_2_10  1
    r[2]      abs_p_2_11  -1
    r[2]      abs_m_2_11  1
    r[2]      abs_p_2_12  -1
    r[2]      abs_m_2_12  1
    r[2]      abs_p_2_13  -1
    r[2]      abs_m_2_13  1
    r[2]      abs_p_2_14  -1
    r[2]      abs_m_2_14  1
    r[2]      abs_p_2_15  -1
    r[2]      abs_m_2_15  1
    r[2]      abs_p_2_16  -1
    r[2]      abs_m_2_16  1
    r[2]      abs_p_2_17  -1
    r[2]      abs_m_2_17  1
    r[2]      abs_p_2_18  -1
    r[2]      abs_m_2_18  1
    r[2]      abs_p_2_19  -1
    r[2]      abs_m_2_19  1
    r[2]      abs_p_2_20  -1
    r[2]      abs_m_2_20  1
    r[2]      abs_p_2_21  -1
    r[2]      abs_m_2_21  1
    r[2]      abs_p_2_22  -1
    r[2]      abs_m_2_22  1
    r[2]      abs_p_2_23  -1
    r[2]      abs_m_2_23  1
    r[2]      abs_p_2_24  -1
    r[2]      abs_m_2_24  1
    r[2]      abs_p_2_25  -1
    r[2]      abs_m_2_25  1
    r[2]      abs_p_2_26  -1
    r[2]      abs_m_2_26  1
    r[2]      abs_p_2_27  -1
    r[2]      abs_m_2_27  1
    r[2]      abs_p_2_28  -1
    r[2]      abs_m_2_28  1
    r[2]      abs_p_2_29  -1
    r[2]      abs_m_2_29  1
    r[2]      abs_p_2_30  -1
    r[2]      abs_m_2_30  1
    r[2]      abs_p_2_31  -1
    r[2]      abs_m_2_31  1
    r[2]      abs_p_2_32  -1
    r[2]      abs_m_2_32  1
    r[2]      abs_p_2_33  -1
    r[2]      abs_m_2_33  1
    r[2]      abs_p_2_34  -1
    r[2]      abs_m_2_34  1
    r[2]      abs_p_2_35  -1
    r[2]      abs_m_2_35  1
    r[3]      normalized_ratio_3  1
    r[3]      normalization  1
    r[3]      abs_p_1_3  1
    r[3]      abs_m_1_3  -1
    r[3]      abs_p_2_3  1
    r[3]      abs_m_2_3  -1
    r[3]      abs_p_3_4  -1
    r[3]      abs_m_3_4  1
    r[3]      abs_p_3_5  -1
    r[3]      abs_m_3_5  1
    r[3]      abs_p_3_6  -1
    r[3]      abs_m_3_6  1
    r[3]      abs_p_3_7  -1
    r[3]      abs_m_3_7  1
    r[3]      abs_p_3_8  -1
    r[3]      abs_m_3_8  1
    r[3]      abs_p_3_9  -1
    r[3]      abs_m_3_9  1
    r[3]      abs_p_3_10  -1
    r[3]      abs_m_3_10  1
    r[3]      abs_p_3_11  -1
    r[3]      abs_m_3_11  1
    r[3]      abs_p_3_12  -1
    r[3]      abs_m_3_12  1
    r[3]      abs_p_3_13  -1
    r[3]      abs_m_3_13  1
    r[3]      abs_p_3_14  -1
    r[3]      abs_m_3_14  1
    r[3]      abs_p_3_15  -1
    r[3]      abs_m_3_15  1
    r[3]      abs_p_3_16  -1
    r[3]      abs_m_3_16  1
    r[3]      abs_p_3_17  -1
    r[3]      abs_m_3_17  1
    r[3]      abs_p_3_18  -1
    r[3]      abs_m_3_18  1
    r[3]      abs_p_3_19  -1
    r[3]      abs_m_3_19  1
    r[3]      abs_p_3_20  -1
    r[3]      abs_m_3_20  1
    r[3]      abs_p_3_21  -1
    r[3]      abs_m_3_21  1
    r[3]      abs_p_3_22  -1
    r[3]      abs_m_3_22  1
    r[3]      abs_p_3_23  -1
    r[3]      abs_m_3_23  1
    r[3]      abs_p_3_24  -1
    r[3]      abs_m_3_24  1
    r[3]      abs_p_3_25  -1
    r[3]      abs_m_3_25  1
    r[3]      abs_p_3_26  -1
    r[3]      abs_m_3_26  1
    r[3]      abs_p_3_27  -1
    r[3]      abs_m_3_27  1
    r[3]      abs_p_3_28  -1
    r[3]      abs_m_3_28  1
    r[3]      abs_p_3_29  -1
    r[3]      abs_m_3_29  1
    r[3]      abs_p_3_30  -1
    r[3]      abs_m_3_30  1
    r[3]      abs_p_3_31  -1
    r[3]      abs_m_3_31  1
    r[3]      abs_p_3_32  -1
    r[3]      abs_m_3_32  1
    r[3]      abs_p_3_33  -1
    r[3]      abs_m_3_33  1
    r[3]      abs_p_3_34  -1
    r[3]      abs_m_3_34  1
    r[3]      abs_p_3_35  -1
    r[3]      abs_m_3_35  1
    r[4]      normalized_ratio_4  1
    r[4]      normalization  1
    r[4]      abs_p_1_4  1
    r[4]      abs_m_1_4  -1
    r[4]      abs_p_2_4  1
    r[4]      abs_m_2_4  -1
    r[4]      abs_p_3_4  1
    r[4]      abs_m_3_4  -1
    r[4]      abs_p_4_5  -1
    r[4]      abs_m_4_5  1
    r[4]      abs_p_4_6  -1
    r[4]      abs_m_4_6  1
    r[4]      abs_p_4_7  -1
    r[4]      abs_m_4_7  1
    r[4]      abs_p_4_8  -1
    r[4]      abs_m_4_8  1
    r[4]      abs_p_4_9  -1
    r[4]      abs_m_4_9  1
    r[4]      abs_p_4_10  -1
    r[4]      abs_m_4_10  1
    r[4]      abs_p_4_11  -1
    r[4]      abs_m_4_11  1
    r[4]      abs_p_4_12  -1
    r[4]      abs_m_4_12  1
    r[4]      abs_p_4_13  -1
    r[4]      abs_m_4_13  1
    r[4]      abs_p_4_14  -1
    r[4]      abs_m_4_14  1
    r[4]      abs_p_4_15  -1
    r[4]      abs_m_4_15  1
    r[4]      abs_p_4_16  -1
    r[4]      abs_m_4_16  1
    r[4]      abs_p_4_17  -1
    r[4]      abs_m_4_17  1
    r[4]      abs_p_4_18  -1
    r[4]      abs_m_4_18  1
    r[4]      abs_p_4_19  -1
    r[4]      abs_m_4_19  1
    r[4]      abs_p_4_20  -1
    r[4]      abs_m_4_20  1
    r[4]      abs_p_4_21  -1
    r[4]      abs_m_4_21  1
    r[4]      abs_p_4_22  -1
    r[4]      abs_m_4_22  1
    r[4]      abs_p_4_23  -1
    r[4]      abs_m_4_23  1
    r[4]      abs_p_4_24  -1
    r[4]      abs_m_4_24  1
    r[4]      abs_p_4_25  -1
    r[4]      abs_m_4_25  1
    r[4]      abs_p_4_26  -1
    r[4]      abs_m_4_26  1
    r[4]      abs_p_4_27  -1
    r[4]      abs_m_4_27  1
    r[4]      abs_p_4_28  -1
    r[4]      abs_m_4_28  1
    r[4]      abs_p_4_29  -1
    r[4]      abs_m_4_29  1
    r[4]      abs_p_4_30  -1
    r[4]      abs_m_4_30  1
    r[4]      abs_p_4_31  -1
    r[4]      abs_m_4_31  1
    r[4]      abs_p_4_32  -1
    r[4]      abs_m_4_32  1
    r[4]      abs_p_4_33  -1
    r[4]      abs_m_4_33  1
    r[4]      abs_p_4_34  -1
    r[4]      abs_m_4_34  1
    r[4]      abs_p_4_35  -1
    r[4]      abs_m_4_35  1
    r[5]      normalized_ratio_5  1
    r[5]      normalization  1
    r[5]      abs_p_1_5  1
    r[5]      abs_m_1_5  -1
    r[5]      abs_p_2_5  1
    r[5]      abs_m_2_5  -1
    r[5]      abs_p_3_5  1
    r[5]      abs_m_3_5  -1
    r[5]      abs_p_4_5  1
    r[5]      abs_m_4_5  -1
    r[5]      abs_p_5_6  -1
    r[5]      abs_m_5_6  1
    r[5]      abs_p_5_7  -1
    r[5]      abs_m_5_7  1
    r[5]      abs_p_5_8  -1
    r[5]      abs_m_5_8  1
    r[5]      abs_p_5_9  -1
    r[5]      abs_m_5_9  1
    r[5]      abs_p_5_10  -1
    r[5]      abs_m_5_10  1
    r[5]      abs_p_5_11  -1
    r[5]      abs_m_5_11  1
    r[5]      abs_p_5_12  -1
    r[5]      abs_m_5_12  1
    r[5]      abs_p_5_13  -1
    r[5]      abs_m_5_13  1
    r[5]      abs_p_5_14  -1
    r[5]      abs_m_5_14  1
    r[5]      abs_p_5_15  -1
    r[5]      abs_m_5_15  1
    r[5]      abs_p_5_16  -1
    r[5]      abs_m_5_16  1
    r[5]      abs_p_5_17  -1
    r[5]      abs_m_5_17  1
    r[5]      abs_p_5_18  -1
    r[5]      abs_m_5_18  1
    r[5]      abs_p_5_19  -1
    r[5]      abs_m_5_19  1
    r[5]      abs_p_5_20  -1
    r[5]      abs_m_5_20  1
    r[5]      abs_p_5_21  -1
    r[5]      abs_m_5_21  1
    r[5]      abs_p_5_22  -1
    r[5]      abs_m_5_22  1
    r[5]      abs_p_5_23  -1
    r[5]      abs_m_5_23  1
    r[5]      abs_p_5_24  -1
    r[5]      abs_m_5_24  1
    r[5]      abs_p_5_25  -1
    r[5]      abs_m_5_25  1
    r[5]      abs_p_5_26  -1
    r[5]      abs_m_5_26  1
    r[5]      abs_p_5_27  -1
    r[5]      abs_m_5_27  1
    r[5]      abs_p_5_28  -1
    r[5]      abs_m_5_28  1
    r[5]      abs_p_5_29  -1
    r[5]      abs_m_5_29  1
    r[5]      abs_p_5_30  -1
    r[5]      abs_m_5_30  1
    r[5]      abs_p_5_31  -1
    r[5]      abs_m_5_31  1
    r[5]      abs_p_5_32  -1
    r[5]      abs_m_5_32  1
    r[5]      abs_p_5_33  -1
    r[5]      abs_m_5_33  1
    r[5]      abs_p_5_34  -1
    r[5]      abs_m_5_34  1
    r[5]      abs_p_5_35  -1
    r[5]      abs_m_5_35  1
    r[6]      normalized_ratio_6  1
    r[6]      normalization  1
    r[6]      abs_p_1_6  1
    r[6]      abs_m_1_6  -1
    r[6]      abs_p_2_6  1
    r[6]      abs_m_2_6  -1
    r[6]      abs_p_3_6  1
    r[6]      abs_m_3_6  -1
    r[6]      abs_p_4_6  1
    r[6]      abs_m_4_6  -1
    r[6]      abs_p_5_6  1
    r[6]      abs_m_5_6  -1
    r[6]      abs_p_6_7  -1
    r[6]      abs_m_6_7  1
    r[6]      abs_p_6_8  -1
    r[6]      abs_m_6_8  1
    r[6]      abs_p_6_9  -1
    r[6]      abs_m_6_9  1
    r[6]      abs_p_6_10  -1
    r[6]      abs_m_6_10  1
    r[6]      abs_p_6_11  -1
    r[6]      abs_m_6_11  1
    r[6]      abs_p_6_12  -1
    r[6]      abs_m_6_12  1
    r[6]      abs_p_6_13  -1
    r[6]      abs_m_6_13  1
    r[6]      abs_p_6_14  -1
    r[6]      abs_m_6_14  1
    r[6]      abs_p_6_15  -1
    r[6]      abs_m_6_15  1
    r[6]      abs_p_6_16  -1
    r[6]      abs_m_6_16  1
    r[6]      abs_p_6_17  -1
    r[6]      abs_m_6_17  1
    r[6]      abs_p_6_18  -1
    r[6]      abs_m_6_18  1
    r[6]      abs_p_6_19  -1
    r[6]      abs_m_6_19  1
    r[6]      abs_p_6_20  -1
    r[6]      abs_m_6_20  1
    r[6]      abs_p_6_21  -1
    r[6]      abs_m_6_21  1
    r[6]      abs_p_6_22  -1
    r[6]      abs_m_6_22  1
    r[6]      abs_p_6_23  -1
    r[6]      abs_m_6_23  1
    r[6]      abs_p_6_24  -1
    r[6]      abs_m_6_24  1
    r[6]      abs_p_6_25  -1
    r[6]      abs_m_6_25  1
    r[6]      abs_p_6_26  -1
    r[6]      abs_m_6_26  1
    r[6]      abs_p_6_27  -1
    r[6]      abs_m_6_27  1
    r[6]      abs_p_6_28  -1
    r[6]      abs_m_6_28  1
    r[6]      abs_p_6_29  -1
    r[6]      abs_m_6_29  1
    r[6]      abs_p_6_30  -1
    r[6]      abs_m_6_30  1
    r[6]      abs_p_6_31  -1
    r[6]      abs_m_6_31  1
    r[6]      abs_p_6_32  -1
    r[6]      abs_m_6_32  1
    r[6]      abs_p_6_33  -1
    r[6]      abs_m_6_33  1
    r[6]      abs_p_6_34  -1
    r[6]      abs_m_6_34  1
    r[6]      abs_p_6_35  -1
    r[6]      abs_m_6_35  1
    r[7]      normalized_ratio_7  1
    r[7]      normalization  1
    r[7]      abs_p_1_7  1
    r[7]      abs_m_1_7  -1
    r[7]      abs_p_2_7  1
    r[7]      abs_m_2_7  -1
    r[7]      abs_p_3_7  1
    r[7]      abs_m_3_7  -1
    r[7]      abs_p_4_7  1
    r[7]      abs_m_4_7  -1
    r[7]      abs_p_5_7  1
    r[7]      abs_m_5_7  -1
    r[7]      abs_p_6_7  1
    r[7]      abs_m_6_7  -1
    r[7]      abs_p_7_8  -1
    r[7]      abs_m_7_8  1
    r[7]      abs_p_7_9  -1
    r[7]      abs_m_7_9  1
    r[7]      abs_p_7_10  -1
    r[7]      abs_m_7_10  1
    r[7]      abs_p_7_11  -1
    r[7]      abs_m_7_11  1
    r[7]      abs_p_7_12  -1
    r[7]      abs_m_7_12  1
    r[7]      abs_p_7_13  -1
    r[7]      abs_m_7_13  1
    r[7]      abs_p_7_14  -1
    r[7]      abs_m_7_14  1
    r[7]      abs_p_7_15  -1
    r[7]      abs_m_7_15  1
    r[7]      abs_p_7_16  -1
    r[7]      abs_m_7_16  1
    r[7]      abs_p_7_17  -1
    r[7]      abs_m_7_17  1
    r[7]      abs_p_7_18  -1
    r[7]      abs_m_7_18  1
    r[7]      abs_p_7_19  -1
    r[7]      abs_m_7_19  1
    r[7]      abs_p_7_20  -1
    r[7]      abs_m_7_20  1
    r[7]      abs_p_7_21  -1
    r[7]      abs_m_7_21  1
    r[7]      abs_p_7_22  -1
    r[7]      abs_m_7_22  1
    r[7]      abs_p_7_23  -1
    r[7]      abs_m_7_23  1
    r[7]      abs_p_7_24  -1
    r[7]      abs_m_7_24  1
    r[7]      abs_p_7_25  -1
    r[7]      abs_m_7_25  1
    r[7]      abs_p_7_26  -1
    r[7]      abs_m_7_26  1
    r[7]      abs_p_7_27  -1
    r[7]      abs_m_7_27  1
    r[7]      abs_p_7_28  -1
    r[7]      abs_m_7_28  1
    r[7]      abs_p_7_29  -1
    r[7]      abs_m_7_29  1
    r[7]      abs_p_7_30  -1
    r[7]      abs_m_7_30  1
    r[7]      abs_p_7_31  -1
    r[7]      abs_m_7_31  1
    r[7]      abs_p_7_32  -1
    r[7]      abs_m_7_32  1
    r[7]      abs_p_7_33  -1
    r[7]      abs_m_7_33  1
    r[7]      abs_p_7_34  -1
    r[7]      abs_m_7_34  1
    r[7]      abs_p_7_35  -1
    r[7]      abs_m_7_35  1
    r[8]      normalized_ratio_8  1
    r[8]      normalization  1
    r[8]      abs_p_1_8  1
    r[8]      abs_m_1_8  -1
    r[8]      abs_p_2_8  1
    r[8]      abs_m_2_8  -1
    r[8]      abs_p_3_8  1
    r[8]      abs_m_3_8  -1
    r[8]      abs_p_4_8  1
    r[8]      abs_m_4_8  -1
    r[8]      abs_p_5_8  1
    r[8]      abs_m_5_8  -1
    r[8]      abs_p_6_8  1
    r[8]      abs_m_6_8  -1
    r[8]      abs_p_7_8  1
    r[8]      abs_m_7_8  -1
    r[8]      abs_p_8_9  -1
    r[8]      abs_m_8_9  1
    r[8]      abs_p_8_10  -1
    r[8]      abs_m_8_10  1
    r[8]      abs_p_8_11  -1
    r[8]      abs_m_8_11  1
    r[8]      abs_p_8_12  -1
    r[8]      abs_m_8_12  1
    r[8]      abs_p_8_13  -1
    r[8]      abs_m_8_13  1
    r[8]      abs_p_8_14  -1
    r[8]      abs_m_8_14  1
    r[8]      abs_p_8_15  -1
    r[8]      abs_m_8_15  1
    r[8]      abs_p_8_16  -1
    r[8]      abs_m_8_16  1
    r[8]      abs_p_8_17  -1
    r[8]      abs_m_8_17  1
    r[8]      abs_p_8_18  -1
    r[8]      abs_m_8_18  1
    r[8]      abs_p_8_19  -1
    r[8]      abs_m_8_19  1
    r[8]      abs_p_8_20  -1
    r[8]      abs_m_8_20  1
    r[8]      abs_p_8_21  -1
    r[8]      abs_m_8_21  1
    r[8]      abs_p_8_22  -1
    r[8]      abs_m_8_22  1
    r[8]      abs_p_8_23  -1
    r[8]      abs_m_8_23  1
    r[8]      abs_p_8_24  -1
    r[8]      abs_m_8_24  1
    r[8]      abs_p_8_25  -1
    r[8]      abs_m_8_25  1
    r[8]      abs_p_8_26  -1
    r[8]      abs_m_8_26  1
    r[8]      abs_p_8_27  -1
    r[8]      abs_m_8_27  1
    r[8]      abs_p_8_28  -1
    r[8]      abs_m_8_28  1
    r[8]      abs_p_8_29  -1
    r[8]      abs_m_8_29  1
    r[8]      abs_p_8_30  -1
    r[8]      abs_m_8_30  1
    r[8]      abs_p_8_31  -1
    r[8]      abs_m_8_31  1
    r[8]      abs_p_8_32  -1
    r[8]      abs_m_8_32  1
    r[8]      abs_p_8_33  -1
    r[8]      abs_m_8_33  1
    r[8]      abs_p_8_34  -1
    r[8]      abs_m_8_34  1
    r[8]      abs_p_8_35  -1
    r[8]      abs_m_8_35  1
    r[9]      normalized_ratio_9  1
    r[9]      normalization  1
    r[9]      abs_p_1_9  1
    r[9]      abs_m_1_9  -1
    r[9]      abs_p_2_9  1
    r[9]      abs_m_2_9  -1
    r[9]      abs_p_3_9  1
    r[9]      abs_m_3_9  -1
    r[9]      abs_p_4_9  1
    r[9]      abs_m_4_9  -1
    r[9]      abs_p_5_9  1
    r[9]      abs_m_5_9  -1
    r[9]      abs_p_6_9  1
    r[9]      abs_m_6_9  -1
    r[9]      abs_p_7_9  1
    r[9]      abs_m_7_9  -1
    r[9]      abs_p_8_9  1
    r[9]      abs_m_8_9  -1
    r[9]      abs_p_9_10  -1
    r[9]      abs_m_9_10  1
    r[9]      abs_p_9_11  -1
    r[9]      abs_m_9_11  1
    r[9]      abs_p_9_12  -1
    r[9]      abs_m_9_12  1
    r[9]      abs_p_9_13  -1
    r[9]      abs_m_9_13  1
    r[9]      abs_p_9_14  -1
    r[9]      abs_m_9_14  1
    r[9]      abs_p_9_15  -1
    r[9]      abs_m_9_15  1
    r[9]      abs_p_9_16  -1
    r[9]      abs_m_9_16  1
    r[9]      abs_p_9_17  -1
    r[9]      abs_m_9_17  1
    r[9]      abs_p_9_18  -1
    r[9]      abs_m_9_18  1
    r[9]      abs_p_9_19  -1
    r[9]      abs_m_9_19  1
    r[9]      abs_p_9_20  -1
    r[9]      abs_m_9_20  1
    r[9]      abs_p_9_21  -1
    r[9]      abs_m_9_21  1
    r[9]      abs_p_9_22  -1
    r[9]      abs_m_9_22  1
    r[9]      abs_p_9_23  -1
    r[9]      abs_m_9_23  1
    r[9]      abs_p_9_24  -1
    r[9]      abs_m_9_24  1
    r[9]      abs_p_9_25  -1
    r[9]      abs_m_9_25  1
    r[9]      abs_p_9_26  -1
    r[9]      abs_m_9_26  1
    r[9]      abs_p_9_27  -1
    r[9]      abs_m_9_27  1
    r[9]      abs_p_9_28  -1
    r[9]      abs_m_9_28  1
    r[9]      abs_p_9_29  -1
    r[9]      abs_m_9_29  1
    r[9]      abs_p_9_30  -1
    r[9]      abs_m_9_30  1
    r[9]      abs_p_9_31  -1
    r[9]      abs_m_9_31  1
    r[9]      abs_p_9_32  -1
    r[9]      abs_m_9_32  1
    r[9]      abs_p_9_33  -1
    r[9]      abs_m_9_33  1
    r[9]      abs_p_9_34  -1
    r[9]      abs_m_9_34  1
    r[9]      abs_p_9_35  -1
    r[9]      abs_m_9_35  1
    r[10]     normalized_ratio_10  1
    r[10]     normalization  1
    r[10]     abs_p_1_10  1
    r[10]     abs_m_1_10  -1
    r[10]     abs_p_2_10  1
    r[10]     abs_m_2_10  -1
    r[10]     abs_p_3_10  1
    r[10]     abs_m_3_10  -1
    r[10]     abs_p_4_10  1
    r[10]     abs_m_4_10  -1
    r[10]     abs_p_5_10  1
    r[10]     abs_m_5_10  -1
    r[10]     abs_p_6_10  1
    r[10]     abs_m_6_10  -1
    r[10]     abs_p_7_10  1
    r[10]     abs_m_7_10  -1
    r[10]     abs_p_8_10  1
    r[10]     abs_m_8_10  -1
    r[10]     abs_p_9_10  1
    r[10]     abs_m_9_10  -1
    r[10]     abs_p_10_11  -1
    r[10]     abs_m_10_11  1
    r[10]     abs_p_10_12  -1
    r[10]     abs_m_10_12  1
    r[10]     abs_p_10_13  -1
    r[10]     abs_m_10_13  1
    r[10]     abs_p_10_14  -1
    r[10]     abs_m_10_14  1
    r[10]     abs_p_10_15  -1
    r[10]     abs_m_10_15  1
    r[10]     abs_p_10_16  -1
    r[10]     abs_m_10_16  1
    r[10]     abs_p_10_17  -1
    r[10]     abs_m_10_17  1
    r[10]     abs_p_10_18  -1
    r[10]     abs_m_10_18  1
    r[10]     abs_p_10_19  -1
    r[10]     abs_m_10_19  1
    r[10]     abs_p_10_20  -1
    r[10]     abs_m_10_20  1
    r[10]     abs_p_10_21  -1
    r[10]     abs_m_10_21  1
    r[10]     abs_p_10_22  -1
    r[10]     abs_m_10_22  1
    r[10]     abs_p_10_23  -1
    r[10]     abs_m_10_23  1
    r[10]     abs_p_10_24  -1
    r[10]     abs_m_10_24  1
    r[10]     abs_p_10_25  -1
    r[10]     abs_m_10_25  1
    r[10]     abs_p_10_26  -1
    r[10]     abs_m_10_26  1
    r[10]     abs_p_10_27  -1
    r[10]     abs_m_10_27  1
    r[10]     abs_p_10_28  -1
    r[10]     abs_m_10_28  1
    r[10]     abs_p_10_29  -1
    r[10]     abs_m_10_29  1
    r[10]     abs_p_10_30  -1
    r[10]     abs_m_10_30  1
    r[10]     abs_p_10_31  -1
    r[10]     abs_m_10_31  1
    r[10]     abs_p_10_32  -1
    r[10]     abs_m_10_32  1
    r[10]     abs_p_10_33  -1
    r[10]     abs_m_10_33  1
    r[10]     abs_p_10_34  -1
    r[10]     abs_m_10_34  1
    r[10]     abs_p_10_35  -1
    r[10]     abs_m_10_35  1
    r[11]     normalized_ratio_11  1
    r[11]     normalization  1
    r[11]     abs_p_1_11  1
    r[11]     abs_m_1_11  -1
    r[11]     abs_p_2_11  1
    r[11]     abs_m_2_11  -1
    r[11]     abs_p_3_11  1
    r[11]     abs_m_3_11  -1
    r[11]     abs_p_4_11  1
    r[11]     abs_m_4_11  -1
    r[11]     abs_p_5_11  1
    r[11]     abs_m_5_11  -1
    r[11]     abs_p_6_11  1
    r[11]     abs_m_6_11  -1
    r[11]     abs_p_7_11  1
    r[11]     abs_m_7_11  -1
    r[11]     abs_p_8_11  1
    r[11]     abs_m_8_11  -1
    r[11]     abs_p_9_11  1
    r[11]     abs_m_9_11  -1
    r[11]     abs_p_10_11  1
    r[11]     abs_m_10_11  -1
    r[11]     abs_p_11_12  -1
    r[11]     abs_m_11_12  1
    r[11]     abs_p_11_13  -1
    r[11]     abs_m_11_13  1
    r[11]     abs_p_11_14  -1
    r[11]     abs_m_11_14  1
    r[11]     abs_p_11_15  -1
    r[11]     abs_m_11_15  1
    r[11]     abs_p_11_16  -1
    r[11]     abs_m_11_16  1
    r[11]     abs_p_11_17  -1
    r[11]     abs_m_11_17  1
    r[11]     abs_p_11_18  -1
    r[11]     abs_m_11_18  1
    r[11]     abs_p_11_19  -1
    r[11]     abs_m_11_19  1
    r[11]     abs_p_11_20  -1
    r[11]     abs_m_11_20  1
    r[11]     abs_p_11_21  -1
    r[11]     abs_m_11_21  1
    r[11]     abs_p_11_22  -1
    r[11]     abs_m_11_22  1
    r[11]     abs_p_11_23  -1
    r[11]     abs_m_11_23  1
    r[11]     abs_p_11_24  -1
    r[11]     abs_m_11_24  1
    r[11]     abs_p_11_25  -1
    r[11]     abs_m_11_25  1
    r[11]     abs_p_11_26  -1
    r[11]     abs_m_11_26  1
    r[11]     abs_p_11_27  -1
    r[11]     abs_m_11_27  1
    r[11]     abs_p_11_28  -1
    r[11]     abs_m_11_28  1
    r[11]     abs_p_11_29  -1
    r[11]     abs_m_11_29  1
    r[11]     abs_p_11_30  -1
    r[11]     abs_m_11_30  1
    r[11]     abs_p_11_31  -1
    r[11]     abs_m_11_31  1
    r[11]     abs_p_11_32  -1
    r[11]     abs_m_11_32  1
    r[11]     abs_p_11_33  -1
    r[11]     abs_m_11_33  1
    r[11]     abs_p_11_34  -1
    r[11]     abs_m_11_34  1
    r[11]     abs_p_11_35  -1
    r[11]     abs_m_11_35  1
    r[12]     normalized_ratio_12  1
    r[12]     normalization  1
    r[12]     abs_p_1_12  1
    r[12]     abs_m_1_12  -1
    r[12]     abs_p_2_12  1
    r[12]     abs_m_2_12  -1
    r[12]     abs_p_3_12  1
    r[12]     abs_m_3_12  -1
    r[12]     abs_p_4_12  1
    r[12]     abs_m_4_12  -1
    r[12]     abs_p_5_12  1
    r[12]     abs_m_5_12  -1
    r[12]     abs_p_6_12  1
    r[12]     abs_m_6_12  -1
    r[12]     abs_p_7_12  1
    r[12]     abs_m_7_12  -1
    r[12]     abs_p_8_12  1
    r[12]     abs_m_8_12  -1
    r[12]     abs_p_9_12  1
    r[12]     abs_m_9_12  -1
    r[12]     abs_p_10_12  1
    r[12]     abs_m_10_12  -1
    r[12]     abs_p_11_12  1
    r[12]     abs_m_11_12  -1
    r[12]     abs_p_12_13  -1
    r[12]     abs_m_12_13  1
    r[12]     abs_p_12_14  -1
    r[12]     abs_m_12_14  1
    r[12]     abs_p_12_15  -1
    r[12]     abs_m_12_15  1
    r[12]     abs_p_12_16  -1
    r[12]     abs_m_12_16  1
    r[12]     abs_p_12_17  -1
    r[12]     abs_m_12_17  1
    r[12]     abs_p_12_18  -1
    r[12]     abs_m_12_18  1
    r[12]     abs_p_12_19  -1
    r[12]     abs_m_12_19  1
    r[12]     abs_p_12_20  -1
    r[12]     abs_m_12_20  1
    r[12]     abs_p_12_21  -1
    r[12]     abs_m_12_21  1
    r[12]     abs_p_12_22  -1
    r[12]     abs_m_12_22  1
    r[12]     abs_p_12_23  -1
    r[12]     abs_m_12_23  1
    r[12]     abs_p_12_24  -1
    r[12]     abs_m_12_24  1
    r[12]     abs_p_12_25  -1
    r[12]     abs_m_12_25  1
    r[12]     abs_p_12_26  -1
    r[12]     abs_m_12_26  1
    r[12]     abs_p_12_27  -1
    r[12]     abs_m_12_27  1
    r[12]     abs_p_12_28  -1
    r[12]     abs_m_12_28  1
    r[12]     abs_p_12_29  -1
    r[12]     abs_m_12_29  1
    r[12]     abs_p_12_30  -1
    r[12]     abs_m_12_30  1
    r[12]     abs_p_12_31  -1
    r[12]     abs_m_12_31  1
    r[12]     abs_p_12_32  -1
    r[12]     abs_m_12_32  1
    r[12]     abs_p_12_33  -1
    r[12]     abs_m_12_33  1
    r[12]     abs_p_12_34  -1
    r[12]     abs_m_12_34  1
    r[12]     abs_p_12_35  -1
    r[12]     abs_m_12_35  1
    r[13]     normalized_ratio_13  1
    r[13]     normalization  1
    r[13]     abs_p_1_13  1
    r[13]     abs_m_1_13  -1
    r[13]     abs_p_2_13  1
    r[13]     abs_m_2_13  -1
    r[13]     abs_p_3_13  1
    r[13]     abs_m_3_13  -1
    r[13]     abs_p_4_13  1
    r[13]     abs_m_4_13  -1
    r[13]     abs_p_5_13  1
    r[13]     abs_m_5_13  -1
    r[13]     abs_p_6_13  1
    r[13]     abs_m_6_13  -1
    r[13]     abs_p_7_13  1
    r[13]     abs_m_7_13  -1
    r[13]     abs_p_8_13  1
    r[13]     abs_m_8_13  -1
    r[13]     abs_p_9_13  1
    r[13]     abs_m_9_13  -1
    r[13]     abs_p_10_13  1
    r[13]     abs_m_10_13  -1
    r[13]     abs_p_11_13  1
    r[13]     abs_m_11_13  -1
    r[13]     abs_p_12_13  1
    r[13]     abs_m_12_13  -1
    r[13]     abs_p_13_14  -1
    r[13]     abs_m_13_14  1
    r[13]     abs_p_13_15  -1
    r[13]     abs_m_13_15  1
    r[13]     abs_p_13_16  -1
    r[13]     abs_m_13_16  1
    r[13]     abs_p_13_17  -1
    r[13]     abs_m_13_17  1
    r[13]     abs_p_13_18  -1
    r[13]     abs_m_13_18  1
    r[13]     abs_p_13_19  -1
    r[13]     abs_m_13_19  1
    r[13]     abs_p_13_20  -1
    r[13]     abs_m_13_20  1
    r[13]     abs_p_13_21  -1
    r[13]     abs_m_13_21  1
    r[13]     abs_p_13_22  -1
    r[13]     abs_m_13_22  1
    r[13]     abs_p_13_23  -1
    r[13]     abs_m_13_23  1
    r[13]     abs_p_13_24  -1
    r[13]     abs_m_13_24  1
    r[13]     abs_p_13_25  -1
    r[13]     abs_m_13_25  1
    r[13]     abs_p_13_26  -1
    r[13]     abs_m_13_26  1
    r[13]     abs_p_13_27  -1
    r[13]     abs_m_13_27  1
    r[13]     abs_p_13_28  -1
    r[13]     abs_m_13_28  1
    r[13]     abs_p_13_29  -1
    r[13]     abs_m_13_29  1
    r[13]     abs_p_13_30  -1
    r[13]     abs_m_13_30  1
    r[13]     abs_p_13_31  -1
    r[13]     abs_m_13_31  1
    r[13]     abs_p_13_32  -1
    r[13]     abs_m_13_32  1
    r[13]     abs_p_13_33  -1
    r[13]     abs_m_13_33  1
    r[13]     abs_p_13_34  -1
    r[13]     abs_m_13_34  1
    r[13]     abs_p_13_35  -1
    r[13]     abs_m_13_35  1
    r[14]     normalized_ratio_14  1
    r[14]     normalization  1
    r[14]     abs_p_1_14  1
    r[14]     abs_m_1_14  -1
    r[14]     abs_p_2_14  1
    r[14]     abs_m_2_14  -1
    r[14]     abs_p_3_14  1
    r[14]     abs_m_3_14  -1
    r[14]     abs_p_4_14  1
    r[14]     abs_m_4_14  -1
    r[14]     abs_p_5_14  1
    r[14]     abs_m_5_14  -1
    r[14]     abs_p_6_14  1
    r[14]     abs_m_6_14  -1
    r[14]     abs_p_7_14  1
    r[14]     abs_m_7_14  -1
    r[14]     abs_p_8_14  1
    r[14]     abs_m_8_14  -1
    r[14]     abs_p_9_14  1
    r[14]     abs_m_9_14  -1
    r[14]     abs_p_10_14  1
    r[14]     abs_m_10_14  -1
    r[14]     abs_p_11_14  1
    r[14]     abs_m_11_14  -1
    r[14]     abs_p_12_14  1
    r[14]     abs_m_12_14  -1
    r[14]     abs_p_13_14  1
    r[14]     abs_m_13_14  -1
    r[14]     abs_p_14_15  -1
    r[14]     abs_m_14_15  1
    r[14]     abs_p_14_16  -1
    r[14]     abs_m_14_16  1
    r[14]     abs_p_14_17  -1
    r[14]     abs_m_14_17  1
    r[14]     abs_p_14_18  -1
    r[14]     abs_m_14_18  1
    r[14]     abs_p_14_19  -1
    r[14]     abs_m_14_19  1
    r[14]     abs_p_14_20  -1
    r[14]     abs_m_14_20  1
    r[14]     abs_p_14_21  -1
    r[14]     abs_m_14_21  1
    r[14]     abs_p_14_22  -1
    r[14]     abs_m_14_22  1
    r[14]     abs_p_14_23  -1
    r[14]     abs_m_14_23  1
    r[14]     abs_p_14_24  -1
    r[14]     abs_m_14_24  1
    r[14]     abs_p_14_25  -1
    r[14]     abs_m_14_25  1
    r[14]     abs_p_14_26  -1
    r[14]     abs_m_14_26  1
    r[14]     abs_p_14_27  -1
    r[14]     abs_m_14_27  1
    r[14]     abs_p_14_28  -1
    r[14]     abs_m_14_28  1
    r[14]     abs_p_14_29  -1
    r[14]     abs_m_14_29  1
    r[14]     abs_p_14_30  -1
    r[14]     abs_m_14_30  1
    r[14]     abs_p_14_31  -1
    r[14]     abs_m_14_31  1
    r[14]     abs_p_14_32  -1
    r[14]     abs_m_14_32  1
    r[14]     abs_p_14_33  -1
    r[14]     abs_m_14_33  1
    r[14]     abs_p_14_34  -1
    r[14]     abs_m_14_34  1
    r[14]     abs_p_14_35  -1
    r[14]     abs_m_14_35  1
    r[15]     normalized_ratio_15  1
    r[15]     normalization  1
    r[15]     abs_p_1_15  1
    r[15]     abs_m_1_15  -1
    r[15]     abs_p_2_15  1
    r[15]     abs_m_2_15  -1
    r[15]     abs_p_3_15  1
    r[15]     abs_m_3_15  -1
    r[15]     abs_p_4_15  1
    r[15]     abs_m_4_15  -1
    r[15]     abs_p_5_15  1
    r[15]     abs_m_5_15  -1
    r[15]     abs_p_6_15  1
    r[15]     abs_m_6_15  -1
    r[15]     abs_p_7_15  1
    r[15]     abs_m_7_15  -1
    r[15]     abs_p_8_15  1
    r[15]     abs_m_8_15  -1
    r[15]     abs_p_9_15  1
    r[15]     abs_m_9_15  -1
    r[15]     abs_p_10_15  1
    r[15]     abs_m_10_15  -1
    r[15]     abs_p_11_15  1
    r[15]     abs_m_11_15  -1
    r[15]     abs_p_12_15  1
    r[15]     abs_m_12_15  -1
    r[15]     abs_p_13_15  1
    r[15]     abs_m_13_15  -1
    r[15]     abs_p_14_15  1
    r[15]     abs_m_14_15  -1
    r[15]     abs_p_15_16  -1
    r[15]     abs_m_15_16  1
    r[15]     abs_p_15_17  -1
    r[15]     abs_m_15_17  1
    r[15]     abs_p_15_18  -1
    r[15]     abs_m_15_18  1
    r[15]     abs_p_15_19  -1
    r[15]     abs_m_15_19  1
    r[15]     abs_p_15_20  -1
    r[15]     abs_m_15_20  1
    r[15]     abs_p_15_21  -1
    r[15]     abs_m_15_21  1
    r[15]     abs_p_15_22  -1
    r[15]     abs_m_15_22  1
    r[15]     abs_p_15_23  -1
    r[15]     abs_m_15_23  1
    r[15]     abs_p_15_24  -1
    r[15]     abs_m_15_24  1
    r[15]     abs_p_15_25  -1
    r[15]     abs_m_15_25  1
    r[15]     abs_p_15_26  -1
    r[15]     abs_m_15_26  1
    r[15]     abs_p_15_27  -1
    r[15]     abs_m_15_27  1
    r[15]     abs_p_15_28  -1
    r[15]     abs_m_15_28  1
    r[15]     abs_p_15_29  -1
    r[15]     abs_m_15_29  1
    r[15]     abs_p_15_30  -1
    r[15]     abs_m_15_30  1
    r[15]     abs_p_15_31  -1
    r[15]     abs_m_15_31  1
    r[15]     abs_p_15_32  -1
    r[15]     abs_m_15_32  1
    r[15]     abs_p_15_33  -1
    r[15]     abs_m_15_33  1
    r[15]     abs_p_15_34  -1
    r[15]     abs_m_15_34  1
    r[15]     abs_p_15_35  -1
    r[15]     abs_m_15_35  1
    r[16]     normalized_ratio_16  1
    r[16]     normalization  1
    r[16]     abs_p_1_16  1
    r[16]     abs_m_1_16  -1
    r[16]     abs_p_2_16  1
    r[16]     abs_m_2_16  -1
    r[16]     abs_p_3_16  1
    r[16]     abs_m_3_16  -1
    r[16]     abs_p_4_16  1
    r[16]     abs_m_4_16  -1
    r[16]     abs_p_5_16  1
    r[16]     abs_m_5_16  -1
    r[16]     abs_p_6_16  1
    r[16]     abs_m_6_16  -1
    r[16]     abs_p_7_16  1
    r[16]     abs_m_7_16  -1
    r[16]     abs_p_8_16  1
    r[16]     abs_m_8_16  -1
    r[16]     abs_p_9_16  1
    r[16]     abs_m_9_16  -1
    r[16]     abs_p_10_16  1
    r[16]     abs_m_10_16  -1
    r[16]     abs_p_11_16  1
    r[16]     abs_m_11_16  -1
    r[16]     abs_p_12_16  1
    r[16]     abs_m_12_16  -1
    r[16]     abs_p_13_16  1
    r[16]     abs_m_13_16  -1
    r[16]     abs_p_14_16  1
    r[16]     abs_m_14_16  -1
    r[16]     abs_p_15_16  1
    r[16]     abs_m_15_16  -1
    r[16]     abs_p_16_17  -1
    r[16]     abs_m_16_17  1
    r[16]     abs_p_16_18  -1
    r[16]     abs_m_16_18  1
    r[16]     abs_p_16_19  -1
    r[16]     abs_m_16_19  1
    r[16]     abs_p_16_20  -1
    r[16]     abs_m_16_20  1
    r[16]     abs_p_16_21  -1
    r[16]     abs_m_16_21  1
    r[16]     abs_p_16_22  -1
    r[16]     abs_m_16_22  1
    r[16]     abs_p_16_23  -1
    r[16]     abs_m_16_23  1
    r[16]     abs_p_16_24  -1
    r[16]     abs_m_16_24  1
    r[16]     abs_p_16_25  -1
    r[16]     abs_m_16_25  1
    r[16]     abs_p_16_26  -1
    r[16]     abs_m_16_26  1
    r[16]     abs_p_16_27  -1
    r[16]     abs_m_16_27  1
    r[16]     abs_p_16_28  -1
    r[16]     abs_m_16_28  1
    r[16]     abs_p_16_29  -1
    r[16]     abs_m_16_29  1
    r[16]     abs_p_16_30  -1
    r[16]     abs_m_16_30  1
    r[16]     abs_p_16_31  -1
    r[16]     abs_m_16_31  1
    r[16]     abs_p_16_32  -1
    r[16]     abs_m_16_32  1
    r[16]     abs_p_16_33  -1
    r[16]     abs_m_16_33  1
    r[16]     abs_p_16_34  -1
    r[16]     abs_m_16_34  1
    r[16]     abs_p_16_35  -1
    r[16]     abs_m_16_35  1
    r[17]     normalized_ratio_17  1
    r[17]     normalization  1
    r[17]     abs_p_1_17  1
    r[17]     abs_m_1_17  -1
    r[17]     abs_p_2_17  1
    r[17]     abs_m_2_17  -1
    r[17]     abs_p_3_17  1
    r[17]     abs_m_3_17  -1
    r[17]     abs_p_4_17  1
    r[17]     abs_m_4_17  -1
    r[17]     abs_p_5_17  1
    r[17]     abs_m_5_17  -1
    r[17]     abs_p_6_17  1
    r[17]     abs_m_6_17  -1
    r[17]     abs_p_7_17  1
    r[17]     abs_m_7_17  -1
    r[17]     abs_p_8_17  1
    r[17]     abs_m_8_17  -1
    r[17]     abs_p_9_17  1
    r[17]     abs_m_9_17  -1
    r[17]     abs_p_10_17  1
    r[17]     abs_m_10_17  -1
    r[17]     abs_p_11_17  1
    r[17]     abs_m_11_17  -1
    r[17]     abs_p_12_17  1
    r[17]     abs_m_12_17  -1
    r[17]     abs_p_13_17  1
    r[17]     abs_m_13_17  -1
    r[17]     abs_p_14_17  1
    r[17]     abs_m_14_17  -1
    r[17]     abs_p_15_17  1
    r[17]     abs_m_15_17  -1
    r[17]     abs_p_16_17  1
    r[17]     abs_m_16_17  -1
    r[17]     abs_p_17_18  -1
    r[17]     abs_m_17_18  1
    r[17]     abs_p_17_19  -1
    r[17]     abs_m_17_19  1
    r[17]     abs_p_17_20  -1
    r[17]     abs_m_17_20  1
    r[17]     abs_p_17_21  -1
    r[17]     abs_m_17_21  1
    r[17]     abs_p_17_22  -1
    r[17]     abs_m_17_22  1
    r[17]     abs_p_17_23  -1
    r[17]     abs_m_17_23  1
    r[17]     abs_p_17_24  -1
    r[17]     abs_m_17_24  1
    r[17]     abs_p_17_25  -1
    r[17]     abs_m_17_25  1
    r[17]     abs_p_17_26  -1
    r[17]     abs_m_17_26  1
    r[17]     abs_p_17_27  -1
    r[17]     abs_m_17_27  1
    r[17]     abs_p_17_28  -1
    r[17]     abs_m_17_28  1
    r[17]     abs_p_17_29  -1
    r[17]     abs_m_17_29  1
    r[17]     abs_p_17_30  -1
    r[17]     abs_m_17_30  1
    r[17]     abs_p_17_31  -1
    r[17]     abs_m_17_31  1
    r[17]     abs_p_17_32  -1
    r[17]     abs_m_17_32  1
    r[17]     abs_p_17_33  -1
    r[17]     abs_m_17_33  1
    r[17]     abs_p_17_34  -1
    r[17]     abs_m_17_34  1
    r[17]     abs_p_17_35  -1
    r[17]     abs_m_17_35  1
    r[18]     normalized_ratio_18  1
    r[18]     normalization  1
    r[18]     abs_p_1_18  1
    r[18]     abs_m_1_18  -1
    r[18]     abs_p_2_18  1
    r[18]     abs_m_2_18  -1
    r[18]     abs_p_3_18  1
    r[18]     abs_m_3_18  -1
    r[18]     abs_p_4_18  1
    r[18]     abs_m_4_18  -1
    r[18]     abs_p_5_18  1
    r[18]     abs_m_5_18  -1
    r[18]     abs_p_6_18  1
    r[18]     abs_m_6_18  -1
    r[18]     abs_p_7_18  1
    r[18]     abs_m_7_18  -1
    r[18]     abs_p_8_18  1
    r[18]     abs_m_8_18  -1
    r[18]     abs_p_9_18  1
    r[18]     abs_m_9_18  -1
    r[18]     abs_p_10_18  1
    r[18]     abs_m_10_18  -1
    r[18]     abs_p_11_18  1
    r[18]     abs_m_11_18  -1
    r[18]     abs_p_12_18  1
    r[18]     abs_m_12_18  -1
    r[18]     abs_p_13_18  1
    r[18]     abs_m_13_18  -1
    r[18]     abs_p_14_18  1
    r[18]     abs_m_14_18  -1
    r[18]     abs_p_15_18  1
    r[18]     abs_m_15_18  -1
    r[18]     abs_p_16_18  1
    r[18]     abs_m_16_18  -1
    r[18]     abs_p_17_18  1
    r[18]     abs_m_17_18  -1
    r[18]     abs_p_18_19  -1
    r[18]     abs_m_18_19  1
    r[18]     abs_p_18_20  -1
    r[18]     abs_m_18_20  1
    r[18]     abs_p_18_21  -1
    r[18]     abs_m_18_21  1
    r[18]     abs_p_18_22  -1
    r[18]     abs_m_18_22  1
    r[18]     abs_p_18_23  -1
    r[18]     abs_m_18_23  1
    r[18]     abs_p_18_24  -1
    r[18]     abs_m_18_24  1
    r[18]     abs_p_18_25  -1
    r[18]     abs_m_18_25  1
    r[18]     abs_p_18_26  -1
    r[18]     abs_m_18_26  1
    r[18]     abs_p_18_27  -1
    r[18]     abs_m_18_27  1
    r[18]     abs_p_18_28  -1
    r[18]     abs_m_18_28  1
    r[18]     abs_p_18_29  -1
    r[18]     abs_m_18_29  1
    r[18]     abs_p_18_30  -1
    r[18]     abs_m_18_30  1
    r[18]     abs_p_18_31  -1
    r[18]     abs_m_18_31  1
    r[18]     abs_p_18_32  -1
    r[18]     abs_m_18_32  1
    r[18]     abs_p_18_33  -1
    r[18]     abs_m_18_33  1
    r[18]     abs_p_18_34  -1
    r[18]     abs_m_18_34  1
    r[18]     abs_p_18_35  -1
    r[18]     abs_m_18_35  1
    r[19]     normalized_ratio_19  1
    r[19]     normalization  1
    r[19]     abs_p_1_19  1
    r[19]     abs_m_1_19  -1
    r[19]     abs_p_2_19  1
    r[19]     abs_m_2_19  -1
    r[19]     abs_p_3_19  1
    r[19]     abs_m_3_19  -1
    r[19]     abs_p_4_19  1
    r[19]     abs_m_4_19  -1
    r[19]     abs_p_5_19  1
    r[19]     abs_m_5_19  -1
    r[19]     abs_p_6_19  1
    r[19]     abs_m_6_19  -1
    r[19]     abs_p_7_19  1
    r[19]     abs_m_7_19  -1
    r[19]     abs_p_8_19  1
    r[19]     abs_m_8_19  -1
    r[19]     abs_p_9_19  1
    r[19]     abs_m_9_19  -1
    r[19]     abs_p_10_19  1
    r[19]     abs_m_10_19  -1
    r[19]     abs_p_11_19  1
    r[19]     abs_m_11_19  -1
    r[19]     abs_p_12_19  1
    r[19]     abs_m_12_19  -1
    r[19]     abs_p_13_19  1
    r[19]     abs_m_13_19  -1
    r[19]     abs_p_14_19  1
    r[19]     abs_m_14_19  -1
    r[19]     abs_p_15_19  1
    r[19]     abs_m_15_19  -1
    r[19]     abs_p_16_19  1
    r[19]     abs_m_16_19  -1
    r[19]     abs_p_17_19  1
    r[19]     abs_m_17_19  -1
    r[19]     abs_p_18_19  1
    r[19]     abs_m_18_19  -1
    r[19]     abs_p_19_20  -1
    r[19]     abs_m_19_20  1
    r[19]     abs_p_19_21  -1
    r[19]     abs_m_19_21  1
    r[19]     abs_p_19_22  -1
    r[19]     abs_m_19_22  1
    r[19]     abs_p_19_23  -1
    r[19]     abs_m_19_23  1
    r[19]     abs_p_19_24  -1
    r[19]     abs_m_19_24  1
    r[19]     abs_p_19_25  -1
    r[19]     abs_m_19_25  1
    r[19]     abs_p_19_26  -1
    r[19]     abs_m_19_26  1
    r[19]     abs_p_19_27  -1
    r[19]     abs_m_19_27  1
    r[19]     abs_p_19_28  -1
    r[19]     abs_m_19_28  1
    r[19]     abs_p_19_29  -1
    r[19]     abs_m_19_29  1
    r[19]     abs_p_19_30  -1
    r[19]     abs_m_19_30  1
    r[19]     abs_p_19_31  -1
    r[19]     abs_m_19_31  1
    r[19]     abs_p_19_32  -1
    r[19]     abs_m_19_32  1
    r[19]     abs_p_19_33  -1
    r[19]     abs_m_19_33  1
    r[19]     abs_p_19_34  -1
    r[19]     abs_m_19_34  1
    r[19]     abs_p_19_35  -1
    r[19]     abs_m_19_35  1
    r[20]     normalized_ratio_20  1
    r[20]     normalization  1
    r[20]     abs_p_1_20  1
    r[20]     abs_m_1_20  -1
    r[20]     abs_p_2_20  1
    r[20]     abs_m_2_20  -1
    r[20]     abs_p_3_20  1
    r[20]     abs_m_3_20  -1
    r[20]     abs_p_4_20  1
    r[20]     abs_m_4_20  -1
    r[20]     abs_p_5_20  1
    r[20]     abs_m_5_20  -1
    r[20]     abs_p_6_20  1
    r[20]     abs_m_6_20  -1
    r[20]     abs_p_7_20  1
    r[20]     abs_m_7_20  -1
    r[20]     abs_p_8_20  1
    r[20]     abs_m_8_20  -1
    r[20]     abs_p_9_20  1
    r[20]     abs_m_9_20  -1
    r[20]     abs_p_10_20  1
    r[20]     abs_m_10_20  -1
    r[20]     abs_p_11_20  1
    r[20]     abs_m_11_20  -1
    r[20]     abs_p_12_20  1
    r[20]     abs_m_12_20  -1
    r[20]     abs_p_13_20  1
    r[20]     abs_m_13_20  -1
    r[20]     abs_p_14_20  1
    r[20]     abs_m_14_20  -1
    r[20]     abs_p_15_20  1
    r[20]     abs_m_15_20  -1
    r[20]     abs_p_16_20  1
    r[20]     abs_m_16_20  -1
    r[20]     abs_p_17_20  1
    r[20]     abs_m_17_20  -1
    r[20]     abs_p_18_20  1
    r[20]     abs_m_18_20  -1
    r[20]     abs_p_19_20  1
    r[20]     abs_m_19_20  -1
    r[20]     abs_p_20_21  -1
    r[20]     abs_m_20_21  1
    r[20]     abs_p_20_22  -1
    r[20]     abs_m_20_22  1
    r[20]     abs_p_20_23  -1
    r[20]     abs_m_20_23  1
    r[20]     abs_p_20_24  -1
    r[20]     abs_m_20_24  1
    r[20]     abs_p_20_25  -1
    r[20]     abs_m_20_25  1
    r[20]     abs_p_20_26  -1
    r[20]     abs_m_20_26  1
    r[20]     abs_p_20_27  -1
    r[20]     abs_m_20_27  1
    r[20]     abs_p_20_28  -1
    r[20]     abs_m_20_28  1
    r[20]     abs_p_20_29  -1
    r[20]     abs_m_20_29  1
    r[20]     abs_p_20_30  -1
    r[20]     abs_m_20_30  1
    r[20]     abs_p_20_31  -1
    r[20]     abs_m_20_31  1
    r[20]     abs_p_20_32  -1
    r[20]     abs_m_20_32  1
    r[20]     abs_p_20_33  -1
    r[20]     abs_m_20_33  1
    r[20]     abs_p_20_34  -1
    r[20]     abs_m_20_34  1
    r[20]     abs_p_20_35  -1
    r[20]     abs_m_20_35  1
    r[21]     normalized_ratio_21  1
    r[21]     normalization  1
    r[21]     abs_p_1_21  1
    r[21]     abs_m_1_21  -1
    r[21]     abs_p_2_21  1
    r[21]     abs_m_2_21  -1
    r[21]     abs_p_3_21  1
    r[21]     abs_m_3_21  -1
    r[21]     abs_p_4_21  1
    r[21]     abs_m_4_21  -1
    r[21]     abs_p_5_21  1
    r[21]     abs_m_5_21  -1
    r[21]     abs_p_6_21  1
    r[21]     abs_m_6_21  -1
    r[21]     abs_p_7_21  1
    r[21]     abs_m_7_21  -1
    r[21]     abs_p_8_21  1
    r[21]     abs_m_8_21  -1
    r[21]     abs_p_9_21  1
    r[21]     abs_m_9_21  -1
    r[21]     abs_p_10_21  1
    r[21]     abs_m_10_21  -1
    r[21]     abs_p_11_21  1
    r[21]     abs_m_11_21  -1
    r[21]     abs_p_12_21  1
    r[21]     abs_m_12_21  -1
    r[21]     abs_p_13_21  1
    r[21]     abs_m_13_21  -1
    r[21]     abs_p_14_21  1
    r[21]     abs_m_14_21  -1
    r[21]     abs_p_15_21  1
    r[21]     abs_m_15_21  -1
    r[21]     abs_p_16_21  1
    r[21]     abs_m_16_21  -1
    r[21]     abs_p_17_21  1
    r[21]     abs_m_17_21  -1
    r[21]     abs_p_18_21  1
    r[21]     abs_m_18_21  -1
    r[21]     abs_p_19_21  1
    r[21]     abs_m_19_21  -1
    r[21]     abs_p_20_21  1
    r[21]     abs_m_20_21  -1
    r[21]     abs_p_21_22  -1
    r[21]     abs_m_21_22  1
    r[21]     abs_p_21_23  -1
    r[21]     abs_m_21_23  1
    r[21]     abs_p_21_24  -1
    r[21]     abs_m_21_24  1
    r[21]     abs_p_21_25  -1
    r[21]     abs_m_21_25  1
    r[21]     abs_p_21_26  -1
    r[21]     abs_m_21_26  1
    r[21]     abs_p_21_27  -1
    r[21]     abs_m_21_27  1
    r[21]     abs_p_21_28  -1
    r[21]     abs_m_21_28  1
    r[21]     abs_p_21_29  -1
    r[21]     abs_m_21_29  1
    r[21]     abs_p_21_30  -1
    r[21]     abs_m_21_30  1
    r[21]     abs_p_21_31  -1
    r[21]     abs_m_21_31  1
    r[21]     abs_p_21_32  -1
    r[21]     abs_m_21_32  1
    r[21]     abs_p_21_33  -1
    r[21]     abs_m_21_33  1
    r[21]     abs_p_21_34  -1
    r[21]     abs_m_21_34  1
    r[21]     abs_p_21_35  -1
    r[21]     abs_m_21_35  1
    r[22]     normalized_ratio_22  1
    r[22]     normalization  1
    r[22]     abs_p_1_22  1
    r[22]     abs_m_1_22  -1
    r[22]     abs_p_2_22  1
    r[22]     abs_m_2_22  -1
    r[22]     abs_p_3_22  1
    r[22]     abs_m_3_22  -1
    r[22]     abs_p_4_22  1
    r[22]     abs_m_4_22  -1
    r[22]     abs_p_5_22  1
    r[22]     abs_m_5_22  -1
    r[22]     abs_p_6_22  1
    r[22]     abs_m_6_22  -1
    r[22]     abs_p_7_22  1
    r[22]     abs_m_7_22  -1
    r[22]     abs_p_8_22  1
    r[22]     abs_m_8_22  -1
    r[22]     abs_p_9_22  1
    r[22]     abs_m_9_22  -1
    r[22]     abs_p_10_22  1
    r[22]     abs_m_10_22  -1
    r[22]     abs_p_11_22  1
    r[22]     abs_m_11_22  -1
    r[22]     abs_p_12_22  1
    r[22]     abs_m_12_22  -1
    r[22]     abs_p_13_22  1
    r[22]     abs_m_13_22  -1
    r[22]     abs_p_14_22  1
    r[22]     abs_m_14_22  -1
    r[22]     abs_p_15_22  1
    r[22]     abs_m_15_22  -1
    r[22]     abs_p_16_22  1
    r[22]     abs_m_16_22  -1
    r[22]     abs_p_17_22  1
    r[22]     abs_m_17_22  -1
    r[22]     abs_p_18_22  1
    r[22]     abs_m_18_22  -1
    r[22]     abs_p_19_22  1
    r[22]     abs_m_19_22  -1
    r[22]     abs_p_20_22  1
    r[22]     abs_m_20_22  -1
    r[22]     abs_p_21_22  1
    r[22]     abs_m_21_22  -1
    r[22]     abs_p_22_23  -1
    r[22]     abs_m_22_23  1
    r[22]     abs_p_22_24  -1
    r[22]     abs_m_22_24  1
    r[22]     abs_p_22_25  -1
    r[22]     abs_m_22_25  1
    r[22]     abs_p_22_26  -1
    r[22]     abs_m_22_26  1
    r[22]     abs_p_22_27  -1
    r[22]     abs_m_22_27  1
    r[22]     abs_p_22_28  -1
    r[22]     abs_m_22_28  1
    r[22]     abs_p_22_29  -1
    r[22]     abs_m_22_29  1
    r[22]     abs_p_22_30  -1
    r[22]     abs_m_22_30  1
    r[22]     abs_p_22_31  -1
    r[22]     abs_m_22_31  1
    r[22]     abs_p_22_32  -1
    r[22]     abs_m_22_32  1
    r[22]     abs_p_22_33  -1
    r[22]     abs_m_22_33  1
    r[22]     abs_p_22_34  -1
    r[22]     abs_m_22_34  1
    r[22]     abs_p_22_35  -1
    r[22]     abs_m_22_35  1
    r[23]     normalized_ratio_23  1
    r[23]     normalization  1
    r[23]     abs_p_1_23  1
    r[23]     abs_m_1_23  -1
    r[23]     abs_p_2_23  1
    r[23]     abs_m_2_23  -1
    r[23]     abs_p_3_23  1
    r[23]     abs_m_3_23  -1
    r[23]     abs_p_4_23  1
    r[23]     abs_m_4_23  -1
    r[23]     abs_p_5_23  1
    r[23]     abs_m_5_23  -1
    r[23]     abs_p_6_23  1
    r[23]     abs_m_6_23  -1
    r[23]     abs_p_7_23  1
    r[23]     abs_m_7_23  -1
    r[23]     abs_p_8_23  1
    r[23]     abs_m_8_23  -1
    r[23]     abs_p_9_23  1
    r[23]     abs_m_9_23  -1
    r[23]     abs_p_10_23  1
    r[23]     abs_m_10_23  -1
    r[23]     abs_p_11_23  1
    r[23]     abs_m_11_23  -1
    r[23]     abs_p_12_23  1
    r[23]     abs_m_12_23  -1
    r[23]     abs_p_13_23  1
    r[23]     abs_m_13_23  -1
    r[23]     abs_p_14_23  1
    r[23]     abs_m_14_23  -1
    r[23]     abs_p_15_23  1
    r[23]     abs_m_15_23  -1
    r[23]     abs_p_16_23  1
    r[23]     abs_m_16_23  -1
    r[23]     abs_p_17_23  1
    r[23]     abs_m_17_23  -1
    r[23]     abs_p_18_23  1
    r[23]     abs_m_18_23  -1
    r[23]     abs_p_19_23  1
    r[23]     abs_m_19_23  -1
    r[23]     abs_p_20_23  1
    r[23]     abs_m_20_23  -1
    r[23]     abs_p_21_23  1
    r[23]     abs_m_21_23  -1
    r[23]     abs_p_22_23  1
    r[23]     abs_m_22_23  -1
    r[23]     abs_p_23_24  -1
    r[23]     abs_m_23_24  1
    r[23]     abs_p_23_25  -1
    r[23]     abs_m_23_25  1
    r[23]     abs_p_23_26  -1
    r[23]     abs_m_23_26  1
    r[23]     abs_p_23_27  -1
    r[23]     abs_m_23_27  1
    r[23]     abs_p_23_28  -1
    r[23]     abs_m_23_28  1
    r[23]     abs_p_23_29  -1
    r[23]     abs_m_23_29  1
    r[23]     abs_p_23_30  -1
    r[23]     abs_m_23_30  1
    r[23]     abs_p_23_31  -1
    r[23]     abs_m_23_31  1
    r[23]     abs_p_23_32  -1
    r[23]     abs_m_23_32  1
    r[23]     abs_p_23_33  -1
    r[23]     abs_m_23_33  1
    r[23]     abs_p_23_34  -1
    r[23]     abs_m_23_34  1
    r[23]     abs_p_23_35  -1
    r[23]     abs_m_23_35  1
    r[24]     normalized_ratio_24  1
    r[24]     normalization  1
    r[24]     abs_p_1_24  1
    r[24]     abs_m_1_24  -1
    r[24]     abs_p_2_24  1
    r[24]     abs_m_2_24  -1
    r[24]     abs_p_3_24  1
    r[24]     abs_m_3_24  -1
    r[24]     abs_p_4_24  1
    r[24]     abs_m_4_24  -1
    r[24]     abs_p_5_24  1
    r[24]     abs_m_5_24  -1
    r[24]     abs_p_6_24  1
    r[24]     abs_m_6_24  -1
    r[24]     abs_p_7_24  1
    r[24]     abs_m_7_24  -1
    r[24]     abs_p_8_24  1
    r[24]     abs_m_8_24  -1
    r[24]     abs_p_9_24  1
    r[24]     abs_m_9_24  -1
    r[24]     abs_p_10_24  1
    r[24]     abs_m_10_24  -1
    r[24]     abs_p_11_24  1
    r[24]     abs_m_11_24  -1
    r[24]     abs_p_12_24  1
    r[24]     abs_m_12_24  -1
    r[24]     abs_p_13_24  1
    r[24]     abs_m_13_24  -1
    r[24]     abs_p_14_24  1
    r[24]     abs_m_14_24  -1
    r[24]     abs_p_15_24  1
    r[24]     abs_m_15_24  -1
    r[24]     abs_p_16_24  1
    r[24]     abs_m_16_24  -1
    r[24]     abs_p_17_24  1
    r[24]     abs_m_17_24  -1
    r[24]     abs_p_18_24  1
    r[24]     abs_m_18_24  -1
    r[24]     abs_p_19_24  1
    r[24]     abs_m_19_24  -1
    r[24]     abs_p_20_24  1
    r[24]     abs_m_20_24  -1
    r[24]     abs_p_21_24  1
    r[24]     abs_m_21_24  -1
    r[24]     abs_p_22_24  1
    r[24]     abs_m_22_24  -1
    r[24]     abs_p_23_24  1
    r[24]     abs_m_23_24  -1
    r[24]     abs_p_24_25  -1
    r[24]     abs_m_24_25  1
    r[24]     abs_p_24_26  -1
    r[24]     abs_m_24_26  1
    r[24]     abs_p_24_27  -1
    r[24]     abs_m_24_27  1
    r[24]     abs_p_24_28  -1
    r[24]     abs_m_24_28  1
    r[24]     abs_p_24_29  -1
    r[24]     abs_m_24_29  1
    r[24]     abs_p_24_30  -1
    r[24]     abs_m_24_30  1
    r[24]     abs_p_24_31  -1
    r[24]     abs_m_24_31  1
    r[24]     abs_p_24_32  -1
    r[24]     abs_m_24_32  1
    r[24]     abs_p_24_33  -1
    r[24]     abs_m_24_33  1
    r[24]     abs_p_24_34  -1
    r[24]     abs_m_24_34  1
    r[24]     abs_p_24_35  -1
    r[24]     abs_m_24_35  1
    r[25]     normalized_ratio_25  1
    r[25]     normalization  1
    r[25]     abs_p_1_25  1
    r[25]     abs_m_1_25  -1
    r[25]     abs_p_2_25  1
    r[25]     abs_m_2_25  -1
    r[25]     abs_p_3_25  1
    r[25]     abs_m_3_25  -1
    r[25]     abs_p_4_25  1
    r[25]     abs_m_4_25  -1
    r[25]     abs_p_5_25  1
    r[25]     abs_m_5_25  -1
    r[25]     abs_p_6_25  1
    r[25]     abs_m_6_25  -1
    r[25]     abs_p_7_25  1
    r[25]     abs_m_7_25  -1
    r[25]     abs_p_8_25  1
    r[25]     abs_m_8_25  -1
    r[25]     abs_p_9_25  1
    r[25]     abs_m_9_25  -1
    r[25]     abs_p_10_25  1
    r[25]     abs_m_10_25  -1
    r[25]     abs_p_11_25  1
    r[25]     abs_m_11_25  -1
    r[25]     abs_p_12_25  1
    r[25]     abs_m_12_25  -1
    r[25]     abs_p_13_25  1
    r[25]     abs_m_13_25  -1
    r[25]     abs_p_14_25  1
    r[25]     abs_m_14_25  -1
    r[25]     abs_p_15_25  1
    r[25]     abs_m_15_25  -1
    r[25]     abs_p_16_25  1
    r[25]     abs_m_16_25  -1
    r[25]     abs_p_17_25  1
    r[25]     abs_m_17_25  -1
    r[25]     abs_p_18_25  1
    r[25]     abs_m_18_25  -1
    r[25]     abs_p_19_25  1
    r[25]     abs_m_19_25  -1
    r[25]     abs_p_20_25  1
    r[25]     abs_m_20_25  -1
    r[25]     abs_p_21_25  1
    r[25]     abs_m_21_25  -1
    r[25]     abs_p_22_25  1
    r[25]     abs_m_22_25  -1
    r[25]     abs_p_23_25  1
    r[25]     abs_m_23_25  -1
    r[25]     abs_p_24_25  1
    r[25]     abs_m_24_25  -1
    r[25]     abs_p_25_26  -1
    r[25]     abs_m_25_26  1
    r[25]     abs_p_25_27  -1
    r[25]     abs_m_25_27  1
    r[25]     abs_p_25_28  -1
    r[25]     abs_m_25_28  1
    r[25]     abs_p_25_29  -1
    r[25]     abs_m_25_29  1
    r[25]     abs_p_25_30  -1
    r[25]     abs_m_25_30  1
    r[25]     abs_p_25_31  -1
    r[25]     abs_m_25_31  1
    r[25]     abs_p_25_32  -1
    r[25]     abs_m_25_32  1
    r[25]     abs_p_25_33  -1
    r[25]     abs_m_25_33  1
    r[25]     abs_p_25_34  -1
    r[25]     abs_m_25_34  1
    r[25]     abs_p_25_35  -1
    r[25]     abs_m_25_35  1
    r[26]     normalized_ratio_26  1
    r[26]     normalization  1
    r[26]     abs_p_1_26  1
    r[26]     abs_m_1_26  -1
    r[26]     abs_p_2_26  1
    r[26]     abs_m_2_26  -1
    r[26]     abs_p_3_26  1
    r[26]     abs_m_3_26  -1
    r[26]     abs_p_4_26  1
    r[26]     abs_m_4_26  -1
    r[26]     abs_p_5_26  1
    r[26]     abs_m_5_26  -1
    r[26]     abs_p_6_26  1
    r[26]     abs_m_6_26  -1
    r[26]     abs_p_7_26  1
    r[26]     abs_m_7_26  -1
    r[26]     abs_p_8_26  1
    r[26]     abs_m_8_26  -1
    r[26]     abs_p_9_26  1
    r[26]     abs_m_9_26  -1
    r[26]     abs_p_10_26  1
    r[26]     abs_m_10_26  -1
    r[26]     abs_p_11_26  1
    r[26]     abs_m_11_26  -1
    r[26]     abs_p_12_26  1
    r[26]     abs_m_12_26  -1
    r[26]     abs_p_13_26  1
    r[26]     abs_m_13_26  -1
    r[26]     abs_p_14_26  1
    r[26]     abs_m_14_26  -1
    r[26]     abs_p_15_26  1
    r[26]     abs_m_15_26  -1
    r[26]     abs_p_16_26  1
    r[26]     abs_m_16_26  -1
    r[26]     abs_p_17_26  1
    r[26]     abs_m_17_26  -1
    r[26]     abs_p_18_26  1
    r[26]     abs_m_18_26  -1
    r[26]     abs_p_19_26  1
    r[26]     abs_m_19_26  -1
    r[26]     abs_p_20_26  1
    r[26]     abs_m_20_26  -1
    r[26]     abs_p_21_26  1
    r[26]     abs_m_21_26  -1
    r[26]     abs_p_22_26  1
    r[26]     abs_m_22_26  -1
    r[26]     abs_p_23_26  1
    r[26]     abs_m_23_26  -1
    r[26]     abs_p_24_26  1
    r[26]     abs_m_24_26  -1
    r[26]     abs_p_25_26  1
    r[26]     abs_m_25_26  -1
    r[26]     abs_p_26_27  -1
    r[26]     abs_m_26_27  1
    r[26]     abs_p_26_28  -1
    r[26]     abs_m_26_28  1
    r[26]     abs_p_26_29  -1
    r[26]     abs_m_26_29  1
    r[26]     abs_p_26_30  -1
    r[26]     abs_m_26_30  1
    r[26]     abs_p_26_31  -1
    r[26]     abs_m_26_31  1
    r[26]     abs_p_26_32  -1
    r[26]     abs_m_26_32  1
    r[26]     abs_p_26_33  -1
    r[26]     abs_m_26_33  1
    r[26]     abs_p_26_34  -1
    r[26]     abs_m_26_34  1
    r[26]     abs_p_26_35  -1
    r[26]     abs_m_26_35  1
    r[27]     normalized_ratio_27  1
    r[27]     normalization  1
    r[27]     abs_p_1_27  1
    r[27]     abs_m_1_27  -1
    r[27]     abs_p_2_27  1
    r[27]     abs_m_2_27  -1
    r[27]     abs_p_3_27  1
    r[27]     abs_m_3_27  -1
    r[27]     abs_p_4_27  1
    r[27]     abs_m_4_27  -1
    r[27]     abs_p_5_27  1
    r[27]     abs_m_5_27  -1
    r[27]     abs_p_6_27  1
    r[27]     abs_m_6_27  -1
    r[27]     abs_p_7_27  1
    r[27]     abs_m_7_27  -1
    r[27]     abs_p_8_27  1
    r[27]     abs_m_8_27  -1
    r[27]     abs_p_9_27  1
    r[27]     abs_m_9_27  -1
    r[27]     abs_p_10_27  1
    r[27]     abs_m_10_27  -1
    r[27]     abs_p_11_27  1
    r[27]     abs_m_11_27  -1
    r[27]     abs_p_12_27  1
    r[27]     abs_m_12_27  -1
    r[27]     abs_p_13_27  1
    r[27]     abs_m_13_27  -1
    r[27]     abs_p_14_27  1
    r[27]     abs_m_14_27  -1
    r[27]     abs_p_15_27  1
    r[27]     abs_m_15_27  -1
    r[27]     abs_p_16_27  1
    r[27]     abs_m_16_27  -1
    r[27]     abs_p_17_27  1
    r[27]     abs_m_17_27  -1
    r[27]     abs_p_18_27  1
    r[27]     abs_m_18_27  -1
    r[27]     abs_p_19_27  1
    r[27]     abs_m_19_27  -1
    r[27]     abs_p_20_27  1
    r[27]     abs_m_20_27  -1
    r[27]     abs_p_21_27  1
    r[27]     abs_m_21_27  -1
    r[27]     abs_p_22_27  1
    r[27]     abs_m_22_27  -1
    r[27]     abs_p_23_27  1
    r[27]     abs_m_23_27  -1
    r[27]     abs_p_24_27  1
    r[27]     abs_m_24_27  -1
    r[27]     abs_p_25_27  1
    r[27]     abs_m_25_27  -1
    r[27]     abs_p_26_27  1
    r[27]     abs_m_26_27  -1
    r[27]     abs_p_27_28  -1
    r[27]     abs_m_27_28  1
    r[27]     abs_p_27_29  -1
    r[27]     abs_m_27_29  1
    r[27]     abs_p_27_30  -1
    r[27]     abs_m_27_30  1
    r[27]     abs_p_27_31  -1
    r[27]     abs_m_27_31  1
    r[27]     abs_p_27_32  -1
    r[27]     abs_m_27_32  1
    r[27]     abs_p_27_33  -1
    r[27]     abs_m_27_33  1
    r[27]     abs_p_27_34  -1
    r[27]     abs_m_27_34  1
    r[27]     abs_p_27_35  -1
    r[27]     abs_m_27_35  1
    r[28]     normalized_ratio_28  1
    r[28]     normalization  1
    r[28]     abs_p_1_28  1
    r[28]     abs_m_1_28  -1
    r[28]     abs_p_2_28  1
    r[28]     abs_m_2_28  -1
    r[28]     abs_p_3_28  1
    r[28]     abs_m_3_28  -1
    r[28]     abs_p_4_28  1
    r[28]     abs_m_4_28  -1
    r[28]     abs_p_5_28  1
    r[28]     abs_m_5_28  -1
    r[28]     abs_p_6_28  1
    r[28]     abs_m_6_28  -1
    r[28]     abs_p_7_28  1
    r[28]     abs_m_7_28  -1
    r[28]     abs_p_8_28  1
    r[28]     abs_m_8_28  -1
    r[28]     abs_p_9_28  1
    r[28]     abs_m_9_28  -1
    r[28]     abs_p_10_28  1
    r[28]     abs_m_10_28  -1
    r[28]     abs_p_11_28  1
    r[28]     abs_m_11_28  -1
    r[28]     abs_p_12_28  1
    r[28]     abs_m_12_28  -1
    r[28]     abs_p_13_28  1
    r[28]     abs_m_13_28  -1
    r[28]     abs_p_14_28  1
    r[28]     abs_m_14_28  -1
    r[28]     abs_p_15_28  1
    r[28]     abs_m_15_28  -1
    r[28]     abs_p_16_28  1
    r[28]     abs_m_16_28  -1
    r[28]     abs_p_17_28  1
    r[28]     abs_m_17_28  -1
    r[28]     abs_p_18_28  1
    r[28]     abs_m_18_28  -1
    r[28]     abs_p_19_28  1
    r[28]     abs_m_19_28  -1
    r[28]     abs_p_20_28  1
    r[28]     abs_m_20_28  -1
    r[28]     abs_p_21_28  1
    r[28]     abs_m_21_28  -1
    r[28]     abs_p_22_28  1
    r[28]     abs_m_22_28  -1
    r[28]     abs_p_23_28  1
    r[28]     abs_m_23_28  -1
    r[28]     abs_p_24_28  1
    r[28]     abs_m_24_28  -1
    r[28]     abs_p_25_28  1
    r[28]     abs_m_25_28  -1
    r[28]     abs_p_26_28  1
    r[28]     abs_m_26_28  -1
    r[28]     abs_p_27_28  1
    r[28]     abs_m_27_28  -1
    r[28]     abs_p_28_29  -1
    r[28]     abs_m_28_29  1
    r[28]     abs_p_28_30  -1
    r[28]     abs_m_28_30  1
    r[28]     abs_p_28_31  -1
    r[28]     abs_m_28_31  1
    r[28]     abs_p_28_32  -1
    r[28]     abs_m_28_32  1
    r[28]     abs_p_28_33  -1
    r[28]     abs_m_28_33  1
    r[28]     abs_p_28_34  -1
    r[28]     abs_m_28_34  1
    r[28]     abs_p_28_35  -1
    r[28]     abs_m_28_35  1
    r[29]     normalized_ratio_29  1
    r[29]     normalization  1
    r[29]     abs_p_1_29  1
    r[29]     abs_m_1_29  -1
    r[29]     abs_p_2_29  1
    r[29]     abs_m_2_29  -1
    r[29]     abs_p_3_29  1
    r[29]     abs_m_3_29  -1
    r[29]     abs_p_4_29  1
    r[29]     abs_m_4_29  -1
    r[29]     abs_p_5_29  1
    r[29]     abs_m_5_29  -1
    r[29]     abs_p_6_29  1
    r[29]     abs_m_6_29  -1
    r[29]     abs_p_7_29  1
    r[29]     abs_m_7_29  -1
    r[29]     abs_p_8_29  1
    r[29]     abs_m_8_29  -1
    r[29]     abs_p_9_29  1
    r[29]     abs_m_9_29  -1
    r[29]     abs_p_10_29  1
    r[29]     abs_m_10_29  -1
    r[29]     abs_p_11_29  1
    r[29]     abs_m_11_29  -1
    r[29]     abs_p_12_29  1
    r[29]     abs_m_12_29  -1
    r[29]     abs_p_13_29  1
    r[29]     abs_m_13_29  -1
    r[29]     abs_p_14_29  1
    r[29]     abs_m_14_29  -1
    r[29]     abs_p_15_29  1
    r[29]     abs_m_15_29  -1
    r[29]     abs_p_16_29  1
    r[29]     abs_m_16_29  -1
    r[29]     abs_p_17_29  1
    r[29]     abs_m_17_29  -1
    r[29]     abs_p_18_29  1
    r[29]     abs_m_18_29  -1
    r[29]     abs_p_19_29  1
    r[29]     abs_m_19_29  -1
    r[29]     abs_p_20_29  1
    r[29]     abs_m_20_29  -1
    r[29]     abs_p_21_29  1
    r[29]     abs_m_21_29  -1
    r[29]     abs_p_22_29  1
    r[29]     abs_m_22_29  -1
    r[29]     abs_p_23_29  1
    r[29]     abs_m_23_29  -1
    r[29]     abs_p_24_29  1
    r[29]     abs_m_24_29  -1
    r[29]     abs_p_25_29  1
    r[29]     abs_m_25_29  -1
    r[29]     abs_p_26_29  1
    r[29]     abs_m_26_29  -1
    r[29]     abs_p_27_29  1
    r[29]     abs_m_27_29  -1
    r[29]     abs_p_28_29  1
    r[29]     abs_m_28_29  -1
    r[29]     abs_p_29_30  -1
    r[29]     abs_m_29_30  1
    r[29]     abs_p_29_31  -1
    r[29]     abs_m_29_31  1
    r[29]     abs_p_29_32  -1
    r[29]     abs_m_29_32  1
    r[29]     abs_p_29_33  -1
    r[29]     abs_m_29_33  1
    r[29]     abs_p_29_34  -1
    r[29]     abs_m_29_34  1
    r[29]     abs_p_29_35  -1
    r[29]     abs_m_29_35  1
    r[30]     normalized_ratio_30  1
    r[30]     normalization  1
    r[30]     abs_p_1_30  1
    r[30]     abs_m_1_30  -1
    r[30]     abs_p_2_30  1
    r[30]     abs_m_2_30  -1
    r[30]     abs_p_3_30  1
    r[30]     abs_m_3_30  -1
    r[30]     abs_p_4_30  1
    r[30]     abs_m_4_30  -1
    r[30]     abs_p_5_30  1
    r[30]     abs_m_5_30  -1
    r[30]     abs_p_6_30  1
    r[30]     abs_m_6_30  -1
    r[30]     abs_p_7_30  1
    r[30]     abs_m_7_30  -1
    r[30]     abs_p_8_30  1
    r[30]     abs_m_8_30  -1
    r[30]     abs_p_9_30  1
    r[30]     abs_m_9_30  -1
    r[30]     abs_p_10_30  1
    r[30]     abs_m_10_30  -1
    r[30]     abs_p_11_30  1
    r[30]     abs_m_11_30  -1
    r[30]     abs_p_12_30  1
    r[30]     abs_m_12_30  -1
    r[30]     abs_p_13_30  1
    r[30]     abs_m_13_30  -1
    r[30]     abs_p_14_30  1
    r[30]     abs_m_14_30  -1
    r[30]     abs_p_15_30  1
    r[30]     abs_m_15_30  -1
    r[30]     abs_p_16_30  1
    r[30]     abs_m_16_30  -1
    r[30]     abs_p_17_30  1
    r[30]     abs_m_17_30  -1
    r[30]     abs_p_18_30  1
    r[30]     abs_m_18_30  -1
    r[30]     abs_p_19_30  1
    r[30]     abs_m_19_30  -1
    r[30]     abs_p_20_30  1
    r[30]     abs_m_20_30  -1
    r[30]     abs_p_21_30  1
    r[30]     abs_m_21_30  -1
    r[30]     abs_p_22_30  1
    r[30]     abs_m_22_30  -1
    r[30]     abs_p_23_30  1
    r[30]     abs_m_23_30  -1
    r[30]     abs_p_24_30  1
    r[30]     abs_m_24_30  -1
    r[30]     abs_p_25_30  1
    r[30]     abs_m_25_30  -1
    r[30]     abs_p_26_30  1
    r[30]     abs_m_26_30  -1
    r[30]     abs_p_27_30  1
    r[30]     abs_m_27_30  -1
    r[30]     abs_p_28_30  1
    r[30]     abs_m_28_30  -1
    r[30]     abs_p_29_30  1
    r[30]     abs_m_29_30  -1
    r[30]     abs_p_30_31  -1
    r[30]     abs_m_30_31  1
    r[30]     abs_p_30_32  -1
    r[30]     abs_m_30_32  1
    r[30]     abs_p_30_33  -1
    r[30]     abs_m_30_33  1
    r[30]     abs_p_30_34  -1
    r[30]     abs_m_30_34  1
    r[30]     abs_p_30_35  -1
    r[30]     abs_m_30_35  1
    r[31]     normalized_ratio_31  1
    r[31]     normalization  1
    r[31]     abs_p_1_31  1
    r[31]     abs_m_1_31  -1
    r[31]     abs_p_2_31  1
    r[31]     abs_m_2_31  -1
    r[31]     abs_p_3_31  1
    r[31]     abs_m_3_31  -1
    r[31]     abs_p_4_31  1
    r[31]     abs_m_4_31  -1
    r[31]     abs_p_5_31  1
    r[31]     abs_m_5_31  -1
    r[31]     abs_p_6_31  1
    r[31]     abs_m_6_31  -1
    r[31]     abs_p_7_31  1
    r[31]     abs_m_7_31  -1
    r[31]     abs_p_8_31  1
    r[31]     abs_m_8_31  -1
    r[31]     abs_p_9_31  1
    r[31]     abs_m_9_31  -1
    r[31]     abs_p_10_31  1
    r[31]     abs_m_10_31  -1
    r[31]     abs_p_11_31  1
    r[31]     abs_m_11_31  -1
    r[31]     abs_p_12_31  1
    r[31]     abs_m_12_31  -1
    r[31]     abs_p_13_31  1
    r[31]     abs_m_13_31  -1
    r[31]     abs_p_14_31  1
    r[31]     abs_m_14_31  -1
    r[31]     abs_p_15_31  1
    r[31]     abs_m_15_31  -1
    r[31]     abs_p_16_31  1
    r[31]     abs_m_16_31  -1
    r[31]     abs_p_17_31  1
    r[31]     abs_m_17_31  -1
    r[31]     abs_p_18_31  1
    r[31]     abs_m_18_31  -1
    r[31]     abs_p_19_31  1
    r[31]     abs_m_19_31  -1
    r[31]     abs_p_20_31  1
    r[31]     abs_m_20_31  -1
    r[31]     abs_p_21_31  1
    r[31]     abs_m_21_31  -1
    r[31]     abs_p_22_31  1
    r[31]     abs_m_22_31  -1
    r[31]     abs_p_23_31  1
    r[31]     abs_m_23_31  -1
    r[31]     abs_p_24_31  1
    r[31]     abs_m_24_31  -1
    r[31]     abs_p_25_31  1
    r[31]     abs_m_25_31  -1
    r[31]     abs_p_26_31  1
    r[31]     abs_m_26_31  -1
    r[31]     abs_p_27_31  1
    r[31]     abs_m_27_31  -1
    r[31]     abs_p_28_31  1
    r[31]     abs_m_28_31  -1
    r[31]     abs_p_29_31  1
    r[31]     abs_m_29_31  -1
    r[31]     abs_p_30_31  1
    r[31]     abs_m_30_31  -1
    r[31]     abs_p_31_32  -1
    r[31]     abs_m_31_32  1
    r[31]     abs_p_31_33  -1
    r[31]     abs_m_31_33  1
    r[31]     abs_p_31_34  -1
    r[31]     abs_m_31_34  1
    r[31]     abs_p_31_35  -1
    r[31]     abs_m_31_35  1
    r[32]     normalized_ratio_32  1
    r[32]     normalization  1
    r[32]     abs_p_1_32  1
    r[32]     abs_m_1_32  -1
    r[32]     abs_p_2_32  1
    r[32]     abs_m_2_32  -1
    r[32]     abs_p_3_32  1
    r[32]     abs_m_3_32  -1
    r[32]     abs_p_4_32  1
    r[32]     abs_m_4_32  -1
    r[32]     abs_p_5_32  1
    r[32]     abs_m_5_32  -1
    r[32]     abs_p_6_32  1
    r[32]     abs_m_6_32  -1
    r[32]     abs_p_7_32  1
    r[32]     abs_m_7_32  -1
    r[32]     abs_p_8_32  1
    r[32]     abs_m_8_32  -1
    r[32]     abs_p_9_32  1
    r[32]     abs_m_9_32  -1
    r[32]     abs_p_10_32  1
    r[32]     abs_m_10_32  -1
    r[32]     abs_p_11_32  1
    r[32]     abs_m_11_32  -1
    r[32]     abs_p_12_32  1
    r[32]     abs_m_12_32  -1
    r[32]     abs_p_13_32  1
    r[32]     abs_m_13_32  -1
    r[32]     abs_p_14_32  1
    r[32]     abs_m_14_32  -1
    r[32]     abs_p_15_32  1
    r[32]     abs_m_15_32  -1
    r[32]     abs_p_16_32  1
    r[32]     abs_m_16_32  -1
    r[32]     abs_p_17_32  1
    r[32]     abs_m_17_32  -1
    r[32]     abs_p_18_32  1
    r[32]     abs_m_18_32  -1
    r[32]     abs_p_19_32  1
    r[32]     abs_m_19_32  -1
    r[32]     abs_p_20_32  1
    r[32]     abs_m_20_32  -1
    r[32]     abs_p_21_32  1
    r[32]     abs_m_21_32  -1
    r[32]     abs_p_22_32  1
    r[32]     abs_m_22_32  -1
    r[32]     abs_p_23_32  1
    r[32]     abs_m_23_32  -1
    r[32]     abs_p_24_32  1
    r[32]     abs_m_24_32  -1
    r[32]     abs_p_25_32  1
    r[32]     abs_m_25_32  -1
    r[32]     abs_p_26_32  1
    r[32]     abs_m_26_32  -1
    r[32]     abs_p_27_32  1
    r[32]     abs_m_27_32  -1
    r[32]     abs_p_28_32  1
    r[32]     abs_m_28_32  -1
    r[32]     abs_p_29_32  1
    r[32]     abs_m_29_32  -1
    r[32]     abs_p_30_32  1
    r[32]     abs_m_30_32  -1
    r[32]     abs_p_31_32  1
    r[32]     abs_m_31_32  -1
    r[32]     abs_p_32_33  -1
    r[32]     abs_m_32_33  1
    r[32]     abs_p_32_34  -1
    r[32]     abs_m_32_34  1
    r[32]     abs_p_32_35  -1
    r[32]     abs_m_32_35  1
    r[33]     normalized_ratio_33  1
    r[33]     normalization  1
    r[33]     abs_p_1_33  1
    r[33]     abs_m_1_33  -1
    r[33]     abs_p_2_33  1
    r[33]     abs_m_2_33  -1
    r[33]     abs_p_3_33  1
    r[33]     abs_m_3_33  -1
    r[33]     abs_p_4_33  1
    r[33]     abs_m_4_33  -1
    r[33]     abs_p_5_33  1
    r[33]     abs_m_5_33  -1
    r[33]     abs_p_6_33  1
    r[33]     abs_m_6_33  -1
    r[33]     abs_p_7_33  1
    r[33]     abs_m_7_33  -1
    r[33]     abs_p_8_33  1
    r[33]     abs_m_8_33  -1
    r[33]     abs_p_9_33  1
    r[33]     abs_m_9_33  -1
    r[33]     abs_p_10_33  1
    r[33]     abs_m_10_33  -1
    r[33]     abs_p_11_33  1
    r[33]     abs_m_11_33  -1
    r[33]     abs_p_12_33  1
    r[33]     abs_m_12_33  -1
    r[33]     abs_p_13_33  1
    r[33]     abs_m_13_33  -1
    r[33]     abs_p_14_33  1
    r[33]     abs_m_14_33  -1
    r[33]     abs_p_15_33  1
    r[33]     abs_m_15_33  -1
    r[33]     abs_p_16_33  1
    r[33]     abs_m_16_33  -1
    r[33]     abs_p_17_33  1
    r[33]     abs_m_17_33  -1
    r[33]     abs_p_18_33  1
    r[33]     abs_m_18_33  -1
    r[33]     abs_p_19_33  1
    r[33]     abs_m_19_33  -1
    r[33]     abs_p_20_33  1
    r[33]     abs_m_20_33  -1
    r[33]     abs_p_21_33  1
    r[33]     abs_m_21_33  -1
    r[33]     abs_p_22_33  1
    r[33]     abs_m_22_33  -1
    r[33]     abs_p_23_33  1
    r[33]     abs_m_23_33  -1
    r[33]     abs_p_24_33  1
    r[33]     abs_m_24_33  -1
    r[33]     abs_p_25_33  1
    r[33]     abs_m_25_33  -1
    r[33]     abs_p_26_33  1
    r[33]     abs_m_26_33  -1
    r[33]     abs_p_27_33  1
    r[33]     abs_m_27_33  -1
    r[33]     abs_p_28_33  1
    r[33]     abs_m_28_33  -1
    r[33]     abs_p_29_33  1
    r[33]     abs_m_29_33  -1
    r[33]     abs_p_30_33  1
    r[33]     abs_m_30_33  -1
    r[33]     abs_p_31_33  1
    r[33]     abs_m_31_33  -1
    r[33]     abs_p_32_33  1
    r[33]     abs_m_32_33  -1
    r[33]     abs_p_33_34  -1
    r[33]     abs_m_33_34  1
    r[33]     abs_p_33_35  -1
    r[33]     abs_m_33_35  1
    r[34]     normalized_ratio_34  1
    r[34]     normalization  1
    r[34]     abs_p_1_34  1
    r[34]     abs_m_1_34  -1
    r[34]     abs_p_2_34  1
    r[34]     abs_m_2_34  -1
    r[34]     abs_p_3_34  1
    r[34]     abs_m_3_34  -1
    r[34]     abs_p_4_34  1
    r[34]     abs_m_4_34  -1
    r[34]     abs_p_5_34  1
    r[34]     abs_m_5_34  -1
    r[34]     abs_p_6_34  1
    r[34]     abs_m_6_34  -1
    r[34]     abs_p_7_34  1
    r[34]     abs_m_7_34  -1
    r[34]     abs_p_8_34  1
    r[34]     abs_m_8_34  -1
    r[34]     abs_p_9_34  1
    r[34]     abs_m_9_34  -1
    r[34]     abs_p_10_34  1
    r[34]     abs_m_10_34  -1
    r[34]     abs_p_11_34  1
    r[34]     abs_m_11_34  -1
    r[34]     abs_p_12_34  1
    r[34]     abs_m_12_34  -1
    r[34]     abs_p_13_34  1
    r[34]     abs_m_13_34  -1
    r[34]     abs_p_14_34  1
    r[34]     abs_m_14_34  -1
    r[34]     abs_p_15_34  1
    r[34]     abs_m_15_34  -1
    r[34]     abs_p_16_34  1
    r[34]     abs_m_16_34  -1
    r[34]     abs_p_17_34  1
    r[34]     abs_m_17_34  -1
    r[34]     abs_p_18_34  1
    r[34]     abs_m_18_34  -1
    r[34]     abs_p_19_34  1
    r[34]     abs_m_19_34  -1
    r[34]     abs_p_20_34  1
    r[34]     abs_m_20_34  -1
    r[34]     abs_p_21_34  1
    r[34]     abs_m_21_34  -1
    r[34]     abs_p_22_34  1
    r[34]     abs_m_22_34  -1
    r[34]     abs_p_23_34  1
    r[34]     abs_m_23_34  -1
    r[34]     abs_p_24_34  1
    r[34]     abs_m_24_34  -1
    r[34]     abs_p_25_34  1
    r[34]     abs_m_25_34  -1
    r[34]     abs_p_26_34  1
    r[34]     abs_m_26_34  -1
    r[34]     abs_p_27_34  1
    r[34]     abs_m_27_34  -1
    r[34]     abs_p_28_34  1
    r[34]     abs_m_28_34  -1
    r[34]     abs_p_29_34  1
    r[34]     abs_m_29_34  -1
    r[34]     abs_p_30_34  1
    r[34]     abs_m_30_34  -1
    r[34]     abs_p_31_34  1
    r[34]     abs_m_31_34  -1
    r[34]     abs_p_32_34  1
    r[34]     abs_m_32_34  -1
    r[34]     abs_p_33_34  1
    r[34]     abs_m_33_34  -1
    r[34]     abs_p_34_35  -1
    r[34]     abs_m_34_35  1
    r[35]     normalized_ratio_35  1
    r[35]     normalization  1
    r[35]     abs_p_1_35  1
    r[35]     abs_m_1_35  -1
    r[35]     abs_p_2_35  1
    r[35]     abs_m_2_35  -1
    r[35]     abs_p_3_35  1
    r[35]     abs_m_3_35  -1
    r[35]     abs_p_4_35  1
    r[35]     abs_m_4_35  -1
    r[35]     abs_p_5_35  1
    r[35]     abs_m_5_35  -1
    r[35]     abs_p_6_35  1
    r[35]     abs_m_6_35  -1
    r[35]     abs_p_7_35  1
    r[35]     abs_m_7_35  -1
    r[35]     abs_p_8_35  1
    r[35]     abs_m_8_35  -1
    r[35]     abs_p_9_35  1
    r[35]     abs_m_9_35  -1
    r[35]     abs_p_10_35  1
    r[35]     abs_m_10_35  -1
    r[35]     abs_p_11_35  1
    r[35]     abs_m_11_35  -1
    r[35]     abs_p_12_35  1
    r[35]     abs_m_12_35  -1
    r[35]     abs_p_13_35  1
    r[35]     abs_m_13_35  -1
    r[35]     abs_p_14_35  1
    r[35]     abs_m_14_35  -1
    r[35]     abs_p_15_35  1
    r[35]     abs_m_15_35  -1
    r[35]     abs_p_16_35  1
    r[35]     abs_m_16_35  -1
    r[35]     abs_p_17_35  1
    r[35]     abs_m_17_35  -1
    r[35]     abs_p_18_35  1
    r[35]     abs_m_18_35  -1
    r[35]     abs_p_19_35  1
    r[35]     abs_m_19_35  -1
    r[35]     abs_p_20_35  1
    r[35]     abs_m_20_35  -1
    r[35]     abs_p_21_35  1
    r[35]     abs_m_21_35  -1
    r[35]     abs_p_22_35  1
    r[35]     abs_m_22_35  -1
    r[35]     abs_p_23_35  1
    r[35]     abs_m_23_35  -1
    r[35]     abs_p_24_35  1
    r[35]     abs_m_24_35  -1
    r[35]     abs_p_25_35  1
    r[35]     abs_m_25_35  -1
    r[35]     abs_p_26_35  1
    r[35]     abs_m_26_35  -1
    r[35]     abs_p_27_35  1
    r[35]     abs_m_27_35  -1
    r[35]     abs_p_28_35  1
    r[35]     abs_m_28_35  -1
    r[35]     abs_p_29_35  1
    r[35]     abs_m_29_35  -1
    r[35]     abs_p_30_35  1
    r[35]     abs_m_30_35  -1
    r[35]     abs_p_31_35  1
    r[35]     abs_m_31_35  -1
    r[35]     abs_p_32_35  1
    r[35]     abs_m_32_35  -1
    r[35]     abs_p_33_35  1
    r[35]     abs_m_33_35  -1
    r[35]     abs_p_34_35  1
    r[35]     abs_m_34_35  -1
    a[1,2]    abs_p_1_2  1
    a[1,2]    abs_m_1_2  1
    a[1,2]    true_G_epigraph  1
    a[1,2]    physical_G_upper  1
    a[1,3]    abs_p_1_3  1
    a[1,3]    abs_m_1_3  1
    a[1,3]    true_G_epigraph  1
    a[1,3]    physical_G_upper  1
    a[1,4]    abs_p_1_4  1
    a[1,4]    abs_m_1_4  1
    a[1,4]    true_G_epigraph  1
    a[1,4]    physical_G_upper  1
    a[1,5]    abs_p_1_5  1
    a[1,5]    abs_m_1_5  1
    a[1,5]    true_G_epigraph  1
    a[1,5]    physical_G_upper  1
    a[1,6]    abs_p_1_6  1
    a[1,6]    abs_m_1_6  1
    a[1,6]    true_G_epigraph  1
    a[1,6]    physical_G_upper  1
    a[1,7]    abs_p_1_7  1
    a[1,7]    abs_m_1_7  1
    a[1,7]    true_G_epigraph  1
    a[1,7]    physical_G_upper  1
    a[1,8]    abs_p_1_8  1
    a[1,8]    abs_m_1_8  1
    a[1,8]    true_G_epigraph  1
    a[1,8]    physical_G_upper  1
    a[1,9]    abs_p_1_9  1
    a[1,9]    abs_m_1_9  1
    a[1,9]    true_G_epigraph  1
    a[1,9]    physical_G_upper  1
    a[1,10]   abs_p_1_10  1
    a[1,10]   abs_m_1_10  1
    a[1,10]   true_G_epigraph  1
    a[1,10]   physical_G_upper  1
    a[1,11]   abs_p_1_11  1
    a[1,11]   abs_m_1_11  1
    a[1,11]   true_G_epigraph  1
    a[1,11]   physical_G_upper  1
    a[1,12]   abs_p_1_12  1
    a[1,12]   abs_m_1_12  1
    a[1,12]   true_G_epigraph  1
    a[1,12]   physical_G_upper  1
    a[1,13]   abs_p_1_13  1
    a[1,13]   abs_m_1_13  1
    a[1,13]   true_G_epigraph  1
    a[1,13]   physical_G_upper  1
    a[1,14]   abs_p_1_14  1
    a[1,14]   abs_m_1_14  1
    a[1,14]   true_G_epigraph  1
    a[1,14]   physical_G_upper  1
    a[1,15]   abs_p_1_15  1
    a[1,15]   abs_m_1_15  1
    a[1,15]   true_G_epigraph  1
    a[1,15]   physical_G_upper  1
    a[1,16]   abs_p_1_16  1
    a[1,16]   abs_m_1_16  1
    a[1,16]   true_G_epigraph  1
    a[1,16]   physical_G_upper  1
    a[1,17]   abs_p_1_17  1
    a[1,17]   abs_m_1_17  1
    a[1,17]   true_G_epigraph  1
    a[1,17]   physical_G_upper  1
    a[1,18]   abs_p_1_18  1
    a[1,18]   abs_m_1_18  1
    a[1,18]   true_G_epigraph  1
    a[1,18]   physical_G_upper  1
    a[1,19]   abs_p_1_19  1
    a[1,19]   abs_m_1_19  1
    a[1,19]   true_G_epigraph  1
    a[1,19]   physical_G_upper  1
    a[1,20]   abs_p_1_20  1
    a[1,20]   abs_m_1_20  1
    a[1,20]   true_G_epigraph  1
    a[1,20]   physical_G_upper  1
    a[1,21]   abs_p_1_21  1
    a[1,21]   abs_m_1_21  1
    a[1,21]   true_G_epigraph  1
    a[1,21]   physical_G_upper  1
    a[1,22]   abs_p_1_22  1
    a[1,22]   abs_m_1_22  1
    a[1,22]   true_G_epigraph  1
    a[1,22]   physical_G_upper  1
    a[1,23]   abs_p_1_23  1
    a[1,23]   abs_m_1_23  1
    a[1,23]   true_G_epigraph  1
    a[1,23]   physical_G_upper  1
    a[1,24]   abs_p_1_24  1
    a[1,24]   abs_m_1_24  1
    a[1,24]   true_G_epigraph  1
    a[1,24]   physical_G_upper  1
    a[1,25]   abs_p_1_25  1
    a[1,25]   abs_m_1_25  1
    a[1,25]   true_G_epigraph  1
    a[1,25]   physical_G_upper  1
    a[1,26]   abs_p_1_26  1
    a[1,26]   abs_m_1_26  1
    a[1,26]   true_G_epigraph  1
    a[1,26]   physical_G_upper  1
    a[1,27]   abs_p_1_27  1
    a[1,27]   abs_m_1_27  1
    a[1,27]   true_G_epigraph  1
    a[1,27]   physical_G_upper  1
    a[1,28]   abs_p_1_28  1
    a[1,28]   abs_m_1_28  1
    a[1,28]   true_G_epigraph  1
    a[1,28]   physical_G_upper  1
    a[1,29]   abs_p_1_29  1
    a[1,29]   abs_m_1_29  1
    a[1,29]   true_G_epigraph  1
    a[1,29]   physical_G_upper  1
    a[1,30]   abs_p_1_30  1
    a[1,30]   abs_m_1_30  1
    a[1,30]   true_G_epigraph  1
    a[1,30]   physical_G_upper  1
    a[1,31]   abs_p_1_31  1
    a[1,31]   abs_m_1_31  1
    a[1,31]   true_G_epigraph  1
    a[1,31]   physical_G_upper  1
    a[1,32]   abs_p_1_32  1
    a[1,32]   abs_m_1_32  1
    a[1,32]   true_G_epigraph  1
    a[1,32]   physical_G_upper  1
    a[1,33]   abs_p_1_33  1
    a[1,33]   abs_m_1_33  1
    a[1,33]   true_G_epigraph  1
    a[1,33]   physical_G_upper  1
    a[1,34]   abs_p_1_34  1
    a[1,34]   abs_m_1_34  1
    a[1,34]   true_G_epigraph  1
    a[1,34]   physical_G_upper  1
    a[1,35]   abs_p_1_35  1
    a[1,35]   abs_m_1_35  1
    a[1,35]   true_G_epigraph  1
    a[1,35]   physical_G_upper  1
    a[2,3]    abs_p_2_3  1
    a[2,3]    abs_m_2_3  1
    a[2,3]    true_G_epigraph  1
    a[2,3]    physical_G_upper  1
    a[2,4]    abs_p_2_4  1
    a[2,4]    abs_m_2_4  1
    a[2,4]    true_G_epigraph  1
    a[2,4]    physical_G_upper  1
    a[2,5]    abs_p_2_5  1
    a[2,5]    abs_m_2_5  1
    a[2,5]    true_G_epigraph  1
    a[2,5]    physical_G_upper  1
    a[2,6]    abs_p_2_6  1
    a[2,6]    abs_m_2_6  1
    a[2,6]    true_G_epigraph  1
    a[2,6]    physical_G_upper  1
    a[2,7]    abs_p_2_7  1
    a[2,7]    abs_m_2_7  1
    a[2,7]    true_G_epigraph  1
    a[2,7]    physical_G_upper  1
    a[2,8]    abs_p_2_8  1
    a[2,8]    abs_m_2_8  1
    a[2,8]    true_G_epigraph  1
    a[2,8]    physical_G_upper  1
    a[2,9]    abs_p_2_9  1
    a[2,9]    abs_m_2_9  1
    a[2,9]    true_G_epigraph  1
    a[2,9]    physical_G_upper  1
    a[2,10]   abs_p_2_10  1
    a[2,10]   abs_m_2_10  1
    a[2,10]   true_G_epigraph  1
    a[2,10]   physical_G_upper  1
    a[2,11]   abs_p_2_11  1
    a[2,11]   abs_m_2_11  1
    a[2,11]   true_G_epigraph  1
    a[2,11]   physical_G_upper  1
    a[2,12]   abs_p_2_12  1
    a[2,12]   abs_m_2_12  1
    a[2,12]   true_G_epigraph  1
    a[2,12]   physical_G_upper  1
    a[2,13]   abs_p_2_13  1
    a[2,13]   abs_m_2_13  1
    a[2,13]   true_G_epigraph  1
    a[2,13]   physical_G_upper  1
    a[2,14]   abs_p_2_14  1
    a[2,14]   abs_m_2_14  1
    a[2,14]   true_G_epigraph  1
    a[2,14]   physical_G_upper  1
    a[2,15]   abs_p_2_15  1
    a[2,15]   abs_m_2_15  1
    a[2,15]   true_G_epigraph  1
    a[2,15]   physical_G_upper  1
    a[2,16]   abs_p_2_16  1
    a[2,16]   abs_m_2_16  1
    a[2,16]   true_G_epigraph  1
    a[2,16]   physical_G_upper  1
    a[2,17]   abs_p_2_17  1
    a[2,17]   abs_m_2_17  1
    a[2,17]   true_G_epigraph  1
    a[2,17]   physical_G_upper  1
    a[2,18]   abs_p_2_18  1
    a[2,18]   abs_m_2_18  1
    a[2,18]   true_G_epigraph  1
    a[2,18]   physical_G_upper  1
    a[2,19]   abs_p_2_19  1
    a[2,19]   abs_m_2_19  1
    a[2,19]   true_G_epigraph  1
    a[2,19]   physical_G_upper  1
    a[2,20]   abs_p_2_20  1
    a[2,20]   abs_m_2_20  1
    a[2,20]   true_G_epigraph  1
    a[2,20]   physical_G_upper  1
    a[2,21]   abs_p_2_21  1
    a[2,21]   abs_m_2_21  1
    a[2,21]   true_G_epigraph  1
    a[2,21]   physical_G_upper  1
    a[2,22]   abs_p_2_22  1
    a[2,22]   abs_m_2_22  1
    a[2,22]   true_G_epigraph  1
    a[2,22]   physical_G_upper  1
    a[2,23]   abs_p_2_23  1
    a[2,23]   abs_m_2_23  1
    a[2,23]   true_G_epigraph  1
    a[2,23]   physical_G_upper  1
    a[2,24]   abs_p_2_24  1
    a[2,24]   abs_m_2_24  1
    a[2,24]   true_G_epigraph  1
    a[2,24]   physical_G_upper  1
    a[2,25]   abs_p_2_25  1
    a[2,25]   abs_m_2_25  1
    a[2,25]   true_G_epigraph  1
    a[2,25]   physical_G_upper  1
    a[2,26]   abs_p_2_26  1
    a[2,26]   abs_m_2_26  1
    a[2,26]   true_G_epigraph  1
    a[2,26]   physical_G_upper  1
    a[2,27]   abs_p_2_27  1
    a[2,27]   abs_m_2_27  1
    a[2,27]   true_G_epigraph  1
    a[2,27]   physical_G_upper  1
    a[2,28]   abs_p_2_28  1
    a[2,28]   abs_m_2_28  1
    a[2,28]   true_G_epigraph  1
    a[2,28]   physical_G_upper  1
    a[2,29]   abs_p_2_29  1
    a[2,29]   abs_m_2_29  1
    a[2,29]   true_G_epigraph  1
    a[2,29]   physical_G_upper  1
    a[2,30]   abs_p_2_30  1
    a[2,30]   abs_m_2_30  1
    a[2,30]   true_G_epigraph  1
    a[2,30]   physical_G_upper  1
    a[2,31]   abs_p_2_31  1
    a[2,31]   abs_m_2_31  1
    a[2,31]   true_G_epigraph  1
    a[2,31]   physical_G_upper  1
    a[2,32]   abs_p_2_32  1
    a[2,32]   abs_m_2_32  1
    a[2,32]   true_G_epigraph  1
    a[2,32]   physical_G_upper  1
    a[2,33]   abs_p_2_33  1
    a[2,33]   abs_m_2_33  1
    a[2,33]   true_G_epigraph  1
    a[2,33]   physical_G_upper  1
    a[2,34]   abs_p_2_34  1
    a[2,34]   abs_m_2_34  1
    a[2,34]   true_G_epigraph  1
    a[2,34]   physical_G_upper  1
    a[2,35]   abs_p_2_35  1
    a[2,35]   abs_m_2_35  1
    a[2,35]   true_G_epigraph  1
    a[2,35]   physical_G_upper  1
    a[3,4]    abs_p_3_4  1
    a[3,4]    abs_m_3_4  1
    a[3,4]    true_G_epigraph  1
    a[3,4]    physical_G_upper  1
    a[3,5]    abs_p_3_5  1
    a[3,5]    abs_m_3_5  1
    a[3,5]    true_G_epigraph  1
    a[3,5]    physical_G_upper  1
    a[3,6]    abs_p_3_6  1
    a[3,6]    abs_m_3_6  1
    a[3,6]    true_G_epigraph  1
    a[3,6]    physical_G_upper  1
    a[3,7]    abs_p_3_7  1
    a[3,7]    abs_m_3_7  1
    a[3,7]    true_G_epigraph  1
    a[3,7]    physical_G_upper  1
    a[3,8]    abs_p_3_8  1
    a[3,8]    abs_m_3_8  1
    a[3,8]    true_G_epigraph  1
    a[3,8]    physical_G_upper  1
    a[3,9]    abs_p_3_9  1
    a[3,9]    abs_m_3_9  1
    a[3,9]    true_G_epigraph  1
    a[3,9]    physical_G_upper  1
    a[3,10]   abs_p_3_10  1
    a[3,10]   abs_m_3_10  1
    a[3,10]   true_G_epigraph  1
    a[3,10]   physical_G_upper  1
    a[3,11]   abs_p_3_11  1
    a[3,11]   abs_m_3_11  1
    a[3,11]   true_G_epigraph  1
    a[3,11]   physical_G_upper  1
    a[3,12]   abs_p_3_12  1
    a[3,12]   abs_m_3_12  1
    a[3,12]   true_G_epigraph  1
    a[3,12]   physical_G_upper  1
    a[3,13]   abs_p_3_13  1
    a[3,13]   abs_m_3_13  1
    a[3,13]   true_G_epigraph  1
    a[3,13]   physical_G_upper  1
    a[3,14]   abs_p_3_14  1
    a[3,14]   abs_m_3_14  1
    a[3,14]   true_G_epigraph  1
    a[3,14]   physical_G_upper  1
    a[3,15]   abs_p_3_15  1
    a[3,15]   abs_m_3_15  1
    a[3,15]   true_G_epigraph  1
    a[3,15]   physical_G_upper  1
    a[3,16]   abs_p_3_16  1
    a[3,16]   abs_m_3_16  1
    a[3,16]   true_G_epigraph  1
    a[3,16]   physical_G_upper  1
    a[3,17]   abs_p_3_17  1
    a[3,17]   abs_m_3_17  1
    a[3,17]   true_G_epigraph  1
    a[3,17]   physical_G_upper  1
    a[3,18]   abs_p_3_18  1
    a[3,18]   abs_m_3_18  1
    a[3,18]   true_G_epigraph  1
    a[3,18]   physical_G_upper  1
    a[3,19]   abs_p_3_19  1
    a[3,19]   abs_m_3_19  1
    a[3,19]   true_G_epigraph  1
    a[3,19]   physical_G_upper  1
    a[3,20]   abs_p_3_20  1
    a[3,20]   abs_m_3_20  1
    a[3,20]   true_G_epigraph  1
    a[3,20]   physical_G_upper  1
    a[3,21]   abs_p_3_21  1
    a[3,21]   abs_m_3_21  1
    a[3,21]   true_G_epigraph  1
    a[3,21]   physical_G_upper  1
    a[3,22]   abs_p_3_22  1
    a[3,22]   abs_m_3_22  1
    a[3,22]   true_G_epigraph  1
    a[3,22]   physical_G_upper  1
    a[3,23]   abs_p_3_23  1
    a[3,23]   abs_m_3_23  1
    a[3,23]   true_G_epigraph  1
    a[3,23]   physical_G_upper  1
    a[3,24]   abs_p_3_24  1
    a[3,24]   abs_m_3_24  1
    a[3,24]   true_G_epigraph  1
    a[3,24]   physical_G_upper  1
    a[3,25]   abs_p_3_25  1
    a[3,25]   abs_m_3_25  1
    a[3,25]   true_G_epigraph  1
    a[3,25]   physical_G_upper  1
    a[3,26]   abs_p_3_26  1
    a[3,26]   abs_m_3_26  1
    a[3,26]   true_G_epigraph  1
    a[3,26]   physical_G_upper  1
    a[3,27]   abs_p_3_27  1
    a[3,27]   abs_m_3_27  1
    a[3,27]   true_G_epigraph  1
    a[3,27]   physical_G_upper  1
    a[3,28]   abs_p_3_28  1
    a[3,28]   abs_m_3_28  1
    a[3,28]   true_G_epigraph  1
    a[3,28]   physical_G_upper  1
    a[3,29]   abs_p_3_29  1
    a[3,29]   abs_m_3_29  1
    a[3,29]   true_G_epigraph  1
    a[3,29]   physical_G_upper  1
    a[3,30]   abs_p_3_30  1
    a[3,30]   abs_m_3_30  1
    a[3,30]   true_G_epigraph  1
    a[3,30]   physical_G_upper  1
    a[3,31]   abs_p_3_31  1
    a[3,31]   abs_m_3_31  1
    a[3,31]   true_G_epigraph  1
    a[3,31]   physical_G_upper  1
    a[3,32]   abs_p_3_32  1
    a[3,32]   abs_m_3_32  1
    a[3,32]   true_G_epigraph  1
    a[3,32]   physical_G_upper  1
    a[3,33]   abs_p_3_33  1
    a[3,33]   abs_m_3_33  1
    a[3,33]   true_G_epigraph  1
    a[3,33]   physical_G_upper  1
    a[3,34]   abs_p_3_34  1
    a[3,34]   abs_m_3_34  1
    a[3,34]   true_G_epigraph  1
    a[3,34]   physical_G_upper  1
    a[3,35]   abs_p_3_35  1
    a[3,35]   abs_m_3_35  1
    a[3,35]   true_G_epigraph  1
    a[3,35]   physical_G_upper  1
    a[4,5]    abs_p_4_5  1
    a[4,5]    abs_m_4_5  1
    a[4,5]    true_G_epigraph  1
    a[4,5]    physical_G_upper  1
    a[4,6]    abs_p_4_6  1
    a[4,6]    abs_m_4_6  1
    a[4,6]    true_G_epigraph  1
    a[4,6]    physical_G_upper  1
    a[4,7]    abs_p_4_7  1
    a[4,7]    abs_m_4_7  1
    a[4,7]    true_G_epigraph  1
    a[4,7]    physical_G_upper  1
    a[4,8]    abs_p_4_8  1
    a[4,8]    abs_m_4_8  1
    a[4,8]    true_G_epigraph  1
    a[4,8]    physical_G_upper  1
    a[4,9]    abs_p_4_9  1
    a[4,9]    abs_m_4_9  1
    a[4,9]    true_G_epigraph  1
    a[4,9]    physical_G_upper  1
    a[4,10]   abs_p_4_10  1
    a[4,10]   abs_m_4_10  1
    a[4,10]   true_G_epigraph  1
    a[4,10]   physical_G_upper  1
    a[4,11]   abs_p_4_11  1
    a[4,11]   abs_m_4_11  1
    a[4,11]   true_G_epigraph  1
    a[4,11]   physical_G_upper  1
    a[4,12]   abs_p_4_12  1
    a[4,12]   abs_m_4_12  1
    a[4,12]   true_G_epigraph  1
    a[4,12]   physical_G_upper  1
    a[4,13]   abs_p_4_13  1
    a[4,13]   abs_m_4_13  1
    a[4,13]   true_G_epigraph  1
    a[4,13]   physical_G_upper  1
    a[4,14]   abs_p_4_14  1
    a[4,14]   abs_m_4_14  1
    a[4,14]   true_G_epigraph  1
    a[4,14]   physical_G_upper  1
    a[4,15]   abs_p_4_15  1
    a[4,15]   abs_m_4_15  1
    a[4,15]   true_G_epigraph  1
    a[4,15]   physical_G_upper  1
    a[4,16]   abs_p_4_16  1
    a[4,16]   abs_m_4_16  1
    a[4,16]   true_G_epigraph  1
    a[4,16]   physical_G_upper  1
    a[4,17]   abs_p_4_17  1
    a[4,17]   abs_m_4_17  1
    a[4,17]   true_G_epigraph  1
    a[4,17]   physical_G_upper  1
    a[4,18]   abs_p_4_18  1
    a[4,18]   abs_m_4_18  1
    a[4,18]   true_G_epigraph  1
    a[4,18]   physical_G_upper  1
    a[4,19]   abs_p_4_19  1
    a[4,19]   abs_m_4_19  1
    a[4,19]   true_G_epigraph  1
    a[4,19]   physical_G_upper  1
    a[4,20]   abs_p_4_20  1
    a[4,20]   abs_m_4_20  1
    a[4,20]   true_G_epigraph  1
    a[4,20]   physical_G_upper  1
    a[4,21]   abs_p_4_21  1
    a[4,21]   abs_m_4_21  1
    a[4,21]   true_G_epigraph  1
    a[4,21]   physical_G_upper  1
    a[4,22]   abs_p_4_22  1
    a[4,22]   abs_m_4_22  1
    a[4,22]   true_G_epigraph  1
    a[4,22]   physical_G_upper  1
    a[4,23]   abs_p_4_23  1
    a[4,23]   abs_m_4_23  1
    a[4,23]   true_G_epigraph  1
    a[4,23]   physical_G_upper  1
    a[4,24]   abs_p_4_24  1
    a[4,24]   abs_m_4_24  1
    a[4,24]   true_G_epigraph  1
    a[4,24]   physical_G_upper  1
    a[4,25]   abs_p_4_25  1
    a[4,25]   abs_m_4_25  1
    a[4,25]   true_G_epigraph  1
    a[4,25]   physical_G_upper  1
    a[4,26]   abs_p_4_26  1
    a[4,26]   abs_m_4_26  1
    a[4,26]   true_G_epigraph  1
    a[4,26]   physical_G_upper  1
    a[4,27]   abs_p_4_27  1
    a[4,27]   abs_m_4_27  1
    a[4,27]   true_G_epigraph  1
    a[4,27]   physical_G_upper  1
    a[4,28]   abs_p_4_28  1
    a[4,28]   abs_m_4_28  1
    a[4,28]   true_G_epigraph  1
    a[4,28]   physical_G_upper  1
    a[4,29]   abs_p_4_29  1
    a[4,29]   abs_m_4_29  1
    a[4,29]   true_G_epigraph  1
    a[4,29]   physical_G_upper  1
    a[4,30]   abs_p_4_30  1
    a[4,30]   abs_m_4_30  1
    a[4,30]   true_G_epigraph  1
    a[4,30]   physical_G_upper  1
    a[4,31]   abs_p_4_31  1
    a[4,31]   abs_m_4_31  1
    a[4,31]   true_G_epigraph  1
    a[4,31]   physical_G_upper  1
    a[4,32]   abs_p_4_32  1
    a[4,32]   abs_m_4_32  1
    a[4,32]   true_G_epigraph  1
    a[4,32]   physical_G_upper  1
    a[4,33]   abs_p_4_33  1
    a[4,33]   abs_m_4_33  1
    a[4,33]   true_G_epigraph  1
    a[4,33]   physical_G_upper  1
    a[4,34]   abs_p_4_34  1
    a[4,34]   abs_m_4_34  1
    a[4,34]   true_G_epigraph  1
    a[4,34]   physical_G_upper  1
    a[4,35]   abs_p_4_35  1
    a[4,35]   abs_m_4_35  1
    a[4,35]   true_G_epigraph  1
    a[4,35]   physical_G_upper  1
    a[5,6]    abs_p_5_6  1
    a[5,6]    abs_m_5_6  1
    a[5,6]    true_G_epigraph  1
    a[5,6]    physical_G_upper  1
    a[5,7]    abs_p_5_7  1
    a[5,7]    abs_m_5_7  1
    a[5,7]    true_G_epigraph  1
    a[5,7]    physical_G_upper  1
    a[5,8]    abs_p_5_8  1
    a[5,8]    abs_m_5_8  1
    a[5,8]    true_G_epigraph  1
    a[5,8]    physical_G_upper  1
    a[5,9]    abs_p_5_9  1
    a[5,9]    abs_m_5_9  1
    a[5,9]    true_G_epigraph  1
    a[5,9]    physical_G_upper  1
    a[5,10]   abs_p_5_10  1
    a[5,10]   abs_m_5_10  1
    a[5,10]   true_G_epigraph  1
    a[5,10]   physical_G_upper  1
    a[5,11]   abs_p_5_11  1
    a[5,11]   abs_m_5_11  1
    a[5,11]   true_G_epigraph  1
    a[5,11]   physical_G_upper  1
    a[5,12]   abs_p_5_12  1
    a[5,12]   abs_m_5_12  1
    a[5,12]   true_G_epigraph  1
    a[5,12]   physical_G_upper  1
    a[5,13]   abs_p_5_13  1
    a[5,13]   abs_m_5_13  1
    a[5,13]   true_G_epigraph  1
    a[5,13]   physical_G_upper  1
    a[5,14]   abs_p_5_14  1
    a[5,14]   abs_m_5_14  1
    a[5,14]   true_G_epigraph  1
    a[5,14]   physical_G_upper  1
    a[5,15]   abs_p_5_15  1
    a[5,15]   abs_m_5_15  1
    a[5,15]   true_G_epigraph  1
    a[5,15]   physical_G_upper  1
    a[5,16]   abs_p_5_16  1
    a[5,16]   abs_m_5_16  1
    a[5,16]   true_G_epigraph  1
    a[5,16]   physical_G_upper  1
    a[5,17]   abs_p_5_17  1
    a[5,17]   abs_m_5_17  1
    a[5,17]   true_G_epigraph  1
    a[5,17]   physical_G_upper  1
    a[5,18]   abs_p_5_18  1
    a[5,18]   abs_m_5_18  1
    a[5,18]   true_G_epigraph  1
    a[5,18]   physical_G_upper  1
    a[5,19]   abs_p_5_19  1
    a[5,19]   abs_m_5_19  1
    a[5,19]   true_G_epigraph  1
    a[5,19]   physical_G_upper  1
    a[5,20]   abs_p_5_20  1
    a[5,20]   abs_m_5_20  1
    a[5,20]   true_G_epigraph  1
    a[5,20]   physical_G_upper  1
    a[5,21]   abs_p_5_21  1
    a[5,21]   abs_m_5_21  1
    a[5,21]   true_G_epigraph  1
    a[5,21]   physical_G_upper  1
    a[5,22]   abs_p_5_22  1
    a[5,22]   abs_m_5_22  1
    a[5,22]   true_G_epigraph  1
    a[5,22]   physical_G_upper  1
    a[5,23]   abs_p_5_23  1
    a[5,23]   abs_m_5_23  1
    a[5,23]   true_G_epigraph  1
    a[5,23]   physical_G_upper  1
    a[5,24]   abs_p_5_24  1
    a[5,24]   abs_m_5_24  1
    a[5,24]   true_G_epigraph  1
    a[5,24]   physical_G_upper  1
    a[5,25]   abs_p_5_25  1
    a[5,25]   abs_m_5_25  1
    a[5,25]   true_G_epigraph  1
    a[5,25]   physical_G_upper  1
    a[5,26]   abs_p_5_26  1
    a[5,26]   abs_m_5_26  1
    a[5,26]   true_G_epigraph  1
    a[5,26]   physical_G_upper  1
    a[5,27]   abs_p_5_27  1
    a[5,27]   abs_m_5_27  1
    a[5,27]   true_G_epigraph  1
    a[5,27]   physical_G_upper  1
    a[5,28]   abs_p_5_28  1
    a[5,28]   abs_m_5_28  1
    a[5,28]   true_G_epigraph  1
    a[5,28]   physical_G_upper  1
    a[5,29]   abs_p_5_29  1
    a[5,29]   abs_m_5_29  1
    a[5,29]   true_G_epigraph  1
    a[5,29]   physical_G_upper  1
    a[5,30]   abs_p_5_30  1
    a[5,30]   abs_m_5_30  1
    a[5,30]   true_G_epigraph  1
    a[5,30]   physical_G_upper  1
    a[5,31]   abs_p_5_31  1
    a[5,31]   abs_m_5_31  1
    a[5,31]   true_G_epigraph  1
    a[5,31]   physical_G_upper  1
    a[5,32]   abs_p_5_32  1
    a[5,32]   abs_m_5_32  1
    a[5,32]   true_G_epigraph  1
    a[5,32]   physical_G_upper  1
    a[5,33]   abs_p_5_33  1
    a[5,33]   abs_m_5_33  1
    a[5,33]   true_G_epigraph  1
    a[5,33]   physical_G_upper  1
    a[5,34]   abs_p_5_34  1
    a[5,34]   abs_m_5_34  1
    a[5,34]   true_G_epigraph  1
    a[5,34]   physical_G_upper  1
    a[5,35]   abs_p_5_35  1
    a[5,35]   abs_m_5_35  1
    a[5,35]   true_G_epigraph  1
    a[5,35]   physical_G_upper  1
    a[6,7]    abs_p_6_7  1
    a[6,7]    abs_m_6_7  1
    a[6,7]    true_G_epigraph  1
    a[6,7]    physical_G_upper  1
    a[6,8]    abs_p_6_8  1
    a[6,8]    abs_m_6_8  1
    a[6,8]    true_G_epigraph  1
    a[6,8]    physical_G_upper  1
    a[6,9]    abs_p_6_9  1
    a[6,9]    abs_m_6_9  1
    a[6,9]    true_G_epigraph  1
    a[6,9]    physical_G_upper  1
    a[6,10]   abs_p_6_10  1
    a[6,10]   abs_m_6_10  1
    a[6,10]   true_G_epigraph  1
    a[6,10]   physical_G_upper  1
    a[6,11]   abs_p_6_11  1
    a[6,11]   abs_m_6_11  1
    a[6,11]   true_G_epigraph  1
    a[6,11]   physical_G_upper  1
    a[6,12]   abs_p_6_12  1
    a[6,12]   abs_m_6_12  1
    a[6,12]   true_G_epigraph  1
    a[6,12]   physical_G_upper  1
    a[6,13]   abs_p_6_13  1
    a[6,13]   abs_m_6_13  1
    a[6,13]   true_G_epigraph  1
    a[6,13]   physical_G_upper  1
    a[6,14]   abs_p_6_14  1
    a[6,14]   abs_m_6_14  1
    a[6,14]   true_G_epigraph  1
    a[6,14]   physical_G_upper  1
    a[6,15]   abs_p_6_15  1
    a[6,15]   abs_m_6_15  1
    a[6,15]   true_G_epigraph  1
    a[6,15]   physical_G_upper  1
    a[6,16]   abs_p_6_16  1
    a[6,16]   abs_m_6_16  1
    a[6,16]   true_G_epigraph  1
    a[6,16]   physical_G_upper  1
    a[6,17]   abs_p_6_17  1
    a[6,17]   abs_m_6_17  1
    a[6,17]   true_G_epigraph  1
    a[6,17]   physical_G_upper  1
    a[6,18]   abs_p_6_18  1
    a[6,18]   abs_m_6_18  1
    a[6,18]   true_G_epigraph  1
    a[6,18]   physical_G_upper  1
    a[6,19]   abs_p_6_19  1
    a[6,19]   abs_m_6_19  1
    a[6,19]   true_G_epigraph  1
    a[6,19]   physical_G_upper  1
    a[6,20]   abs_p_6_20  1
    a[6,20]   abs_m_6_20  1
    a[6,20]   true_G_epigraph  1
    a[6,20]   physical_G_upper  1
    a[6,21]   abs_p_6_21  1
    a[6,21]   abs_m_6_21  1
    a[6,21]   true_G_epigraph  1
    a[6,21]   physical_G_upper  1
    a[6,22]   abs_p_6_22  1
    a[6,22]   abs_m_6_22  1
    a[6,22]   true_G_epigraph  1
    a[6,22]   physical_G_upper  1
    a[6,23]   abs_p_6_23  1
    a[6,23]   abs_m_6_23  1
    a[6,23]   true_G_epigraph  1
    a[6,23]   physical_G_upper  1
    a[6,24]   abs_p_6_24  1
    a[6,24]   abs_m_6_24  1
    a[6,24]   true_G_epigraph  1
    a[6,24]   physical_G_upper  1
    a[6,25]   abs_p_6_25  1
    a[6,25]   abs_m_6_25  1
    a[6,25]   true_G_epigraph  1
    a[6,25]   physical_G_upper  1
    a[6,26]   abs_p_6_26  1
    a[6,26]   abs_m_6_26  1
    a[6,26]   true_G_epigraph  1
    a[6,26]   physical_G_upper  1
    a[6,27]   abs_p_6_27  1
    a[6,27]   abs_m_6_27  1
    a[6,27]   true_G_epigraph  1
    a[6,27]   physical_G_upper  1
    a[6,28]   abs_p_6_28  1
    a[6,28]   abs_m_6_28  1
    a[6,28]   true_G_epigraph  1
    a[6,28]   physical_G_upper  1
    a[6,29]   abs_p_6_29  1
    a[6,29]   abs_m_6_29  1
    a[6,29]   true_G_epigraph  1
    a[6,29]   physical_G_upper  1
    a[6,30]   abs_p_6_30  1
    a[6,30]   abs_m_6_30  1
    a[6,30]   true_G_epigraph  1
    a[6,30]   physical_G_upper  1
    a[6,31]   abs_p_6_31  1
    a[6,31]   abs_m_6_31  1
    a[6,31]   true_G_epigraph  1
    a[6,31]   physical_G_upper  1
    a[6,32]   abs_p_6_32  1
    a[6,32]   abs_m_6_32  1
    a[6,32]   true_G_epigraph  1
    a[6,32]   physical_G_upper  1
    a[6,33]   abs_p_6_33  1
    a[6,33]   abs_m_6_33  1
    a[6,33]   true_G_epigraph  1
    a[6,33]   physical_G_upper  1
    a[6,34]   abs_p_6_34  1
    a[6,34]   abs_m_6_34  1
    a[6,34]   true_G_epigraph  1
    a[6,34]   physical_G_upper  1
    a[6,35]   abs_p_6_35  1
    a[6,35]   abs_m_6_35  1
    a[6,35]   true_G_epigraph  1
    a[6,35]   physical_G_upper  1
    a[7,8]    abs_p_7_8  1
    a[7,8]    abs_m_7_8  1
    a[7,8]    true_G_epigraph  1
    a[7,8]    physical_G_upper  1
    a[7,9]    abs_p_7_9  1
    a[7,9]    abs_m_7_9  1
    a[7,9]    true_G_epigraph  1
    a[7,9]    physical_G_upper  1
    a[7,10]   abs_p_7_10  1
    a[7,10]   abs_m_7_10  1
    a[7,10]   true_G_epigraph  1
    a[7,10]   physical_G_upper  1
    a[7,11]   abs_p_7_11  1
    a[7,11]   abs_m_7_11  1
    a[7,11]   true_G_epigraph  1
    a[7,11]   physical_G_upper  1
    a[7,12]   abs_p_7_12  1
    a[7,12]   abs_m_7_12  1
    a[7,12]   true_G_epigraph  1
    a[7,12]   physical_G_upper  1
    a[7,13]   abs_p_7_13  1
    a[7,13]   abs_m_7_13  1
    a[7,13]   true_G_epigraph  1
    a[7,13]   physical_G_upper  1
    a[7,14]   abs_p_7_14  1
    a[7,14]   abs_m_7_14  1
    a[7,14]   true_G_epigraph  1
    a[7,14]   physical_G_upper  1
    a[7,15]   abs_p_7_15  1
    a[7,15]   abs_m_7_15  1
    a[7,15]   true_G_epigraph  1
    a[7,15]   physical_G_upper  1
    a[7,16]   abs_p_7_16  1
    a[7,16]   abs_m_7_16  1
    a[7,16]   true_G_epigraph  1
    a[7,16]   physical_G_upper  1
    a[7,17]   abs_p_7_17  1
    a[7,17]   abs_m_7_17  1
    a[7,17]   true_G_epigraph  1
    a[7,17]   physical_G_upper  1
    a[7,18]   abs_p_7_18  1
    a[7,18]   abs_m_7_18  1
    a[7,18]   true_G_epigraph  1
    a[7,18]   physical_G_upper  1
    a[7,19]   abs_p_7_19  1
    a[7,19]   abs_m_7_19  1
    a[7,19]   true_G_epigraph  1
    a[7,19]   physical_G_upper  1
    a[7,20]   abs_p_7_20  1
    a[7,20]   abs_m_7_20  1
    a[7,20]   true_G_epigraph  1
    a[7,20]   physical_G_upper  1
    a[7,21]   abs_p_7_21  1
    a[7,21]   abs_m_7_21  1
    a[7,21]   true_G_epigraph  1
    a[7,21]   physical_G_upper  1
    a[7,22]   abs_p_7_22  1
    a[7,22]   abs_m_7_22  1
    a[7,22]   true_G_epigraph  1
    a[7,22]   physical_G_upper  1
    a[7,23]   abs_p_7_23  1
    a[7,23]   abs_m_7_23  1
    a[7,23]   true_G_epigraph  1
    a[7,23]   physical_G_upper  1
    a[7,24]   abs_p_7_24  1
    a[7,24]   abs_m_7_24  1
    a[7,24]   true_G_epigraph  1
    a[7,24]   physical_G_upper  1
    a[7,25]   abs_p_7_25  1
    a[7,25]   abs_m_7_25  1
    a[7,25]   true_G_epigraph  1
    a[7,25]   physical_G_upper  1
    a[7,26]   abs_p_7_26  1
    a[7,26]   abs_m_7_26  1
    a[7,26]   true_G_epigraph  1
    a[7,26]   physical_G_upper  1
    a[7,27]   abs_p_7_27  1
    a[7,27]   abs_m_7_27  1
    a[7,27]   true_G_epigraph  1
    a[7,27]   physical_G_upper  1
    a[7,28]   abs_p_7_28  1
    a[7,28]   abs_m_7_28  1
    a[7,28]   true_G_epigraph  1
    a[7,28]   physical_G_upper  1
    a[7,29]   abs_p_7_29  1
    a[7,29]   abs_m_7_29  1
    a[7,29]   true_G_epigraph  1
    a[7,29]   physical_G_upper  1
    a[7,30]   abs_p_7_30  1
    a[7,30]   abs_m_7_30  1
    a[7,30]   true_G_epigraph  1
    a[7,30]   physical_G_upper  1
    a[7,31]   abs_p_7_31  1
    a[7,31]   abs_m_7_31  1
    a[7,31]   true_G_epigraph  1
    a[7,31]   physical_G_upper  1
    a[7,32]   abs_p_7_32  1
    a[7,32]   abs_m_7_32  1
    a[7,32]   true_G_epigraph  1
    a[7,32]   physical_G_upper  1
    a[7,33]   abs_p_7_33  1
    a[7,33]   abs_m_7_33  1
    a[7,33]   true_G_epigraph  1
    a[7,33]   physical_G_upper  1
    a[7,34]   abs_p_7_34  1
    a[7,34]   abs_m_7_34  1
    a[7,34]   true_G_epigraph  1
    a[7,34]   physical_G_upper  1
    a[7,35]   abs_p_7_35  1
    a[7,35]   abs_m_7_35  1
    a[7,35]   true_G_epigraph  1
    a[7,35]   physical_G_upper  1
    a[8,9]    abs_p_8_9  1
    a[8,9]    abs_m_8_9  1
    a[8,9]    true_G_epigraph  1
    a[8,9]    physical_G_upper  1
    a[8,10]   abs_p_8_10  1
    a[8,10]   abs_m_8_10  1
    a[8,10]   true_G_epigraph  1
    a[8,10]   physical_G_upper  1
    a[8,11]   abs_p_8_11  1
    a[8,11]   abs_m_8_11  1
    a[8,11]   true_G_epigraph  1
    a[8,11]   physical_G_upper  1
    a[8,12]   abs_p_8_12  1
    a[8,12]   abs_m_8_12  1
    a[8,12]   true_G_epigraph  1
    a[8,12]   physical_G_upper  1
    a[8,13]   abs_p_8_13  1
    a[8,13]   abs_m_8_13  1
    a[8,13]   true_G_epigraph  1
    a[8,13]   physical_G_upper  1
    a[8,14]   abs_p_8_14  1
    a[8,14]   abs_m_8_14  1
    a[8,14]   true_G_epigraph  1
    a[8,14]   physical_G_upper  1
    a[8,15]   abs_p_8_15  1
    a[8,15]   abs_m_8_15  1
    a[8,15]   true_G_epigraph  1
    a[8,15]   physical_G_upper  1
    a[8,16]   abs_p_8_16  1
    a[8,16]   abs_m_8_16  1
    a[8,16]   true_G_epigraph  1
    a[8,16]   physical_G_upper  1
    a[8,17]   abs_p_8_17  1
    a[8,17]   abs_m_8_17  1
    a[8,17]   true_G_epigraph  1
    a[8,17]   physical_G_upper  1
    a[8,18]   abs_p_8_18  1
    a[8,18]   abs_m_8_18  1
    a[8,18]   true_G_epigraph  1
    a[8,18]   physical_G_upper  1
    a[8,19]   abs_p_8_19  1
    a[8,19]   abs_m_8_19  1
    a[8,19]   true_G_epigraph  1
    a[8,19]   physical_G_upper  1
    a[8,20]   abs_p_8_20  1
    a[8,20]   abs_m_8_20  1
    a[8,20]   true_G_epigraph  1
    a[8,20]   physical_G_upper  1
    a[8,21]   abs_p_8_21  1
    a[8,21]   abs_m_8_21  1
    a[8,21]   true_G_epigraph  1
    a[8,21]   physical_G_upper  1
    a[8,22]   abs_p_8_22  1
    a[8,22]   abs_m_8_22  1
    a[8,22]   true_G_epigraph  1
    a[8,22]   physical_G_upper  1
    a[8,23]   abs_p_8_23  1
    a[8,23]   abs_m_8_23  1
    a[8,23]   true_G_epigraph  1
    a[8,23]   physical_G_upper  1
    a[8,24]   abs_p_8_24  1
    a[8,24]   abs_m_8_24  1
    a[8,24]   true_G_epigraph  1
    a[8,24]   physical_G_upper  1
    a[8,25]   abs_p_8_25  1
    a[8,25]   abs_m_8_25  1
    a[8,25]   true_G_epigraph  1
    a[8,25]   physical_G_upper  1
    a[8,26]   abs_p_8_26  1
    a[8,26]   abs_m_8_26  1
    a[8,26]   true_G_epigraph  1
    a[8,26]   physical_G_upper  1
    a[8,27]   abs_p_8_27  1
    a[8,27]   abs_m_8_27  1
    a[8,27]   true_G_epigraph  1
    a[8,27]   physical_G_upper  1
    a[8,28]   abs_p_8_28  1
    a[8,28]   abs_m_8_28  1
    a[8,28]   true_G_epigraph  1
    a[8,28]   physical_G_upper  1
    a[8,29]   abs_p_8_29  1
    a[8,29]   abs_m_8_29  1
    a[8,29]   true_G_epigraph  1
    a[8,29]   physical_G_upper  1
    a[8,30]   abs_p_8_30  1
    a[8,30]   abs_m_8_30  1
    a[8,30]   true_G_epigraph  1
    a[8,30]   physical_G_upper  1
    a[8,31]   abs_p_8_31  1
    a[8,31]   abs_m_8_31  1
    a[8,31]   true_G_epigraph  1
    a[8,31]   physical_G_upper  1
    a[8,32]   abs_p_8_32  1
    a[8,32]   abs_m_8_32  1
    a[8,32]   true_G_epigraph  1
    a[8,32]   physical_G_upper  1
    a[8,33]   abs_p_8_33  1
    a[8,33]   abs_m_8_33  1
    a[8,33]   true_G_epigraph  1
    a[8,33]   physical_G_upper  1
    a[8,34]   abs_p_8_34  1
    a[8,34]   abs_m_8_34  1
    a[8,34]   true_G_epigraph  1
    a[8,34]   physical_G_upper  1
    a[8,35]   abs_p_8_35  1
    a[8,35]   abs_m_8_35  1
    a[8,35]   true_G_epigraph  1
    a[8,35]   physical_G_upper  1
    a[9,10]   abs_p_9_10  1
    a[9,10]   abs_m_9_10  1
    a[9,10]   true_G_epigraph  1
    a[9,10]   physical_G_upper  1
    a[9,11]   abs_p_9_11  1
    a[9,11]   abs_m_9_11  1
    a[9,11]   true_G_epigraph  1
    a[9,11]   physical_G_upper  1
    a[9,12]   abs_p_9_12  1
    a[9,12]   abs_m_9_12  1
    a[9,12]   true_G_epigraph  1
    a[9,12]   physical_G_upper  1
    a[9,13]   abs_p_9_13  1
    a[9,13]   abs_m_9_13  1
    a[9,13]   true_G_epigraph  1
    a[9,13]   physical_G_upper  1
    a[9,14]   abs_p_9_14  1
    a[9,14]   abs_m_9_14  1
    a[9,14]   true_G_epigraph  1
    a[9,14]   physical_G_upper  1
    a[9,15]   abs_p_9_15  1
    a[9,15]   abs_m_9_15  1
    a[9,15]   true_G_epigraph  1
    a[9,15]   physical_G_upper  1
    a[9,16]   abs_p_9_16  1
    a[9,16]   abs_m_9_16  1
    a[9,16]   true_G_epigraph  1
    a[9,16]   physical_G_upper  1
    a[9,17]   abs_p_9_17  1
    a[9,17]   abs_m_9_17  1
    a[9,17]   true_G_epigraph  1
    a[9,17]   physical_G_upper  1
    a[9,18]   abs_p_9_18  1
    a[9,18]   abs_m_9_18  1
    a[9,18]   true_G_epigraph  1
    a[9,18]   physical_G_upper  1
    a[9,19]   abs_p_9_19  1
    a[9,19]   abs_m_9_19  1
    a[9,19]   true_G_epigraph  1
    a[9,19]   physical_G_upper  1
    a[9,20]   abs_p_9_20  1
    a[9,20]   abs_m_9_20  1
    a[9,20]   true_G_epigraph  1
    a[9,20]   physical_G_upper  1
    a[9,21]   abs_p_9_21  1
    a[9,21]   abs_m_9_21  1
    a[9,21]   true_G_epigraph  1
    a[9,21]   physical_G_upper  1
    a[9,22]   abs_p_9_22  1
    a[9,22]   abs_m_9_22  1
    a[9,22]   true_G_epigraph  1
    a[9,22]   physical_G_upper  1
    a[9,23]   abs_p_9_23  1
    a[9,23]   abs_m_9_23  1
    a[9,23]   true_G_epigraph  1
    a[9,23]   physical_G_upper  1
    a[9,24]   abs_p_9_24  1
    a[9,24]   abs_m_9_24  1
    a[9,24]   true_G_epigraph  1
    a[9,24]   physical_G_upper  1
    a[9,25]   abs_p_9_25  1
    a[9,25]   abs_m_9_25  1
    a[9,25]   true_G_epigraph  1
    a[9,25]   physical_G_upper  1
    a[9,26]   abs_p_9_26  1
    a[9,26]   abs_m_9_26  1
    a[9,26]   true_G_epigraph  1
    a[9,26]   physical_G_upper  1
    a[9,27]   abs_p_9_27  1
    a[9,27]   abs_m_9_27  1
    a[9,27]   true_G_epigraph  1
    a[9,27]   physical_G_upper  1
    a[9,28]   abs_p_9_28  1
    a[9,28]   abs_m_9_28  1
    a[9,28]   true_G_epigraph  1
    a[9,28]   physical_G_upper  1
    a[9,29]   abs_p_9_29  1
    a[9,29]   abs_m_9_29  1
    a[9,29]   true_G_epigraph  1
    a[9,29]   physical_G_upper  1
    a[9,30]   abs_p_9_30  1
    a[9,30]   abs_m_9_30  1
    a[9,30]   true_G_epigraph  1
    a[9,30]   physical_G_upper  1
    a[9,31]   abs_p_9_31  1
    a[9,31]   abs_m_9_31  1
    a[9,31]   true_G_epigraph  1
    a[9,31]   physical_G_upper  1
    a[9,32]   abs_p_9_32  1
    a[9,32]   abs_m_9_32  1
    a[9,32]   true_G_epigraph  1
    a[9,32]   physical_G_upper  1
    a[9,33]   abs_p_9_33  1
    a[9,33]   abs_m_9_33  1
    a[9,33]   true_G_epigraph  1
    a[9,33]   physical_G_upper  1
    a[9,34]   abs_p_9_34  1
    a[9,34]   abs_m_9_34  1
    a[9,34]   true_G_epigraph  1
    a[9,34]   physical_G_upper  1
    a[9,35]   abs_p_9_35  1
    a[9,35]   abs_m_9_35  1
    a[9,35]   true_G_epigraph  1
    a[9,35]   physical_G_upper  1
    a[10,11]  abs_p_10_11  1
    a[10,11]  abs_m_10_11  1
    a[10,11]  true_G_epigraph  1
    a[10,11]  physical_G_upper  1
    a[10,12]  abs_p_10_12  1
    a[10,12]  abs_m_10_12  1
    a[10,12]  true_G_epigraph  1
    a[10,12]  physical_G_upper  1
    a[10,13]  abs_p_10_13  1
    a[10,13]  abs_m_10_13  1
    a[10,13]  true_G_epigraph  1
    a[10,13]  physical_G_upper  1
    a[10,14]  abs_p_10_14  1
    a[10,14]  abs_m_10_14  1
    a[10,14]  true_G_epigraph  1
    a[10,14]  physical_G_upper  1
    a[10,15]  abs_p_10_15  1
    a[10,15]  abs_m_10_15  1
    a[10,15]  true_G_epigraph  1
    a[10,15]  physical_G_upper  1
    a[10,16]  abs_p_10_16  1
    a[10,16]  abs_m_10_16  1
    a[10,16]  true_G_epigraph  1
    a[10,16]  physical_G_upper  1
    a[10,17]  abs_p_10_17  1
    a[10,17]  abs_m_10_17  1
    a[10,17]  true_G_epigraph  1
    a[10,17]  physical_G_upper  1
    a[10,18]  abs_p_10_18  1
    a[10,18]  abs_m_10_18  1
    a[10,18]  true_G_epigraph  1
    a[10,18]  physical_G_upper  1
    a[10,19]  abs_p_10_19  1
    a[10,19]  abs_m_10_19  1
    a[10,19]  true_G_epigraph  1
    a[10,19]  physical_G_upper  1
    a[10,20]  abs_p_10_20  1
    a[10,20]  abs_m_10_20  1
    a[10,20]  true_G_epigraph  1
    a[10,20]  physical_G_upper  1
    a[10,21]  abs_p_10_21  1
    a[10,21]  abs_m_10_21  1
    a[10,21]  true_G_epigraph  1
    a[10,21]  physical_G_upper  1
    a[10,22]  abs_p_10_22  1
    a[10,22]  abs_m_10_22  1
    a[10,22]  true_G_epigraph  1
    a[10,22]  physical_G_upper  1
    a[10,23]  abs_p_10_23  1
    a[10,23]  abs_m_10_23  1
    a[10,23]  true_G_epigraph  1
    a[10,23]  physical_G_upper  1
    a[10,24]  abs_p_10_24  1
    a[10,24]  abs_m_10_24  1
    a[10,24]  true_G_epigraph  1
    a[10,24]  physical_G_upper  1
    a[10,25]  abs_p_10_25  1
    a[10,25]  abs_m_10_25  1
    a[10,25]  true_G_epigraph  1
    a[10,25]  physical_G_upper  1
    a[10,26]  abs_p_10_26  1
    a[10,26]  abs_m_10_26  1
    a[10,26]  true_G_epigraph  1
    a[10,26]  physical_G_upper  1
    a[10,27]  abs_p_10_27  1
    a[10,27]  abs_m_10_27  1
    a[10,27]  true_G_epigraph  1
    a[10,27]  physical_G_upper  1
    a[10,28]  abs_p_10_28  1
    a[10,28]  abs_m_10_28  1
    a[10,28]  true_G_epigraph  1
    a[10,28]  physical_G_upper  1
    a[10,29]  abs_p_10_29  1
    a[10,29]  abs_m_10_29  1
    a[10,29]  true_G_epigraph  1
    a[10,29]  physical_G_upper  1
    a[10,30]  abs_p_10_30  1
    a[10,30]  abs_m_10_30  1
    a[10,30]  true_G_epigraph  1
    a[10,30]  physical_G_upper  1
    a[10,31]  abs_p_10_31  1
    a[10,31]  abs_m_10_31  1
    a[10,31]  true_G_epigraph  1
    a[10,31]  physical_G_upper  1
    a[10,32]  abs_p_10_32  1
    a[10,32]  abs_m_10_32  1
    a[10,32]  true_G_epigraph  1
    a[10,32]  physical_G_upper  1
    a[10,33]  abs_p_10_33  1
    a[10,33]  abs_m_10_33  1
    a[10,33]  true_G_epigraph  1
    a[10,33]  physical_G_upper  1
    a[10,34]  abs_p_10_34  1
    a[10,34]  abs_m_10_34  1
    a[10,34]  true_G_epigraph  1
    a[10,34]  physical_G_upper  1
    a[10,35]  abs_p_10_35  1
    a[10,35]  abs_m_10_35  1
    a[10,35]  true_G_epigraph  1
    a[10,35]  physical_G_upper  1
    a[11,12]  abs_p_11_12  1
    a[11,12]  abs_m_11_12  1
    a[11,12]  true_G_epigraph  1
    a[11,12]  physical_G_upper  1
    a[11,13]  abs_p_11_13  1
    a[11,13]  abs_m_11_13  1
    a[11,13]  true_G_epigraph  1
    a[11,13]  physical_G_upper  1
    a[11,14]  abs_p_11_14  1
    a[11,14]  abs_m_11_14  1
    a[11,14]  true_G_epigraph  1
    a[11,14]  physical_G_upper  1
    a[11,15]  abs_p_11_15  1
    a[11,15]  abs_m_11_15  1
    a[11,15]  true_G_epigraph  1
    a[11,15]  physical_G_upper  1
    a[11,16]  abs_p_11_16  1
    a[11,16]  abs_m_11_16  1
    a[11,16]  true_G_epigraph  1
    a[11,16]  physical_G_upper  1
    a[11,17]  abs_p_11_17  1
    a[11,17]  abs_m_11_17  1
    a[11,17]  true_G_epigraph  1
    a[11,17]  physical_G_upper  1
    a[11,18]  abs_p_11_18  1
    a[11,18]  abs_m_11_18  1
    a[11,18]  true_G_epigraph  1
    a[11,18]  physical_G_upper  1
    a[11,19]  abs_p_11_19  1
    a[11,19]  abs_m_11_19  1
    a[11,19]  true_G_epigraph  1
    a[11,19]  physical_G_upper  1
    a[11,20]  abs_p_11_20  1
    a[11,20]  abs_m_11_20  1
    a[11,20]  true_G_epigraph  1
    a[11,20]  physical_G_upper  1
    a[11,21]  abs_p_11_21  1
    a[11,21]  abs_m_11_21  1
    a[11,21]  true_G_epigraph  1
    a[11,21]  physical_G_upper  1
    a[11,22]  abs_p_11_22  1
    a[11,22]  abs_m_11_22  1
    a[11,22]  true_G_epigraph  1
    a[11,22]  physical_G_upper  1
    a[11,23]  abs_p_11_23  1
    a[11,23]  abs_m_11_23  1
    a[11,23]  true_G_epigraph  1
    a[11,23]  physical_G_upper  1
    a[11,24]  abs_p_11_24  1
    a[11,24]  abs_m_11_24  1
    a[11,24]  true_G_epigraph  1
    a[11,24]  physical_G_upper  1
    a[11,25]  abs_p_11_25  1
    a[11,25]  abs_m_11_25  1
    a[11,25]  true_G_epigraph  1
    a[11,25]  physical_G_upper  1
    a[11,26]  abs_p_11_26  1
    a[11,26]  abs_m_11_26  1
    a[11,26]  true_G_epigraph  1
    a[11,26]  physical_G_upper  1
    a[11,27]  abs_p_11_27  1
    a[11,27]  abs_m_11_27  1
    a[11,27]  true_G_epigraph  1
    a[11,27]  physical_G_upper  1
    a[11,28]  abs_p_11_28  1
    a[11,28]  abs_m_11_28  1
    a[11,28]  true_G_epigraph  1
    a[11,28]  physical_G_upper  1
    a[11,29]  abs_p_11_29  1
    a[11,29]  abs_m_11_29  1
    a[11,29]  true_G_epigraph  1
    a[11,29]  physical_G_upper  1
    a[11,30]  abs_p_11_30  1
    a[11,30]  abs_m_11_30  1
    a[11,30]  true_G_epigraph  1
    a[11,30]  physical_G_upper  1
    a[11,31]  abs_p_11_31  1
    a[11,31]  abs_m_11_31  1
    a[11,31]  true_G_epigraph  1
    a[11,31]  physical_G_upper  1
    a[11,32]  abs_p_11_32  1
    a[11,32]  abs_m_11_32  1
    a[11,32]  true_G_epigraph  1
    a[11,32]  physical_G_upper  1
    a[11,33]  abs_p_11_33  1
    a[11,33]  abs_m_11_33  1
    a[11,33]  true_G_epigraph  1
    a[11,33]  physical_G_upper  1
    a[11,34]  abs_p_11_34  1
    a[11,34]  abs_m_11_34  1
    a[11,34]  true_G_epigraph  1
    a[11,34]  physical_G_upper  1
    a[11,35]  abs_p_11_35  1
    a[11,35]  abs_m_11_35  1
    a[11,35]  true_G_epigraph  1
    a[11,35]  physical_G_upper  1
    a[12,13]  abs_p_12_13  1
    a[12,13]  abs_m_12_13  1
    a[12,13]  true_G_epigraph  1
    a[12,13]  physical_G_upper  1
    a[12,14]  abs_p_12_14  1
    a[12,14]  abs_m_12_14  1
    a[12,14]  true_G_epigraph  1
    a[12,14]  physical_G_upper  1
    a[12,15]  abs_p_12_15  1
    a[12,15]  abs_m_12_15  1
    a[12,15]  true_G_epigraph  1
    a[12,15]  physical_G_upper  1
    a[12,16]  abs_p_12_16  1
    a[12,16]  abs_m_12_16  1
    a[12,16]  true_G_epigraph  1
    a[12,16]  physical_G_upper  1
    a[12,17]  abs_p_12_17  1
    a[12,17]  abs_m_12_17  1
    a[12,17]  true_G_epigraph  1
    a[12,17]  physical_G_upper  1
    a[12,18]  abs_p_12_18  1
    a[12,18]  abs_m_12_18  1
    a[12,18]  true_G_epigraph  1
    a[12,18]  physical_G_upper  1
    a[12,19]  abs_p_12_19  1
    a[12,19]  abs_m_12_19  1
    a[12,19]  true_G_epigraph  1
    a[12,19]  physical_G_upper  1
    a[12,20]  abs_p_12_20  1
    a[12,20]  abs_m_12_20  1
    a[12,20]  true_G_epigraph  1
    a[12,20]  physical_G_upper  1
    a[12,21]  abs_p_12_21  1
    a[12,21]  abs_m_12_21  1
    a[12,21]  true_G_epigraph  1
    a[12,21]  physical_G_upper  1
    a[12,22]  abs_p_12_22  1
    a[12,22]  abs_m_12_22  1
    a[12,22]  true_G_epigraph  1
    a[12,22]  physical_G_upper  1
    a[12,23]  abs_p_12_23  1
    a[12,23]  abs_m_12_23  1
    a[12,23]  true_G_epigraph  1
    a[12,23]  physical_G_upper  1
    a[12,24]  abs_p_12_24  1
    a[12,24]  abs_m_12_24  1
    a[12,24]  true_G_epigraph  1
    a[12,24]  physical_G_upper  1
    a[12,25]  abs_p_12_25  1
    a[12,25]  abs_m_12_25  1
    a[12,25]  true_G_epigraph  1
    a[12,25]  physical_G_upper  1
    a[12,26]  abs_p_12_26  1
    a[12,26]  abs_m_12_26  1
    a[12,26]  true_G_epigraph  1
    a[12,26]  physical_G_upper  1
    a[12,27]  abs_p_12_27  1
    a[12,27]  abs_m_12_27  1
    a[12,27]  true_G_epigraph  1
    a[12,27]  physical_G_upper  1
    a[12,28]  abs_p_12_28  1
    a[12,28]  abs_m_12_28  1
    a[12,28]  true_G_epigraph  1
    a[12,28]  physical_G_upper  1
    a[12,29]  abs_p_12_29  1
    a[12,29]  abs_m_12_29  1
    a[12,29]  true_G_epigraph  1
    a[12,29]  physical_G_upper  1
    a[12,30]  abs_p_12_30  1
    a[12,30]  abs_m_12_30  1
    a[12,30]  true_G_epigraph  1
    a[12,30]  physical_G_upper  1
    a[12,31]  abs_p_12_31  1
    a[12,31]  abs_m_12_31  1
    a[12,31]  true_G_epigraph  1
    a[12,31]  physical_G_upper  1
    a[12,32]  abs_p_12_32  1
    a[12,32]  abs_m_12_32  1
    a[12,32]  true_G_epigraph  1
    a[12,32]  physical_G_upper  1
    a[12,33]  abs_p_12_33  1
    a[12,33]  abs_m_12_33  1
    a[12,33]  true_G_epigraph  1
    a[12,33]  physical_G_upper  1
    a[12,34]  abs_p_12_34  1
    a[12,34]  abs_m_12_34  1
    a[12,34]  true_G_epigraph  1
    a[12,34]  physical_G_upper  1
    a[12,35]  abs_p_12_35  1
    a[12,35]  abs_m_12_35  1
    a[12,35]  true_G_epigraph  1
    a[12,35]  physical_G_upper  1
    a[13,14]  abs_p_13_14  1
    a[13,14]  abs_m_13_14  1
    a[13,14]  true_G_epigraph  1
    a[13,14]  physical_G_upper  1
    a[13,15]  abs_p_13_15  1
    a[13,15]  abs_m_13_15  1
    a[13,15]  true_G_epigraph  1
    a[13,15]  physical_G_upper  1
    a[13,16]  abs_p_13_16  1
    a[13,16]  abs_m_13_16  1
    a[13,16]  true_G_epigraph  1
    a[13,16]  physical_G_upper  1
    a[13,17]  abs_p_13_17  1
    a[13,17]  abs_m_13_17  1
    a[13,17]  true_G_epigraph  1
    a[13,17]  physical_G_upper  1
    a[13,18]  abs_p_13_18  1
    a[13,18]  abs_m_13_18  1
    a[13,18]  true_G_epigraph  1
    a[13,18]  physical_G_upper  1
    a[13,19]  abs_p_13_19  1
    a[13,19]  abs_m_13_19  1
    a[13,19]  true_G_epigraph  1
    a[13,19]  physical_G_upper  1
    a[13,20]  abs_p_13_20  1
    a[13,20]  abs_m_13_20  1
    a[13,20]  true_G_epigraph  1
    a[13,20]  physical_G_upper  1
    a[13,21]  abs_p_13_21  1
    a[13,21]  abs_m_13_21  1
    a[13,21]  true_G_epigraph  1
    a[13,21]  physical_G_upper  1
    a[13,22]  abs_p_13_22  1
    a[13,22]  abs_m_13_22  1
    a[13,22]  true_G_epigraph  1
    a[13,22]  physical_G_upper  1
    a[13,23]  abs_p_13_23  1
    a[13,23]  abs_m_13_23  1
    a[13,23]  true_G_epigraph  1
    a[13,23]  physical_G_upper  1
    a[13,24]  abs_p_13_24  1
    a[13,24]  abs_m_13_24  1
    a[13,24]  true_G_epigraph  1
    a[13,24]  physical_G_upper  1
    a[13,25]  abs_p_13_25  1
    a[13,25]  abs_m_13_25  1
    a[13,25]  true_G_epigraph  1
    a[13,25]  physical_G_upper  1
    a[13,26]  abs_p_13_26  1
    a[13,26]  abs_m_13_26  1
    a[13,26]  true_G_epigraph  1
    a[13,26]  physical_G_upper  1
    a[13,27]  abs_p_13_27  1
    a[13,27]  abs_m_13_27  1
    a[13,27]  true_G_epigraph  1
    a[13,27]  physical_G_upper  1
    a[13,28]  abs_p_13_28  1
    a[13,28]  abs_m_13_28  1
    a[13,28]  true_G_epigraph  1
    a[13,28]  physical_G_upper  1
    a[13,29]  abs_p_13_29  1
    a[13,29]  abs_m_13_29  1
    a[13,29]  true_G_epigraph  1
    a[13,29]  physical_G_upper  1
    a[13,30]  abs_p_13_30  1
    a[13,30]  abs_m_13_30  1
    a[13,30]  true_G_epigraph  1
    a[13,30]  physical_G_upper  1
    a[13,31]  abs_p_13_31  1
    a[13,31]  abs_m_13_31  1
    a[13,31]  true_G_epigraph  1
    a[13,31]  physical_G_upper  1
    a[13,32]  abs_p_13_32  1
    a[13,32]  abs_m_13_32  1
    a[13,32]  true_G_epigraph  1
    a[13,32]  physical_G_upper  1
    a[13,33]  abs_p_13_33  1
    a[13,33]  abs_m_13_33  1
    a[13,33]  true_G_epigraph  1
    a[13,33]  physical_G_upper  1
    a[13,34]  abs_p_13_34  1
    a[13,34]  abs_m_13_34  1
    a[13,34]  true_G_epigraph  1
    a[13,34]  physical_G_upper  1
    a[13,35]  abs_p_13_35  1
    a[13,35]  abs_m_13_35  1
    a[13,35]  true_G_epigraph  1
    a[13,35]  physical_G_upper  1
    a[14,15]  abs_p_14_15  1
    a[14,15]  abs_m_14_15  1
    a[14,15]  true_G_epigraph  1
    a[14,15]  physical_G_upper  1
    a[14,16]  abs_p_14_16  1
    a[14,16]  abs_m_14_16  1
    a[14,16]  true_G_epigraph  1
    a[14,16]  physical_G_upper  1
    a[14,17]  abs_p_14_17  1
    a[14,17]  abs_m_14_17  1
    a[14,17]  true_G_epigraph  1
    a[14,17]  physical_G_upper  1
    a[14,18]  abs_p_14_18  1
    a[14,18]  abs_m_14_18  1
    a[14,18]  true_G_epigraph  1
    a[14,18]  physical_G_upper  1
    a[14,19]  abs_p_14_19  1
    a[14,19]  abs_m_14_19  1
    a[14,19]  true_G_epigraph  1
    a[14,19]  physical_G_upper  1
    a[14,20]  abs_p_14_20  1
    a[14,20]  abs_m_14_20  1
    a[14,20]  true_G_epigraph  1
    a[14,20]  physical_G_upper  1
    a[14,21]  abs_p_14_21  1
    a[14,21]  abs_m_14_21  1
    a[14,21]  true_G_epigraph  1
    a[14,21]  physical_G_upper  1
    a[14,22]  abs_p_14_22  1
    a[14,22]  abs_m_14_22  1
    a[14,22]  true_G_epigraph  1
    a[14,22]  physical_G_upper  1
    a[14,23]  abs_p_14_23  1
    a[14,23]  abs_m_14_23  1
    a[14,23]  true_G_epigraph  1
    a[14,23]  physical_G_upper  1
    a[14,24]  abs_p_14_24  1
    a[14,24]  abs_m_14_24  1
    a[14,24]  true_G_epigraph  1
    a[14,24]  physical_G_upper  1
    a[14,25]  abs_p_14_25  1
    a[14,25]  abs_m_14_25  1
    a[14,25]  true_G_epigraph  1
    a[14,25]  physical_G_upper  1
    a[14,26]  abs_p_14_26  1
    a[14,26]  abs_m_14_26  1
    a[14,26]  true_G_epigraph  1
    a[14,26]  physical_G_upper  1
    a[14,27]  abs_p_14_27  1
    a[14,27]  abs_m_14_27  1
    a[14,27]  true_G_epigraph  1
    a[14,27]  physical_G_upper  1
    a[14,28]  abs_p_14_28  1
    a[14,28]  abs_m_14_28  1
    a[14,28]  true_G_epigraph  1
    a[14,28]  physical_G_upper  1
    a[14,29]  abs_p_14_29  1
    a[14,29]  abs_m_14_29  1
    a[14,29]  true_G_epigraph  1
    a[14,29]  physical_G_upper  1
    a[14,30]  abs_p_14_30  1
    a[14,30]  abs_m_14_30  1
    a[14,30]  true_G_epigraph  1
    a[14,30]  physical_G_upper  1
    a[14,31]  abs_p_14_31  1
    a[14,31]  abs_m_14_31  1
    a[14,31]  true_G_epigraph  1
    a[14,31]  physical_G_upper  1
    a[14,32]  abs_p_14_32  1
    a[14,32]  abs_m_14_32  1
    a[14,32]  true_G_epigraph  1
    a[14,32]  physical_G_upper  1
    a[14,33]  abs_p_14_33  1
    a[14,33]  abs_m_14_33  1
    a[14,33]  true_G_epigraph  1
    a[14,33]  physical_G_upper  1
    a[14,34]  abs_p_14_34  1
    a[14,34]  abs_m_14_34  1
    a[14,34]  true_G_epigraph  1
    a[14,34]  physical_G_upper  1
    a[14,35]  abs_p_14_35  1
    a[14,35]  abs_m_14_35  1
    a[14,35]  true_G_epigraph  1
    a[14,35]  physical_G_upper  1
    a[15,16]  abs_p_15_16  1
    a[15,16]  abs_m_15_16  1
    a[15,16]  true_G_epigraph  1
    a[15,16]  physical_G_upper  1
    a[15,17]  abs_p_15_17  1
    a[15,17]  abs_m_15_17  1
    a[15,17]  true_G_epigraph  1
    a[15,17]  physical_G_upper  1
    a[15,18]  abs_p_15_18  1
    a[15,18]  abs_m_15_18  1
    a[15,18]  true_G_epigraph  1
    a[15,18]  physical_G_upper  1
    a[15,19]  abs_p_15_19  1
    a[15,19]  abs_m_15_19  1
    a[15,19]  true_G_epigraph  1
    a[15,19]  physical_G_upper  1
    a[15,20]  abs_p_15_20  1
    a[15,20]  abs_m_15_20  1
    a[15,20]  true_G_epigraph  1
    a[15,20]  physical_G_upper  1
    a[15,21]  abs_p_15_21  1
    a[15,21]  abs_m_15_21  1
    a[15,21]  true_G_epigraph  1
    a[15,21]  physical_G_upper  1
    a[15,22]  abs_p_15_22  1
    a[15,22]  abs_m_15_22  1
    a[15,22]  true_G_epigraph  1
    a[15,22]  physical_G_upper  1
    a[15,23]  abs_p_15_23  1
    a[15,23]  abs_m_15_23  1
    a[15,23]  true_G_epigraph  1
    a[15,23]  physical_G_upper  1
    a[15,24]  abs_p_15_24  1
    a[15,24]  abs_m_15_24  1
    a[15,24]  true_G_epigraph  1
    a[15,24]  physical_G_upper  1
    a[15,25]  abs_p_15_25  1
    a[15,25]  abs_m_15_25  1
    a[15,25]  true_G_epigraph  1
    a[15,25]  physical_G_upper  1
    a[15,26]  abs_p_15_26  1
    a[15,26]  abs_m_15_26  1
    a[15,26]  true_G_epigraph  1
    a[15,26]  physical_G_upper  1
    a[15,27]  abs_p_15_27  1
    a[15,27]  abs_m_15_27  1
    a[15,27]  true_G_epigraph  1
    a[15,27]  physical_G_upper  1
    a[15,28]  abs_p_15_28  1
    a[15,28]  abs_m_15_28  1
    a[15,28]  true_G_epigraph  1
    a[15,28]  physical_G_upper  1
    a[15,29]  abs_p_15_29  1
    a[15,29]  abs_m_15_29  1
    a[15,29]  true_G_epigraph  1
    a[15,29]  physical_G_upper  1
    a[15,30]  abs_p_15_30  1
    a[15,30]  abs_m_15_30  1
    a[15,30]  true_G_epigraph  1
    a[15,30]  physical_G_upper  1
    a[15,31]  abs_p_15_31  1
    a[15,31]  abs_m_15_31  1
    a[15,31]  true_G_epigraph  1
    a[15,31]  physical_G_upper  1
    a[15,32]  abs_p_15_32  1
    a[15,32]  abs_m_15_32  1
    a[15,32]  true_G_epigraph  1
    a[15,32]  physical_G_upper  1
    a[15,33]  abs_p_15_33  1
    a[15,33]  abs_m_15_33  1
    a[15,33]  true_G_epigraph  1
    a[15,33]  physical_G_upper  1
    a[15,34]  abs_p_15_34  1
    a[15,34]  abs_m_15_34  1
    a[15,34]  true_G_epigraph  1
    a[15,34]  physical_G_upper  1
    a[15,35]  abs_p_15_35  1
    a[15,35]  abs_m_15_35  1
    a[15,35]  true_G_epigraph  1
    a[15,35]  physical_G_upper  1
    a[16,17]  abs_p_16_17  1
    a[16,17]  abs_m_16_17  1
    a[16,17]  true_G_epigraph  1
    a[16,17]  physical_G_upper  1
    a[16,18]  abs_p_16_18  1
    a[16,18]  abs_m_16_18  1
    a[16,18]  true_G_epigraph  1
    a[16,18]  physical_G_upper  1
    a[16,19]  abs_p_16_19  1
    a[16,19]  abs_m_16_19  1
    a[16,19]  true_G_epigraph  1
    a[16,19]  physical_G_upper  1
    a[16,20]  abs_p_16_20  1
    a[16,20]  abs_m_16_20  1
    a[16,20]  true_G_epigraph  1
    a[16,20]  physical_G_upper  1
    a[16,21]  abs_p_16_21  1
    a[16,21]  abs_m_16_21  1
    a[16,21]  true_G_epigraph  1
    a[16,21]  physical_G_upper  1
    a[16,22]  abs_p_16_22  1
    a[16,22]  abs_m_16_22  1
    a[16,22]  true_G_epigraph  1
    a[16,22]  physical_G_upper  1
    a[16,23]  abs_p_16_23  1
    a[16,23]  abs_m_16_23  1
    a[16,23]  true_G_epigraph  1
    a[16,23]  physical_G_upper  1
    a[16,24]  abs_p_16_24  1
    a[16,24]  abs_m_16_24  1
    a[16,24]  true_G_epigraph  1
    a[16,24]  physical_G_upper  1
    a[16,25]  abs_p_16_25  1
    a[16,25]  abs_m_16_25  1
    a[16,25]  true_G_epigraph  1
    a[16,25]  physical_G_upper  1
    a[16,26]  abs_p_16_26  1
    a[16,26]  abs_m_16_26  1
    a[16,26]  true_G_epigraph  1
    a[16,26]  physical_G_upper  1
    a[16,27]  abs_p_16_27  1
    a[16,27]  abs_m_16_27  1
    a[16,27]  true_G_epigraph  1
    a[16,27]  physical_G_upper  1
    a[16,28]  abs_p_16_28  1
    a[16,28]  abs_m_16_28  1
    a[16,28]  true_G_epigraph  1
    a[16,28]  physical_G_upper  1
    a[16,29]  abs_p_16_29  1
    a[16,29]  abs_m_16_29  1
    a[16,29]  true_G_epigraph  1
    a[16,29]  physical_G_upper  1
    a[16,30]  abs_p_16_30  1
    a[16,30]  abs_m_16_30  1
    a[16,30]  true_G_epigraph  1
    a[16,30]  physical_G_upper  1
    a[16,31]  abs_p_16_31  1
    a[16,31]  abs_m_16_31  1
    a[16,31]  true_G_epigraph  1
    a[16,31]  physical_G_upper  1
    a[16,32]  abs_p_16_32  1
    a[16,32]  abs_m_16_32  1
    a[16,32]  true_G_epigraph  1
    a[16,32]  physical_G_upper  1
    a[16,33]  abs_p_16_33  1
    a[16,33]  abs_m_16_33  1
    a[16,33]  true_G_epigraph  1
    a[16,33]  physical_G_upper  1
    a[16,34]  abs_p_16_34  1
    a[16,34]  abs_m_16_34  1
    a[16,34]  true_G_epigraph  1
    a[16,34]  physical_G_upper  1
    a[16,35]  abs_p_16_35  1
    a[16,35]  abs_m_16_35  1
    a[16,35]  true_G_epigraph  1
    a[16,35]  physical_G_upper  1
    a[17,18]  abs_p_17_18  1
    a[17,18]  abs_m_17_18  1
    a[17,18]  true_G_epigraph  1
    a[17,18]  physical_G_upper  1
    a[17,19]  abs_p_17_19  1
    a[17,19]  abs_m_17_19  1
    a[17,19]  true_G_epigraph  1
    a[17,19]  physical_G_upper  1
    a[17,20]  abs_p_17_20  1
    a[17,20]  abs_m_17_20  1
    a[17,20]  true_G_epigraph  1
    a[17,20]  physical_G_upper  1
    a[17,21]  abs_p_17_21  1
    a[17,21]  abs_m_17_21  1
    a[17,21]  true_G_epigraph  1
    a[17,21]  physical_G_upper  1
    a[17,22]  abs_p_17_22  1
    a[17,22]  abs_m_17_22  1
    a[17,22]  true_G_epigraph  1
    a[17,22]  physical_G_upper  1
    a[17,23]  abs_p_17_23  1
    a[17,23]  abs_m_17_23  1
    a[17,23]  true_G_epigraph  1
    a[17,23]  physical_G_upper  1
    a[17,24]  abs_p_17_24  1
    a[17,24]  abs_m_17_24  1
    a[17,24]  true_G_epigraph  1
    a[17,24]  physical_G_upper  1
    a[17,25]  abs_p_17_25  1
    a[17,25]  abs_m_17_25  1
    a[17,25]  true_G_epigraph  1
    a[17,25]  physical_G_upper  1
    a[17,26]  abs_p_17_26  1
    a[17,26]  abs_m_17_26  1
    a[17,26]  true_G_epigraph  1
    a[17,26]  physical_G_upper  1
    a[17,27]  abs_p_17_27  1
    a[17,27]  abs_m_17_27  1
    a[17,27]  true_G_epigraph  1
    a[17,27]  physical_G_upper  1
    a[17,28]  abs_p_17_28  1
    a[17,28]  abs_m_17_28  1
    a[17,28]  true_G_epigraph  1
    a[17,28]  physical_G_upper  1
    a[17,29]  abs_p_17_29  1
    a[17,29]  abs_m_17_29  1
    a[17,29]  true_G_epigraph  1
    a[17,29]  physical_G_upper  1
    a[17,30]  abs_p_17_30  1
    a[17,30]  abs_m_17_30  1
    a[17,30]  true_G_epigraph  1
    a[17,30]  physical_G_upper  1
    a[17,31]  abs_p_17_31  1
    a[17,31]  abs_m_17_31  1
    a[17,31]  true_G_epigraph  1
    a[17,31]  physical_G_upper  1
    a[17,32]  abs_p_17_32  1
    a[17,32]  abs_m_17_32  1
    a[17,32]  true_G_epigraph  1
    a[17,32]  physical_G_upper  1
    a[17,33]  abs_p_17_33  1
    a[17,33]  abs_m_17_33  1
    a[17,33]  true_G_epigraph  1
    a[17,33]  physical_G_upper  1
    a[17,34]  abs_p_17_34  1
    a[17,34]  abs_m_17_34  1
    a[17,34]  true_G_epigraph  1
    a[17,34]  physical_G_upper  1
    a[17,35]  abs_p_17_35  1
    a[17,35]  abs_m_17_35  1
    a[17,35]  true_G_epigraph  1
    a[17,35]  physical_G_upper  1
    a[18,19]  abs_p_18_19  1
    a[18,19]  abs_m_18_19  1
    a[18,19]  true_G_epigraph  1
    a[18,19]  physical_G_upper  1
    a[18,20]  abs_p_18_20  1
    a[18,20]  abs_m_18_20  1
    a[18,20]  true_G_epigraph  1
    a[18,20]  physical_G_upper  1
    a[18,21]  abs_p_18_21  1
    a[18,21]  abs_m_18_21  1
    a[18,21]  true_G_epigraph  1
    a[18,21]  physical_G_upper  1
    a[18,22]  abs_p_18_22  1
    a[18,22]  abs_m_18_22  1
    a[18,22]  true_G_epigraph  1
    a[18,22]  physical_G_upper  1
    a[18,23]  abs_p_18_23  1
    a[18,23]  abs_m_18_23  1
    a[18,23]  true_G_epigraph  1
    a[18,23]  physical_G_upper  1
    a[18,24]  abs_p_18_24  1
    a[18,24]  abs_m_18_24  1
    a[18,24]  true_G_epigraph  1
    a[18,24]  physical_G_upper  1
    a[18,25]  abs_p_18_25  1
    a[18,25]  abs_m_18_25  1
    a[18,25]  true_G_epigraph  1
    a[18,25]  physical_G_upper  1
    a[18,26]  abs_p_18_26  1
    a[18,26]  abs_m_18_26  1
    a[18,26]  true_G_epigraph  1
    a[18,26]  physical_G_upper  1
    a[18,27]  abs_p_18_27  1
    a[18,27]  abs_m_18_27  1
    a[18,27]  true_G_epigraph  1
    a[18,27]  physical_G_upper  1
    a[18,28]  abs_p_18_28  1
    a[18,28]  abs_m_18_28  1
    a[18,28]  true_G_epigraph  1
    a[18,28]  physical_G_upper  1
    a[18,29]  abs_p_18_29  1
    a[18,29]  abs_m_18_29  1
    a[18,29]  true_G_epigraph  1
    a[18,29]  physical_G_upper  1
    a[18,30]  abs_p_18_30  1
    a[18,30]  abs_m_18_30  1
    a[18,30]  true_G_epigraph  1
    a[18,30]  physical_G_upper  1
    a[18,31]  abs_p_18_31  1
    a[18,31]  abs_m_18_31  1
    a[18,31]  true_G_epigraph  1
    a[18,31]  physical_G_upper  1
    a[18,32]  abs_p_18_32  1
    a[18,32]  abs_m_18_32  1
    a[18,32]  true_G_epigraph  1
    a[18,32]  physical_G_upper  1
    a[18,33]  abs_p_18_33  1
    a[18,33]  abs_m_18_33  1
    a[18,33]  true_G_epigraph  1
    a[18,33]  physical_G_upper  1
    a[18,34]  abs_p_18_34  1
    a[18,34]  abs_m_18_34  1
    a[18,34]  true_G_epigraph  1
    a[18,34]  physical_G_upper  1
    a[18,35]  abs_p_18_35  1
    a[18,35]  abs_m_18_35  1
    a[18,35]  true_G_epigraph  1
    a[18,35]  physical_G_upper  1
    a[19,20]  abs_p_19_20  1
    a[19,20]  abs_m_19_20  1
    a[19,20]  true_G_epigraph  1
    a[19,20]  physical_G_upper  1
    a[19,21]  abs_p_19_21  1
    a[19,21]  abs_m_19_21  1
    a[19,21]  true_G_epigraph  1
    a[19,21]  physical_G_upper  1
    a[19,22]  abs_p_19_22  1
    a[19,22]  abs_m_19_22  1
    a[19,22]  true_G_epigraph  1
    a[19,22]  physical_G_upper  1
    a[19,23]  abs_p_19_23  1
    a[19,23]  abs_m_19_23  1
    a[19,23]  true_G_epigraph  1
    a[19,23]  physical_G_upper  1
    a[19,24]  abs_p_19_24  1
    a[19,24]  abs_m_19_24  1
    a[19,24]  true_G_epigraph  1
    a[19,24]  physical_G_upper  1
    a[19,25]  abs_p_19_25  1
    a[19,25]  abs_m_19_25  1
    a[19,25]  true_G_epigraph  1
    a[19,25]  physical_G_upper  1
    a[19,26]  abs_p_19_26  1
    a[19,26]  abs_m_19_26  1
    a[19,26]  true_G_epigraph  1
    a[19,26]  physical_G_upper  1
    a[19,27]  abs_p_19_27  1
    a[19,27]  abs_m_19_27  1
    a[19,27]  true_G_epigraph  1
    a[19,27]  physical_G_upper  1
    a[19,28]  abs_p_19_28  1
    a[19,28]  abs_m_19_28  1
    a[19,28]  true_G_epigraph  1
    a[19,28]  physical_G_upper  1
    a[19,29]  abs_p_19_29  1
    a[19,29]  abs_m_19_29  1
    a[19,29]  true_G_epigraph  1
    a[19,29]  physical_G_upper  1
    a[19,30]  abs_p_19_30  1
    a[19,30]  abs_m_19_30  1
    a[19,30]  true_G_epigraph  1
    a[19,30]  physical_G_upper  1
    a[19,31]  abs_p_19_31  1
    a[19,31]  abs_m_19_31  1
    a[19,31]  true_G_epigraph  1
    a[19,31]  physical_G_upper  1
    a[19,32]  abs_p_19_32  1
    a[19,32]  abs_m_19_32  1
    a[19,32]  true_G_epigraph  1
    a[19,32]  physical_G_upper  1
    a[19,33]  abs_p_19_33  1
    a[19,33]  abs_m_19_33  1
    a[19,33]  true_G_epigraph  1
    a[19,33]  physical_G_upper  1
    a[19,34]  abs_p_19_34  1
    a[19,34]  abs_m_19_34  1
    a[19,34]  true_G_epigraph  1
    a[19,34]  physical_G_upper  1
    a[19,35]  abs_p_19_35  1
    a[19,35]  abs_m_19_35  1
    a[19,35]  true_G_epigraph  1
    a[19,35]  physical_G_upper  1
    a[20,21]  abs_p_20_21  1
    a[20,21]  abs_m_20_21  1
    a[20,21]  true_G_epigraph  1
    a[20,21]  physical_G_upper  1
    a[20,22]  abs_p_20_22  1
    a[20,22]  abs_m_20_22  1
    a[20,22]  true_G_epigraph  1
    a[20,22]  physical_G_upper  1
    a[20,23]  abs_p_20_23  1
    a[20,23]  abs_m_20_23  1
    a[20,23]  true_G_epigraph  1
    a[20,23]  physical_G_upper  1
    a[20,24]  abs_p_20_24  1
    a[20,24]  abs_m_20_24  1
    a[20,24]  true_G_epigraph  1
    a[20,24]  physical_G_upper  1
    a[20,25]  abs_p_20_25  1
    a[20,25]  abs_m_20_25  1
    a[20,25]  true_G_epigraph  1
    a[20,25]  physical_G_upper  1
    a[20,26]  abs_p_20_26  1
    a[20,26]  abs_m_20_26  1
    a[20,26]  true_G_epigraph  1
    a[20,26]  physical_G_upper  1
    a[20,27]  abs_p_20_27  1
    a[20,27]  abs_m_20_27  1
    a[20,27]  true_G_epigraph  1
    a[20,27]  physical_G_upper  1
    a[20,28]  abs_p_20_28  1
    a[20,28]  abs_m_20_28  1
    a[20,28]  true_G_epigraph  1
    a[20,28]  physical_G_upper  1
    a[20,29]  abs_p_20_29  1
    a[20,29]  abs_m_20_29  1
    a[20,29]  true_G_epigraph  1
    a[20,29]  physical_G_upper  1
    a[20,30]  abs_p_20_30  1
    a[20,30]  abs_m_20_30  1
    a[20,30]  true_G_epigraph  1
    a[20,30]  physical_G_upper  1
    a[20,31]  abs_p_20_31  1
    a[20,31]  abs_m_20_31  1
    a[20,31]  true_G_epigraph  1
    a[20,31]  physical_G_upper  1
    a[20,32]  abs_p_20_32  1
    a[20,32]  abs_m_20_32  1
    a[20,32]  true_G_epigraph  1
    a[20,32]  physical_G_upper  1
    a[20,33]  abs_p_20_33  1
    a[20,33]  abs_m_20_33  1
    a[20,33]  true_G_epigraph  1
    a[20,33]  physical_G_upper  1
    a[20,34]  abs_p_20_34  1
    a[20,34]  abs_m_20_34  1
    a[20,34]  true_G_epigraph  1
    a[20,34]  physical_G_upper  1
    a[20,35]  abs_p_20_35  1
    a[20,35]  abs_m_20_35  1
    a[20,35]  true_G_epigraph  1
    a[20,35]  physical_G_upper  1
    a[21,22]  abs_p_21_22  1
    a[21,22]  abs_m_21_22  1
    a[21,22]  true_G_epigraph  1
    a[21,22]  physical_G_upper  1
    a[21,23]  abs_p_21_23  1
    a[21,23]  abs_m_21_23  1
    a[21,23]  true_G_epigraph  1
    a[21,23]  physical_G_upper  1
    a[21,24]  abs_p_21_24  1
    a[21,24]  abs_m_21_24  1
    a[21,24]  true_G_epigraph  1
    a[21,24]  physical_G_upper  1
    a[21,25]  abs_p_21_25  1
    a[21,25]  abs_m_21_25  1
    a[21,25]  true_G_epigraph  1
    a[21,25]  physical_G_upper  1
    a[21,26]  abs_p_21_26  1
    a[21,26]  abs_m_21_26  1
    a[21,26]  true_G_epigraph  1
    a[21,26]  physical_G_upper  1
    a[21,27]  abs_p_21_27  1
    a[21,27]  abs_m_21_27  1
    a[21,27]  true_G_epigraph  1
    a[21,27]  physical_G_upper  1
    a[21,28]  abs_p_21_28  1
    a[21,28]  abs_m_21_28  1
    a[21,28]  true_G_epigraph  1
    a[21,28]  physical_G_upper  1
    a[21,29]  abs_p_21_29  1
    a[21,29]  abs_m_21_29  1
    a[21,29]  true_G_epigraph  1
    a[21,29]  physical_G_upper  1
    a[21,30]  abs_p_21_30  1
    a[21,30]  abs_m_21_30  1
    a[21,30]  true_G_epigraph  1
    a[21,30]  physical_G_upper  1
    a[21,31]  abs_p_21_31  1
    a[21,31]  abs_m_21_31  1
    a[21,31]  true_G_epigraph  1
    a[21,31]  physical_G_upper  1
    a[21,32]  abs_p_21_32  1
    a[21,32]  abs_m_21_32  1
    a[21,32]  true_G_epigraph  1
    a[21,32]  physical_G_upper  1
    a[21,33]  abs_p_21_33  1
    a[21,33]  abs_m_21_33  1
    a[21,33]  true_G_epigraph  1
    a[21,33]  physical_G_upper  1
    a[21,34]  abs_p_21_34  1
    a[21,34]  abs_m_21_34  1
    a[21,34]  true_G_epigraph  1
    a[21,34]  physical_G_upper  1
    a[21,35]  abs_p_21_35  1
    a[21,35]  abs_m_21_35  1
    a[21,35]  true_G_epigraph  1
    a[21,35]  physical_G_upper  1
    a[22,23]  abs_p_22_23  1
    a[22,23]  abs_m_22_23  1
    a[22,23]  true_G_epigraph  1
    a[22,23]  physical_G_upper  1
    a[22,24]  abs_p_22_24  1
    a[22,24]  abs_m_22_24  1
    a[22,24]  true_G_epigraph  1
    a[22,24]  physical_G_upper  1
    a[22,25]  abs_p_22_25  1
    a[22,25]  abs_m_22_25  1
    a[22,25]  true_G_epigraph  1
    a[22,25]  physical_G_upper  1
    a[22,26]  abs_p_22_26  1
    a[22,26]  abs_m_22_26  1
    a[22,26]  true_G_epigraph  1
    a[22,26]  physical_G_upper  1
    a[22,27]  abs_p_22_27  1
    a[22,27]  abs_m_22_27  1
    a[22,27]  true_G_epigraph  1
    a[22,27]  physical_G_upper  1
    a[22,28]  abs_p_22_28  1
    a[22,28]  abs_m_22_28  1
    a[22,28]  true_G_epigraph  1
    a[22,28]  physical_G_upper  1
    a[22,29]  abs_p_22_29  1
    a[22,29]  abs_m_22_29  1
    a[22,29]  true_G_epigraph  1
    a[22,29]  physical_G_upper  1
    a[22,30]  abs_p_22_30  1
    a[22,30]  abs_m_22_30  1
    a[22,30]  true_G_epigraph  1
    a[22,30]  physical_G_upper  1
    a[22,31]  abs_p_22_31  1
    a[22,31]  abs_m_22_31  1
    a[22,31]  true_G_epigraph  1
    a[22,31]  physical_G_upper  1
    a[22,32]  abs_p_22_32  1
    a[22,32]  abs_m_22_32  1
    a[22,32]  true_G_epigraph  1
    a[22,32]  physical_G_upper  1
    a[22,33]  abs_p_22_33  1
    a[22,33]  abs_m_22_33  1
    a[22,33]  true_G_epigraph  1
    a[22,33]  physical_G_upper  1
    a[22,34]  abs_p_22_34  1
    a[22,34]  abs_m_22_34  1
    a[22,34]  true_G_epigraph  1
    a[22,34]  physical_G_upper  1
    a[22,35]  abs_p_22_35  1
    a[22,35]  abs_m_22_35  1
    a[22,35]  true_G_epigraph  1
    a[22,35]  physical_G_upper  1
    a[23,24]  abs_p_23_24  1
    a[23,24]  abs_m_23_24  1
    a[23,24]  true_G_epigraph  1
    a[23,24]  physical_G_upper  1
    a[23,25]  abs_p_23_25  1
    a[23,25]  abs_m_23_25  1
    a[23,25]  true_G_epigraph  1
    a[23,25]  physical_G_upper  1
    a[23,26]  abs_p_23_26  1
    a[23,26]  abs_m_23_26  1
    a[23,26]  true_G_epigraph  1
    a[23,26]  physical_G_upper  1
    a[23,27]  abs_p_23_27  1
    a[23,27]  abs_m_23_27  1
    a[23,27]  true_G_epigraph  1
    a[23,27]  physical_G_upper  1
    a[23,28]  abs_p_23_28  1
    a[23,28]  abs_m_23_28  1
    a[23,28]  true_G_epigraph  1
    a[23,28]  physical_G_upper  1
    a[23,29]  abs_p_23_29  1
    a[23,29]  abs_m_23_29  1
    a[23,29]  true_G_epigraph  1
    a[23,29]  physical_G_upper  1
    a[23,30]  abs_p_23_30  1
    a[23,30]  abs_m_23_30  1
    a[23,30]  true_G_epigraph  1
    a[23,30]  physical_G_upper  1
    a[23,31]  abs_p_23_31  1
    a[23,31]  abs_m_23_31  1
    a[23,31]  true_G_epigraph  1
    a[23,31]  physical_G_upper  1
    a[23,32]  abs_p_23_32  1
    a[23,32]  abs_m_23_32  1
    a[23,32]  true_G_epigraph  1
    a[23,32]  physical_G_upper  1
    a[23,33]  abs_p_23_33  1
    a[23,33]  abs_m_23_33  1
    a[23,33]  true_G_epigraph  1
    a[23,33]  physical_G_upper  1
    a[23,34]  abs_p_23_34  1
    a[23,34]  abs_m_23_34  1
    a[23,34]  true_G_epigraph  1
    a[23,34]  physical_G_upper  1
    a[23,35]  abs_p_23_35  1
    a[23,35]  abs_m_23_35  1
    a[23,35]  true_G_epigraph  1
    a[23,35]  physical_G_upper  1
    a[24,25]  abs_p_24_25  1
    a[24,25]  abs_m_24_25  1
    a[24,25]  true_G_epigraph  1
    a[24,25]  physical_G_upper  1
    a[24,26]  abs_p_24_26  1
    a[24,26]  abs_m_24_26  1
    a[24,26]  true_G_epigraph  1
    a[24,26]  physical_G_upper  1
    a[24,27]  abs_p_24_27  1
    a[24,27]  abs_m_24_27  1
    a[24,27]  true_G_epigraph  1
    a[24,27]  physical_G_upper  1
    a[24,28]  abs_p_24_28  1
    a[24,28]  abs_m_24_28  1
    a[24,28]  true_G_epigraph  1
    a[24,28]  physical_G_upper  1
    a[24,29]  abs_p_24_29  1
    a[24,29]  abs_m_24_29  1
    a[24,29]  true_G_epigraph  1
    a[24,29]  physical_G_upper  1
    a[24,30]  abs_p_24_30  1
    a[24,30]  abs_m_24_30  1
    a[24,30]  true_G_epigraph  1
    a[24,30]  physical_G_upper  1
    a[24,31]  abs_p_24_31  1
    a[24,31]  abs_m_24_31  1
    a[24,31]  true_G_epigraph  1
    a[24,31]  physical_G_upper  1
    a[24,32]  abs_p_24_32  1
    a[24,32]  abs_m_24_32  1
    a[24,32]  true_G_epigraph  1
    a[24,32]  physical_G_upper  1
    a[24,33]  abs_p_24_33  1
    a[24,33]  abs_m_24_33  1
    a[24,33]  true_G_epigraph  1
    a[24,33]  physical_G_upper  1
    a[24,34]  abs_p_24_34  1
    a[24,34]  abs_m_24_34  1
    a[24,34]  true_G_epigraph  1
    a[24,34]  physical_G_upper  1
    a[24,35]  abs_p_24_35  1
    a[24,35]  abs_m_24_35  1
    a[24,35]  true_G_epigraph  1
    a[24,35]  physical_G_upper  1
    a[25,26]  abs_p_25_26  1
    a[25,26]  abs_m_25_26  1
    a[25,26]  true_G_epigraph  1
    a[25,26]  physical_G_upper  1
    a[25,27]  abs_p_25_27  1
    a[25,27]  abs_m_25_27  1
    a[25,27]  true_G_epigraph  1
    a[25,27]  physical_G_upper  1
    a[25,28]  abs_p_25_28  1
    a[25,28]  abs_m_25_28  1
    a[25,28]  true_G_epigraph  1
    a[25,28]  physical_G_upper  1
    a[25,29]  abs_p_25_29  1
    a[25,29]  abs_m_25_29  1
    a[25,29]  true_G_epigraph  1
    a[25,29]  physical_G_upper  1
    a[25,30]  abs_p_25_30  1
    a[25,30]  abs_m_25_30  1
    a[25,30]  true_G_epigraph  1
    a[25,30]  physical_G_upper  1
    a[25,31]  abs_p_25_31  1
    a[25,31]  abs_m_25_31  1
    a[25,31]  true_G_epigraph  1
    a[25,31]  physical_G_upper  1
    a[25,32]  abs_p_25_32  1
    a[25,32]  abs_m_25_32  1
    a[25,32]  true_G_epigraph  1
    a[25,32]  physical_G_upper  1
    a[25,33]  abs_p_25_33  1
    a[25,33]  abs_m_25_33  1
    a[25,33]  true_G_epigraph  1
    a[25,33]  physical_G_upper  1
    a[25,34]  abs_p_25_34  1
    a[25,34]  abs_m_25_34  1
    a[25,34]  true_G_epigraph  1
    a[25,34]  physical_G_upper  1
    a[25,35]  abs_p_25_35  1
    a[25,35]  abs_m_25_35  1
    a[25,35]  true_G_epigraph  1
    a[25,35]  physical_G_upper  1
    a[26,27]  abs_p_26_27  1
    a[26,27]  abs_m_26_27  1
    a[26,27]  true_G_epigraph  1
    a[26,27]  physical_G_upper  1
    a[26,28]  abs_p_26_28  1
    a[26,28]  abs_m_26_28  1
    a[26,28]  true_G_epigraph  1
    a[26,28]  physical_G_upper  1
    a[26,29]  abs_p_26_29  1
    a[26,29]  abs_m_26_29  1
    a[26,29]  true_G_epigraph  1
    a[26,29]  physical_G_upper  1
    a[26,30]  abs_p_26_30  1
    a[26,30]  abs_m_26_30  1
    a[26,30]  true_G_epigraph  1
    a[26,30]  physical_G_upper  1
    a[26,31]  abs_p_26_31  1
    a[26,31]  abs_m_26_31  1
    a[26,31]  true_G_epigraph  1
    a[26,31]  physical_G_upper  1
    a[26,32]  abs_p_26_32  1
    a[26,32]  abs_m_26_32  1
    a[26,32]  true_G_epigraph  1
    a[26,32]  physical_G_upper  1
    a[26,33]  abs_p_26_33  1
    a[26,33]  abs_m_26_33  1
    a[26,33]  true_G_epigraph  1
    a[26,33]  physical_G_upper  1
    a[26,34]  abs_p_26_34  1
    a[26,34]  abs_m_26_34  1
    a[26,34]  true_G_epigraph  1
    a[26,34]  physical_G_upper  1
    a[26,35]  abs_p_26_35  1
    a[26,35]  abs_m_26_35  1
    a[26,35]  true_G_epigraph  1
    a[26,35]  physical_G_upper  1
    a[27,28]  abs_p_27_28  1
    a[27,28]  abs_m_27_28  1
    a[27,28]  true_G_epigraph  1
    a[27,28]  physical_G_upper  1
    a[27,29]  abs_p_27_29  1
    a[27,29]  abs_m_27_29  1
    a[27,29]  true_G_epigraph  1
    a[27,29]  physical_G_upper  1
    a[27,30]  abs_p_27_30  1
    a[27,30]  abs_m_27_30  1
    a[27,30]  true_G_epigraph  1
    a[27,30]  physical_G_upper  1
    a[27,31]  abs_p_27_31  1
    a[27,31]  abs_m_27_31  1
    a[27,31]  true_G_epigraph  1
    a[27,31]  physical_G_upper  1
    a[27,32]  abs_p_27_32  1
    a[27,32]  abs_m_27_32  1
    a[27,32]  true_G_epigraph  1
    a[27,32]  physical_G_upper  1
    a[27,33]  abs_p_27_33  1
    a[27,33]  abs_m_27_33  1
    a[27,33]  true_G_epigraph  1
    a[27,33]  physical_G_upper  1
    a[27,34]  abs_p_27_34  1
    a[27,34]  abs_m_27_34  1
    a[27,34]  true_G_epigraph  1
    a[27,34]  physical_G_upper  1
    a[27,35]  abs_p_27_35  1
    a[27,35]  abs_m_27_35  1
    a[27,35]  true_G_epigraph  1
    a[27,35]  physical_G_upper  1
    a[28,29]  abs_p_28_29  1
    a[28,29]  abs_m_28_29  1
    a[28,29]  true_G_epigraph  1
    a[28,29]  physical_G_upper  1
    a[28,30]  abs_p_28_30  1
    a[28,30]  abs_m_28_30  1
    a[28,30]  true_G_epigraph  1
    a[28,30]  physical_G_upper  1
    a[28,31]  abs_p_28_31  1
    a[28,31]  abs_m_28_31  1
    a[28,31]  true_G_epigraph  1
    a[28,31]  physical_G_upper  1
    a[28,32]  abs_p_28_32  1
    a[28,32]  abs_m_28_32  1
    a[28,32]  true_G_epigraph  1
    a[28,32]  physical_G_upper  1
    a[28,33]  abs_p_28_33  1
    a[28,33]  abs_m_28_33  1
    a[28,33]  true_G_epigraph  1
    a[28,33]  physical_G_upper  1
    a[28,34]  abs_p_28_34  1
    a[28,34]  abs_m_28_34  1
    a[28,34]  true_G_epigraph  1
    a[28,34]  physical_G_upper  1
    a[28,35]  abs_p_28_35  1
    a[28,35]  abs_m_28_35  1
    a[28,35]  true_G_epigraph  1
    a[28,35]  physical_G_upper  1
    a[29,30]  abs_p_29_30  1
    a[29,30]  abs_m_29_30  1
    a[29,30]  true_G_epigraph  1
    a[29,30]  physical_G_upper  1
    a[29,31]  abs_p_29_31  1
    a[29,31]  abs_m_29_31  1
    a[29,31]  true_G_epigraph  1
    a[29,31]  physical_G_upper  1
    a[29,32]  abs_p_29_32  1
    a[29,32]  abs_m_29_32  1
    a[29,32]  true_G_epigraph  1
    a[29,32]  physical_G_upper  1
    a[29,33]  abs_p_29_33  1
    a[29,33]  abs_m_29_33  1
    a[29,33]  true_G_epigraph  1
    a[29,33]  physical_G_upper  1
    a[29,34]  abs_p_29_34  1
    a[29,34]  abs_m_29_34  1
    a[29,34]  true_G_epigraph  1
    a[29,34]  physical_G_upper  1
    a[29,35]  abs_p_29_35  1
    a[29,35]  abs_m_29_35  1
    a[29,35]  true_G_epigraph  1
    a[29,35]  physical_G_upper  1
    a[30,31]  abs_p_30_31  1
    a[30,31]  abs_m_30_31  1
    a[30,31]  true_G_epigraph  1
    a[30,31]  physical_G_upper  1
    a[30,32]  abs_p_30_32  1
    a[30,32]  abs_m_30_32  1
    a[30,32]  true_G_epigraph  1
    a[30,32]  physical_G_upper  1
    a[30,33]  abs_p_30_33  1
    a[30,33]  abs_m_30_33  1
    a[30,33]  true_G_epigraph  1
    a[30,33]  physical_G_upper  1
    a[30,34]  abs_p_30_34  1
    a[30,34]  abs_m_30_34  1
    a[30,34]  true_G_epigraph  1
    a[30,34]  physical_G_upper  1
    a[30,35]  abs_p_30_35  1
    a[30,35]  abs_m_30_35  1
    a[30,35]  true_G_epigraph  1
    a[30,35]  physical_G_upper  1
    a[31,32]  abs_p_31_32  1
    a[31,32]  abs_m_31_32  1
    a[31,32]  true_G_epigraph  1
    a[31,32]  physical_G_upper  1
    a[31,33]  abs_p_31_33  1
    a[31,33]  abs_m_31_33  1
    a[31,33]  true_G_epigraph  1
    a[31,33]  physical_G_upper  1
    a[31,34]  abs_p_31_34  1
    a[31,34]  abs_m_31_34  1
    a[31,34]  true_G_epigraph  1
    a[31,34]  physical_G_upper  1
    a[31,35]  abs_p_31_35  1
    a[31,35]  abs_m_31_35  1
    a[31,35]  true_G_epigraph  1
    a[31,35]  physical_G_upper  1
    a[32,33]  abs_p_32_33  1
    a[32,33]  abs_m_32_33  1
    a[32,33]  true_G_epigraph  1
    a[32,33]  physical_G_upper  1
    a[32,34]  abs_p_32_34  1
    a[32,34]  abs_m_32_34  1
    a[32,34]  true_G_epigraph  1
    a[32,34]  physical_G_upper  1
    a[32,35]  abs_p_32_35  1
    a[32,35]  abs_m_32_35  1
    a[32,35]  true_G_epigraph  1
    a[32,35]  physical_G_upper  1
    a[33,34]  abs_p_33_34  1
    a[33,34]  abs_m_33_34  1
    a[33,34]  true_G_epigraph  1
    a[33,34]  physical_G_upper  1
    a[33,35]  abs_p_33_35  1
    a[33,35]  abs_m_33_35  1
    a[33,35]  true_G_epigraph  1
    a[33,35]  physical_G_upper  1
    a[34,35]  abs_p_34_35  1
    a[34,35]  abs_m_34_35  1
    a[34,35]  true_G_epigraph  1
    a[34,35]  physical_G_upper  1
    q         OBJ       1
    q         true_G_epigraph  -35
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      onehot_3  1
    RHS1      onehot_4  1
    RHS1      onehot_5  1
    RHS1      onehot_6  1
    RHS1      onehot_7  1
    RHS1      onehot_8  1
    RHS1      onehot_9  1
    RHS1      onehot_10  1
    RHS1      onehot_11  1
    RHS1      onehot_12  1
    RHS1      onehot_13  1
    RHS1      onehot_14  1
    RHS1      onehot_15  1
    RHS1      onehot_16  1
    RHS1      onehot_17  1
    RHS1      onehot_18  1
    RHS1      onehot_19  1
    RHS1      onehot_20  1
    RHS1      onehot_21  1
    RHS1      onehot_22  1
    RHS1      onehot_23  1
    RHS1      onehot_24  1
    RHS1      onehot_25  1
    RHS1      onehot_26  1
    RHS1      onehot_27  1
    RHS1      onehot_28  1
    RHS1      onehot_29  1
    RHS1      onehot_30  1
    RHS1      onehot_31  1
    RHS1      onehot_32  1
    RHS1      onehot_33  1
    RHS1      onehot_34  1
    RHS1      onehot_35  1
    RHS1      hard_lower  136
    RHS1      hard_upper  211
    RHS1      normalization  1
    RHS1      physical_G_upper  2.0202628062360798e+01
BOUNDS
 BV BND1      x[1,0]  
 BV BND1      x[1,1]  
 BV BND1      x[1,2]  
 BV BND1      x[1,3]  
 BV BND1      x[1,4]  
 BV BND1      x[1,5]  
 BV BND1      x[1,6]  
 BV BND1      x[1,7]  
 BV BND1      x[1,8]  
 BV BND1      x[1,9]  
 BV BND1      x[1,10] 
 BV BND1      x[1,11] 
 BV BND1      x[1,12] 
 BV BND1      x[1,13] 
 BV BND1      x[1,14] 
 BV BND1      x[1,15] 
 BV BND1      x[1,16] 
 BV BND1      x[1,17] 
 BV BND1      x[1,18] 
 BV BND1      x[1,19] 
 BV BND1      x[2,0]  
 BV BND1      x[2,1]  
 BV BND1      x[2,2]  
 BV BND1      x[2,3]  
 BV BND1      x[2,4]  
 BV BND1      x[2,5]  
 BV BND1      x[2,6]  
 BV BND1      x[2,7]  
 BV BND1      x[2,8]  
 BV BND1      x[2,9]  
 BV BND1      x[2,10] 
 BV BND1      x[2,11] 
 BV BND1      x[2,12] 
 BV BND1      x[2,13] 
 BV BND1      x[2,14] 
 BV BND1      x[2,15] 
 BV BND1      x[3,0]  
 BV BND1      x[3,1]  
 BV BND1      x[3,2]  
 BV BND1      x[3,3]  
 BV BND1      x[3,4]  
 BV BND1      x[3,5]  
 BV BND1      x[3,6]  
 BV BND1      x[3,7]  
 BV BND1      x[3,8]  
 BV BND1      x[3,9]  
 BV BND1      x[3,10] 
 BV BND1      x[3,11] 
 BV BND1      x[3,12] 
 BV BND1      x[3,13] 
 BV BND1      x[3,14] 
 BV BND1      x[3,15] 
 BV BND1      x[3,16] 
 BV BND1      x[3,17] 
 BV BND1      x[4,0]  
 BV BND1      x[4,1]  
 BV BND1      x[4,2]  
 BV BND1      x[4,3]  
 BV BND1      x[4,4]  
 BV BND1      x[4,5]  
 BV BND1      x[4,6]  
 BV BND1      x[4,7]  
 BV BND1      x[4,8]  
 BV BND1      x[4,9]  
 BV BND1      x[4,10] 
 BV BND1      x[4,11] 
 BV BND1      x[4,12] 
 BV BND1      x[4,13] 
 BV BND1      x[4,14] 
 BV BND1      x[4,15] 
 BV BND1      x[5,0]  
 BV BND1      x[5,1]  
 BV BND1      x[5,2]  
 BV BND1      x[5,3]  
 BV BND1      x[5,4]  
 BV BND1      x[5,5]  
 BV BND1      x[5,6]  
 BV BND1      x[5,7]  
 BV BND1      x[5,8]  
 BV BND1      x[5,9]  
 BV BND1      x[5,10] 
 BV BND1      x[5,11] 
 BV BND1      x[5,12] 
 BV BND1      x[5,13] 
 BV BND1      x[5,14] 
 BV BND1      x[5,15] 
 BV BND1      x[5,16] 
 BV BND1      x[6,0]  
 BV BND1      x[6,1]  
 BV BND1      x[6,2]  
 BV BND1      x[6,3]  
 BV BND1      x[6,4]  
 BV BND1      x[6,5]  
 BV BND1      x[6,6]  
 BV BND1      x[6,7]  
 BV BND1      x[6,8]  
 BV BND1      x[6,9]  
 BV BND1      x[6,10] 
 BV BND1      x[7,0]  
 BV BND1      x[7,1]  
 BV BND1      x[7,2]  
 BV BND1      x[7,3]  
 BV BND1      x[7,4]  
 BV BND1      x[7,5]  
 BV BND1      x[7,6]  
 BV BND1      x[7,7]  
 BV BND1      x[7,8]  
 BV BND1      x[7,9]  
 BV BND1      x[7,10] 
 BV BND1      x[7,11] 
 BV BND1      x[7,12] 
 BV BND1      x[7,13] 
 BV BND1      x[7,14] 
 BV BND1      x[7,15] 
 BV BND1      x[7,16] 
 BV BND1      x[7,17] 
 BV BND1      x[8,0]  
 BV BND1      x[8,1]  
 BV BND1      x[8,2]  
 BV BND1      x[8,3]  
 BV BND1      x[8,4]  
 BV BND1      x[8,5]  
 BV BND1      x[8,6]  
 BV BND1      x[8,7]  
 BV BND1      x[8,8]  
 BV BND1      x[8,9]  
 BV BND1      x[8,10] 
 BV BND1      x[8,11] 
 BV BND1      x[8,12] 
 BV BND1      x[8,13] 
 BV BND1      x[8,14] 
 BV BND1      x[8,15] 
 BV BND1      x[8,16] 
 BV BND1      x[8,17] 
 BV BND1      x[8,18] 
 BV BND1      x[8,19] 
 BV BND1      x[8,20] 
 BV BND1      x[8,21] 
 BV BND1      x[9,0]  
 BV BND1      x[9,1]  
 BV BND1      x[9,2]  
 BV BND1      x[9,3]  
 BV BND1      x[9,4]  
 BV BND1      x[9,5]  
 BV BND1      x[9,6]  
 BV BND1      x[9,7]  
 BV BND1      x[9,8]  
 BV BND1      x[9,9]  
 BV BND1      x[9,10] 
 BV BND1      x[9,11] 
 BV BND1      x[9,12] 
 BV BND1      x[10,0] 
 BV BND1      x[10,1] 
 BV BND1      x[10,2] 
 BV BND1      x[10,3] 
 BV BND1      x[10,4] 
 BV BND1      x[10,5] 
 BV BND1      x[10,6] 
 BV BND1      x[10,7] 
 BV BND1      x[10,8] 
 BV BND1      x[10,9] 
 BV BND1      x[10,10]
 BV BND1      x[10,11]
 BV BND1      x[10,12]
 BV BND1      x[10,13]
 BV BND1      x[10,14]
 BV BND1      x[10,15]
 BV BND1      x[10,16]
 BV BND1      x[10,17]
 BV BND1      x[10,18]
 BV BND1      x[10,19]
 BV BND1      x[11,0] 
 BV BND1      x[11,1] 
 BV BND1      x[11,2] 
 BV BND1      x[11,3] 
 BV BND1      x[11,4] 
 BV BND1      x[11,5] 
 BV BND1      x[11,6] 
 BV BND1      x[11,7] 
 BV BND1      x[11,8] 
 BV BND1      x[11,9] 
 BV BND1      x[11,10]
 BV BND1      x[11,11]
 BV BND1      x[11,12]
 BV BND1      x[12,0] 
 BV BND1      x[12,1] 
 BV BND1      x[12,2] 
 BV BND1      x[12,3] 
 BV BND1      x[12,4] 
 BV BND1      x[12,5] 
 BV BND1      x[12,6] 
 BV BND1      x[12,7] 
 BV BND1      x[12,8] 
 BV BND1      x[12,9] 
 BV BND1      x[12,10]
 BV BND1      x[12,11]
 BV BND1      x[12,12]
 BV BND1      x[12,13]
 BV BND1      x[12,14]
 BV BND1      x[12,15]
 BV BND1      x[13,0] 
 BV BND1      x[13,1] 
 BV BND1      x[13,2] 
 BV BND1      x[13,3] 
 BV BND1      x[13,4] 
 BV BND1      x[13,5] 
 BV BND1      x[13,6] 
 BV BND1      x[13,7] 
 BV BND1      x[13,8] 
 BV BND1      x[13,9] 
 BV BND1      x[13,10]
 BV BND1      x[13,11]
 BV BND1      x[13,12]
 BV BND1      x[13,13]
 BV BND1      x[13,14]
 BV BND1      x[13,15]
 BV BND1      x[13,16]
 BV BND1      x[13,17]
 BV BND1      x[13,18]
 BV BND1      x[13,19]
 BV BND1      x[14,0] 
 BV BND1      x[14,1] 
 BV BND1      x[14,2] 
 BV BND1      x[14,3] 
 BV BND1      x[14,4] 
 BV BND1      x[14,5] 
 BV BND1      x[14,6] 
 BV BND1      x[14,7] 
 BV BND1      x[14,8] 
 BV BND1      x[14,9] 
 BV BND1      x[14,10]
 BV BND1      x[14,11]
 BV BND1      x[14,12]
 BV BND1      x[14,13]
 BV BND1      x[14,14]
 BV BND1      x[14,15]
 BV BND1      x[15,0] 
 BV BND1      x[15,1] 
 BV BND1      x[15,2] 
 BV BND1      x[15,3] 
 BV BND1      x[15,4] 
 BV BND1      x[15,5] 
 BV BND1      x[15,6] 
 BV BND1      x[15,7] 
 BV BND1      x[15,8] 
 BV BND1      x[15,9] 
 BV BND1      x[15,10]
 BV BND1      x[15,11]
 BV BND1      x[15,12]
 BV BND1      x[15,13]
 BV BND1      x[15,14]
 BV BND1      x[15,15]
 BV BND1      x[15,16]
 BV BND1      x[16,0] 
 BV BND1      x[16,1] 
 BV BND1      x[16,2] 
 BV BND1      x[16,3] 
 BV BND1      x[16,4] 
 BV BND1      x[16,5] 
 BV BND1      x[16,6] 
 BV BND1      x[16,7] 
 BV BND1      x[16,8] 
 BV BND1      x[16,9] 
 BV BND1      x[16,10]
 BV BND1      x[16,11]
 BV BND1      x[16,12]
 BV BND1      x[17,0] 
 BV BND1      x[17,1] 
 BV BND1      x[17,2] 
 BV BND1      x[17,3] 
 BV BND1      x[17,4] 
 BV BND1      x[17,5] 
 BV BND1      x[17,6] 
 BV BND1      x[17,7] 
 BV BND1      x[17,8] 
 BV BND1      x[17,9] 
 BV BND1      x[17,10]
 BV BND1      x[17,11]
 BV BND1      x[17,12]
 BV BND1      x[17,13]
 BV BND1      x[17,14]
 BV BND1      x[17,15]
 BV BND1      x[17,16]
 BV BND1      x[18,0] 
 BV BND1      x[18,1] 
 BV BND1      x[18,2] 
 BV BND1      x[18,3] 
 BV BND1      x[18,4] 
 BV BND1      x[18,5] 
 BV BND1      x[18,6] 
 BV BND1      x[18,7] 
 BV BND1      x[18,8] 
 BV BND1      x[18,9] 
 BV BND1      x[18,10]
 BV BND1      x[18,11]
 BV BND1      x[18,12]
 BV BND1      x[18,13]
 BV BND1      x[18,14]
 BV BND1      x[18,15]
 BV BND1      x[18,16]
 BV BND1      x[18,17]
 BV BND1      x[19,0] 
 BV BND1      x[19,1] 
 BV BND1      x[19,2] 
 BV BND1      x[19,3] 
 BV BND1      x[19,4] 
 BV BND1      x[19,5] 
 BV BND1      x[19,6] 
 BV BND1      x[19,7] 
 BV BND1      x[19,8] 
 BV BND1      x[20,0] 
 BV BND1      x[20,1] 
 BV BND1      x[20,2] 
 BV BND1      x[20,3] 
 BV BND1      x[20,4] 
 BV BND1      x[20,5] 
 BV BND1      x[20,6] 
 BV BND1      x[20,7] 
 BV BND1      x[20,8] 
 BV BND1      x[20,9] 
 BV BND1      x[20,10]
 BV BND1      x[20,11]
 BV BND1      x[20,12]
 BV BND1      x[21,0] 
 BV BND1      x[21,1] 
 BV BND1      x[21,2] 
 BV BND1      x[21,3] 
 BV BND1      x[21,4] 
 BV BND1      x[21,5] 
 BV BND1      x[21,6] 
 BV BND1      x[21,7] 
 BV BND1      x[21,8] 
 BV BND1      x[21,9] 
 BV BND1      x[21,10]
 BV BND1      x[21,11]
 BV BND1      x[21,12]
 BV BND1      x[21,13]
 BV BND1      x[21,14]
 BV BND1      x[21,15]
 BV BND1      x[22,0] 
 BV BND1      x[22,1] 
 BV BND1      x[22,2] 
 BV BND1      x[22,3] 
 BV BND1      x[22,4] 
 BV BND1      x[22,5] 
 BV BND1      x[22,6] 
 BV BND1      x[22,7] 
 BV BND1      x[22,8] 
 BV BND1      x[22,9] 
 BV BND1      x[22,10]
 BV BND1      x[22,11]
 BV BND1      x[22,12]
 BV BND1      x[23,0] 
 BV BND1      x[23,1] 
 BV BND1      x[23,2] 
 BV BND1      x[23,3] 
 BV BND1      x[23,4] 
 BV BND1      x[23,5] 
 BV BND1      x[23,6] 
 BV BND1      x[23,7] 
 BV BND1      x[23,8] 
 BV BND1      x[23,9] 
 BV BND1      x[23,10]
 BV BND1      x[23,11]
 BV BND1      x[24,0] 
 BV BND1      x[24,1] 
 BV BND1      x[24,2] 
 BV BND1      x[24,3] 
 BV BND1      x[24,4] 
 BV BND1      x[24,5] 
 BV BND1      x[24,6] 
 BV BND1      x[24,7] 
 BV BND1      x[24,8] 
 BV BND1      x[24,9] 
 BV BND1      x[24,10]
 BV BND1      x[24,11]
 BV BND1      x[24,12]
 BV BND1      x[24,13]
 BV BND1      x[24,14]
 BV BND1      x[24,15]
 BV BND1      x[25,0] 
 BV BND1      x[25,1] 
 BV BND1      x[25,2] 
 BV BND1      x[25,3] 
 BV BND1      x[25,4] 
 BV BND1      x[25,5] 
 BV BND1      x[25,6] 
 BV BND1      x[25,7] 
 BV BND1      x[25,8] 
 BV BND1      x[25,9] 
 BV BND1      x[25,10]
 BV BND1      x[25,11]
 BV BND1      x[25,12]
 BV BND1      x[25,13]
 BV BND1      x[25,14]
 BV BND1      x[25,15]
 BV BND1      x[26,0] 
 BV BND1      x[26,1] 
 BV BND1      x[26,2] 
 BV BND1      x[26,3] 
 BV BND1      x[26,4] 
 BV BND1      x[26,5] 
 BV BND1      x[26,6] 
 BV BND1      x[26,7] 
 BV BND1      x[26,8] 
 BV BND1      x[27,0] 
 BV BND1      x[27,1] 
 BV BND1      x[27,2] 
 BV BND1      x[27,3] 
 BV BND1      x[27,4] 
 BV BND1      x[27,5] 
 BV BND1      x[27,6] 
 BV BND1      x[27,7] 
 BV BND1      x[27,8] 
 BV BND1      x[27,9] 
 BV BND1      x[27,10]
 BV BND1      x[27,11]
 BV BND1      x[27,12]
 BV BND1      x[27,13]
 BV BND1      x[27,14]
 BV BND1      x[27,15]
 BV BND1      x[28,0] 
 BV BND1      x[28,1] 
 BV BND1      x[28,2] 
 BV BND1      x[28,3] 
 BV BND1      x[28,4] 
 BV BND1      x[28,5] 
 BV BND1      x[28,6] 
 BV BND1      x[28,7] 
 BV BND1      x[28,8] 
 BV BND1      x[28,9] 
 BV BND1      x[28,10]
 BV BND1      x[28,11]
 BV BND1      x[28,12]
 BV BND1      x[28,13]
 BV BND1      x[28,14]
 BV BND1      x[28,15]
 BV BND1      x[28,16]
 BV BND1      x[28,17]
 BV BND1      x[28,18]
 BV BND1      x[28,19]
 BV BND1      x[29,0] 
 BV BND1      x[29,1] 
 BV BND1      x[29,2] 
 BV BND1      x[29,3] 
 BV BND1      x[29,4] 
 BV BND1      x[29,5] 
 BV BND1      x[29,6] 
 BV BND1      x[29,7] 
 BV BND1      x[29,8] 
 BV BND1      x[29,9] 
 BV BND1      x[29,10]
 BV BND1      x[29,11]
 BV BND1      x[29,12]
 BV BND1      x[29,13]
 BV BND1      x[29,14]
 BV BND1      x[29,15]
 BV BND1      x[30,0] 
 BV BND1      x[30,1] 
 BV BND1      x[30,2] 
 BV BND1      x[30,3] 
 BV BND1      x[30,4] 
 BV BND1      x[30,5] 
 BV BND1      x[30,6] 
 BV BND1      x[30,7] 
 BV BND1      x[30,8] 
 BV BND1      x[31,0] 
 BV BND1      x[31,1] 
 BV BND1      x[31,2] 
 BV BND1      x[31,3] 
 BV BND1      x[31,4] 
 BV BND1      x[31,5] 
 BV BND1      x[31,6] 
 BV BND1      x[31,7] 
 BV BND1      x[31,8] 
 BV BND1      x[31,9] 
 BV BND1      x[31,10]
 BV BND1      x[31,11]
 BV BND1      x[31,12]
 BV BND1      x[32,0] 
 BV BND1      x[32,1] 
 BV BND1      x[32,2] 
 BV BND1      x[32,3] 
 BV BND1      x[32,4] 
 BV BND1      x[32,5] 
 BV BND1      x[32,6] 
 BV BND1      x[32,7] 
 BV BND1      x[32,8] 
 BV BND1      x[32,9] 
 BV BND1      x[32,10]
 BV BND1      x[32,11]
 BV BND1      x[32,12]
 BV BND1      x[33,0] 
 BV BND1      x[33,1] 
 BV BND1      x[33,2] 
 BV BND1      x[33,3] 
 BV BND1      x[33,4] 
 BV BND1      x[33,5] 
 BV BND1      x[33,6] 
 BV BND1      x[33,7] 
 BV BND1      x[33,8] 
 BV BND1      x[33,9] 
 BV BND1      x[33,10]
 BV BND1      x[33,11]
 BV BND1      x[33,12]
 BV BND1      x[33,13]
 BV BND1      x[33,14]
 BV BND1      x[33,15]
 BV BND1      x[33,16]
 BV BND1      x[34,0] 
 BV BND1      x[34,1] 
 BV BND1      x[34,2] 
 BV BND1      x[34,3] 
 BV BND1      x[34,4] 
 BV BND1      x[34,5] 
 BV BND1      x[34,6] 
 BV BND1      x[34,7] 
 BV BND1      x[34,8] 
 BV BND1      x[34,9] 
 BV BND1      x[34,10]
 BV BND1      x[34,11]
 BV BND1      x[35,0] 
 BV BND1      x[35,1] 
 BV BND1      x[35,2] 
 BV BND1      x[35,3] 
 BV BND1      x[35,4] 
 BV BND1      x[35,5] 
 BV BND1      x[35,6] 
 BV BND1      x[35,7] 
 BV BND1      x[35,8] 
 BV BND1      x[35,9] 
 BV BND1      x[35,10]
 BV BND1      x[35,11]
 BV BND1      x[35,12]
 BV BND1      x[35,13]
 BV BND1      x[35,14]
 BV BND1      x[35,15]
 UP BND1      w[1,0]    6.7365269461077862e-02
 UP BND1      w[1,1]    6.7365269461077862e-02
 UP BND1      w[1,2]    6.7365269461077862e-02
 UP BND1      w[1,3]    6.7365269461077862e-02
 UP BND1      w[1,4]    6.7365269461077862e-02
 UP BND1      w[1,5]    6.7365269461077862e-02
 UP BND1      w[1,6]    6.7365269461077862e-02
 UP BND1      w[1,7]    6.7365269461077862e-02
 UP BND1      w[1,8]    6.7365269461077862e-02
 UP BND1      w[1,9]    6.7365269461077862e-02
 UP BND1      w[1,10]   6.7365269461077862e-02
 UP BND1      w[1,11]   6.7365269461077862e-02
 UP BND1      w[1,12]   6.7365269461077862e-02
 UP BND1      w[1,13]   6.7365269461077862e-02
 UP BND1      w[1,14]   6.7365269461077862e-02
 UP BND1      w[1,15]   6.7365269461077862e-02
 UP BND1      w[1,16]   6.7365269461077862e-02
 UP BND1      w[1,17]   6.7365269461077862e-02
 UP BND1      w[1,18]   6.7365269461077862e-02
 UP BND1      w[1,19]   6.7365269461077862e-02
 UP BND1      w[2,0]    6.7365269461077862e-02
 UP BND1      w[2,1]    6.7365269461077862e-02
 UP BND1      w[2,2]    6.7365269461077862e-02
 UP BND1      w[2,3]    6.7365269461077862e-02
 UP BND1      w[2,4]    6.7365269461077862e-02
 UP BND1      w[2,5]    6.7365269461077862e-02
 UP BND1      w[2,6]    6.7365269461077862e-02
 UP BND1      w[2,7]    6.7365269461077862e-02
 UP BND1      w[2,8]    6.7365269461077862e-02
 UP BND1      w[2,9]    6.7365269461077862e-02
 UP BND1      w[2,10]   6.7365269461077862e-02
 UP BND1      w[2,11]   6.7365269461077862e-02
 UP BND1      w[2,12]   6.7365269461077862e-02
 UP BND1      w[2,13]   6.7365269461077862e-02
 UP BND1      w[2,14]   6.7365269461077862e-02
 UP BND1      w[2,15]   6.7365269461077862e-02
 UP BND1      w[3,0]    6.7365269461077862e-02
 UP BND1      w[3,1]    6.7365269461077862e-02
 UP BND1      w[3,2]    6.7365269461077862e-02
 UP BND1      w[3,3]    6.7365269461077862e-02
 UP BND1      w[3,4]    6.7365269461077862e-02
 UP BND1      w[3,5]    6.7365269461077862e-02
 UP BND1      w[3,6]    6.7365269461077862e-02
 UP BND1      w[3,7]    6.7365269461077862e-02
 UP BND1      w[3,8]    6.7365269461077862e-02
 UP BND1      w[3,9]    6.7365269461077862e-02
 UP BND1      w[3,10]   6.7365269461077862e-02
 UP BND1      w[3,11]   6.7365269461077862e-02
 UP BND1      w[3,12]   6.7365269461077862e-02
 UP BND1      w[3,13]   6.7365269461077862e-02
 UP BND1      w[3,14]   6.7365269461077862e-02
 UP BND1      w[3,15]   6.7365269461077862e-02
 UP BND1      w[3,16]   6.7365269461077862e-02
 UP BND1      w[3,17]   6.7365269461077862e-02
 UP BND1      w[4,0]    6.7365269461077862e-02
 UP BND1      w[4,1]    6.7365269461077862e-02
 UP BND1      w[4,2]    6.7365269461077862e-02
 UP BND1      w[4,3]    6.7365269461077862e-02
 UP BND1      w[4,4]    6.7365269461077862e-02
 UP BND1      w[4,5]    6.7365269461077862e-02
 UP BND1      w[4,6]    6.7365269461077862e-02
 UP BND1      w[4,7]    6.7365269461077862e-02
 UP BND1      w[4,8]    6.7365269461077862e-02
 UP BND1      w[4,9]    6.7365269461077862e-02
 UP BND1      w[4,10]   6.7365269461077862e-02
 UP BND1      w[4,11]   6.7365269461077862e-02
 UP BND1      w[4,12]   6.7365269461077862e-02
 UP BND1      w[4,13]   6.7365269461077862e-02
 UP BND1      w[4,14]   6.7365269461077862e-02
 UP BND1      w[4,15]   6.7365269461077862e-02
 UP BND1      w[5,0]    6.7365269461077862e-02
 UP BND1      w[5,1]    6.7365269461077862e-02
 UP BND1      w[5,2]    6.7365269461077862e-02
 UP BND1      w[5,3]    6.7365269461077862e-02
 UP BND1      w[5,4]    6.7365269461077862e-02
 UP BND1      w[5,5]    6.7365269461077862e-02
 UP BND1      w[5,6]    6.7365269461077862e-02
 UP BND1      w[5,7]    6.7365269461077862e-02
 UP BND1      w[5,8]    6.7365269461077862e-02
 UP BND1      w[5,9]    6.7365269461077862e-02
 UP BND1      w[5,10]   6.7365269461077862e-02
 UP BND1      w[5,11]   6.7365269461077862e-02
 UP BND1      w[5,12]   6.7365269461077862e-02
 UP BND1      w[5,13]   6.7365269461077862e-02
 UP BND1      w[5,14]   6.7365269461077862e-02
 UP BND1      w[5,15]   6.7365269461077862e-02
 UP BND1      w[5,16]   6.7365269461077862e-02
 UP BND1      w[6,0]    6.7365269461077862e-02
 UP BND1      w[6,1]    6.7365269461077862e-02
 UP BND1      w[6,2]    6.7365269461077862e-02
 UP BND1      w[6,3]    6.7365269461077862e-02
 UP BND1      w[6,4]    6.7365269461077862e-02
 UP BND1      w[6,5]    6.7365269461077862e-02
 UP BND1      w[6,6]    6.7365269461077862e-02
 UP BND1      w[6,7]    6.7365269461077862e-02
 UP BND1      w[6,8]    6.7365269461077862e-02
 UP BND1      w[6,9]    6.7365269461077862e-02
 UP BND1      w[6,10]   6.7365269461077862e-02
 UP BND1      w[7,0]    6.7365269461077862e-02
 UP BND1      w[7,1]    6.7365269461077862e-02
 UP BND1      w[7,2]    6.7365269461077862e-02
 UP BND1      w[7,3]    6.7365269461077862e-02
 UP BND1      w[7,4]    6.7365269461077862e-02
 UP BND1      w[7,5]    6.7365269461077862e-02
 UP BND1      w[7,6]    6.7365269461077862e-02
 UP BND1      w[7,7]    6.7365269461077862e-02
 UP BND1      w[7,8]    6.7365269461077862e-02
 UP BND1      w[7,9]    6.7365269461077862e-02
 UP BND1      w[7,10]   6.7365269461077862e-02
 UP BND1      w[7,11]   6.7365269461077862e-02
 UP BND1      w[7,12]   6.7365269461077862e-02
 UP BND1      w[7,13]   6.7365269461077862e-02
 UP BND1      w[7,14]   6.7365269461077862e-02
 UP BND1      w[7,15]   6.7365269461077862e-02
 UP BND1      w[7,16]   6.7365269461077862e-02
 UP BND1      w[7,17]   6.7365269461077862e-02
 UP BND1      w[8,0]    6.7365269461077862e-02
 UP BND1      w[8,1]    6.7365269461077862e-02
 UP BND1      w[8,2]    6.7365269461077862e-02
 UP BND1      w[8,3]    6.7365269461077862e-02
 UP BND1      w[8,4]    6.7365269461077862e-02
 UP BND1      w[8,5]    6.7365269461077862e-02
 UP BND1      w[8,6]    6.7365269461077862e-02
 UP BND1      w[8,7]    6.7365269461077862e-02
 UP BND1      w[8,8]    6.7365269461077862e-02
 UP BND1      w[8,9]    6.7365269461077862e-02
 UP BND1      w[8,10]   6.7365269461077862e-02
 UP BND1      w[8,11]   6.7365269461077862e-02
 UP BND1      w[8,12]   6.7365269461077862e-02
 UP BND1      w[8,13]   6.7365269461077862e-02
 UP BND1      w[8,14]   6.7365269461077862e-02
 UP BND1      w[8,15]   6.7365269461077862e-02
 UP BND1      w[8,16]   6.7365269461077862e-02
 UP BND1      w[8,17]   6.7365269461077862e-02
 UP BND1      w[8,18]   6.7365269461077862e-02
 UP BND1      w[8,19]   6.7365269461077862e-02
 UP BND1      w[8,20]   6.7365269461077862e-02
 UP BND1      w[8,21]   6.7365269461077862e-02
 UP BND1      w[9,0]    6.7365269461077862e-02
 UP BND1      w[9,1]    6.7365269461077862e-02
 UP BND1      w[9,2]    6.7365269461077862e-02
 UP BND1      w[9,3]    6.7365269461077862e-02
 UP BND1      w[9,4]    6.7365269461077862e-02
 UP BND1      w[9,5]    6.7365269461077862e-02
 UP BND1      w[9,6]    6.7365269461077862e-02
 UP BND1      w[9,7]    6.7365269461077862e-02
 UP BND1      w[9,8]    6.7365269461077862e-02
 UP BND1      w[9,9]    6.7365269461077862e-02
 UP BND1      w[9,10]   6.7365269461077862e-02
 UP BND1      w[9,11]   6.7365269461077862e-02
 UP BND1      w[9,12]   6.7365269461077862e-02
 UP BND1      w[10,0]   6.7365269461077862e-02
 UP BND1      w[10,1]   6.7365269461077862e-02
 UP BND1      w[10,2]   6.7365269461077862e-02
 UP BND1      w[10,3]   6.7365269461077862e-02
 UP BND1      w[10,4]   6.7365269461077862e-02
 UP BND1      w[10,5]   6.7365269461077862e-02
 UP BND1      w[10,6]   6.7365269461077862e-02
 UP BND1      w[10,7]   6.7365269461077862e-02
 UP BND1      w[10,8]   6.7365269461077862e-02
 UP BND1      w[10,9]   6.7365269461077862e-02
 UP BND1      w[10,10]  6.7365269461077862e-02
 UP BND1      w[10,11]  6.7365269461077862e-02
 UP BND1      w[10,12]  6.7365269461077862e-02
 UP BND1      w[10,13]  6.7365269461077862e-02
 UP BND1      w[10,14]  6.7365269461077862e-02
 UP BND1      w[10,15]  6.7365269461077862e-02
 UP BND1      w[10,16]  6.7365269461077862e-02
 UP BND1      w[10,17]  6.7365269461077862e-02
 UP BND1      w[10,18]  6.7365269461077862e-02
 UP BND1      w[10,19]  6.7365269461077862e-02
 UP BND1      w[11,0]   6.7365269461077862e-02
 UP BND1      w[11,1]   6.7365269461077862e-02
 UP BND1      w[11,2]   6.7365269461077862e-02
 UP BND1      w[11,3]   6.7365269461077862e-02
 UP BND1      w[11,4]   6.7365269461077862e-02
 UP BND1      w[11,5]   6.7365269461077862e-02
 UP BND1      w[11,6]   6.7365269461077862e-02
 UP BND1      w[11,7]   6.7365269461077862e-02
 UP BND1      w[11,8]   6.7365269461077862e-02
 UP BND1      w[11,9]   6.7365269461077862e-02
 UP BND1      w[11,10]  6.7365269461077862e-02
 UP BND1      w[11,11]  6.7365269461077862e-02
 UP BND1      w[11,12]  6.7365269461077862e-02
 UP BND1      w[12,0]   6.7365269461077862e-02
 UP BND1      w[12,1]   6.7365269461077862e-02
 UP BND1      w[12,2]   6.7365269461077862e-02
 UP BND1      w[12,3]   6.7365269461077862e-02
 UP BND1      w[12,4]   6.7365269461077862e-02
 UP BND1      w[12,5]   6.7365269461077862e-02
 UP BND1      w[12,6]   6.7365269461077862e-02
 UP BND1      w[12,7]   6.7365269461077862e-02
 UP BND1      w[12,8]   6.7365269461077862e-02
 UP BND1      w[12,9]   6.7365269461077862e-02
 UP BND1      w[12,10]  6.7365269461077862e-02
 UP BND1      w[12,11]  6.7365269461077862e-02
 UP BND1      w[12,12]  6.7365269461077862e-02
 UP BND1      w[12,13]  6.7365269461077862e-02
 UP BND1      w[12,14]  6.7365269461077862e-02
 UP BND1      w[12,15]  6.7365269461077862e-02
 UP BND1      w[13,0]   6.7365269461077862e-02
 UP BND1      w[13,1]   6.7365269461077862e-02
 UP BND1      w[13,2]   6.7365269461077862e-02
 UP BND1      w[13,3]   6.7365269461077862e-02
 UP BND1      w[13,4]   6.7365269461077862e-02
 UP BND1      w[13,5]   6.7365269461077862e-02
 UP BND1      w[13,6]   6.7365269461077862e-02
 UP BND1      w[13,7]   6.7365269461077862e-02
 UP BND1      w[13,8]   6.7365269461077862e-02
 UP BND1      w[13,9]   6.7365269461077862e-02
 UP BND1      w[13,10]  6.7365269461077862e-02
 UP BND1      w[13,11]  6.7365269461077862e-02
 UP BND1      w[13,12]  6.7365269461077862e-02
 UP BND1      w[13,13]  6.7365269461077862e-02
 UP BND1      w[13,14]  6.7365269461077862e-02
 UP BND1      w[13,15]  6.7365269461077862e-02
 UP BND1      w[13,16]  6.7365269461077862e-02
 UP BND1      w[13,17]  6.7365269461077862e-02
 UP BND1      w[13,18]  6.7365269461077862e-02
 UP BND1      w[13,19]  6.7365269461077862e-02
 UP BND1      w[14,0]   6.7365269461077862e-02
 UP BND1      w[14,1]   6.7365269461077862e-02
 UP BND1      w[14,2]   6.7365269461077862e-02
 UP BND1      w[14,3]   6.7365269461077862e-02
 UP BND1      w[14,4]   6.7365269461077862e-02
 UP BND1      w[14,5]   6.7365269461077862e-02
 UP BND1      w[14,6]   6.7365269461077862e-02
 UP BND1      w[14,7]   6.7365269461077862e-02
 UP BND1      w[14,8]   6.7365269461077862e-02
 UP BND1      w[14,9]   6.7365269461077862e-02
 UP BND1      w[14,10]  6.7365269461077862e-02
 UP BND1      w[14,11]  6.7365269461077862e-02
 UP BND1      w[14,12]  6.7365269461077862e-02
 UP BND1      w[14,13]  6.7365269461077862e-02
 UP BND1      w[14,14]  6.7365269461077862e-02
 UP BND1      w[14,15]  6.7365269461077862e-02
 UP BND1      w[15,0]   6.7365269461077862e-02
 UP BND1      w[15,1]   6.7365269461077862e-02
 UP BND1      w[15,2]   6.7365269461077862e-02
 UP BND1      w[15,3]   6.7365269461077862e-02
 UP BND1      w[15,4]   6.7365269461077862e-02
 UP BND1      w[15,5]   6.7365269461077862e-02
 UP BND1      w[15,6]   6.7365269461077862e-02
 UP BND1      w[15,7]   6.7365269461077862e-02
 UP BND1      w[15,8]   6.7365269461077862e-02
 UP BND1      w[15,9]   6.7365269461077862e-02
 UP BND1      w[15,10]  6.7365269461077862e-02
 UP BND1      w[15,11]  6.7365269461077862e-02
 UP BND1      w[15,12]  6.7365269461077862e-02
 UP BND1      w[15,13]  6.7365269461077862e-02
 UP BND1      w[15,14]  6.7365269461077862e-02
 UP BND1      w[15,15]  6.7365269461077862e-02
 UP BND1      w[15,16]  6.7365269461077862e-02
 UP BND1      w[16,0]   6.7365269461077862e-02
 UP BND1      w[16,1]   6.7365269461077862e-02
 UP BND1      w[16,2]   6.7365269461077862e-02
 UP BND1      w[16,3]   6.7365269461077862e-02
 UP BND1      w[16,4]   6.7365269461077862e-02
 UP BND1      w[16,5]   6.7365269461077862e-02
 UP BND1      w[16,6]   6.7365269461077862e-02
 UP BND1      w[16,7]   6.7365269461077862e-02
 UP BND1      w[16,8]   6.7365269461077862e-02
 UP BND1      w[16,9]   6.7365269461077862e-02
 UP BND1      w[16,10]  6.7365269461077862e-02
 UP BND1      w[16,11]  6.7365269461077862e-02
 UP BND1      w[16,12]  6.7365269461077862e-02
 UP BND1      w[17,0]   6.7365269461077862e-02
 UP BND1      w[17,1]   6.7365269461077862e-02
 UP BND1      w[17,2]   6.7365269461077862e-02
 UP BND1      w[17,3]   6.7365269461077862e-02
 UP BND1      w[17,4]   6.7365269461077862e-02
 UP BND1      w[17,5]   6.7365269461077862e-02
 UP BND1      w[17,6]   6.7365269461077862e-02
 UP BND1      w[17,7]   6.7365269461077862e-02
 UP BND1      w[17,8]   6.7365269461077862e-02
 UP BND1      w[17,9]   6.7365269461077862e-02
 UP BND1      w[17,10]  6.7365269461077862e-02
 UP BND1      w[17,11]  6.7365269461077862e-02
 UP BND1      w[17,12]  6.7365269461077862e-02
 UP BND1      w[17,13]  6.7365269461077862e-02
 UP BND1      w[17,14]  6.7365269461077862e-02
 UP BND1      w[17,15]  6.7365269461077862e-02
 UP BND1      w[17,16]  6.7365269461077862e-02
 UP BND1      w[18,0]   6.7365269461077862e-02
 UP BND1      w[18,1]   6.7365269461077862e-02
 UP BND1      w[18,2]   6.7365269461077862e-02
 UP BND1      w[18,3]   6.7365269461077862e-02
 UP BND1      w[18,4]   6.7365269461077862e-02
 UP BND1      w[18,5]   6.7365269461077862e-02
 UP BND1      w[18,6]   6.7365269461077862e-02
 UP BND1      w[18,7]   6.7365269461077862e-02
 UP BND1      w[18,8]   6.7365269461077862e-02
 UP BND1      w[18,9]   6.7365269461077862e-02
 UP BND1      w[18,10]  6.7365269461077862e-02
 UP BND1      w[18,11]  6.7365269461077862e-02
 UP BND1      w[18,12]  6.7365269461077862e-02
 UP BND1      w[18,13]  6.7365269461077862e-02
 UP BND1      w[18,14]  6.7365269461077862e-02
 UP BND1      w[18,15]  6.7365269461077862e-02
 UP BND1      w[18,16]  6.7365269461077862e-02
 UP BND1      w[18,17]  6.7365269461077862e-02
 UP BND1      w[19,0]   6.7365269461077862e-02
 UP BND1      w[19,1]   6.7365269461077862e-02
 UP BND1      w[19,2]   6.7365269461077862e-02
 UP BND1      w[19,3]   6.7365269461077862e-02
 UP BND1      w[19,4]   6.7365269461077862e-02
 UP BND1      w[19,5]   6.7365269461077862e-02
 UP BND1      w[19,6]   6.7365269461077862e-02
 UP BND1      w[19,7]   6.7365269461077862e-02
 UP BND1      w[19,8]   6.7365269461077862e-02
 UP BND1      w[20,0]   6.7365269461077862e-02
 UP BND1      w[20,1]   6.7365269461077862e-02
 UP BND1      w[20,2]   6.7365269461077862e-02
 UP BND1      w[20,3]   6.7365269461077862e-02
 UP BND1      w[20,4]   6.7365269461077862e-02
 UP BND1      w[20,5]   6.7365269461077862e-02
 UP BND1      w[20,6]   6.7365269461077862e-02
 UP BND1      w[20,7]   6.7365269461077862e-02
 UP BND1      w[20,8]   6.7365269461077862e-02
 UP BND1      w[20,9]   6.7365269461077862e-02
 UP BND1      w[20,10]  6.7365269461077862e-02
 UP BND1      w[20,11]  6.7365269461077862e-02
 UP BND1      w[20,12]  6.7365269461077862e-02
 UP BND1      w[21,0]   6.7365269461077862e-02
 UP BND1      w[21,1]   6.7365269461077862e-02
 UP BND1      w[21,2]   6.7365269461077862e-02
 UP BND1      w[21,3]   6.7365269461077862e-02
 UP BND1      w[21,4]   6.7365269461077862e-02
 UP BND1      w[21,5]   6.7365269461077862e-02
 UP BND1      w[21,6]   6.7365269461077862e-02
 UP BND1      w[21,7]   6.7365269461077862e-02
 UP BND1      w[21,8]   6.7365269461077862e-02
 UP BND1      w[21,9]   6.7365269461077862e-02
 UP BND1      w[21,10]  6.7365269461077862e-02
 UP BND1      w[21,11]  6.7365269461077862e-02
 UP BND1      w[21,12]  6.7365269461077862e-02
 UP BND1      w[21,13]  6.7365269461077862e-02
 UP BND1      w[21,14]  6.7365269461077862e-02
 UP BND1      w[21,15]  6.7365269461077862e-02
 UP BND1      w[22,0]   6.7365269461077862e-02
 UP BND1      w[22,1]   6.7365269461077862e-02
 UP BND1      w[22,2]   6.7365269461077862e-02
 UP BND1      w[22,3]   6.7365269461077862e-02
 UP BND1      w[22,4]   6.7365269461077862e-02
 UP BND1      w[22,5]   6.7365269461077862e-02
 UP BND1      w[22,6]   6.7365269461077862e-02
 UP BND1      w[22,7]   6.7365269461077862e-02
 UP BND1      w[22,8]   6.7365269461077862e-02
 UP BND1      w[22,9]   6.7365269461077862e-02
 UP BND1      w[22,10]  6.7365269461077862e-02
 UP BND1      w[22,11]  6.7365269461077862e-02
 UP BND1      w[22,12]  6.7365269461077862e-02
 UP BND1      w[23,0]   6.7365269461077862e-02
 UP BND1      w[23,1]   6.7365269461077862e-02
 UP BND1      w[23,2]   6.7365269461077862e-02
 UP BND1      w[23,3]   6.7365269461077862e-02
 UP BND1      w[23,4]   6.7365269461077862e-02
 UP BND1      w[23,5]   6.7365269461077862e-02
 UP BND1      w[23,6]   6.7365269461077862e-02
 UP BND1      w[23,7]   6.7365269461077862e-02
 UP BND1      w[23,8]   6.7365269461077862e-02
 UP BND1      w[23,9]   6.7365269461077862e-02
 UP BND1      w[23,10]  6.7365269461077862e-02
 UP BND1      w[23,11]  6.7365269461077862e-02
 UP BND1      w[24,0]   6.7365269461077862e-02
 UP BND1      w[24,1]   6.7365269461077862e-02
 UP BND1      w[24,2]   6.7365269461077862e-02
 UP BND1      w[24,3]   6.7365269461077862e-02
 UP BND1      w[24,4]   6.7365269461077862e-02
 UP BND1      w[24,5]   6.7365269461077862e-02
 UP BND1      w[24,6]   6.7365269461077862e-02
 UP BND1      w[24,7]   6.7365269461077862e-02
 UP BND1      w[24,8]   6.7365269461077862e-02
 UP BND1      w[24,9]   6.7365269461077862e-02
 UP BND1      w[24,10]  6.7365269461077862e-02
 UP BND1      w[24,11]  6.7365269461077862e-02
 UP BND1      w[24,12]  6.7365269461077862e-02
 UP BND1      w[24,13]  6.7365269461077862e-02
 UP BND1      w[24,14]  6.7365269461077862e-02
 UP BND1      w[24,15]  6.7365269461077862e-02
 UP BND1      w[25,0]   6.7365269461077862e-02
 UP BND1      w[25,1]   6.7365269461077862e-02
 UP BND1      w[25,2]   6.7365269461077862e-02
 UP BND1      w[25,3]   6.7365269461077862e-02
 UP BND1      w[25,4]   6.7365269461077862e-02
 UP BND1      w[25,5]   6.7365269461077862e-02
 UP BND1      w[25,6]   6.7365269461077862e-02
 UP BND1      w[25,7]   6.7365269461077862e-02
 UP BND1      w[25,8]   6.7365269461077862e-02
 UP BND1      w[25,9]   6.7365269461077862e-02
 UP BND1      w[25,10]  6.7365269461077862e-02
 UP BND1      w[25,11]  6.7365269461077862e-02
 UP BND1      w[25,12]  6.7365269461077862e-02
 UP BND1      w[25,13]  6.7365269461077862e-02
 UP BND1      w[25,14]  6.7365269461077862e-02
 UP BND1      w[25,15]  6.7365269461077862e-02
 UP BND1      w[26,0]   6.7365269461077862e-02
 UP BND1      w[26,1]   6.7365269461077862e-02
 UP BND1      w[26,2]   6.7365269461077862e-02
 UP BND1      w[26,3]   6.7365269461077862e-02
 UP BND1      w[26,4]   6.7365269461077862e-02
 UP BND1      w[26,5]   6.7365269461077862e-02
 UP BND1      w[26,6]   6.7365269461077862e-02
 UP BND1      w[26,7]   6.7365269461077862e-02
 UP BND1      w[26,8]   6.7365269461077862e-02
 UP BND1      w[27,0]   6.7365269461077862e-02
 UP BND1      w[27,1]   6.7365269461077862e-02
 UP BND1      w[27,2]   6.7365269461077862e-02
 UP BND1      w[27,3]   6.7365269461077862e-02
 UP BND1      w[27,4]   6.7365269461077862e-02
 UP BND1      w[27,5]   6.7365269461077862e-02
 UP BND1      w[27,6]   6.7365269461077862e-02
 UP BND1      w[27,7]   6.7365269461077862e-02
 UP BND1      w[27,8]   6.7365269461077862e-02
 UP BND1      w[27,9]   6.7365269461077862e-02
 UP BND1      w[27,10]  6.7365269461077862e-02
 UP BND1      w[27,11]  6.7365269461077862e-02
 UP BND1      w[27,12]  6.7365269461077862e-02
 UP BND1      w[27,13]  6.7365269461077862e-02
 UP BND1      w[27,14]  6.7365269461077862e-02
 UP BND1      w[27,15]  6.7365269461077862e-02
 UP BND1      w[28,0]   6.7365269461077862e-02
 UP BND1      w[28,1]   6.7365269461077862e-02
 UP BND1      w[28,2]   6.7365269461077862e-02
 UP BND1      w[28,3]   6.7365269461077862e-02
 UP BND1      w[28,4]   6.7365269461077862e-02
 UP BND1      w[28,5]   6.7365269461077862e-02
 UP BND1      w[28,6]   6.7365269461077862e-02
 UP BND1      w[28,7]   6.7365269461077862e-02
 UP BND1      w[28,8]   6.7365269461077862e-02
 UP BND1      w[28,9]   6.7365269461077862e-02
 UP BND1      w[28,10]  6.7365269461077862e-02
 UP BND1      w[28,11]  6.7365269461077862e-02
 UP BND1      w[28,12]  6.7365269461077862e-02
 UP BND1      w[28,13]  6.7365269461077862e-02
 UP BND1      w[28,14]  6.7365269461077862e-02
 UP BND1      w[28,15]  6.7365269461077862e-02
 UP BND1      w[28,16]  6.7365269461077862e-02
 UP BND1      w[28,17]  6.7365269461077862e-02
 UP BND1      w[28,18]  6.7365269461077862e-02
 UP BND1      w[28,19]  6.7365269461077862e-02
 UP BND1      w[29,0]   6.7365269461077862e-02
 UP BND1      w[29,1]   6.7365269461077862e-02
 UP BND1      w[29,2]   6.7365269461077862e-02
 UP BND1      w[29,3]   6.7365269461077862e-02
 UP BND1      w[29,4]   6.7365269461077862e-02
 UP BND1      w[29,5]   6.7365269461077862e-02
 UP BND1      w[29,6]   6.7365269461077862e-02
 UP BND1      w[29,7]   6.7365269461077862e-02
 UP BND1      w[29,8]   6.7365269461077862e-02
 UP BND1      w[29,9]   6.7365269461077862e-02
 UP BND1      w[29,10]  6.7365269461077862e-02
 UP BND1      w[29,11]  6.7365269461077862e-02
 UP BND1      w[29,12]  6.7365269461077862e-02
 UP BND1      w[29,13]  6.7365269461077862e-02
 UP BND1      w[29,14]  6.7365269461077862e-02
 UP BND1      w[29,15]  6.7365269461077862e-02
 UP BND1      w[30,0]   6.7365269461077862e-02
 UP BND1      w[30,1]   6.7365269461077862e-02
 UP BND1      w[30,2]   6.7365269461077862e-02
 UP BND1      w[30,3]   6.7365269461077862e-02
 UP BND1      w[30,4]   6.7365269461077862e-02
 UP BND1      w[30,5]   6.7365269461077862e-02
 UP BND1      w[30,6]   6.7365269461077862e-02
 UP BND1      w[30,7]   6.7365269461077862e-02
 UP BND1      w[30,8]   6.7365269461077862e-02
 UP BND1      w[31,0]   6.7365269461077862e-02
 UP BND1      w[31,1]   6.7365269461077862e-02
 UP BND1      w[31,2]   6.7365269461077862e-02
 UP BND1      w[31,3]   6.7365269461077862e-02
 UP BND1      w[31,4]   6.7365269461077862e-02
 UP BND1      w[31,5]   6.7365269461077862e-02
 UP BND1      w[31,6]   6.7365269461077862e-02
 UP BND1      w[31,7]   6.7365269461077862e-02
 UP BND1      w[31,8]   6.7365269461077862e-02
 UP BND1      w[31,9]   6.7365269461077862e-02
 UP BND1      w[31,10]  6.7365269461077862e-02
 UP BND1      w[31,11]  6.7365269461077862e-02
 UP BND1      w[31,12]  6.7365269461077862e-02
 UP BND1      w[32,0]   6.7365269461077862e-02
 UP BND1      w[32,1]   6.7365269461077862e-02
 UP BND1      w[32,2]   6.7365269461077862e-02
 UP BND1      w[32,3]   6.7365269461077862e-02
 UP BND1      w[32,4]   6.7365269461077862e-02
 UP BND1      w[32,5]   6.7365269461077862e-02
 UP BND1      w[32,6]   6.7365269461077862e-02
 UP BND1      w[32,7]   6.7365269461077862e-02
 UP BND1      w[32,8]   6.7365269461077862e-02
 UP BND1      w[32,9]   6.7365269461077862e-02
 UP BND1      w[32,10]  6.7365269461077862e-02
 UP BND1      w[32,11]  6.7365269461077862e-02
 UP BND1      w[32,12]  6.7365269461077862e-02
 UP BND1      w[33,0]   6.7365269461077862e-02
 UP BND1      w[33,1]   6.7365269461077862e-02
 UP BND1      w[33,2]   6.7365269461077862e-02
 UP BND1      w[33,3]   6.7365269461077862e-02
 UP BND1      w[33,4]   6.7365269461077862e-02
 UP BND1      w[33,5]   6.7365269461077862e-02
 UP BND1      w[33,6]   6.7365269461077862e-02
 UP BND1      w[33,7]   6.7365269461077862e-02
 UP BND1      w[33,8]   6.7365269461077862e-02
 UP BND1      w[33,9]   6.7365269461077862e-02
 UP BND1      w[33,10]  6.7365269461077862e-02
 UP BND1      w[33,11]  6.7365269461077862e-02
 UP BND1      w[33,12]  6.7365269461077862e-02
 UP BND1      w[33,13]  6.7365269461077862e-02
 UP BND1      w[33,14]  6.7365269461077862e-02
 UP BND1      w[33,15]  6.7365269461077862e-02
 UP BND1      w[33,16]  6.7365269461077862e-02
 UP BND1      w[34,0]   6.7365269461077862e-02
 UP BND1      w[34,1]   6.7365269461077862e-02
 UP BND1      w[34,2]   6.7365269461077862e-02
 UP BND1      w[34,3]   6.7365269461077862e-02
 UP BND1      w[34,4]   6.7365269461077862e-02
 UP BND1      w[34,5]   6.7365269461077862e-02
 UP BND1      w[34,6]   6.7365269461077862e-02
 UP BND1      w[34,7]   6.7365269461077862e-02
 UP BND1      w[34,8]   6.7365269461077862e-02
 UP BND1      w[34,9]   6.7365269461077862e-02
 UP BND1      w[34,10]  6.7365269461077862e-02
 UP BND1      w[34,11]  6.7365269461077862e-02
 UP BND1      w[35,0]   6.7365269461077862e-02
 UP BND1      w[35,1]   6.7365269461077862e-02
 UP BND1      w[35,2]   6.7365269461077862e-02
 UP BND1      w[35,3]   6.7365269461077862e-02
 UP BND1      w[35,4]   6.7365269461077862e-02
 UP BND1      w[35,5]   6.7365269461077862e-02
 UP BND1      w[35,6]   6.7365269461077862e-02
 UP BND1      w[35,7]   6.7365269461077862e-02
 UP BND1      w[35,8]   6.7365269461077862e-02
 UP BND1      w[35,9]   6.7365269461077862e-02
 UP BND1      w[35,10]  6.7365269461077862e-02
 UP BND1      w[35,11]  6.7365269461077862e-02
 UP BND1      w[35,12]  6.7365269461077862e-02
 UP BND1      w[35,13]  6.7365269461077862e-02
 UP BND1      w[35,14]  6.7365269461077862e-02
 UP BND1      w[35,15]  6.7365269461077862e-02
 LO BND1      t         2.6697177726926005e-02
 UP BND1      t         6.7365269461077862e-02
 UP BND1      q         5.7721794463887988e-01
ENDATA
