* Signature: 0x6504cc2b267480e
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  inventory_1
 E  ratio_1 
 E  onehot_2
 E  inventory_2
 E  ratio_2 
 E  onehot_3
 E  inventory_3
 E  ratio_3 
 E  onehot_4
 E  inventory_4
 E  ratio_4 
 E  onehot_5
 E  inventory_5
 E  ratio_5 
 E  onehot_6
 E  inventory_6
 E  ratio_6 
 E  onehot_7
 E  inventory_7
 E  ratio_7 
 E  onehot_8
 E  inventory_8
 E  ratio_8 
 E  onehot_9
 E  inventory_9
 E  ratio_9 
 E  onehot_10
 E  inventory_10
 E  ratio_10
 E  onehot_11
 E  inventory_11
 E  ratio_11
 E  onehot_12
 E  inventory_12
 E  ratio_12
 E  onehot_13
 E  inventory_13
 E  ratio_13
 E  onehot_14
 E  inventory_14
 E  ratio_14
 E  onehot_15
 E  inventory_15
 E  ratio_15
 E  onehot_16
 E  inventory_16
 E  ratio_16
 E  onehot_17
 E  inventory_17
 E  ratio_17
 E  onehot_18
 E  inventory_18
 E  ratio_18
 E  onehot_19
 E  inventory_19
 E  ratio_19
 E  onehot_20
 E  inventory_20
 E  ratio_20
 E  onehot_21
 E  inventory_21
 E  ratio_21
 E  onehot_22
 E  inventory_22
 E  ratio_22
 E  onehot_23
 E  inventory_23
 E  ratio_23
 E  onehot_24
 E  inventory_24
 E  ratio_24
 E  onehot_25
 E  inventory_25
 E  ratio_25
 E  onehot_26
 E  inventory_26
 E  ratio_26
 E  onehot_27
 E  inventory_27
 E  ratio_27
 E  onehot_28
 E  inventory_28
 E  ratio_28
 E  onehot_29
 E  inventory_29
 E  ratio_29
 E  onehot_30
 E  inventory_30
 E  ratio_30
 E  onehot_31
 E  inventory_31
 E  ratio_31
 E  onehot_32
 E  inventory_32
 E  ratio_32
 E  onehot_33
 E  inventory_33
 E  ratio_33
 E  onehot_34
 E  inventory_34
 E  ratio_34
 E  onehot_35
 E  inventory_35
 E  ratio_35
 G  R105    
 G  R106    
 G  R107    
 G  R108    
 G  R109    
 G  R110    
 G  R111    
 G  R112    
 G  R113    
 G  R114    
 G  R115    
 G  R116    
 G  R117    
 G  R118    
 G  R119    
 G  R120    
 G  R121    
 G  R122    
 G  R123    
 G  R124    
 G  R125    
 G  R126    
 G  R127    
 G  R128    
 G  R129    
 G  R130    
 G  R131    
 G  R132    
 G  R133    
 G  R134    
 G  R135    
 G  R136    
 G  R137    
 G  R138    
 G  R139    
 G  R140    
 G  R141    
 G  R142    
 G  R143    
 G  R144    
 G  R145    
 G  R146    
 G  R147    
 G  R148    
 G  R149    
 G  R150    
 G  R151    
 G  R152    
 G  R153    
 G  R154    
 G  R155    
 G  R156    
 G  R157    
 G  R158    
 G  R159    
 G  R160    
 G  R161    
 G  R162    
 G  R163    
 G  R164    
 G  R165    
 G  R166    
 G  R167    
 G  R168    
 G  R169    
 G  R170    
 G  R171    
 G  R172    
 G  R173    
 G  R174    
 G  R175    
 G  R176    
 G  R177    
 G  R178    
 G  R179    
 G  R180    
 G  R181    
 G  R182    
 G  R183    
 G  R184    
 G  R185    
 G  R186    
 G  R187    
 G  R188    
 G  R189    
 G  R190    
 G  R191    
 G  R192    
 G  R193    
 G  R194    
 G  R195    
 G  R196    
 G  R197    
 G  R198    
 G  R199    
 G  R200    
 G  R201    
 G  R202    
 G  R203    
 G  R204    
 G  R205    
 G  R206    
 G  R207    
 G  R208    
 G  R209    
 G  R210    
 G  R211    
 G  R212    
 G  R213    
 G  R214    
 G  R215    
 G  R216    
 G  R217    
 G  R218    
 G  R219    
 G  R220    
 G  R221    
 G  R222    
 G  R223    
 G  R224    
 G  R225    
 G  R226    
 G  R227    
 G  R228    
 G  R229    
 G  R230    
 G  R231    
 G  R232    
 G  R233    
 G  R234    
 G  R235    
 G  R236    
 G  R237    
 G  R238    
 G  R239    
 G  R240    
 G  R241    
 G  R242    
 G  R243    
 G  R244    
 G  R245    
 G  R246    
 G  R247    
 G  R248    
 G  R249    
 G  R250    
 G  R251    
 G  R252    
 G  R253    
 G  R254    
 G  R255    
 G  R256    
 G  R257    
 G  R258    
 G  R259    
 G  R260    
 G  R261    
 G  R262    
 G  R263    
 G  R264    
 G  R265    
 G  R266    
 G  R267    
 G  R268    
 G  R269    
 G  R270    
 G  R271    
 G  R272    
 G  R273    
 G  R274    
 G  R275    
 G  R276    
 G  R277    
 G  R278    
 G  R279    
 G  R280    
 G  R281    
 G  R282    
 G  R283    
 G  R284    
 G  R285    
 G  R286    
 G  R287    
 G  R288    
 G  R289    
 G  R290    
 G  R291    
 G  R292    
 G  R293    
 G  R294    
 G  R295    
 G  R296    
 G  R297    
 G  R298    
 G  R299    
 G  R300    
 G  R301    
 G  R302    
 G  R303    
 G  R304    
 G  R305    
 G  R306    
 G  R307    
 G  R308    
 G  R309    
 G  R310    
 G  R311    
 G  R312    
 G  R313    
 G  R314    
 G  R315    
 G  R316    
 G  R317    
 G  R318    
 G  R319    
 G  R320    
 G  R321    
 G  R322    
 G  R323    
 G  R324    
 G  R325    
 G  R326    
 G  R327    
 G  R328    
 G  R329    
 G  R330    
 G  R331    
 G  R332    
 G  R333    
 G  R334    
 G  R335    
 G  R336    
 G  R337    
 G  R338    
 G  R339    
 G  R340    
 G  R341    
 G  R342    
 G  R343    
 G  R344    
 G  R345    
 G  R346    
 G  R347    
 G  R348    
 G  R349    
 G  R350    
 G  R351    
 G  R352    
 G  R353    
 G  R354    
 G  R355    
 G  R356    
 G  R357    
 G  R358    
 G  R359    
 G  R360    
 G  R361    
 G  R362    
 G  R363    
 G  R364    
 G  R365    
 G  R366    
 G  R367    
 G  R368    
 G  R369    
 G  R370    
 G  R371    
 G  R372    
 G  R373    
 G  R374    
 G  R375    
 G  R376    
 G  R377    
 G  R378    
 G  R379    
 G  R380    
 G  R381    
 G  R382    
 G  R383    
 G  R384    
 G  R385    
 G  R386    
 G  R387    
 G  R388    
 G  R389    
 G  R390    
 G  R391    
 G  R392    
 G  R393    
 G  R394    
 G  R395    
 G  R396    
 G  R397    
 G  R398    
 G  R399    
 G  R400    
 G  R401    
 G  R402    
 G  R403    
 G  R404    
 G  R405    
 G  R406    
 G  R407    
 G  R408    
 G  R409    
 G  R410    
 G  R411    
 G  R412    
 G  R413    
 G  R414    
 G  R415    
 G  R416    
 G  R417    
 G  R418    
 G  R419    
 G  R420    
 G  R421    
 G  R422    
 G  R423    
 G  R424    
 G  R425    
 G  R426    
 G  R427    
 G  R428    
 G  R429    
 G  R430    
 G  R431    
 G  R432    
 G  R433    
 G  R434    
 G  R435    
 G  R436    
 G  R437    
 G  R438    
 G  R439    
 G  R440    
 G  R441    
 G  R442    
 G  R443    
 G  R444    
 G  R445    
 G  R446    
 G  R447    
 G  R448    
 G  R449    
 G  R450    
 G  R451    
 G  R452    
 G  R453    
 G  R454    
 G  R455    
 G  R456    
 G  R457    
 G  R458    
 G  R459    
 G  R460    
 G  R461    
 G  R462    
 G  R463    
 G  R464    
 G  R465    
 G  R466    
 G  R467    
 G  R468    
 G  R469    
 G  R470    
 G  R471    
 G  R472    
 G  R473    
 G  R474    
 G  R475    
 G  R476    
 G  R477    
 G  R478    
 G  R479    
 G  R480    
 G  R481    
 G  R482    
 G  R483    
 G  R484    
 G  R485    
 G  R486    
 G  R487    
 G  R488    
 G  R489    
 G  R490    
 G  R491    
 G  R492    
 G  R493    
 G  R494    
 G  R495    
 G  R496    
 G  R497    
 G  R498    
 G  R499    
 G  R500    
 G  R501    
 G  R502    
 G  R503    
 G  R504    
 G  R505    
 G  R506    
 G  R507    
 G  R508    
 G  R509    
 G  R510    
 G  R511    
 G  R512    
 G  R513    
 G  R514    
 G  R515    
 G  R516    
 G  R517    
 G  R518    
 G  R519    
 G  R520    
 G  R521    
 G  R522    
 G  R523    
 G  R524    
 G  R525    
 G  R526    
 G  R527    
 G  R528    
 G  R529    
 G  R530    
 G  R531    
 G  R532    
 G  R533    
 G  R534    
 G  R535    
 G  R536    
 G  R537    
 G  R538    
 G  R539    
 G  R540    
 G  R541    
 G  R542    
 G  R543    
 G  R544    
 G  R545    
 G  R546    
 G  R547    
 G  R548    
 G  R549    
 G  R550    
 G  R551    
 G  R552    
 G  R553    
 G  R554    
 G  R555    
 G  R556    
 G  R557    
 G  R558    
 G  R559    
 G  R560    
 G  R561    
 G  R562    
 G  R563    
 G  R564    
 G  R565    
 G  R566    
 G  R567    
 G  R568    
 G  R569    
 G  R570    
 G  R571    
 G  R572    
 G  R573    
 G  R574    
 G  R575    
 G  R576    
 G  R577    
 G  R578    
 G  R579    
 G  R580    
 G  R581    
 G  R582    
 G  R583    
 G  R584    
 G  R585    
 G  R586    
 G  R587    
 G  R588    
 G  R589    
 G  R590    
 G  R591    
 G  R592    
 G  R593    
 G  R594    
 G  R595    
 G  R596    
 G  R597    
 G  R598    
 G  R599    
 G  R600    
 G  R601    
 G  R602    
 G  R603    
 G  R604    
 G  R605    
 G  R606    
 G  R607    
 G  R608    
 G  R609    
 G  R610    
 G  R611    
 G  R612    
 G  R613    
 G  R614    
 G  R615    
 G  R616    
 G  R617    
 G  R618    
 G  R619    
 G  R620    
 G  R621    
 G  R622    
 G  R623    
 G  R624    
 G  R625    
 G  R626    
 G  R627    
 G  R628    
 G  R629    
 G  R630    
 G  R631    
 G  R632    
 G  R633    
 G  R634    
 G  R635    
 G  R636    
 G  R637    
 G  R638    
 G  R639    
 G  R640    
 G  R641    
 G  R642    
 G  R643    
 G  R644    
 G  R645    
 G  R646    
 G  R647    
 G  R648    
 G  R649    
 G  R650    
 G  R651    
 G  R652    
 G  R653    
 G  R654    
 G  R655    
 G  R656    
 G  R657    
 G  R658    
 G  R659    
 G  R660    
 G  R661    
 G  R662    
 G  R663    
 G  R664    
 G  R665    
 G  R666    
 G  R667    
 G  R668    
 G  R669    
 G  R670    
 G  R671    
 G  R672    
 G  R673    
 G  R674    
 G  R675    
 G  R676    
 G  R677    
 G  R678    
 G  R679    
 G  R680    
 G  R681    
 G  R682    
 G  R683    
 G  R684    
 G  R685    
 G  R686    
 G  R687    
 G  R688    
 G  R689    
 G  R690    
 G  R691    
 G  R692    
 G  R693    
 G  R694    
 G  R695    
 G  R696    
 G  R697    
 G  R698    
 G  R699    
 G  R700    
 G  R701    
 G  R702    
 G  R703    
 G  R704    
 G  R705    
 G  R706    
 G  R707    
 G  R708    
 G  R709    
 G  R710    
 G  R711    
 G  R712    
 G  R713    
 G  R714    
 G  R715    
 G  R716    
 G  R717    
 G  R718    
 G  R719    
 G  R720    
 G  R721    
 G  R722    
 G  R723    
 G  R724    
 G  R725    
 G  R726    
 G  R727    
 G  R728    
 G  R729    
 G  R730    
 G  R731    
 G  R732    
 G  R733    
 G  R734    
 G  R735    
 G  R736    
 G  R737    
 G  R738    
 G  R739    
 G  R740    
 G  R741    
 G  R742    
 G  R743    
 G  R744    
 G  R745    
 G  R746    
 G  R747    
 G  R748    
 G  R749    
 G  R750    
 G  R751    
 G  R752    
 G  R753    
 G  R754    
 G  R755    
 G  R756    
 G  R757    
 G  R758    
 G  R759    
 G  R760    
 G  R761    
 G  R762    
 G  R763    
 G  R764    
 G  R765    
 G  R766    
 G  R767    
 G  R768    
 G  R769    
 G  R770    
 G  R771    
 G  R772    
 G  R773    
 G  R774    
 G  R775    
 G  R776    
 G  R777    
 G  R778    
 G  R779    
 G  R780    
 G  R781    
 G  R782    
 G  R783    
 G  R784    
 G  R785    
 G  R786    
 G  R787    
 G  R788    
 G  R789    
 G  R790    
 G  R791    
 G  R792    
 G  R793    
 G  R794    
 G  R795    
 G  R796    
 G  R797    
 G  R798    
 G  R799    
 G  R800    
 G  R801    
 G  R802    
 G  R803    
 G  R804    
 G  R805    
 G  R806    
 G  R807    
 G  R808    
 G  R809    
 G  R810    
 G  R811    
 G  R812    
 G  R813    
 G  R814    
 G  R815    
 G  R816    
 G  R817    
 G  R818    
 G  R819    
 G  R820    
 G  R821    
 G  R822    
 G  R823    
 G  R824    
 G  R825    
 G  R826    
 G  R827    
 G  R828    
 G  R829    
 G  R830    
 G  R831    
 G  R832    
 G  R833    
 G  R834    
 G  R835    
 G  R836    
 G  R837    
 G  R838    
 G  R839    
 G  R840    
 G  R841    
 G  R842    
 G  R843    
 G  R844    
 G  R845    
 G  R846    
 G  R847    
 G  R848    
 G  R849    
 G  R850    
 G  R851    
 G  R852    
 G  R853    
 G  R854    
 G  R855    
 G  R856    
 G  R857    
 G  R858    
 G  R859    
 G  R860    
 G  R861    
 G  R862    
 G  R863    
 G  R864    
 G  R865    
 G  R866    
 G  R867    
 G  R868    
 G  R869    
 G  R870    
 G  R871    
 G  R872    
 G  R873    
 G  R874    
 G  R875    
 G  R876    
 G  R877    
 G  R878    
 G  R879    
 G  R880    
 G  R881    
 G  R882    
 G  R883    
 G  R884    
 G  R885    
 G  R886    
 G  R887    
 G  R888    
 G  R889    
 G  R890    
 G  R891    
 G  R892    
 G  R893    
 G  R894    
 G  R895    
 G  R896    
 G  R897    
 G  R898    
 G  R899    
 G  R900    
 G  R901    
 G  R902    
 G  R903    
 G  R904    
 G  R905    
 G  R906    
 G  R907    
 G  R908    
 G  R909    
 G  R910    
 G  R911    
 G  R912    
 G  R913    
 G  R914    
 G  R915    
 G  R916    
 G  R917    
 G  R918    
 G  R919    
 G  R920    
 G  R921    
 G  R922    
 G  R923    
 G  R924    
 G  R925    
 G  R926    
 G  R927    
 G  R928    
 G  R929    
 G  R930    
 G  R931    
 G  R932    
 G  R933    
 G  R934    
 G  R935    
 G  R936    
 G  R937    
 G  R938    
 G  R939    
 G  R940    
 G  R941    
 G  R942    
 G  R943    
 G  R944    
 G  R945    
 G  R946    
 G  R947    
 G  R948    
 G  R949    
 G  R950    
 G  R951    
 G  R952    
 G  R953    
 G  R954    
 G  R955    
 G  R956    
 G  R957    
 G  R958    
 G  R959    
 G  R960    
 G  R961    
 G  R962    
 G  R963    
 G  R964    
 G  R965    
 G  R966    
 G  R967    
 G  R968    
 G  R969    
 G  R970    
 G  R971    
 G  R972    
 G  R973    
 G  R974    
 G  R975    
 G  R976    
 G  R977    
 G  R978    
 G  R979    
 G  R980    
 G  R981    
 G  R982    
 G  R983    
 G  R984    
 G  R985    
 G  R986    
 G  R987    
 G  R988    
 G  R989    
 G  R990    
 G  R991    
 G  R992    
 G  R993    
 G  R994    
 G  R995    
 G  R996    
 G  R997    
 G  R998    
 G  R999    
 G  R1000   
 G  R1001   
 G  R1002   
 G  R1003   
 G  R1004   
 G  R1005   
 G  R1006   
 G  R1007   
 G  R1008   
 G  R1009   
 G  R1010   
 G  R1011   
 G  R1012   
 G  R1013   
 G  R1014   
 G  R1015   
 G  R1016   
 G  R1017   
 G  R1018   
 G  R1019   
 G  R1020   
 G  R1021   
 G  R1022   
 G  R1023   
 G  R1024   
 G  R1025   
 G  R1026   
 G  R1027   
 G  R1028   
 G  R1029   
 G  R1030   
 G  R1031   
 G  R1032   
 G  R1033   
 G  R1034   
 G  R1035   
 G  R1036   
 G  R1037   
 G  R1038   
 G  R1039   
 G  R1040   
 G  R1041   
 G  R1042   
 G  R1043   
 G  R1044   
 G  R1045   
 G  R1046   
 G  R1047   
 G  R1048   
 G  R1049   
 G  R1050   
 G  R1051   
 G  R1052   
 G  R1053   
 G  R1054   
 G  R1055   
 G  R1056   
 G  R1057   
 G  R1058   
 G  R1059   
 G  R1060   
 G  R1061   
 G  R1062   
 G  R1063   
 G  R1064   
 G  R1065   
 G  R1066   
 G  R1067   
 G  R1068   
 G  R1069   
 G  R1070   
 G  R1071   
 G  R1072   
 G  R1073   
 G  R1074   
 G  R1075   
 G  R1076   
 G  R1077   
 G  R1078   
 G  R1079   
 G  R1080   
 G  R1081   
 G  R1082   
 G  R1083   
 G  R1084   
 G  R1085   
 G  R1086   
 G  R1087   
 G  R1088   
 G  R1089   
 G  R1090   
 G  R1091   
 G  R1092   
 G  R1093   
 G  R1094   
 G  R1095   
 G  R1096   
 G  R1097   
 G  R1098   
 G  R1099   
 G  R1100   
 G  R1101   
 G  R1102   
 G  R1103   
 G  R1104   
 G  R1105   
 G  R1106   
 G  R1107   
 G  R1108   
 G  R1109   
 G  R1110   
 G  R1111   
 G  R1112   
 G  R1113   
 G  R1114   
 G  R1115   
 G  R1116   
 G  R1117   
 G  R1118   
 G  R1119   
 G  R1120   
 G  R1121   
 G  R1122   
 G  R1123   
 G  R1124   
 G  R1125   
 G  R1126   
 G  R1127   
 G  R1128   
 G  R1129   
 G  R1130   
 G  R1131   
 G  R1132   
 G  R1133   
 G  R1134   
 G  R1135   
 G  R1136   
 G  R1137   
 G  R1138   
 G  R1139   
 G  R1140   
 G  R1141   
 G  R1142   
 G  R1143   
 G  R1144   
 G  R1145   
 G  R1146   
 G  R1147   
 G  R1148   
 G  R1149   
 G  R1150   
 G  R1151   
 G  R1152   
 G  R1153   
 G  R1154   
 G  R1155   
 G  R1156   
 G  R1157   
 G  R1158   
 G  R1159   
 G  R1160   
 G  R1161   
 G  R1162   
 G  R1163   
 G  R1164   
 G  R1165   
 G  R1166   
 G  R1167   
 G  R1168   
 G  R1169   
 G  R1170   
 G  R1171   
 G  R1172   
 G  R1173   
 G  R1174   
 G  R1175   
 G  R1176   
 G  R1177   
 G  R1178   
 G  R1179   
 G  R1180   
 G  R1181   
 G  R1182   
 G  R1183   
 G  R1184   
 G  R1185   
 G  R1186   
 G  R1187   
 G  R1188   
 G  R1189   
 G  R1190   
 G  R1191   
 G  R1192   
 G  R1193   
 G  R1194   
 G  R1195   
 G  R1196   
 G  R1197   
 G  R1198   
 G  R1199   
 G  R1200   
 G  R1201   
 G  R1202   
 G  R1203   
 G  R1204   
 G  R1205   
 G  R1206   
 G  R1207   
 G  R1208   
 G  R1209   
 G  R1210   
 G  R1211   
 G  R1212   
 G  R1213   
 G  R1214   
 G  R1215   
 G  R1216   
 G  R1217   
 G  R1218   
 G  R1219   
 G  R1220   
 G  R1221   
 G  R1222   
 G  R1223   
 G  R1224   
 G  R1225   
 G  R1226   
 G  R1227   
 G  R1228   
 G  R1229   
 G  R1230   
 G  R1231   
 G  R1232   
 G  R1233   
 G  R1234   
 G  R1235   
 G  R1236   
 G  R1237   
 G  R1238   
 G  R1239   
 G  R1240   
 G  R1241   
 G  R1242   
 G  R1243   
 G  R1244   
 G  R1245   
 G  R1246   
 G  R1247   
 G  R1248   
 G  R1249   
 G  R1250   
 G  R1251   
 G  R1252   
 G  R1253   
 G  R1254   
 G  R1255   
 G  R1256   
 G  R1257   
 G  R1258   
 G  R1259   
 G  R1260   
 G  R1261   
 G  R1262   
 G  R1263   
 G  R1264   
 G  R1265   
 G  R1266   
 G  R1267   
 G  R1268   
 G  R1269   
 G  R1270   
 G  R1271   
 G  R1272   
 G  R1273   
 G  R1274   
 G  R1275   
 G  R1276   
 G  R1277   
 G  R1278   
 G  R1279   
 G  R1280   
 G  R1281   
 G  R1282   
 G  R1283   
 G  R1284   
 G  R1285   
 G  R1286   
 G  R1287   
 G  R1288   
 G  R1289   
 G  R1290   
 G  R1291   
 G  R1292   
 G  R1293   
 G  R1294   
 G  hard_lower
 L  hard_upper
 G  bin_lower
 L  bin_upper
 L  surrogate_G
 L  physical_G_upper
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,4]    OBJ       2.8402349999999996e-02
    x[1,4]    onehot_1  1
    x[1,4]    inventory_1  -4
    x[2,12]   OBJ       7.0949163211153631e-18
    x[2,12]   onehot_2  1
    x[2,12]   inventory_2  -12
    x[3,13]   OBJ       3.7278128571428565e-02
    x[3,13]   onehot_3  1
    x[3,13]   inventory_3  -13
    x[4,7]    OBJ       2.4142438048713188e-18
    x[4,7]    onehot_4  1
    x[4,7]    inventory_4  -7
    x[4,13]   OBJ       -1.6777748510373044e-02
    x[4,13]   onehot_4  1
    x[4,13]   inventory_4  -13
    x[5,8]    onehot_5  1
    x[5,8]    inventory_5  -8
    x[6,4]    OBJ       3.9940833333333328e-02
    x[6,4]    onehot_6  1
    x[6,4]    inventory_6  -4
    x[7,10]   OBJ       4.9270254542932435e-18
    x[7,10]   onehot_7  1
    x[7,10]   inventory_7  -10
    x[8,7]    OBJ       2.4142438048713188e-18
    x[8,7]    onehot_8  1
    x[8,7]    inventory_8  -7
    x[8,13]   OBJ       -1.6777748510373044e-02
    x[8,13]   onehot_8  1
    x[8,13]   inventory_8  -13
    x[9,5]    OBJ       -1.2618428572802692e-02
    x[9,5]    onehot_9  1
    x[9,5]    inventory_9  -5
    x[9,10]   OBJ       4.9270254542932435e-18
    x[9,10]   onehot_9  1
    x[9,10]   inventory_9  -10
    x[10,4]   OBJ       -8.1300226228394022e-03
    x[10,4]   onehot_10  1
    x[10,4]   inventory_10  -4
    x[10,6]   OBJ       1.7737311619470120e-18
    x[10,6]   onehot_10  1
    x[10,6]   inventory_10  -6
    x[10,7]   OBJ       -3.4758171589391036e-03
    x[10,7]   onehot_10  1
    x[10,7]   inventory_10  -7
    x[11,7]   OBJ       2.4142438048713188e-18
    x[11,7]   onehot_11  1
    x[11,7]   inventory_11  -7
    x[12,8]   onehot_12  1
    x[12,8]   inventory_12  -8
    x[12,14]  OBJ       -1.4485639808224775e-02
    x[12,14]  onehot_12  1
    x[12,14]  inventory_12  -14
    x[13,10]  OBJ       4.9270254542932435e-18
    x[13,10]  onehot_13  1
    x[13,10]  inventory_13  -10
    x[14,10]  OBJ       4.9270254542932435e-18
    x[14,10]  onehot_14  1
    x[14,10]  inventory_14  -10
    x[15,10]  OBJ       4.9270254542932435e-18
    x[15,10]  onehot_15  1
    x[15,10]  inventory_15  -10
    x[16,3]   OBJ       8.8757399999999983e-03
    x[16,3]   onehot_16  1
    x[16,3]   inventory_16  -3
    x[16,11]  OBJ       -5.3688579971921226e-03
    x[16,11]  onehot_16  1
    x[16,11]  inventory_16  -11
    x[17,16]  OBJ       5.5917166666666657e-02
    x[17,16]  onehot_17  1
    x[17,16]  inventory_17  -16
    x[18,7]   OBJ       2.4142438048713188e-18
    x[18,7]   onehot_18  1
    x[18,7]   inventory_18  -7
    x[19,9]   OBJ       3.9908909510444345e-18
    x[19,9]   onehot_19  1
    x[19,9]   inventory_19  -9
    x[20,7]   OBJ       2.4142438048713188e-18
    x[20,7]   onehot_20  1
    x[20,7]   inventory_20  -7
    x[20,13]  OBJ       -1.6777748510373044e-02
    x[20,13]  onehot_20  1
    x[20,13]  inventory_20  -13
    x[21,9]   OBJ       3.9908909510444345e-18
    x[21,9]   onehot_21  1
    x[21,9]   inventory_21  -9
    x[22,10]  OBJ       4.9270254542932435e-18
    x[22,10]  onehot_22  1
    x[22,10]  inventory_22  -10
    x[23,8]   onehot_23  1
    x[23,8]   inventory_23  -8
    x[23,13]  OBJ       -1.1530564158295186e-02
    x[23,13]  onehot_23  1
    x[23,13]  inventory_23  -13
    x[24,2]   OBJ       0.0075
    x[24,2]   onehot_24  1
    x[24,2]   inventory_24  -2
    x[24,4]   OBJ       2.0118428572802695e-02
    x[24,4]   onehot_24  1
    x[24,4]   inventory_24  -4
    x[24,5]   OBJ       1.4785771265787832e-02
    x[24,5]   onehot_24  1
    x[24,5]   inventory_24  -5
    x[24,6]   OBJ       9.5176300622384843e-03
    x[24,6]   onehot_24  1
    x[24,6]   inventory_24  -6
    x[24,7]   OBJ       4.3339424340683441e-03
    x[24,7]   onehot_24  1
    x[24,7]   inventory_24  -7
    x[24,8]   OBJ       -3.2409046155872784e-04
    x[24,8]   onehot_24  1
    x[24,8]   inventory_24  -8
    x[25,7]   OBJ       2.4142438048713188e-18
    x[25,7]   onehot_25  1
    x[25,7]   inventory_25  -7
    x[26,8]   onehot_26  1
    x[26,8]   inventory_26  -8
    x[26,13]  OBJ       -1.3269172824240897e-02
    x[26,13]  onehot_26  1
    x[26,13]  inventory_26  -13
    x[27,9]   OBJ       3.9908909510444345e-18
    x[27,9]   onehot_27  1
    x[27,9]   inventory_27  -9
    x[28,7]   OBJ       2.4142438048713188e-18
    x[28,7]   onehot_28  1
    x[28,7]   inventory_28  -7
    x[29,7]   OBJ       2.4142438048713188e-18
    x[29,7]   onehot_29  1
    x[29,7]   inventory_29  -7
    x[29,12]  OBJ       -1.4215893804213606e-02
    x[29,12]  onehot_29  1
    x[29,12]  inventory_29  -12
    x[30,11]  OBJ       2.9808489010463287e-18
    x[30,11]  onehot_30  1
    x[30,11]  inventory_30  -11
    x[31,7]   OBJ       2.4142438048713188e-18
    x[31,7]   onehot_31  1
    x[31,7]   inventory_31  -7
    x[32,8]   onehot_32  1
    x[32,8]   inventory_32  -8
    x[33,13]  OBJ       8.3266726846886737e-18
    x[33,13]  onehot_33  1
    x[33,13]  inventory_33  -13
    x[34,8]   onehot_34  1
    x[34,8]   inventory_34  -8
    x[35,9]   OBJ       3.9908909510444345e-18
    x[35,9]   onehot_35  1
    x[35,9]   inventory_35  -9
    MARKER    'MARKER'                 'INTEND'
    Y[1]      inventory_1  1
    Y[1]      ratio_1   -0.125
    Y[1]      hard_lower  1
    Y[1]      hard_upper  1
    Y[2]      inventory_2  1
    Y[2]      ratio_2   -8.3333333333333329e-02
    Y[2]      hard_lower  1
    Y[2]      hard_upper  1
    Y[3]      inventory_3  1
    Y[3]      ratio_3   -1.4285714285714285e-01
    Y[3]      hard_lower  1
    Y[3]      hard_upper  1
    Y[4]      inventory_4  1
    Y[4]      ratio_4   -1.4285714285714285e-01
    Y[4]      hard_lower  1
    Y[4]      hard_upper  1
    Y[5]      inventory_5  1
    Y[5]      ratio_5   -0.125
    Y[5]      hard_lower  1
    Y[5]      hard_upper  1
    Y[6]      inventory_6  1
    Y[6]      ratio_6   -1.1111111111111110e-01
    Y[6]      hard_lower  1
    Y[6]      hard_upper  1
    Y[7]      inventory_7  1
    Y[7]      ratio_7   -0.1
    Y[7]      hard_lower  1
    Y[7]      hard_upper  1
    Y[8]      inventory_8  1
    Y[8]      ratio_8   -1.4285714285714285e-01
    Y[8]      hard_lower  1
    Y[8]      hard_upper  1
    Y[9]      inventory_9  1
    Y[9]      ratio_9   -0.1
    Y[9]      hard_lower  1
    Y[9]      hard_upper  1
    Y[10]     inventory_10  1
    Y[10]     ratio_10  -1.6666666666666666e-01
    Y[10]     hard_lower  1
    Y[10]     hard_upper  1
    Y[11]     inventory_11  1
    Y[11]     ratio_11  -1.4285714285714285e-01
    Y[11]     hard_lower  1
    Y[11]     hard_upper  1
    Y[12]     inventory_12  1
    Y[12]     ratio_12  -0.125
    Y[12]     hard_lower  1
    Y[12]     hard_upper  1
    Y[13]     inventory_13  1
    Y[13]     ratio_13  -0.1
    Y[13]     hard_lower  1
    Y[13]     hard_upper  1
    Y[14]     inventory_14  1
    Y[14]     ratio_14  -0.1
    Y[14]     hard_lower  1
    Y[14]     hard_upper  1
    Y[15]     inventory_15  1
    Y[15]     ratio_15  -0.1
    Y[15]     hard_lower  1
    Y[15]     hard_upper  1
    Y[16]     inventory_16  1
    Y[16]     ratio_16  -0.2
    Y[16]     hard_lower  1
    Y[16]     hard_upper  1
    Y[17]     inventory_17  1
    Y[17]     ratio_17  -1.1111111111111110e-01
    Y[17]     hard_lower  1
    Y[17]     hard_upper  1
    Y[18]     inventory_18  1
    Y[18]     ratio_18  -1.4285714285714285e-01
    Y[18]     hard_lower  1
    Y[18]     hard_upper  1
    Y[19]     inventory_19  1
    Y[19]     ratio_19  -1.1111111111111110e-01
    Y[19]     hard_lower  1
    Y[19]     hard_upper  1
    Y[20]     inventory_20  1
    Y[20]     ratio_20  -1.4285714285714285e-01
    Y[20]     hard_lower  1
    Y[20]     hard_upper  1
    Y[21]     inventory_21  1
    Y[21]     ratio_21  -1.1111111111111110e-01
    Y[21]     hard_lower  1
    Y[21]     hard_upper  1
    Y[22]     inventory_22  1
    Y[22]     ratio_22  -0.1
    Y[22]     hard_lower  1
    Y[22]     hard_upper  1
    Y[23]     inventory_23  1
    Y[23]     ratio_23  -0.125
    Y[23]     hard_lower  1
    Y[23]     hard_upper  1
    Y[24]     inventory_24  1
    Y[24]     ratio_24  -0.25
    Y[24]     hard_lower  1
    Y[24]     hard_upper  1
    Y[25]     inventory_25  1
    Y[25]     ratio_25  -1.4285714285714285e-01
    Y[25]     hard_lower  1
    Y[25]     hard_upper  1
    Y[26]     inventory_26  1
    Y[26]     ratio_26  -0.125
    Y[26]     hard_lower  1
    Y[26]     hard_upper  1
    Y[27]     inventory_27  1
    Y[27]     ratio_27  -1.1111111111111110e-01
    Y[27]     hard_lower  1
    Y[27]     hard_upper  1
    Y[28]     inventory_28  1
    Y[28]     ratio_28  -1.4285714285714285e-01
    Y[28]     hard_lower  1
    Y[28]     hard_upper  1
    Y[29]     inventory_29  1
    Y[29]     ratio_29  -1.4285714285714285e-01
    Y[29]     hard_lower  1
    Y[29]     hard_upper  1
    Y[30]     inventory_30  1
    Y[30]     ratio_30  -9.0909090909090912e-02
    Y[30]     hard_lower  1
    Y[30]     hard_upper  1
    Y[31]     inventory_31  1
    Y[31]     ratio_31  -1.4285714285714285e-01
    Y[31]     hard_lower  1
    Y[31]     hard_upper  1
    Y[32]     inventory_32  1
    Y[32]     ratio_32  -0.125
    Y[32]     hard_lower  1
    Y[32]     hard_upper  1
    Y[33]     inventory_33  1
    Y[33]     ratio_33  -7.6923076923076927e-02
    Y[33]     hard_lower  1
    Y[33]     hard_upper  1
    Y[34]     inventory_34  1
    Y[34]     ratio_34  -0.125
    Y[34]     hard_lower  1
    Y[34]     hard_upper  1
    Y[35]     inventory_35  1
    Y[35]     ratio_35  -1.1111111111111110e-01
    Y[35]     hard_lower  1
    Y[35]     hard_upper  1
    r[1]      ratio_1   1
    r[1]      R105      -1
    r[1]      R106      1
    r[1]      R107      -1
    r[1]      R108      1
    r[1]      R109      -1
    r[1]      R110      1
    r[1]      R111      -1
    r[1]      R112      1
    r[1]      R113      -1
    r[1]      R114      1
    r[1]      R115      -1
    r[1]      R116      1
    r[1]      R117      -1
    r[1]      R118      1
    r[1]      R119      -1
    r[1]      R120      1
    r[1]      R121      -1
    r[1]      R122      1
    r[1]      R123      -1
    r[1]      R124      1
    r[1]      R125      -1
    r[1]      R126      1
    r[1]      R127      -1
    r[1]      R128      1
    r[1]      R129      -1
    r[1]      R130      1
    r[1]      R131      -1
    r[1]      R132      1
    r[1]      R133      -1
    r[1]      R134      1
    r[1]      R135      -1
    r[1]      R136      1
    r[1]      R137      -1
    r[1]      R138      1
    r[1]      R139      -1
    r[1]      R140      1
    r[1]      R141      -1
    r[1]      R142      1
    r[1]      R143      -1
    r[1]      R144      1
    r[1]      R145      -1
    r[1]      R146      1
    r[1]      R147      -1
    r[1]      R148      1
    r[1]      R149      -1
    r[1]      R150      1
    r[1]      R151      -1
    r[1]      R152      1
    r[1]      R153      -1
    r[1]      R154      1
    r[1]      R155      -1
    r[1]      R156      1
    r[1]      R157      -1
    r[1]      R158      1
    r[1]      R159      -1
    r[1]      R160      1
    r[1]      R161      -1
    r[1]      R162      1
    r[1]      R163      -1
    r[1]      R164      1
    r[1]      R165      -1
    r[1]      R166      1
    r[1]      R167      -1
    r[1]      R168      1
    r[1]      R169      -1
    r[1]      R170      1
    r[1]      R171      -1
    r[1]      R172      1
    r[1]      bin_lower  1
    r[1]      bin_upper  1
    r[1]      physical_G_upper  -2.6860981165365086e+01
    r[2]      ratio_2   1
    r[2]      R105      1
    r[2]      R106      -1
    r[2]      R173      -1
    r[2]      R174      1
    r[2]      R175      -1
    r[2]      R176      1
    r[2]      R177      -1
    r[2]      R178      1
    r[2]      R179      -1
    r[2]      R180      1
    r[2]      R181      -1
    r[2]      R182      1
    r[2]      R183      -1
    r[2]      R184      1
    r[2]      R185      -1
    r[2]      R186      1
    r[2]      R187      -1
    r[2]      R188      1
    r[2]      R189      -1
    r[2]      R190      1
    r[2]      R191      -1
    r[2]      R192      1
    r[2]      R193      -1
    r[2]      R194      1
    r[2]      R195      -1
    r[2]      R196      1
    r[2]      R197      -1
    r[2]      R198      1
    r[2]      R199      -1
    r[2]      R200      1
    r[2]      R201      -1
    r[2]      R202      1
    r[2]      R203      -1
    r[2]      R204      1
    r[2]      R205      -1
    r[2]      R206      1
    r[2]      R207      -1
    r[2]      R208      1
    r[2]      R209      -1
    r[2]      R210      1
    r[2]      R211      -1
    r[2]      R212      1
    r[2]      R213      -1
    r[2]      R214      1
    r[2]      R215      -1
    r[2]      R216      1
    r[2]      R217      -1
    r[2]      R218      1
    r[2]      R219      -1
    r[2]      R220      1
    r[2]      R221      -1
    r[2]      R222      1
    r[2]      R223      -1
    r[2]      R224      1
    r[2]      R225      -1
    r[2]      R226      1
    r[2]      R227      -1
    r[2]      R228      1
    r[2]      R229      -1
    r[2]      R230      1
    r[2]      R231      -1
    r[2]      R232      1
    r[2]      R233      -1
    r[2]      R234      1
    r[2]      R235      -1
    r[2]      R236      1
    r[2]      R237      -1
    r[2]      R238      1
    r[2]      bin_lower  1
    r[2]      bin_upper  1
    r[2]      physical_G_upper  -2.6860981165365086e+01
    r[3]      ratio_3   1
    r[3]      R107      1
    r[3]      R108      -1
    r[3]      R173      1
    r[3]      R174      -1
    r[3]      R239      -1
    r[3]      R240      1
    r[3]      R241      -1
    r[3]      R242      1
    r[3]      R243      -1
    r[3]      R244      1
    r[3]      R245      -1
    r[3]      R246      1
    r[3]      R247      -1
    r[3]      R248      1
    r[3]      R249      -1
    r[3]      R250      1
    r[3]      R251      -1
    r[3]      R252      1
    r[3]      R253      -1
    r[3]      R254      1
    r[3]      R255      -1
    r[3]      R256      1
    r[3]      R257      -1
    r[3]      R258      1
    r[3]      R259      -1
    r[3]      R260      1
    r[3]      R261      -1
    r[3]      R262      1
    r[3]      R263      -1
    r[3]      R264      1
    r[3]      R265      -1
    r[3]      R266      1
    r[3]      R267      -1
    r[3]      R268      1
    r[3]      R269      -1
    r[3]      R270      1
    r[3]      R271      -1
    r[3]      R272      1
    r[3]      R273      -1
    r[3]      R274      1
    r[3]      R275      -1
    r[3]      R276      1
    r[3]      R277      -1
    r[3]      R278      1
    r[3]      R279      -1
    r[3]      R280      1
    r[3]      R281      -1
    r[3]      R282      1
    r[3]      R283      -1
    r[3]      R284      1
    r[3]      R285      -1
    r[3]      R286      1
    r[3]      R287      -1
    r[3]      R288      1
    r[3]      R289      -1
    r[3]      R290      1
    r[3]      R291      -1
    r[3]      R292      1
    r[3]      R293      -1
    r[3]      R294      1
    r[3]      R295      -1
    r[3]      R296      1
    r[3]      R297      -1
    r[3]      R298      1
    r[3]      R299      -1
    r[3]      R300      1
    r[3]      R301      -1
    r[3]      R302      1
    r[3]      bin_lower  1
    r[3]      bin_upper  1
    r[3]      physical_G_upper  -2.6860981165365086e+01
    r[4]      ratio_4   1
    r[4]      R109      1
    r[4]      R110      -1
    r[4]      R175      1
    r[4]      R176      -1
    r[4]      R239      1
    r[4]      R240      -1
    r[4]      R303      -1
    r[4]      R304      1
    r[4]      R305      -1
    r[4]      R306      1
    r[4]      R307      -1
    r[4]      R308      1
    r[4]      R309      -1
    r[4]      R310      1
    r[4]      R311      -1
    r[4]      R312      1
    r[4]      R313      -1
    r[4]      R314      1
    r[4]      R315      -1
    r[4]      R316      1
    r[4]      R317      -1
    r[4]      R318      1
    r[4]      R319      -1
    r[4]      R320      1
    r[4]      R321      -1
    r[4]      R322      1
    r[4]      R323      -1
    r[4]      R324      1
    r[4]      R325      -1
    r[4]      R326      1
    r[4]      R327      -1
    r[4]      R328      1
    r[4]      R329      -1
    r[4]      R330      1
    r[4]      R331      -1
    r[4]      R332      1
    r[4]      R333      -1
    r[4]      R334      1
    r[4]      R335      -1
    r[4]      R336      1
    r[4]      R337      -1
    r[4]      R338      1
    r[4]      R339      -1
    r[4]      R340      1
    r[4]      R341      -1
    r[4]      R342      1
    r[4]      R343      -1
    r[4]      R344      1
    r[4]      R345      -1
    r[4]      R346      1
    r[4]      R347      -1
    r[4]      R348      1
    r[4]      R349      -1
    r[4]      R350      1
    r[4]      R351      -1
    r[4]      R352      1
    r[4]      R353      -1
    r[4]      R354      1
    r[4]      R355      -1
    r[4]      R356      1
    r[4]      R357      -1
    r[4]      R358      1
    r[4]      R359      -1
    r[4]      R360      1
    r[4]      R361      -1
    r[4]      R362      1
    r[4]      R363      -1
    r[4]      R364      1
    r[4]      bin_lower  1
    r[4]      bin_upper  1
    r[4]      physical_G_upper  -2.6860981165365086e+01
    r[5]      ratio_5   1
    r[5]      R111      1
    r[5]      R112      -1
    r[5]      R177      1
    r[5]      R178      -1
    r[5]      R241      1
    r[5]      R242      -1
    r[5]      R303      1
    r[5]      R304      -1
    r[5]      R365      -1
    r[5]      R366      1
    r[5]      R367      -1
    r[5]      R368      1
    r[5]      R369      -1
    r[5]      R370      1
    r[5]      R371      -1
    r[5]      R372      1
    r[5]      R373      -1
    r[5]      R374      1
    r[5]      R375      -1
    r[5]      R376      1
    r[5]      R377      -1
    r[5]      R378      1
    r[5]      R379      -1
    r[5]      R380      1
    r[5]      R381      -1
    r[5]      R382      1
    r[5]      R383      -1
    r[5]      R384      1
    r[5]      R385      -1
    r[5]      R386      1
    r[5]      R387      -1
    r[5]      R388      1
    r[5]      R389      -1
    r[5]      R390      1
    r[5]      R391      -1
    r[5]      R392      1
    r[5]      R393      -1
    r[5]      R394      1
    r[5]      R395      -1
    r[5]      R396      1
    r[5]      R397      -1
    r[5]      R398      1
    r[5]      R399      -1
    r[5]      R400      1
    r[5]      R401      -1
    r[5]      R402      1
    r[5]      R403      -1
    r[5]      R404      1
    r[5]      R405      -1
    r[5]      R406      1
    r[5]      R407      -1
    r[5]      R408      1
    r[5]      R409      -1
    r[5]      R410      1
    r[5]      R411      -1
    r[5]      R412      1
    r[5]      R413      -1
    r[5]      R414      1
    r[5]      R415      -1
    r[5]      R416      1
    r[5]      R417      -1
    r[5]      R418      1
    r[5]      R419      -1
    r[5]      R420      1
    r[5]      R421      -1
    r[5]      R422      1
    r[5]      R423      -1
    r[5]      R424      1
    r[5]      bin_lower  1
    r[5]      bin_upper  1
    r[5]      physical_G_upper  -2.6860981165365086e+01
    r[6]      ratio_6   1
    r[6]      R113      1
    r[6]      R114      -1
    r[6]      R179      1
    r[6]      R180      -1
    r[6]      R243      1
    r[6]      R244      -1
    r[6]      R305      1
    r[6]      R306      -1
    r[6]      R365      1
    r[6]      R366      -1
    r[6]      R425      -1
    r[6]      R426      1
    r[6]      R427      -1
    r[6]      R428      1
    r[6]      R429      -1
    r[6]      R430      1
    r[6]      R431      -1
    r[6]      R432      1
    r[6]      R433      -1
    r[6]      R434      1
    r[6]      R435      -1
    r[6]      R436      1
    r[6]      R437      -1
    r[6]      R438      1
    r[6]      R439      -1
    r[6]      R440      1
    r[6]      R441      -1
    r[6]      R442      1
    r[6]      R443      -1
    r[6]      R444      1
    r[6]      R445      -1
    r[6]      R446      1
    r[6]      R447      -1
    r[6]      R448      1
    r[6]      R449      -1
    r[6]      R450      1
    r[6]      R451      -1
    r[6]      R452      1
    r[6]      R453      -1
    r[6]      R454      1
    r[6]      R455      -1
    r[6]      R456      1
    r[6]      R457      -1
    r[6]      R458      1
    r[6]      R459      -1
    r[6]      R460      1
    r[6]      R461      -1
    r[6]      R462      1
    r[6]      R463      -1
    r[6]      R464      1
    r[6]      R465      -1
    r[6]      R466      1
    r[6]      R467      -1
    r[6]      R468      1
    r[6]      R469      -1
    r[6]      R470      1
    r[6]      R471      -1
    r[6]      R472      1
    r[6]      R473      -1
    r[6]      R474      1
    r[6]      R475      -1
    r[6]      R476      1
    r[6]      R477      -1
    r[6]      R478      1
    r[6]      R479      -1
    r[6]      R480      1
    r[6]      R481      -1
    r[6]      R482      1
    r[6]      bin_lower  1
    r[6]      bin_upper  1
    r[6]      physical_G_upper  -2.6860981165365086e+01
    r[7]      ratio_7   1
    r[7]      R115      1
    r[7]      R116      -1
    r[7]      R181      1
    r[7]      R182      -1
    r[7]      R245      1
    r[7]      R246      -1
    r[7]      R307      1
    r[7]      R308      -1
    r[7]      R367      1
    r[7]      R368      -1
    r[7]      R425      1
    r[7]      R426      -1
    r[7]      R483      -1
    r[7]      R484      1
    r[7]      R485      -1
    r[7]      R486      1
    r[7]      R487      -1
    r[7]      R488      1
    r[7]      R489      -1
    r[7]      R490      1
    r[7]      R491      -1
    r[7]      R492      1
    r[7]      R493      -1
    r[7]      R494      1
    r[7]      R495      -1
    r[7]      R496      1
    r[7]      R497      -1
    r[7]      R498      1
    r[7]      R499      -1
    r[7]      R500      1
    r[7]      R501      -1
    r[7]      R502      1
    r[7]      R503      -1
    r[7]      R504      1
    r[7]      R505      -1
    r[7]      R506      1
    r[7]      R507      -1
    r[7]      R508      1
    r[7]      R509      -1
    r[7]      R510      1
    r[7]      R511      -1
    r[7]      R512      1
    r[7]      R513      -1
    r[7]      R514      1
    r[7]      R515      -1
    r[7]      R516      1
    r[7]      R517      -1
    r[7]      R518      1
    r[7]      R519      -1
    r[7]      R520      1
    r[7]      R521      -1
    r[7]      R522      1
    r[7]      R523      -1
    r[7]      R524      1
    r[7]      R525      -1
    r[7]      R526      1
    r[7]      R527      -1
    r[7]      R528      1
    r[7]      R529      -1
    r[7]      R530      1
    r[7]      R531      -1
    r[7]      R532      1
    r[7]      R533      -1
    r[7]      R534      1
    r[7]      R535      -1
    r[7]      R536      1
    r[7]      R537      -1
    r[7]      R538      1
    r[7]      bin_lower  1
    r[7]      bin_upper  1
    r[7]      physical_G_upper  -2.6860981165365086e+01
    r[8]      ratio_8   1
    r[8]      R117      1
    r[8]      R118      -1
    r[8]      R183      1
    r[8]      R184      -1
    r[8]      R247      1
    r[8]      R248      -1
    r[8]      R309      1
    r[8]      R310      -1
    r[8]      R369      1
    r[8]      R370      -1
    r[8]      R427      1
    r[8]      R428      -1
    r[8]      R483      1
    r[8]      R484      -1
    r[8]      R539      -1
    r[8]      R540      1
    r[8]      R541      -1
    r[8]      R542      1
    r[8]      R543      -1
    r[8]      R544      1
    r[8]      R545      -1
    r[8]      R546      1
    r[8]      R547      -1
    r[8]      R548      1
    r[8]      R549      -1
    r[8]      R550      1
    r[8]      R551      -1
    r[8]      R552      1
    r[8]      R553      -1
    r[8]      R554      1
    r[8]      R555      -1
    r[8]      R556      1
    r[8]      R557      -1
    r[8]      R558      1
    r[8]      R559      -1
    r[8]      R560      1
    r[8]      R561      -1
    r[8]      R562      1
    r[8]      R563      -1
    r[8]      R564      1
    r[8]      R565      -1
    r[8]      R566      1
    r[8]      R567      -1
    r[8]      R568      1
    r[8]      R569      -1
    r[8]      R570      1
    r[8]      R571      -1
    r[8]      R572      1
    r[8]      R573      -1
    r[8]      R574      1
    r[8]      R575      -1
    r[8]      R576      1
    r[8]      R577      -1
    r[8]      R578      1
    r[8]      R579      -1
    r[8]      R580      1
    r[8]      R581      -1
    r[8]      R582      1
    r[8]      R583      -1
    r[8]      R584      1
    r[8]      R585      -1
    r[8]      R586      1
    r[8]      R587      -1
    r[8]      R588      1
    r[8]      R589      -1
    r[8]      R590      1
    r[8]      R591      -1
    r[8]      R592      1
    r[8]      bin_lower  1
    r[8]      bin_upper  1
    r[8]      physical_G_upper  -2.6860981165365086e+01
    r[9]      ratio_9   1
    r[9]      R119      1
    r[9]      R120      -1
    r[9]      R185      1
    r[9]      R186      -1
    r[9]      R249      1
    r[9]      R250      -1
    r[9]      R311      1
    r[9]      R312      -1
    r[9]      R371      1
    r[9]      R372      -1
    r[9]      R429      1
    r[9]      R430      -1
    r[9]      R485      1
    r[9]      R486      -1
    r[9]      R539      1
    r[9]      R540      -1
    r[9]      R593      -1
    r[9]      R594      1
    r[9]      R595      -1
    r[9]      R596      1
    r[9]      R597      -1
    r[9]      R598      1
    r[9]      R599      -1
    r[9]      R600      1
    r[9]      R601      -1
    r[9]      R602      1
    r[9]      R603      -1
    r[9]      R604      1
    r[9]      R605      -1
    r[9]      R606      1
    r[9]      R607      -1
    r[9]      R608      1
    r[9]      R609      -1
    r[9]      R610      1
    r[9]      R611      -1
    r[9]      R612      1
    r[9]      R613      -1
    r[9]      R614      1
    r[9]      R615      -1
    r[9]      R616      1
    r[9]      R617      -1
    r[9]      R618      1
    r[9]      R619      -1
    r[9]      R620      1
    r[9]      R621      -1
    r[9]      R622      1
    r[9]      R623      -1
    r[9]      R624      1
    r[9]      R625      -1
    r[9]      R626      1
    r[9]      R627      -1
    r[9]      R628      1
    r[9]      R629      -1
    r[9]      R630      1
    r[9]      R631      -1
    r[9]      R632      1
    r[9]      R633      -1
    r[9]      R634      1
    r[9]      R635      -1
    r[9]      R636      1
    r[9]      R637      -1
    r[9]      R638      1
    r[9]      R639      -1
    r[9]      R640      1
    r[9]      R641      -1
    r[9]      R642      1
    r[9]      R643      -1
    r[9]      R644      1
    r[9]      bin_lower  1
    r[9]      bin_upper  1
    r[9]      physical_G_upper  -2.6860981165365086e+01
    r[10]     ratio_10  1
    r[10]     R121      1
    r[10]     R122      -1
    r[10]     R187      1
    r[10]     R188      -1
    r[10]     R251      1
    r[10]     R252      -1
    r[10]     R313      1
    r[10]     R314      -1
    r[10]     R373      1
    r[10]     R374      -1
    r[10]     R431      1
    r[10]     R432      -1
    r[10]     R487      1
    r[10]     R488      -1
    r[10]     R541      1
    r[10]     R542      -1
    r[10]     R593      1
    r[10]     R594      -1
    r[10]     R645      -1
    r[10]     R646      1
    r[10]     R647      -1
    r[10]     R648      1
    r[10]     R649      -1
    r[10]     R650      1
    r[10]     R651      -1
    r[10]     R652      1
    r[10]     R653      -1
    r[10]     R654      1
    r[10]     R655      -1
    r[10]     R656      1
    r[10]     R657      -1
    r[10]     R658      1
    r[10]     R659      -1
    r[10]     R660      1
    r[10]     R661      -1
    r[10]     R662      1
    r[10]     R663      -1
    r[10]     R664      1
    r[10]     R665      -1
    r[10]     R666      1
    r[10]     R667      -1
    r[10]     R668      1
    r[10]     R669      -1
    r[10]     R670      1
    r[10]     R671      -1
    r[10]     R672      1
    r[10]     R673      -1
    r[10]     R674      1
    r[10]     R675      -1
    r[10]     R676      1
    r[10]     R677      -1
    r[10]     R678      1
    r[10]     R679      -1
    r[10]     R680      1
    r[10]     R681      -1
    r[10]     R682      1
    r[10]     R683      -1
    r[10]     R684      1
    r[10]     R685      -1
    r[10]     R686      1
    r[10]     R687      -1
    r[10]     R688      1
    r[10]     R689      -1
    r[10]     R690      1
    r[10]     R691      -1
    r[10]     R692      1
    r[10]     R693      -1
    r[10]     R694      1
    r[10]     bin_lower  1
    r[10]     bin_upper  1
    r[10]     physical_G_upper  -2.6860981165365086e+01
    r[11]     ratio_11  1
    r[11]     R123      1
    r[11]     R124      -1
    r[11]     R189      1
    r[11]     R190      -1
    r[11]     R253      1
    r[11]     R254      -1
    r[11]     R315      1
    r[11]     R316      -1
    r[11]     R375      1
    r[11]     R376      -1
    r[11]     R433      1
    r[11]     R434      -1
    r[11]     R489      1
    r[11]     R490      -1
    r[11]     R543      1
    r[11]     R544      -1
    r[11]     R595      1
    r[11]     R596      -1
    r[11]     R645      1
    r[11]     R646      -1
    r[11]     R695      -1
    r[11]     R696      1
    r[11]     R697      -1
    r[11]     R698      1
    r[11]     R699      -1
    r[11]     R700      1
    r[11]     R701      -1
    r[11]     R702      1
    r[11]     R703      -1
    r[11]     R704      1
    r[11]     R705      -1
    r[11]     R706      1
    r[11]     R707      -1
    r[11]     R708      1
    r[11]     R709      -1
    r[11]     R710      1
    r[11]     R711      -1
    r[11]     R712      1
    r[11]     R713      -1
    r[11]     R714      1
    r[11]     R715      -1
    r[11]     R716      1
    r[11]     R717      -1
    r[11]     R718      1
    r[11]     R719      -1
    r[11]     R720      1
    r[11]     R721      -1
    r[11]     R722      1
    r[11]     R723      -1
    r[11]     R724      1
    r[11]     R725      -1
    r[11]     R726      1
    r[11]     R727      -1
    r[11]     R728      1
    r[11]     R729      -1
    r[11]     R730      1
    r[11]     R731      -1
    r[11]     R732      1
    r[11]     R733      -1
    r[11]     R734      1
    r[11]     R735      -1
    r[11]     R736      1
    r[11]     R737      -1
    r[11]     R738      1
    r[11]     R739      -1
    r[11]     R740      1
    r[11]     R741      -1
    r[11]     R742      1
    r[11]     bin_lower  1
    r[11]     bin_upper  1
    r[11]     physical_G_upper  -2.6860981165365086e+01
    r[12]     ratio_12  1
    r[12]     R125      1
    r[12]     R126      -1
    r[12]     R191      1
    r[12]     R192      -1
    r[12]     R255      1
    r[12]     R256      -1
    r[12]     R317      1
    r[12]     R318      -1
    r[12]     R377      1
    r[12]     R378      -1
    r[12]     R435      1
    r[12]     R436      -1
    r[12]     R491      1
    r[12]     R492      -1
    r[12]     R545      1
    r[12]     R546      -1
    r[12]     R597      1
    r[12]     R598      -1
    r[12]     R647      1
    r[12]     R648      -1
    r[12]     R695      1
    r[12]     R696      -1
    r[12]     R743      -1
    r[12]     R744      1
    r[12]     R745      -1
    r[12]     R746      1
    r[12]     R747      -1
    r[12]     R748      1
    r[12]     R749      -1
    r[12]     R750      1
    r[12]     R751      -1
    r[12]     R752      1
    r[12]     R753      -1
    r[12]     R754      1
    r[12]     R755      -1
    r[12]     R756      1
    r[12]     R757      -1
    r[12]     R758      1
    r[12]     R759      -1
    r[12]     R760      1
    r[12]     R761      -1
    r[12]     R762      1
    r[12]     R763      -1
    r[12]     R764      1
    r[12]     R765      -1
    r[12]     R766      1
    r[12]     R767      -1
    r[12]     R768      1
    r[12]     R769      -1
    r[12]     R770      1
    r[12]     R771      -1
    r[12]     R772      1
    r[12]     R773      -1
    r[12]     R774      1
    r[12]     R775      -1
    r[12]     R776      1
    r[12]     R777      -1
    r[12]     R778      1
    r[12]     R779      -1
    r[12]     R780      1
    r[12]     R781      -1
    r[12]     R782      1
    r[12]     R783      -1
    r[12]     R784      1
    r[12]     R785      -1
    r[12]     R786      1
    r[12]     R787      -1
    r[12]     R788      1
    r[12]     bin_lower  1
    r[12]     bin_upper  1
    r[12]     physical_G_upper  -2.6860981165365086e+01
    r[13]     ratio_13  1
    r[13]     R127      1
    r[13]     R128      -1
    r[13]     R193      1
    r[13]     R194      -1
    r[13]     R257      1
    r[13]     R258      -1
    r[13]     R319      1
    r[13]     R320      -1
    r[13]     R379      1
    r[13]     R380      -1
    r[13]     R437      1
    r[13]     R438      -1
    r[13]     R493      1
    r[13]     R494      -1
    r[13]     R547      1
    r[13]     R548      -1
    r[13]     R599      1
    r[13]     R600      -1
    r[13]     R649      1
    r[13]     R650      -1
    r[13]     R697      1
    r[13]     R698      -1
    r[13]     R743      1
    r[13]     R744      -1
    r[13]     R789      -1
    r[13]     R790      1
    r[13]     R791      -1
    r[13]     R792      1
    r[13]     R793      -1
    r[13]     R794      1
    r[13]     R795      -1
    r[13]     R796      1
    r[13]     R797      -1
    r[13]     R798      1
    r[13]     R799      -1
    r[13]     R800      1
    r[13]     R801      -1
    r[13]     R802      1
    r[13]     R803      -1
    r[13]     R804      1
    r[13]     R805      -1
    r[13]     R806      1
    r[13]     R807      -1
    r[13]     R808      1
    r[13]     R809      -1
    r[13]     R810      1
    r[13]     R811      -1
    r[13]     R812      1
    r[13]     R813      -1
    r[13]     R814      1
    r[13]     R815      -1
    r[13]     R816      1
    r[13]     R817      -1
    r[13]     R818      1
    r[13]     R819      -1
    r[13]     R820      1
    r[13]     R821      -1
    r[13]     R822      1
    r[13]     R823      -1
    r[13]     R824      1
    r[13]     R825      -1
    r[13]     R826      1
    r[13]     R827      -1
    r[13]     R828      1
    r[13]     R829      -1
    r[13]     R830      1
    r[13]     R831      -1
    r[13]     R832      1
    r[13]     bin_lower  1
    r[13]     bin_upper  1
    r[13]     physical_G_upper  -2.6860981165365086e+01
    r[14]     ratio_14  1
    r[14]     R129      1
    r[14]     R130      -1
    r[14]     R195      1
    r[14]     R196      -1
    r[14]     R259      1
    r[14]     R260      -1
    r[14]     R321      1
    r[14]     R322      -1
    r[14]     R381      1
    r[14]     R382      -1
    r[14]     R439      1
    r[14]     R440      -1
    r[14]     R495      1
    r[14]     R496      -1
    r[14]     R549      1
    r[14]     R550      -1
    r[14]     R601      1
    r[14]     R602      -1
    r[14]     R651      1
    r[14]     R652      -1
    r[14]     R699      1
    r[14]     R700      -1
    r[14]     R745      1
    r[14]     R746      -1
    r[14]     R789      1
    r[14]     R790      -1
    r[14]     R833      -1
    r[14]     R834      1
    r[14]     R835      -1
    r[14]     R836      1
    r[14]     R837      -1
    r[14]     R838      1
    r[14]     R839      -1
    r[14]     R840      1
    r[14]     R841      -1
    r[14]     R842      1
    r[14]     R843      -1
    r[14]     R844      1
    r[14]     R845      -1
    r[14]     R846      1
    r[14]     R847      -1
    r[14]     R848      1
    r[14]     R849      -1
    r[14]     R850      1
    r[14]     R851      -1
    r[14]     R852      1
    r[14]     R853      -1
    r[14]     R854      1
    r[14]     R855      -1
    r[14]     R856      1
    r[14]     R857      -1
    r[14]     R858      1
    r[14]     R859      -1
    r[14]     R860      1
    r[14]     R861      -1
    r[14]     R862      1
    r[14]     R863      -1
    r[14]     R864      1
    r[14]     R865      -1
    r[14]     R866      1
    r[14]     R867      -1
    r[14]     R868      1
    r[14]     R869      -1
    r[14]     R870      1
    r[14]     R871      -1
    r[14]     R872      1
    r[14]     R873      -1
    r[14]     R874      1
    r[14]     bin_lower  1
    r[14]     bin_upper  1
    r[14]     physical_G_upper  -2.6860981165365086e+01
    r[15]     ratio_15  1
    r[15]     R131      1
    r[15]     R132      -1
    r[15]     R197      1
    r[15]     R198      -1
    r[15]     R261      1
    r[15]     R262      -1
    r[15]     R323      1
    r[15]     R324      -1
    r[15]     R383      1
    r[15]     R384      -1
    r[15]     R441      1
    r[15]     R442      -1
    r[15]     R497      1
    r[15]     R498      -1
    r[15]     R551      1
    r[15]     R552      -1
    r[15]     R603      1
    r[15]     R604      -1
    r[15]     R653      1
    r[15]     R654      -1
    r[15]     R701      1
    r[15]     R702      -1
    r[15]     R747      1
    r[15]     R748      -1
    r[15]     R791      1
    r[15]     R792      -1
    r[15]     R833      1
    r[15]     R834      -1
    r[15]     R875      -1
    r[15]     R876      1
    r[15]     R877      -1
    r[15]     R878      1
    r[15]     R879      -1
    r[15]     R880      1
    r[15]     R881      -1
    r[15]     R882      1
    r[15]     R883      -1
    r[15]     R884      1
    r[15]     R885      -1
    r[15]     R886      1
    r[15]     R887      -1
    r[15]     R888      1
    r[15]     R889      -1
    r[15]     R890      1
    r[15]     R891      -1
    r[15]     R892      1
    r[15]     R893      -1
    r[15]     R894      1
    r[15]     R895      -1
    r[15]     R896      1
    r[15]     R897      -1
    r[15]     R898      1
    r[15]     R899      -1
    r[15]     R900      1
    r[15]     R901      -1
    r[15]     R902      1
    r[15]     R903      -1
    r[15]     R904      1
    r[15]     R905      -1
    r[15]     R906      1
    r[15]     R907      -1
    r[15]     R908      1
    r[15]     R909      -1
    r[15]     R910      1
    r[15]     R911      -1
    r[15]     R912      1
    r[15]     R913      -1
    r[15]     R914      1
    r[15]     bin_lower  1
    r[15]     bin_upper  1
    r[15]     physical_G_upper  -2.6860981165365086e+01
    r[16]     ratio_16  1
    r[16]     R133      1
    r[16]     R134      -1
    r[16]     R199      1
    r[16]     R200      -1
    r[16]     R263      1
    r[16]     R264      -1
    r[16]     R325      1
    r[16]     R326      -1
    r[16]     R385      1
    r[16]     R386      -1
    r[16]     R443      1
    r[16]     R444      -1
    r[16]     R499      1
    r[16]     R500      -1
    r[16]     R553      1
    r[16]     R554      -1
    r[16]     R605      1
    r[16]     R606      -1
    r[16]     R655      1
    r[16]     R656      -1
    r[16]     R703      1
    r[16]     R704      -1
    r[16]     R749      1
    r[16]     R750      -1
    r[16]     R793      1
    r[16]     R794      -1
    r[16]     R835      1
    r[16]     R836      -1
    r[16]     R875      1
    r[16]     R876      -1
    r[16]     R915      -1
    r[16]     R916      1
    r[16]     R917      -1
    r[16]     R918      1
    r[16]     R919      -1
    r[16]     R920      1
    r[16]     R921      -1
    r[16]     R922      1
    r[16]     R923      -1
    r[16]     R924      1
    r[16]     R925      -1
    r[16]     R926      1
    r[16]     R927      -1
    r[16]     R928      1
    r[16]     R929      -1
    r[16]     R930      1
    r[16]     R931      -1
    r[16]     R932      1
    r[16]     R933      -1
    r[16]     R934      1
    r[16]     R935      -1
    r[16]     R936      1
    r[16]     R937      -1
    r[16]     R938      1
    r[16]     R939      -1
    r[16]     R940      1
    r[16]     R941      -1
    r[16]     R942      1
    r[16]     R943      -1
    r[16]     R944      1
    r[16]     R945      -1
    r[16]     R946      1
    r[16]     R947      -1
    r[16]     R948      1
    r[16]     R949      -1
    r[16]     R950      1
    r[16]     R951      -1
    r[16]     R952      1
    r[16]     bin_lower  1
    r[16]     bin_upper  1
    r[16]     physical_G_upper  -2.6860981165365086e+01
    r[17]     ratio_17  1
    r[17]     R135      1
    r[17]     R136      -1
    r[17]     R201      1
    r[17]     R202      -1
    r[17]     R265      1
    r[17]     R266      -1
    r[17]     R327      1
    r[17]     R328      -1
    r[17]     R387      1
    r[17]     R388      -1
    r[17]     R445      1
    r[17]     R446      -1
    r[17]     R501      1
    r[17]     R502      -1
    r[17]     R555      1
    r[17]     R556      -1
    r[17]     R607      1
    r[17]     R608      -1
    r[17]     R657      1
    r[17]     R658      -1
    r[17]     R705      1
    r[17]     R706      -1
    r[17]     R751      1
    r[17]     R752      -1
    r[17]     R795      1
    r[17]     R796      -1
    r[17]     R837      1
    r[17]     R838      -1
    r[17]     R877      1
    r[17]     R878      -1
    r[17]     R915      1
    r[17]     R916      -1
    r[17]     R953      -1
    r[17]     R954      1
    r[17]     R955      -1
    r[17]     R956      1
    r[17]     R957      -1
    r[17]     R958      1
    r[17]     R959      -1
    r[17]     R960      1
    r[17]     R961      -1
    r[17]     R962      1
    r[17]     R963      -1
    r[17]     R964      1
    r[17]     R965      -1
    r[17]     R966      1
    r[17]     R967      -1
    r[17]     R968      1
    r[17]     R969      -1
    r[17]     R970      1
    r[17]     R971      -1
    r[17]     R972      1
    r[17]     R973      -1
    r[17]     R974      1
    r[17]     R975      -1
    r[17]     R976      1
    r[17]     R977      -1
    r[17]     R978      1
    r[17]     R979      -1
    r[17]     R980      1
    r[17]     R981      -1
    r[17]     R982      1
    r[17]     R983      -1
    r[17]     R984      1
    r[17]     R985      -1
    r[17]     R986      1
    r[17]     R987      -1
    r[17]     R988      1
    r[17]     bin_lower  1
    r[17]     bin_upper  1
    r[17]     physical_G_upper  -2.6860981165365086e+01
    r[18]     ratio_18  1
    r[18]     R137      1
    r[18]     R138      -1
    r[18]     R203      1
    r[18]     R204      -1
    r[18]     R267      1
    r[18]     R268      -1
    r[18]     R329      1
    r[18]     R330      -1
    r[18]     R389      1
    r[18]     R390      -1
    r[18]     R447      1
    r[18]     R448      -1
    r[18]     R503      1
    r[18]     R504      -1
    r[18]     R557      1
    r[18]     R558      -1
    r[18]     R609      1
    r[18]     R610      -1
    r[18]     R659      1
    r[18]     R660      -1
    r[18]     R707      1
    r[18]     R708      -1
    r[18]     R753      1
    r[18]     R754      -1
    r[18]     R797      1
    r[18]     R798      -1
    r[18]     R839      1
    r[18]     R840      -1
    r[18]     R879      1
    r[18]     R880      -1
    r[18]     R917      1
    r[18]     R918      -1
    r[18]     R953      1
    r[18]     R954      -1
    r[18]     R989      -1
    r[18]     R990      1
    r[18]     R991      -1
    r[18]     R992      1
    r[18]     R993      -1
    r[18]     R994      1
    r[18]     R995      -1
    r[18]     R996      1
    r[18]     R997      -1
    r[18]     R998      1
    r[18]     R999      -1
    r[18]     R1000     1
    r[18]     R1001     -1
    r[18]     R1002     1
    r[18]     R1003     -1
    r[18]     R1004     1
    r[18]     R1005     -1
    r[18]     R1006     1
    r[18]     R1007     -1
    r[18]     R1008     1
    r[18]     R1009     -1
    r[18]     R1010     1
    r[18]     R1011     -1
    r[18]     R1012     1
    r[18]     R1013     -1
    r[18]     R1014     1
    r[18]     R1015     -1
    r[18]     R1016     1
    r[18]     R1017     -1
    r[18]     R1018     1
    r[18]     R1019     -1
    r[18]     R1020     1
    r[18]     R1021     -1
    r[18]     R1022     1
    r[18]     bin_lower  1
    r[18]     bin_upper  1
    r[18]     physical_G_upper  -2.6860981165365086e+01
    r[19]     ratio_19  1
    r[19]     R139      1
    r[19]     R140      -1
    r[19]     R205      1
    r[19]     R206      -1
    r[19]     R269      1
    r[19]     R270      -1
    r[19]     R331      1
    r[19]     R332      -1
    r[19]     R391      1
    r[19]     R392      -1
    r[19]     R449      1
    r[19]     R450      -1
    r[19]     R505      1
    r[19]     R506      -1
    r[19]     R559      1
    r[19]     R560      -1
    r[19]     R611      1
    r[19]     R612      -1
    r[19]     R661      1
    r[19]     R662      -1
    r[19]     R709      1
    r[19]     R710      -1
    r[19]     R755      1
    r[19]     R756      -1
    r[19]     R799      1
    r[19]     R800      -1
    r[19]     R841      1
    r[19]     R842      -1
    r[19]     R881      1
    r[19]     R882      -1
    r[19]     R919      1
    r[19]     R920      -1
    r[19]     R955      1
    r[19]     R956      -1
    r[19]     R989      1
    r[19]     R990      -1
    r[19]     R1023     -1
    r[19]     R1024     1
    r[19]     R1025     -1
    r[19]     R1026     1
    r[19]     R1027     -1
    r[19]     R1028     1
    r[19]     R1029     -1
    r[19]     R1030     1
    r[19]     R1031     -1
    r[19]     R1032     1
    r[19]     R1033     -1
    r[19]     R1034     1
    r[19]     R1035     -1
    r[19]     R1036     1
    r[19]     R1037     -1
    r[19]     R1038     1
    r[19]     R1039     -1
    r[19]     R1040     1
    r[19]     R1041     -1
    r[19]     R1042     1
    r[19]     R1043     -1
    r[19]     R1044     1
    r[19]     R1045     -1
    r[19]     R1046     1
    r[19]     R1047     -1
    r[19]     R1048     1
    r[19]     R1049     -1
    r[19]     R1050     1
    r[19]     R1051     -1
    r[19]     R1052     1
    r[19]     R1053     -1
    r[19]     R1054     1
    r[19]     bin_lower  1
    r[19]     bin_upper  1
    r[19]     physical_G_upper  -2.6860981165365086e+01
    r[20]     ratio_20  1
    r[20]     R141      1
    r[20]     R142      -1
    r[20]     R207      1
    r[20]     R208      -1
    r[20]     R271      1
    r[20]     R272      -1
    r[20]     R333      1
    r[20]     R334      -1
    r[20]     R393      1
    r[20]     R394      -1
    r[20]     R451      1
    r[20]     R452      -1
    r[20]     R507      1
    r[20]     R508      -1
    r[20]     R561      1
    r[20]     R562      -1
    r[20]     R613      1
    r[20]     R614      -1
    r[20]     R663      1
    r[20]     R664      -1
    r[20]     R711      1
    r[20]     R712      -1
    r[20]     R757      1
    r[20]     R758      -1
    r[20]     R801      1
    r[20]     R802      -1
    r[20]     R843      1
    r[20]     R844      -1
    r[20]     R883      1
    r[20]     R884      -1
    r[20]     R921      1
    r[20]     R922      -1
    r[20]     R957      1
    r[20]     R958      -1
    r[20]     R991      1
    r[20]     R992      -1
    r[20]     R1023     1
    r[20]     R1024     -1
    r[20]     R1055     -1
    r[20]     R1056     1
    r[20]     R1057     -1
    r[20]     R1058     1
    r[20]     R1059     -1
    r[20]     R1060     1
    r[20]     R1061     -1
    r[20]     R1062     1
    r[20]     R1063     -1
    r[20]     R1064     1
    r[20]     R1065     -1
    r[20]     R1066     1
    r[20]     R1067     -1
    r[20]     R1068     1
    r[20]     R1069     -1
    r[20]     R1070     1
    r[20]     R1071     -1
    r[20]     R1072     1
    r[20]     R1073     -1
    r[20]     R1074     1
    r[20]     R1075     -1
    r[20]     R1076     1
    r[20]     R1077     -1
    r[20]     R1078     1
    r[20]     R1079     -1
    r[20]     R1080     1
    r[20]     R1081     -1
    r[20]     R1082     1
    r[20]     R1083     -1
    r[20]     R1084     1
    r[20]     bin_lower  1
    r[20]     bin_upper  1
    r[20]     physical_G_upper  -2.6860981165365086e+01
    r[21]     ratio_21  1
    r[21]     R143      1
    r[21]     R144      -1
    r[21]     R209      1
    r[21]     R210      -1
    r[21]     R273      1
    r[21]     R274      -1
    r[21]     R335      1
    r[21]     R336      -1
    r[21]     R395      1
    r[21]     R396      -1
    r[21]     R453      1
    r[21]     R454      -1
    r[21]     R509      1
    r[21]     R510      -1
    r[21]     R563      1
    r[21]     R564      -1
    r[21]     R615      1
    r[21]     R616      -1
    r[21]     R665      1
    r[21]     R666      -1
    r[21]     R713      1
    r[21]     R714      -1
    r[21]     R759      1
    r[21]     R760      -1
    r[21]     R803      1
    r[21]     R804      -1
    r[21]     R845      1
    r[21]     R846      -1
    r[21]     R885      1
    r[21]     R886      -1
    r[21]     R923      1
    r[21]     R924      -1
    r[21]     R959      1
    r[21]     R960      -1
    r[21]     R993      1
    r[21]     R994      -1
    r[21]     R1025     1
    r[21]     R1026     -1
    r[21]     R1055     1
    r[21]     R1056     -1
    r[21]     R1085     -1
    r[21]     R1086     1
    r[21]     R1087     -1
    r[21]     R1088     1
    r[21]     R1089     -1
    r[21]     R1090     1
    r[21]     R1091     -1
    r[21]     R1092     1
    r[21]     R1093     -1
    r[21]     R1094     1
    r[21]     R1095     -1
    r[21]     R1096     1
    r[21]     R1097     -1
    r[21]     R1098     1
    r[21]     R1099     -1
    r[21]     R1100     1
    r[21]     R1101     -1
    r[21]     R1102     1
    r[21]     R1103     -1
    r[21]     R1104     1
    r[21]     R1105     -1
    r[21]     R1106     1
    r[21]     R1107     -1
    r[21]     R1108     1
    r[21]     R1109     -1
    r[21]     R1110     1
    r[21]     R1111     -1
    r[21]     R1112     1
    r[21]     bin_lower  1
    r[21]     bin_upper  1
    r[21]     physical_G_upper  -2.6860981165365086e+01
    r[22]     ratio_22  1
    r[22]     R145      1
    r[22]     R146      -1
    r[22]     R211      1
    r[22]     R212      -1
    r[22]     R275      1
    r[22]     R276      -1
    r[22]     R337      1
    r[22]     R338      -1
    r[22]     R397      1
    r[22]     R398      -1
    r[22]     R455      1
    r[22]     R456      -1
    r[22]     R511      1
    r[22]     R512      -1
    r[22]     R565      1
    r[22]     R566      -1
    r[22]     R617      1
    r[22]     R618      -1
    r[22]     R667      1
    r[22]     R668      -1
    r[22]     R715      1
    r[22]     R716      -1
    r[22]     R761      1
    r[22]     R762      -1
    r[22]     R805      1
    r[22]     R806      -1
    r[22]     R847      1
    r[22]     R848      -1
    r[22]     R887      1
    r[22]     R888      -1
    r[22]     R925      1
    r[22]     R926      -1
    r[22]     R961      1
    r[22]     R962      -1
    r[22]     R995      1
    r[22]     R996      -1
    r[22]     R1027     1
    r[22]     R1028     -1
    r[22]     R1057     1
    r[22]     R1058     -1
    r[22]     R1085     1
    r[22]     R1086     -1
    r[22]     R1113     -1
    r[22]     R1114     1
    r[22]     R1115     -1
    r[22]     R1116     1
    r[22]     R1117     -1
    r[22]     R1118     1
    r[22]     R1119     -1
    r[22]     R1120     1
    r[22]     R1121     -1
    r[22]     R1122     1
    r[22]     R1123     -1
    r[22]     R1124     1
    r[22]     R1125     -1
    r[22]     R1126     1
    r[22]     R1127     -1
    r[22]     R1128     1
    r[22]     R1129     -1
    r[22]     R1130     1
    r[22]     R1131     -1
    r[22]     R1132     1
    r[22]     R1133     -1
    r[22]     R1134     1
    r[22]     R1135     -1
    r[22]     R1136     1
    r[22]     R1137     -1
    r[22]     R1138     1
    r[22]     bin_lower  1
    r[22]     bin_upper  1
    r[22]     physical_G_upper  -2.6860981165365086e+01
    r[23]     ratio_23  1
    r[23]     R147      1
    r[23]     R148      -1
    r[23]     R213      1
    r[23]     R214      -1
    r[23]     R277      1
    r[23]     R278      -1
    r[23]     R339      1
    r[23]     R340      -1
    r[23]     R399      1
    r[23]     R400      -1
    r[23]     R457      1
    r[23]     R458      -1
    r[23]     R513      1
    r[23]     R514      -1
    r[23]     R567      1
    r[23]     R568      -1
    r[23]     R619      1
    r[23]     R620      -1
    r[23]     R669      1
    r[23]     R670      -1
    r[23]     R717      1
    r[23]     R718      -1
    r[23]     R763      1
    r[23]     R764      -1
    r[23]     R807      1
    r[23]     R808      -1
    r[23]     R849      1
    r[23]     R850      -1
    r[23]     R889      1
    r[23]     R890      -1
    r[23]     R927      1
    r[23]     R928      -1
    r[23]     R963      1
    r[23]     R964      -1
    r[23]     R997      1
    r[23]     R998      -1
    r[23]     R1029     1
    r[23]     R1030     -1
    r[23]     R1059     1
    r[23]     R1060     -1
    r[23]     R1087     1
    r[23]     R1088     -1
    r[23]     R1113     1
    r[23]     R1114     -1
    r[23]     R1139     -1
    r[23]     R1140     1
    r[23]     R1141     -1
    r[23]     R1142     1
    r[23]     R1143     -1
    r[23]     R1144     1
    r[23]     R1145     -1
    r[23]     R1146     1
    r[23]     R1147     -1
    r[23]     R1148     1
    r[23]     R1149     -1
    r[23]     R1150     1
    r[23]     R1151     -1
    r[23]     R1152     1
    r[23]     R1153     -1
    r[23]     R1154     1
    r[23]     R1155     -1
    r[23]     R1156     1
    r[23]     R1157     -1
    r[23]     R1158     1
    r[23]     R1159     -1
    r[23]     R1160     1
    r[23]     R1161     -1
    r[23]     R1162     1
    r[23]     bin_lower  1
    r[23]     bin_upper  1
    r[23]     physical_G_upper  -2.6860981165365086e+01
    r[24]     ratio_24  1
    r[24]     R149      1
    r[24]     R150      -1
    r[24]     R215      1
    r[24]     R216      -1
    r[24]     R279      1
    r[24]     R280      -1
    r[24]     R341      1
    r[24]     R342      -1
    r[24]     R401      1
    r[24]     R402      -1
    r[24]     R459      1
    r[24]     R460      -1
    r[24]     R515      1
    r[24]     R516      -1
    r[24]     R569      1
    r[24]     R570      -1
    r[24]     R621      1
    r[24]     R622      -1
    r[24]     R671      1
    r[24]     R672      -1
    r[24]     R719      1
    r[24]     R720      -1
    r[24]     R765      1
    r[24]     R766      -1
    r[24]     R809      1
    r[24]     R810      -1
    r[24]     R851      1
    r[24]     R852      -1
    r[24]     R891      1
    r[24]     R892      -1
    r[24]     R929      1
    r[24]     R930      -1
    r[24]     R965      1
    r[24]     R966      -1
    r[24]     R999      1
    r[24]     R1000     -1
    r[24]     R1031     1
    r[24]     R1032     -1
    r[24]     R1061     1
    r[24]     R1062     -1
    r[24]     R1089     1
    r[24]     R1090     -1
    r[24]     R1115     1
    r[24]     R1116     -1
    r[24]     R1139     1
    r[24]     R1140     -1
    r[24]     R1163     -1
    r[24]     R1164     1
    r[24]     R1165     -1
    r[24]     R1166     1
    r[24]     R1167     -1
    r[24]     R1168     1
    r[24]     R1169     -1
    r[24]     R1170     1
    r[24]     R1171     -1
    r[24]     R1172     1
    r[24]     R1173     -1
    r[24]     R1174     1
    r[24]     R1175     -1
    r[24]     R1176     1
    r[24]     R1177     -1
    r[24]     R1178     1
    r[24]     R1179     -1
    r[24]     R1180     1
    r[24]     R1181     -1
    r[24]     R1182     1
    r[24]     R1183     -1
    r[24]     R1184     1
    r[24]     bin_lower  1
    r[24]     bin_upper  1
    r[24]     physical_G_upper  -2.6860981165365086e+01
    r[25]     ratio_25  1
    r[25]     R151      1
    r[25]     R152      -1
    r[25]     R217      1
    r[25]     R218      -1
    r[25]     R281      1
    r[25]     R282      -1
    r[25]     R343      1
    r[25]     R344      -1
    r[25]     R403      1
    r[25]     R404      -1
    r[25]     R461      1
    r[25]     R462      -1
    r[25]     R517      1
    r[25]     R518      -1
    r[25]     R571      1
    r[25]     R572      -1
    r[25]     R623      1
    r[25]     R624      -1
    r[25]     R673      1
    r[25]     R674      -1
    r[25]     R721      1
    r[25]     R722      -1
    r[25]     R767      1
    r[25]     R768      -1
    r[25]     R811      1
    r[25]     R812      -1
    r[25]     R853      1
    r[25]     R854      -1
    r[25]     R893      1
    r[25]     R894      -1
    r[25]     R931      1
    r[25]     R932      -1
    r[25]     R967      1
    r[25]     R968      -1
    r[25]     R1001     1
    r[25]     R1002     -1
    r[25]     R1033     1
    r[25]     R1034     -1
    r[25]     R1063     1
    r[25]     R1064     -1
    r[25]     R1091     1
    r[25]     R1092     -1
    r[25]     R1117     1
    r[25]     R1118     -1
    r[25]     R1141     1
    r[25]     R1142     -1
    r[25]     R1163     1
    r[25]     R1164     -1
    r[25]     R1185     -1
    r[25]     R1186     1
    r[25]     R1187     -1
    r[25]     R1188     1
    r[25]     R1189     -1
    r[25]     R1190     1
    r[25]     R1191     -1
    r[25]     R1192     1
    r[25]     R1193     -1
    r[25]     R1194     1
    r[25]     R1195     -1
    r[25]     R1196     1
    r[25]     R1197     -1
    r[25]     R1198     1
    r[25]     R1199     -1
    r[25]     R1200     1
    r[25]     R1201     -1
    r[25]     R1202     1
    r[25]     R1203     -1
    r[25]     R1204     1
    r[25]     bin_lower  1
    r[25]     bin_upper  1
    r[25]     physical_G_upper  -2.6860981165365086e+01
    r[26]     ratio_26  1
    r[26]     R153      1
    r[26]     R154      -1
    r[26]     R219      1
    r[26]     R220      -1
    r[26]     R283      1
    r[26]     R284      -1
    r[26]     R345      1
    r[26]     R346      -1
    r[26]     R405      1
    r[26]     R406      -1
    r[26]     R463      1
    r[26]     R464      -1
    r[26]     R519      1
    r[26]     R520      -1
    r[26]     R573      1
    r[26]     R574      -1
    r[26]     R625      1
    r[26]     R626      -1
    r[26]     R675      1
    r[26]     R676      -1
    r[26]     R723      1
    r[26]     R724      -1
    r[26]     R769      1
    r[26]     R770      -1
    r[26]     R813      1
    r[26]     R814      -1
    r[26]     R855      1
    r[26]     R856      -1
    r[26]     R895      1
    r[26]     R896      -1
    r[26]     R933      1
    r[26]     R934      -1
    r[26]     R969      1
    r[26]     R970      -1
    r[26]     R1003     1
    r[26]     R1004     -1
    r[26]     R1035     1
    r[26]     R1036     -1
    r[26]     R1065     1
    r[26]     R1066     -1
    r[26]     R1093     1
    r[26]     R1094     -1
    r[26]     R1119     1
    r[26]     R1120     -1
    r[26]     R1143     1
    r[26]     R1144     -1
    r[26]     R1165     1
    r[26]     R1166     -1
    r[26]     R1185     1
    r[26]     R1186     -1
    r[26]     R1205     -1
    r[26]     R1206     1
    r[26]     R1207     -1
    r[26]     R1208     1
    r[26]     R1209     -1
    r[26]     R1210     1
    r[26]     R1211     -1
    r[26]     R1212     1
    r[26]     R1213     -1
    r[26]     R1214     1
    r[26]     R1215     -1
    r[26]     R1216     1
    r[26]     R1217     -1
    r[26]     R1218     1
    r[26]     R1219     -1
    r[26]     R1220     1
    r[26]     R1221     -1
    r[26]     R1222     1
    r[26]     bin_lower  1
    r[26]     bin_upper  1
    r[26]     physical_G_upper  -2.6860981165365086e+01
    r[27]     ratio_27  1
    r[27]     R155      1
    r[27]     R156      -1
    r[27]     R221      1
    r[27]     R222      -1
    r[27]     R285      1
    r[27]     R286      -1
    r[27]     R347      1
    r[27]     R348      -1
    r[27]     R407      1
    r[27]     R408      -1
    r[27]     R465      1
    r[27]     R466      -1
    r[27]     R521      1
    r[27]     R522      -1
    r[27]     R575      1
    r[27]     R576      -1
    r[27]     R627      1
    r[27]     R628      -1
    r[27]     R677      1
    r[27]     R678      -1
    r[27]     R725      1
    r[27]     R726      -1
    r[27]     R771      1
    r[27]     R772      -1
    r[27]     R815      1
    r[27]     R816      -1
    r[27]     R857      1
    r[27]     R858      -1
    r[27]     R897      1
    r[27]     R898      -1
    r[27]     R935      1
    r[27]     R936      -1
    r[27]     R971      1
    r[27]     R972      -1
    r[27]     R1005     1
    r[27]     R1006     -1
    r[27]     R1037     1
    r[27]     R1038     -1
    r[27]     R1067     1
    r[27]     R1068     -1
    r[27]     R1095     1
    r[27]     R1096     -1
    r[27]     R1121     1
    r[27]     R1122     -1
    r[27]     R1145     1
    r[27]     R1146     -1
    r[27]     R1167     1
    r[27]     R1168     -1
    r[27]     R1187     1
    r[27]     R1188     -1
    r[27]     R1205     1
    r[27]     R1206     -1
    r[27]     R1223     -1
    r[27]     R1224     1
    r[27]     R1225     -1
    r[27]     R1226     1
    r[27]     R1227     -1
    r[27]     R1228     1
    r[27]     R1229     -1
    r[27]     R1230     1
    r[27]     R1231     -1
    r[27]     R1232     1
    r[27]     R1233     -1
    r[27]     R1234     1
    r[27]     R1235     -1
    r[27]     R1236     1
    r[27]     R1237     -1
    r[27]     R1238     1
    r[27]     bin_lower  1
    r[27]     bin_upper  1
    r[27]     physical_G_upper  -2.6860981165365086e+01
    r[28]     ratio_28  1
    r[28]     R157      1
    r[28]     R158      -1
    r[28]     R223      1
    r[28]     R224      -1
    r[28]     R287      1
    r[28]     R288      -1
    r[28]     R349      1
    r[28]     R350      -1
    r[28]     R409      1
    r[28]     R410      -1
    r[28]     R467      1
    r[28]     R468      -1
    r[28]     R523      1
    r[28]     R524      -1
    r[28]     R577      1
    r[28]     R578      -1
    r[28]     R629      1
    r[28]     R630      -1
    r[28]     R679      1
    r[28]     R680      -1
    r[28]     R727      1
    r[28]     R728      -1
    r[28]     R773      1
    r[28]     R774      -1
    r[28]     R817      1
    r[28]     R818      -1
    r[28]     R859      1
    r[28]     R860      -1
    r[28]     R899      1
    r[28]     R900      -1
    r[28]     R937      1
    r[28]     R938      -1
    r[28]     R973      1
    r[28]     R974      -1
    r[28]     R1007     1
    r[28]     R1008     -1
    r[28]     R1039     1
    r[28]     R1040     -1
    r[28]     R1069     1
    r[28]     R1070     -1
    r[28]     R1097     1
    r[28]     R1098     -1
    r[28]     R1123     1
    r[28]     R1124     -1
    r[28]     R1147     1
    r[28]     R1148     -1
    r[28]     R1169     1
    r[28]     R1170     -1
    r[28]     R1189     1
    r[28]     R1190     -1
    r[28]     R1207     1
    r[28]     R1208     -1
    r[28]     R1223     1
    r[28]     R1224     -1
    r[28]     R1239     -1
    r[28]     R1240     1
    r[28]     R1241     -1
    r[28]     R1242     1
    r[28]     R1243     -1
    r[28]     R1244     1
    r[28]     R1245     -1
    r[28]     R1246     1
    r[28]     R1247     -1
    r[28]     R1248     1
    r[28]     R1249     -1
    r[28]     R1250     1
    r[28]     R1251     -1
    r[28]     R1252     1
    r[28]     bin_lower  1
    r[28]     bin_upper  1
    r[28]     physical_G_upper  -2.6860981165365086e+01
    r[29]     ratio_29  1
    r[29]     R159      1
    r[29]     R160      -1
    r[29]     R225      1
    r[29]     R226      -1
    r[29]     R289      1
    r[29]     R290      -1
    r[29]     R351      1
    r[29]     R352      -1
    r[29]     R411      1
    r[29]     R412      -1
    r[29]     R469      1
    r[29]     R470      -1
    r[29]     R525      1
    r[29]     R526      -1
    r[29]     R579      1
    r[29]     R580      -1
    r[29]     R631      1
    r[29]     R632      -1
    r[29]     R681      1
    r[29]     R682      -1
    r[29]     R729      1
    r[29]     R730      -1
    r[29]     R775      1
    r[29]     R776      -1
    r[29]     R819      1
    r[29]     R820      -1
    r[29]     R861      1
    r[29]     R862      -1
    r[29]     R901      1
    r[29]     R902      -1
    r[29]     R939      1
    r[29]     R940      -1
    r[29]     R975      1
    r[29]     R976      -1
    r[29]     R1009     1
    r[29]     R1010     -1
    r[29]     R1041     1
    r[29]     R1042     -1
    r[29]     R1071     1
    r[29]     R1072     -1
    r[29]     R1099     1
    r[29]     R1100     -1
    r[29]     R1125     1
    r[29]     R1126     -1
    r[29]     R1149     1
    r[29]     R1150     -1
    r[29]     R1171     1
    r[29]     R1172     -1
    r[29]     R1191     1
    r[29]     R1192     -1
    r[29]     R1209     1
    r[29]     R1210     -1
    r[29]     R1225     1
    r[29]     R1226     -1
    r[29]     R1239     1
    r[29]     R1240     -1
    r[29]     R1253     -1
    r[29]     R1254     1
    r[29]     R1255     -1
    r[29]     R1256     1
    r[29]     R1257     -1
    r[29]     R1258     1
    r[29]     R1259     -1
    r[29]     R1260     1
    r[29]     R1261     -1
    r[29]     R1262     1
    r[29]     R1263     -1
    r[29]     R1264     1
    r[29]     bin_lower  1
    r[29]     bin_upper  1
    r[29]     physical_G_upper  -2.6860981165365086e+01
    r[30]     ratio_30  1
    r[30]     R161      1
    r[30]     R162      -1
    r[30]     R227      1
    r[30]     R228      -1
    r[30]     R291      1
    r[30]     R292      -1
    r[30]     R353      1
    r[30]     R354      -1
    r[30]     R413      1
    r[30]     R414      -1
    r[30]     R471      1
    r[30]     R472      -1
    r[30]     R527      1
    r[30]     R528      -1
    r[30]     R581      1
    r[30]     R582      -1
    r[30]     R633      1
    r[30]     R634      -1
    r[30]     R683      1
    r[30]     R684      -1
    r[30]     R731      1
    r[30]     R732      -1
    r[30]     R777      1
    r[30]     R778      -1
    r[30]     R821      1
    r[30]     R822      -1
    r[30]     R863      1
    r[30]     R864      -1
    r[30]     R903      1
    r[30]     R904      -1
    r[30]     R941      1
    r[30]     R942      -1
    r[30]     R977      1
    r[30]     R978      -1
    r[30]     R1011     1
    r[30]     R1012     -1
    r[30]     R1043     1
    r[30]     R1044     -1
    r[30]     R1073     1
    r[30]     R1074     -1
    r[30]     R1101     1
    r[30]     R1102     -1
    r[30]     R1127     1
    r[30]     R1128     -1
    r[30]     R1151     1
    r[30]     R1152     -1
    r[30]     R1173     1
    r[30]     R1174     -1
    r[30]     R1193     1
    r[30]     R1194     -1
    r[30]     R1211     1
    r[30]     R1212     -1
    r[30]     R1227     1
    r[30]     R1228     -1
    r[30]     R1241     1
    r[30]     R1242     -1
    r[30]     R1253     1
    r[30]     R1254     -1
    r[30]     R1265     -1
    r[30]     R1266     1
    r[30]     R1267     -1
    r[30]     R1268     1
    r[30]     R1269     -1
    r[30]     R1270     1
    r[30]     R1271     -1
    r[30]     R1272     1
    r[30]     R1273     -1
    r[30]     R1274     1
    r[30]     bin_lower  1
    r[30]     bin_upper  1
    r[30]     physical_G_upper  -2.6860981165365086e+01
    r[31]     ratio_31  1
    r[31]     R163      1
    r[31]     R164      -1
    r[31]     R229      1
    r[31]     R230      -1
    r[31]     R293      1
    r[31]     R294      -1
    r[31]     R355      1
    r[31]     R356      -1
    r[31]     R415      1
    r[31]     R416      -1
    r[31]     R473      1
    r[31]     R474      -1
    r[31]     R529      1
    r[31]     R530      -1
    r[31]     R583      1
    r[31]     R584      -1
    r[31]     R635      1
    r[31]     R636      -1
    r[31]     R685      1
    r[31]     R686      -1
    r[31]     R733      1
    r[31]     R734      -1
    r[31]     R779      1
    r[31]     R780      -1
    r[31]     R823      1
    r[31]     R824      -1
    r[31]     R865      1
    r[31]     R866      -1
    r[31]     R905      1
    r[31]     R906      -1
    r[31]     R943      1
    r[31]     R944      -1
    r[31]     R979      1
    r[31]     R980      -1
    r[31]     R1013     1
    r[31]     R1014     -1
    r[31]     R1045     1
    r[31]     R1046     -1
    r[31]     R1075     1
    r[31]     R1076     -1
    r[31]     R1103     1
    r[31]     R1104     -1
    r[31]     R1129     1
    r[31]     R1130     -1
    r[31]     R1153     1
    r[31]     R1154     -1
    r[31]     R1175     1
    r[31]     R1176     -1
    r[31]     R1195     1
    r[31]     R1196     -1
    r[31]     R1213     1
    r[31]     R1214     -1
    r[31]     R1229     1
    r[31]     R1230     -1
    r[31]     R1243     1
    r[31]     R1244     -1
    r[31]     R1255     1
    r[31]     R1256     -1
    r[31]     R1265     1
    r[31]     R1266     -1
    r[31]     R1275     -1
    r[31]     R1276     1
    r[31]     R1277     -1
    r[31]     R1278     1
    r[31]     R1279     -1
    r[31]     R1280     1
    r[31]     R1281     -1
    r[31]     R1282     1
    r[31]     bin_lower  1
    r[31]     bin_upper  1
    r[31]     physical_G_upper  -2.6860981165365086e+01
    r[32]     ratio_32  1
    r[32]     R165      1
    r[32]     R166      -1
    r[32]     R231      1
    r[32]     R232      -1
    r[32]     R295      1
    r[32]     R296      -1
    r[32]     R357      1
    r[32]     R358      -1
    r[32]     R417      1
    r[32]     R418      -1
    r[32]     R475      1
    r[32]     R476      -1
    r[32]     R531      1
    r[32]     R532      -1
    r[32]     R585      1
    r[32]     R586      -1
    r[32]     R637      1
    r[32]     R638      -1
    r[32]     R687      1
    r[32]     R688      -1
    r[32]     R735      1
    r[32]     R736      -1
    r[32]     R781      1
    r[32]     R782      -1
    r[32]     R825      1
    r[32]     R826      -1
    r[32]     R867      1
    r[32]     R868      -1
    r[32]     R907      1
    r[32]     R908      -1
    r[32]     R945      1
    r[32]     R946      -1
    r[32]     R981      1
    r[32]     R982      -1
    r[32]     R1015     1
    r[32]     R1016     -1
    r[32]     R1047     1
    r[32]     R1048     -1
    r[32]     R1077     1
    r[32]     R1078     -1
    r[32]     R1105     1
    r[32]     R1106     -1
    r[32]     R1131     1
    r[32]     R1132     -1
    r[32]     R1155     1
    r[32]     R1156     -1
    r[32]     R1177     1
    r[32]     R1178     -1
    r[32]     R1197     1
    r[32]     R1198     -1
    r[32]     R1215     1
    r[32]     R1216     -1
    r[32]     R1231     1
    r[32]     R1232     -1
    r[32]     R1245     1
    r[32]     R1246     -1
    r[32]     R1257     1
    r[32]     R1258     -1
    r[32]     R1267     1
    r[32]     R1268     -1
    r[32]     R1275     1
    r[32]     R1276     -1
    r[32]     R1283     -1
    r[32]     R1284     1
    r[32]     R1285     -1
    r[32]     R1286     1
    r[32]     R1287     -1
    r[32]     R1288     1
    r[32]     bin_lower  1
    r[32]     bin_upper  1
    r[32]     physical_G_upper  -2.6860981165365086e+01
    r[33]     ratio_33  1
    r[33]     R167      1
    r[33]     R168      -1
    r[33]     R233      1
    r[33]     R234      -1
    r[33]     R297      1
    r[33]     R298      -1
    r[33]     R359      1
    r[33]     R360      -1
    r[33]     R419      1
    r[33]     R420      -1
    r[33]     R477      1
    r[33]     R478      -1
    r[33]     R533      1
    r[33]     R534      -1
    r[33]     R587      1
    r[33]     R588      -1
    r[33]     R639      1
    r[33]     R640      -1
    r[33]     R689      1
    r[33]     R690      -1
    r[33]     R737      1
    r[33]     R738      -1
    r[33]     R783      1
    r[33]     R784      -1
    r[33]     R827      1
    r[33]     R828      -1
    r[33]     R869      1
    r[33]     R870      -1
    r[33]     R909      1
    r[33]     R910      -1
    r[33]     R947      1
    r[33]     R948      -1
    r[33]     R983      1
    r[33]     R984      -1
    r[33]     R1017     1
    r[33]     R1018     -1
    r[33]     R1049     1
    r[33]     R1050     -1
    r[33]     R1079     1
    r[33]     R1080     -1
    r[33]     R1107     1
    r[33]     R1108     -1
    r[33]     R1133     1
    r[33]     R1134     -1
    r[33]     R1157     1
    r[33]     R1158     -1
    r[33]     R1179     1
    r[33]     R1180     -1
    r[33]     R1199     1
    r[33]     R1200     -1
    r[33]     R1217     1
    r[33]     R1218     -1
    r[33]     R1233     1
    r[33]     R1234     -1
    r[33]     R1247     1
    r[33]     R1248     -1
    r[33]     R1259     1
    r[33]     R1260     -1
    r[33]     R1269     1
    r[33]     R1270     -1
    r[33]     R1277     1
    r[33]     R1278     -1
    r[33]     R1283     1
    r[33]     R1284     -1
    r[33]     R1289     -1
    r[33]     R1290     1
    r[33]     R1291     -1
    r[33]     R1292     1
    r[33]     bin_lower  1
    r[33]     bin_upper  1
    r[33]     physical_G_upper  -2.6860981165365086e+01
    r[34]     ratio_34  1
    r[34]     R169      1
    r[34]     R170      -1
    r[34]     R235      1
    r[34]     R236      -1
    r[34]     R299      1
    r[34]     R300      -1
    r[34]     R361      1
    r[34]     R362      -1
    r[34]     R421      1
    r[34]     R422      -1
    r[34]     R479      1
    r[34]     R480      -1
    r[34]     R535      1
    r[34]     R536      -1
    r[34]     R589      1
    r[34]     R590      -1
    r[34]     R641      1
    r[34]     R642      -1
    r[34]     R691      1
    r[34]     R692      -1
    r[34]     R739      1
    r[34]     R740      -1
    r[34]     R785      1
    r[34]     R786      -1
    r[34]     R829      1
    r[34]     R830      -1
    r[34]     R871      1
    r[34]     R872      -1
    r[34]     R911      1
    r[34]     R912      -1
    r[34]     R949      1
    r[34]     R950      -1
    r[34]     R985      1
    r[34]     R986      -1
    r[34]     R1019     1
    r[34]     R1020     -1
    r[34]     R1051     1
    r[34]     R1052     -1
    r[34]     R1081     1
    r[34]     R1082     -1
    r[34]     R1109     1
    r[34]     R1110     -1
    r[34]     R1135     1
    r[34]     R1136     -1
    r[34]     R1159     1
    r[34]     R1160     -1
    r[34]     R1181     1
    r[34]     R1182     -1
    r[34]     R1201     1
    r[34]     R1202     -1
    r[34]     R1219     1
    r[34]     R1220     -1
    r[34]     R1235     1
    r[34]     R1236     -1
    r[34]     R1249     1
    r[34]     R1250     -1
    r[34]     R1261     1
    r[34]     R1262     -1
    r[34]     R1271     1
    r[34]     R1272     -1
    r[34]     R1279     1
    r[34]     R1280     -1
    r[34]     R1285     1
    r[34]     R1286     -1
    r[34]     R1289     1
    r[34]     R1290     -1
    r[34]     R1293     -1
    r[34]     R1294     1
    r[34]     bin_lower  1
    r[34]     bin_upper  1
    r[34]     physical_G_upper  -2.6860981165365086e+01
    r[35]     ratio_35  1
    r[35]     R171      1
    r[35]     R172      -1
    r[35]     R237      1
    r[35]     R238      -1
    r[35]     R301      1
    r[35]     R302      -1
    r[35]     R363      1
    r[35]     R364      -1
    r[35]     R423      1
    r[35]     R424      -1
    r[35]     R481      1
    r[35]     R482      -1
    r[35]     R537      1
    r[35]     R538      -1
    r[35]     R591      1
    r[35]     R592      -1
    r[35]     R643      1
    r[35]     R644      -1
    r[35]     R693      1
    r[35]     R694      -1
    r[35]     R741      1
    r[35]     R742      -1
    r[35]     R787      1
    r[35]     R788      -1
    r[35]     R831      1
    r[35]     R832      -1
    r[35]     R873      1
    r[35]     R874      -1
    r[35]     R913      1
    r[35]     R914      -1
    r[35]     R951      1
    r[35]     R952      -1
    r[35]     R987      1
    r[35]     R988      -1
    r[35]     R1021     1
    r[35]     R1022     -1
    r[35]     R1053     1
    r[35]     R1054     -1
    r[35]     R1083     1
    r[35]     R1084     -1
    r[35]     R1111     1
    r[35]     R1112     -1
    r[35]     R1137     1
    r[35]     R1138     -1
    r[35]     R1161     1
    r[35]     R1162     -1
    r[35]     R1183     1
    r[35]     R1184     -1
    r[35]     R1203     1
    r[35]     R1204     -1
    r[35]     R1221     1
    r[35]     R1222     -1
    r[35]     R1237     1
    r[35]     R1238     -1
    r[35]     R1251     1
    r[35]     R1252     -1
    r[35]     R1263     1
    r[35]     R1264     -1
    r[35]     R1273     1
    r[35]     R1274     -1
    r[35]     R1281     1
    r[35]     R1282     -1
    r[35]     R1287     1
    r[35]     R1288     -1
    r[35]     R1291     1
    r[35]     R1292     -1
    r[35]     R1293     1
    r[35]     R1294     -1
    r[35]     bin_lower  1
    r[35]     bin_upper  1
    r[35]     physical_G_upper  -2.6860981165365086e+01
    a[1,2]    R105      1
    a[1,2]    R106      1
    a[1,2]    surrogate_G  1
    a[1,2]    physical_G_upper  1
    a[1,3]    R107      1
    a[1,3]    R108      1
    a[1,3]    surrogate_G  1
    a[1,3]    physical_G_upper  1
    a[1,4]    R109      1
    a[1,4]    R110      1
    a[1,4]    surrogate_G  1
    a[1,4]    physical_G_upper  1
    a[1,5]    R111      1
    a[1,5]    R112      1
    a[1,5]    surrogate_G  1
    a[1,5]    physical_G_upper  1
    a[1,6]    R113      1
    a[1,6]    R114      1
    a[1,6]    surrogate_G  1
    a[1,6]    physical_G_upper  1
    a[1,7]    R115      1
    a[1,7]    R116      1
    a[1,7]    surrogate_G  1
    a[1,7]    physical_G_upper  1
    a[1,8]    R117      1
    a[1,8]    R118      1
    a[1,8]    surrogate_G  1
    a[1,8]    physical_G_upper  1
    a[1,9]    R119      1
    a[1,9]    R120      1
    a[1,9]    surrogate_G  1
    a[1,9]    physical_G_upper  1
    a[1,10]   R121      1
    a[1,10]   R122      1
    a[1,10]   surrogate_G  1
    a[1,10]   physical_G_upper  1
    a[1,11]   R123      1
    a[1,11]   R124      1
    a[1,11]   surrogate_G  1
    a[1,11]   physical_G_upper  1
    a[1,12]   R125      1
    a[1,12]   R126      1
    a[1,12]   surrogate_G  1
    a[1,12]   physical_G_upper  1
    a[1,13]   R127      1
    a[1,13]   R128      1
    a[1,13]   surrogate_G  1
    a[1,13]   physical_G_upper  1
    a[1,14]   R129      1
    a[1,14]   R130      1
    a[1,14]   surrogate_G  1
    a[1,14]   physical_G_upper  1
    a[1,15]   R131      1
    a[1,15]   R132      1
    a[1,15]   surrogate_G  1
    a[1,15]   physical_G_upper  1
    a[1,16]   R133      1
    a[1,16]   R134      1
    a[1,16]   surrogate_G  1
    a[1,16]   physical_G_upper  1
    a[1,17]   R135      1
    a[1,17]   R136      1
    a[1,17]   surrogate_G  1
    a[1,17]   physical_G_upper  1
    a[1,18]   R137      1
    a[1,18]   R138      1
    a[1,18]   surrogate_G  1
    a[1,18]   physical_G_upper  1
    a[1,19]   R139      1
    a[1,19]   R140      1
    a[1,19]   surrogate_G  1
    a[1,19]   physical_G_upper  1
    a[1,20]   R141      1
    a[1,20]   R142      1
    a[1,20]   surrogate_G  1
    a[1,20]   physical_G_upper  1
    a[1,21]   R143      1
    a[1,21]   R144      1
    a[1,21]   surrogate_G  1
    a[1,21]   physical_G_upper  1
    a[1,22]   R145      1
    a[1,22]   R146      1
    a[1,22]   surrogate_G  1
    a[1,22]   physical_G_upper  1
    a[1,23]   R147      1
    a[1,23]   R148      1
    a[1,23]   surrogate_G  1
    a[1,23]   physical_G_upper  1
    a[1,24]   R149      1
    a[1,24]   R150      1
    a[1,24]   surrogate_G  1
    a[1,24]   physical_G_upper  1
    a[1,25]   R151      1
    a[1,25]   R152      1
    a[1,25]   surrogate_G  1
    a[1,25]   physical_G_upper  1
    a[1,26]   R153      1
    a[1,26]   R154      1
    a[1,26]   surrogate_G  1
    a[1,26]   physical_G_upper  1
    a[1,27]   R155      1
    a[1,27]   R156      1
    a[1,27]   surrogate_G  1
    a[1,27]   physical_G_upper  1
    a[1,28]   R157      1
    a[1,28]   R158      1
    a[1,28]   surrogate_G  1
    a[1,28]   physical_G_upper  1
    a[1,29]   R159      1
    a[1,29]   R160      1
    a[1,29]   surrogate_G  1
    a[1,29]   physical_G_upper  1
    a[1,30]   R161      1
    a[1,30]   R162      1
    a[1,30]   surrogate_G  1
    a[1,30]   physical_G_upper  1
    a[1,31]   R163      1
    a[1,31]   R164      1
    a[1,31]   surrogate_G  1
    a[1,31]   physical_G_upper  1
    a[1,32]   R165      1
    a[1,32]   R166      1
    a[1,32]   surrogate_G  1
    a[1,32]   physical_G_upper  1
    a[1,33]   R167      1
    a[1,33]   R168      1
    a[1,33]   surrogate_G  1
    a[1,33]   physical_G_upper  1
    a[1,34]   R169      1
    a[1,34]   R170      1
    a[1,34]   surrogate_G  1
    a[1,34]   physical_G_upper  1
    a[1,35]   R171      1
    a[1,35]   R172      1
    a[1,35]   surrogate_G  1
    a[1,35]   physical_G_upper  1
    a[2,3]    R173      1
    a[2,3]    R174      1
    a[2,3]    surrogate_G  1
    a[2,3]    physical_G_upper  1
    a[2,4]    R175      1
    a[2,4]    R176      1
    a[2,4]    surrogate_G  1
    a[2,4]    physical_G_upper  1
    a[2,5]    R177      1
    a[2,5]    R178      1
    a[2,5]    surrogate_G  1
    a[2,5]    physical_G_upper  1
    a[2,6]    R179      1
    a[2,6]    R180      1
    a[2,6]    surrogate_G  1
    a[2,6]    physical_G_upper  1
    a[2,7]    R181      1
    a[2,7]    R182      1
    a[2,7]    surrogate_G  1
    a[2,7]    physical_G_upper  1
    a[2,8]    R183      1
    a[2,8]    R184      1
    a[2,8]    surrogate_G  1
    a[2,8]    physical_G_upper  1
    a[2,9]    R185      1
    a[2,9]    R186      1
    a[2,9]    surrogate_G  1
    a[2,9]    physical_G_upper  1
    a[2,10]   R187      1
    a[2,10]   R188      1
    a[2,10]   surrogate_G  1
    a[2,10]   physical_G_upper  1
    a[2,11]   R189      1
    a[2,11]   R190      1
    a[2,11]   surrogate_G  1
    a[2,11]   physical_G_upper  1
    a[2,12]   R191      1
    a[2,12]   R192      1
    a[2,12]   surrogate_G  1
    a[2,12]   physical_G_upper  1
    a[2,13]   R193      1
    a[2,13]   R194      1
    a[2,13]   surrogate_G  1
    a[2,13]   physical_G_upper  1
    a[2,14]   R195      1
    a[2,14]   R196      1
    a[2,14]   surrogate_G  1
    a[2,14]   physical_G_upper  1
    a[2,15]   R197      1
    a[2,15]   R198      1
    a[2,15]   surrogate_G  1
    a[2,15]   physical_G_upper  1
    a[2,16]   R199      1
    a[2,16]   R200      1
    a[2,16]   surrogate_G  1
    a[2,16]   physical_G_upper  1
    a[2,17]   R201      1
    a[2,17]   R202      1
    a[2,17]   surrogate_G  1
    a[2,17]   physical_G_upper  1
    a[2,18]   R203      1
    a[2,18]   R204      1
    a[2,18]   surrogate_G  1
    a[2,18]   physical_G_upper  1
    a[2,19]   R205      1
    a[2,19]   R206      1
    a[2,19]   surrogate_G  1
    a[2,19]   physical_G_upper  1
    a[2,20]   R207      1
    a[2,20]   R208      1
    a[2,20]   surrogate_G  1
    a[2,20]   physical_G_upper  1
    a[2,21]   R209      1
    a[2,21]   R210      1
    a[2,21]   surrogate_G  1
    a[2,21]   physical_G_upper  1
    a[2,22]   R211      1
    a[2,22]   R212      1
    a[2,22]   surrogate_G  1
    a[2,22]   physical_G_upper  1
    a[2,23]   R213      1
    a[2,23]   R214      1
    a[2,23]   surrogate_G  1
    a[2,23]   physical_G_upper  1
    a[2,24]   R215      1
    a[2,24]   R216      1
    a[2,24]   surrogate_G  1
    a[2,24]   physical_G_upper  1
    a[2,25]   R217      1
    a[2,25]   R218      1
    a[2,25]   surrogate_G  1
    a[2,25]   physical_G_upper  1
    a[2,26]   R219      1
    a[2,26]   R220      1
    a[2,26]   surrogate_G  1
    a[2,26]   physical_G_upper  1
    a[2,27]   R221      1
    a[2,27]   R222      1
    a[2,27]   surrogate_G  1
    a[2,27]   physical_G_upper  1
    a[2,28]   R223      1
    a[2,28]   R224      1
    a[2,28]   surrogate_G  1
    a[2,28]   physical_G_upper  1
    a[2,29]   R225      1
    a[2,29]   R226      1
    a[2,29]   surrogate_G  1
    a[2,29]   physical_G_upper  1
    a[2,30]   R227      1
    a[2,30]   R228      1
    a[2,30]   surrogate_G  1
    a[2,30]   physical_G_upper  1
    a[2,31]   R229      1
    a[2,31]   R230      1
    a[2,31]   surrogate_G  1
    a[2,31]   physical_G_upper  1
    a[2,32]   R231      1
    a[2,32]   R232      1
    a[2,32]   surrogate_G  1
    a[2,32]   physical_G_upper  1
    a[2,33]   R233      1
    a[2,33]   R234      1
    a[2,33]   surrogate_G  1
    a[2,33]   physical_G_upper  1
    a[2,34]   R235      1
    a[2,34]   R236      1
    a[2,34]   surrogate_G  1
    a[2,34]   physical_G_upper  1
    a[2,35]   R237      1
    a[2,35]   R238      1
    a[2,35]   surrogate_G  1
    a[2,35]   physical_G_upper  1
    a[3,4]    R239      1
    a[3,4]    R240      1
    a[3,4]    surrogate_G  1
    a[3,4]    physical_G_upper  1
    a[3,5]    R241      1
    a[3,5]    R242      1
    a[3,5]    surrogate_G  1
    a[3,5]    physical_G_upper  1
    a[3,6]    R243      1
    a[3,6]    R244      1
    a[3,6]    surrogate_G  1
    a[3,6]    physical_G_upper  1
    a[3,7]    R245      1
    a[3,7]    R246      1
    a[3,7]    surrogate_G  1
    a[3,7]    physical_G_upper  1
    a[3,8]    R247      1
    a[3,8]    R248      1
    a[3,8]    surrogate_G  1
    a[3,8]    physical_G_upper  1
    a[3,9]    R249      1
    a[3,9]    R250      1
    a[3,9]    surrogate_G  1
    a[3,9]    physical_G_upper  1
    a[3,10]   R251      1
    a[3,10]   R252      1
    a[3,10]   surrogate_G  1
    a[3,10]   physical_G_upper  1
    a[3,11]   R253      1
    a[3,11]   R254      1
    a[3,11]   surrogate_G  1
    a[3,11]   physical_G_upper  1
    a[3,12]   R255      1
    a[3,12]   R256      1
    a[3,12]   surrogate_G  1
    a[3,12]   physical_G_upper  1
    a[3,13]   R257      1
    a[3,13]   R258      1
    a[3,13]   surrogate_G  1
    a[3,13]   physical_G_upper  1
    a[3,14]   R259      1
    a[3,14]   R260      1
    a[3,14]   surrogate_G  1
    a[3,14]   physical_G_upper  1
    a[3,15]   R261      1
    a[3,15]   R262      1
    a[3,15]   surrogate_G  1
    a[3,15]   physical_G_upper  1
    a[3,16]   R263      1
    a[3,16]   R264      1
    a[3,16]   surrogate_G  1
    a[3,16]   physical_G_upper  1
    a[3,17]   R265      1
    a[3,17]   R266      1
    a[3,17]   surrogate_G  1
    a[3,17]   physical_G_upper  1
    a[3,18]   R267      1
    a[3,18]   R268      1
    a[3,18]   surrogate_G  1
    a[3,18]   physical_G_upper  1
    a[3,19]   R269      1
    a[3,19]   R270      1
    a[3,19]   surrogate_G  1
    a[3,19]   physical_G_upper  1
    a[3,20]   R271      1
    a[3,20]   R272      1
    a[3,20]   surrogate_G  1
    a[3,20]   physical_G_upper  1
    a[3,21]   R273      1
    a[3,21]   R274      1
    a[3,21]   surrogate_G  1
    a[3,21]   physical_G_upper  1
    a[3,22]   R275      1
    a[3,22]   R276      1
    a[3,22]   surrogate_G  1
    a[3,22]   physical_G_upper  1
    a[3,23]   R277      1
    a[3,23]   R278      1
    a[3,23]   surrogate_G  1
    a[3,23]   physical_G_upper  1
    a[3,24]   R279      1
    a[3,24]   R280      1
    a[3,24]   surrogate_G  1
    a[3,24]   physical_G_upper  1
    a[3,25]   R281      1
    a[3,25]   R282      1
    a[3,25]   surrogate_G  1
    a[3,25]   physical_G_upper  1
    a[3,26]   R283      1
    a[3,26]   R284      1
    a[3,26]   surrogate_G  1
    a[3,26]   physical_G_upper  1
    a[3,27]   R285      1
    a[3,27]   R286      1
    a[3,27]   surrogate_G  1
    a[3,27]   physical_G_upper  1
    a[3,28]   R287      1
    a[3,28]   R288      1
    a[3,28]   surrogate_G  1
    a[3,28]   physical_G_upper  1
    a[3,29]   R289      1
    a[3,29]   R290      1
    a[3,29]   surrogate_G  1
    a[3,29]   physical_G_upper  1
    a[3,30]   R291      1
    a[3,30]   R292      1
    a[3,30]   surrogate_G  1
    a[3,30]   physical_G_upper  1
    a[3,31]   R293      1
    a[3,31]   R294      1
    a[3,31]   surrogate_G  1
    a[3,31]   physical_G_upper  1
    a[3,32]   R295      1
    a[3,32]   R296      1
    a[3,32]   surrogate_G  1
    a[3,32]   physical_G_upper  1
    a[3,33]   R297      1
    a[3,33]   R298      1
    a[3,33]   surrogate_G  1
    a[3,33]   physical_G_upper  1
    a[3,34]   R299      1
    a[3,34]   R300      1
    a[3,34]   surrogate_G  1
    a[3,34]   physical_G_upper  1
    a[3,35]   R301      1
    a[3,35]   R302      1
    a[3,35]   surrogate_G  1
    a[3,35]   physical_G_upper  1
    a[4,5]    R303      1
    a[4,5]    R304      1
    a[4,5]    surrogate_G  1
    a[4,5]    physical_G_upper  1
    a[4,6]    R305      1
    a[4,6]    R306      1
    a[4,6]    surrogate_G  1
    a[4,6]    physical_G_upper  1
    a[4,7]    R307      1
    a[4,7]    R308      1
    a[4,7]    surrogate_G  1
    a[4,7]    physical_G_upper  1
    a[4,8]    R309      1
    a[4,8]    R310      1
    a[4,8]    surrogate_G  1
    a[4,8]    physical_G_upper  1
    a[4,9]    R311      1
    a[4,9]    R312      1
    a[4,9]    surrogate_G  1
    a[4,9]    physical_G_upper  1
    a[4,10]   R313      1
    a[4,10]   R314      1
    a[4,10]   surrogate_G  1
    a[4,10]   physical_G_upper  1
    a[4,11]   R315      1
    a[4,11]   R316      1
    a[4,11]   surrogate_G  1
    a[4,11]   physical_G_upper  1
    a[4,12]   R317      1
    a[4,12]   R318      1
    a[4,12]   surrogate_G  1
    a[4,12]   physical_G_upper  1
    a[4,13]   R319      1
    a[4,13]   R320      1
    a[4,13]   surrogate_G  1
    a[4,13]   physical_G_upper  1
    a[4,14]   R321      1
    a[4,14]   R322      1
    a[4,14]   surrogate_G  1
    a[4,14]   physical_G_upper  1
    a[4,15]   R323      1
    a[4,15]   R324      1
    a[4,15]   surrogate_G  1
    a[4,15]   physical_G_upper  1
    a[4,16]   R325      1
    a[4,16]   R326      1
    a[4,16]   surrogate_G  1
    a[4,16]   physical_G_upper  1
    a[4,17]   R327      1
    a[4,17]   R328      1
    a[4,17]   surrogate_G  1
    a[4,17]   physical_G_upper  1
    a[4,18]   R329      1
    a[4,18]   R330      1
    a[4,18]   surrogate_G  1
    a[4,18]   physical_G_upper  1
    a[4,19]   R331      1
    a[4,19]   R332      1
    a[4,19]   surrogate_G  1
    a[4,19]   physical_G_upper  1
    a[4,20]   R333      1
    a[4,20]   R334      1
    a[4,20]   surrogate_G  1
    a[4,20]   physical_G_upper  1
    a[4,21]   R335      1
    a[4,21]   R336      1
    a[4,21]   surrogate_G  1
    a[4,21]   physical_G_upper  1
    a[4,22]   R337      1
    a[4,22]   R338      1
    a[4,22]   surrogate_G  1
    a[4,22]   physical_G_upper  1
    a[4,23]   R339      1
    a[4,23]   R340      1
    a[4,23]   surrogate_G  1
    a[4,23]   physical_G_upper  1
    a[4,24]   R341      1
    a[4,24]   R342      1
    a[4,24]   surrogate_G  1
    a[4,24]   physical_G_upper  1
    a[4,25]   R343      1
    a[4,25]   R344      1
    a[4,25]   surrogate_G  1
    a[4,25]   physical_G_upper  1
    a[4,26]   R345      1
    a[4,26]   R346      1
    a[4,26]   surrogate_G  1
    a[4,26]   physical_G_upper  1
    a[4,27]   R347      1
    a[4,27]   R348      1
    a[4,27]   surrogate_G  1
    a[4,27]   physical_G_upper  1
    a[4,28]   R349      1
    a[4,28]   R350      1
    a[4,28]   surrogate_G  1
    a[4,28]   physical_G_upper  1
    a[4,29]   R351      1
    a[4,29]   R352      1
    a[4,29]   surrogate_G  1
    a[4,29]   physical_G_upper  1
    a[4,30]   R353      1
    a[4,30]   R354      1
    a[4,30]   surrogate_G  1
    a[4,30]   physical_G_upper  1
    a[4,31]   R355      1
    a[4,31]   R356      1
    a[4,31]   surrogate_G  1
    a[4,31]   physical_G_upper  1
    a[4,32]   R357      1
    a[4,32]   R358      1
    a[4,32]   surrogate_G  1
    a[4,32]   physical_G_upper  1
    a[4,33]   R359      1
    a[4,33]   R360      1
    a[4,33]   surrogate_G  1
    a[4,33]   physical_G_upper  1
    a[4,34]   R361      1
    a[4,34]   R362      1
    a[4,34]   surrogate_G  1
    a[4,34]   physical_G_upper  1
    a[4,35]   R363      1
    a[4,35]   R364      1
    a[4,35]   surrogate_G  1
    a[4,35]   physical_G_upper  1
    a[5,6]    R365      1
    a[5,6]    R366      1
    a[5,6]    surrogate_G  1
    a[5,6]    physical_G_upper  1
    a[5,7]    R367      1
    a[5,7]    R368      1
    a[5,7]    surrogate_G  1
    a[5,7]    physical_G_upper  1
    a[5,8]    R369      1
    a[5,8]    R370      1
    a[5,8]    surrogate_G  1
    a[5,8]    physical_G_upper  1
    a[5,9]    R371      1
    a[5,9]    R372      1
    a[5,9]    surrogate_G  1
    a[5,9]    physical_G_upper  1
    a[5,10]   R373      1
    a[5,10]   R374      1
    a[5,10]   surrogate_G  1
    a[5,10]   physical_G_upper  1
    a[5,11]   R375      1
    a[5,11]   R376      1
    a[5,11]   surrogate_G  1
    a[5,11]   physical_G_upper  1
    a[5,12]   R377      1
    a[5,12]   R378      1
    a[5,12]   surrogate_G  1
    a[5,12]   physical_G_upper  1
    a[5,13]   R379      1
    a[5,13]   R380      1
    a[5,13]   surrogate_G  1
    a[5,13]   physical_G_upper  1
    a[5,14]   R381      1
    a[5,14]   R382      1
    a[5,14]   surrogate_G  1
    a[5,14]   physical_G_upper  1
    a[5,15]   R383      1
    a[5,15]   R384      1
    a[5,15]   surrogate_G  1
    a[5,15]   physical_G_upper  1
    a[5,16]   R385      1
    a[5,16]   R386      1
    a[5,16]   surrogate_G  1
    a[5,16]   physical_G_upper  1
    a[5,17]   R387      1
    a[5,17]   R388      1
    a[5,17]   surrogate_G  1
    a[5,17]   physical_G_upper  1
    a[5,18]   R389      1
    a[5,18]   R390      1
    a[5,18]   surrogate_G  1
    a[5,18]   physical_G_upper  1
    a[5,19]   R391      1
    a[5,19]   R392      1
    a[5,19]   surrogate_G  1
    a[5,19]   physical_G_upper  1
    a[5,20]   R393      1
    a[5,20]   R394      1
    a[5,20]   surrogate_G  1
    a[5,20]   physical_G_upper  1
    a[5,21]   R395      1
    a[5,21]   R396      1
    a[5,21]   surrogate_G  1
    a[5,21]   physical_G_upper  1
    a[5,22]   R397      1
    a[5,22]   R398      1
    a[5,22]   surrogate_G  1
    a[5,22]   physical_G_upper  1
    a[5,23]   R399      1
    a[5,23]   R400      1
    a[5,23]   surrogate_G  1
    a[5,23]   physical_G_upper  1
    a[5,24]   R401      1
    a[5,24]   R402      1
    a[5,24]   surrogate_G  1
    a[5,24]   physical_G_upper  1
    a[5,25]   R403      1
    a[5,25]   R404      1
    a[5,25]   surrogate_G  1
    a[5,25]   physical_G_upper  1
    a[5,26]   R405      1
    a[5,26]   R406      1
    a[5,26]   surrogate_G  1
    a[5,26]   physical_G_upper  1
    a[5,27]   R407      1
    a[5,27]   R408      1
    a[5,27]   surrogate_G  1
    a[5,27]   physical_G_upper  1
    a[5,28]   R409      1
    a[5,28]   R410      1
    a[5,28]   surrogate_G  1
    a[5,28]   physical_G_upper  1
    a[5,29]   R411      1
    a[5,29]   R412      1
    a[5,29]   surrogate_G  1
    a[5,29]   physical_G_upper  1
    a[5,30]   R413      1
    a[5,30]   R414      1
    a[5,30]   surrogate_G  1
    a[5,30]   physical_G_upper  1
    a[5,31]   R415      1
    a[5,31]   R416      1
    a[5,31]   surrogate_G  1
    a[5,31]   physical_G_upper  1
    a[5,32]   R417      1
    a[5,32]   R418      1
    a[5,32]   surrogate_G  1
    a[5,32]   physical_G_upper  1
    a[5,33]   R419      1
    a[5,33]   R420      1
    a[5,33]   surrogate_G  1
    a[5,33]   physical_G_upper  1
    a[5,34]   R421      1
    a[5,34]   R422      1
    a[5,34]   surrogate_G  1
    a[5,34]   physical_G_upper  1
    a[5,35]   R423      1
    a[5,35]   R424      1
    a[5,35]   surrogate_G  1
    a[5,35]   physical_G_upper  1
    a[6,7]    R425      1
    a[6,7]    R426      1
    a[6,7]    surrogate_G  1
    a[6,7]    physical_G_upper  1
    a[6,8]    R427      1
    a[6,8]    R428      1
    a[6,8]    surrogate_G  1
    a[6,8]    physical_G_upper  1
    a[6,9]    R429      1
    a[6,9]    R430      1
    a[6,9]    surrogate_G  1
    a[6,9]    physical_G_upper  1
    a[6,10]   R431      1
    a[6,10]   R432      1
    a[6,10]   surrogate_G  1
    a[6,10]   physical_G_upper  1
    a[6,11]   R433      1
    a[6,11]   R434      1
    a[6,11]   surrogate_G  1
    a[6,11]   physical_G_upper  1
    a[6,12]   R435      1
    a[6,12]   R436      1
    a[6,12]   surrogate_G  1
    a[6,12]   physical_G_upper  1
    a[6,13]   R437      1
    a[6,13]   R438      1
    a[6,13]   surrogate_G  1
    a[6,13]   physical_G_upper  1
    a[6,14]   R439      1
    a[6,14]   R440      1
    a[6,14]   surrogate_G  1
    a[6,14]   physical_G_upper  1
    a[6,15]   R441      1
    a[6,15]   R442      1
    a[6,15]   surrogate_G  1
    a[6,15]   physical_G_upper  1
    a[6,16]   R443      1
    a[6,16]   R444      1
    a[6,16]   surrogate_G  1
    a[6,16]   physical_G_upper  1
    a[6,17]   R445      1
    a[6,17]   R446      1
    a[6,17]   surrogate_G  1
    a[6,17]   physical_G_upper  1
    a[6,18]   R447      1
    a[6,18]   R448      1
    a[6,18]   surrogate_G  1
    a[6,18]   physical_G_upper  1
    a[6,19]   R449      1
    a[6,19]   R450      1
    a[6,19]   surrogate_G  1
    a[6,19]   physical_G_upper  1
    a[6,20]   R451      1
    a[6,20]   R452      1
    a[6,20]   surrogate_G  1
    a[6,20]   physical_G_upper  1
    a[6,21]   R453      1
    a[6,21]   R454      1
    a[6,21]   surrogate_G  1
    a[6,21]   physical_G_upper  1
    a[6,22]   R455      1
    a[6,22]   R456      1
    a[6,22]   surrogate_G  1
    a[6,22]   physical_G_upper  1
    a[6,23]   R457      1
    a[6,23]   R458      1
    a[6,23]   surrogate_G  1
    a[6,23]   physical_G_upper  1
    a[6,24]   R459      1
    a[6,24]   R460      1
    a[6,24]   surrogate_G  1
    a[6,24]   physical_G_upper  1
    a[6,25]   R461      1
    a[6,25]   R462      1
    a[6,25]   surrogate_G  1
    a[6,25]   physical_G_upper  1
    a[6,26]   R463      1
    a[6,26]   R464      1
    a[6,26]   surrogate_G  1
    a[6,26]   physical_G_upper  1
    a[6,27]   R465      1
    a[6,27]   R466      1
    a[6,27]   surrogate_G  1
    a[6,27]   physical_G_upper  1
    a[6,28]   R467      1
    a[6,28]   R468      1
    a[6,28]   surrogate_G  1
    a[6,28]   physical_G_upper  1
    a[6,29]   R469      1
    a[6,29]   R470      1
    a[6,29]   surrogate_G  1
    a[6,29]   physical_G_upper  1
    a[6,30]   R471      1
    a[6,30]   R472      1
    a[6,30]   surrogate_G  1
    a[6,30]   physical_G_upper  1
    a[6,31]   R473      1
    a[6,31]   R474      1
    a[6,31]   surrogate_G  1
    a[6,31]   physical_G_upper  1
    a[6,32]   R475      1
    a[6,32]   R476      1
    a[6,32]   surrogate_G  1
    a[6,32]   physical_G_upper  1
    a[6,33]   R477      1
    a[6,33]   R478      1
    a[6,33]   surrogate_G  1
    a[6,33]   physical_G_upper  1
    a[6,34]   R479      1
    a[6,34]   R480      1
    a[6,34]   surrogate_G  1
    a[6,34]   physical_G_upper  1
    a[6,35]   R481      1
    a[6,35]   R482      1
    a[6,35]   surrogate_G  1
    a[6,35]   physical_G_upper  1
    a[7,8]    R483      1
    a[7,8]    R484      1
    a[7,8]    surrogate_G  1
    a[7,8]    physical_G_upper  1
    a[7,9]    R485      1
    a[7,9]    R486      1
    a[7,9]    surrogate_G  1
    a[7,9]    physical_G_upper  1
    a[7,10]   R487      1
    a[7,10]   R488      1
    a[7,10]   surrogate_G  1
    a[7,10]   physical_G_upper  1
    a[7,11]   R489      1
    a[7,11]   R490      1
    a[7,11]   surrogate_G  1
    a[7,11]   physical_G_upper  1
    a[7,12]   R491      1
    a[7,12]   R492      1
    a[7,12]   surrogate_G  1
    a[7,12]   physical_G_upper  1
    a[7,13]   R493      1
    a[7,13]   R494      1
    a[7,13]   surrogate_G  1
    a[7,13]   physical_G_upper  1
    a[7,14]   R495      1
    a[7,14]   R496      1
    a[7,14]   surrogate_G  1
    a[7,14]   physical_G_upper  1
    a[7,15]   R497      1
    a[7,15]   R498      1
    a[7,15]   surrogate_G  1
    a[7,15]   physical_G_upper  1
    a[7,16]   R499      1
    a[7,16]   R500      1
    a[7,16]   surrogate_G  1
    a[7,16]   physical_G_upper  1
    a[7,17]   R501      1
    a[7,17]   R502      1
    a[7,17]   surrogate_G  1
    a[7,17]   physical_G_upper  1
    a[7,18]   R503      1
    a[7,18]   R504      1
    a[7,18]   surrogate_G  1
    a[7,18]   physical_G_upper  1
    a[7,19]   R505      1
    a[7,19]   R506      1
    a[7,19]   surrogate_G  1
    a[7,19]   physical_G_upper  1
    a[7,20]   R507      1
    a[7,20]   R508      1
    a[7,20]   surrogate_G  1
    a[7,20]   physical_G_upper  1
    a[7,21]   R509      1
    a[7,21]   R510      1
    a[7,21]   surrogate_G  1
    a[7,21]   physical_G_upper  1
    a[7,22]   R511      1
    a[7,22]   R512      1
    a[7,22]   surrogate_G  1
    a[7,22]   physical_G_upper  1
    a[7,23]   R513      1
    a[7,23]   R514      1
    a[7,23]   surrogate_G  1
    a[7,23]   physical_G_upper  1
    a[7,24]   R515      1
    a[7,24]   R516      1
    a[7,24]   surrogate_G  1
    a[7,24]   physical_G_upper  1
    a[7,25]   R517      1
    a[7,25]   R518      1
    a[7,25]   surrogate_G  1
    a[7,25]   physical_G_upper  1
    a[7,26]   R519      1
    a[7,26]   R520      1
    a[7,26]   surrogate_G  1
    a[7,26]   physical_G_upper  1
    a[7,27]   R521      1
    a[7,27]   R522      1
    a[7,27]   surrogate_G  1
    a[7,27]   physical_G_upper  1
    a[7,28]   R523      1
    a[7,28]   R524      1
    a[7,28]   surrogate_G  1
    a[7,28]   physical_G_upper  1
    a[7,29]   R525      1
    a[7,29]   R526      1
    a[7,29]   surrogate_G  1
    a[7,29]   physical_G_upper  1
    a[7,30]   R527      1
    a[7,30]   R528      1
    a[7,30]   surrogate_G  1
    a[7,30]   physical_G_upper  1
    a[7,31]   R529      1
    a[7,31]   R530      1
    a[7,31]   surrogate_G  1
    a[7,31]   physical_G_upper  1
    a[7,32]   R531      1
    a[7,32]   R532      1
    a[7,32]   surrogate_G  1
    a[7,32]   physical_G_upper  1
    a[7,33]   R533      1
    a[7,33]   R534      1
    a[7,33]   surrogate_G  1
    a[7,33]   physical_G_upper  1
    a[7,34]   R535      1
    a[7,34]   R536      1
    a[7,34]   surrogate_G  1
    a[7,34]   physical_G_upper  1
    a[7,35]   R537      1
    a[7,35]   R538      1
    a[7,35]   surrogate_G  1
    a[7,35]   physical_G_upper  1
    a[8,9]    R539      1
    a[8,9]    R540      1
    a[8,9]    surrogate_G  1
    a[8,9]    physical_G_upper  1
    a[8,10]   R541      1
    a[8,10]   R542      1
    a[8,10]   surrogate_G  1
    a[8,10]   physical_G_upper  1
    a[8,11]   R543      1
    a[8,11]   R544      1
    a[8,11]   surrogate_G  1
    a[8,11]   physical_G_upper  1
    a[8,12]   R545      1
    a[8,12]   R546      1
    a[8,12]   surrogate_G  1
    a[8,12]   physical_G_upper  1
    a[8,13]   R547      1
    a[8,13]   R548      1
    a[8,13]   surrogate_G  1
    a[8,13]   physical_G_upper  1
    a[8,14]   R549      1
    a[8,14]   R550      1
    a[8,14]   surrogate_G  1
    a[8,14]   physical_G_upper  1
    a[8,15]   R551      1
    a[8,15]   R552      1
    a[8,15]   surrogate_G  1
    a[8,15]   physical_G_upper  1
    a[8,16]   R553      1
    a[8,16]   R554      1
    a[8,16]   surrogate_G  1
    a[8,16]   physical_G_upper  1
    a[8,17]   R555      1
    a[8,17]   R556      1
    a[8,17]   surrogate_G  1
    a[8,17]   physical_G_upper  1
    a[8,18]   R557      1
    a[8,18]   R558      1
    a[8,18]   surrogate_G  1
    a[8,18]   physical_G_upper  1
    a[8,19]   R559      1
    a[8,19]   R560      1
    a[8,19]   surrogate_G  1
    a[8,19]   physical_G_upper  1
    a[8,20]   R561      1
    a[8,20]   R562      1
    a[8,20]   surrogate_G  1
    a[8,20]   physical_G_upper  1
    a[8,21]   R563      1
    a[8,21]   R564      1
    a[8,21]   surrogate_G  1
    a[8,21]   physical_G_upper  1
    a[8,22]   R565      1
    a[8,22]   R566      1
    a[8,22]   surrogate_G  1
    a[8,22]   physical_G_upper  1
    a[8,23]   R567      1
    a[8,23]   R568      1
    a[8,23]   surrogate_G  1
    a[8,23]   physical_G_upper  1
    a[8,24]   R569      1
    a[8,24]   R570      1
    a[8,24]   surrogate_G  1
    a[8,24]   physical_G_upper  1
    a[8,25]   R571      1
    a[8,25]   R572      1
    a[8,25]   surrogate_G  1
    a[8,25]   physical_G_upper  1
    a[8,26]   R573      1
    a[8,26]   R574      1
    a[8,26]   surrogate_G  1
    a[8,26]   physical_G_upper  1
    a[8,27]   R575      1
    a[8,27]   R576      1
    a[8,27]   surrogate_G  1
    a[8,27]   physical_G_upper  1
    a[8,28]   R577      1
    a[8,28]   R578      1
    a[8,28]   surrogate_G  1
    a[8,28]   physical_G_upper  1
    a[8,29]   R579      1
    a[8,29]   R580      1
    a[8,29]   surrogate_G  1
    a[8,29]   physical_G_upper  1
    a[8,30]   R581      1
    a[8,30]   R582      1
    a[8,30]   surrogate_G  1
    a[8,30]   physical_G_upper  1
    a[8,31]   R583      1
    a[8,31]   R584      1
    a[8,31]   surrogate_G  1
    a[8,31]   physical_G_upper  1
    a[8,32]   R585      1
    a[8,32]   R586      1
    a[8,32]   surrogate_G  1
    a[8,32]   physical_G_upper  1
    a[8,33]   R587      1
    a[8,33]   R588      1
    a[8,33]   surrogate_G  1
    a[8,33]   physical_G_upper  1
    a[8,34]   R589      1
    a[8,34]   R590      1
    a[8,34]   surrogate_G  1
    a[8,34]   physical_G_upper  1
    a[8,35]   R591      1
    a[8,35]   R592      1
    a[8,35]   surrogate_G  1
    a[8,35]   physical_G_upper  1
    a[9,10]   R593      1
    a[9,10]   R594      1
    a[9,10]   surrogate_G  1
    a[9,10]   physical_G_upper  1
    a[9,11]   R595      1
    a[9,11]   R596      1
    a[9,11]   surrogate_G  1
    a[9,11]   physical_G_upper  1
    a[9,12]   R597      1
    a[9,12]   R598      1
    a[9,12]   surrogate_G  1
    a[9,12]   physical_G_upper  1
    a[9,13]   R599      1
    a[9,13]   R600      1
    a[9,13]   surrogate_G  1
    a[9,13]   physical_G_upper  1
    a[9,14]   R601      1
    a[9,14]   R602      1
    a[9,14]   surrogate_G  1
    a[9,14]   physical_G_upper  1
    a[9,15]   R603      1
    a[9,15]   R604      1
    a[9,15]   surrogate_G  1
    a[9,15]   physical_G_upper  1
    a[9,16]   R605      1
    a[9,16]   R606      1
    a[9,16]   surrogate_G  1
    a[9,16]   physical_G_upper  1
    a[9,17]   R607      1
    a[9,17]   R608      1
    a[9,17]   surrogate_G  1
    a[9,17]   physical_G_upper  1
    a[9,18]   R609      1
    a[9,18]   R610      1
    a[9,18]   surrogate_G  1
    a[9,18]   physical_G_upper  1
    a[9,19]   R611      1
    a[9,19]   R612      1
    a[9,19]   surrogate_G  1
    a[9,19]   physical_G_upper  1
    a[9,20]   R613      1
    a[9,20]   R614      1
    a[9,20]   surrogate_G  1
    a[9,20]   physical_G_upper  1
    a[9,21]   R615      1
    a[9,21]   R616      1
    a[9,21]   surrogate_G  1
    a[9,21]   physical_G_upper  1
    a[9,22]   R617      1
    a[9,22]   R618      1
    a[9,22]   surrogate_G  1
    a[9,22]   physical_G_upper  1
    a[9,23]   R619      1
    a[9,23]   R620      1
    a[9,23]   surrogate_G  1
    a[9,23]   physical_G_upper  1
    a[9,24]   R621      1
    a[9,24]   R622      1
    a[9,24]   surrogate_G  1
    a[9,24]   physical_G_upper  1
    a[9,25]   R623      1
    a[9,25]   R624      1
    a[9,25]   surrogate_G  1
    a[9,25]   physical_G_upper  1
    a[9,26]   R625      1
    a[9,26]   R626      1
    a[9,26]   surrogate_G  1
    a[9,26]   physical_G_upper  1
    a[9,27]   R627      1
    a[9,27]   R628      1
    a[9,27]   surrogate_G  1
    a[9,27]   physical_G_upper  1
    a[9,28]   R629      1
    a[9,28]   R630      1
    a[9,28]   surrogate_G  1
    a[9,28]   physical_G_upper  1
    a[9,29]   R631      1
    a[9,29]   R632      1
    a[9,29]   surrogate_G  1
    a[9,29]   physical_G_upper  1
    a[9,30]   R633      1
    a[9,30]   R634      1
    a[9,30]   surrogate_G  1
    a[9,30]   physical_G_upper  1
    a[9,31]   R635      1
    a[9,31]   R636      1
    a[9,31]   surrogate_G  1
    a[9,31]   physical_G_upper  1
    a[9,32]   R637      1
    a[9,32]   R638      1
    a[9,32]   surrogate_G  1
    a[9,32]   physical_G_upper  1
    a[9,33]   R639      1
    a[9,33]   R640      1
    a[9,33]   surrogate_G  1
    a[9,33]   physical_G_upper  1
    a[9,34]   R641      1
    a[9,34]   R642      1
    a[9,34]   surrogate_G  1
    a[9,34]   physical_G_upper  1
    a[9,35]   R643      1
    a[9,35]   R644      1
    a[9,35]   surrogate_G  1
    a[9,35]   physical_G_upper  1
    a[10,11]  R645      1
    a[10,11]  R646      1
    a[10,11]  surrogate_G  1
    a[10,11]  physical_G_upper  1
    a[10,12]  R647      1
    a[10,12]  R648      1
    a[10,12]  surrogate_G  1
    a[10,12]  physical_G_upper  1
    a[10,13]  R649      1
    a[10,13]  R650      1
    a[10,13]  surrogate_G  1
    a[10,13]  physical_G_upper  1
    a[10,14]  R651      1
    a[10,14]  R652      1
    a[10,14]  surrogate_G  1
    a[10,14]  physical_G_upper  1
    a[10,15]  R653      1
    a[10,15]  R654      1
    a[10,15]  surrogate_G  1
    a[10,15]  physical_G_upper  1
    a[10,16]  R655      1
    a[10,16]  R656      1
    a[10,16]  surrogate_G  1
    a[10,16]  physical_G_upper  1
    a[10,17]  R657      1
    a[10,17]  R658      1
    a[10,17]  surrogate_G  1
    a[10,17]  physical_G_upper  1
    a[10,18]  R659      1
    a[10,18]  R660      1
    a[10,18]  surrogate_G  1
    a[10,18]  physical_G_upper  1
    a[10,19]  R661      1
    a[10,19]  R662      1
    a[10,19]  surrogate_G  1
    a[10,19]  physical_G_upper  1
    a[10,20]  R663      1
    a[10,20]  R664      1
    a[10,20]  surrogate_G  1
    a[10,20]  physical_G_upper  1
    a[10,21]  R665      1
    a[10,21]  R666      1
    a[10,21]  surrogate_G  1
    a[10,21]  physical_G_upper  1
    a[10,22]  R667      1
    a[10,22]  R668      1
    a[10,22]  surrogate_G  1
    a[10,22]  physical_G_upper  1
    a[10,23]  R669      1
    a[10,23]  R670      1
    a[10,23]  surrogate_G  1
    a[10,23]  physical_G_upper  1
    a[10,24]  R671      1
    a[10,24]  R672      1
    a[10,24]  surrogate_G  1
    a[10,24]  physical_G_upper  1
    a[10,25]  R673      1
    a[10,25]  R674      1
    a[10,25]  surrogate_G  1
    a[10,25]  physical_G_upper  1
    a[10,26]  R675      1
    a[10,26]  R676      1
    a[10,26]  surrogate_G  1
    a[10,26]  physical_G_upper  1
    a[10,27]  R677      1
    a[10,27]  R678      1
    a[10,27]  surrogate_G  1
    a[10,27]  physical_G_upper  1
    a[10,28]  R679      1
    a[10,28]  R680      1
    a[10,28]  surrogate_G  1
    a[10,28]  physical_G_upper  1
    a[10,29]  R681      1
    a[10,29]  R682      1
    a[10,29]  surrogate_G  1
    a[10,29]  physical_G_upper  1
    a[10,30]  R683      1
    a[10,30]  R684      1
    a[10,30]  surrogate_G  1
    a[10,30]  physical_G_upper  1
    a[10,31]  R685      1
    a[10,31]  R686      1
    a[10,31]  surrogate_G  1
    a[10,31]  physical_G_upper  1
    a[10,32]  R687      1
    a[10,32]  R688      1
    a[10,32]  surrogate_G  1
    a[10,32]  physical_G_upper  1
    a[10,33]  R689      1
    a[10,33]  R690      1
    a[10,33]  surrogate_G  1
    a[10,33]  physical_G_upper  1
    a[10,34]  R691      1
    a[10,34]  R692      1
    a[10,34]  surrogate_G  1
    a[10,34]  physical_G_upper  1
    a[10,35]  R693      1
    a[10,35]  R694      1
    a[10,35]  surrogate_G  1
    a[10,35]  physical_G_upper  1
    a[11,12]  R695      1
    a[11,12]  R696      1
    a[11,12]  surrogate_G  1
    a[11,12]  physical_G_upper  1
    a[11,13]  R697      1
    a[11,13]  R698      1
    a[11,13]  surrogate_G  1
    a[11,13]  physical_G_upper  1
    a[11,14]  R699      1
    a[11,14]  R700      1
    a[11,14]  surrogate_G  1
    a[11,14]  physical_G_upper  1
    a[11,15]  R701      1
    a[11,15]  R702      1
    a[11,15]  surrogate_G  1
    a[11,15]  physical_G_upper  1
    a[11,16]  R703      1
    a[11,16]  R704      1
    a[11,16]  surrogate_G  1
    a[11,16]  physical_G_upper  1
    a[11,17]  R705      1
    a[11,17]  R706      1
    a[11,17]  surrogate_G  1
    a[11,17]  physical_G_upper  1
    a[11,18]  R707      1
    a[11,18]  R708      1
    a[11,18]  surrogate_G  1
    a[11,18]  physical_G_upper  1
    a[11,19]  R709      1
    a[11,19]  R710      1
    a[11,19]  surrogate_G  1
    a[11,19]  physical_G_upper  1
    a[11,20]  R711      1
    a[11,20]  R712      1
    a[11,20]  surrogate_G  1
    a[11,20]  physical_G_upper  1
    a[11,21]  R713      1
    a[11,21]  R714      1
    a[11,21]  surrogate_G  1
    a[11,21]  physical_G_upper  1
    a[11,22]  R715      1
    a[11,22]  R716      1
    a[11,22]  surrogate_G  1
    a[11,22]  physical_G_upper  1
    a[11,23]  R717      1
    a[11,23]  R718      1
    a[11,23]  surrogate_G  1
    a[11,23]  physical_G_upper  1
    a[11,24]  R719      1
    a[11,24]  R720      1
    a[11,24]  surrogate_G  1
    a[11,24]  physical_G_upper  1
    a[11,25]  R721      1
    a[11,25]  R722      1
    a[11,25]  surrogate_G  1
    a[11,25]  physical_G_upper  1
    a[11,26]  R723      1
    a[11,26]  R724      1
    a[11,26]  surrogate_G  1
    a[11,26]  physical_G_upper  1
    a[11,27]  R725      1
    a[11,27]  R726      1
    a[11,27]  surrogate_G  1
    a[11,27]  physical_G_upper  1
    a[11,28]  R727      1
    a[11,28]  R728      1
    a[11,28]  surrogate_G  1
    a[11,28]  physical_G_upper  1
    a[11,29]  R729      1
    a[11,29]  R730      1
    a[11,29]  surrogate_G  1
    a[11,29]  physical_G_upper  1
    a[11,30]  R731      1
    a[11,30]  R732      1
    a[11,30]  surrogate_G  1
    a[11,30]  physical_G_upper  1
    a[11,31]  R733      1
    a[11,31]  R734      1
    a[11,31]  surrogate_G  1
    a[11,31]  physical_G_upper  1
    a[11,32]  R735      1
    a[11,32]  R736      1
    a[11,32]  surrogate_G  1
    a[11,32]  physical_G_upper  1
    a[11,33]  R737      1
    a[11,33]  R738      1
    a[11,33]  surrogate_G  1
    a[11,33]  physical_G_upper  1
    a[11,34]  R739      1
    a[11,34]  R740      1
    a[11,34]  surrogate_G  1
    a[11,34]  physical_G_upper  1
    a[11,35]  R741      1
    a[11,35]  R742      1
    a[11,35]  surrogate_G  1
    a[11,35]  physical_G_upper  1
    a[12,13]  R743      1
    a[12,13]  R744      1
    a[12,13]  surrogate_G  1
    a[12,13]  physical_G_upper  1
    a[12,14]  R745      1
    a[12,14]  R746      1
    a[12,14]  surrogate_G  1
    a[12,14]  physical_G_upper  1
    a[12,15]  R747      1
    a[12,15]  R748      1
    a[12,15]  surrogate_G  1
    a[12,15]  physical_G_upper  1
    a[12,16]  R749      1
    a[12,16]  R750      1
    a[12,16]  surrogate_G  1
    a[12,16]  physical_G_upper  1
    a[12,17]  R751      1
    a[12,17]  R752      1
    a[12,17]  surrogate_G  1
    a[12,17]  physical_G_upper  1
    a[12,18]  R753      1
    a[12,18]  R754      1
    a[12,18]  surrogate_G  1
    a[12,18]  physical_G_upper  1
    a[12,19]  R755      1
    a[12,19]  R756      1
    a[12,19]  surrogate_G  1
    a[12,19]  physical_G_upper  1
    a[12,20]  R757      1
    a[12,20]  R758      1
    a[12,20]  surrogate_G  1
    a[12,20]  physical_G_upper  1
    a[12,21]  R759      1
    a[12,21]  R760      1
    a[12,21]  surrogate_G  1
    a[12,21]  physical_G_upper  1
    a[12,22]  R761      1
    a[12,22]  R762      1
    a[12,22]  surrogate_G  1
    a[12,22]  physical_G_upper  1
    a[12,23]  R763      1
    a[12,23]  R764      1
    a[12,23]  surrogate_G  1
    a[12,23]  physical_G_upper  1
    a[12,24]  R765      1
    a[12,24]  R766      1
    a[12,24]  surrogate_G  1
    a[12,24]  physical_G_upper  1
    a[12,25]  R767      1
    a[12,25]  R768      1
    a[12,25]  surrogate_G  1
    a[12,25]  physical_G_upper  1
    a[12,26]  R769      1
    a[12,26]  R770      1
    a[12,26]  surrogate_G  1
    a[12,26]  physical_G_upper  1
    a[12,27]  R771      1
    a[12,27]  R772      1
    a[12,27]  surrogate_G  1
    a[12,27]  physical_G_upper  1
    a[12,28]  R773      1
    a[12,28]  R774      1
    a[12,28]  surrogate_G  1
    a[12,28]  physical_G_upper  1
    a[12,29]  R775      1
    a[12,29]  R776      1
    a[12,29]  surrogate_G  1
    a[12,29]  physical_G_upper  1
    a[12,30]  R777      1
    a[12,30]  R778      1
    a[12,30]  surrogate_G  1
    a[12,30]  physical_G_upper  1
    a[12,31]  R779      1
    a[12,31]  R780      1
    a[12,31]  surrogate_G  1
    a[12,31]  physical_G_upper  1
    a[12,32]  R781      1
    a[12,32]  R782      1
    a[12,32]  surrogate_G  1
    a[12,32]  physical_G_upper  1
    a[12,33]  R783      1
    a[12,33]  R784      1
    a[12,33]  surrogate_G  1
    a[12,33]  physical_G_upper  1
    a[12,34]  R785      1
    a[12,34]  R786      1
    a[12,34]  surrogate_G  1
    a[12,34]  physical_G_upper  1
    a[12,35]  R787      1
    a[12,35]  R788      1
    a[12,35]  surrogate_G  1
    a[12,35]  physical_G_upper  1
    a[13,14]  R789      1
    a[13,14]  R790      1
    a[13,14]  surrogate_G  1
    a[13,14]  physical_G_upper  1
    a[13,15]  R791      1
    a[13,15]  R792      1
    a[13,15]  surrogate_G  1
    a[13,15]  physical_G_upper  1
    a[13,16]  R793      1
    a[13,16]  R794      1
    a[13,16]  surrogate_G  1
    a[13,16]  physical_G_upper  1
    a[13,17]  R795      1
    a[13,17]  R796      1
    a[13,17]  surrogate_G  1
    a[13,17]  physical_G_upper  1
    a[13,18]  R797      1
    a[13,18]  R798      1
    a[13,18]  surrogate_G  1
    a[13,18]  physical_G_upper  1
    a[13,19]  R799      1
    a[13,19]  R800      1
    a[13,19]  surrogate_G  1
    a[13,19]  physical_G_upper  1
    a[13,20]  R801      1
    a[13,20]  R802      1
    a[13,20]  surrogate_G  1
    a[13,20]  physical_G_upper  1
    a[13,21]  R803      1
    a[13,21]  R804      1
    a[13,21]  surrogate_G  1
    a[13,21]  physical_G_upper  1
    a[13,22]  R805      1
    a[13,22]  R806      1
    a[13,22]  surrogate_G  1
    a[13,22]  physical_G_upper  1
    a[13,23]  R807      1
    a[13,23]  R808      1
    a[13,23]  surrogate_G  1
    a[13,23]  physical_G_upper  1
    a[13,24]  R809      1
    a[13,24]  R810      1
    a[13,24]  surrogate_G  1
    a[13,24]  physical_G_upper  1
    a[13,25]  R811      1
    a[13,25]  R812      1
    a[13,25]  surrogate_G  1
    a[13,25]  physical_G_upper  1
    a[13,26]  R813      1
    a[13,26]  R814      1
    a[13,26]  surrogate_G  1
    a[13,26]  physical_G_upper  1
    a[13,27]  R815      1
    a[13,27]  R816      1
    a[13,27]  surrogate_G  1
    a[13,27]  physical_G_upper  1
    a[13,28]  R817      1
    a[13,28]  R818      1
    a[13,28]  surrogate_G  1
    a[13,28]  physical_G_upper  1
    a[13,29]  R819      1
    a[13,29]  R820      1
    a[13,29]  surrogate_G  1
    a[13,29]  physical_G_upper  1
    a[13,30]  R821      1
    a[13,30]  R822      1
    a[13,30]  surrogate_G  1
    a[13,30]  physical_G_upper  1
    a[13,31]  R823      1
    a[13,31]  R824      1
    a[13,31]  surrogate_G  1
    a[13,31]  physical_G_upper  1
    a[13,32]  R825      1
    a[13,32]  R826      1
    a[13,32]  surrogate_G  1
    a[13,32]  physical_G_upper  1
    a[13,33]  R827      1
    a[13,33]  R828      1
    a[13,33]  surrogate_G  1
    a[13,33]  physical_G_upper  1
    a[13,34]  R829      1
    a[13,34]  R830      1
    a[13,34]  surrogate_G  1
    a[13,34]  physical_G_upper  1
    a[13,35]  R831      1
    a[13,35]  R832      1
    a[13,35]  surrogate_G  1
    a[13,35]  physical_G_upper  1
    a[14,15]  R833      1
    a[14,15]  R834      1
    a[14,15]  surrogate_G  1
    a[14,15]  physical_G_upper  1
    a[14,16]  R835      1
    a[14,16]  R836      1
    a[14,16]  surrogate_G  1
    a[14,16]  physical_G_upper  1
    a[14,17]  R837      1
    a[14,17]  R838      1
    a[14,17]  surrogate_G  1
    a[14,17]  physical_G_upper  1
    a[14,18]  R839      1
    a[14,18]  R840      1
    a[14,18]  surrogate_G  1
    a[14,18]  physical_G_upper  1
    a[14,19]  R841      1
    a[14,19]  R842      1
    a[14,19]  surrogate_G  1
    a[14,19]  physical_G_upper  1
    a[14,20]  R843      1
    a[14,20]  R844      1
    a[14,20]  surrogate_G  1
    a[14,20]  physical_G_upper  1
    a[14,21]  R845      1
    a[14,21]  R846      1
    a[14,21]  surrogate_G  1
    a[14,21]  physical_G_upper  1
    a[14,22]  R847      1
    a[14,22]  R848      1
    a[14,22]  surrogate_G  1
    a[14,22]  physical_G_upper  1
    a[14,23]  R849      1
    a[14,23]  R850      1
    a[14,23]  surrogate_G  1
    a[14,23]  physical_G_upper  1
    a[14,24]  R851      1
    a[14,24]  R852      1
    a[14,24]  surrogate_G  1
    a[14,24]  physical_G_upper  1
    a[14,25]  R853      1
    a[14,25]  R854      1
    a[14,25]  surrogate_G  1
    a[14,25]  physical_G_upper  1
    a[14,26]  R855      1
    a[14,26]  R856      1
    a[14,26]  surrogate_G  1
    a[14,26]  physical_G_upper  1
    a[14,27]  R857      1
    a[14,27]  R858      1
    a[14,27]  surrogate_G  1
    a[14,27]  physical_G_upper  1
    a[14,28]  R859      1
    a[14,28]  R860      1
    a[14,28]  surrogate_G  1
    a[14,28]  physical_G_upper  1
    a[14,29]  R861      1
    a[14,29]  R862      1
    a[14,29]  surrogate_G  1
    a[14,29]  physical_G_upper  1
    a[14,30]  R863      1
    a[14,30]  R864      1
    a[14,30]  surrogate_G  1
    a[14,30]  physical_G_upper  1
    a[14,31]  R865      1
    a[14,31]  R866      1
    a[14,31]  surrogate_G  1
    a[14,31]  physical_G_upper  1
    a[14,32]  R867      1
    a[14,32]  R868      1
    a[14,32]  surrogate_G  1
    a[14,32]  physical_G_upper  1
    a[14,33]  R869      1
    a[14,33]  R870      1
    a[14,33]  surrogate_G  1
    a[14,33]  physical_G_upper  1
    a[14,34]  R871      1
    a[14,34]  R872      1
    a[14,34]  surrogate_G  1
    a[14,34]  physical_G_upper  1
    a[14,35]  R873      1
    a[14,35]  R874      1
    a[14,35]  surrogate_G  1
    a[14,35]  physical_G_upper  1
    a[15,16]  R875      1
    a[15,16]  R876      1
    a[15,16]  surrogate_G  1
    a[15,16]  physical_G_upper  1
    a[15,17]  R877      1
    a[15,17]  R878      1
    a[15,17]  surrogate_G  1
    a[15,17]  physical_G_upper  1
    a[15,18]  R879      1
    a[15,18]  R880      1
    a[15,18]  surrogate_G  1
    a[15,18]  physical_G_upper  1
    a[15,19]  R881      1
    a[15,19]  R882      1
    a[15,19]  surrogate_G  1
    a[15,19]  physical_G_upper  1
    a[15,20]  R883      1
    a[15,20]  R884      1
    a[15,20]  surrogate_G  1
    a[15,20]  physical_G_upper  1
    a[15,21]  R885      1
    a[15,21]  R886      1
    a[15,21]  surrogate_G  1
    a[15,21]  physical_G_upper  1
    a[15,22]  R887      1
    a[15,22]  R888      1
    a[15,22]  surrogate_G  1
    a[15,22]  physical_G_upper  1
    a[15,23]  R889      1
    a[15,23]  R890      1
    a[15,23]  surrogate_G  1
    a[15,23]  physical_G_upper  1
    a[15,24]  R891      1
    a[15,24]  R892      1
    a[15,24]  surrogate_G  1
    a[15,24]  physical_G_upper  1
    a[15,25]  R893      1
    a[15,25]  R894      1
    a[15,25]  surrogate_G  1
    a[15,25]  physical_G_upper  1
    a[15,26]  R895      1
    a[15,26]  R896      1
    a[15,26]  surrogate_G  1
    a[15,26]  physical_G_upper  1
    a[15,27]  R897      1
    a[15,27]  R898      1
    a[15,27]  surrogate_G  1
    a[15,27]  physical_G_upper  1
    a[15,28]  R899      1
    a[15,28]  R900      1
    a[15,28]  surrogate_G  1
    a[15,28]  physical_G_upper  1
    a[15,29]  R901      1
    a[15,29]  R902      1
    a[15,29]  surrogate_G  1
    a[15,29]  physical_G_upper  1
    a[15,30]  R903      1
    a[15,30]  R904      1
    a[15,30]  surrogate_G  1
    a[15,30]  physical_G_upper  1
    a[15,31]  R905      1
    a[15,31]  R906      1
    a[15,31]  surrogate_G  1
    a[15,31]  physical_G_upper  1
    a[15,32]  R907      1
    a[15,32]  R908      1
    a[15,32]  surrogate_G  1
    a[15,32]  physical_G_upper  1
    a[15,33]  R909      1
    a[15,33]  R910      1
    a[15,33]  surrogate_G  1
    a[15,33]  physical_G_upper  1
    a[15,34]  R911      1
    a[15,34]  R912      1
    a[15,34]  surrogate_G  1
    a[15,34]  physical_G_upper  1
    a[15,35]  R913      1
    a[15,35]  R914      1
    a[15,35]  surrogate_G  1
    a[15,35]  physical_G_upper  1
    a[16,17]  R915      1
    a[16,17]  R916      1
    a[16,17]  surrogate_G  1
    a[16,17]  physical_G_upper  1
    a[16,18]  R917      1
    a[16,18]  R918      1
    a[16,18]  surrogate_G  1
    a[16,18]  physical_G_upper  1
    a[16,19]  R919      1
    a[16,19]  R920      1
    a[16,19]  surrogate_G  1
    a[16,19]  physical_G_upper  1
    a[16,20]  R921      1
    a[16,20]  R922      1
    a[16,20]  surrogate_G  1
    a[16,20]  physical_G_upper  1
    a[16,21]  R923      1
    a[16,21]  R924      1
    a[16,21]  surrogate_G  1
    a[16,21]  physical_G_upper  1
    a[16,22]  R925      1
    a[16,22]  R926      1
    a[16,22]  surrogate_G  1
    a[16,22]  physical_G_upper  1
    a[16,23]  R927      1
    a[16,23]  R928      1
    a[16,23]  surrogate_G  1
    a[16,23]  physical_G_upper  1
    a[16,24]  R929      1
    a[16,24]  R930      1
    a[16,24]  surrogate_G  1
    a[16,24]  physical_G_upper  1
    a[16,25]  R931      1
    a[16,25]  R932      1
    a[16,25]  surrogate_G  1
    a[16,25]  physical_G_upper  1
    a[16,26]  R933      1
    a[16,26]  R934      1
    a[16,26]  surrogate_G  1
    a[16,26]  physical_G_upper  1
    a[16,27]  R935      1
    a[16,27]  R936      1
    a[16,27]  surrogate_G  1
    a[16,27]  physical_G_upper  1
    a[16,28]  R937      1
    a[16,28]  R938      1
    a[16,28]  surrogate_G  1
    a[16,28]  physical_G_upper  1
    a[16,29]  R939      1
    a[16,29]  R940      1
    a[16,29]  surrogate_G  1
    a[16,29]  physical_G_upper  1
    a[16,30]  R941      1
    a[16,30]  R942      1
    a[16,30]  surrogate_G  1
    a[16,30]  physical_G_upper  1
    a[16,31]  R943      1
    a[16,31]  R944      1
    a[16,31]  surrogate_G  1
    a[16,31]  physical_G_upper  1
    a[16,32]  R945      1
    a[16,32]  R946      1
    a[16,32]  surrogate_G  1
    a[16,32]  physical_G_upper  1
    a[16,33]  R947      1
    a[16,33]  R948      1
    a[16,33]  surrogate_G  1
    a[16,33]  physical_G_upper  1
    a[16,34]  R949      1
    a[16,34]  R950      1
    a[16,34]  surrogate_G  1
    a[16,34]  physical_G_upper  1
    a[16,35]  R951      1
    a[16,35]  R952      1
    a[16,35]  surrogate_G  1
    a[16,35]  physical_G_upper  1
    a[17,18]  R953      1
    a[17,18]  R954      1
    a[17,18]  surrogate_G  1
    a[17,18]  physical_G_upper  1
    a[17,19]  R955      1
    a[17,19]  R956      1
    a[17,19]  surrogate_G  1
    a[17,19]  physical_G_upper  1
    a[17,20]  R957      1
    a[17,20]  R958      1
    a[17,20]  surrogate_G  1
    a[17,20]  physical_G_upper  1
    a[17,21]  R959      1
    a[17,21]  R960      1
    a[17,21]  surrogate_G  1
    a[17,21]  physical_G_upper  1
    a[17,22]  R961      1
    a[17,22]  R962      1
    a[17,22]  surrogate_G  1
    a[17,22]  physical_G_upper  1
    a[17,23]  R963      1
    a[17,23]  R964      1
    a[17,23]  surrogate_G  1
    a[17,23]  physical_G_upper  1
    a[17,24]  R965      1
    a[17,24]  R966      1
    a[17,24]  surrogate_G  1
    a[17,24]  physical_G_upper  1
    a[17,25]  R967      1
    a[17,25]  R968      1
    a[17,25]  surrogate_G  1
    a[17,25]  physical_G_upper  1
    a[17,26]  R969      1
    a[17,26]  R970      1
    a[17,26]  surrogate_G  1
    a[17,26]  physical_G_upper  1
    a[17,27]  R971      1
    a[17,27]  R972      1
    a[17,27]  surrogate_G  1
    a[17,27]  physical_G_upper  1
    a[17,28]  R973      1
    a[17,28]  R974      1
    a[17,28]  surrogate_G  1
    a[17,28]  physical_G_upper  1
    a[17,29]  R975      1
    a[17,29]  R976      1
    a[17,29]  surrogate_G  1
    a[17,29]  physical_G_upper  1
    a[17,30]  R977      1
    a[17,30]  R978      1
    a[17,30]  surrogate_G  1
    a[17,30]  physical_G_upper  1
    a[17,31]  R979      1
    a[17,31]  R980      1
    a[17,31]  surrogate_G  1
    a[17,31]  physical_G_upper  1
    a[17,32]  R981      1
    a[17,32]  R982      1
    a[17,32]  surrogate_G  1
    a[17,32]  physical_G_upper  1
    a[17,33]  R983      1
    a[17,33]  R984      1
    a[17,33]  surrogate_G  1
    a[17,33]  physical_G_upper  1
    a[17,34]  R985      1
    a[17,34]  R986      1
    a[17,34]  surrogate_G  1
    a[17,34]  physical_G_upper  1
    a[17,35]  R987      1
    a[17,35]  R988      1
    a[17,35]  surrogate_G  1
    a[17,35]  physical_G_upper  1
    a[18,19]  R989      1
    a[18,19]  R990      1
    a[18,19]  surrogate_G  1
    a[18,19]  physical_G_upper  1
    a[18,20]  R991      1
    a[18,20]  R992      1
    a[18,20]  surrogate_G  1
    a[18,20]  physical_G_upper  1
    a[18,21]  R993      1
    a[18,21]  R994      1
    a[18,21]  surrogate_G  1
    a[18,21]  physical_G_upper  1
    a[18,22]  R995      1
    a[18,22]  R996      1
    a[18,22]  surrogate_G  1
    a[18,22]  physical_G_upper  1
    a[18,23]  R997      1
    a[18,23]  R998      1
    a[18,23]  surrogate_G  1
    a[18,23]  physical_G_upper  1
    a[18,24]  R999      1
    a[18,24]  R1000     1
    a[18,24]  surrogate_G  1
    a[18,24]  physical_G_upper  1
    a[18,25]  R1001     1
    a[18,25]  R1002     1
    a[18,25]  surrogate_G  1
    a[18,25]  physical_G_upper  1
    a[18,26]  R1003     1
    a[18,26]  R1004     1
    a[18,26]  surrogate_G  1
    a[18,26]  physical_G_upper  1
    a[18,27]  R1005     1
    a[18,27]  R1006     1
    a[18,27]  surrogate_G  1
    a[18,27]  physical_G_upper  1
    a[18,28]  R1007     1
    a[18,28]  R1008     1
    a[18,28]  surrogate_G  1
    a[18,28]  physical_G_upper  1
    a[18,29]  R1009     1
    a[18,29]  R1010     1
    a[18,29]  surrogate_G  1
    a[18,29]  physical_G_upper  1
    a[18,30]  R1011     1
    a[18,30]  R1012     1
    a[18,30]  surrogate_G  1
    a[18,30]  physical_G_upper  1
    a[18,31]  R1013     1
    a[18,31]  R1014     1
    a[18,31]  surrogate_G  1
    a[18,31]  physical_G_upper  1
    a[18,32]  R1015     1
    a[18,32]  R1016     1
    a[18,32]  surrogate_G  1
    a[18,32]  physical_G_upper  1
    a[18,33]  R1017     1
    a[18,33]  R1018     1
    a[18,33]  surrogate_G  1
    a[18,33]  physical_G_upper  1
    a[18,34]  R1019     1
    a[18,34]  R1020     1
    a[18,34]  surrogate_G  1
    a[18,34]  physical_G_upper  1
    a[18,35]  R1021     1
    a[18,35]  R1022     1
    a[18,35]  surrogate_G  1
    a[18,35]  physical_G_upper  1
    a[19,20]  R1023     1
    a[19,20]  R1024     1
    a[19,20]  surrogate_G  1
    a[19,20]  physical_G_upper  1
    a[19,21]  R1025     1
    a[19,21]  R1026     1
    a[19,21]  surrogate_G  1
    a[19,21]  physical_G_upper  1
    a[19,22]  R1027     1
    a[19,22]  R1028     1
    a[19,22]  surrogate_G  1
    a[19,22]  physical_G_upper  1
    a[19,23]  R1029     1
    a[19,23]  R1030     1
    a[19,23]  surrogate_G  1
    a[19,23]  physical_G_upper  1
    a[19,24]  R1031     1
    a[19,24]  R1032     1
    a[19,24]  surrogate_G  1
    a[19,24]  physical_G_upper  1
    a[19,25]  R1033     1
    a[19,25]  R1034     1
    a[19,25]  surrogate_G  1
    a[19,25]  physical_G_upper  1
    a[19,26]  R1035     1
    a[19,26]  R1036     1
    a[19,26]  surrogate_G  1
    a[19,26]  physical_G_upper  1
    a[19,27]  R1037     1
    a[19,27]  R1038     1
    a[19,27]  surrogate_G  1
    a[19,27]  physical_G_upper  1
    a[19,28]  R1039     1
    a[19,28]  R1040     1
    a[19,28]  surrogate_G  1
    a[19,28]  physical_G_upper  1
    a[19,29]  R1041     1
    a[19,29]  R1042     1
    a[19,29]  surrogate_G  1
    a[19,29]  physical_G_upper  1
    a[19,30]  R1043     1
    a[19,30]  R1044     1
    a[19,30]  surrogate_G  1
    a[19,30]  physical_G_upper  1
    a[19,31]  R1045     1
    a[19,31]  R1046     1
    a[19,31]  surrogate_G  1
    a[19,31]  physical_G_upper  1
    a[19,32]  R1047     1
    a[19,32]  R1048     1
    a[19,32]  surrogate_G  1
    a[19,32]  physical_G_upper  1
    a[19,33]  R1049     1
    a[19,33]  R1050     1
    a[19,33]  surrogate_G  1
    a[19,33]  physical_G_upper  1
    a[19,34]  R1051     1
    a[19,34]  R1052     1
    a[19,34]  surrogate_G  1
    a[19,34]  physical_G_upper  1
    a[19,35]  R1053     1
    a[19,35]  R1054     1
    a[19,35]  surrogate_G  1
    a[19,35]  physical_G_upper  1
    a[20,21]  R1055     1
    a[20,21]  R1056     1
    a[20,21]  surrogate_G  1
    a[20,21]  physical_G_upper  1
    a[20,22]  R1057     1
    a[20,22]  R1058     1
    a[20,22]  surrogate_G  1
    a[20,22]  physical_G_upper  1
    a[20,23]  R1059     1
    a[20,23]  R1060     1
    a[20,23]  surrogate_G  1
    a[20,23]  physical_G_upper  1
    a[20,24]  R1061     1
    a[20,24]  R1062     1
    a[20,24]  surrogate_G  1
    a[20,24]  physical_G_upper  1
    a[20,25]  R1063     1
    a[20,25]  R1064     1
    a[20,25]  surrogate_G  1
    a[20,25]  physical_G_upper  1
    a[20,26]  R1065     1
    a[20,26]  R1066     1
    a[20,26]  surrogate_G  1
    a[20,26]  physical_G_upper  1
    a[20,27]  R1067     1
    a[20,27]  R1068     1
    a[20,27]  surrogate_G  1
    a[20,27]  physical_G_upper  1
    a[20,28]  R1069     1
    a[20,28]  R1070     1
    a[20,28]  surrogate_G  1
    a[20,28]  physical_G_upper  1
    a[20,29]  R1071     1
    a[20,29]  R1072     1
    a[20,29]  surrogate_G  1
    a[20,29]  physical_G_upper  1
    a[20,30]  R1073     1
    a[20,30]  R1074     1
    a[20,30]  surrogate_G  1
    a[20,30]  physical_G_upper  1
    a[20,31]  R1075     1
    a[20,31]  R1076     1
    a[20,31]  surrogate_G  1
    a[20,31]  physical_G_upper  1
    a[20,32]  R1077     1
    a[20,32]  R1078     1
    a[20,32]  surrogate_G  1
    a[20,32]  physical_G_upper  1
    a[20,33]  R1079     1
    a[20,33]  R1080     1
    a[20,33]  surrogate_G  1
    a[20,33]  physical_G_upper  1
    a[20,34]  R1081     1
    a[20,34]  R1082     1
    a[20,34]  surrogate_G  1
    a[20,34]  physical_G_upper  1
    a[20,35]  R1083     1
    a[20,35]  R1084     1
    a[20,35]  surrogate_G  1
    a[20,35]  physical_G_upper  1
    a[21,22]  R1085     1
    a[21,22]  R1086     1
    a[21,22]  surrogate_G  1
    a[21,22]  physical_G_upper  1
    a[21,23]  R1087     1
    a[21,23]  R1088     1
    a[21,23]  surrogate_G  1
    a[21,23]  physical_G_upper  1
    a[21,24]  R1089     1
    a[21,24]  R1090     1
    a[21,24]  surrogate_G  1
    a[21,24]  physical_G_upper  1
    a[21,25]  R1091     1
    a[21,25]  R1092     1
    a[21,25]  surrogate_G  1
    a[21,25]  physical_G_upper  1
    a[21,26]  R1093     1
    a[21,26]  R1094     1
    a[21,26]  surrogate_G  1
    a[21,26]  physical_G_upper  1
    a[21,27]  R1095     1
    a[21,27]  R1096     1
    a[21,27]  surrogate_G  1
    a[21,27]  physical_G_upper  1
    a[21,28]  R1097     1
    a[21,28]  R1098     1
    a[21,28]  surrogate_G  1
    a[21,28]  physical_G_upper  1
    a[21,29]  R1099     1
    a[21,29]  R1100     1
    a[21,29]  surrogate_G  1
    a[21,29]  physical_G_upper  1
    a[21,30]  R1101     1
    a[21,30]  R1102     1
    a[21,30]  surrogate_G  1
    a[21,30]  physical_G_upper  1
    a[21,31]  R1103     1
    a[21,31]  R1104     1
    a[21,31]  surrogate_G  1
    a[21,31]  physical_G_upper  1
    a[21,32]  R1105     1
    a[21,32]  R1106     1
    a[21,32]  surrogate_G  1
    a[21,32]  physical_G_upper  1
    a[21,33]  R1107     1
    a[21,33]  R1108     1
    a[21,33]  surrogate_G  1
    a[21,33]  physical_G_upper  1
    a[21,34]  R1109     1
    a[21,34]  R1110     1
    a[21,34]  surrogate_G  1
    a[21,34]  physical_G_upper  1
    a[21,35]  R1111     1
    a[21,35]  R1112     1
    a[21,35]  surrogate_G  1
    a[21,35]  physical_G_upper  1
    a[22,23]  R1113     1
    a[22,23]  R1114     1
    a[22,23]  surrogate_G  1
    a[22,23]  physical_G_upper  1
    a[22,24]  R1115     1
    a[22,24]  R1116     1
    a[22,24]  surrogate_G  1
    a[22,24]  physical_G_upper  1
    a[22,25]  R1117     1
    a[22,25]  R1118     1
    a[22,25]  surrogate_G  1
    a[22,25]  physical_G_upper  1
    a[22,26]  R1119     1
    a[22,26]  R1120     1
    a[22,26]  surrogate_G  1
    a[22,26]  physical_G_upper  1
    a[22,27]  R1121     1
    a[22,27]  R1122     1
    a[22,27]  surrogate_G  1
    a[22,27]  physical_G_upper  1
    a[22,28]  R1123     1
    a[22,28]  R1124     1
    a[22,28]  surrogate_G  1
    a[22,28]  physical_G_upper  1
    a[22,29]  R1125     1
    a[22,29]  R1126     1
    a[22,29]  surrogate_G  1
    a[22,29]  physical_G_upper  1
    a[22,30]  R1127     1
    a[22,30]  R1128     1
    a[22,30]  surrogate_G  1
    a[22,30]  physical_G_upper  1
    a[22,31]  R1129     1
    a[22,31]  R1130     1
    a[22,31]  surrogate_G  1
    a[22,31]  physical_G_upper  1
    a[22,32]  R1131     1
    a[22,32]  R1132     1
    a[22,32]  surrogate_G  1
    a[22,32]  physical_G_upper  1
    a[22,33]  R1133     1
    a[22,33]  R1134     1
    a[22,33]  surrogate_G  1
    a[22,33]  physical_G_upper  1
    a[22,34]  R1135     1
    a[22,34]  R1136     1
    a[22,34]  surrogate_G  1
    a[22,34]  physical_G_upper  1
    a[22,35]  R1137     1
    a[22,35]  R1138     1
    a[22,35]  surrogate_G  1
    a[22,35]  physical_G_upper  1
    a[23,24]  R1139     1
    a[23,24]  R1140     1
    a[23,24]  surrogate_G  1
    a[23,24]  physical_G_upper  1
    a[23,25]  R1141     1
    a[23,25]  R1142     1
    a[23,25]  surrogate_G  1
    a[23,25]  physical_G_upper  1
    a[23,26]  R1143     1
    a[23,26]  R1144     1
    a[23,26]  surrogate_G  1
    a[23,26]  physical_G_upper  1
    a[23,27]  R1145     1
    a[23,27]  R1146     1
    a[23,27]  surrogate_G  1
    a[23,27]  physical_G_upper  1
    a[23,28]  R1147     1
    a[23,28]  R1148     1
    a[23,28]  surrogate_G  1
    a[23,28]  physical_G_upper  1
    a[23,29]  R1149     1
    a[23,29]  R1150     1
    a[23,29]  surrogate_G  1
    a[23,29]  physical_G_upper  1
    a[23,30]  R1151     1
    a[23,30]  R1152     1
    a[23,30]  surrogate_G  1
    a[23,30]  physical_G_upper  1
    a[23,31]  R1153     1
    a[23,31]  R1154     1
    a[23,31]  surrogate_G  1
    a[23,31]  physical_G_upper  1
    a[23,32]  R1155     1
    a[23,32]  R1156     1
    a[23,32]  surrogate_G  1
    a[23,32]  physical_G_upper  1
    a[23,33]  R1157     1
    a[23,33]  R1158     1
    a[23,33]  surrogate_G  1
    a[23,33]  physical_G_upper  1
    a[23,34]  R1159     1
    a[23,34]  R1160     1
    a[23,34]  surrogate_G  1
    a[23,34]  physical_G_upper  1
    a[23,35]  R1161     1
    a[23,35]  R1162     1
    a[23,35]  surrogate_G  1
    a[23,35]  physical_G_upper  1
    a[24,25]  R1163     1
    a[24,25]  R1164     1
    a[24,25]  surrogate_G  1
    a[24,25]  physical_G_upper  1
    a[24,26]  R1165     1
    a[24,26]  R1166     1
    a[24,26]  surrogate_G  1
    a[24,26]  physical_G_upper  1
    a[24,27]  R1167     1
    a[24,27]  R1168     1
    a[24,27]  surrogate_G  1
    a[24,27]  physical_G_upper  1
    a[24,28]  R1169     1
    a[24,28]  R1170     1
    a[24,28]  surrogate_G  1
    a[24,28]  physical_G_upper  1
    a[24,29]  R1171     1
    a[24,29]  R1172     1
    a[24,29]  surrogate_G  1
    a[24,29]  physical_G_upper  1
    a[24,30]  R1173     1
    a[24,30]  R1174     1
    a[24,30]  surrogate_G  1
    a[24,30]  physical_G_upper  1
    a[24,31]  R1175     1
    a[24,31]  R1176     1
    a[24,31]  surrogate_G  1
    a[24,31]  physical_G_upper  1
    a[24,32]  R1177     1
    a[24,32]  R1178     1
    a[24,32]  surrogate_G  1
    a[24,32]  physical_G_upper  1
    a[24,33]  R1179     1
    a[24,33]  R1180     1
    a[24,33]  surrogate_G  1
    a[24,33]  physical_G_upper  1
    a[24,34]  R1181     1
    a[24,34]  R1182     1
    a[24,34]  surrogate_G  1
    a[24,34]  physical_G_upper  1
    a[24,35]  R1183     1
    a[24,35]  R1184     1
    a[24,35]  surrogate_G  1
    a[24,35]  physical_G_upper  1
    a[25,26]  R1185     1
    a[25,26]  R1186     1
    a[25,26]  surrogate_G  1
    a[25,26]  physical_G_upper  1
    a[25,27]  R1187     1
    a[25,27]  R1188     1
    a[25,27]  surrogate_G  1
    a[25,27]  physical_G_upper  1
    a[25,28]  R1189     1
    a[25,28]  R1190     1
    a[25,28]  surrogate_G  1
    a[25,28]  physical_G_upper  1
    a[25,29]  R1191     1
    a[25,29]  R1192     1
    a[25,29]  surrogate_G  1
    a[25,29]  physical_G_upper  1
    a[25,30]  R1193     1
    a[25,30]  R1194     1
    a[25,30]  surrogate_G  1
    a[25,30]  physical_G_upper  1
    a[25,31]  R1195     1
    a[25,31]  R1196     1
    a[25,31]  surrogate_G  1
    a[25,31]  physical_G_upper  1
    a[25,32]  R1197     1
    a[25,32]  R1198     1
    a[25,32]  surrogate_G  1
    a[25,32]  physical_G_upper  1
    a[25,33]  R1199     1
    a[25,33]  R1200     1
    a[25,33]  surrogate_G  1
    a[25,33]  physical_G_upper  1
    a[25,34]  R1201     1
    a[25,34]  R1202     1
    a[25,34]  surrogate_G  1
    a[25,34]  physical_G_upper  1
    a[25,35]  R1203     1
    a[25,35]  R1204     1
    a[25,35]  surrogate_G  1
    a[25,35]  physical_G_upper  1
    a[26,27]  R1205     1
    a[26,27]  R1206     1
    a[26,27]  surrogate_G  1
    a[26,27]  physical_G_upper  1
    a[26,28]  R1207     1
    a[26,28]  R1208     1
    a[26,28]  surrogate_G  1
    a[26,28]  physical_G_upper  1
    a[26,29]  R1209     1
    a[26,29]  R1210     1
    a[26,29]  surrogate_G  1
    a[26,29]  physical_G_upper  1
    a[26,30]  R1211     1
    a[26,30]  R1212     1
    a[26,30]  surrogate_G  1
    a[26,30]  physical_G_upper  1
    a[26,31]  R1213     1
    a[26,31]  R1214     1
    a[26,31]  surrogate_G  1
    a[26,31]  physical_G_upper  1
    a[26,32]  R1215     1
    a[26,32]  R1216     1
    a[26,32]  surrogate_G  1
    a[26,32]  physical_G_upper  1
    a[26,33]  R1217     1
    a[26,33]  R1218     1
    a[26,33]  surrogate_G  1
    a[26,33]  physical_G_upper  1
    a[26,34]  R1219     1
    a[26,34]  R1220     1
    a[26,34]  surrogate_G  1
    a[26,34]  physical_G_upper  1
    a[26,35]  R1221     1
    a[26,35]  R1222     1
    a[26,35]  surrogate_G  1
    a[26,35]  physical_G_upper  1
    a[27,28]  R1223     1
    a[27,28]  R1224     1
    a[27,28]  surrogate_G  1
    a[27,28]  physical_G_upper  1
    a[27,29]  R1225     1
    a[27,29]  R1226     1
    a[27,29]  surrogate_G  1
    a[27,29]  physical_G_upper  1
    a[27,30]  R1227     1
    a[27,30]  R1228     1
    a[27,30]  surrogate_G  1
    a[27,30]  physical_G_upper  1
    a[27,31]  R1229     1
    a[27,31]  R1230     1
    a[27,31]  surrogate_G  1
    a[27,31]  physical_G_upper  1
    a[27,32]  R1231     1
    a[27,32]  R1232     1
    a[27,32]  surrogate_G  1
    a[27,32]  physical_G_upper  1
    a[27,33]  R1233     1
    a[27,33]  R1234     1
    a[27,33]  surrogate_G  1
    a[27,33]  physical_G_upper  1
    a[27,34]  R1235     1
    a[27,34]  R1236     1
    a[27,34]  surrogate_G  1
    a[27,34]  physical_G_upper  1
    a[27,35]  R1237     1
    a[27,35]  R1238     1
    a[27,35]  surrogate_G  1
    a[27,35]  physical_G_upper  1
    a[28,29]  R1239     1
    a[28,29]  R1240     1
    a[28,29]  surrogate_G  1
    a[28,29]  physical_G_upper  1
    a[28,30]  R1241     1
    a[28,30]  R1242     1
    a[28,30]  surrogate_G  1
    a[28,30]  physical_G_upper  1
    a[28,31]  R1243     1
    a[28,31]  R1244     1
    a[28,31]  surrogate_G  1
    a[28,31]  physical_G_upper  1
    a[28,32]  R1245     1
    a[28,32]  R1246     1
    a[28,32]  surrogate_G  1
    a[28,32]  physical_G_upper  1
    a[28,33]  R1247     1
    a[28,33]  R1248     1
    a[28,33]  surrogate_G  1
    a[28,33]  physical_G_upper  1
    a[28,34]  R1249     1
    a[28,34]  R1250     1
    a[28,34]  surrogate_G  1
    a[28,34]  physical_G_upper  1
    a[28,35]  R1251     1
    a[28,35]  R1252     1
    a[28,35]  surrogate_G  1
    a[28,35]  physical_G_upper  1
    a[29,30]  R1253     1
    a[29,30]  R1254     1
    a[29,30]  surrogate_G  1
    a[29,30]  physical_G_upper  1
    a[29,31]  R1255     1
    a[29,31]  R1256     1
    a[29,31]  surrogate_G  1
    a[29,31]  physical_G_upper  1
    a[29,32]  R1257     1
    a[29,32]  R1258     1
    a[29,32]  surrogate_G  1
    a[29,32]  physical_G_upper  1
    a[29,33]  R1259     1
    a[29,33]  R1260     1
    a[29,33]  surrogate_G  1
    a[29,33]  physical_G_upper  1
    a[29,34]  R1261     1
    a[29,34]  R1262     1
    a[29,34]  surrogate_G  1
    a[29,34]  physical_G_upper  1
    a[29,35]  R1263     1
    a[29,35]  R1264     1
    a[29,35]  surrogate_G  1
    a[29,35]  physical_G_upper  1
    a[30,31]  R1265     1
    a[30,31]  R1266     1
    a[30,31]  surrogate_G  1
    a[30,31]  physical_G_upper  1
    a[30,32]  R1267     1
    a[30,32]  R1268     1
    a[30,32]  surrogate_G  1
    a[30,32]  physical_G_upper  1
    a[30,33]  R1269     1
    a[30,33]  R1270     1
    a[30,33]  surrogate_G  1
    a[30,33]  physical_G_upper  1
    a[30,34]  R1271     1
    a[30,34]  R1272     1
    a[30,34]  surrogate_G  1
    a[30,34]  physical_G_upper  1
    a[30,35]  R1273     1
    a[30,35]  R1274     1
    a[30,35]  surrogate_G  1
    a[30,35]  physical_G_upper  1
    a[31,32]  R1275     1
    a[31,32]  R1276     1
    a[31,32]  surrogate_G  1
    a[31,32]  physical_G_upper  1
    a[31,33]  R1277     1
    a[31,33]  R1278     1
    a[31,33]  surrogate_G  1
    a[31,33]  physical_G_upper  1
    a[31,34]  R1279     1
    a[31,34]  R1280     1
    a[31,34]  surrogate_G  1
    a[31,34]  physical_G_upper  1
    a[31,35]  R1281     1
    a[31,35]  R1282     1
    a[31,35]  surrogate_G  1
    a[31,35]  physical_G_upper  1
    a[32,33]  R1283     1
    a[32,33]  R1284     1
    a[32,33]  surrogate_G  1
    a[32,33]  physical_G_upper  1
    a[32,34]  R1285     1
    a[32,34]  R1286     1
    a[32,34]  surrogate_G  1
    a[32,34]  physical_G_upper  1
    a[32,35]  R1287     1
    a[32,35]  R1288     1
    a[32,35]  surrogate_G  1
    a[32,35]  physical_G_upper  1
    a[33,34]  R1289     1
    a[33,34]  R1290     1
    a[33,34]  surrogate_G  1
    a[33,34]  physical_G_upper  1
    a[33,35]  R1291     1
    a[33,35]  R1292     1
    a[33,35]  surrogate_G  1
    a[33,35]  physical_G_upper  1
    a[34,35]  R1293     1
    a[34,35]  R1294     1
    a[34,35]  surrogate_G  1
    a[34,35]  physical_G_upper  1
    q         OBJ       1
    q         surrogate_G  -1.4343611111111113e+03
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      onehot_3  1
    RHS1      onehot_4  1
    RHS1      onehot_5  1
    RHS1      onehot_6  1
    RHS1      onehot_7  1
    RHS1      onehot_8  1
    RHS1      onehot_9  1
    RHS1      onehot_10  1
    RHS1      onehot_11  1
    RHS1      onehot_12  1
    RHS1      onehot_13  1
    RHS1      onehot_14  1
    RHS1      onehot_15  1
    RHS1      onehot_16  1
    RHS1      onehot_17  1
    RHS1      onehot_18  1
    RHS1      onehot_19  1
    RHS1      onehot_20  1
    RHS1      onehot_21  1
    RHS1      onehot_22  1
    RHS1      onehot_23  1
    RHS1      onehot_24  1
    RHS1      onehot_25  1
    RHS1      onehot_26  1
    RHS1      onehot_27  1
    RHS1      onehot_28  1
    RHS1      onehot_29  1
    RHS1      onehot_30  1
    RHS1      onehot_31  1
    RHS1      onehot_32  1
    RHS1      onehot_33  1
    RHS1      onehot_34  1
    RHS1      onehot_35  1
    RHS1      hard_lower  251
    RHS1      hard_upper  326
    RHS1      bin_lower  4.0762201548661352e+01
    RHS1      bin_upper  4.0981746031746034e+01
BOUNDS
 BV BND1      x[1,4]  
 BV BND1      x[2,12] 
 BV BND1      x[3,13] 
 BV BND1      x[4,7]  
 BV BND1      x[4,13] 
 BV BND1      x[5,8]  
 BV BND1      x[6,4]  
 BV BND1      x[7,10] 
 BV BND1      x[8,7]  
 BV BND1      x[8,13] 
 BV BND1      x[9,5]  
 BV BND1      x[9,10] 
 BV BND1      x[10,4] 
 BV BND1      x[10,6] 
 BV BND1      x[10,7] 
 BV BND1      x[11,7] 
 BV BND1      x[12,8] 
 BV BND1      x[12,14]
 BV BND1      x[13,10]
 BV BND1      x[14,10]
 BV BND1      x[15,10]
 BV BND1      x[16,3] 
 BV BND1      x[16,11]
 BV BND1      x[17,16]
 BV BND1      x[18,7] 
 BV BND1      x[19,9] 
 BV BND1      x[20,7] 
 BV BND1      x[20,13]
 BV BND1      x[21,9] 
 BV BND1      x[22,10]
 BV BND1      x[23,8] 
 BV BND1      x[23,13]
 BV BND1      x[24,2] 
 BV BND1      x[24,4] 
 BV BND1      x[24,5] 
 BV BND1      x[24,6] 
 BV BND1      x[24,7] 
 BV BND1      x[24,8] 
 BV BND1      x[25,7] 
 BV BND1      x[26,8] 
 BV BND1      x[26,13]
 BV BND1      x[27,9] 
 BV BND1      x[28,7] 
 BV BND1      x[29,7] 
 BV BND1      x[29,12]
 BV BND1      x[30,11]
 BV BND1      x[31,7] 
 BV BND1      x[32,8] 
 BV BND1      x[33,13]
 BV BND1      x[34,8] 
 BV BND1      x[35,9] 
ENDATA
